package com.soliste.bolbec.commun.service.model;

/**
 * DTO d�crivant une trame HTTP (API Rest) � archiver c�t� routeur
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/09/2016</TD><TD>JDE</TD><TD>G9R2C1 - Refactoring de l'archivage des messages API (IN et OUT)</TD></TR>
 * </TABLE>
 */
public class MessageAPIOutDTO extends MessageAPIDTO {

	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = 7854286564140096235L;

	/**
	 * Le constructeur du DTO MessageAPIOut
	 *
	 * @param partenaire
	 * @param utilisateur
	 * @param methode
	 * @param url
	 * @param service
	 * @param idCommande
	 * @param codeResponse
	 * @param contenuRequete
	 * @param contenuReponse
	 */
	public MessageAPIOutDTO(String partenaire, String utilisateur, String methode, String url, String service, String idCommande, String codeResponse, String contenuRequete, String contenuReponse) {
		super(partenaire, utilisateur, methode, url, service, idCommande, codeResponse, contenuRequete, contenuReponse);
	}

	public MessageAPIOutDTO() {
		super(null, null, null, null, null, null, null, null, null);
	}
}
