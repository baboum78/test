/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.sort;

import java.io.Serializable;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe d�finissant les deux directions possibles pour le tri (ASC et DESC).
 * Cette classe impl�mente le pattern "type-safe enumeration". On peut donc
 * comparer deux instances de cette classe en utilisant == plut�t que equals.
 * 
 * @author rgvs7490
 */
public final class Direction implements Serializable {

	/**
	 * La direction ascendante
	 */
	public static final Direction ASC = new Direction("asc");
	/**
	 * La direction descendante
	 */
	public static final Direction DESC = new Direction("desc");
	/**
	 * La valeur
	 */
	private String value;

	/**
	 * Constructeur, priv� pour �viter les instanciations.
	 * 
	 * @param value
	 */
	private Direction(String value) {
		this.value = value;
	}

	/**
	 * Retourne la direction correspondant � la cha�ne donn�e. Si la cha�ne est
	 * "desc" (casse ignor�e), DESC est retourn�. Si la cha�ne est "asc" (casse
	 * ignor�e), ASC est retourn�. Dans les autres cas, une exception est lanc�e
	 * (IllegalArgumentException)
	 * 
	 * @param s
	 * la direction sous forme de cha�ne de caract�re
	 * @return la direction correspondant � la cha�ne donn�e
	 * @throws IllegalArgumentException
	 * si la cha�ne donn�e n'est pas une direction.
	 */
	public static Direction fromString(String s) throws IllegalArgumentException {
		if (DESC.value.equalsIgnoreCase(s)) {
			return DESC;
		} else if (ASC.value.equalsIgnoreCase(s)) {
			return ASC;
		} else {
			throw new IllegalArgumentException(s + " is not a valid direction");
		}
	}

	/**
	 * 
	 */
	public boolean equals(Object o) {
		return (this == o);
	}

	/**
	 * 
	 */
	public int hashCode() {
		return value.hashCode();
	}

	/**
	 * Retourne "asc" pour ASC, et "desc" pour DESC. Cette valeur peut donc �tre
	 * utilis�e telle quelle dans une requ�te SQL.
	 * 
	 * @return "asc" pour ASC, et "desc" pour DESC. Cette valeur peut donc �tre
	 * utilis�e telle quelle dans une requ�te SQL.
	 */
	public String toString() {
		return value;
	}

	/**
	 * M�thode permettant d'�tre s�r que seules deux instances de cette classe
	 * existent, m�me en cas de d�s�rialisation (type-safe enum)
	 * 
	 * @return ?
	 */
	private Object readResolve() {
		if (DESC.value.equals(value)) {
			return DESC;
		}
		return ASC;
	}
}