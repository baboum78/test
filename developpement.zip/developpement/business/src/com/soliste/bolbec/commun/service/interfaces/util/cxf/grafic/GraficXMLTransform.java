package com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic;

import java.io.OutputStream;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.factory.GraficXMLTransformCallBackFactory;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.CacheWriteSwitcherOutputStream;

/**
 * Intercepteur encapsulant le message dans CacheWriteSwitcherOutputStream
 * Utile pour modifier le message avant �mission
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 */
public class GraficXMLTransform extends AbstractPhaseInterceptor<Message> {

	private final GraficXMLTransformCallBackFactory graficXMLTransformCallBackFactory;

	public GraficXMLTransform(GraficXMLTransformCallBackFactory graficXMLTransformCallBackFactory) {
		super(Phase.PRE_STREAM);
		this.graficXMLTransformCallBackFactory = graficXMLTransformCallBackFactory;
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		// Nous r�cup�rons le message, ...
		OutputStream os = message.getContent(OutputStream.class);
		// ...nous l'encapsulons dans un objet OutPutStream qui g�re le cache
		final CachedOutputStream newOut = new CacheWriteSwitcherOutputStream(os);

		message.setContent(OutputStream.class, newOut);
		newOut.registerCallback(graficXMLTransformCallBackFactory.createGraficXMLTransformCallBack());
	}

}
