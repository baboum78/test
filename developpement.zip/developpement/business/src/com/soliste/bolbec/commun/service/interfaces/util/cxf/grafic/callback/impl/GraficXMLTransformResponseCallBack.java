package com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.impl;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.GraficXMLTransformCallBack;
import com.soliste.bolbec.commun.service.util.xml.XmlDomFactory;

/**
 * Impl�mentation de la transformation d'un message de r�ponse � destination de Grafic
 * 
 * @author bperrard
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 */
public class GraficXMLTransformResponseCallBack extends GraficXMLTransformCallBack {

	public GraficXMLTransformResponseCallBack(XmlDomFactory xmlDomFactory) {
		super(xmlDomFactory);
	}

	/**
	 * A partir d'un message de r�ponse, retourne le contenu de l'�l�ment Body
	 * 
	 * @param body l'�lement body du message SOAP
	 * @return le corps du message
	 */
	@Override
	protected Element getRootMessage(Node body) {
		NodeList bodyChildren = body.getChildNodes();

		Node node;
		for (int i = 0; i < bodyChildren.getLength(); i++) {
			node = bodyChildren.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				return (Element) node;
			}
		}
		throw new IllegalStateException("Body must have at least one element");
	}

}
