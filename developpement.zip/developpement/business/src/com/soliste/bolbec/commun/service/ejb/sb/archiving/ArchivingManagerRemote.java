package com.soliste.bolbec.commun.service.ejb.sb.archiving;

import javax.ejb.EJBObject;

public interface ArchivingManagerRemote extends IArchivingManagerRemote, EJBObject {

}
