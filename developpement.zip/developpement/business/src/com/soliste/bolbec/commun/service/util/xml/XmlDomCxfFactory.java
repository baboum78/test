package com.soliste.bolbec.commun.service.util.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerFactory;

/**
 * Factory XML d�di�e � CXF (UTF-8, avec gestion des namespace, avec d�claration XML, indentation...)
 * 
 * @author bperrard
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 */
public class XmlDomCxfFactory implements XmlDomFactory {

	private final DocumentBuilderFactory documentBuilderFactory;
	private final TransformerFactory transformerFactory;

	private static final XmlDomFactory INSTANCE = new XmlDomCxfFactory();

	/**
	 * R�cup�re l'instance singleton
	 * 
	 * @return l'instance singleton
	 */
	public static XmlDomFactory getInstance() {
		return INSTANCE;
	}

	/**
	 * Initialise le document builder et le transformer
	 * Constructeur priv� car classe singleton
	 */
	private XmlDomCxfFactory() {
		documentBuilderFactory = DocumentBuilderFactory.newInstance();
		documentBuilderFactory.setNamespaceAware(true);
		transformerFactory = TransformerFactory.newInstance();
	}

	/**
	 * @return une instance DocumentBuilder
	 */
	@Override
	public DocumentBuilder createDocumentBuilder() {
		try {
			return documentBuilderFactory.newDocumentBuilder();
		} catch (ParserConfigurationException e) {
			// Cette erreur ne devrait pas se produire
			throw new RuntimeException("Cr�ation instance DocumentBuilder impossible", e);
		}
	}

	/**
	 * @return une instance Tranformer
	 */
	@Override
	public Transformer createTranformer() {
		Transformer transformer;
		try {
			transformer = transformerFactory.newTransformer();
		} catch (TransformerConfigurationException e) {
			// Cette erreur ne devrait pas se produire
			throw new RuntimeException("Cr�ation instance Transformer impossible", e);
		}
		transformer.setOutputProperty(OutputKeys.OMIT_XML_DECLARATION, "yes");
		transformer.setOutputProperty(OutputKeys.METHOD, "xml");
		transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
		transformer.setOutputProperty(OutputKeys.INDENT, "yes");
		return transformer;
	}

}
