/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Interface home de l'EJB session CounterManager.
 * 
 * @author afbu7552
 */
public interface CounterManagerHome extends EJBLocalHome {

	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public CounterManagerLocal create() throws CreateException;

}
