package com.soliste.bolbec.commun.service.exception;

public class SOAPFaultException extends RuntimeException {

	/**
	 * Exception retourn�e par CXF lorsqu'il y a une erreur technique lors d'un appel � un service externe.
	 * Seulement utilis�e pour le mode deconnect�.
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border' bgcolor=green>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>25/09/2013</TD><TD>VDE</TD><TD>MIGRATION Webservices Axis -> CXF Ajout SOAPFaultException</TD></TR>
	 * </TABLE><BR>
	 */

	private static final long serialVersionUID = -68806223776326291L;

	/**
	 * Constructeur utilis� par le mode d�connect�
	 * 
	 * @param msg
	 */
	public SOAPFaultException(String msg) {
		super(msg);
	}
}
