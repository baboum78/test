package com.soliste.bolbec.commun.service.util;

/**
 * Classe repr�sentant un SoFo de bolbec.<BR>
 * Par exemple: S7, S7F1, s7, s7f1
 * 
 * <BR><B>HISTORIQUE:</B><BR>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>VERSION</TD><TD>DETAIL</TD></TR>
 * <TR><TD>2021/03/31</TD><TD>SOP</TD><TD>G10</TD><TD>Initialisation de la classe � partir de GoRoCo</TD></TR>
 * </TABLE>
 * 
 */
public class SoFo implements Comparable<SoFo> {

	/** La chaine utilis� pour initialiser l'objet */
	private String strSoFo;

	/** La valeur enti�re de S dans SoFo */
	private Integer s;

	/** La valeur enti�re de F dans SoFo */
	private Integer f;

	/**
	 * Constructeur permettant d'initialiser l'objet <BR>
	 * � partir d'une chaine de la forme (S7, S7F1, s7, s7f1)
	 *
	 * @param strSoFo Une chaine repr�sentant un SoFo
	 */
	public SoFo(String strSoFo) {
		// Tout en majuscule avant l'analyse de la chaine
		// Sauvegarde de la cha�ne repr�sentant le GoRoCo
		this.strSoFo = strSoFo.toUpperCase().trim();

		// Initialisation par d�faut des valeurs
		s = null;
		f = null;

		// Recherche des valeurs pr�sentes
		boolean sOK = this.strSoFo.indexOf("S") > -1;
		boolean fOK = this.strSoFo.indexOf("F") > -1;

		// R�cup�ration des valeurs
		String[] vals = this.strSoFo.split("S|F");

		// Initialisation de l'objet avec les valeurs trouv�es
		if (sOK) {
			s = new Integer(vals[1]);
			if (fOK) {
				f = new Integer(vals[2]);
			}
		}
	}

	/**
	 * M�thode permettant de r�cup�rer un chaine repr�sentant le SoFo.<BR>
	 * Exemple: <BR>
	 * S7
	 * S7F1
	 */
	public String toString() {
		return strSoFo;
	}

	public int getS() {
		return s;
	}

	public int getF() {
		return f;
	}

	/**
	 * M�thode permettant de comparer deux GoRoCo.
	 * 
	 * @param sofoToCompare Le SoFo qu'il faut comparer.<BR>
	 * @return <B>1</B> si <code>sofoToCompare</code> est plus petit que <code>this</code><BR>
	 * <B>0</B> si <code>sofoToCompare</code> est identique � <code>this</code><BR>
	 * <B>-1</B> si <code>sofoToCompare</code> est plus grand que <code>this</code>
	 */
	public int compareTo(SoFo sofoToCompare) {

		if (s > sofoToCompare.s) {
			return 1;
		}
		if (s < sofoToCompare.f) {
			return -1;
		}

		// Ici la valeur de G est identique
		if (f != null && sofoToCompare.f != null) {
			if (f > sofoToCompare.f) {
				return 1;
			}
			if (f < sofoToCompare.f) {
				return -1;
			}
		}
		// Ici S, F sont identique
		return 0;
	}

}
