package com.soliste.bolbec.commun.service.interfaces.util.cxf.accent.callback;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.xml.ws.WebServiceException;

import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.io.CachedOutputStreamCallback;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.CacheWriteSwitcherOutputStream;
import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * CallBack permettant de transformer les accents en code HTML des messages d'�mission SOAP (requ�tes, r�ponses et s�ponse fault)
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/02/2015</TD><TD>BPE</TD><TD>G9R0 Anticipation palliatif des potentiels probl�mes d'encoding avec les partenaires en WS Soap</TD></TR>
 * </TABLE>
 */
public class AccentTransformCallBack implements CachedOutputStreamCallback {

	private static Map<String, String> accentsMap = initializeAccentsMap();
	private static Pattern accentsPattern = initialiserMappingAccent(accentsMap);

	/**
	 * Constructeur
	 */
	public AccentTransformCallBack() {
	}

	/**
	 * On ne fait rien
	 */
	@SuppressWarnings("unused")
	public void onFlush(CachedOutputStream cos) {
	}

	/**
	 * On proc�de � la transformation au tout dernier moment. Appel de la m�thode process
	 */
	public void onClose(CachedOutputStream cos) {
		try {
			process(cos);
		} catch (Exception e) {
			throw new WebServiceException("Le message � destination de Grafic n'a pas pu �tre adapt�", e);
		}
	}

	/**
	 * R�cup�ration du message dans le cache, transformation des accents en code html, et insertion
	 * du nouveau message de le flux sortant
	 * 
	 * @param cos
	 * @throws Exception
	 */
	public void process(CachedOutputStream cos) throws Exception {
		// R�cup�ration du message mis en cache
		final StringBuilder messageSoapEntreeBuilder = new StringBuilder();
		cos.writeCacheTo(messageSoapEntreeBuilder);

		final String messageSoapEntree = messageSoapEntreeBuilder.toString();
		String messageTransforme = messageSoapEntree;
		for (Matcher matcher = accentsPattern.matcher(messageTransforme); matcher.find(); matcher = accentsPattern.matcher(messageTransforme)) {
			String accent = matcher.group();
			messageTransforme = messageTransforme.replaceAll(accent, accentsMap.get(accent));
		}

		CacheWriteSwitcherOutputStream cwwcs = (CacheWriteSwitcherOutputStream) cos;
		cwwcs.setSwitchWriting(false);

		cos.write(StringUtils.toUtf8(messageTransforme).getBytes());
		cos.flush();
	}

	/**
	 * Cr�ation de la Map "caract�res accentu�s iso-8859" -> "Code html"
	 * 
	 * @return la map
	 */
	private static Map<String, String> initializeAccentsMap() {
		final Map<String, String> accentsMap = new HashMap<String, String>();

		accentsMap.put("�", "&#xC0;");
		accentsMap.put("�", "&#xC1;");
		accentsMap.put("�", "&#xC2;");
		accentsMap.put("�", "&#xC3;");
		accentsMap.put("�", "&#xC4;");
		accentsMap.put("�", "&#xC5;");
		accentsMap.put("�", "&#xC6;");
		accentsMap.put("�", "&#xC7;");
		accentsMap.put("�", "&#xC8;");
		accentsMap.put("�", "&#xC9;");
		accentsMap.put("�", "&#xCA;");
		accentsMap.put("�", "&#xCB;");
		accentsMap.put("�", "&#xCC;");
		accentsMap.put("�", "&#xCD;");
		accentsMap.put("�", "&#xCE;");
		accentsMap.put("�", "&#xCF;");
		accentsMap.put("�", "&#xD0;");
		accentsMap.put("�", "&#xD1;");
		accentsMap.put("�", "&#xD2;");
		accentsMap.put("�", "&#xD3;");
		accentsMap.put("�", "&#xD4;");
		accentsMap.put("�", "&#xD5;");
		accentsMap.put("�", "&#xD6;");
		accentsMap.put("�", "&#xD8;");
		accentsMap.put("�", "&#xD9;");
		accentsMap.put("�", "&#xDA;");
		accentsMap.put("�", "&#xDB;");
		accentsMap.put("�", "&#xDC;");
		accentsMap.put("�", "&#xDD;");
		accentsMap.put("�", "&#xDE;");
		accentsMap.put("�", "&#xDF;");
		accentsMap.put("�", "&#xE0;");
		accentsMap.put("�", "&#xE1;");
		accentsMap.put("�", "&#xE2;");
		accentsMap.put("�", "&#xE3;");
		accentsMap.put("�", "&#xE4;");
		accentsMap.put("�", "&#xE5;");
		accentsMap.put("�", "&#xE6;");
		accentsMap.put("�", "&#xE7;");
		accentsMap.put("�", "&#xE8;");
		accentsMap.put("�", "&#xE9;");
		accentsMap.put("�", "&#xEA;");
		accentsMap.put("�", "&#xEB;");
		accentsMap.put("�", "&#xEC;");
		accentsMap.put("�", "&#xED;");
		accentsMap.put("�", "&#xEE;");
		accentsMap.put("�", "&#xEF;");
		accentsMap.put("�", "&#xF0;");
		accentsMap.put("�", "&#xF1;");
		accentsMap.put("�", "&#xF2;");
		accentsMap.put("�", "&#xF3;");
		accentsMap.put("�", "&#xF4;");
		accentsMap.put("�", "&#xF5;");
		accentsMap.put("�", "&#xF6;");
		accentsMap.put("�", "&#xF8;");
		accentsMap.put("�", "&#xF9;");
		accentsMap.put("�", "&#xFA;");
		accentsMap.put("�", "&#xFB;");
		accentsMap.put("�", "&#xFC;");
		accentsMap.put("�", "&#xFD;");
		accentsMap.put("�", "&#xFE;");
		accentsMap.put("�", "&#xFF;");

		return accentsMap;
	}

	/**
	 * A partir de la map, cr�e l'expression r�guli�re de d�tection d'accent
	 * 
	 * @param accentsMap
	 * @return l'expression r�guli�re de d�tection d'accent
	 */
	private static Pattern initialiserMappingAccent(Map<String, String> accentsMap) {
		final String patternStr = String.format("(%s)", org.apache.commons.lang3.StringUtils.join(accentsMap.keySet(), '|'));
		return Pattern.compile(patternStr);
	}
}