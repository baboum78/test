/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.log;

import java.util.logging.Level;

/**
 * Cette classe de log est une classe permettant de logger, via le logger JDK,
 * les logs applicatives de l'application bolbec
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>16/09/2010</TD><TD>GPA</TD><TD>EV-000053: Ajout du champ commandeId dans la signature qualif(...)</TD></TR>
 * </TABLE>
 */
public class LoggerManager implements ILoggerManager {

	// singleton's private instance
	private static ILoggerManager instance;

	/**
	 * Constructeur priv� (Impl�mentation du pattern SINGLETON)
	 */
	private LoggerManager() {

	}

	/**
	 * Gets the logger.
	 * 
	 * @return the logger
	 */
	public synchronized static ILoggerManager getInstance() {
		if (instance == null) {
			instance = new LoggerManager();
		}
		return instance;
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isDebugActivated() {
		return LoggerJdkWeblo.isDebugActivated();
	}

	/**
	 * {@inheritDoc}
	 */
	public void config(String sourceClass, String sourceMethod, String msg) {
		LoggerJdkWeblo.getLogger().config(sourceClass, sourceMethod, msg);
	}

	/**
	 * {@inheritDoc}
	 */
	public void config(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		LoggerJdkWeblo.getLogger().config(sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * {@inheritDoc}
	 */
	public void fine(String sourceClass, String sourceMethod, String msg) {
		LoggerJdkWeblo.getLogger().fine(sourceClass, sourceMethod, msg);
	}

	/**
	 * {@inheritDoc}
	 */
	public void fine(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		LoggerJdkWeblo.getLogger().fine(sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * {@inheritDoc}
	 */
	public void finer(String sourceClass, String sourceMethod, String msg) {
		LoggerJdkWeblo.getLogger().finer(sourceClass, sourceMethod, msg);
	}

	/**
	 * {@inheritDoc}
	 */
	public void finer(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		LoggerJdkWeblo.getLogger().finer(sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * {@inheritDoc}
	 */
	public void finest(String sourceClass, String sourceMethod, String msg) {
		LoggerJdkWeblo.getLogger().finest(sourceClass, sourceMethod, msg);
	}

	/**
	 * {@inheritDoc}
	 */
	public void finest(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		LoggerJdkWeblo.getLogger().finest(sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * {@inheritDoc}
	 */
	public void info(String sourceClass, String sourceMethod, String msg) {
		LoggerJdkWeblo.getLogger().info(sourceClass, sourceMethod, msg);
	}

	/**
	 * {@inheritDoc}
	 */
	public void info(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		LoggerJdkWeblo.getLogger().info(sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * {@inheritDoc}
	 */
	public void severe(String sourceClass, String sourceMethod, String msg) {
		LoggerJdkWeblo.getLogger().severe(sourceClass, sourceMethod, msg);
	}

	/**
	 * {@inheritDoc}
	 */
	public void severe(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		LoggerJdkWeblo.getLogger().severe(sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * {@inheritDoc}
	 */
	public void warning(String sourceClass, String sourceMethod, String msg) {
		LoggerJdkWeblo.getLogger().warning(sourceClass, sourceMethod, msg);
	}

	/**
	 * {@inheritDoc}
	 */
	public void warning(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		LoggerJdkWeblo.getLogger().warning(sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * {@inheritDoc}
	 */
	public boolean isLoggable(Level level) {
		return LoggerJdkWeblo.getLogger().isLoggable(level);
	}

	/**
	 * {@inheritDoc}
	 */
	public void qualif(String className, int indentation, String methodName, String commandId, String templateMessage, String... params) {

		StringBuilder esp = new StringBuilder();
		for (int i = 0; i < indentation; i++) {
			esp.append(" ");
		}

		int lastId = className.lastIndexOf(".");
		if (lastId != -1) {
			LoggerJdkWeblo.getLogger().finer(className, methodName, String.format("QUALIF : " + esp.toString() + commandId + " - " + className.substring(lastId + 1) + " " + templateMessage, (Object[]) params));
		} else {
			LoggerJdkWeblo.getLogger().finer(className, methodName, String.format("QUALIF : " + esp.toString() + commandId + " - " + className + " " + templateMessage, (Object[]) params));
		}

	}

}
