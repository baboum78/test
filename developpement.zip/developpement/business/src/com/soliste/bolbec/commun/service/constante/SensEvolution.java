package com.soliste.bolbec.commun.service.constante;

/**
 * Enumeration des diff�rents sens d'�volution
 * 
 * @author Sopragroup
 */
public enum SensEvolution {
	/** Cr�ation */
	CR,
	/** Conservation */
	CS,
	/** Suppression */
	SU,
	/** D�num�rotation */
	DENUM;
}
