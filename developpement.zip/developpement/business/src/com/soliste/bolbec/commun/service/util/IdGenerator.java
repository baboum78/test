package com.soliste.bolbec.commun.service.util;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;
import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.ejb.ConstantesJNDI;
import com.soliste.bolbec.commun.service.ejb.sb.fondation.CounterManager;
import com.soliste.bolbec.commun.service.ejb.sb.fondation.CounterManagerBean;
import com.soliste.bolbec.commun.service.ejb.sb.fondation.CounterManagerHome;
import com.soliste.bolbec.commun.service.ejb.sb.fondation.CounterManagerRemoteHome;
import com.soliste.bolbec.commun.service.ejb.sb.fondation.ICounterManagerRemote;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;
import com.soliste.bolbec.fwk.jndi.ServiceLocator;
import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * Classe permettant de recuperer un id <br/>
 * Remplace la classe com.soliste.aps.foundation.ejb.counter.CounterManager
 * 
 * @author kyrw0678
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public class IdGenerator {

	/** Nombre d'identifiants que le gestionnaire est capable de fournir entre deux sollicitations d'un m�me EJB entit� <code>Counter</code>. */
	private final static long MODULO = 1000L;

	/**
	 * Le flag d�terminant si on acc�de � bolbec en remote ou non.<br> Le mode remote est activ� en passant
	 * la propri�t� syst�me <code>-Dbolbec.remote.acces=true</code> au lancement de la JVM.
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
	 * </TABLE>
	 */
	private static final boolean REMOTE_BOLBEC_ACCES = Boolean.getBoolean("bolbec.remote.acces");

	/** Pr�fixe qui pr�c�dera toutes les cl�s retourn�es . */
	public final static String COUNTER_PREFIX = System.getProperty("CounterPrefix");

	/** Table de hachage m�morisant les s�ries d'identifiants en cours d'utilisation par type de contenu. */
	private Map<String, Long> ids;

	/** EJB session g�rant les compteurs en base. */
	private CounterManager counterManager;
	private ICounterManagerRemote counterManagerRemote;

	/** Instance priv�e du singleton. */
	private static IdGenerator keygen;

	static {
		keygen = new IdGenerator();
	}

	/**
	 * G�n�re une cl� unique pour le type de contenu sp�cifi�.
	 * 
	 * @param contentType type de contenu
	 * 
	 * @return une cl� unique pour le type de contenu sp�cifi�
	 */
	public static String generateKey(String contentType) {
		return keygen.getDBKey(contentType);
	}

	/**
	 * G�n�re une cl� unique pour le type de contenu sp�cifi�.
	 *
	 * @param contentType type de contenu
	 * @param prefix prefixe a utiliser par �e compteur
	 *
	 * @return une cl� unique pour le type de contenu sp�cifi�
	 */
	public static String generateKey(String contentType, String prefix) {
		if (StringUtils.isBlank(contentType)) {
			throw new IllegalArgumentException("le parametre 'contentType' est null ou vide");
		}
		return keygen.getDBKey(contentType, prefix);
	}


	/**
	 * G�n�re une cl� unique
	 * 
	 * @return the string
	 */
	public static String generateKey() {
		return keygen.getDBKey(CounterManagerBean.DEFAULT_COUNTER_NAME);
	}

	/**
	 * Instantiates a new id manager.
	 */
	private IdGenerator() {
		// constructeur priv� pour �viter les instanciations inutiles
		try {
			ids = new HashMap<String, Long>();
			if (REMOTE_BOLBEC_ACCES) {
				CounterManagerRemoteHome home = (CounterManagerRemoteHome) ServiceLocator.getInstance().getRemoteHome(ConstantesJNDI.JNDI_COUNTER_MANAGER_REMOTE, CounterManagerRemoteHome.class);
				counterManagerRemote = home.create();
			} else {
				CounterManagerHome home = (CounterManagerHome) ServiceLocator.getInstance().getLocalHome(ConstantesJNDI.JNDI_COUNTER_MANAGER);
				counterManager = home.create();
			}
		} catch (NamingException ne) {
			throw new EJBException(ne);
		} catch (CreateException ce) {
			throw new EJBException(ce);
		} catch (RemoteException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Gets the dB key.
	 * 
	 * @param contentType the content type
	 * @param prefix le prefixe du compteur
	 * 
	 * @return the dB key
	 */
	private synchronized String getDBKey(String contentType, String prefix) {
		// on teste si la s�rie demand�e � d�j� �t� utilis�e ...
		Long id = ids.get(contentType);
		// ... si ce n'est pas le cas, ou si elle est �puis�e ...
		if (id == null || (id.longValue() % MODULO) == 0) {
			// ... on l'initialise (ou on la r�-initialise) � partir de la
			// valeur du compteur en base
			if (REMOTE_BOLBEC_ACCES) {
				try {
					id = Long.valueOf(counterManagerRemote.next(contentType) * MODULO);
				} catch (RemoteException e) {
					e.printStackTrace();
				}
			} else {
				id = Long.valueOf(counterManager.next(contentType) * MODULO);
			}
		}
		// on incr�mente la s�rie pour la prochaine utilisation
		ids.put(contentType, Long.valueOf(id.longValue() + 1));

		// XXX Ajout d'un log pour analyser le probl�me de ORA-01461: can bind a LONG value only for insert into a LONG column
		LoggerManager.getInstance().finest("IdGenerator", "getDBKey", "Nouvel identifiant: " + (prefix + id));
		// on retourne la cl�
		return prefix + id;
	}

	/**
	 * Gets the dB key.
	 *
	 * @param contentType the content type
	 *
	 * @return the dB key
	 */
	private synchronized String getDBKey(String contentType) {
		return this.getDBKey(contentType, COUNTER_PREFIX);
	}

}
