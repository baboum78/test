package com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collection;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import javax.xml.ws.WebServiceException;

import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.io.CachedOutputStreamCallback;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.CacheWriteSwitcherOutputStream;
import com.soliste.bolbec.commun.service.util.xml.XmlDomFactory;
import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * CallBack permettant de transformer le message xml � destination de Grafic
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 */
public abstract class GraficXMLTransformCallBack implements CachedOutputStreamCallback {

	private final XmlDomFactory xmlDomFactory;

	/**
	 * Constructeur
	 */
	public GraficXMLTransformCallBack(final XmlDomFactory xmlDomFactory) {
		this.xmlDomFactory = xmlDomFactory;
	}

	@SuppressWarnings("unused")
	public void onFlush(CachedOutputStream cos) {
	}

	public void onClose(CachedOutputStream cos) {
		try {
			process(cos);
		} catch (Exception e) {
			throw new WebServiceException("Le message � destination de Grafic n'a pas pu �tre adapt�", e);
		}
	}

	public void process(CachedOutputStream cos) throws Exception {

		// R�cup�ration du message mis en cache
		final StringBuilder messageSoapEntree = new StringBuilder();
		cos.writeCacheTo(messageSoapEntree);

		// Transformation du message en document DOM
		final DocumentBuilder documentBuilder = xmlDomFactory.createDocumentBuilder();
		final Document doc = documentBuilder.parse(new InputSource(new StringReader(messageSoapEntree.toString())));

		final Node body = doc.getElementsByTagNameNS(GraficXMLTransformCallbackConstantes.SOAP_NAMESPACE, GraficXMLTransformCallbackConstantes.SOAP_BODY_ELEMENT_NAME).item(0);

		// Extraction du message de l'enveloppe SOAP
		final Element rootMessage = getRootMessage(body);
		// Extraction du namespace de l'�l�ment racine
		final String namespace = rootMessage.getNamespaceURI();
		// Extraction du prefix de l'�l�ment racine
		final String oldNameSpacePrefix = rootMessage.getPrefix();
		// Extraction des sous-�l�ments (non r�cursif) de l'�l�ment racine
		final Collection<Element> subElementsList = getSubNodes(rootMessage);

		// Modif du prefix de l'�l�ment racine
		rootMessage.setPrefix(StringUtils.EMPTY);
		// Attribution du namespace sans prefix sur l'�l�ment racine
		rootMessage.setAttribute(GraficXMLTransformCallbackConstantes.XML_NAMESPACE_PREFIX, namespace);
		// Suppression de l'ancienne definition du namespcace
		rootMessage.removeAttribute(String.format("%s:%s", oldNameSpacePrefix, GraficXMLTransformCallbackConstantes.XML_NAMESPACE_PREFIX));

		// Surcharge du namespace xmlns="" pour chaque sous �l�ment
		for (Element subElement : subElementsList) {
			subElement.setPrefix(StringUtils.EMPTY);
			rootMessage.setAttribute(GraficXMLTransformCallbackConstantes.XML_NAMESPACE_PREFIX, StringUtils.EMPTY);
		}

		// G�n�ration du nouvel XML
		DOMSource domSource = new DOMSource(doc);
		Transformer transformer = xmlDomFactory.createTranformer();
		StringWriter sw = new StringWriter();
		StreamResult sr = new StreamResult(sw);
		transformer.transform(domSource, sr);

		CacheWriteSwitcherOutputStream cwwcs = (CacheWriteSwitcherOutputStream) cos;
		cwwcs.setSwitchWriting(false);

		cos.write(StringUtils.toUtf8(sw.toString()).getBytes());
		cos.flush();
	}

	private Collection<Element> getSubNodes(Node rootMessage) {
		final Collection<Element> nodesList = new ArrayList<Element>();
		final NodeList rootMessageChildren = rootMessage.getChildNodes();

		Node node;
		for (int i = 0; i < rootMessageChildren.getLength(); i++) {
			node = rootMessageChildren.item(i);
			if (node.getNodeType() == Node.ELEMENT_NODE) {
				nodesList.add((Element) node);
			}
		}
		return nodesList;
	}

	protected abstract Element getRootMessage(Node body);
}