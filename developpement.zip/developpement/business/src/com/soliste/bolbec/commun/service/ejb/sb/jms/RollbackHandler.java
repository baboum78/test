/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

import javax.jms.JMSException;
import javax.jms.Message;

import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Class abstraite permettant de savoir, � la r�ception d'un message, s'il faut
 * le traiter, le rejeter ou le republier. Cette impl�mentation peut �tre
 * surcharg�e par une sous-classe.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>23/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>02/04/2020</TD><TD>RRU</TD><TD>Possibilit� d'�tablir le max. repub (GestionnaireNotif)</TD></TR>
 * </TABLE><BR>
 */
public class RollbackHandler {

	/**
	 * Le type des alertes noires
	 */
	public static final int BLACK_ALERT_TYPE = 4;
	/**
	 * Le type des alertes vertes
	 */
	public static final int GREEN_ALERT_TYPE = 1;
	/**
	 * Nom de la propri�t� contenant le timestamp initial du message, c-�-d le
	 * timestamp du message re�u la premi�re fois.
	 */
	public static final String INITIAL_TIMESTAMP_PROPERTY = "ArtemisInitialTimestamp";
	/**
	 * Le type des alertes rouges
	 */
	public static final int RED_ALERT_TYPE = 3;
	/**
	 * Propri�t� permettant de conna�tre le nombre de republications d'un
	 * message
	 */
	public static final String REPUBLICATION_COUNT_PROPERTY = "ArtemisRepublicationCount";
	/**
	 * Le type des alertes jaunes
	 */
	public static final int YELLOW_ALERT_TYPE = 2;
	/**
	 * Temporisation par d�faut pour les alertes noires
	 */
	protected static final long DEFAULT_BLACK_ALERT_SLEEP_TIME = 60000L;
	/**
	 * Temporisation par d�faut pour les alertes vertes
	 */
	// protected static final long DEFAULT_GREEN_ALERT_SLEEP_TIME = 5000L;
	// TODO G10 : R�cup�rer la config original
	protected static final long DEFAULT_GREEN_ALERT_SLEEP_TIME = 500L;
	/**
	 * Nombre maximum de republications par d�faut
	 */
	protected static final int DEFAULT_MAX_REPUBLICATION_COUNT = 65;
	/**
	 * Temporisation par d�faut pour les alertes rouge
	 */
	protected static final long DEFAULT_RED_ALERT_SLEEP_TIME = 60000L;
	/**
	 * Temporisation par d�faut pour les alertes jaunes
	 */
	// protected static final long DEFAULT_YELLOW_ALERT_SLEEP_TIME = 60000L;
	// TODO G10 : R�cup�rer la config original
	protected static final long DEFAULT_YELLOW_ALERT_SLEEP_TIME = 5000L;
	
	private static final String CLASS_NAME = RollbackHandler.class.getName();

	/**
	 * Le nombre maximum de republications.
	 */
	protected int iMaxRepublicationCount = DEFAULT_MAX_REPUBLICATION_COUNT;

	/**
	 * Bool�en indiquant si le message doit �tre republi�e de fa�on asynchrone
	 */
	private boolean republishAsync;

	/**
	 * Constructeur
	 *
	 */
	public RollbackHandler() {
		this(false);
	}

	/**
	 * Constructeur avec option de republication asynchrone sp�cifi�e
	 *
	 */
	public RollbackHandler(boolean republishAsync) {
		this.republishAsync = republishAsync;
	}

	/**
	 * Retourne le nombre maximum de republications.
	 * 
	 * @return le nombre maximum de republications
	 * (DEFAULT_MAX_REPUBLICATION_COUNT pour cette impl�mentation)
	 */
	public int getMaxRepublicationCount() {
		return iMaxRepublicationCount;
	}

	/**
	 * D�termine le nombre maximum de republications.
	 * (DEFAULT_MAX_REPUBLICATION_COUNT pour cette impl�mentation)
	 * 
	 */
	public void setMaxRepublicationCount(int iMaxRepublicationCount) {
		this.iMaxRepublicationCount = iMaxRepublicationCount;
	}

	/**
	 * Indique si les republications se font de fa�on asynchrone.
	 *
	 * @return true si les republications se font de fa�on asynchrone
	 */
	public boolean isRepublishAsync() {
		return republishAsync;
	}

	/**
	 * D�termine si les republications doivent se faire de fa�on asynchrone.
	 *
	 */
	public void setRepublishAsync(boolean republishAsync) {
		this.republishAsync = republishAsync;
	}

	/**
	 * D�termine si le message doit �tre trait�, republi� ou rejet�. Si le code
	 * retourn� est MESSAGE_MUST_BE_REPUBLISHED, alors l'appelant devra
	 * republier un message qu'il pourra construire gr�ce � la m�thode
	 * generateRepublicationMessage de l'objet retourn�. L'impl�mentation est la
	 * suivante:
	 * <ul>
	 * <li>Si le message re�u est un message d�livr� pour la premi�re fois,
	 * alors il doit �tre trait�.</li>
	 * <li>Si par contre le message re�u est un message red�livr�:
	 * <ul>
	 * <li>On obtient la valeur du compteur de republication (propri�t� du
	 * message)</li>
	 * <li>Si le compteur est sup�rieur ou �gal � sa valeur maximale, alors il
	 * doit �tre rejet�</li>
	 * <li>Si le compteur est inf�rieur � sa valeur maximale, une temporisation
	 * est effectu�e (d�pendante de la valeur du compteur), le compteur est
	 * incr�ment�, et le message doit �tre republi�</li>
	 * </ul>
	 * </li>
	 * </ul>
	 * 
	 * @param message
	 * le message re�u. Attention, dans le cas o� le message doit
	 * �tre republi�, il importe que ce soit ce message pr�cis qui
	 * soit republi�, puisque c'est lui qui contient la propri�t�
	 * "compteur de republication"
	 * @return l'action � effectuer avec ce message, contenant le nombre de
	 * republications � placer dans le message � r��mettre.
	 * @throws JMSException
	 * si un probl�me survient lors de la d�termination de
	 * l'op�ration
	 */
	public RollbackHandlerNextAction handleMessage(Message message) throws JMSException {
		if (message.getJMSRedelivered()) {
			int republicationCount = getRepublicationCountFromMessage(message);
			if (republicationCount >= getMaxRepublicationCount()) {
				return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_REJECTED, 0);
			}

			int alertType = getAlertType(republicationCount);
			long sleepTime = getSleepTime(alertType);

			if (!republishAsync) {
				sleep(alertType, sleepTime);
				return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_REPUBLISHED, republicationCount + 1);
			}

			// Ici la republication doit se faire de fa�on asynchrone
			return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_REPUBLISHED_ASYNC, republicationCount + 1, sleepTime);
		}
		return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_HANDLED, 0);
	}

	/**
	 * getAlertString
	 * 
	 * @param alertType
	 * @return
	 */
	protected String getAlertString(int alertType) {
		switch (alertType) {
		case GREEN_ALERT_TYPE:
			return "Alerte verte";
		case YELLOW_ALERT_TYPE:
			return "Alerte jaune";
		case RED_ALERT_TYPE:
			return "Alerte rouge";
		default:
			return "Alerte noire";
		}
	}

	/**
	 * Retourne le type d'alerte pour le nombre de republications donn�.
	 * 
	 * @param republicationCount
	 * le nombre de republications du message
	 * @return le type d'alerte pour le nombre de republications donn�
	 */
	protected int getAlertType(int republicationCount) {
		if (republicationCount < 10) {
			return GREEN_ALERT_TYPE;
		} else if (republicationCount < 20) {
			return YELLOW_ALERT_TYPE;
		} else if (republicationCount < 50) {
			return RED_ALERT_TYPE;
		} else {
			return BLACK_ALERT_TYPE;
		}
	}

	/**
	 * 
	 * @param message
	 * @return
	 * @throws JMSException
	 */
	protected int getRepublicationCountFromMessage(Message message) throws JMSException {
		int republicationCount = 0;
		if (message.propertyExists(REPUBLICATION_COUNT_PROPERTY)) {
			republicationCount = message.getIntProperty(REPUBLICATION_COUNT_PROPERTY);
		}
		return republicationCount;
	}

	/**
	 * Retourne le temps d'attente (en millisecondes) pour le nombre de
	 * republications et le type d'alerte donn�s
	 * 
	 * @param alertType le type d'alerte correspondant au nombre de republications
	 * @return le temps d'attente (en millisecondes)
	 */
	protected long getSleepTime(int alertType) {
		switch (alertType) {
		case GREEN_ALERT_TYPE:
			return DEFAULT_GREEN_ALERT_SLEEP_TIME;
		case YELLOW_ALERT_TYPE:
			return DEFAULT_YELLOW_ALERT_SLEEP_TIME;
		case RED_ALERT_TYPE:
			return DEFAULT_RED_ALERT_SLEEP_TIME;
		default:
			return DEFAULT_BLACK_ALERT_SLEEP_TIME;
		}
	}

	/**
	 * 
	 * @param alertType
	 * @param sleepTime
	 */
	protected void sleep(int alertType, long sleepTime) {
		LoggerManager.getInstance().warning(CLASS_NAME, "sleep", getAlertString(alertType) + "! Thread endormi pendant " + (sleepTime / 1000) + " secondes avant republication du message");
		try {
			Thread.sleep(sleepTime);
		} catch (InterruptedException e) {
			// ignore
		}
	}
}