package com.soliste.bolbec.commun.service.exception;

/**
 * Repr�sente une erreur de connexion
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>20/01/2011</TD><TD>GPA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */
public class ValidationRetourServiceException extends Exception {

	/**
	 * Constructeur par d�faut
	 */
	public ValidationRetourServiceException() {
		super();
	}

	/**
	 * Constructeur d'initialisation avec simple message
	 * 
	 * @param msg Le message de l'exception
	 */
	public ValidationRetourServiceException(String msg) {
		super(msg);
	}

	/**
	 * Constructeur d'initalisation
	 * 
	 * @param msg Le m�ssage de l'exception
	 * @param t L'erreur m�re
	 */
	public ValidationRetourServiceException(String msg, Throwable t) {
		super(msg, t);
	}

}
