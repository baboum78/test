package com.soliste.bolbec.commun.service.interfaces.util.cxf.ipon;

import java.util.Collections;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.MediaType;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

public class IponInterceptorFaultInLiv extends AbstractPhaseInterceptor<Message> {

	public IponInterceptorFaultInLiv() {
		super(Phase.RECEIVE);
	}

	public IponInterceptorFaultInLiv(String phase) {
		super(phase);
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		String contentType = (String) message.get(Message.CONTENT_TYPE);

		// Si jamais Ipon decide de corriger l'erreur de son cot�, l'action ne sera plus realis�
		if (contentType != null && contentType.contains(MediaType.TEXT_HTML)) {
			Map<String, List> map = (Map<String, List>) message.get(Message.PROTOCOL_HEADERS);
			message.put(Message.CONTENT_TYPE, MediaType.TEXT_XML);
			map.put(Message.CONTENT_TYPE, Collections.singletonList(MediaType.TEXT_XML));
			message.put(Message.PROTOCOL_HEADERS, map);
		}
	}
}
