/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.pagination;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;

import javax.sql.DataSource;

import com.soliste.bolbec.commun.service.util.jdbc.JdbcUtils;
import com.soliste.bolbec.commun.service.util.jdbc.RowMapper;
import com.soliste.bolbec.commun.service.util.sort.SortCommand;
import com.soliste.bolbec.commun.service.util.sort.SortTranslator;

/**
 * Classe utilitaire pour la pagination
 * 
 * @author rgvs7490
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/02/2010</TD><TD>DBA</TD><TD>EV-000029: Gestion de plusieurs tris au lieu de 1</TD></TR>
 * </TABLE>
 */
public class PaginationUtil {

	/**
	 * Constructeur
	 */
	private PaginationUtil() {
		// priv� pour �viter les instanciations inutiles
	}

	/**
	 * Retourne le num�ro de page r�el retourn� pour un num�ro de page demand�.
	 * En effet, si le num�ro de page demand� correspond � une page inexistante,
	 * on retourne la page la plus proche.
	 * 
	 * @param askedPageNumber
	 * le num�ro de page voulu
	 * @param objectsPerPage
	 * le nombre d'objets par page voulu
	 * @param totalObjectCount
	 * le nombre total d'objets dans la liste
	 * @return le num�ro de page valide le plus proche du num�ro demand�
	 */
	public static int getActualPageNumber(int askedPageNumber, int objectsPerPage, int totalObjectCount) {
		int result = askedPageNumber;
		if (askedPageNumber < 1) {
			result = 1;
		} else {
			int beginIndex = (askedPageNumber - 1) * objectsPerPage;
			if (beginIndex >= totalObjectCount) {
				int pageCount = totalObjectCount / objectsPerPage;
				if ((totalObjectCount % objectsPerPage) > 0) {
					pageCount++;
				}
				result = pageCount;
			}
		}
		return result;
	}

	/**
	 * Calcul du num�ro de la derni�re page de la pagination selon le nombre
	 * d'objets par page et le nombre total d'�l�ments � paginer
	 * 
	 * @param objectsPerPage
	 * le nombre d'objets par page
	 * @param totalObjectCount
	 * le nombre total d'�l�ments � paginer
	 * @return le num�ro de la derni�re page
	 */
	public static int getLastPageNumber(int objectsPerPage, int totalObjectCount) {
		int pageCount = totalObjectCount / objectsPerPage;
		if ((totalObjectCount % objectsPerPage) > 0) {
			pageCount++;
		}
		return pageCount;
	}

	/**
	 * Calcul du num�ro de la page courante de la pagination selon le nombre
	 * d'objets par page et le rang du premier object affich� sur la page
	 * 
	 * @param objectsPerPage
	 * le nombre d'objets par page
	 * @param beginIndex
	 * le rang du premier object affich� sur la page
	 * @return le num�ro de la page courante
	 */
	public static int getCurrentPageNumber(int objectsPerPage, int beginIndex) {
		int pageCount = beginIndex / objectsPerPage;
		if ((beginIndex % objectsPerPage) >= 0) {
			pageCount++;
		}
		return pageCount;
	}

	/**
	 * Retourne l'index (� partir de 0) du premier �l�ment de la page valide la
	 * plus proche de la page demand�e En effet, si le num�ro de page demand�
	 * correspond � une page inexistante, on retourne la page la plus proche.
	 * 
	 * @param askedPageNumber
	 * le num�ro de page voulu
	 * @param objectsPerPage
	 * le nombre d'objets par page voulu
	 * @param totalObjectCount
	 * le nombre total d'objets dans la liste
	 * @return l'index (� partir de 0) du premier �l�ment de la page valide la
	 * plus proche de la page demand�e
	 */
	public static int getActualBeginIndex(int askedPageNumber, int objectsPerPage, int totalObjectCount) {
		int actualPageNumber = getActualPageNumber(askedPageNumber, objectsPerPage, totalObjectCount);
		return (actualPageNumber - 1) * objectsPerPage;
	}

	/**
	 * Retourne la sous-liste de la collection donn�e d�butant � l'index donn�,
	 * et contenant au maximum le nombre d'objets par page donn�
	 * 
	 * @param c
	 * la collection dont on veut extraire la sous-liste
	 * @param beginIndex
	 * l'index du premier �l�ment de la sous-liste
	 * @param objectsPerPage
	 * le nombre d'objets (maximal) de la sous-liste
	 * @return la sous-liste de la collection donn�e d�butant � l'index donn�,
	 * et contenant au maximum le nombre d'objets par page donn�
	 */
	public static <T> List<T> subList(Collection<T> c, int beginIndex, int objectsPerPage) {
		List<T> list = new ArrayList<T>();
		int i = 0;
		for (Iterator<T> it = c.iterator(); it.hasNext() && (list.size() < objectsPerPage);) {
			T o = it.next();
			if (i >= beginIndex) {
				list.add(o);
			}
			i++;
		}
		return list;
	}

	/**
	 * Cr�e une requ�te SQL de pagination, � partir d'une requ�te SQL valide. La
	 * requ�te cr��e n'extrait de la base de donn�es que les lignes
	 * correspondant � la commande de pagination donn�e. Pour appeler cette
	 * m�thode, il faut conna�tre le nombre total d'�l�ments de la liste, en
	 * ayant ex�cut� auparavant une requ�te SQL qui compte le nombre de
	 * r�sultats.
	 * 
	 * @param query
	 * la requ�te originale
	 * @param paginationCommand
	 * la commande de pagination
	 * @param totalObjectCount
	 * le nombre total d'objets dans la liste
	 * @return la requ�te de pagination
	 */
	public static String createPaginationQuery(String query, PaginationCommand paginationCommand, int totalObjectCount) {
		int objectsPerPage = paginationCommand.getObjectsPerPage();
		int beginIndex = PaginationUtil.getActualBeginIndex(paginationCommand.getPageNumber(), objectsPerPage, totalObjectCount);
		StringBuffer buffer = new StringBuffer();
		buffer.append("SELECT * " + "FROM ( SELECT a.*, rownum rnum " + "FROM ( ");
		buffer.append(query);
		buffer.append(" ) a" + " WHERE rownum <= ");
		buffer.append(beginIndex + objectsPerPage);
		buffer.append(" )" + " WHERE rnum >= ");
		buffer.append(beginIndex + 1);
		return buffer.toString();
	}

	/**
	 * Cr�e une liste pagin�e � partir d'un ResultSet contenant uniquement les
	 * lignes correspondant � la sous-liste demand�e
	 * 
	 * @param rs
	 * le ResultSet contenant les lignes de la sous-liste
	 * @param totalObjectCount
	 * le nombre total d'objets dans la liste compl�te
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @param rowMapper
	 * le RowMapper permettant de g�n�rer un objet pour chaque ligne
	 * du ResultSet
	 * @return la liste pagin�e
	 * @throws SQLException
	 * si une exception SQL survient pendant la cr�ation de la liste
	 */
	public static <T> PaginatedList<T> createPaginatedList(ResultSet rs, int totalObjectCount, PaginationCommand paginationCommand, SortCommand sortCommand, RowMapper<T> rowMapper) throws SQLException {
		int actualPageNumber = PaginationUtil.getActualPageNumber(paginationCommand.getPageNumber(), paginationCommand.getObjectsPerPage(), totalObjectCount);
		List<T> resultList = new ArrayList<T>(paginationCommand.getObjectsPerPage());
		while (rs.next()) {
			T dto = rowMapper.mapRow(rs);
			resultList.add(dto);
		}
		// EV-000029: Gestion du multi-tri
		return new PaginatedList<T>(resultList, actualPageNumber, paginationCommand.getObjectsPerPage(), totalObjectCount, (sortCommand.getCriterion())[0], sortCommand.getDirection());
	}

	/**
	 * Effectue une recherche en SQL et renvoit une liste pagin�e
	 * 
	 * @param dataSource
	 * la DataSource permettant d'obtenir une Connection
	 * @param countQuery
	 * la requ�te permettant de compter le nombre total d'objets dans
	 * la liste
	 * @param searchQuery
	 * la requ�te permettant d'obtenir la liste d'objets. Cette
	 * requ�te est d'abord traduite par le SortTranslator, puis
	 * transform�e en requ�te pagin�e
	 * @param args
	 * les arguments � appliquer aux deux requ�tes. null est une
	 * valeur accept�e.
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @param sortTranslator
	 * le traducteur de tri
	 * @param rowMapper
	 * le RowMapper permettant de g�n�rer un objet pour chaque ligne
	 * retourn�e
	 * @return la liste pagin�e
	 * @throws SQLException
	 * si une exception SQL survient
	 */
	public static <T> PaginatedList<T> search(DataSource dataSource, String countQuery, String searchQuery, Object[] args, PaginationCommand paginationCommand, SortCommand sortCommand, SortTranslator sortTranslator, RowMapper<T> rowMapper)
			throws SQLException {
		PaginatedList<T> result = null;
		Connection c = null;
		PreparedStatement s1 = null;
		PreparedStatement s2 = null;
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		try {
			c = dataSource.getConnection();
			s1 = c.prepareStatement(countQuery);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					s1.setObject(i + 1, args[i]);
				}
			}
			rs1 = s1.executeQuery();

			rs1.next();
			int totalCount = rs1.getInt(1);
			if (totalCount == 0) {
				List<T> emptyList = Collections.emptyList();
				// EV-000029: Gestion du multi-tri
				return new PaginatedList<T>(emptyList, 1, paginationCommand.getObjectsPerPage(), totalCount, sortCommand.getCriterion()[0], sortCommand.getDirection());
			}
			String sortQuery = sortTranslator.translate(searchQuery, sortCommand);
			String paginationQuery = PaginationUtil.createPaginationQuery(sortQuery, paginationCommand, totalCount);
			s2 = c.prepareStatement(paginationQuery);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					s2.setObject(i + 1, args[i]);
				}
			}
			rs2 = s2.executeQuery();
			result = PaginationUtil.createPaginatedList(rs2, totalCount, paginationCommand, sortCommand, rowMapper);
		} finally {
			JdbcUtils.closeResultSet(rs1);
			JdbcUtils.closeResultSet(rs2);
			JdbcUtils.closeStatement(s1);
			JdbcUtils.closeStatement(s2);
			JdbcUtils.closeConnection(c);
		}
		return result;
	}

	/**
	 * Renvoie un sous-ensemble d'une liste correspondant � la page courante
	 * 
	 * @param allElements
	 * @param paginationCommand
	 * @return un sous-ensemble d'une liste correspondant � la page courante
	 */
	public static <T> List<T> subList(List<T> allElements, PaginationCommand paginationCommand) {
		int objectsPerPage = paginationCommand.getObjectsPerPage();
		int actualBeginIndex = getActualBeginIndex(paginationCommand.getPageNumber(), objectsPerPage, allElements.size());
		return subList(allElements, actualBeginIndex, objectsPerPage);
	}
}
