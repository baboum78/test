/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.util.sort;

/**
 * Interface permettant de traduire une requ�te SQL donn�e (contenant par exemple
 * une sous-cha�ne � remplacer), en requ�te SQL valide contenant une portion d�di�e
 * au tri.
 * 
 * @author rgvs7490
 */
public interface SortTranslator {

	/**
	 * Traduit la requ�te donn�e
	 * 
	 * @param query la requ�te � traduire, contenant par exemple une sous-cha�ne �
	 * remplacer par une portion de requ�te d�di�e au tri
	 * @param sortCommand la commande de tri permettant de g�n�rer la portion de
	 * requ�te d�di�e au tri
	 * @return la requ�te SQL traduite, valide.
	 */
	public String translate(String query, SortCommand sortCommand);
}
