package com.soliste.bolbec.commun.service.ejb;

/**
 * Constantes des noms JNDI des EJB de la couche commune
 * 
 * @author kyrw0678
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>18/10/2010</TD><TD>GPA</TD><TD>EV-000087: Cr�ation des constantes JNDI_EXTRACT_INFO_LIV_MANAGER et JNDI_EXTRACT_INFO_ROU_MANAGER</TD></TR>
 * <TR><TD>29/11/2010</TD><TD>GPA</TD><TD>Reports G7R4C2 en G7R5C1 (projet d�veloppement)</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>13/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Ajout de la constante JNDI_MESSAGE_WEB_SRV_ROU_MANAGER</TD></TR>
 * <TR><TD>11/02/2014</TD><TD>BPE</TD><TD>EV-000276 : G8R2C4 - Mise en place de l'infoTrafic</TD></TR>
 * <TR><TD>07/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * </TABLE>
 */
public interface ConstantesJNDI {

	static final String JNDI_CONFIG_MANAGER = "ejb.service.ConfigManager";

	static final String JNDI_COUNTER_MANAGER = "ejb.service.CounterManager";

	static final String JNDI_COUNTER_MANAGER_REMOTE = "ejb.service.CounterManagerRemote";

	static final String JNDI_CACHE_MANAGER = "ejb.service.CacheManager";

	static final String JNDI_LOCALISATION_WS_MANAGER = "ejb.service.LocalisationWsManager";

	static final String JNDI_PREFERENCE_MANAGER = "ejb.service.PreferenceManager";

	static final String JNDI_AGENT_MANAGER = "ejb.service.AgentManager";

	static final String JNDI_ARCHIVING_MANAGER = "ejb.service.ArchivingManager";

	static final String JNDI_ARCHIVING_MANAGER_REMOTE = "ejb.service.ArchivingManagerRemote" ;

	static final String JNDI_INFOTRAFIC_MANAGER = "ejb.service.InfoTraficManager";

	static final String JNDI_COCHISE_PHARAON_MANAGER = "ejb.service.CochisePharaonManager";

	static final String JNDI_API_REST_RESSOURCE_MANAGER = "ejb.service.ApiRessourceManager";
}
