package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.Role;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * RoleDTO fait partie de l'espace de reference
 */
public class RoleDTO implements java.io.Serializable {

	private String id;
	private String gerable;
	private String libelle;

	/**
	 * 
	 * @param id
	 */
	public RoleDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public RoleDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(Role.FIELD_ID);
		this.gerable = (String) ep.getValue(Role.FIELD_GERABLE);
		this.libelle = (String) ep.getValue(Role.FIELD_LIBELLE);
	}

	/**
	 * 
	 * @param role
	 */
	public RoleDTO(Role role) {
		this.id = role.getId();
		this.gerable = role.getGerable();
		this.libelle = role.getLibelle();
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public String getGerable() {
		return gerable;
	}

	public String getLibelle() {
		return libelle;
	}

}
