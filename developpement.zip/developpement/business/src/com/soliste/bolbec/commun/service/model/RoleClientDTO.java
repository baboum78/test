package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.RoleClient;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * RoleClientDTO fait partie de l'espace de r�f�rence
 */
public class RoleClientDTO implements java.io.Serializable {

	private String id;
	private String libelle;

	/**
	 * 
	 * @param id
	 */
	public RoleClientDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public RoleClientDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(RoleClient.FIELD_ID);
		this.libelle = (String) ep.getValue(RoleClient.FIELD_LIBELLE);
	}

	/**
	 * 
	 * @param roleClient
	 */
	public RoleClientDTO(RoleClient roleClient) {
		this.id = roleClient.getId();
		this.libelle = roleClient.getLibelle();
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public String getLibelle() {
		return libelle;
	}

}
