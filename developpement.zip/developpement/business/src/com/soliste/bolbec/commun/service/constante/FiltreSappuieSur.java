package com.soliste.bolbec.commun.service.constante;

public enum FiltreSappuieSur {
	TOUS, TOUS_SAUF_SENSEVOL_CS, AUCUN
}