/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.fondation;

import java.util.ArrayList;

import com.soliste.aps.foundation.ejb.Condition;
import com.soliste.aps.foundation.ejb.EntityProxy;
import com.soliste.aps.foundation.ejb.EntitySpace;
import com.soliste.aps.foundation.ejb.EntitySpaceCursor;
import com.soliste.aps.foundation.web.ReferenceData;

/**
 * FONCTIONS RENVOYANT DES OBJETS DE L'ESPACE DE REFERENCE A PARTIR DES OBJETS
 * DE L'ESPACE DES COMMANDES (par ordre alphab�tique)
 * <p>
 * Cette classe regroupe les m�thodes qui font des "travers�es d'espaces". Pour
 * les navigations au sein du m�me espace utiliser <link>SimpleLinkNavigator</link>
 * ou <link>MultipleLinkNavigator</link>
 * <p>
 * Toutes les methodes respectent la technique de nommage suivante :<br>
 * "from" + nom_classe_d�part + "To" + nom_classe_arriv�e [ + "Id"]
 * <p>
 * Remarque : si on dispose d'une methode fromAToB et une deuxieme fromBToC on
 * demande de ne pas ecrire la methode fromAToC mais plutot utiliser la forme
 * suivante:<br>
 * 
 * <pre>
 * EntityProxy b = fromAToB(a);
 * EntityProxy c = fromBToC(b);
 * ou bien
 * EntityProxy c = fromBToC(fromAToB(a));
 * </pre>
 * 
 * @author Adrian Stanciu
 * @version 1.0, 27 ao�t 03
 */
public class ReferenceSpaceNavigator {

	/**
	 * nom JNDI du Session Bean qui est l'espace de r�f�rence; � priori on est
	 * pas cens�s conna�tre ce nom, mais le r�cup�rer � partir du contexte
	 * d'appel (contexte de la servlet - param�tre "JndiReferenceGateName") -
	 * mais bon...
	 */
	private final static String JNDI_REFERENCE_SPACE_NAME = "aps.ReferenceGateHome";

	/**
	 * Retrouve dans l'espace de r�f�rence un EntityProxy de type
	 * <code>a_class</code> et r�pondant au crit�re <code>a_condition</code>
	 * 
	 * @see #listInReferenceSpace(Class, Condition)
	 * @param a_class
	 * @param a_filter
	 * crit�re de filtrage que le curseur doit appliquer. Ce crit�re
	 * doit impl�menter une m�thode <code>isVerified</code>
	 * concernant un objet de donn�es de la liste.
	 * @return premier EntityProxy r�pondant aux crit�res, null si pas trouv�
	 */
	public static EntityProxy findInReferenceSpace(Class<?> a_class, Condition a_filter) {
		EntitySpace l_referenceSpace = getReferenceSpace();
		EntitySpaceCursor l_cursor = new EntitySpaceCursor(l_referenceSpace);
		l_cursor.putOnList(a_class, null, a_filter);
		if (l_cursor.hasNext()) {
			l_cursor.next();
			return (EntityProxy) l_cursor.getCurrentEntity();
		}
		return null;
	}

	/**
	 * Retrouve un EntityProxy dans l'espace de r�f�rence � partir de son ID.
	 * 
	 * @param a_class
	 * @param a_id
	 * @return premier EntityProxy r�pondant aux crit�res, null si pas trouv�
	 */
	public static EntityProxy findInReferenceSpace(Class<?> a_class, String a_id) {
		if (a_id == null) {
			return null;
		}
		EntitySpace l_referenceSpace = getReferenceSpace();
		EntityProxy l_result = l_referenceSpace.getEntityProxy(a_class, a_id);
		return l_result;
	}

	/**
	 * m�thode utilitaire qui r�cup�re l'espace des nomenclatures
	 * (ReferenceSpace= et qui l'initialise en plus s'il n'est pas encore cr��.
	 * 
	 * @return espace des nomenclatures
	 */
	public static EntitySpace getReferenceSpace() {
		EntitySpace l_referenceSpace = ReferenceData.getStandardReferenceSpace();
		if (l_referenceSpace != null) {
			return l_referenceSpace;
		}
		return ReferenceData.refreshReferenceSpace(ReferenceData.REFERENCE_NAME, JNDI_REFERENCE_SPACE_NAME);
	}

	/**
	 * Pareil que findInReferenceSpace, mais retourne tous les r�sultats
	 * retrouv�s dans une liste (m�me s'il s'agit d'un seul) - donc plus
	 * g�n�rique
	 * 
	 * @see #findInReferenceSpace(Class, Condition)
	 * @param a_class
	 * @param a_filter
	 * crit�re de filtrage que le curseur doit appliquer. Ce crit�re
	 * doit impl�menter une m�thode <code>isVerified</code>
	 * concernant un objet de donn�es de la liste.
	 * @return tous les r�sultats retrouv�s dans une liste (m�me s'il s'agit
	 * d'un seul)
	 */
	@SuppressWarnings("unchecked")
	public static ArrayList<EntityProxy> listInReferenceSpace(Class<?> a_class, Condition a_filter) {
		EntitySpace l_referenceSpace = getReferenceSpace();
		EntitySpaceCursor l_cursor = new EntitySpaceCursor(l_referenceSpace);
		l_cursor.putOnList(a_class, null, a_filter);
		return l_cursor.getCurrentList();
	}
}