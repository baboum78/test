package com.soliste.bolbec.commun.service.constante;

/**
 * Liste des instances BOLBEC
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>22/10/2010</TD><TD>GPA</TD><TD>EV-000087: Cr�ation de la classe</TD></TR>
 * </TABLE>
 */
public enum InstanceArtemis {
	ln, ls, rr
}
