package com.soliste.bolbec.commun.service.exception;

/**
 * The Class BusinessException.
 */
public class BusinessException extends Exception {

	/**
	 * Instantiates a new business exception.
	 */
	public BusinessException() {
		super();
	}

	/**
	 * Instantiates a new business exception.
	 * 
	 * @param msg the msg
	 */
	public BusinessException(String msg) {
		super(msg);
	}

	/**
	 * Instantiates a new business exception.
	 * 
	 * @param msg the msg
	 * @param t the t
	 */
	public BusinessException(String msg, Throwable t) {
		super(msg, t);
	}

}
