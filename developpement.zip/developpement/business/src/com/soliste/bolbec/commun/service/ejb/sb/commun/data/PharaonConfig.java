package com.soliste.bolbec.commun.service.ejb.sb.commun.data;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>08/03/2010</TD><TD>DBA</TD><TD>EV-000047: Nouvelle classe</TD></TR>
 * <TR><TD>06/04/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place JAVADOC + Fixe de TO DO</TD></TR>
 * <TR><TD>16/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion du param�trage via properties</TD></TR>
 * </TABLE>
 * 
 */
public class PharaonConfig {

	// Cl�s permettant d'acc�der au param�trage du fichier properties
	// -------------------------------------------------------------------
	public static final String PHARAON_KEY_EXTRACT_DIR = "EXTRACT_DIR";
	public static final String PHARAON_KEY_LOG_DIR = "LOG_DIR";
	public static final String PHARAON_KEY_INIT_DIR = "INIT_DIR";
	public static final String PHARAON_KEY_SEP_DATA = "SEP_DATA";
	public static final String PHARAON_KEY_ACTIF = "ACTIF";
	public static final String PHARAON_KEY_PREFIX_EXTRACT_FILENAME = "PREFIX_EXTRACT_FILENAME";
	public static final String PHARAON_KEY_PREFIXE_INIT_FILE = "PREFIXE_INIT_FILE";

	/** Le s�parateur de valeur (Fichier d'initialisation) */
	private String sepValue = "";
	private String extractDir = "";
	private String logDir = "";
	private String initDir = "";
	private String sepData = "";
	private boolean actif = true;
	private String prefixExtractFilename = "";
	private String prefixInitFilename = "";

	/** Liste des URL pour chaque instance */
	private Map<String, String> urlInstance = new HashMap<String, String>();

	/** La liste des r�les g�r�s par Pharaon */
	private List<String> roles = new ArrayList<String>();

	/**
	 * 
	 * @return La liste des URLs permettant de cibler les instances<Br>
	 * LN -> ....<BR>
	 * LS -> .... <BR>
	 */
	public Map<String, String> getUrlInstance() {
		return urlInstance;
	}

	/**
	 * @return la liste des r�les d�finie dans le param�trage
	 */
	public List<String> getRoles() {
		return roles;
	}

	/**
	 * @return Permet de r�cuperer le separateur utilis� pour la cr�ation du fichier d'init
	 */
	public String getSepValue() {
		return sepValue;
	}

	/**
	 * M�thode permettant de modifier le s�parateur de valeur (Construction du fichier d'initialisation)
	 * 
	 * @param sepValue Le nouveau s�parateur a utiliser
	 */
	public void setSepValue(String sepValue) {
		this.sepValue = sepValue;
	}

	/**
	 * @return Le s�parateur � utiliser pour s�parer les enregistrements (Groupe de valeurs)
	 */
	public String getSepData() {
		return sepData;
	}

	/**
	 * Permet de r�cuperer l'url de la livraison pour l'instance pass�e en parametre. <BR>
	 * Cette URL provient de la table DESTINATION en recherchant Login_% (Avec l'�tat ACTIF)
	 * 
	 * @param instance : instance (ln ou ls)
	 * @return l'url de l'instance livraison demand�e
	 */
	public String getCible(String instance) {
		return urlInstance.get(instance);
	}

	/**
	 * 
	 * @return Le pr�fixe du fichier d'extraction
	 */
	public String getPrefixExtractFilename() {
		return prefixExtractFilename;
	}

	/**
	 * 
	 * @return Le pr�fixe du nom du fichier de log d'erreur � utiliser pour conserver les erreurs d'extraction lors de l'init
	 */
	public String getPrefixErreurExtractFilename() {
		return "ERR_" + getPrefixExtractFilename();
	}

	/**
	 * 
	 * @return Le pr�fixe du fichier d'initialisation pour Pharaon
	 */
	public String getPrefixInitFilename() {
		return prefixInitFilename;
	}

	/**
	 * @return the extractDir
	 */
	public String getExtractDir() {
		return extractDir;
	}

	/**
	 * @param extractDir the extractDir to set
	 */
	public void setExtractDir(String extractDir) {
		this.extractDir = extractDir;
	}

	/**
	 * @return the logDir
	 */
	public String getLogDir() {
		return logDir;
	}

	/**
	 * @param logDir the logDir to set
	 */
	public void setLogDir(String logDir) {
		this.logDir = logDir;
	}

	/**
	 * @return the initDir
	 */
	public String getInitDir() {
		return initDir;
	}

	/**
	 * @param initDir the initDir to set
	 */
	public void setInitDir(String initDir) {
		this.initDir = initDir;
	}

	/**
	 * @return the actif
	 */
	public boolean isActif() {
		return actif;
	}

	/**
	 * @param actif the actif to set
	 */
	public void setActif(boolean actif) {
		this.actif = actif;
	}

	/**
	 * @param sepData the sepData to set
	 */
	public void setSepData(String sepData) {
		this.sepData = sepData;
	}

	/**
	 * @param prefixExtractFilename the prefixExtractFilename to set
	 */
	public void setPrefixExtractFilename(String prefixExtractFilename) {
		this.prefixExtractFilename = prefixExtractFilename;
	}

	/**
	 * @param prefixInitFilename the prefixInitFilename to set
	 */
	public void setPrefixInitFilename(String prefixInitFilename) {
		this.prefixInitFilename = prefixInitFilename;
	}

}
