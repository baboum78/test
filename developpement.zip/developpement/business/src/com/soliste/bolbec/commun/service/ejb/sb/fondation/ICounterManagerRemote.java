package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import java.rmi.RemoteException;

/**
 * Interface metier de l'ejb <code>CounterManagerSB</code><br/>
 * Permet de recuperer les id<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public interface ICounterManagerRemote {

	/**
	 * Retourne le prochain identifiant du compteur par d�faut.
	 * 
	 * @return le prochain identifiant
	 */
	public long next() throws RemoteException;

	/**
	 * Retourne le prochain identifiant du compteur ayant le nom donn�.
	 * 
	 * @param counterName nom du compteur
	 * 
	 * @return le prochain identifiant du compteur ayant le nom donn�
	 */
	public long next(String counterName) throws RemoteException;
}
