package com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.factory;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.GraficXMLTransformCallBack;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.impl.GraficXMLTransformFaultCallBack;
import com.soliste.bolbec.commun.service.util.xml.XmlDomCxfFactory;

/**
 * Factory qui instancie un callback traitant les r�ponses
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 */
public class GraficXMLTransformFaultCallBackFactory implements GraficXMLTransformCallBackFactory {

	@Override
	public GraficXMLTransformCallBack createGraficXMLTransformCallBack() {
		return new GraficXMLTransformFaultCallBack(XmlDomCxfFactory.getInstance());
	}
}
