package com.soliste.bolbec.commun.service.util.archiving;

/**
 * Interface d�finissant la notion d'archiver
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public interface Archiver {

	/**
	 * Archivage en BDD
	 * 
	 * @param archivable l'objet � archiver
	 * @throws ArchivingException
	 */
	public void archive(Archivable archivable) throws ArchivingException;

}
