package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import javax.ejb.EJBObject;

/**
 * Interface Remote de l'EJB session CounterManagerSB. Permet de g�rer la g�n�ration des
 * identifiants en base.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public interface CounterManagerRemote extends ICounterManagerRemote, EJBObject {

}
