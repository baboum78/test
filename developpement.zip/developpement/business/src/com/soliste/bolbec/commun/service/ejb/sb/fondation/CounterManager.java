package com.soliste.bolbec.commun.service.ejb.sb.fondation;

/**
 * Interface metier de l'ejb <code>CounterManagerSB</code><br/>
 * Permet de recuperer les id<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * @author kyrw0678
 * 
 */
public interface CounterManager {

	/**
	 * Retourne le prochain identifiant du compteur par d�faut.
	 * 
	 * @return le prochain identifiant
	 */
	public long next();

	/**
	 * Retourne le prochain identifiant du compteur ayant le nom donn�.
	 * 
	 * @param counterName nom du compteur
	 * 
	 * @return le prochain identifiant du compteur ayant le nom donn�
	 */
	public long next(String counterName);

}
