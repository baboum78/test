package com.soliste.bolbec.commun.service.exception;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Ajout accolades autour d'instruction seule</TD></TR>
 * <TR><TD>18/12/2012</TD><TD>BPE</TD><TD>DE-000692 : Objets Pharaon non instanci�s par le conteneur EJB</TD></TR>
 * </TABLE><BR>
 */

/**
 * The Class TechnicalBusinessException.
 */
public class TechnicalBusinessException extends RuntimeException {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -8138353260270285316L;

	/**
	 * Instantiates a new technical business exception.
	 */
	public TechnicalBusinessException() {
		super();
	}

	/**
	 * Instantiates a new technical business exception.
	 * 
	 * @param msg the msg
	 */
	public TechnicalBusinessException(String msg) {
		super(msg);
	}

	/**
	 * Instantiates a new technical business exception.
	 * 
	 * @param msg the msg
	 * @param t the t
	 */
	public TechnicalBusinessException(String msg, Throwable t) {
		super(msg, t);
	}

}
