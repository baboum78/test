package com.soliste.bolbec.commun.service.interfaces.util.cxf;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.headers.Header;
import org.apache.cxf.jaxb.JAXBDataBinding;
import org.apache.cxf.message.Message;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

import com.sun.org.apache.xerces.internal.dom.ElementNSImpl;

/**
 * Class d'outils pour les intercepteurs
 */
public class InterceptorUtils {

	private static final String CLASS_NAME = InterceptorUtils.class.getName();


	private InterceptorUtils(){}

	/**
	 * M�thode pour ajouter au message re�u le header de l'emetteur de la commande
	 *
	 * @param message
	 * @param headerList
	 */
	public static void misAJourHeaderAvecEmetteur(Message message, List<Header> headerList) {
		List<Header> headerListAEnvoyer = new ArrayList<>();
		String emetteur = null;
		String refExterne = null;
		String typeMessage = null;
		for (Header header : headerList) {
			emetteur = getHeader(emetteur, header, Constantes.HEADER_ROU_EMETTEUR);
			refExterne = getHeader(refExterne, header, Constantes.HEADER_ROU_REF_EXTERNE);
			typeMessage = getHeader(typeMessage, header, Constantes.HEADER_ROU_TYPE_MESSAGE);
		}

		addHeader(headerListAEnvoyer, emetteur, Constantes.HEADER_ROU_EMETTEUR);
		addHeader(headerListAEnvoyer, refExterne, Constantes.HEADER_ROU_REF_EXTERNE);
		addHeader(headerListAEnvoyer, typeMessage, Constantes.HEADER_ROU_TYPE_MESSAGE);
		if (headerListAEnvoyer.size() > 0) {
			message.put(Header.HEADER_LIST, headerListAEnvoyer);
		}
	}

	/**
	 * On ajoute un header � la liste avec headerName si le headerValue est non vide
	 *
	 * @param headerListAEnvoyer
	 * @param headerValue
	 * @param headerName
	 */
	private static void addHeader(List<Header> headerListAEnvoyer, String headerValue, String headerName) {
		String method = "addHeader";
		if (StringUtils.isNotBlank(headerValue)) {
			try {
				Header newHeader = new Header(new QName(Constantes.URI_ORG_APACHE_CXF, headerName), headerValue, new JAXBDataBinding(String.class));
				headerListAEnvoyer.add(newHeader);
			} catch (JAXBException e) {
				LoggerManager.getInstance().finest(CLASS_NAME, method, "Erreur lors de la recup�ration du header routeur");
			}
		}
	}

	/**
	 * Si le nom du header est egal � HeaderName, on retour la valeur du header
	 *
	 * @param headerValue
	 * @param header
	 * @param headerName
	 * @return
	 */
	private static String getHeader(String headerValue, Header header, String headerName) {
		if (StringUtils.isBlank(headerValue) && header.getName().toString().contains(headerName)) {
			//la valeur cherch� peut venir des 2 mani�re selon d'o� vient le message
			//le traitement des headers c'est diff�rent si le message est proventant des files MQ ou de la partie routeur/livraison
			if (header.getObject() instanceof  String) {
				headerValue = (String) header.getObject();
			} else if (header.getObject() instanceof ElementNSImpl) {
				headerValue = ((ElementNSImpl) header.getObject()).getFirstChild().getNodeValue();
			}
		}
		return headerValue;
	}

}
