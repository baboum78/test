package com.soliste.bolbec.commun.service.exception;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/07/2012</TD><TD>FTE</TD><TD>Cr�ation classe</TD></TR>
 * </TABLE><BR>
 */

public class InterfaceTechnicalException extends RuntimeException {

	/**
	 * 
	 * @param msg
	 * @param cause
	 */
	public InterfaceTechnicalException(String msg, Throwable cause) {
		super(msg, cause);
	}
}
