package com.soliste.bolbec.commun.service.model;

import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.fwk.util.DateUtils;

import java.util.HashMap;

/**
 * DTO d�crivant un appel ZBus archiver c�t� routeur
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/11/2020</TD><TD>JDE</TD><TD>G9R7C17 - Initialisation</TD></TR>
 * </TABLE>
 */
public class MessageZBusOutDTO implements Archivable {

	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = -5460264704362328207L;

	/** Clefs (les noms exacts des colonnes des tables routeur MessageZBusOut) */
	public static String CLE_DATE_MESSAGE = "dateMessage";
	public static String CLE_METHODE = "methode";
	public static String CLE_SERVICE = "service";
	public static String CLE_CODE_REPONSE = "codeReponse";
	public static String CLE_CONTENU_REQUETE = "contenuRequete";
	public static String CLE_CONTENU_REPONSE = "contenuReponse";

	/** Infos */
	protected Long dateMessage;
	protected String methode;
	protected String service;
	protected String codeReponse;
	protected String contenuRequete;
	protected String contenuReponse;


	public Long getDateMessage(){
		return dateMessage;
	}

	public void setDateMessage(Long dateMessage){
		this.dateMessage = dateMessage;
	}

	public String getMethode(){
		return methode;
	}

	public void setMethode(String methode){
		this.methode = methode;
	}

	public String getService(){
		return service;
	}

	public void setService(String service){
		this.service = service;
	}

	public String getCodeReponse(){
		return codeReponse;
	}

	public void setCodeReponse(String codeReponse){
		this.codeReponse = codeReponse;
	}

	public String getContenuRequete(){
		return contenuRequete;
	}

	public void setContenuRequete(String contenuRequete){
		this.contenuRequete = contenuRequete;
	}

	public String getContenuReponse(){
		return contenuReponse;
	}

	public void setContenuReponse(String contenuReponse){
		this.contenuReponse = contenuReponse;
	}

	/**
	 * Le constructeur du DTO MessageZBusOut
	 *
	 * @param methode
	 * @param service
	 * @param codeResponse
	 * @param contenuRequete
	 * @param contenuReponse
	 */
	public MessageZBusOutDTO(String methode, String service, String codeResponse, String contenuRequete, String contenuReponse) {
		this.dateMessage = DateUtils.getDatabaseDate();
		this.methode = methode;
		this.service = service;
		this.codeReponse = codeResponse;
		this.contenuRequete = contenuRequete;
		this.contenuReponse = contenuReponse;
	}

	/**
	 * R�cup�rer une image de l'objet sous forme de map
	 *
	 * @return l'image de l'objet sous forme de map
	 */
	public HashMap<String, Object> toMap() {
		HashMap<String, Object> map = new HashMap<String, Object>();

		map.put(CLE_DATE_MESSAGE, dateMessage);
		map.put(CLE_METHODE, methode);
		map.put(CLE_SERVICE, service);
		map.put(CLE_CODE_REPONSE, codeReponse);
		map.put(CLE_CONTENU_REQUETE, contenuRequete);
		map.put(CLE_CONTENU_REPONSE, contenuReponse);

		return map;
	}

}