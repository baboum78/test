package com.soliste.bolbec.commun.service.constante;

/**
 * Etats possibles li�s � un transfert CFT
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>22/10/2010</TD><TD>GPA</TD><TD>EV-000087: Cr�ation de la classe</TD></TR>
 * </TABLE>
 */
public enum CodeTransfert {
	A_EXTRAIRE, EN_COURS, ECRIT, ENVOYE, ERREUR, ERREUR_IMF
}
