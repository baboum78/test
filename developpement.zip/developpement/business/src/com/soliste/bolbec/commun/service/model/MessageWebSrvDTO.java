package com.soliste.bolbec.commun.service.model;

import java.util.HashMap;

import com.soliste.bolbec.commun.service.constante.SoapTrameType;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.fwk.util.DateUtils;

/**
 * DTO d�crivant une trame SOAP � archiver c�t� routeur lors d'un appel par un service externe
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>17/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public abstract class MessageWebSrvDTO implements Archivable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = -1122111204417541602L;

	/** Clefs (les noms exacts des colonnes des tables routeur MessageWebSrv) */
	public static String CLE_DATE_MESSAGE = "dateMessage";
	public static String CLE_SERVICE = "service";
	public static String CLE_TYPE_MESSAGE = "typeMessage";
	public static String CLE_CONTENU = "contenu";
	public static String CLE_REF_COMMANDE = "refCommande";

	/** Infos */
	protected Long dateMessage;
	protected String service;
	protected SoapTrameType typeMessage;
	protected String contenu;
	protected String refCommande;

	/**
	 * Constructeur
	 * 
	 * @param service le service appel�
	 * @param typeMessage le type du message
	 * @param contenu la trame SOAP
	 */
	public MessageWebSrvDTO(String service, SoapTrameType typeMessage, String contenu, String refCommande) {
		this.dateMessage = DateUtils.getDatabaseDate();
		this.service = service;
		this.typeMessage = typeMessage;
		this.contenu = contenu;
		this.refCommande = refCommande;
	}

	/**
	 * R�cup�rer une image de l'objet sous forme de map
	 * 
	 * @return l'image de l'objet
	 */
	public HashMap<String, Object> toMap() {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(CLE_DATE_MESSAGE, dateMessage);
		map.put(CLE_SERVICE, service);
		map.put(CLE_TYPE_MESSAGE, typeMessage.name());
		map.put(CLE_CONTENU, contenu);
		map.put(CLE_REF_COMMANDE, refCommande);

		return map;
	}

}
