package com.soliste.bolbec.commun.service.util;

import java.io.IOException;
import java.io.InputStream;

import org.codehaus.jackson.map.DeserializationConfig;
import org.codehaus.jackson.map.ObjectMapper;
import org.codehaus.jackson.map.SerializationConfig;
import org.codehaus.jackson.map.annotate.JsonSerialize;

public class JsonUtils {
    private static final String CLASS_NAME = JsonUtils.class.getName();

    private static ObjectMapper getObjectMapper() {
		ObjectMapper mapper = new ObjectMapper();
		mapper.setSerializationInclusion(JsonSerialize.Inclusion.NON_NULL);

		// Serial
		mapper.configure(SerializationConfig.Feature.INDENT_OUTPUT, true);
		mapper.configure(SerializationConfig.Feature.WRITE_DATES_AS_TIMESTAMPS, false);
		mapper.configure(SerializationConfig.Feature.WRITE_NULL_MAP_VALUES, true);

		// Deserial
		mapper.configure(DeserializationConfig.Feature.FAIL_ON_UNKNOWN_PROPERTIES, false);

		return mapper;
    }

    public static String format(Object obj) throws IOException {
		ObjectMapper objectMapper = getObjectMapper();
		return  objectMapper.writeValueAsString(obj);
    }

	public static <T> T parse(String sText, Class<T> c) throws IOException {
		ObjectMapper objectMapper = getObjectMapper();
		return  objectMapper.readValue(sText, c);
	}

	public static <T> T parse(InputStream sText, Class<T> c) throws IOException {
		ObjectMapper objectMapper = getObjectMapper();
		return  objectMapper.readValue(sText, c);
	}
}
