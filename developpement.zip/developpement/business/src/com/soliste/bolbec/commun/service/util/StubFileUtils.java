/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util;

import java.io.File;
import java.util.NoSuchElementException;
import java.util.WeakHashMap;

import org.apache.commons.configuration.ConfigurationException;
import org.apache.commons.configuration.PropertiesConfiguration;

import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>06/03/2012</TD><TD>BPE</TD><TD>Am�lioration de la recherche de bouchons</TD></TR>
 * </TABLE><BR>
 * 
 * @author AFBU7552
 */
public class StubFileUtils {

	private static final Log log = new Log(StubFileUtils.class);

	private static WeakHashMap<String, PropertiesConfiguration> cache = new WeakHashMap<String, PropertiesConfiguration>();

	/**
	 * @param dirPath
	 * @param serviceExterneId
	 * @param criterion
	 * @return
	 */
	public static PropertiesConfiguration loadCachedFile(String dirPath, String serviceExterneId, String criterion) {
		String key = new StringBuilder(serviceExterneId).append(criterion).toString();
		PropertiesConfiguration p = cache.get(key);
		if (p == null) {
			p = loadFile(dirPath, serviceExterneId, criterion);
			cache.put(key, p);
		}
		return p;
	}

	/**
	 * @param dirPath
	 * @param serviceExterneId
	 * @param criterion
	 * @return
	 */
	public static PropertiesConfiguration loadFile(String dirPath, String serviceExterneId, String criterion) {

		// on r�cup�re le fichier bouchon ...
		File bouchon = getFile(dirPath, serviceExterneId, criterion);

		// ... et on le charge
		PropertiesConfiguration p;
		try {
			p = new PropertiesConfiguration(bouchon);
			p.setThrowExceptionOnMissing(Boolean.TRUE.booleanValue());
		} catch (ConfigurationException e) {
			String msg = "une erreur est survenue lors du chargement du fichier bouchon " + bouchon.getAbsolutePath();
			log.fatal(msg, e);
			throw new IllegalStateException(msg, e);
		}
		return p;
	}

	/**
	 * @param dirPath
	 * @param serviceExterneId
	 * @param criterion
	 * @return
	 */
	private static File getFile(String dirPath, String serviceExterneId, String criterion) {

		String suffixe = (StringUtils.isBlank(criterion) ? "0" : criterion);

		File file = null;
		String fileName = null;

		fileName = new StringBuffer("res_").append(serviceExterneId).append("_").append(suffixe).toString();

		String tmpFileName = fileName;
		int fileNameLength = fileName.length();
		int limit = suffixe.length();
		int cpt = 0;
		while (cpt < limit && file == null) {

			File tmpFile = new File(dirPath, tmpFileName);
			if (tmpFile.exists()) {
				file = tmpFile;
			}
			tmpFileName = tmpFileName.substring(0, fileNameLength - ++cpt);
		}

		if (file == null) {
			fileName = new StringBuffer("res_").append(serviceExterneId).toString();
			File tmpFile = new File(dirPath, fileName);
			if (tmpFile.exists()) {
				file = tmpFile;
			}
		}

		if (file == null) {
			String msg = "aucun fichier bouchon [ fichier bouchon recherch� = " + StringUtils.replaceOnce(dirPath + "/", "//", "/") + fileName + " ]";
			log.fatal(msg);
			throw new NoSuchElementException(msg);
		}

		if (log.isDebugEnabled()) {
			log.debug("fichier bouchon recherch�: " + StringUtils.replaceOnce(dirPath + "/", "//", "/") + fileName + ", fichier bouchon utilis�: " + file.getAbsolutePath());
		}

		return file;
	}

	private StubFileUtils() {
		// constructeur priv� pour �viter les instanciations inutiles
	}
}
