package com.soliste.bolbec.commun.service;

/**
 * Classe de constantes pour l'API
 * 
 * @author bperrard
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/11/2015</TD><TD>BPE</TD><TD>G9R1C1 - Mise en place du routage de l'API Rest</TD></TR>
 * <TR><TD>15/09/2016</TD><TD>JDE</TD><TD>G9R2C1 - Refactoring de l'archivage des messages API (IN et OUT)</TD></TR>
 * </TABLE>
 *
 */
public interface ConstantesAPI {

	/**
	 * Ent�te HTTP permettant de r�cup�rer le nom de l'agent
	 */
	String HEADER_AGENT = "X-OAPI-User-Id";

	/**
	 * Ent�te HTTP permettant de r�cup�rer le nom de l'application
	 */
	String HEADER_APPLICATION = "X-OAPI-Application-Id";

	/**
	 * Ent�te HTTP content Type
	 */
	String HEADER_CONTENT_TYPE = "Content-Type";

	/**
	 * Ent�te HTTP permettant de surcharger la m�thode propos�e
	 * Utilis� notamment pour le PATCH car IOSW ne supporte pas cette m�thode
	 */
	String HEADER_METHOD_OVERRIDE = "X-HTTP-Method-Override";

	/**
	 * Valeur ContentType JSON UTF-8
	 */
	String CONTENT_TYPE_JSON_UTF8 = "application/json;charset=UTF-8";

	/**
	 * Constantes permettant de traduire l'�tat de la commande vers l'objet ServiceOrderStatus
	 */

	public final static String FO_ACOMP = "FO_ACOMP";
	public final static String FO_CREEE = "FO_CREEE";
	public final static String FO_VALID = "FO_VALID";
	public final static String ANN = "ANN";
	public final static String ANOINJ = "ANOINJ";
	public final static String COMP = "COMP";
	public final static String CREEE = "CREEE";
	public final static String LIVR = "LIVR";
	public final static String REJ = "REJ";
	public final static String TERM = "TERM";
}
