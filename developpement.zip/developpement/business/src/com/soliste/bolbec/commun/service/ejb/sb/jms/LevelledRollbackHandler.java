/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

import java.util.logging.Level;

import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Extension du Rollback Handler pour externaliser la d�finition des niveaux de traitement.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/01/2021</TD><TD>SOP</TD><TD>Initialisation pour Camunda</TD></TR>
 * </TABLE><BR>
 */
public class LevelledRollbackHandler extends  RollbackHandler {
	protected final ILoggerManager loggerManager = LoggerManager.getInstance();

	private static final String CLASS_NAME = LevelledRollbackHandler.class.getName();
	private static final String METHOD_NAME_GET_ALERT_TYPE = "getAlertType";
	private static final String METHOD_NAME_GET_ALERT_SLEEP_TIME = "getSleepTime";

	protected String className;

	private RollbackLevel[] rollbackLevels;





	/**
	 * Constructeur
	 *
	 */
	public LevelledRollbackHandler() {
		super(false);
		rollbackLevels = new RollbackLevel[] {
				RollbackLevel.DEFAULT_GREEN_LEVEL,
				RollbackLevel.DEFAULT_YELLOW_LEVEL,
				RollbackLevel.DEFAULT_RED_LEVEL,
				RollbackLevel.DEFAULT_BLACK_LEVEL,
				RollbackLevel.DEFAULT_DISCARD_LEVEL
		};
		className = CLASS_NAME;
	}

	/**
	 * Constructeur
	 *
	 */
	public LevelledRollbackHandler(RollbackLevel rollbackLevels[]) {
		super(false);
		this.rollbackLevels = rollbackLevels;
	}

	/**
	 * Setter des rollback levels
	 * @param rollbackLevels
	 */
	public void setRollbackLevels(RollbackLevel ... rollbackLevels){
		this.rollbackLevels = rollbackLevels;
	}
	/**
	 * Retourne le type d'alerte pour le nombre de republications donn�.
	 *
	 * @param republicationCount
	 * le nombre de republications du message
	 * @return le type d'alerte pour le nombre de republications donn�
	 */
	protected int getAlertType(int republicationCount) {
		final String methodName = METHOD_NAME_GET_ALERT_TYPE;
		int alertType = -1;
		for ( int iLevel = 0; iLevel < rollbackLevels.length; iLevel++) {
			if (rollbackLevels[iLevel].getThreshold() <= republicationCount) {
				alertType = iLevel;
			} else {
				break;
			}
		}

		// Log de l'op�ration
		if ( loggerManager.isLoggable(Level.FINER)) {
			loggerManager.finer(className, methodName, "Republication " + republicationCount + " --> Alert type " + getAlertString(alertType));
		}
		return alertType;
	}

	/**
	 * getAlertString
	 * 
	 * @param alertType
	 * @return
	 */
	protected String getAlertString(int alertType) {
		if ( (alertType >= 0) &&  (alertType<rollbackLevels.length)) {
			return rollbackLevels[alertType].getName();
		} else {
			return "Alerte inconnue.";
		}
	}

	/**
	 * Retourne le temps d'attente (en millisecondes) pour le nombre de
	 * republications et le type d'alerte donn�s
	 * 
	 * @param alertType le type d'alerte correspondant au nombre de republications
	 * @return le temps d'attente (en millisecondes)
	 */
	protected long getSleepTime(int alertType) {
		final String methodName = METHOD_NAME_GET_ALERT_SLEEP_TIME;

		long sleepTime = 60000L;
		if ( (alertType >= 0) &&  (alertType<rollbackLevels.length)) {
			sleepTime =  rollbackLevels[alertType].getSleepTime();
		}

		// Log de l'op�ration
		if ( loggerManager.isLoggable(Level.FINER)) {
			loggerManager.finer(className, methodName, "Alert type " + getAlertString(alertType) + " --> Sleep time de " + sleepTime);
		}

		// Fin
		return sleepTime;
	}
}