package com.soliste.bolbec.commun.service.constante;

/**
 * Liste des types de trames SOAP
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public enum SoapTrameType {
	Request, Response, Fault
}
