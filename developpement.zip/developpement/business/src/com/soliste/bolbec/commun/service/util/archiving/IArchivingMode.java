package com.soliste.bolbec.commun.service.util.archiving;

/**
 * Interface d�finissant les mode d'archivage
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>21/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public interface IArchivingMode {

	/**
	 * R�cup�ration du mode d'archivage des WS
	 * 
	 * @return le mode
	 */
	public boolean getWSArchivingMode();

}
