/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.util.pagination;

import java.io.Serializable;

/**
 * Classe d�finissant une commande de pagination.
 * 
 * @author rgvs7490
 */
public class PaginationCommand implements Serializable {

	/**
	 * Le nombre par d�faut d'objets par page.
	 */
	public static final int DEFAULT_OBJECTS_PER_PAGE = 10;

	/**
	 * Le num�ro (� partir de 1) de la page demand�e
	 */
	private int pageNumber;

	/**
	 * Le nombre d'objets voulus par page
	 */
	private int objectsPerPage;

	/**
	 * Constructeur. Le nombre d'objets par page est le nombre par d�faut.
	 * 
	 * @param pageNumber le num�ro (� partir de 0) de la page demand�e
	 */
	public PaginationCommand(int pageNumber) {
		this(pageNumber, DEFAULT_OBJECTS_PER_PAGE);
	}

	/**
	 * Constructeur.
	 * 
	 * @param pageNumber le num�ro de page demand� (� partir de 1)
	 * @param objectsPerPage le nombre d'objets par page voulu
	 */
	public PaginationCommand(int pageNumber, int objectsPerPage) {
		if (pageNumber < 1) {
			throw new IllegalArgumentException("pageNumber must be >= 1");
		}
		if (objectsPerPage <= 0) {
			throw new IllegalArgumentException("objectsPerPage must be > 0");
		}

		this.pageNumber = pageNumber;
		this.objectsPerPage = objectsPerPage;
	}

	/**
	 * Retourne le num�ro de page demand� (� partir de 1)
	 * 
	 * @return le num�ro de page demand� (� partir de 1)
	 */
	public int getPageNumber() {
		return this.pageNumber;
	}

	/**
	 * Retourne le nombre d'objets par page voulu
	 * 
	 * @return le nombre d'objets par page voulu
	 */
	public int getObjectsPerPage() {
		return this.objectsPerPage;
	}
}
