package com.soliste.bolbec.commun.service.ejb.sb.archiving;

import javax.ejb.EJBLocalObject;

/**
 * Interface local de l'EJB Session MessageWebSrvRouManager
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public interface ArchivingManagerLocal extends EJBLocalObject, ArchivingManager {

}
