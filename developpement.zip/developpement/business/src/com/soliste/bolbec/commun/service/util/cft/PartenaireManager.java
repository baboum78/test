/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.cft;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

/**
 * Gere les partenaires CFT. Il est possible d'obtenir un partenaire en
 * s'adressant � la m�thode getPartenaire(a_id, a_class). Cette m�thode attends
 * en param�tres l'identifiant du partenaire et le nom de la classe de ce
 * partenaire.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/10/2010</TD><TD>GPA</TD><TD>suppression des printStackTrace suite � l'audit Cast G7R3C1</TD></TR>
 * </TABLE>
 */
public class PartenaireManager {

	/** Instance du singleton */
	private static PartenaireManager instance = null;
	/** Table des partenaires */
	protected HashMap<String, Partenaire> partenaires = new HashMap<String, Partenaire>(101);
	/** Classes des instances g�r�es par le singleton. */
	private static HashMap<String, String> classesName = new HashMap<String, String>(101);

	/**
	 * Construit l'instance du singleton. Initialise la liste des types des
	 * partenaires g�r�s.
	 */
	private PartenaireManager() {
		// Rien � faire
	}

	/**
	 * Retourne l'instance unique.
	 * 
	 * @return l'instance unique
	 */
	public static PartenaireManager getInstance() {
		if (instance == null) {
			instance = new PartenaireManager();
		}
		return instance;
	}

	/**
	 * Ajoute une instance � g�rer par le PartenaireManager
	 * 
	 * @param instanceToAdd
	 * nom de l'instance � ajouter
	 * @param nomClasse
	 * nom de la classe Partenaire
	 */
	public void addInstance(String instanceToAdd, String nomClasse) {
		classesName.put(instanceToAdd, nomClasse);
	}

	/**
	 * Ajoute le partenaire a_partenaire
	 * 
	 * @param partenaire
	 * partenaire cft � ajouter
	 */
	public void addPartenaire(Partenaire partenaire) {
		synchronized (partenaires) {
			partenaires.put(partenaire.getIdInstanceSE(), partenaire);
		}
	}

	/**
	 * Retourne le partenaire dont l'identifiant est pass� en param�tre.
	 * 
	 * @param partenaireId
	 * @param type
	 * @param properties
	 * @return le partenaire dont l'identifiant est pass� en param�tre.
	 */
	public Partenaire getPartenaire(String partenaireId, String type, HashMap<String, Connection> properties) {
		return doGetPartenaire(partenaireId, type, properties);
	}

	/**
	 * Ferme tous les partenaires qui ont �t� ouverts.
	 * 
	 * @param type
	 */
	public void closeAll(String type) {
		synchronized (partenaires) {
			Iterator<String> iIdPartenaires = partenaires.keySet().iterator();
			List<String> idDesPartenairesASupprimer = new ArrayList<String>();
			while (iIdPartenaires.hasNext()) {
				String idPartenaire = iIdPartenaires.next();
				Partenaire partenaire = partenaires.get(idPartenaire);
				if (partenaire.getClass().getName().equals(classesName.get(type))) {
					partenaire.close();
					/*
					 * on ne doit pas modifier une collection lorsqu'on est dans
					 * une boucle sur les clefs de celle-ci : le remove se fait
					 * hors de la boucle
					 */
					idDesPartenairesASupprimer.add(idPartenaire);
				}
			}
			for (int index = 0; index < idDesPartenairesASupprimer.size(); index++) {
				partenaires.remove(idDesPartenairesASupprimer.get(index));
			}
		}
	}

	/**
	 * Retourne le partenaire dont l'identifiant est pass� en param�tre.
	 * 
	 * @param idPartenaire
	 * @param type
	 * @param properties
	 * @return le partenaire dont l'identifiant est pass� en param�tre.
	 */
	protected Partenaire doGetPartenaire(String idPartenaire, String type, HashMap<String, Connection> properties) {
		Partenaire partenaire = null;
		synchronized (partenaires) {
			partenaire = partenaires.get(idPartenaire);
			if (partenaire == null) {
				try {
					partenaire = (Partenaire) Class.forName(classesName.get(type)).newInstance();
					partenaire.init(idPartenaire, properties);
					addPartenaire(partenaire);
				} catch (Exception e) {
					throw new RuntimeException("Erreur dans PartenaireManager.doGetPartenaire : " + e.getMessage(), e);
				}
			}
		}
		return partenaire;
	}
}