package com.soliste.bolbec.commun.service.util.jdbc;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import org.apache.commons.dbutils.DbUtils;

/**
 * Class utilitaire pour JDBC
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/03/2011</TD><TD>GPE</TD><TD>IRMA 969: ORA-01461 can bind a LONG value only for insert into a LONG column workaround</TD></TR>
 * <TR><TD>12/07/2013</TD><TD>JLA</TD><TD>Retour arri�re sur l'IRMA 969 suite au passage � Weblo 10</TD></TR>
 * <TR><TD>23/10/2013</TD><TD>EBA</TD><TD>G9R0C1 : Corrections sonar</TD></TR>
 * </TABLE><BR>
 */
public class JdbcUtils {

	/**
	 * D�finition pour les connections JDBC � la base
	 */
	private final static String CONNECTION_USER_COLLECTE = "USERORACLE";
	private final static String CONNECTION_PWD_COLLECTE = "PASSWORDORACLE";
	private final static String JDBC_DRIVER_NAME = "oracle.jdbc.driver.OracleDriver";
	private final static String JDBC_PREFIXE = "jdbc:oracle:thin:@";
	private final static String ORACLE_HOST = "ORACLE_HOST";
	private final static String ORACLE_PORT = "ORACLE_PORT";
	private final static String ORACLE_SERVICE = "ORACLE_SERVICE";

	private static final String USER = System.getProperty(CONNECTION_USER_COLLECTE);
	private static final String PWD = System.getProperty(CONNECTION_PWD_COLLECTE);
	private static final String CONNECT_STRING = JDBC_PREFIXE + System.getProperty(ORACLE_HOST) + ":" + System.getProperty(ORACLE_PORT) + ":" + System.getProperty(ORACLE_SERVICE);

	private static final String SELECT_F_COUNTER = "SELECT f_count FROM F_COUNTER WHERE f_name = ?";
	private static final String UPDATE_F_COUNTER = "UPDATE F_COUNTER SET f_count = ? WHERE f_name= ?";

	/**
	 * Ferme le ResultSet donn�, et ignore les exception SQL qui peuvent d�couler
	 * de cette fermeture.
	 * 
	 * @param rs le ResultSet � fermer. null est une valeur accept�e.
	 */
	public static void closeResultSet(ResultSet rs) {
		try {
			DbUtils.close(rs);
		} catch (SQLException e1) {
			// ignore
		}
	}

	/**
	 * Ferme le Statement donn�, et ignore les exception SQL qui peuvent d�couler
	 * de cette fermeture.
	 * 
	 * @param s le Statement � fermer. null est une valeur accept�e.
	 */
	public static void closeStatement(Statement s) {
		try {
			DbUtils.close(s);
		} catch (SQLException e1) {
			// ignore
		}
	}

	/**
	 * Ferme la Connection donn�e, et ignore les exception SQL qui peuvent d�couler
	 * de cette fermeture.
	 * 
	 * @param c la Connection � fermer. null est une valeur accept�e.
	 */
	public static void closeConnection(Connection c) {
		try {
			DbUtils.close(c);
		} catch (SQLException e1) {
			// ignore
		}
	}

	/**
	 * Ex�cute une requ�te SQL, et retourne une liste d'objets. Les objets retourn�s
	 * sont cr��s gr�ce au RowMapper pass� en argument.
	 * 
	 * @param dataSource le DataSource sur lequel la requ�te doit �tre ex�cut�e
	 * @param query la requ�te � ex�cuter
	 * @param args les arguments de la requ�tes
	 * @param rowMapper le RowMapper permettant de transformer les lignes retourn�es
	 * par la requ�te en objets
	 * 
	 * @return une liste d'objets
	 * 
	 * @throws SQLException dans le cas o� l'ex�cution de la requ�te lance une telle
	 * exception
	 */
	public static <T> List<T> query(DataSource dataSource, String query, Object[] args, RowMapper<T> rowMapper) throws SQLException {
		List<T> result = new ArrayList<T>();
		Connection c = null;
		PreparedStatement s1 = null;
		ResultSet rs1 = null;
		try {
			c = dataSource.getConnection();

			s1 = c.prepareStatement(query);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					s1.setObject(i + 1, args[i]);
				}
			}
			rs1 = s1.executeQuery();
			while (rs1.next()) {
				result.add(rowMapper.mapRow(rs1));
			}
		} finally {
			closeResultSet(rs1);
			closeStatement(s1);
			closeConnection(c);
		}
		return result;
	}

	/**
	 * Ex�cute une requ�te SQL, et retourne une liste d'objets. Les objets retourn�s
	 * sont cr��s gr�ce au RowMapper pass� en argument.
	 * 
	 * @param connection
	 * la connection sur laquelle la requ�te doit �tre ex�cut�e
	 * @param query
	 * la requ�te � ex�cuter
	 * @param args
	 * les arguments de la requ�tes
	 * @param rowMapper
	 * le RowMapper permettant de transformer les lignes retourn�es par la requ�te en objets
	 * @param autoClose
	 * faut il fermer la connection?
	 * @return
	 * une liste d'objets
	 * @throws SQLException
	 * dans le cas o� l'ex�cution de la requ�te lance une telle exception
	 */
	public static <T> List<T> query(Connection connection, String query, Object[] args, RowMapper<T> rowMapper, boolean autoClose) throws SQLException {
		List<T> result = new ArrayList<T>();
		PreparedStatement s1 = null;
		ResultSet rs1 = null;
		try {
			s1 = connection.prepareStatement(query);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					s1.setObject(i + 1, args[i]);
				}
			}
			rs1 = s1.executeQuery();
			while (rs1.next()) {
				result.add(rowMapper.mapRow(rs1));
			}
		} finally {
			closeResultSet(rs1);
			closeStatement(s1);
			if (autoClose) {
				closeConnection(connection);
			}
		}
		return result;
	}

	/**
	 * Ex�cute une requ�te SQL, et retourne une liste d'objets. Les objets retourn�s
	 * sont cr��s gr�ce au RowMapper pass� en argument. Attention, cette m�thode peut retourner null.
	 * 
	 * @param connection
	 * la connection sur laquelle la requ�te doit �tre ex�cut�e
	 * @param query
	 * la requ�te � ex�cuter
	 * @param args
	 * les arguments de la requ�tes
	 * @param autoClose
	 * faut il fermer la connection?
	 * @return
	 * une liste d'objets
	 * @throws SQLException
	 * dans le cas o� l'ex�cution de la requ�te lance une telle exception
	 */
	public static String query(Connection connection, String query, Object[] args, boolean autoClose) throws SQLException {
		PreparedStatement s1 = null;
		ResultSet rs1 = null;
		String result = null;
		try {
			s1 = connection.prepareStatement(query);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					s1.setObject(i + 1, args[i]);
				}
			}
			rs1 = s1.executeQuery();

			if (rs1.next()) {
				result = rs1.getString(1);
			}
		} finally {
			closeResultSet(rs1);
			closeStatement(s1);
			if (autoClose) {
				closeConnection(connection);
			}
		}
		return result;
	}

	/**
	 * Ex�cute une requ�te SQL d'update.
	 * 
	 * @param connection
	 * la connection sur laquelle la requ�te doit �tre ex�cut�e
	 * @param query
	 * la requ�te � ex�cuter
	 * @param args
	 * les arguments de la requ�tes
	 * @param autoClose
	 * faut il fermer la connection?
	 * @throws SQLException
	 * dans le cas o� l'ex�cution de la requ�te lance une telle exception
	 */
	public static void updateQuery(Connection connection, String query, Object[] args, boolean autoClose) throws SQLException {
		PreparedStatement s1 = null;
		ResultSet rs1 = null;
		try {
			s1 = connection.prepareStatement(query);
			if (args != null) {
				for (int i = 0; i < args.length; i++) {
					s1.setObject(i + 1, args[i]);
				}
			}
			rs1 = s1.executeQuery();
		} finally {
			closeResultSet(rs1);
			closeStatement(s1);
			if (autoClose) {
				closeConnection(connection);
			}
		}
	}

	/**
	 * 
	 * @return une connection JDBC � la base de donn�es
	 */
	public static Connection getConnection() {
		Connection connection = null;
		try {
			DriverManager.registerDriver((Driver) Class.forName(JDBC_DRIVER_NAME).newInstance());
			connection = DriverManager.getConnection(CONNECT_STRING, USER, PWD);
		} catch (Exception t) {
			throw new RuntimeException("JdbcUtils.getConnection", t);
		}
		return connection;
	}

	/**
	 * @param fName
	 * @return la valeur de l'enregistrement de la table F_COUNTER dont la cl� est pass� en param�tre
	 * @throws Exception
	 */
	public static String getFCount(String fName) throws Exception {
		Connection connection = getConnection();
		Object[] args = new Object[] { fName };
		return query(connection, SELECT_F_COUNTER, args, true);
	}

	/**
	 * @param fName
	 * @param fCount
	 * @throws Exception
	 */
	public static void setFCount(String fName, String fCount) throws Exception {
		Connection connection = getConnection();
		Object[] args = new Object[] { fCount, fName };
		updateQuery(connection, UPDATE_F_COUNTER, args, true);
	}

}
