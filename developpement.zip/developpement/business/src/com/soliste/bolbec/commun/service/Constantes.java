package com.soliste.bolbec.commun.service;

import com.soliste.bolbec.fwk.util.PropertiesUtils;

/**
 * Constante commune � l'application bolbec
 * 
 * @author kyrw0678
 * test
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>28/07/2010</TD><TD>DBA</TD><TD>MAJ - Fichier Constantes (G7R4 > G7R5, G7R3 > G7R4, G7R2 > G7R3)</TD></TR>
 * <TR><TD>04/07/2012</TD><TD>GPA</TD><TD>EV-000184 : Achat FTTH - Ajout de la constante PIPE</TD></TR>
 * <TR><TD>01/08/2012</TD><TD>AGR</TD><TD>EV-000188 : Vente FTTH - Ajout constantes Accolades</TD></TR>
 * <TR><TD>13/11/2012</TD><TD>FTE</TD><TD>Ajout des mots-cl�s "public static final" pour chaque constantes</TD></TR>
 * <TR><TD>10/12/2012</TD><TD>FTE</TD><TD>EV-000217 : Affichage Num JVM et machine sur bureau - Ajout des constantes JVM_NAME et HOSTNAME</TD></TR>
 * <TR><TD>21/12/2012</TD><TD>GPA</TD><TD>EV-000191 : G8R2C1 - Ajout de la clef CLE_ARCHIVAGE_WS</TD></TR>
 * <TR><TD>02/01/2013</TD><TD>FTE</TD><TD>EV-000215 : Ajout de la constante VALEUR_OUI</TD></TR>
 * <TR><TD>29/05/2013</TD><TD>EBA</TD><TD>G8R2C2 BackOffice : Mise en place du MigrationManager</TD></TR>
 * <TR><TD>13/06/2013</TD><TD>AZA</TD><TD>G9R0C1 : Cr�ation de la branche G9R0C1</TD></TR>
 * <TR><TD>10/10/2013</TD><TD>VDE</TD><TD>Migration : Ajout des intercepteurs CXF</TD></TR>
 * <TR><TD>19/11/2013</TD><TD>BPE</TD><TD>G9R0C1 : EV-000252 "Modification du m�canisme de routage aux IHMs Artemis"</TD></TR>
 * <TR><TD>31/10/2014</TD><TD>KRA</TD><TD>EV-000302_03 : PLP Fibre</TD></TR>
 * </TABLE>
 */
public interface Constantes {

	public static final String BOLBEC_PROP_FILE = System.getProperty("ConfigFile");

	public static final String BOLBEC_JVM_PROP_FILE = "bolbec_jvm.properties";

	public static final String VERSION = PropertiesUtils.getConfig(BOLBEC_PROP_FILE).getString("bolbec.server.version");

	public static final String APPLICATION_TYPE = PropertiesUtils.getConfig(Constantes.BOLBEC_PROP_FILE).getString("bolbec.type.appli");

	public static final String INSTANCE_CODE = PropertiesUtils.getConfig(Constantes.BOLBEC_PROP_FILE).getString("bolbec.instance.code");

	public static final String JVM_NAME = System.getProperty("weblogic.Name");

	public static final String HOSTNAME = System.getProperty("hostname");

	public static final String ALTEON_ADDRESS = System.getProperty("AlteonAddress");

	public static final String ALTEON_PORT_STR = System.getProperty("AlteonPort");

	public static final int ALTEON_PORT = ALTEON_PORT_STR == null ? -1 : Integer.parseInt(ALTEON_PORT_STR);

	public static final String APPLICATION_TYPE_LIVRAISON = "LIVRAISON";

	public static final String APPLICATION_TYPE_ROUTEUR = "ROUTEUR";

	public static final String APPLICATION_BOLBEC_MAJ = "BOLBEC";
	public static final String APPLICATION_BOLBEC_MAJ_MIN = "Artemis";
	public static final String APPLICATION_BOLBEC_MIN = "bolbec";

	// Changement_version : d�claration des 3 versions actives pour eviter de
	// modifier le code
	// a chaque changement de version
	public static final String VERSION_COURANTE = "G10";

	public static final String ND = "ND";

	public static final String DATASOURCE_NAME = PropertiesUtils.getConfig(BOLBEC_PROP_FILE).getString("dataSource");

	public static final String FIELD_MESSAGE = "Message";
	public static final String FIELD_TYPE_SERVICE = "TypeService";
	public static final String FIELD_SERVICE_DEST = "ServiceDest";
	public static final String FIELD_ID_EXTERNE = "IdExterne";
	public static final String FIELD_TRAITEMENT = "Traitement";
	public static final String FIELD_ND = "ND";
	public static final String FIELD_EMETTEUR = "Emetteur";
	public static final String FIELD_INSTANCE_LOCALISATION = "InstanceLocalisation";
	public static final String FIELD_RETOUR_ROUTEUR_AUTORISE = "retourRouteurAutorise";
	public static final String RETOUR_ROUTEUR_AUTORISE = "1";
	public static final String RETOUR_ROUTEUR_INTERDIT = "0";
	public static final String FIELD_INJECTEUR_INTERNE_CR_ACTIVATION_PARAM = "InjecteurIntCR_Activation";
	public static final String FIELD_INJECTEUR_INTERNE_CR_MESSAGE = "InjecteurIntCR_Message";
	public static final String FIELD_ID_COMMANDE = "IdCommande";
	public static final String FIELD_DATE_ROUTEUR = "DateTraitementRouteur";

	/**
	 * D�finition des attributs XML utilis�s dans les publications
	 * 
	 * @rt�mis/routeur et les messages routeur/SupDePro
	 */
	public static final String PUBLI_SUPDEPRO_ATT_REFERENCECDE = "ReferenceCde";
	public static final String PUBLI_SUPDEPRO_ATT_REFERENCELC = "ReferenceLC";
	public static final String PUBLI_SUPDEPRO_ATT_CODEACTION = "CodeAction";
	public static final String PUBLI_SUPDEPRO_ATT_JALON = "Jalon";
	public static final String PUBLI_SUPDEPRO_ATT_CODEDR = "CodeDR";
	public static final String PUBLI_SUPDEPRO_ATT_DATE = "Date";
	public static final String PUBLI_SUPDEPRO_ATT_INFO = "Info";
	public static final String PUBLI_SUPDEPRO_ATT_DATEENVOI = "DateEnvoi";

	/**
	 * Definition des constantes de Comparison de la fondation
	 */
	public static final String OPERATOR_EQUAL = "==";
	public static final String OPERATOR_DIFFERENT = "!=";
	public static final String OPERATOR_GREATER = ">";
	public static final String OPERATOR_GREATER_EQUAL = ">=";
	public static final String OPERATOR_LOWER = "<";
	public static final String OPERATOR_LOWER_EQUAL = "<=";
	public static final String OPERATOR_LIKE = "LIKE";
	public static final String OPERATOR_IS_NULL = "IS NULL";
	public static final String OPERATOR_IS_NOT_NULL = "IS NOT NULL";

	/**
	 * Definition de constantes diverses
	 */
	public static final String SEPARATEUR_PIPE = "|";
	public static final String ACCOLADE_GAUCHE = "{";
	public static final String ACCOLADE_DROITE = "}";
	public static final String STRING_UNDERSCORE = "_";

	/**
	 * Archivage des WS
	 */
	public static final String CLE_ARCHIVAGE_WS_SORTANTS = "ARCHIVAGE_WS_SORTANTS";

	public static final String CST_OUI = "OUI"; // EV-000032
	public static final String CST_NON = "NON"; // EV-000032

	public static final String XMLMESSAGE = "xmlMessage";

	/**
	 * Option remote du migrationManager
	 */
	public static final String CLE_MIGRATION_MANAGER_REMOTE = "MIGRATION_MANAGER_REMOTE";

	public static final String CST_SHORT_YES = "O"; // EV-000302
	public static final String CST_SHORT_NO = "N"; // EV-000302

	/**
	 * @since EV 322
	 * Mise en place de l'aide en ligne
	 */

	public static final String INCLUDETAG_SERVEUR = PropertiesUtils.getConfig(Constantes.BOLBEC_PROP_FILE).getString("bolbec.includeTag.serveur");

	/**
	 * EV-454
	 */
	public static final String STRING_0 = "0";
	public static final String STRING_1 = "1";

	public static final String CST_DOT = ".";

	String STR_ACTIVATION_PARAM_ACTIVATED_BY = "ACTIVATION_PARAM_ACTIVATED_BY";
	String STR_ACTIVATION_PARAM_ID_REQUETE = "ACTIVATION_PARAM_ID_REQUETE";
	String STR_ACTIVATION_PARAM_TYPE_REQUETE = "ACTIVATION_PARAM_TYPE_REQUETE";

	public static final String URI_ORG_APACHE_CXF = "uri:org.apache.cxf";
	public static final String HEADER_ROU_MESSAGE_IN = "HeaderRouMessageIn";
	public static final String HEADER_LIV_REF_COMMANDE = "HeaderLivRefCommande";
	public static final String HEADER_ROU_EMETTEUR = "HeaderRouEmetteur";
	public static final String HEADER_ROU_REF_EXTERNE = "HeaderRouRefExterne";
	public static final String HEADER_ROU_TYPE_MESSAGE = "HeaderRouTypeMessage";
}
