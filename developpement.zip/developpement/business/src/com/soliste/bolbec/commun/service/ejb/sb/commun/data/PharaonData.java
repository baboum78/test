package com.soliste.bolbec.commun.service.ejb.sb.commun.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>08/03/2010</TD><TD>DBA</TD><TD>EV-000047: Nouvelle classe</TD></TR>
 * <TR><TD>21/01/2011</TD><TD>CCL</TD><TD>EV-124: Ajout du nouvel attribut ndContactClient</TD></TR>
 * <TR><TD>12/10/2012</TD><TD>GPA</TD><TD>EV-000083: Ajout du nouvel attribut "entete"</TD></TR>
 * </TABLE>
 * 
 */
public class PharaonData {

	/**
	 * Constructeur de la classe PharaonData.
	 * 
	 * Initialise tous les attributs � vide par d�faut
	 */
	public PharaonData() {
		setCauseEvt("");
		setCauseEvtInitiale("");
		setDateAction("");
		setDateContractuelle("");
		setErreur("");
		setFamilleOffreFonctionnelle("");
		setIdcommande("");
		setIdIntervGPC("");
		setIndicateurAction("");
		setNd("");
		setNdplp("");
		setNomTache("");
		setRefEtude42C("");
		setRole("");
		setZoneSI("");
		setUrlInfos("");
		setNdContactClient("");
	}

	private String entete;

	public enum Entete {
		Commande, AVP
	}

	private String idcommande;

	private String nomTache;

	private String nd;

	private String ndplp;

	private String dateContractuelle;

	private String familleOffreFonctionnelle;

	private String role;

	private String zoneSI;

	private String refEtude42C;

	private String idIntervGPC;

	private String causeEvt;

	private String causeEvtInitiale;

	private String indicateurAction;

	private String dateAction;

	private String erreur;

	private String urlInfos;

	private String ndContactClient;

	/**
	 * @return the entete
	 */
	public Entete getEntete() {
		return Entete.valueOf(entete);
	}

	/**
	 * @param entete the entete to set
	 */
	public void setEntete(Entete entete) {
		this.entete = entete.name();
	}

	/**
	 * 
	 * @return L'url infos
	 */
	public String getUrlInfos() {
		return urlInfos;
	}

	/**
	 * M�thode permettant de modifier l'URL infos
	 * 
	 * @param urlInfos La nouvelle url infos
	 */
	public void setUrlInfos(String urlInfos) {
		this.urlInfos = urlInfos;
	}

	/**
	 * @return the erreur
	 */
	public String getErreur() {
		return erreur;
	}

	/**
	 * @param erreur the erreur to set
	 */
	public void setErreur(String erreur) {
		this.erreur = erreur;
	}

	/**
	 * @return the idcommande
	 */
	public String getIdcommande() {
		return idcommande;
	}

	/**
	 * @param idcommande the idcommande to set
	 */
	public void setIdcommande(String idcommande) {
		this.idcommande = idcommande;
	}

	/**
	 * @return the nomTache
	 */
	public String getNomTache() {
		return nomTache;
	}

	/**
	 * @param nomTache the nomTache to set
	 */
	public void setNomTache(String nomTache) {
		this.nomTache = nomTache;
	}

	/**
	 * @return the nd
	 */
	public String getNd() {
		return nd;
	}

	/**
	 * @param nd the nd to set
	 */
	public void setNd(String nd) {
		this.nd = nd;
	}

	/**
	 * @return the ndplp
	 */
	public String getNdplp() {
		return ndplp;
	}

	/**
	 * @param ndplp the ndplp to set
	 */
	public void setNdplp(String ndplp) {
		this.ndplp = ndplp;
	}

	/**
	 * @return the dateContractuelle
	 */
	public String getDateContractuelle() {
		return dateContractuelle;
	}

	/**
	 * @param dateContractuelle the dateContractuelle to set
	 */
	public void setDateContractuelle(String dateContractuelle) {
		this.dateContractuelle = dateContractuelle;
	}

	/**
	 * @return the familleOffreFonctionnelle
	 */
	public String getFamilleOffreFonctionnelle() {
		return familleOffreFonctionnelle;
	}

	/**
	 * @param familleOffreFonctionnelle the familleOffreFonctionnelle to set
	 */
	public void setFamilleOffreFonctionnelle(String familleOffreFonctionnelle) {
		this.familleOffreFonctionnelle = familleOffreFonctionnelle;
	}

	/**
	 * @return the role
	 */
	public String getRole() {
		return role;
	}

	/**
	 * @param role the role to set
	 */
	public void setRole(String role) {
		this.role = role;
	}

	/**
	 * @return the zoneSI
	 */
	public String getZoneSI() {
		return zoneSI;
	}

	/**
	 * @param zoneSI the zoneSI to set
	 */
	public void setZoneSI(String zoneSI) {
		this.zoneSI = zoneSI;
	}

	/**
	 * @return the refEtude42C
	 */
	public String getRefEtude42C() {
		return refEtude42C;
	}

	/**
	 * @param refEtude42C the refEtude42C to set
	 */
	public void setRefEtude42C(String refEtude42C) {
		this.refEtude42C = refEtude42C;
	}

	/**
	 * @return the idIntervGPC
	 */
	public String getIdIntervGPC() {
		return idIntervGPC;
	}

	/**
	 * @param idIntervGPC the idIntervGPC to set
	 */
	public void setIdIntervGPC(String idIntervGPC) {
		this.idIntervGPC = idIntervGPC;
	}

	/**
	 * @return the causeEvt
	 */
	public String getCauseEvt() {
		return causeEvt;
	}

	/**
	 * @param causeEvt the causeEvt to set
	 */
	public void setCauseEvt(String causeEvt) {
		this.causeEvt = causeEvt;
	}

	/**
	 * @return the causeEvtInitiale
	 */
	public String getCauseEvtInitiale() {
		return causeEvtInitiale;
	}

	/**
	 * @param causeEvtInitiale the causeEvtInitiale to set
	 */
	public void setCauseEvtInitiale(String causeEvtInitiale) {
		this.causeEvtInitiale = causeEvtInitiale;
	}

	/**
	 * @return the indicateurAction
	 */
	public String getIndicateurAction() {
		return indicateurAction;
	}

	/**
	 * @param indicateurAction the indicateurAction to set
	 */
	public void setIndicateurAction(String indicateurAction) {
		this.indicateurAction = indicateurAction;
	}

	/**
	 * @return the dateAction
	 */
	public String getDateAction() {
		return dateAction;
	}

	/**
	 * @param dateAction the dateAction to set
	 */
	public void setDateAction(String dateAction) {
		this.dateAction = dateAction;
	}

	/**
	 * @return le ndContactClient
	 */
	public String getNdContactClient() {
		return ndContactClient;
	}

	/**
	 * @param ndContactClient Nouvelle valeur de ndContactClient
	 */
	public void setNdContactClient(String ndContactClient) {
		this.ndContactClient = ndContactClient;
	}

}
