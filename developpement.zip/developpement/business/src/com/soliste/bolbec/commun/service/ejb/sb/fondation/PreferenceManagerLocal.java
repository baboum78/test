package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import javax.ejb.EJBLocalObject;

public interface PreferenceManagerLocal extends EJBLocalObject, PreferenceManager {

}
