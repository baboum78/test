/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.cft;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.HashMap;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Ajout accolades autour d'instruction seule</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe permettant de d�crire les partenaire CFT. Un partenaire sait:
 * <UL>
 * <LI> Cr�er le nom du fichier d'export
 * <LI> Emettre le fichier
 * <LI> Donner un writer pour �crire dans le fichier
 * </UL>
 * Chaque partenaire s'initialise � partir de l'acc�s � son ....
 */
abstract public class Partenaire {

	private static final String CFTUTIL_STRING = "CFTUTIL";
	private static final String SEND_STRING = "SEND";
	private static final String EQUALS_QUOTE_STRING = "='";
	private static final String QUOTE_COMMA_STRING = "',";

	public static final String ARGUMENTS_CFT_IDF = "IDF";
	public static final String ARGUMENTS_CFT_FNAME = "FNAME";
	public static final String ARGUMENTS_CFT_PART = "PART";
	public static final String ARGUMENTS_CFT_RUSER = "RUSER";
	public static final String ARGUMENTS_CFT_SUSER = "SUSER";
	public static final String ARGUMENTS_CFT_PARM = "PARM";
	public static final String ARGUMENTS_CFT_SAPPL = "SAPPL";

	public static final String PARAMETREINSTANCE_NOM_CODEEMETTEUR = "codeEmetteur";
	public static final String PARAMETREINSTANCE_NOM_IDFENTRANT = "idfEntrant";
	public static final String PARAMETREINSTANCE_NOM_IDFSORTANT = "idfSortant";
	public static final String PARAMETREINSTANCE_NOM_PARTENAIRE = "partenaire";
	public static final String PARAMETREINSTANCE_NOM_PATHFILESORTANT = "pathFileSortant";
	public static final String PARAMETREINSTANCE_NOM_PREFIXE = "prefixe";
	public static final String PARAMETREINSTANCE_NOM_SAPPL = "sappl";
	public static final String PARAMETREINSTANCE_NOM_SEQUENCE = "sequence";

	protected PrintWriter writer;
	protected File fichier;
	protected String partenaire;
	protected String idInstanceSE;
	protected String idfSortant;
	protected String prefixe;
	protected String idfEntrant;
	protected String user;

	/**
	 * param�tres sp�cifiques du partenaire.
	 */
	protected HashMap<String, Connection> properties = null;

	/**
	 * Constructeur sans param�tre n�cessaire pour le Manager. Il est
	 * indispensable d'appeler init() ensuite !!!!!
	 */
	public Partenaire() {
	}

	/**
	 * Retourne l'identifiant du partenaire
	 * 
	 * @return l'identifiant du partenaire
	 */
	abstract public String getPartenaire();

	/**
	 * Retourne idInstanceSE du partenaire
	 * 
	 * @return idInstanceSE du partenaire
	 */
	public String getIdInstanceSE() {
		return idInstanceSE;
	}

	/**
	 * Charge les donn�es d'initialisation du partenaire.
	 * 
	 * @param localIdInstanceSE
	 * @param localProperties
	 * @param localSpace
	 */
	protected void init(String localIdInstanceSE, HashMap<String, Connection> localProperties) {
		this.idInstanceSE = localIdInstanceSE;
		this.properties = localProperties;
		this.idfSortant = getIdfSortant();
	}

	/**
	 * Cette m�thode doit �tre surcharg�e dans les classes filles afin
	 * d'initialiser la variable idf.
	 * 
	 * @return la variable idf
	 */
	abstract protected String getIdfSortant();

	/**
	 * @return la variable idf
	 */
	abstract protected String getIdfEntrant();

	/**
	 * Construire la commande CFT SEND qui permet d'envoyer le fichier CFTUTIL
	 * SEND IDF=un_idf, PART=un_partenaire, FNAME=un_chemin
	 * 
	 * @return la commande CFT SEND
	 */
	public String[] getCommandeCFTSend() {
		String[] cft = new String[3];
		cft[0] = CFTUTIL_STRING;
		cft[1] = SEND_STRING;
		StringBuffer param = new StringBuffer();
		param.append(ARGUMENTS_CFT_IDF).append(EQUALS_QUOTE_STRING).append(getIdfSortant()).append(QUOTE_COMMA_STRING);
		param.append(ARGUMENTS_CFT_PART).append(EQUALS_QUOTE_STRING).append(getPartenaire()).append(QUOTE_COMMA_STRING);
		param.append(ARGUMENTS_CFT_FNAME).append(EQUALS_QUOTE_STRING).append(fichier.getAbsolutePath()).append(QUOTE_COMMA_STRING);
		cft[2] = param.toString();

		return cft;
	}

	/**
	 * @param propertyName
	 * le nom de la propri�t�
	 * @return la propri�t� dont le nom est pass� en argument. La table de
	 * propri�t�s doit �tre initialis�e par un appel � la m�thode
	 * <code>init</code>.
	 */
	protected Object getProperty(String propertyName) {
		return properties.get(propertyName);
	}

	/**
	 * retourne le nom de fichier de sortie
	 * 
	 * @return le nom de fichier de sortie
	 */
	public String getNomFichierSortie() {
		return fichier.getAbsolutePath();
	}

	/**
	 * Affecte le nom de fichier de sortie
	 * 
	 * @param nomFichier
	 */
	abstract public void setFichierSortie(String nomFichier);

	/**
	 * retourne un PrintWriter correspondant au fichier
	 * 
	 * @return un PrintWriter correspondant au fichier
	 * @throws IOException
	 */
	public PrintWriter getWriter() throws IOException {
		if (writer == null) {
			writer = newWriter();
		}
		return writer;
	}

	/**
	 * Cr�e et retourne un writer sur le fichier courant.
	 * 
	 * @return un writer sur le fichier courant
	 * @throws IOException
	 */
	protected PrintWriter newWriter() throws IOException {
		return new PrintWriter(new FileWriter(getNomFichierSortie()));
	}

	/**
	 * ferme le writer
	 */
	public void close() {
		writer.close();
		writer = null;
	}
}