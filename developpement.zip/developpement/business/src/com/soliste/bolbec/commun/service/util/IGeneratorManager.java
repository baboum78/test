package com.soliste.bolbec.commun.service.util;

public interface IGeneratorManager {

	/**
	 * G�n�re une cl� unique pour le type de contenu sp�cifi�.
	 * 
	 * @param contentType type de contenu
	 * 
	 * @return une cl� unique pour le type de contenu sp�cifi�
	 */
	String generateKey(String contentType);

	/**
	 * G�n�re une cl� unique pour le type de contenu sp�cifi�.
	 *
	 * @param contentType type de contenu
	 * @param prefix prefix a utiliser par le compteur
	 *
	 * @return une cl� unique pour le type de contenu sp�cifi�
	 */
	String generateKey(String contentType, String prefix);


	/**
	 * G�n�re une cl� unique
	 * 
	 * @return the string
	 */
	String generateKey();

}