/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.ejb.sb.agent;

import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.pagination.PaginatedList;
import com.soliste.bolbec.commun.service.util.pagination.PaginationCommand;
import com.soliste.bolbec.commun.service.util.sort.AgentSortCommand;

/**
 * Interface de l'EJB session AgentManager. Permet de g�rer des agents.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/10/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV000183 - Apostrof Corbeille IHM BIS</TD></TR>
 * <TR><TD>13/05/2013</TD><TD>EBA</TD><TD>G8R2C1 - DE-000824 (334 FT) : La cr�ation d'un nouvel utilisateur depuis une IHM G8R2 g�n�re une exception</TD></TR>
 * <TR><TD>15/10/2013</TD><TD>BPE</TD><TD>DE-000952 : Nouvelle methode ejb findAgentById</TD></TR>
 * </TABLE><BR>
 * 
 * @author rgvs7490
 */
public interface AgentManager {

	/**
	 * Permet d'obtenir les informations essentielles de l'agent courant, i.e.
	 * l'agent qui appelle cette m�thode, pour l'application donn�e en argument
	 * 
	 * @param applicationName le nom de l'application (livraison ou routeur par exemple)
	 * @param login the login
	 * 
	 * @return les informations de l'agent
	 */
	public AgentDTO getCurrentAgent(String login, String applicationName);

	/**
	 * Authenticate agent.
	 * 
	 * @param id the id
	 * @param password the password
	 * @param applicationName the application name
	 * 
	 * @return the agent
	 */
	public AgentDTO authenticateAgent(String id, String password, String applicationName);

	/**
	 * Retourne l'agent ayant l'ID donn� (ne va pas dans l'espace de reference). provoque un Rollbak si l'agent n'est pas trouv�
	 * 
	 * @param id l'identifiant de l'agent
	 * 
	 * @return l'agent
	 */
	public AgentDTO getAgent(String id);

	/**
	 * Retourne l'agent ayant l'ID donn� (ne va pas dans l'espace de reference). Retourne null si l'agent n'est pas trouv�
	 * 
	 * @param id l'identifiant de l'agent
	 * 
	 * @return l'agent, ou null si non trouv�
	 */
	public AgentDTO findAgentById(String id);

	/**
	 * Ins�re un nouvel agent.
	 * 
	 * @param id the id
	 * @param actif the actif
	 * @param email the email
	 * @param fax the fax
	 * @param gerable the gerable
	 * @param mdp the mdp
	 * @param nom the nom
	 * @param prenom the prenom
	 * @param telephone the telephone
	 * @param uniteActiviteId the unite activite id
	 */
	public void insertAgent(String id, boolean actif, String email, String fax, boolean gerable, String mdp, String nom, String prenom, String telephone, String uniteActiviteId, String modifNote);

	/**
	 * Met � jour l'agent ayant l'ID donn�.
	 * 
	 * @param id the id
	 * @param actif the actif
	 * @param email the email
	 * @param fax the fax
	 * @param gerable the gerable
	 * @param mdp the mdp
	 * @param nom the nom
	 * @param prenom the prenom
	 * @param telephone the telephone
	 * @param uniteActiviteId the unite activite id
	 */
	public void updateAgent(String id, boolean actif, String email, String fax, boolean gerable, String mdp, String nom, String prenom, String telephone, String uniteActiviteId, int modifNote);

	/**
	 * Supprime l'agent ayant l'ID donn�.
	 * 
	 * @param id l'identifiant de l'agent
	 */
	public void deleteAgent(String id);

	/**
	 * Search all.
	 * 
	 * @param paginationCommand the pagination command
	 * @param sortCommand the sort command
	 * 
	 * @return the paginated list< agent search result dt o>
	 */
	PaginatedList<AgentDTO> searchAll(PaginationCommand paginationCommand, AgentSortCommand sortCommand);

	/**
	 * Search by id.
	 * 
	 * @param id the id
	 * @param paginationCommand the pagination command
	 * @param sortCommand the sort command
	 * 
	 * @return the paginated list< agent search result dt o>
	 */
	PaginatedList<AgentDTO> searchById(String id, PaginationCommand paginationCommand, AgentSortCommand sortCommand);

	/**
	 * Search by nom.
	 * 
	 * @param nom the nom
	 * @param paginationCommand the pagination command
	 * @param sortCommand the sort command
	 * 
	 * @return the paginated list< agent search result dt o>
	 */
	PaginatedList<AgentDTO> searchByNom(String nom, PaginationCommand paginationCommand, AgentSortCommand sortCommand);

	/**
	 * Search by unite activite id.
	 * 
	 * @param uniteActiviteId the unite activite id
	 * @param paginationCommand the pagination command
	 * @param sortCommand the sort command
	 * 
	 * @return the paginated list< agent search result dt o>
	 */
	PaginatedList<AgentDTO> searchByUniteActiviteId(String uniteActiviteId, PaginationCommand paginationCommand, AgentSortCommand sortCommand);

	/**
	 * Search by unite organisation id.
	 * 
	 * @param uniteOrganisationId the unite organisation id
	 * @param paginationCommand the pagination command
	 * @param sortCommand the sort command
	 * 
	 * @return the paginated list< agent search result dt o>
	 */
	PaginatedList<AgentDTO> searchByUniteOrganisationId(String uniteOrganisationId, PaginationCommand paginationCommand, AgentSortCommand sortCommand);

}
