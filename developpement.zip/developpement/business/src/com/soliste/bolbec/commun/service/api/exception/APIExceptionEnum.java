package com.soliste.bolbec.commun.service.api.exception;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.commun.service.api.model.APIError;

/**
 * APIExceptionEnum
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>30/11/2015</TD><TD>MFA</TD><TD>Initialisation APIExceptionEnum</TD></TR>
 * <TR><TD>19/01/2016</TD><TD>KWE</TD><TD>Ajout APIExceptionEnum</TD></TR>
 * <TR><TD>07/03/2016</TD><TD>FCV</TD><TD>Modification libell�s codes erreurs</TD></TR>
 * <TR><TD>09/11/2016</TD><TD>FCV</TD><TD>Ajout de nouveaux codes erreurs (adresse et client)</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * <TR><TD>03/05/2018</TD><TD>AJO</TD><TD>API GET Vador</TD></TR>
 * </TABLE>
 **/
public enum APIExceptionEnum {

    serviceordernotfound(1, 404, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "La commande n'a pas �t� trouv�e avec l'id: %s"),
    serviceorderabortmalformed(2, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "Les informations n�cessaires � l'abandon ne sont pas renseign�es"),
    serviceorderisnotinprogress(3, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "La commande id: %s n'est pas � l'�tat en cours"),
    serviceordernotfoundeventcause(4, 422, "El�ment introuvable", "Le ServiceOrder fourni d'id: %s n'a pas de cause �v�nement"),
    serviceorderabandonerror(5, 403, "service introuvable ou non disponible", "service introuvable ou non disponible lors de l'abandon de la commande d'id: %s"),
    serviceorderandtasknotlinked(6, 422, "service introuvable ou non disponible", "Il n'existe pas de tache associ�e � la commande d'id: %s"),
    serviceorderandprocessnotlinked(7, 422, "service introuvable ou non disponible", "Il n'existe pas de process associ� � la commande d'id: %s"),
    serviceorderappointmentidandexternalidnull(8, 400, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "L'appointmentId ainsi que l'externalId ne sont pas renseign�s"),
    serviceordernotfoundwithappointmentid(9, 422, "El�ment introuvable", "L'id Intervention  %s n'a pas de commande associ�e"),
    serviceordernotfoundwithexternalid(10, 422, "El�ment introuvable", "L'id externe %s n'a pas de commande associ�e"),
    serviceorderappointmentandexternalnull(11, 422, "El�ment introuvable", "Il n'existe pas de commande associ�e � l'external id %s et � l'intervention id %s"),
    serviceorderidandidcommandenotlinked(12, 400, "Erreur de composition de la requ�te", "L'id %s de la commande n'est pas �gal � celui de l'id %s du corps de la requ�te"),
    serviceorderidnull(13, 400, "Erreur de composition de la requ�te", "L'id de la commande n'existe pas"),
    serviceorderbadstatus(14, 400, "Erreur de composition de la requ�te", "L'�tat fourni de la commande est incorrect"),
    serviceordercausenotallowed(15, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "La cause abandon renseign�e ne fait pas partie des causes abandon autoris�es"),
    serviceorderalreadyreserved(16, 422, "El�ment introuvable", "La commande d'id %s ne peut �tre modifi�e car elle est d�j� verrouill�e par un utilisateur � l'IHM"),
    serviceorderabandonrefusegpc(17, 422, "Abandon interdit", "Abandon interdit : Lib�ration de l'intervention refus�e par GPC"),
    serviceorderabandoninterditinterventionterminee(18, 422, "Abandon interdit", "Abandon interdit : Commande avec intervention r�alis�e et termin�e"),
    appointmentidnotfound(100, 404, "El�ment introuvable", "Le RDV fourni d'id: %s n'existe pas"),
    appointmentorderidnotfound(101, 404, "El�ment introuvable", "La commande fournie d'id: %s n'existe pas"),
    appointmentorderandrdvnotlinked(102, 422, "El�ment introuvable", "L'intervention d'id %s n'est pas associ�e � la commande d'id: %s"),
    appointmenterrorcancelling(103, 422, "El�ment introuvable", "Impossible de lib�rer l'intervention d'id %s."),
    appointmentbadstateintervention(104, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "L'intervention d'id: %s est d�j� en statut annul�"),
    appointmentidandidinternotlinked(105, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "L'intervention d'id: %s et l'id renseign�e ne sont pas identiques"),
    appointmentdoesnotexist(106, 400, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "Il n'y a pas d'intervention fournie"),
    appointmentnotfound(107, 404, "El�ment introuvable", "L'intervention d'id: %s n'existe pas"),
    appointmentalreadyreserved(108, 422, "El�ment introuvable", "L'intervention d'id %s ne peut �tre modifi�e car elle est d�j� verrouill�e par un utilisateur � l'IHM"),
    appointmentbadstatus(109, 400, "Erreur de composition de la requ�te", "L'�tat fourni de l'intervention est incorrect"),
    noteidnotfound(200, 404, "El�ment introuvable", "La note fournie d'id: %s n'existe pas"),
    noteorderidnotfound(201, 400, "El�ment introuvable", "L'id de la commande n'a pas �t� fourni"),
    noteandordernotlinked(202, 422, "El�ment introuvable", "La note d'id %s n'est pas associ�e � la commande d'id: %s"),
    notecommentnull(203, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "La note d'id %s ne contient pas de commentaires"),
    notenotoldest(204, 403, "El�ment introuvable", "Il est interdit de modifier cette note"),
    noteerrorcreating(205, 422, "Erreur pendant la cr�ation de la note", "Impossible de creer la note d'id %s "),
    noteerrorupdating(206, 422, "Erreur pendant la modification de la note", "Impossible de modifier la note d'id %s"),
    noteerrorvalidating(207, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "Le commentaire de la note est trop long"),
    notenotfound(208, 404, "El�ment introuvable", "La note d'id %s n'existe pas"),
    notealreadyexists(209, 422, "Erreur pendant la cr�ation de la note", "Impossible de cr�er la note car un id a �t� renseign� "),
    noteorderdosnotexists(210, 422, "El�ment introuvable", "La commande d'id %s n'existe pas"),
    notebadstatus(211, 400, "Erreur de composition de la requ�te", "L'�tat fourni de la note est incorrect"),
    taskidnotfound(300, 400, "El�ment introuvable", "L'id de la t�che n'est pas fourni"),
    taskorderidnotfound(301, 400, "El�ment introuvable", "L'id de la commande n'est pas fourni"),
    taskidandorderidnotlinked(302, 422, "El�ment introuvable", "La t�che d'id %s n'est pas associ�e � la commande d'id: %s"),
    taskeventnull(303, 422, "El�ment introuvable", "La t�che d'id %s n'a pas d'�v�nement"),
    taskcauseeventnull(304, 422, "El�ment introuvable", "L'�v�nement de la t�che d'id %s n'a pas de cause �v�nement"),
    taskeventcauserefnull(305, 400, "El�ment introuvable", "L'�v�nement de la t�che d'id %s n'est pas renseign�"),
    taskeventcauserefidnull(306, 400, "El�ment introuvable", "L'id de l'EventCauseRef n'est pas renseign�"),
    taskcausenotpossible(308, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "Il n'est pas possible de cl�turer la t�che d'id %s avec la cause �v�nement d'id %s"),
    taskalreadyreserved(309, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "Il n'est pas possible de cl�turer la t�che d'id %s car d�j� r�serv�e par un autre utilisateur"),
    taskwkfactivitynull(310, 422, "El�ment introuvable", "Impossible de r�cup�rer les informations relatives � la t�che"),
    taskcloseexception(311, 422, "Erreur pendant la cl�ture de t�che", "Erreur pendant la cl�ture de t�che d'id: %s"),
    taskidorderandorderidnotlinked(313, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)", "La commande d'id: %s et la commande obtenue de la t�che renseign�e ne sont pas identiques"),
    tasknotfound(314, 404, "El�ment introuvable", "La tache d'id: %s n'existe pas"),
    taskrolenotreassignable(315, 422, "Erreur lors du changement de r�le", "Le r�le choisi n'est pas autoris�"),
    tasklisteventcausenull(316, 422, "El�ment introuvable", "La tache d'id: %s n'a pas de causes �v�nements possibles pour cloturer"),
    tasknotstatusfinished(317, 422, "Information erronn�e", "Le statut de la t�che fournie dans le body n'est pas � FINISHED"),
    tasknotcausereassignable(318, 422, "Erreur lors du changement de r�le", "La valeur constante de la cause �v�nement est diff�rente de REASSIGNAVP"),
    tasknotreassignable(319, 422, "Erreur lors du changement de r�le", "Erreur lors de la reassignation"),
    taskstatusnull(320, 400, "Erreur lors de l'acc�s � la t�che", "Le statut de la t�che n'a pas �t� renseign�"),
    tasknotinprogress(321, 422, "Erreur lors de l'acc�s � la t�che", "Il n'existe pas de t�che en cours avec cet id"),
    tasklisteventnotwkfactivity(322, 422, "Erreur lors de l'acc�s au workflow", "Il n'existe pas de workflow avec la tache d'id"),
    taskbadstatus(323, 400, "Erreur de composition de la requ�te", "L'�tat fourni de la t�che est incorrect"),
    taskbaddate(324, 400, "Erreur de composition de la requ�te", "La date fournie de cl�ture de t�che n'est pas au bon format"),
    taskdatenotfound(325, 400, "Erreur de composition de la requ�te", "Il est obligatoire de fournir une date pour cette cause de cl�ture"),
    taskdatetoosoon(326, 422, "Erreur de composition de la requ�te", "La date fournie pour la cl�ture de t�che doit �tre au plus t�t � la date du jour"),
	taskerrorvalidating(327, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)","Le champ %s de la t�che est trop long : la taille maximale pour ce champ est %s caract�res"),
    customeridnotfound(500, 404, "El�ment introuvable", "Le client fourni d'id: %s n'existe pas"),
    customerandordernotlinked(501, 422, "Erreur de composition de la requ�te", "Le client fourni d'id %s n'est pas associ� � la commande d'id %s"),
    customerandaddressnotlinked(502, 422, "Erreur de composition de la requ�te", "Le client fourni d'id %s n'est pas associ� � l'adresse d'id %s"),
    addressidnotfound(600, 404, "El�ment introuvable", "L'adresse fournie d'id: %s n'existe pas"),
    addressalreadyreserved(603, 422, "Erreur de composition de la requ�te", "L'adresse d'id %s ne peut �tre modifi�e car elle est d�j� verrouill�e par un utilisateur � l'IHM"),
    addresserrorvalidating(604, 422, "Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s)","Le champ %s de l'adresse est trop long : la taille maximale pour ce champ est %s caract�res"),
    addresserrorupdating(605, 422, "Erreur pendant la modification de l'adresse", "Impossible de modifier l'adresse d'id %s"),
    partenairenotfound(700, 400, "El�ment introuvable", "Le partenaire d'id: %s n'existe pas"),
    unauthorized(10000, 401, "Error authentication", "Error authentication"),
    generic400(10002, 400, "Requ�te invalide", "La syntaxe de la requ�te est erron�e"),
    generic404(10006, 404, "Non trouv�", "Ressource non trouv�e"),
    generic405(10003, 405, "M�thode non autoris�e", "M�thode de requ�te non autoris�e"),
    generic406(10004, 406, "Format non acceptable", "La ressource demand�e n'est pas disponible dans un format qui respecterait les en-t�tes \"Accept\" de la requ�te"),
    generic415(10005, 415, "Format de requ�te non support�", "Format de requ�te non support� pour une m�thode et une ressource donn�es"),
    generic500(11000, 500, "Erreur Interne", "Erreur interne du serveur"),
    generic503(10001, 503, "Service temporairement indisponible", "Service temporairement indisponible ou en maintenance"),
    generic600(10007, 400, "Erreur de composition de la requ�te", "Erreur dans le corps de requ�te: pr�sence d'un �l�ment sans valeur"),
    generic700(10008, 503, "Service temporairement indisponible", "Erreur d'acc�s concurrent : l'objet ne peut �tre modifi� car il est d�j� verrouill�");

	private final int codeHttp;
	private final int codeFonc;
	private final String message;
	private final String templateDescription;

	/**
	 * APIExceptionEnum Constructor
	 * 
	 * @param codeHttp
	 * @param code
	 * @param message
	 * @param templateDescription
	 * @param infoURL
	 */
	private APIExceptionEnum(final int codeFonc, final int codeHttp, final String message, final String templateDescription) {
		this.codeFonc = codeFonc;
		this.codeHttp = codeHttp;
		this.message = message;
		this.templateDescription = templateDescription;
	}

	/**
	 * createAPIException
	 * Permet de cr�er l'APIException avec la r�ponse et l'erreur initialis�es
	 * 
	 * @param params
	 * @return
	 */
	public APIException createAPIException(Object... params) {
		final Response reponse = createAPIErrorResponse(params);
		return new APIException(reponse);
	}

	/**
	 * createAPIErrorResponse
	 * Permet de cr�er la r�ponse associ�e � l'erreur REST obtenue.
	 * 
	 * @param params
	 * @return
	 */
	private Response createAPIErrorResponse(Object... params) {
		APIError aPIError = buildApiError(params);
		return Response.status(codeHttp).entity(aPIError).build();
	}

	/**
	 * buildApiError
	 * Construction de l'APIError avec les motifs de l'erreur REST.
	 * 
	 * @param params
	 * @return
	 */
	private APIError buildApiError(Object... params) {
		APIError aPIError = new APIError();

		aPIError.setCode(codeFonc);

		if (StringUtils.isNotBlank(message)) {
			aPIError.setMessage(message);
		}

		if (StringUtils.isNotBlank(templateDescription)) {
			aPIError.setDescription(String.format(templateDescription, params));
		}

		return aPIError;
	}

	public static APIException createGenericApiException(final int httpCode) {
		final APIExceptionEnum apiExceptionEnum;
		try {
			apiExceptionEnum = valueOf(String.format("generic%s", Integer.toString(httpCode)));
		} catch (IllegalArgumentException e) {
			return null;
		}
		return apiExceptionEnum.createAPIException();
	}

}
