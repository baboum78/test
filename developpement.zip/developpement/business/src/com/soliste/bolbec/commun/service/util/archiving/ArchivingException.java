/**
 * 
 */
package com.soliste.bolbec.commun.service.util.archiving;

/**
 * Exception remont�e lors d'un archivage
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public class ArchivingException extends Exception {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = -8704691335212551484L;

	/**
	 * Constructeur par d�faut
	 */
	public ArchivingException() {
	}

	/**
	 * @param message
	 */
	public ArchivingException(String message) {
		super(message);
	}

	/**
	 * @param cause
	 */
	public ArchivingException(Throwable cause) {
		super(cause);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public ArchivingException(String message, Throwable cause) {
		super(message, cause);
	}

}
