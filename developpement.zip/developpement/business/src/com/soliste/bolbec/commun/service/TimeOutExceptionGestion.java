package com.soliste.bolbec.commun.service;

import org.apache.commons.configuration.PropertiesConfiguration;
import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.endpoint.Client;
import org.apache.cxf.jaxrs.client.WebClient;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;

import com.soliste.bolbec.commun.service.util.log.LoggerManager;
import com.soliste.bolbec.fwk.util.PropertiesUtils;

/**
 * Classe de gestion des timeouts pour API et WebServices
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>01/03/2017</TD><TD>JDE</TD><TD>EV-000282 : Timeouts WebServices</TD></TR>
 * </TABLE>
 */
public class TimeOutExceptionGestion {

	private static final String CLASS_NAME = TimeOutExceptionGestion.class.getName();

	private static final String WEBSERVICES_CONFIG_FILE = "WebServices.properties";

	private static final String CLE_TIMEOUT_CONNECTION = "TIMEOUT_CONNECTION_";
	private static final String CLE_TIMEOUT_RECEPTION = "TIMEOUT_RECEPTION_";

	/**
	 * M�thode pour la mise en place des timeouts sur un objet Client
	 * 
	 * @param client
	 * @param nomService
	 */
	public static void setTimeOutPolicy(Client client, String nomService) {
		setTimeOutPolicy((HTTPConduit) client.getConduit(), nomService);
	}

	/**
	 * M�thode pour la mise en place des timeouts sur un objet WebClient
	 * 
	 * @param webClient
	 * @param nomService
	 */
	public static void setTimeOutPolicy(WebClient webClient, String nomService) {
		setTimeOutPolicy(WebClient.getConfig(webClient).getHttpConduit(), nomService);
	}

	/**
	 * M�thode pour la mise en place des timeouts sur un objet HTTPConduit
	 * 
	 * @param httpConduit
	 * @param nomService
	 */
	private static void setTimeOutPolicy(HTTPConduit httpConduit, String nomService) {
		setTimeOutPolicy(httpConduit.getClient(), nomService);
	}

	/**
	 * M�thode pour la mise en place des timeouts sur un objet HTTPClientPolicy
	 * 
	 * @param clientPolicy
	 * @param nomService
	 */
	private static void setTimeOutPolicy(HTTPClientPolicy clientPolicy, String nomService) {
		final String method = "setTimeOutPolicy";

		PropertiesConfiguration config = PropertiesUtils.getConfig(WEBSERVICES_CONFIG_FILE);
		String connectionTimeOut = config.getString(CLE_TIMEOUT_CONNECTION + nomService);
		String receptionTimeout = config.getString(CLE_TIMEOUT_RECEPTION + nomService);

		if (StringUtils.isBlank(connectionTimeOut)) {
			LoggerManager.getInstance().info(CLASS_NAME, method, "Configuration " + CLE_TIMEOUT_CONNECTION + nomService + " non trouv� : pas de timeout configur�");
		} else {
			clientPolicy.setConnectionTimeout(Long.parseLong(connectionTimeOut));
		}

		if (StringUtils.isBlank(receptionTimeout)) {
			LoggerManager.getInstance().info(CLASS_NAME, method, "Configuration " + CLE_TIMEOUT_RECEPTION + nomService + " non trouv� : pas de timeout configur�");
		} else {
			clientPolicy.setReceiveTimeout(Long.parseLong(receptionTimeout));
		}
	}

}
