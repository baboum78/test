package com.soliste.bolbec.commun.service.exception.sw.customerorder;

/**
 * <BR>
 * <B>HISTORIQUE DES MODIFICATIONS:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/07/2012</TD><TD>BPE</TD><TD>EV-000188: Am�lioration du m�canisme d'exceptions pour Grafic</TD></TR>
 * </TABLE>
 * <BR>
 */
public enum GraficTypeFaultEnum {
	MessageMalFormate("Message mal format�", "001"), ChampObligatoireAbsent("Champ obligatoire absent", "002"), ParametresInvalides("Param�tres invalides", "003"), ErreurTraduction("Erreur de traduction Art�mis", "004"), AbandonInterdit(
			"Abandon interdit", "005"), ErreurLocalisation("Erreur Localisation", "006"), ImpossibiliteTemporaire("Impossibilite temporaire", "007"), CommandeRegroupee("Abandon interdit", "008"), ErreurInterne("Erreur Interne", "999");

	private String label;
	private String codeErreur;

	/**
	 * @param label
	 * @param codeErreur
	 */
	GraficTypeFaultEnum(final String label, final String codeErreur) {
		this.label = label;
		this.codeErreur = codeErreur;
	}

	public String getLabel() {
		return label;
	}

	public String getCodeErreur() {
		return codeErreur;
	}

}
