package com.soliste.bolbec.commun.service.exception.sw.customerorder;

import java.util.Collection;

import com.orange.bolbec.customerOrder.types.fault.CustomerOrderFault;
import com.orange.bolbec.customerOrder.types.fault.FaultDetail;

/**
 * <BR>
 * <B>HISTORIQUE DES MODIFICATIONS:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/07/2012</TD><TD>BPE</TD><TD>EV-000188: Am�lioration du m�canisme d'exceptions pour Grafic</TD></TR>
 * <TR><TD>12/02/2013</TD><TD>EBA</TD><TD>G8R1C2 - EV-000210: Suppression de la stacktrace et log</TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * </TABLE>
 * <BR>
 */
public class ConstructeurGraficException {

	/**
	 * Permet de construire une exception customerOrder (Grafic)
	 * 
	 * @param exceptionClass la classe de l'exception � g�n�rer
	 * @param graficTypeFaultEnum le type de la fault
	 * @param labelErreur le label erreur
	 * @return l'exception correctement construit
	 */
	public CustomerOrderFault contruireCustomerException(Class<? extends CustomerOrderFault> exceptionClass, GraficTypeFaultEnum graficTypeFaultEnum, String labelErreur) {
		CustomerOrderFault exception;
		try {
			exception = exceptionClass.newInstance();
		} catch (InstantiationException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		}
		final FaultDetail faultDetail = new FaultDetail();

		faultDetail.getLocalErrorLabel().add(labelErreur);

		faultDetail.getLocalErrorCode().add(graficTypeFaultEnum.getCodeErreur());

		exception.getFaultDetail().add(faultDetail);

		exception.setFaultLabel(graficTypeFaultEnum.getLabel());

		return exception;
	}

	/**
	 * Permet de construire une exception customerOrder (Grafic)
	 * 
	 * @param exceptionClass la classe de l'exception � g�n�rer
	 * @param label le label
	 * @param faultDetailList le champ faultDetail
	 * @return l'exception correctement construit
	 */
	public CustomerOrderFault contruireCustomerException(Class<? extends CustomerOrderFault> exceptionClass, String label, Collection<? extends FaultDetail> faultDetailList) {
		CustomerOrderFault exception;
		try {
			exception = exceptionClass.newInstance();
		} catch (InstantiationException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		}

		exception.getFaultDetail().addAll(faultDetailList);
		exception.setFaultLabel(label);
		// exception.setFaultString(label);

		return exception;
	}
}
