/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

import com.soliste.bolbec.commun.service.util.log.LoggerManager;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;


/**
 * Class de d�finition pour un niveau de Rollback
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/01/2021</TD><TD>SOP</TD><TD>Initialisation pour Camunda</TD></TR>
 * </TABLE><BR>
 */
public class RollbackLevel {
	private static final String CLASS_NAME = RollbackLevel.class.getName();

	// DEFAULT GREEN LEVEL
	public static final String DEFAULT_GREEN_LEVEL_MESSAGE = "Alerte verte";
	public static final long DEFAULT_GREEN_LEVEL_SLEEP_TIME = 5000L;
	public static final int DEFAULT_GREEN_LEVEL_THRESHOLD = 0;
	public static final RollbackLevel DEFAULT_GREEN_LEVEL = new RollbackLevel(DEFAULT_GREEN_LEVEL_MESSAGE, DEFAULT_GREEN_LEVEL_THRESHOLD, DEFAULT_GREEN_LEVEL_SLEEP_TIME);

	// DEFAULT YELLOW LEVEL
	public static final String DEFAULT_YELLOW_LEVEL_MESSAGE = "Alerte jaune";
	public static final long DEFAULT_YELLOW_LEVEL_SLEEP_TIME = 60000L;
	public static final int DEFAULT_YELLOW_LEVEL_THRESHOLD = 10;
	public static final RollbackLevel DEFAULT_YELLOW_LEVEL = new RollbackLevel(DEFAULT_YELLOW_LEVEL_MESSAGE, DEFAULT_YELLOW_LEVEL_THRESHOLD, DEFAULT_YELLOW_LEVEL_SLEEP_TIME);

	// DEFAULT RED LEVEL
	public static final String DEFAULT_RED_LEVEL_MESSAGE = "Alerte rouge";
	public static final long DEFAULT_RED_LEVEL_SLEEP_TIME = 60000L;
	public static final int DEFAULT_RED_LEVEL_THRESHOLD = 20;
	public static final RollbackLevel DEFAULT_RED_LEVEL = new RollbackLevel(DEFAULT_RED_LEVEL_MESSAGE, DEFAULT_RED_LEVEL_THRESHOLD, DEFAULT_RED_LEVEL_SLEEP_TIME);

	// DEFAULT BLACK LEVEL
	public static final String DEFAULT_BLACK_LEVEL_MESSAGE = "Alerte noire";
	public static final long DEFAULT_BLACK_LEVEL_SLEEP_TIME = 60000L;
	public static final int DEFAULT_BLACK_LEVEL_THRESHOLD = 50;
	public static final RollbackLevel DEFAULT_BLACK_LEVEL = new RollbackLevel(DEFAULT_BLACK_LEVEL_MESSAGE, DEFAULT_BLACK_LEVEL_THRESHOLD, DEFAULT_BLACK_LEVEL_SLEEP_TIME);

	// DEFAULT DISCARD LEVEL
	public static final String DEFAULT_DISCARD_LEVEL_MESSAGE = "Discard";
	public static final long DEFAULT_DISCARD_LEVEL_SLEEP_TIME = 0L;
	public static final int DEFAULT_DISCARD_LEVEL_THRESHOLD = 65;
	public static final RollbackLevel DEFAULT_DISCARD_LEVEL = new RollbackLevel(DEFAULT_DISCARD_LEVEL_MESSAGE, DEFAULT_DISCARD_LEVEL_THRESHOLD, DEFAULT_DISCARD_LEVEL_SLEEP_TIME);

	/**
	 * Level nom (default: vert, jaune, rouge, noire, discard)
	 */
	private final String name;

	/**
	 * Level seuil
	 */
	private final int threshold;

	/**
	 * Level Temps d'attente avant la prochaine it�ration
	 */
	private final long sleepTime;

	/**
	 * Level indicateur pour les niveaux qui comportent le rejet du message.
	 */
	private final boolean discard;

	/**
	 * Constructeur du RollbackLevel
	 * @param name Le nom du niveau
	 * @param threshold Le seuil du niveau
	 * @param sleepTime Le temps d'attente du niveau
	 * @param discard true si le niveau est un niveau de rejet
	 */
	public RollbackLevel(String name, int threshold, long sleepTime, boolean discard) {
		this.name = name;
		this.threshold = threshold;
		this.sleepTime = sleepTime;
		this.discard = discard;
	}

	/**
	 * Constructeur du RollbackLevel (discard=false)
	 * @param name Le nom du niveau
	 * @param threshold Le seuil du niveau
	 * @param sleepTime Le temps d'attente du niveau
	 */
	public RollbackLevel(String name, int threshold, long sleepTime) {
		this( name, threshold, sleepTime, false);
	}

	public String getName() {
		return name;
	}

	public int getThreshold() {
		return threshold;
	}

	public long getSleepTime() {
		return sleepTime;
	}

	public boolean isDiscard() {
		return discard;
	}

	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.DEFAULT_STYLE);
	}


	public static RollbackLevel[] generateRollbackLevels(int iMaxRepublicationCount , double[] levelRatioThreshold , long[] levelRatioSleep) {
		final String methodName = "generateRollbackLevels";
		// Validation des param�tres
		if ( iMaxRepublicationCount <= 0 ) {
			LoggerManager.getInstance().severe(CLASS_NAME, methodName, "Le nombre de republications doit �tre � minima 1.");
			return null;
		}
		if ( levelRatioThreshold == null || levelRatioThreshold.length == 0 ) {
			LoggerManager.getInstance().severe(CLASS_NAME, methodName, "La liste propos� de threshold doit contenir au minima une valeur.");
			return null;
		}
		if ( levelRatioSleep == null || levelRatioSleep.length == 0 ) {
			LoggerManager.getInstance().severe(CLASS_NAME, methodName, "La liste propos� de sleep doit contenir au minima une valeur.");
			return null;
		}
		if ( levelRatioThreshold.length != levelRatioSleep.length ) {
			LoggerManager.getInstance().severe(CLASS_NAME, methodName, "La liste propos� de threshold et la liste de sleep doivent avoir la m�me longueur.");
			return null;
		}

		// Initialisation des niveaux du RollbackHandler avec des seuils en fonction du nombre de republications.
		// Si deux niveaux utilisent le m�me seuil, on utilise le plus grave
		int iLastLevelThreshold = iMaxRepublicationCount;
		List<RollbackLevel> lstRollbackLevel = new ArrayList<RollbackLevel>();
		for ( int iLevel = levelRatioThreshold.length-1; iLevel>=0 ; iLevel--) {
			int iLevelThreshold = (int) Math.floor(levelRatioThreshold[iLevel] * iMaxRepublicationCount);
			if ( iLevelThreshold != iLastLevelThreshold) {
				String levelName = "<<Level [" + iLevelThreshold + ", " +iLastLevelThreshold + ") sur " + iMaxRepublicationCount + ">>";
				RollbackLevel rollbackLevel = new RollbackLevel(levelName, iLevelThreshold, levelRatioSleep[iLevel]);
				lstRollbackLevel.add(rollbackLevel);
				iLastLevelThreshold = iLevelThreshold;
			}
		}
		Collections.reverse(lstRollbackLevel);
		return lstRollbackLevel.toArray(new RollbackLevel[0]);
	}
}