/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.pagination;

import java.io.Serializable;
import java.util.List;

import com.soliste.bolbec.commun.service.util.sort.Direction;

/**
 * Classe contenant une sous-liste (page) d'une liste compl�te.
 * 
 * @author rgvs7490
 */
public class PaginatedList<T> implements Serializable {

	/**
	 * La sous-liste d'objets � afficher
	 */
	private List<T> list;
	/**
	 * Le nombre (maximal) d'objets par page
	 */
	private int objectsPerPage;
	/**
	 * Le num�ro de la page correspondant � la sous-liste. Les num�ros
	 * commencent � 1.
	 */
	private int pageNumber;
	/**
	 * Le crit�re de tri
	 */
	private String sortCriterion;
	/**
	 * La direction du tri
	 */
	private Direction sortDirection;
	/**
	 * Le nombre total d'objets dans la liste compl�te
	 */
	private int totalObjectCount;

	/**
	 * Constructeur
	 * 
	 * @param list
	 * la sous-liste courante
	 * @param pageNumber
	 * le num�ro de la page courante
	 * @param objectsPerPage
	 * le nombre (maximal) d'objets par page
	 * @param totalObjectCount
	 * le nombre total d'objets dans la liste compl�te
	 * @param sortCriterion
	 * le crit�re de tri ayant �t� utilis� pour obtenir cette liste
	 * @param sortDirection
	 * la direction de tri ayant �t� utilis�e pour obtenir cette
	 * liste
	 */
	public PaginatedList(List<T> list, int pageNumber, int objectsPerPage, int totalObjectCount, String sortCriterion, Direction sortDirection) {
		this.list = list;
		this.pageNumber = pageNumber;
		this.objectsPerPage = objectsPerPage;
		this.totalObjectCount = totalObjectCount;
		this.sortCriterion = sortCriterion;
		this.sortDirection = sortDirection;
	}

	/**
	 * Retourne l'index (� partir de 0) du premier objet de cette sous-liste
	 * dans la liste compl�te
	 * 
	 * @return l'index (� partir de 0) du premier objet de cette sous-liste dans
	 * la liste compl�te
	 */
	public int getFirstIndex() {
		return (getPageNumber() - 1) * getObjectsPerPage();
	}

	/**
	 * Retourne l'index (� partir de 0) du dernier objet de cette sous-liste
	 * dans la liste compl�te
	 * 
	 * @return l'index (� partir de 0) du dernier objet de cette sous-liste dans
	 * la liste compl�te
	 */
	public int getLastIndex() {
		return getFirstIndex() + getSize() - 1;
	}

	/**
	 * Retourne la sous-liste courante
	 * 
	 * @return la sous-liste courante
	 */
	public List<T> getList() {
		return list;
	}

	/**
	 * Retourne le nombre (maximal) d'objets par page
	 * 
	 * @return le nombre (maximal) d'objets par page
	 */
	public int getObjectsPerPage() {
		return objectsPerPage;
	}

	/**
	 * Retourne le nombre de pages
	 * 
	 * @return le nombre de pages
	 */
	public int getPageCount() {
		int pageCount = totalObjectCount / objectsPerPage;
		if ((totalObjectCount % objectsPerPage) > 0) {
			pageCount++;
		}
		return pageCount;
	}

	/**
	 * Retourne le num�ro de la page courante (� partir de 1)
	 * 
	 * @return le num�ro de la page courante
	 */
	public int getPageNumber() {
		return pageNumber;
	}

	/**
	 * Retourne le nombre d'objets dans la page courante
	 * 
	 * @return le nombre d'objets dans la page courante
	 */
	public int getSize() {
		return list.size();
	}

	/**
	 * Retourne le crit�re de tri
	 * 
	 * @return le crit�re de tri
	 */
	public String getSortCriterion() {
		return sortCriterion;
	}

	/**
	 * Retourne la direction du tri
	 * 
	 * @return la direction du tri
	 */
	public Direction getSortDirection() {
		return sortDirection;
	}

	/**
	 * Retourne le nombre total d'objets dans la liste compl�te
	 * 
	 * @return le nombre total d'objets dans la liste compl�te
	 */
	public int getTotalObjectCount() {
		return totalObjectCount;
	}

	/**
	 * Retourne <code>true</code> le nombre total d'objets dans la liste
	 * compl�te est �gal � 0 (z�ro) sinon <code>false</code>
	 * 
	 * @return <code>true</code> le nombre total d'objets dans la liste
	 * compl�te est �gal � 0 (z�ro) sinon <code>false</code>
	 */
	public boolean isEmpty() {
		return totalObjectCount == 0;
	}

	/**
	 * D�termine s'il existe une page suivante
	 * 
	 * @return true s'il existe une page suivante, sinon false
	 */
	public boolean isNextPageAvailable() {
		return (pageNumber < getPageCount());
	}

	/**
	 * D�termine s'il existe une page pr�c�dente
	 * 
	 * @return true s'il existe une page pr�c�dente, sinon false
	 */
	public boolean isPreviousPageAvailable() {
		return (pageNumber > 1);
	}
}