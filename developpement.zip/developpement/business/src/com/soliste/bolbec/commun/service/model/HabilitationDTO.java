package com.soliste.bolbec.commun.service.model;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.Habilitation;
import aps.RoleHabilitation;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * HabilitationDTO fait partie de l'espace de r�f�rence
 */
public class HabilitationDTO implements java.io.Serializable {

	private String id;
	private String application;
	private String servlet;
	private List<RoleDTO> roles = new ArrayList<RoleDTO>();

	/**
	 * 
	 * @param id
	 */
	public HabilitationDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public HabilitationDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(Habilitation.FIELD_ID);
		this.application = (String) ep.getValue(Habilitation.FIELD_APPLICATION);
		this.servlet = (String) ep.getValue(Habilitation.FIELD_SERVLET);
		@SuppressWarnings("unchecked")
		List<EntityProxy> habilitationRoles = ep.getLinkedObjects(Habilitation.MLINK_POUR_ROLE);
		for (EntityProxy habilitationRole : habilitationRoles) {
			EntityProxy role = (EntityProxy) habilitationRole.getLinkedObject(RoleHabilitation.SLINK_POUR_ROLE);
			RoleDTO roleDTO = new RoleDTO(role);
			roles.add(roleDTO);
		}
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public String getApplication() {
		return application;
	}

	public String getServlet() {
		return servlet;
	}

	public List<RoleDTO> getRoles() {
		return roles;
	}

}
