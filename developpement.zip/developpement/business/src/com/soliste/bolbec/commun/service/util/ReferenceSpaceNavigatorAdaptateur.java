package com.soliste.bolbec.commun.service.util;

import java.lang.reflect.Constructor;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import aps.Agent;
import aps.Habilitation;

import com.soliste.aps.foundation.ejb.EntityProxy;
import com.soliste.aps.foundation.ejb.conditions.ValueComparatorCondition;
import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.HabilitationDTO;
import com.soliste.bolbec.commun.service.util.fondation.ReferenceSpaceNavigator;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>09/08/2010</TD><TD>YTR</TD><TD>Refactor generation manager</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>23/10/2013</TD><TD>EBA</TD><TD>G9R0C1 : Corrections sonar</TD></TR>
 * </TABLE>
 * Classe adaptant le <code>com.soliste.bolbec.commun.service.util.fondation.ReferenceSpaceNavigator</code> au model d'�change
 */
public class ReferenceSpaceNavigatorAdaptateur {

	private static final String CLASS_NAME = ReferenceSpaceNavigatorAdaptateur.class.getName();

	/** The Constant entityBeanToPojo. */
	private static final Map<Class<?>, Class<?>> entityBeanToPojo = getEntityBeanToPojo();

	/**
	 * Retrouve un DTO dans l'espace de r�f�rence � partir de son <code>id</code>.
	 * 
	 * @param classDTO the class dto
	 * @param id the id
	 * 
	 * @return the T
	 */
	public static <T> T findInReferenceSpace(Class<T> classDTO, String id) {
		if (id == null || classDTO == null) {
			return null;
		}
		if (entityBeanToPojo.containsKey(classDTO)) {
			Class<?> classFoundation = entityBeanToPojo.get(classDTO);
			EntityProxy entityProxy = ReferenceSpaceNavigator.findInReferenceSpace(classFoundation, id);
			return instanciateDTO(classDTO, entityProxy);
		}
		return null;
	}

	/**
	 * Retrouve dans l'espace de r�f�rence une liste DTO de type <code>classDTO</code>
	 * r�pondant aux crit�res pass�s en param�tres, tel que :
	 * valeur du champ field1 <code>operator</code> value1 <p>
	 * C'est l'equivalent de la requete :<br>
	 * "select * from class where (classDTO.field1 <code>operator</code> value1);"
	 * 
	 * @param classDTO the class dto
	 * @param field1 the field1
	 * @param value1 the value1
	 * @param operator the operator
	 * 
	 * @return the list< t>
	 */
	public static <T> List<T> listInReferenceSpace(Class<T> classDTO, String field1, String value1, String operator) {
		if (classDTO == null) {
			return new ArrayList<T>();
		}
		if (entityBeanToPojo.containsKey(classDTO)) {
			Class<?> classFoundation = entityBeanToPojo.get(classDTO);
			List<EntityProxy> entityProxies = ReferenceSpaceNavigator.listInReferenceSpace(classFoundation, new ValueComparatorCondition(field1, operator, value1));
			if (entityProxies != null) {
				List<T> listDTO = new ArrayList<T>(entityProxies.size());
				for (Iterator<EntityProxy> iterator = entityProxies.iterator(); iterator.hasNext();) {
					EntityProxy entityProxy = iterator.next();
					T objDTO = instanciateDTO(classDTO, entityProxy);
					listDTO.add(objDTO);
				}
				return listDTO;
			}
			return new ArrayList<T>();
		}
		return new ArrayList<T>();
	}

	/**
	 * Retrouve dans l'espace de r�f�rence une liste DTO de type <code>classDTO</code>
	 * r�pondant aux crit�res pass�s en param�tres, tel que :
	 * valeur du champ field1 = value1 <p>
	 * C'est l'equivalent de la requete :<br>
	 * "select * from class where (classDTO.field1 = value1);"
	 * 
	 * @param classDTO the class dto
	 * @param field1 the field1
	 * @param value1 the value1
	 * 
	 * @return the list< t>
	 */
	public static <T> List<T> listInReferenceSpace(Class<T> classDTO, String field1, String value1) {
		return listInReferenceSpace(classDTO, field1, value1, Constantes.OPERATOR_EQUAL);
	}

	/**
	 * Instantie une classe DTO.
	 * 
	 * @param classDTO the class dto
	 * @param entityProxy the entity proxy
	 * 
	 * @return the T
	 */
	private static <T> T instanciateDTO(Class<T> classDTO, EntityProxy entityProxy) {
		LoggerManager.getInstance().finest(CLASS_NAME, "instanciateDTO", "classDTO = " + classDTO + " ,entityProxy = " + entityProxy);
		if (entityProxy == null) {
			return null;
		}
		Class<?>[] types = { EntityProxy.class };
		Object[] values = { entityProxy };
		try {
			Constructor<T> constructor = classDTO.getConstructor(types);
			return constructor.newInstance(values);
		} catch (Exception t) {
			LoggerManager.getInstance().warning(CLASS_NAME, "instanciateDTO", "Exception = " + t);
			return null;
		}
	}

	/**
	 * Gets the entity bean to pojo.
	 * 
	 * @return the entity bean to pojo
	 */
	private static Map<Class<?>, Class<?>> getEntityBeanToPojo() {
		Map<Class<?>, Class<?>> map = new HashMap<Class<?>, Class<?>>();
		map.put(AgentDTO.class, Agent.class);
		map.put(HabilitationDTO.class, Habilitation.class);
		return map;
	}

}
