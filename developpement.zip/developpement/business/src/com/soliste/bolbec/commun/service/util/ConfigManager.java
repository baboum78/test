package com.soliste.bolbec.commun.service.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.InvalidPropertiesFormatException;
import java.util.Properties;

/**
 * Impl�mentation de ConfigManager
 * 
 * @author dBaret
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>14/08/2014</TD><TD>GCL</TD><TD>Nouveau ConfigManager</TD></TR>
 * </TABLE><BR>
 * 
 */
public class ConfigManager {

	/** Path vers le chemin des fichiers de configuration commun entre la livraison et le routeur (Propri�t� -Drouteur.properties.dir d�finit dans les option de d�marrage des JVM) */
	private String CONFIG_DIR = System.getProperty("bolbec.home.dir");

	/** La configuration de pharaon via le fichier de proprietes */
	protected Properties allConfig;

	/**
	 * M�thode permettant de r�cup�rer la configuration d�fini dans un fichier properties
	 * pour un nom donn�e. Le nom de la config doit correspondre � un fichier properties du r�pertoire
	 * de configuration g�n�rale. R�pertoire positionn� dans les param�tres de d�marrage des JVM.
	 * -Dbolbec.home.dir
	 * 
	 * @param configName Le nom de la configuration � charger (Doit correspondre � un fichier properties du r�pertoire bolbec.config.dir)
	 * @return Les propri�t�s charg�es
	 */
	public Properties loadConfig(String configName) {
		allConfig = new Properties();
		try {
			allConfig.load(new FileInputStream(CONFIG_DIR + File.separatorChar + "properties" + File.separatorChar + configName + ".properties"));
		} catch (InvalidPropertiesFormatException e) {
			// FIXME Remont�e une anomalie dans les 3 cas
			// ServiceManager.getInstance().getLoggerManager().severe("ConfigManager", "loadConfig", "Erreur chargement du fichier properties: " + configName, e);
		} catch (FileNotFoundException e) {
			// ServiceManager.getInstance().getLoggerManager().severe("ConfigManager", "loadConfig", "Erreur chargement du fichier properties: " + configName, e);
		} catch (IOException e) {
			// ServiceManager.getInstance().getLoggerManager().severe("ConfigManager", "loadConfig", "Erreur chargement du fichier properties: " + configName, e);
		}
		return allConfig;
	}

	/**
	 * @return Une repr�sentation objet de la configuration (Fichier properties)
	 */
	public Properties getAllConfig() {
		return allConfig;
	}

	/**
	 * M�thode permettant de r�cup�rer une valeur de la configuration (Du fichier properties)
	 * 
	 * @param cle La cle du fichier properties
	 * @return La valeur associ�e
	 */
	public String getConfig(String cle) {
		Object val = allConfig.get(cle);
		if (val != null) {
			return (String) val;
		}
		return null;
	}
}
