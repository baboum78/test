package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.ZoneSIUnite;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * ZoneSiUniteDTO: table relation entre UniteActivite et ZoneSi
 * fait partie de l'espace de r�f�rence
 */
public class ZoneSiUniteDTO implements java.io.Serializable {

	private String id;
	private UniteActiviteDTO uniteActivite;
	private ZoneSiDTO zoneSi;

	/**
	 * 
	 * @param id
	 */
	public ZoneSiUniteDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public ZoneSiUniteDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(ZoneSIUnite.FIELD_ID);
		EntityProxy ua = (EntityProxy) ep.getLinkedObject(ZoneSIUnite.SLINK_GERE_UNITE_UNITE_ACTIVITE);
		if (ua != null) {
			this.uniteActivite = new UniteActiviteDTO(ua);
		}
		EntityProxy zs = (EntityProxy) ep.getLinkedObject(ZoneSIUnite.SLINK_EST_DANS_ZONE_S_I);
		if (zs != null) {
			this.zoneSi = new ZoneSiDTO(zs);
		}
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public UniteActiviteDTO getUniteActivite() {
		return uniteActivite;
	}

	public ZoneSiDTO getZoneSi() {
		return zoneSi;
	}

}
