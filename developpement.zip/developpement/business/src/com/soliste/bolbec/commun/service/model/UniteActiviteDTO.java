package com.soliste.bolbec.commun.service.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import aps.CatClientUnite;
import aps.Role;
import aps.RoleUnite;
import aps.UniteActivite;
import aps.UniteOrganisation;
import aps.ZoneGeoUnite;
import aps.ZoneGeographique;
import aps.ZoneSI;
import aps.ZoneSIUnite;
import com.soliste.aps.foundation.ejb.EntityProxy;
import com.soliste.bolbec.fwk.util.StringUtils;
import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * UniteActiviteDTO fait partie de l'espace de r�f�rence
 */
public class UniteActiviteDTO implements java.io.Serializable {

	private String id;
	private UniteOrganisationDTO uniteOrganisation;
	private String adresse;
	private String email;
	private boolean gerable;
	private String libelle;
	private String telephone;
	private List<ZoneGeographiqueDTO> zoneGeos = new ArrayList<ZoneGeographiqueDTO>();
	private List<ZoneSiDTO> zoneSis = new ArrayList<ZoneSiDTO>();
	private List<RoleDTO> roles = new ArrayList<RoleDTO>();
	private List<CatClientUniteDTO> catClientUnites = new ArrayList<CatClientUniteDTO>();

	/**
	 * 
	 * @param id
	 */
	public UniteActiviteDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	@SuppressWarnings("unchecked")
	public UniteActiviteDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(UniteActivite.FIELD_ID);
		this.adresse = (String) ep.getValue(UniteActivite.FIELD_ADRESSE);
		this.email = (String) ep.getValue(UniteActivite.FIELD_EMAIL);
		String gerable = (String) ep.getValue(UniteActivite.FIELD_GERABLE);
		if (StringUtils.equals(gerable, "1")) {
			this.gerable = true;
		} else {
			this.gerable = false;
		}
		this.libelle = (String) ep.getValue(UniteActivite.FIELD_LIBELLE);
		this.telephone = (String) ep.getValue(UniteActivite.FIELD_TELEPHONE);
		EntityProxy uo = (EntityProxy) ep.getLinkedObject(UniteActivite.SLINK_RATTACHE_A_UNITE_ORGANISATION);
		if (uo != null) {
			this.uniteOrganisation = new UniteOrganisationDTO(uo);
		}
		List zgus = ep.getLinkedObjects(UniteActivite.MLINK_SUR_ZONE_GEOGRAPHIQUE);
		if (zgus != null) {
			int sizeList = zgus.size();
			for (int i = 0; i < sizeList; i++) {
				EntityProxy zgu = (EntityProxy) zgus.get(i);
				EntityProxy zg = (EntityProxy) zgu.getLinkedObject(ZoneGeoUnite.SLINK_SUR_ZONE_GEOGRAPHIQUE);
				zoneGeos.add(new ZoneGeographiqueDTO(zg));
			}
		}
		List zsis = ep.getLinkedObjects(UniteActivite.MLINK_EST_DANS_ZONE_S_I);
		if (zsis != null) {
			int sizeList = zsis.size();
			for (int i = 0; i < sizeList; i++) {
				EntityProxy zsu = (EntityProxy) zsis.get(i);
				EntityProxy zs = (EntityProxy) zsu.getLinkedObject(ZoneSIUnite.SLINK_EST_DANS_ZONE_S_I);
				zoneSis.add(new ZoneSiDTO(zs));
			}
		}
		List roleUnites = ep.getLinkedObjects(UniteActivite.MLINK_COUVRE_ROLE);
		if (roleUnites != null) {
			int sizeList = roleUnites.size();
			for (int i = 0; i < sizeList; i++) {
				EntityProxy roleUnite = (EntityProxy) roleUnites.get(i);
				EntityProxy role = (EntityProxy) roleUnite.getLinkedObject(RoleUnite.SLINK_COUVRE_ROLE);
				roles.add(new RoleDTO(role));
			}
		}
		List catClientUniteEPs = ep.getLinkedObjects(UniteActivite.MLINK_GERE_CAT_CLIENT_UNITE);
		if (catClientUniteEPs != null) {
			int sizeList = catClientUniteEPs.size();
			for (int i = 0; i < sizeList; i++) {
				EntityProxy catClientUnite = (EntityProxy) catClientUniteEPs.get(i);
				catClientUnites.add(new CatClientUniteDTO(catClientUnite));
			}
		}
	}

	/**
	 * 
	 * @param uniteActivite
	 */
	public UniteActiviteDTO(UniteActivite uniteActivite) {
		this.id = uniteActivite.getId();
		this.adresse = uniteActivite.getAdresse();
		this.email = uniteActivite.getEmail();
		String gerable = uniteActivite.getGerable();
		if (StringUtils.equals(gerable, "1")) {
			this.gerable = true;
		} else {
			this.gerable = false;
		}
		this.libelle = uniteActivite.getLibelle();
		this.telephone = uniteActivite.getTelephone();
		UniteOrganisation uo = uniteActivite.getLinkRattacheAUniteOrganisation();
		if (uo != null) {
			this.uniteOrganisation = new UniteOrganisationDTO(uo.getId(), uo.getLibelle());
		}
		@SuppressWarnings("unchecked")
		Collection<ZoneGeoUnite> zgus = uniteActivite.getLinkSurZoneGeographique();
		if (zgus != null) {
			for (ZoneGeoUnite zoneGeoUnite : zgus) {
				ZoneGeographique zg = zoneGeoUnite.getLinkSurZoneGeographique();
				zoneGeos.add(new ZoneGeographiqueDTO(zg));
			}
		}
		@SuppressWarnings("unchecked")
		Collection<ZoneSIUnite> zsis = uniteActivite.getLinkEstDansZoneSI();
		if (zsis != null) {
			for (ZoneSIUnite zoneSIUnite : zsis) {
				ZoneSI zi = zoneSIUnite.getLinkEstDansZoneSI();
				zoneSis.add(new ZoneSiDTO(zi));
			}
		}
		@SuppressWarnings("unchecked")
		Collection<RoleUnite> roleUnites = uniteActivite.getLinkCouvreRole();
		if (roleUnites != null) {
			for (RoleUnite roleUnite : roleUnites) {
				Role role = roleUnite.getLinkCouvreRole();
				roles.add(new RoleDTO(role));
			}
		}
		@SuppressWarnings("unchecked")
		Collection<CatClientUnite> catClientUniteEPs = uniteActivite.getLinkGereCatClientUnite();
		if (catClientUniteEPs != null) {
			for (CatClientUnite catClientUnite : catClientUniteEPs) {
				catClientUnites.add(new CatClientUniteDTO(catClientUnite));
			}
		}
	}

	/**
	 * 
	 * @param uniteActiviteId
	 * @param uniteActiviteLibelle
	 * @param uniteOrganisationDTO
	 */
	public UniteActiviteDTO(String uniteActiviteId, String uniteActiviteLibelle, UniteOrganisationDTO uniteOrganisationDTO) {
		this.id = uniteActiviteId;
		this.libelle = uniteActiviteLibelle;
		this.uniteOrganisation = uniteOrganisationDTO;
	}

	/**
	 * 
	 * @param id
	 * @param adresse
	 * @param email
	 * @param libelle
	 * @param telephone
	 * @param uniteOrganisationId
	 * @param uniteOrganisationLibelle
	 */
	public UniteActiviteDTO(String id, String adresse, String email, String libelle, String telephone, String uniteOrganisationId, String uniteOrganisationLibelle) {
		this.id = id;
		this.adresse = adresse;
		this.email = email;
		this.libelle = libelle;
		this.telephone = telephone;
		this.uniteOrganisation = new UniteOrganisationDTO(uniteOrganisationId, uniteOrganisationLibelle);
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public UniteOrganisationDTO getUniteOrganisation() {
		return uniteOrganisation;
	}

	public String getAdresse() {
		return adresse;
	}

	public String getEmail() {
		return email;
	}

	public String getLibelle() {
		return libelle;
	}

	public String getTelephone() {
		return telephone;
	}

	public List<ZoneGeographiqueDTO> getZoneGeos() {
		return zoneGeos;
	}

	public List<ZoneSiDTO> getZoneSis() {
		return zoneSis;
	}

	public List<RoleDTO> getRoles() {
		return roles;
	}

	public List<CatClientUniteDTO> getCatClientUnites() {
		return catClientUnites;
	}

	public boolean isGerable() {
		return gerable;
	}

}
