package com.soliste.bolbec.commun.service.constante;

/**
 * Les diff�rents type d'op�ration
 * 
 * @author Sopragroup
 * 
 */
public enum TypeOpPonctuelle {
	/** Cas Cr�ation */
	CR,
	/** Cas modification */
	MO,
	/** Cas suppression */
	SU,
	/** Cas de conservation */
	EQUALS
}
