package com.soliste.bolbec.commun.service.util;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe permettant de recuperer un id <br/>
 * Remplace la classe com.soliste.aps.foundation.ejb.counter.CounterManager
 * 
 * @author kyrw0678
 */
public class GeneratorManager implements IGeneratorManager {

	/** Pr�fixe qui pr�c�dera toutes les cl�s retourn�es . */
	public static String COUNTER_PREFIX = System.getProperty("CounterPrefix");

	/** Instance priv�e du singleton. */
	private static IGeneratorManager instance;

	/**
	 * Instantiates a new id manager.
	 */
	private GeneratorManager() {

	}

	/**
	 * 
	 * @return
	 */
	public synchronized static IGeneratorManager getInstance() {
		if (instance == null) {
			instance = new GeneratorManager();
		}
		return instance;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.util.IGeneratorManager#generateKey(java.lang.String,java.lang.String)
	 */
	public String generateKey(String contentType, String prefix) {
		return IdGenerator.generateKey(contentType, prefix);
	}

	/**
	 * @see com.soliste.bolbec.commun.service.util.IGeneratorManager#generateKey(java.lang.String)
	 */
	public String generateKey(String contentType) {
		return IdGenerator.generateKey(contentType);
	}

	/**
	 * @see com.soliste.bolbec.commun.service.util.IGeneratorManager#generateKey()
	 */
	public String generateKey() {
		return IdGenerator.generateKey();
	}

}
