package com.soliste.bolbec.commun.service.model;

import java.util.HashMap;

import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.fwk.util.DateUtils;

/**
 * DTO d�crivant une trame HTTP (API Rest) � archiver c�t� routeur
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/09/2016</TD><TD>JDE</TD><TD>G9R2C1 - Refactoring de l'archivage des messages API (IN et OUT)</TD></TR>
 * </TABLE>
 */
public abstract class MessageAPIDTO implements Archivable {

	/**
	 * Generated serial version UID
	 */
	private static final long serialVersionUID = 3973247951437054554L;

	/** Clefs (les noms exacts des colonnes des tables routeur MessageAPI) */
	private static String CLE_DATE_MESSAGE = "dateMessage";
	private static String CLE_PARTENAIRE = "partenaire";
	private static String CLE_UTILISATEUR = "utilisateur";
	private static String CLE_METHODE = "methode";
	private static String CLE_URL = "url";
	private static String CLE_SERVICE = "service";
	private static String CLE_ID_COMMANDE = "idCommande";
	private static String CLE_CODE_REPONSE = "codeReponse";
	private static String CLE_CONTENU_REQUETE = "contenuRequete";
	private static String CLE_CONTENU_REPONSE = "contenuReponse";

	/** Infos */
	protected Long dateMessage;
	protected String partenaire;
	protected String utilisateur;
	protected String methode;
	protected String url;
	protected String service;
	protected String idCommande;
	protected String codeReponse;
	protected String contenuRequete;
	protected String contenuReponse;


	public Long getDateMessage(){
		return dateMessage;
	}

	public void setDateMessage(Long dateMessage){
		this.dateMessage = dateMessage;
	}

	public String getPartenaire(){
		return partenaire;
	}

	public void setPartenaire(String partenaire){
		this.partenaire = partenaire;
	}

	public String getUtilisateur(){
		return utilisateur;
	}

	public void setUtilisateur(String utilisateur){
		this.utilisateur = utilisateur;
	}

	public String getMethode(){
		return methode;
	}

	public void setMethode(String methode){
		this.methode = methode;
	}

	public String getUrl(){
		return url;
	}

	public void setUrl(String url){
		this.url = url;
	}

	public String getService(){
		return service;
	}

	public void setService(String service){
		this.service = service;
	}

	public String getIdCommande(){
		return idCommande;
	}

	public void setIdCommande(String idCommande){
		this.idCommande = idCommande;
	}

	public String getCodeReponse(){
		return codeReponse;
	}

	public void setCodeReponse(String codeReponse){
		this.codeReponse = codeReponse;
	}

	public String getContenuRequete(){
		return contenuRequete;
	}

	public void setContenuRequete(String contenuRequete){
		this.contenuRequete = contenuRequete;
	}

	public String getContenuReponse(){
		return contenuReponse;
	}

	public void setContenuReponse(String contenuReponse){
		this.contenuReponse = contenuReponse;
	}

	/**
	 * Le constructeur du DTO MessageAPI
	 *
	 * @param partenaire
	 * @param utilisateur
	 * @param methode
	 * @param url
	 * @param service
	 * @param idCommande
	 * @param codeResponse
	 * @param contenuRequete
	 * @param contenuReponse
	 */
	public MessageAPIDTO(String partenaire, String utilisateur, String methode, String url, String service, String idCommande, String codeResponse, String contenuRequete, String contenuReponse) {
		this.dateMessage = DateUtils.getDatabaseDate();
		this.partenaire = partenaire;
		this.utilisateur = utilisateur;
		this.methode = methode;
		this.url = url;
		this.service = service;
		this.idCommande = idCommande;
		this.codeReponse = codeResponse;
		this.contenuRequete = contenuRequete;
		this.contenuReponse = contenuReponse;
	}

	/**
	 * R�cup�rer une image de l'objet sous forme de map
	 *
	 * @return l'image de l'objet sous forme de map
	 */
	public HashMap<String, Object> toMap() {
		HashMap<String, Object> map = new HashMap<String, Object>();

		map.put(CLE_DATE_MESSAGE, dateMessage);
		map.put(CLE_PARTENAIRE, partenaire);
		map.put(CLE_UTILISATEUR, utilisateur);
		map.put(CLE_METHODE, methode);
		map.put(CLE_URL, url);
		map.put(CLE_SERVICE, service);
		map.put(CLE_ID_COMMANDE, idCommande);
		map.put(CLE_CODE_REPONSE, codeReponse);
		map.put(CLE_CONTENU_REQUETE, contenuRequete);
		map.put(CLE_CONTENU_REPONSE, contenuReponse);

		return map;
	}

}
