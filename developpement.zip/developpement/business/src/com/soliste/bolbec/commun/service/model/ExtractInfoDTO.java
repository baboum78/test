package com.soliste.bolbec.commun.service.model;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import com.soliste.bolbec.commun.service.constante.CibleTransfert;
import com.soliste.bolbec.commun.service.constante.CodeTransfert;
import com.soliste.bolbec.commun.service.constante.InstanceArtemis;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>18/10/2010</TD><TD>GPA</TD><TD>EV-000087: Cr�ation de la classe</TD></TR>
 * <TR><TD>07/09/2011</TD><TD>BPE</TD><TD>EV-000144: Ajout d'un constructeur vide</TD></TR>
 * <TR><TD>20/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Impl�mentation de l'interface Archivable</TD></TR>
 * </TABLE>
 */
public class ExtractInfoDTO implements Archivable {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -2179026046354824936L;

	/** Clefs (les noms exacts des colonnes de la table routeur ExtractInfo) */
	public static String CLE_ID_COMMANDE = "idCommande";
	public static String CLE_REF_EXTERNE_COMMANDE = "refExterneCommande";
	public static String CLE_DATE_CREATION = "dateCreation";
	public static String CLE_CONTENU = "contenu";
	public static String CLE_VERSION_BOLBEC = "versionArtemis";
	public static String CLE_INSTANCE_BOLBEC = "instanceArtemis";
	public static String CLE_CIBLE_TRANSFERT = "cibleTransfert";
	public static String CLE_DATE_TRANSFERT = "dateTransfert";
	public static String CLE_CODE_TRANSFERT = "codeTransfert";
	public static String CLE_FICHIER_GENERE = "fichierTransfert";

	/** Infos */
	private String idCommande;
	private String refExterneCommande;
	private Long dateCreation;
	private String contenu;
	private String versionArtemis;
	private InstanceArtemis instanceArtemis;
	private CibleTransfert cibleTransfert;
	private Long dateTransfert;
	private CodeTransfert codeTransfert;
	private String fichierGenere;

	/** Format de date */
	private static final SimpleDateFormat SDF = new SimpleDateFormat("yyyyMMddHHmmss");

	/**
	 * Constructeur de la classe ExtractInfoData
	 */
	public ExtractInfoDTO(String idCommande, String refExterneCommande, String contenu, String version, InstanceArtemis instance, CibleTransfert cibleTransfert) {
		setIdcommande(idCommande);
		setRefExterneCommande(refExterneCommande);
		setDateCreation(Long.valueOf(SDF.format(new Date())));
		setContenu(contenu);
		setVersionArtemis(version);
		setInstanceArtemis(instance);
		setCibleTransfert(cibleTransfert);
		setDateTransfert(Long.valueOf(0));
		setCodeTransfert(CodeTransfert.A_EXTRAIRE);
		setFichierGenere("");
	}

	public String getIdCommande() {
		return idCommande;
	}

	public void setIdcommande(String idCommande) {
		this.idCommande = idCommande;
	}

	public String getRefExterneCommande() {
		return refExterneCommande;
	}

	public void setRefExterneCommande(String refExterneCommande) {
		this.refExterneCommande = refExterneCommande;
	}

	public Long getDateCreation() {
		return dateCreation;
	}

	public void setDateCreation(Long dateCreation) {
		this.dateCreation = dateCreation;
	}

	public String getContenu() {
		return contenu;
	}

	public void setContenu(String contenu) {
		this.contenu = contenu;
	}

	public String getVersionArtemis() {
		return versionArtemis;
	}

	public void setVersionArtemis(String versionArtemis) {
		this.versionArtemis = versionArtemis;
	}

	public InstanceArtemis getInstanceArtemis() {
		return instanceArtemis;
	}

	public void setInstanceArtemis(InstanceArtemis instanceArtemis) {
		this.instanceArtemis = instanceArtemis;
	}

	public CibleTransfert getCibleTransfert() {
		return cibleTransfert;
	}

	public void setCibleTransfert(CibleTransfert cibleTransfert) {
		this.cibleTransfert = cibleTransfert;
	}

	public Long getDateTransfert() {
		return dateTransfert;
	}

	public void setDateTransfert(Long dateTransfert) {
		this.dateTransfert = dateTransfert;
	}

	public CodeTransfert getCodeTransfert() {
		return codeTransfert;
	}

	public void setCodeTransfert(CodeTransfert codeTransfert) {
		this.codeTransfert = codeTransfert;
	}

	public String getFichierGenere() {
		return fichierGenere;
	}

	public void setFichierGenere(String fichierGenere) {
		this.fichierGenere = fichierGenere;
	}

	/**
	 * R�cup�rer une image de l'objet sous forme de chaine
	 * 
	 * @return l'image de l'objet
	 */
	public String toString() {
		return "ExtractInfoDTO [cibleTransfert=" + cibleTransfert + ", codeTransfert=" + codeTransfert + ", contenu=" + contenu + ", dateCreation=" + dateCreation + ", dateTransfert=" + dateTransfert + ", fichierGenere=" + fichierGenere + ", idCommande="
				+ idCommande + ", instanceArtemis=" + instanceArtemis + ", refExterneCommande=" + refExterneCommande + ", versionArtemis=" + versionArtemis + "]";
	}

	/**
	 * R�cup�rer une image de l'objet sous forme de map
	 * 
	 * @return l'image de l'objet
	 */
	public HashMap<String, Object> toMap() {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(CLE_ID_COMMANDE, idCommande);
		map.put(CLE_REF_EXTERNE_COMMANDE, refExterneCommande);
		map.put(CLE_DATE_CREATION, dateCreation);
		map.put(CLE_CONTENU, contenu);
		map.put(CLE_VERSION_BOLBEC, versionArtemis);
		map.put(CLE_INSTANCE_BOLBEC, instanceArtemis.name());
		map.put(CLE_CIBLE_TRANSFERT, cibleTransfert.name());
		map.put(CLE_DATE_TRANSFERT, dateTransfert);
		map.put(CLE_CODE_TRANSFERT, codeTransfert.name());
		map.put(CLE_FICHIER_GENERE, fichierGenere);
		return map;
	}

}
