package com.soliste.bolbec.commun.service.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import com.soliste.aps.foundation.ejb.EntityProxy;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;

import aps.Agent;
import aps.UniteActivite;

/**
 * AgentDTO fait partie de l'espace de r�f�rence
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>19/10/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV000183 - Apostrof Corbeille IHM BIS</TD></TR>
 * </TABLE><BR>
 * 
 */
public class AgentDTO implements java.io.Serializable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 6655461087239948224L;

	private String id;
	private UniteActiviteDTO uniteActivite;
	private boolean actif;
	private Long dateSupp;
	private String email;
	private String fax;
	private boolean gerable;
	private String motDePasse;
	private String nom;
	private String notificationMean;
	private String prenom;
	private String telephone;
	protected boolean modifNote;
	private Map<String, Boolean> habilitations = new HashMap<String, Boolean>();

	/**
	 * 
	 */
	public AgentDTO() {
		this.id = null;
		this.actif = true;
		this.dateSupp = null;
		this.email = null;
		this.fax = null;
		this.gerable = true;
		this.motDePasse = null;
		this.nom = null;
		this.notificationMean = null;
		this.prenom = null;
		this.telephone = null;
		this.uniteActivite = null;
		this.modifNote = false;
	}

	/**
	 * 
	 * @param id
	 */
	public AgentDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param agent
	 */
	public AgentDTO(Agent agent) {
		this.id = agent.getId();
		this.actif = StringUtils.equals(agent.getActif(), "1");
		this.dateSupp = agent.getDateSupp();
		this.email = agent.getEmail();
		this.fax = agent.getFax();
		this.gerable = StringUtils.equals(agent.getGerable(), "1");
		this.motDePasse = agent.getMotDePasse();
		this.nom = agent.getNom();
		this.notificationMean = agent.getNotificationMean();
		this.prenom = agent.getPrenom();
		this.telephone = agent.getTelephone();
		UniteActivite ua = agent.getLinkAppartientUniteActivite();
		if (ua != null) {
			this.uniteActivite = new UniteActiviteDTO(ua.getId());
		}
		if (agent.getModifNote() != null) {
			this.modifNote = (Integer.parseInt(agent.getModifNote()) == 1);
		}
	}

	/**
	 * 
	 * @param ep
	 */
	public AgentDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(Agent.FIELD_ID);
		this.actif = StringUtils.equals((String) ep.getValue(Agent.FIELD_ACTIF), "1");
		this.dateSupp = (Long) ep.getValue(Agent.FIELD_DATE_SUPP);
		this.email = (String) ep.getValue(Agent.FIELD_EMAIL);
		this.fax = (String) ep.getValue(Agent.FIELD_FAX);
		this.gerable = StringUtils.equals((String) ep.getValue(Agent.FIELD_GERABLE), "1");
		this.motDePasse = (String) ep.getValue(Agent.FIELD_MOT_DE_PASSE);
		this.nom = (String) ep.getValue(Agent.FIELD_NOM);
		this.notificationMean = (String) ep.getValue(Agent.FIELD_NOTIFICATION_MEAN);
		this.prenom = (String) ep.getValue(Agent.FIELD_PRENOM);
		this.telephone = (String) ep.getValue(Agent.FIELD_TELEPHONE);
		EntityProxy ua = (EntityProxy) ep.getLinkedObject(Agent.SLINK_APPARTIENT_UNITE_ACTIVITE);
		if (ua != null) {
			this.uniteActivite = new UniteActiviteDTO(ua);
		}
		if (ep.getValue(Agent.FIELD_MODIF_NOTE) != null) {
			this.modifNote = (Integer.parseInt((String) ep.getValue(Agent.FIELD_MODIF_NOTE)) == 1);
		}
	}

	/**
	 * 
	 * @param id
	 * @param actif
	 * @param dateSupp
	 * @param email
	 * @param fax
	 * @param nom
	 * @param prenom
	 * @param telephone
	 * @param uniteActiviteId
	 * @param uniteActiviteLibelle
	 * @param uniteOrganisationId
	 * @param uniteOrganisationLibelle
	 */
	public AgentDTO(String id, Boolean actif, Date dateSupp, String email, String fax, String nom, String prenom, String telephone, String uniteActiviteId, String uniteActiviteLibelle, String uniteOrganisationId, String uniteOrganisationLibelle) {
		this.id = id;
		this.actif = actif;
		this.dateSupp = DateUtils.getDatabaseDate(dateSupp);
		this.email = email;
		this.fax = fax;
		this.nom = nom;
		this.prenom = prenom;
		this.telephone = telephone;
		UniteOrganisationDTO uniteOrganisationDTO = new UniteOrganisationDTO(uniteOrganisationId, uniteOrganisationLibelle);
		this.uniteActivite = new UniteActiviteDTO(uniteActiviteId, uniteActiviteLibelle, uniteOrganisationDTO);
	}

	/**
	 * 
	 * @param id
	 * @param actif
	 * @param dateSupp
	 * @param email
	 * @param fax
	 * @param nom
	 * @param prenom
	 * @param telephone
	 * @param uniteActiviteId
	 * @param uniteActiviteLibelle
	 * @param uniteOrganisationId
	 * @param uniteOrganisationLibelle
	 */
	public AgentDTO(String id, Boolean actif, Date dateSupp, String email, String fax, String nom, String prenom, String telephone, String uniteActiviteId, String uniteActiviteLibelle, String uniteOrganisationId, String uniteOrganisationLibelle,
			boolean modifNote) {
		this.id = id;
		this.actif = actif;
		this.dateSupp = DateUtils.getDatabaseDate(dateSupp);
		this.email = email;
		this.fax = fax;
		this.nom = nom;
		this.prenom = prenom;
		this.telephone = telephone;
		UniteOrganisationDTO uniteOrganisationDTO = new UniteOrganisationDTO(uniteOrganisationId, uniteOrganisationLibelle);
		this.uniteActivite = new UniteActiviteDTO(uniteActiviteId, uniteActiviteLibelle, uniteOrganisationDTO);
		this.modifNote = modifNote;
	}

	/**
	 * 
	 */
	public AgentDTO(AgentDTO agent) {
		this.id = agent.id;
		this.actif = agent.actif;
		this.dateSupp = agent.dateSupp;
		this.email = agent.email;
		this.fax = agent.fax;
		this.gerable = agent.gerable;
		this.motDePasse = agent.motDePasse;
		this.nom = agent.nom;
		this.notificationMean = agent.notificationMean;
		this.prenom = agent.prenom;
		this.telephone = agent.telephone;
		this.uniteActivite = agent.uniteActivite;
		this.modifNote = agent.modifNote;
		this.habilitations = agent.habilitations;
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public UniteActiviteDTO getUniteActivite() {
		return uniteActivite;
	}

	public Long getDatabaseDateSupp() {
		return dateSupp;
	}

	public Date getDateSupp() {
		return DateUtils.getDatabaseDate(dateSupp);
	}

	public String getEmail() {
		return email;
	}

	public String getFax() {
		return fax;
	}

	public String getMotDePasse() {
		return motDePasse;
	}

	public String getNom() {
		return nom;
	}

	public String getNotificationMean() {
		return notificationMean;
	}

	public String getPrenom() {
		return prenom;
	}

	public String getTelephone() {
		return telephone;
	}

	public boolean isActif() {
		return actif;
	}

	public boolean isGerable() {
		return gerable;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setUniteActivite(UniteActiviteDTO uniteActivite) {
		this.uniteActivite = uniteActivite;
	}

	public void setActif(boolean actif) {
		this.actif = actif;
	}

	public void setDateSupp(Long dateSupp) {
		this.dateSupp = dateSupp;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public void setGerable(boolean gerable) {
		this.gerable = gerable;
	}

	public void setMotDePasse(String motDePasse) {
		this.motDePasse = motDePasse;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public void setNotificationMean(String notificationMean) {
		this.notificationMean = notificationMean;
	}

	public void setPrenom(String prenom) {
		this.prenom = prenom;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public Map<String, Boolean> getHabilitations() {
		return habilitations;
	}

	public void setHabilitations(Map<String, Boolean> habilitations) {
		this.habilitations = habilitations;
	}

	public boolean getModifNote() {
		return modifNote;
	}

	public void setModifNote(boolean modifNote) {
		this.modifNote = modifNote;
	}

	/**
	 * Retourne le nom complet de l'agent
	 * @param agentInfo
	 * @return
	 */
	public String getFullName() {
		String result = this.prenom;
		if (StringUtils.isNotEmpty(result) && StringUtils.isNotBlank(this.nom) ) {
			result = result.concat(" ").concat(this.nom);
		}
		return result;
	}

}
