package com.soliste.bolbec.commun.service.ejb.sb.agent;

import javax.ejb.EJBLocalObject;

public interface AgentManagerLocal extends EJBLocalObject, AgentManager {

}
