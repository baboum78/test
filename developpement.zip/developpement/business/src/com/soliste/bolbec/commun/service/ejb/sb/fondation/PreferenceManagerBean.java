/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Properties;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionContext;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.soliste.aps.foundation.ejb.preferences.Preference;
import com.soliste.aps.foundation.ejb.preferences.PreferenceHome;
import com.soliste.bolbec.commun.service.ejb.sb.commun.data.Column;
import com.soliste.bolbec.commun.service.ejb.sb.commun.data.TablePreferences;
import com.soliste.bolbec.commun.service.util.GeneratorManager;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;

/**
 * Impl�mentation du session bean PreferenceManager.
 * 
 * @author rgvs7490
 * @see PreferenceManager
 */
public class PreferenceManagerBean extends FwkSessionBean implements PreferenceManager {

	/** The Constant SYSTEM_USER. */
	private static final String SYSTEM_USER = "Artemis";

	/** The preference home. */
	private PreferenceHome preferenceHome;

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#getPreferences(java.lang.String, java.lang.String)
	 */
	public String getPreferences(String key, String agentId) {
		String result = getPreference(key, agentId);
		if (result == null) {
			result = getSystemPreferences(key);
		}
		return result;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#getPreferencesAsProperties(java.lang.String, java.lang.String)
	 */
	public Properties getPreferencesAsProperties(String key, String agentId) {
		try {
			String pref = getPreference(key, agentId);
			return asProperties(pref);
		} catch (IOException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Gets the system preferences.
	 * 
	 * @param key the key
	 * 
	 * @return the system preferences
	 */
	private String getSystemPreferences(String key) {
		return getPreference(key, SYSTEM_USER);
	}

	/**
	 * Gets the system preferences as properties.
	 * 
	 * @param key the key
	 * 
	 * @return the system preferences as properties
	 */
	private Properties getSystemPreferencesAsProperties(String key) {
		try {
			String pref = getSystemPreferences(key);
			return asProperties(pref);
		} catch (IOException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#getSystemTablePreferences(java.lang.String)
	 */
	public TablePreferences getSystemTablePreferences(String tableKey) {
		Properties props = getSystemPreferencesAsProperties(tableKey);
		return asTablePreferences(tableKey, props);
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#getTablePreferences(java.lang.String, java.lang.String)
	 */
	public TablePreferences getTablePreferences(String tableKey, String agentId) {
		Properties props = getPreferencesAsProperties(tableKey, agentId);
		return asTablePreferences(tableKey, props);
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#getTypePreferences(java.lang.String, java.lang.String)
	 */
	public List<String> getTypePreferences(String typeKey, String agentId) {
		List<String> listTypePreferences = new ArrayList<String>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Preference> c = preferenceHome.findByDomainAndOwner("bolbec", agentId);
			for (Preference preference : c) {
				if (preference.getKey().startsWith(typeKey)) {
					listTypePreferences.add(preference.getKey());
				}
			}
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		return listTypePreferences;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#savePreferences(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void savePreferences(String key, String preferences, String agentId) {
		try {
			@SuppressWarnings("unchecked")
			Collection<Preference> c = preferenceHome.findByDomainAndOwner("bolbec", agentId);
			Preference preference = null;
			for (Iterator<Preference> it = c.iterator(); it.hasNext() && (preference == null);) {
				Preference p = it.next();
				if (key.equals(p.getKey())) {
					preference = p;
				}
			}
			if (preference != null) {
				preference.setContent(preferences);
			} else {
				String id = GeneratorManager.getInstance().generateKey();
				HashMap<String, Object> values = new HashMap<String, Object>();
				values.put(Preference.FIELD_DOMAIN, "bolbec");
				values.put(Preference.FIELD_KEY, key);
				values.put(Preference.FIELD_OWNER, agentId);
				values.put(Preference.FIELD_CONTENT, preferences);
				preferenceHome.create(id, values);
			}
		} catch (FinderException e) {
			throw new EJBException(e);
		} catch (CreateException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#savePreferencesAsProperties(java.lang.String, java.util.Properties, java.lang.String)
	 */
	public void savePreferencesAsProperties(String key, Properties preferences, String agentId) {
		try {
			String s = asString(preferences);
			savePreferences(key, s, agentId);
		} catch (IOException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#saveTablePreferences(bolbec.ihm.common.data.preferences.table.TablePreferences, java.lang.String)
	 */
	public void saveTablePreferences(TablePreferences tablePreferences, String agentId) {
		String tableKey = tablePreferences.getTableKey();
		Properties props = new Properties();
		for (Iterator<Column> it = tablePreferences.getColumns().iterator(); it.hasNext();) {
			Column column = it.next();
			props.put(column.getTitleKey(), Boolean.toString(column.isVisible()));
		}
		savePreferencesAsProperties(tableKey, props, agentId);
	}

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			InitialContext initCtx = new InitialContext();
			preferenceHome = (PreferenceHome) initCtx.lookup("java:comp/env/ejb/Preference");
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * As properties.
	 * 
	 * @param s the s
	 * 
	 * @return the properties
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private Properties asProperties(String s) throws IOException {
		if (s == null) {
			return null;
		}
		byte[] prefAsBytes = s.getBytes("ISO-8859-1");
		Properties props = new Properties();
		InputStream in = new ByteArrayInputStream(prefAsBytes);
		props.load(in);
		return props;
	}

	/**
	 * As string.
	 * 
	 * @param props the props
	 * 
	 * @return the string
	 * 
	 * @throws IOException Signals that an I/O exception has occurred.
	 */
	private String asString(Properties props) throws IOException {
		if (props == null) {
			return null;
		}
		ByteArrayOutputStream out = new ByteArrayOutputStream();
		props.store(out, null);
		byte[] contentAsBytes = out.toByteArray();
		String content = new String(contentAsBytes, "ISO-8859-1");
		return content;
	}

	/**
	 * As table preferences.
	 * 
	 * @param tableKey the table key
	 * @param props the props
	 * 
	 * @return the table preferences
	 */
	private TablePreferences asTablePreferences(String tableKey, Properties props) {
		if (props == null) {
			return null;
		}
		TablePreferences result = new TablePreferences(tableKey);
		for (Iterator<Object> it = props.keySet().iterator(); it.hasNext();) {
			String key = (String) it.next();
			String value = props.getProperty(key);
			boolean visible = Boolean.valueOf(value).booleanValue();
			result.addOptionalColumn(key, visible);
		}
		return result;
	}

	/**
	 * Gets the preference.
	 * 
	 * @param key the key
	 * @param user the user
	 * 
	 * @return the preference
	 */
	private String getPreference(String key, String user) {
		try {
			@SuppressWarnings("unchecked")
			Collection<Preference> c = preferenceHome.findByDomainAndOwner("bolbec", user);
			Preference preference = null;
			for (Iterator<Preference> it = c.iterator(); it.hasNext() && (preference == null);) {
				Preference p = it.next();
				if (key.equals(p.getKey())) {
					preference = p;
				}
			}
			return (preference == null) ? null : preference.getContent();
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#deletePreferences(java.lang.String, java.lang.String)
	 */
	public void deletePreferences(String key, String agentId) {
		try {
			@SuppressWarnings("unchecked")
			Collection<Preference> c = preferenceHome.findByDomainAndOwner("bolbec", agentId);
			for (Iterator<Preference> it = c.iterator(); it.hasNext();) {
				Preference p = it.next();
				if (key.equals(p.getKey())) {
					p.remove();
				}
			}
		} catch (FinderException e) {
			throw new EJBException(e);
		} catch (EJBException e) {
			throw new EJBException(e);
		} catch (RemoveException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.PreferenceManager#deletePreferences(java.lang.String, java.util.Map, java.lang.String)
	 */
	public void deletePreferences(String key, Map<String, String> values, String agentId) {
		try {
			@SuppressWarnings("unchecked")
			Collection<Preference> c = preferenceHome.findByDomainAndOwner("bolbec", agentId);
			for (Iterator<Preference> it = c.iterator(); it.hasNext();) {
				Preference p = it.next();

				if (key.equals(p.getKey())) {
					Properties prop = asProperties(p.getContent());

					boolean match = true;
					for (Entry<String, String> entry : values.entrySet()) {
						if (!entry.getValue().equals(prop.get(entry.getKey()))) {
							match = false;
						}
					}

					if (match) {
						p.remove();
					}
				}
			}
		} catch (IOException e) {
			throw new EJBException(e);
		} catch (FinderException e) {
			throw new EJBException(e);
		} catch (EJBException e) {
			throw new EJBException(e);
		} catch (RemoveException e) {
			throw new EJBException(e);
		}
	}
}