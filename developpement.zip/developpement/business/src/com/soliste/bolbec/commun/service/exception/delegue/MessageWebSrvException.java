package com.soliste.bolbec.commun.service.exception.delegue;

import com.soliste.bolbec.commun.service.exception.BusinessException;

/**
 * Exception li�e � l'archivage des trames web services
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public class MessageWebSrvException extends BusinessException {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = -5106869084365573213L;

	/**
	 * @param msg
	 */
	public MessageWebSrvException(String msg) {
		super(msg);
	}

	/**
	 * @param msg
	 * @param t
	 */
	public MessageWebSrvException(String msg, Throwable t) {
		super(msg, t);
	}

}
