package com.soliste.bolbec.commun.service.interfaces.util.cxf;

import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Intercepteur qui capture les trames xml entrantes et les renseigne dans le message captur� pour que la trame soit disponible plus tard dans le processus d'interception
 * 
 * @author vDelamarre
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/10/2013</TD><TD>VDE</TD><TD>Migration : Ajout Intercepteurs CXF</TD></TR>
 * </TABLE>
 */

public class ArchivingInterceptorInMessage extends AbstractPhaseInterceptor<Message> {

	private static final String CLASS_NAME = ArchivingInterceptorInMessage.class.getName();

	/**
	 * 
	 */
	public ArchivingInterceptorInMessage() {
		super(Phase.RECEIVE);
	}

	@Override
	public void handleMessage(Message message) throws Fault {

		final String method = "handleMessage";

		// Recuperation de la trame Soap
		InputStream inputStream = message.getContent(InputStream.class);
		if (inputStream != null) {
			// Copie du Stream du message Soap
			CachedOutputStream cachedInputStream = new CachedOutputStream();
			try {
				IOUtils.copy(inputStream, cachedInputStream);
				inputStream.close();
				cachedInputStream.close();
				InputStream tmpInputStream = cachedInputStream.getInputStream();
				String xml = "";
				int data;
				while ((data = tmpInputStream.read()) != -1) {
					byte x = (byte) data;
					xml += (char) x;
				}
				message.setContent(InputStream.class, cachedInputStream.getInputStream());
				if (StringUtils.isNotBlank(xml)) {
					message.put(Constantes.XMLMESSAGE, xml);
				}
			} catch (IOException e) {
				LoggerManager.getInstance().severe(CLASS_NAME, method, "Probl�me lors de l'interception du Stream", e);
			}
		}
	}

}
