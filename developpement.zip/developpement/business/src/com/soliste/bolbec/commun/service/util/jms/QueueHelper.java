/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.util.jms;

import javax.jms.JMSException;
import javax.jms.Queue;
import javax.jms.QueueConnection;
import javax.jms.QueueConnectionFactory;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Classe d'aide permettant d'envoyer de mani�re transactionnelle un
 * message dans une queue, � partir d'un EJB ou d'un servlet.
 * <br/>
 * Cette classe prend en compte les instructions donn�e � l'addresse suivante:
 * <a href="http://e-docs.bea.com/wls/docs81/jms/j2ee_components.html">http://e-docs.bea.com/wls/docs81/jms/j2ee_components.html</a>
 * <br/>
 * Voici un exemple d'utilisation de cette classe. Les parties les plus importantes � respecter sont
 * la fermeture de la connection dans le bloc finally, et l'invalidation du helper
 * en cas de JMSException.
 * <pre>
 * public class MessageSender {
 * private QueueHelper helper =
 * new QueueHelper("jms/myQueueConnectionFactory",
 * "jms/myQueue");
 * 
 * public void sendMessage(Serializable messageBody) {
 * QueueConnection queueConnection = null;
 * try {
 * queueConnection = helper.createConnection();
 * QueueSession queueSession = queueConnection.createQueueSession(true, 0);
 * QueueSender queueSender =
 * queueSession.createSender(helper.getQueue());
 * ObjectMessage msg =
 * queueSession.createObjectMessage(messageBody);
 * queueSender.send(msg);
 * }
 * catch(JMSException e) {
 * helper.invalidate();
 * throw new RuntimeException(e);
 * }
 * catch(NamingException e) {
 * throw new EJBException(e);
 * }
 * finally {
 * QueueHelper.closeConnection(queueConnection);
 * }
 * }
 * }
 * </pre>
 * Pour que cela puisse fonctionner, il faut que le composant (EJB par exemple)
 * faisant appel � cette classe ait un descripteur de d�ploiement configur� correctement:<br/>
 * ejb-jar.xml:
 * <pre>
 * &lt;resource-ref&gt;
 * &lt;res-ref-name&gt;jms/myQueueConnectionFactory&lt;/res-ref-name&gt;
 * &lt;res-type&gt;javax.jms.QueueConnectionFactory&lt;/res-type&gt;
 * &lt;res-auth&gt;Container&lt;/res-auth&gt;
 * &lt;res-sharing-scope&gt;Shareable&lt;/res-sharing-scope&gt;
 * &lt;/resource-ref&gt;
 * 
 * &lt;resource-env-ref&gt;
 * &lt;resource-env-ref-name&gt;jms/myQueue&lt;/resource-env-ref-name&gt;
 * &lt;resource-env-ref-type&gt;javax.jms.Queue&lt;/resource-env-ref-type&gt;
 * &lt;/resource-env-ref&gt;
 * </pre>
 * weblogic-ejb-jar.xml:
 * <pre>
 * &lt;reference-descriptor&gt;
 * &lt;resource-description&gt;
 * &lt;res-ref-name&gt;jms/errorQueueConnectionFactory&lt;/res-ref-name&gt;
 * &lt;jndi-name&gt;queue.XAQueueFactory&lt;/jndi-name&gt;
 * &lt;/resource-description&gt;
 * &lt;resource-env-description&gt;
 * &lt;res-env-ref-name&gt;jms/myQueue&lt;/res-env-ref-name&gt;
 * &lt;jndi-name&gt;queue.MyQueue&lt;/jndi-name&gt;
 * &lt;/resource-env-description&gt;
 * &lt;/reference-descriptor&gt;
 * </pre>
 * 
 * @author JB Nizet
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>05/10/2012</TD><TD>GPA</TD><TD>Correction suite � l'audit CAST G7R6C4</TD></TR>
 * </TABLE>
 */
public class QueueHelper {

	/** Le nom de la classe */
	public static final String CLASS_NAME = QueueHelper.class.getName();

	private String factoryName;
	private String queueName;
	private boolean queueNameIsAbsolute = false;
	private boolean initialized = false;

	private QueueConnectionFactory connectionFactory;
	private Queue queue;

	/**
	 * Constructor
	 * 
	 * @param factoryName Le nom JNDI, � partir du contexte d'environnement,
	 * de la connection factory
	 * @param queueName Le nom JNDI, � partir du contexte d'environnement,
	 * de la queue
	 */
	public QueueHelper(String factoryName, String queueName) {
		this(factoryName, queueName, false);
	}

	/**
	 * Constructor
	 * 
	 * @param factoryName Le nom JNDI, � partir du contexte d'environnement,
	 * de la connection factory
	 * @param queueName Le nom JNDI, � partir du contexte d'environnement
	 * (sauf si queueNameIsAbsolute est � true), de la queue
	 */
	public QueueHelper(String factoryName, String queueName, boolean queueNameIsAbsolute) {
		this.factoryName = factoryName;
		this.queueName = queueName;
		this.queueNameIsAbsolute = queueNameIsAbsolute;
	}

	/**
	 * Permet d'obtenir la connection factory. Un lookup JNDI est effectu�
	 * pour obtenir la factory et la queue si elles n'ont pas encore �t�
	 * obtenues ou si invalidate vient d'�tre appel�.
	 * 
	 * @return la connection factory
	 * @throws NamingException si une exception est lev�e pendant le lookup
	 */
	public synchronized QueueConnectionFactory getConnectionFactory() throws NamingException {
		if (!initialized) {
			initialize();
		}
		return connectionFactory;
	}

	/**
	 * Permet de cr�er une connection � partir de la connection factory.
	 * Un lookup JNDI est effectu� pour obtenir la factory et la queue si
	 * elles n'ont pas encore �t� obtenues ou si invalidate vient d'�tre appel�.
	 * 
	 * @return une connection
	 * @throws NamingException si une erreur survient pendant le lookup
	 */
	public QueueConnection createConnection() throws JMSException, NamingException {
		return getConnectionFactory().createQueueConnection();
	}

	/**
	 * Permet d'obtenir la queue. Un lookup JNDI est effectu�
	 * pour obtenir la factory et la queue si elles n'ont pas encore �t�
	 * obtenues ou si invalidate vient d'�tre appel�.
	 * 
	 * @return la queue
	 * @throws NamingException si une exception est lev�e pendant le lookup
	 */
	public synchronized Queue getQueue() throws NamingException {
		if (!initialized) {
			initialize();
		}
		return queue;
	}

	/**
	 * Invalide le helper. Un appel � cette m�thode provoque un nouveau lookup JNDI
	 * � l'utilisation suivante du helper. Cette m�thode devrait �tre appel�e si une
	 * JMSException survient pendant l'envoi d'un message sur la queue
	 */
	public synchronized void invalidate() {
		connectionFactory = null;
		queue = null;
		initialized = false;
	}

	/**
	 * M�thode statique permettant de fermer une connection. Cette m�thode
	 * devrait �tre utilis�e dans un bloc finally.
	 * 
	 * @param connection la connection � fermer (null est accept�)
	 */
	public static void closeConnection(QueueConnection connection) {
		if (connection != null) {
			try {
				connection.close();
			} catch (JMSException e) {
				// ignore
				LoggerManager.getInstance().fine(CLASS_NAME, "closeConnection", "JMSException lors de la fermeture de la connection");
			}
		}
	}

	private void initialize() throws NamingException {
		InitialContext initCtx = new InitialContext();
		Context envContext = (Context) initCtx.lookup("java:comp/env");
		this.connectionFactory = (QueueConnectionFactory) envContext.lookup(factoryName);
		if (queueNameIsAbsolute) {
			this.queue = (Queue) initCtx.lookup(queueName);
		} else {
			this.queue = (Queue) envContext.lookup(queueName);
		}
		initialized = true;
	}
}
