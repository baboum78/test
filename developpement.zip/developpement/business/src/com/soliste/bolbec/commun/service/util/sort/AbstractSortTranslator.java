/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.util.sort;

/**
 * Impl�mentation abstraite de l'interface SortTranslator.
 * Elle se base sur une requ�te dans laquelle se trouve la cha�ne
 * $SORT$, � remplacer par la portion de SQL d�di�e au tri.
 * 
 * @see SortTranslator
 * @author rgvs7490
 */
public abstract class AbstractSortTranslator implements SortTranslator {

	/**
	 * La cha�ne � remplacer dans la requ�te ($SORT$)
	 */
	public static final String SORT_PLACE_HOLDER = "$SORT$";

	/**
	 * Retourne la requ�te originale, dans laquelle la sous-cha�ne $SORT$,
	 * si elle est pr�sente, a �t� remplac�e par la portion de SQL d�di�e au tri,
	 * g�n�r�e par la m�thode translate(SortCommand)
	 * 
	 * @see com.soliste.bolbec.commun.service.util.sort.SortTranslator#translate(java.lang.String, bolbec.ihm.common.sort.SortCommand)
	 */
	public String translate(String query, SortCommand sortCommand) {
		int sortIndex = query.indexOf(SORT_PLACE_HOLDER);
		if (sortIndex < 0) {
			return query;
		}

		StringBuffer buffer = new StringBuffer(query.length() + 100);
		buffer.append(query.substring(0, sortIndex));
		buffer.append(translate(sortCommand));
		buffer.append(query.substring(sortIndex + SORT_PLACE_HOLDER.length()));
		return buffer.toString();
	}

	/**
	 * Traduit la commande de tri donn�e en SQL
	 * 
	 * @param sortCommand la commande de tri � traduire
	 * @return la commande de tri traduite
	 */
	protected abstract String translate(SortCommand sortCommand);
}
