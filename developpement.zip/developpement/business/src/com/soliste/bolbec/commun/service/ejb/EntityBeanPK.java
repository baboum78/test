/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.ejb;

import com.soliste.aps.foundation.ejb.BaseEntityBeanPK;

/**
 * Wrapper pour l'objet de la fondation BaseEntityBeanPK
 * 
 * @author afbu7552
 */
public class EntityBeanPK extends BaseEntityBeanPK {

	/**
	 * Constructeur vide
	 */
	public EntityBeanPK() {
		// Rien � faire
	}

	/**
	 * Constructeur prenant en param�tre la cl�
	 */
	public EntityBeanPK(String id) {
		this.id = id;
	}

	/**
	 * Retourne le <code>id</code>
	 * 
	 * @return le <code>id</code>
	 */
	public String getId() {
		return id;
	}

	/**
	 * Affecte le <code>id</code>
	 * 
	 * @param id le <code>id</code> � affecter
	 */
	public void setId(String id) {
		this.id = id;
	}
}
