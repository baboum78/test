package com.soliste.bolbec.commun.service.model;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.builder.ReflectionToStringBuilder;

import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.fwk.util.DateUtils;

/**
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>08/01/2014</TD><TD>EBA</TD><TD>G8R2C4 - EV-000266 : Gel du ND</TD></TR>
 * </TABLE>
 * 
 * 
 */
public class NdGelesDTO implements Archivable {

	/** Contraintes BDD */
	private static final int MAX_CHAR_ND = 20;
	private static final int MAX_CHAR_TYPEABANDON = 30;
	private static final int MAX_CHAR_TYPEVENTE = 30;

	/** Clefs (les noms exacts des colonnes des tables routeur NDGELES) */
	private static final String CLE_ND = "nd";
	private static final String CLE_DATE_ABANDON = "dateAbandon";
	private static final String CLE_DATE_EXTRACTION = "dateExtraction";
	private static final String CLE_TYPE_ABANDON = "typeAbandon";
	private static final String CLE_TYPE_VENTE = "typeVente";

	/**
	 * serial version UID
	 */
	private static final long serialVersionUID = 2065901257520863721L;

	private String nd;
	private String typeVente;
	private String typeAbandon;
	private Date dateAbandon;
	private Date dateExtraction;

	/**
	 * Constructeur de base
	 * 
	 * @param nd
	 * @param dateAbandon
	 */
	public NdGelesDTO(String nd, Date dateAbandon) {
		this.nd = nd;
		this.dateAbandon = dateAbandon;
	}

	public String getNd() {
		return nd;
	}

	public void setNd(String nd) {
		this.nd = nd;
	}

	public String getTypeVente() {
		return typeVente;
	}

	public void setTypeVente(String typeVente) {
		this.typeVente = typeVente;
	}

	public String getTypeAbandon() {
		return typeAbandon;
	}

	public void setTypeAbandon(String typeAbandon) {
		this.typeAbandon = typeAbandon;
	}

	public Date getDateAbandon() {
		return dateAbandon;
	}

	public void setDateAbandon(Date dateAbandon) {
		this.dateAbandon = dateAbandon;
	}

	public Date getDateExtraction() {
		return dateExtraction;
	}

	public void setDateExtraction(Date dateExtraction) {
		this.dateExtraction = dateExtraction;
	}

	/**
	 * R�cup�rer une image de l'objet sous forme de map
	 * 
	 * @return l'image de l'objet
	 */
	public Map<String, Object> toMap() {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(CLE_DATE_ABANDON, DateUtils.getDatabaseDate(dateAbandon));
		map.put(CLE_DATE_EXTRACTION, DateUtils.getDatabaseDate(dateExtraction));
		map.put(CLE_ND, nd);
		map.put(CLE_TYPE_ABANDON, typeAbandon);
		map.put(CLE_TYPE_VENTE, typeVente);
		return map;
	}

	/**
	 * Valide le contenu de l'objet
	 * 
	 * Retourne true si l'objet est conforme au schema SQL, false sinon.
	 */
	public boolean validate() {
		return (nd != null && nd.length() <= MAX_CHAR_ND) && (typeAbandon != null && typeAbandon.length() <= MAX_CHAR_TYPEABANDON) && (typeVente != null && typeVente.length() <= MAX_CHAR_TYPEVENTE);
	}

	/**
	 * @return une repr�sentation "String" de l'objet
	 */
	@Override
	public String toString() {
		return ReflectionToStringBuilder.toString(this);
	}
}
