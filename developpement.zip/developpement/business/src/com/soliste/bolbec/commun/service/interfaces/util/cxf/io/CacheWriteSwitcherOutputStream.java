package com.soliste.bolbec.commun.service.interfaces.util.cxf.io;

import java.io.IOException;
import java.io.OutputStream;

import org.apache.cxf.io.CachedOutputStream;

/**
 * Cr�ation d'un CachedOutputStream permettant de switcher l'�criture entre le cache et le flux de sortie
 * 
 * @author bperrard
 *
 */
public class CacheWriteSwitcherOutputStream extends CachedOutputStream {

	private boolean writeToCache = true;
	private OutputStream flowThroughStream;
	private long count;
	private long limit = Long.MAX_VALUE;

	public CacheWriteSwitcherOutputStream(OutputStream stream) {
		super();
		if (stream == null) {
			throw new IllegalArgumentException("Stream may not be null");
		}
		flowThroughStream = stream;
	}

	/**
	 * Permet de switcher entre le cache et le flux de sortie
	 * 
	 * @param writeToCache
	 */
	public void setSwitchWriting(final boolean writeToCache) {
		this.writeToCache = writeToCache;
	}

	public void setCacheLimit(long l) {
		limit = l;
	}

	public void closeFlowthroughStream() throws IOException {
		flowThroughStream.flush();
		flowThroughStream.close();
	}

	protected void postClose() throws IOException {
		flowThroughStream.flush();
		flowThroughStream.close();
	}

	public OutputStream getFlowThroughStream() {
		return flowThroughStream;
	}

	@Override
	protected void onWrite() throws IOException {
		// does nothing
	}

	@Override
	public void write(int b) throws IOException {
		if (!writeToCache) {
			flowThroughStream.write(b);
		} else if (count <= limit) {
			super.write(b);
			count++;
		}
	}

	@Override
	public void write(byte[] b, int off, int len) throws IOException {
		if (!writeToCache) {
			flowThroughStream.write(b, off, len);
		} else if (count <= limit) {
			super.write(b, off, len);
			count += len;
		}
	}

	@Override
	public void write(byte[] b) throws IOException {
		if (!writeToCache) {
			flowThroughStream.write(b);
		} else if (count <= limit) {
			super.write(b);
			count += b.length;
		}
	}
}
