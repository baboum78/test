package com.soliste.bolbec.commun.service.api.exception;

import javax.ejb.EJBException;
import javax.ws.rs.core.Response;

/**
 * APIException
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>30/11/2015</TD><TD>MFA</TD><TD>Initialisation APIException</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 **/
public class APIException extends EJBException {

	private static final long serialVersionUID = 7157620391707545646L;

	private Response reponse;

	/**
	 * APIException
	 * 
	 * @param reponse
	 */
	public APIException(Response reponse) {
		super();
		this.reponse = reponse;
	}

	/**
	 * @return the reponse
	 */
	public Response getReponse() {
		return reponse;
	}

}
