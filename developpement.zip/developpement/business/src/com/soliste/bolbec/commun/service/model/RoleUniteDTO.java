package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.RoleUnite;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * RoleUniteDTO: Table relation entre UniteActivite et Role
 * fait partie de l'espace de r�f�rence
 */
public class RoleUniteDTO implements java.io.Serializable {

	private String id;
	private UniteActiviteDTO uniteActivite;
	private RoleDTO role;

	/**
	 * 
	 * @param id
	 */
	public RoleUniteDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public RoleUniteDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(RoleUnite.FIELD_ID);
		EntityProxy ua = (EntityProxy) ep.getLinkedObject(RoleUnite.SLINK_GERE_PAR_UNITE_ACTIVITE);
		if (ua != null) {
			this.uniteActivite = new UniteActiviteDTO(ua);
		}
		EntityProxy r = (EntityProxy) ep.getLinkedObject(RoleUnite.SLINK_COUVRE_ROLE);
		if (r != null) {
			this.role = new RoleDTO(r);
		}
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public UniteActiviteDTO getUniteActivite() {
		return uniteActivite;
	}

	public RoleDTO getRole() {
		return role;
	}

}
