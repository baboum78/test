package com.soliste.bolbec.commun.service.interfaces.util.cxf;

import java.io.IOException;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.common.util.CollectionUtils;
import org.apache.cxf.headers.Header;
import org.apache.cxf.helpers.IOUtils;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.io.CachedOutputStreamCallback;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.constante.SoapTrameType;
import com.soliste.bolbec.commun.service.model.MessageWebSrvInDTO;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Intercepteur capturant les fault sortant
 * 
 * @author vDelamarre
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/10/2013</TD><TD>VDE</TD><TD>Migration : Ajout Intercepteurs CXF</TD></TR>
 * </TABLE>
 */
public class InterceptorOutFaultCallBack implements CachedOutputStreamCallback {
	private static final String CLASS_NAME = ArchivingInterceptorInMessage.class.getName();

	ArchivingInterceptorFaultOut archivingInterceptorFaultOut = null;

	Archivable messageToArchive = null;

	String service;

	private List<Header> lstHeader;

	/**
	 * Constructeur appell� par ArchivingInterceptorOut
	 * 
	 * @param archivingInterceptorOut
	 */
	public InterceptorOutFaultCallBack(ArchivingInterceptorFaultOut archivingInterceptorOut, String service, List<Header> lstHeader) {
		this.archivingInterceptorFaultOut = archivingInterceptorOut;
		this.service = service;
		this.lstHeader = lstHeader;
	}

	@Override
	public void onClose(CachedOutputStream cos) {
		final String method = "onClose";
		if (cos != null) {
			try {
				String xml = IOUtils.toString(cos.getInputStream());
				System.out.println("Response XML in out Interceptor : " + xml);

				String request = null;
				String idCommande = null;
				if (!CollectionUtils.isEmpty(lstHeader)) {
					for (Header header: lstHeader) {
						try {
							if (header.getName().toString().contains(Constantes.HEADER_ROU_MESSAGE_IN)) {
								request = (String) header.getObject();
							} else if (header.getName().toString().contains(Constantes.HEADER_LIV_REF_COMMANDE)) {
								idCommande = (String) header.getObject();
							}
						} catch (Exception e) {
							LoggerManager.getInstance().finest(CLASS_NAME, method, "Erreur lors de la recup�ration des donn�es de la table MESSAGEWEBSRVIN");
						}
					}
				}
				if (StringUtils.isNotBlank(request) && !request.contains(Constantes.HEADER_ROU_EMETTEUR)) {
					messageToArchive = new MessageWebSrvInDTO(service, SoapTrameType.Request, request, idCommande);
					archivingInterceptorFaultOut.archive(messageToArchive);
					messageToArchive = new MessageWebSrvInDTO(service, SoapTrameType.Fault, xml, idCommande);
					archivingInterceptorFaultOut.archive(messageToArchive);
				}


			} catch (ArchivingException e) {
				LoggerManager.getInstance().severe(CLASS_NAME, method, "Probl�me lors de l'archivage de la trame : " + messageToArchive, e);
			} catch (IOException e) {
				LoggerManager.getInstance().severe(CLASS_NAME, method, "Probl�me lors de l'interception du Stream", e);
			}
		}

	}

	@Override
	public void onFlush(@SuppressWarnings("unused") CachedOutputStream arg0) {
		// do nothing
	}

}
