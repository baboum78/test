/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.commun.data;

import java.io.Serializable;

/**
 * D�finit les pr�f�rences utilisateur pour une colonne d'une table. La colonne
 * est identifi�e par sa cl� de titre.
 * 
 * @author rgvs7490
 */
public class Column implements Serializable {

	private String titleKey;
	private boolean visible;

	/**
	 * Constructeur.
	 * 
	 * @param titleKey la cl� de la colonne
	 * @param visible d�termine si l'utilisateur pr�f�re que cette colonne soit visible
	 * ou non.
	 */
	public Column(String titleKey, boolean visible) {
		this.titleKey = titleKey;
		this.visible = visible;
	}

	/**
	 * Retourne la visibilit� de la colonne
	 * 
	 * @return true si l'utilisateur pr�f�re voir cette colonne, false s'il la pr�f�re
	 * masqu�e
	 */
	public boolean isVisible() {
		return this.visible;
	}

	/**
	 * Modifie la visibilit� d'une colonne.
	 * 
	 * @param visible la nouvelle visibilit�
	 */
	void setVisible(boolean visible) {
		this.visible = visible;
	}

	/**
	 * Retourne la cl� de la colonne
	 * 
	 * @return la cl� de la colonne
	 */
	public String getTitleKey() {
		return this.titleKey;
	}

	/**
	 * Retourne la classe CSS correspondant � la pr�f�rence de visibilit� (cha�ne
	 * vide si la colonne est visible, "invisible" si la colonne est masqu�e)
	 * 
	 * @return la classe CSS correspondant � la pr�f�rence de visibilit�
	 */
	public String getCssClass() {
		return visible ? "" : "invisible";
	}
}
