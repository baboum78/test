package com.soliste.bolbec.commun.service.interfaces.util.cxf.accent;

import java.io.OutputStream;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CachedOutputStream;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.accent.callback.AccentTransformCallBack;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.CacheWriteSwitcherOutputStream;

/**
 * Intercepteur permettant de transformer les accents en code HTML des messages d'�mission SOAP (requ�tes, r�ponses et s�ponse fault)
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/02/2015</TD><TD>BPE</TD><TD>G9R0 Anticipation palliatif des potentiels probl�mes d'encoding avec les partenaires en WS Soap</TD></TR>
 * </TABLE>
 */
public class AccentXMLTransformInterceptor extends AbstractPhaseInterceptor<Message> {

	public AccentXMLTransformInterceptor() {
		super(Phase.PRE_STREAM);
	}

	/**
	 * Mise en place de l'intercepteur
	 */
	@Override
	public void handleMessage(Message message) throws Fault {
		// Nous r�cup�rons le message, ...
		OutputStream os = message.getContent(OutputStream.class);
		// ...nous l'encapsulons dans un objet OutPutStream qui g�re le cache
		final CachedOutputStream newOut = new CacheWriteSwitcherOutputStream(os);

		message.setContent(OutputStream.class, newOut);
		newOut.registerCallback(new AccentTransformCallBack());
	}

}
