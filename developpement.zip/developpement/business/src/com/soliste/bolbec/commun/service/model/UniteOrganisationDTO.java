package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.UniteOrganisation;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * UniteOrganisationDTO fait partie de l'espace de r�f�rence
 */
public class UniteOrganisationDTO implements java.io.Serializable {

	private String id;
	private TypeUniteDTO typeUnite;
	private UniteOrganisationDTO uniteOrganisation;
	private String adresse;
	private String email;
	private String libelle;
	private String telephone;

	/**
	 * 
	 * @param id
	 */
	public UniteOrganisationDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public UniteOrganisationDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(UniteOrganisation.FIELD_ID);
		this.adresse = (String) ep.getValue(UniteOrganisation.FIELD_ADRESSE);
		this.email = (String) ep.getValue(UniteOrganisation.FIELD_EMAIL);
		this.libelle = (String) ep.getValue(UniteOrganisation.FIELD_LIBELLE);
		this.telephone = (String) ep.getValue(UniteOrganisation.FIELD_TELEPHONE);
		EntityProxy uo = (EntityProxy) ep.getLinkedObject(UniteOrganisation.SLINK_DEPEND_DE_UNITE_ORGANISATION);
		if (uo != null) {
			this.uniteOrganisation = new UniteOrganisationDTO(uo);
		}
		EntityProxy tu = (EntityProxy) ep.getLinkedObject(UniteOrganisation.SLINK_EST_TYPE_UNITE);
		if (tu != null) {
			this.typeUnite = new TypeUniteDTO(tu);
		}
	}

	/**
	 * 
	 * @param uniteOrganisationId
	 * @param uniteOrganisationLibelle
	 */
	public UniteOrganisationDTO(String uniteOrganisationId, String uniteOrganisationLibelle) {
		this.id = uniteOrganisationId;
		this.libelle = uniteOrganisationLibelle;
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public TypeUniteDTO getTypeUnite() {
		return typeUnite;
	}

	public UniteOrganisationDTO getUniteOrganisation() {
		return uniteOrganisation;
	}

	public String getAdresse() {
		return adresse;
	}

	public String getEmail() {
		return email;
	}

	public String getLibelle() {
		return libelle;
	}

	public String getTelephone() {
		return telephone;
	}

}
