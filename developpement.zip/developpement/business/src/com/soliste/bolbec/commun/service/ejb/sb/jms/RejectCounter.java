/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Interface permettant de g�rer un compteur de rejets. Le compteur peut �tre
 * remis � z�ro.
 * 
 * @author rgvs7490
 */
public interface RejectCounter {

	/**
	 * 
	 */
	public void increment();

	/**
	 * 
	 */
	public void reset();

	/**
	 * 
	 * @return
	 */
	public int getValue();

}
