package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.ZoneSI;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * ZoneSiDTO fait partie de l'espace de r�f�rence
 */
public class ZoneSiDTO implements java.io.Serializable {

	private String id;
	private String libelleCourt;
	private String libelle;

	/**
	 * 
	 * @param id
	 */
	public ZoneSiDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public ZoneSiDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(ZoneSI.FIELD_ID);
		this.libelle = (String) ep.getValue(ZoneSI.FIELD_LIBELLE);
		this.libelleCourt = (String) ep.getValue(ZoneSI.FIELD_LIBELLE_COURT);
	}

	/**
	 * 
	 * @param id
	 * @param libelleCourt
	 * @param libelle
	 */
	public ZoneSiDTO(String id, String libelleCourt, String libelle) {
		this.id = id;
		this.libelleCourt = libelleCourt;
		this.libelle = libelle;
	}

	/**
	 * 
	 * @param zoneSI
	 */
	public ZoneSiDTO(ZoneSI zoneSI) {
		this.id = zoneSI.getId();
		this.libelleCourt = zoneSI.getLibelleCourt();
		this.libelle = zoneSI.getLibelle();
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public String getLibelleCourt() {
		return libelleCourt;
	}

	public String getLibelle() {
		return libelle;
	}

	/**
	 * @param libelleCourt the libelleCourt to set
	 */
	public void setLibelleCourt(String libelleCourt) {
		this.libelleCourt = libelleCourt;
	}

	/**
	 * @param libelle the libelle to set
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

}
