package com.soliste.bolbec.commun.service.model;

import com.soliste.bolbec.commun.service.constante.SoapTrameType;

/**
 * DTO d�crivant une trame SOAP � archiver c�t� routeur lors de l'appel d'un service externe
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public class MessageWebSrvOutDTO extends MessageWebSrvDTO {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 9117498323461050104L;

	/**
	 * Constructeur
	 * 
	 * @param service le service appel�
	 * @param typeMessage le type du message
	 * @param contenu la trame SOAP
	 */
	public MessageWebSrvOutDTO(String service, SoapTrameType typeMessage, String contenu, String refCommande) {
		super(service, typeMessage, contenu, refCommande);
	}

	/**
	 * R�cup�rer une image de l'objet sous forme de chaine
	 * 
	 * @return l'image de l'objet
	 */
	public String toString() {
		return "WebSrvOutDTO [dateMessage=" + dateMessage + ", service=" + service + ", typeMessage=" + typeMessage + ", contenu=" + contenu  + ", refCommande=" + refCommande + "]";
	}

}
