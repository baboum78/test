/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.commun.data;

import java.io.Serializable;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Les pr�f�rences utilisateur pour une table donn�e.
 * 
 * @author rgvs7490
 */
public class TablePreferences implements Serializable {

	/** The table key. */
	private String tableKey;

	/** The columns. */
	private LinkedHashMap<String, Column> columns = new LinkedHashMap<String, Column>();

	/** L'interligne. */
	private boolean interligne;

	/**
	 * Constructeur.
	 * 
	 * @param tableKey la cl� de la table
	 */
	public TablePreferences(String tableKey) {
		this.tableKey = tableKey;
	}

	/**
	 * Ajoute une colonne optionnelle (i.e. qui peut �tre masqu�e) aux pr�f�rences.
	 * La Map contenant les classes CSS des colonnes est �galement modifi�e par
	 * cette m�thode
	 * 
	 * @param titleKey la cl� de la colonne
	 * @param visible la visibilit� de la colonne
	 */
	public void addOptionalColumn(String titleKey, boolean visible) {
		Column column = new Column(titleKey, visible);
		this.columns.put(titleKey, column);
	}

	/**
	 * Modifie la visibilit� d'une colonne. La Map contenant les classes CSS
	 * des colonnes est �galement modifi�e par cette m�thode
	 * 
	 * @param titleKey la cl� de la colonne
	 * @param visible la nouvelle visibilit�
	 */
	public void setColumnVisible(String titleKey, boolean visible) {
		Column column = this.columns.get(titleKey);
		column.setVisible(visible);
	}

	/**
	 * Retourne les colonnes.
	 * 
	 * @return une collection d'instances de Column
	 */
	public Collection<Column> getColumns() {
		return columns.values();
	}

	/**
	 * Retourne une Map contenant, pour chaque cl� de colonne, un bool�en
	 * indiquant si la colonne est visible ou non
	 * � la visibilit� de cette colonne.
	 * 
	 * @return une Map de classes CSS
	 */
	public Map<String, Boolean> getVisibilityMap() {
		Map<String, Boolean> map = new HashMap<String, Boolean>();
		for (Iterator<Column> it = getColumns().iterator(); it.hasNext();) {
			Column c = it.next();
			map.put(c.getTitleKey(), Boolean.valueOf(c.isVisible()));
		}
		return map;
	}

	/**
	 * Retourne la cl� de la table.
	 * 
	 * @return la cl� de la table
	 */
	public String getTableKey() {
		return this.tableKey;
	}

	/**
	 * Retourne un bool�en repr�sentant la pr�f�rence d'affichage avec interligne r�duit.
	 * 
	 * @return bool
	 */
	public boolean setInterligne() {
		if (columns.get("Corbeille.info.interligne") == null) {
			return this.interligne;
		}
		this.interligne = columns.get("Corbeille.info.interligne").isVisible();
		return this.interligne;
	}
}
