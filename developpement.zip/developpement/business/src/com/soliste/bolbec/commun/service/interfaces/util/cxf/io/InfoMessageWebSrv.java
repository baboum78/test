package com.soliste.bolbec.commun.service.interfaces.util.cxf.io;

/**
 * Classe pour envoyer les donn�es n�cessaires aux tables MessageWebService IN et OUT
 */
public class InfoMessageWebSrv {
	private String refCommande;

	public InfoMessageWebSrv () {
		refCommande = "";
	}

	public InfoMessageWebSrv (String refCommande) {
		this.refCommande = refCommande;
	}

	public String getRefCommande() {
		return refCommande;
	}

	public void setRefCommande(String refCommande) {
		this.refCommande = refCommande;
	}
}
