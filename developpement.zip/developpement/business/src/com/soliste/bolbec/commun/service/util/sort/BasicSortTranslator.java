/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.util.sort;

/**
 * Impl�mentation basique de AbstractSortTranslator, dans laquelle la commande
 * de tri est traduite en "&lt;sortCriterion&gt; &lt;direction&gt;". La requ�te
 * utilis�e doit donc ressembler �
 * <code>SELECT foo.a, foo.b, foo.c FROM foo ORDER BY $SORT$</code
 * 
 * @author rgvs7490
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/02/2010</TD><TD>DBA</TD><TD>EV-000029: Gestion de plusieurs tris au lieu de 1</TD></TR>
 * </TABLE>
 */
public abstract class BasicSortTranslator extends AbstractSortTranslator {

	/**
	 * Traduit la commande de tri en "&lt;sortCriterion&gt;". Le
	 * sortCriterion plac� derri�re order by est obtenu par la m�thode
	 * translatSortCriterion.
	 * 
	 * @see com.soliste.bolbec.commun.service.util.sort.AbstractSortTranslator#translate(bolbec.ihm.common.sort.SortCommand)
	 */
	protected String translate(SortCommand sortCommand) {
		StringBuffer buffer = new StringBuffer();
		// EV-000029: Gestion du multi-tri
		for (String crit : sortCommand.getCriterion()) {
			if (crit != null) {
				buffer.append(translateSortCriterion(crit));
				buffer.append(" ");
				buffer.append(sortCommand.getDirection());
				buffer.append(",");
			}
		}
		if (buffer.length() > 0) {
			return buffer.substring(0, buffer.length() - 1).toString();
		}
		return "";

	}

	/**
	 * Traduit le sortCriterion en son �quivalent SQL. Cette impl�mentation par
	 * d�faut retourne le sortCriterion tel quel.
	 * 
	 * @param sortCriterion le crit�re de tri � traduire
	 * @return sortCriterion
	 */
	protected String translateSortCriterion(String sortCriterion) {
		return sortCriterion;
	}
}
