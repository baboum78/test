package com.soliste.bolbec.commun.service.util.jdbc;

import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Interface permettant de transformer une ligne de base de donn�es en objet.
 * 
 * @author rgvs7490
 */
public interface RowMapper<T> {

	/**
	 * Transforme la ligne courante du ResultSet donn� en objet. Les impl�mentations
	 * ne doivent pas appeler next() ou toute autre m�thode modifiant la position
	 * ou l'�tat du ResultSet
	 * 
	 * @param rs le ResultSet contenant la ligne � transformer.
	 * @return l'objet correspondant � la ligne courante
	 * @throws SQLException si une exception SQL survient
	 */
	public T mapRow(ResultSet rs) throws SQLException;
}
