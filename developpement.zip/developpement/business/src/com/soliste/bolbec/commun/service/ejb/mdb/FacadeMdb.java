/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.mdb;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.MessageDrivenBean;
import javax.ejb.MessageDrivenContext;
import javax.jms.Message;
import javax.jms.MessageListener;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.ejb.sb.jms.MessageHandlerLocal;
import com.soliste.bolbec.commun.service.ejb.sb.jms.MessageHandlerLocalHome;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * MDB lisant recevant un message d'une queue et d�l�guant son traitement �
 * un session bean "MessageHandlerLocal".
 * Il a besoin des entr�es suivantes dans son descripteur de d�ploiement:
 * <pre>
 * &lt;ejb-local-ref&gt;
 * &lt;ejb-ref-name&gt;ejb/MessageHandler&lt;/ejb-ref-name&gt;
 * &lt;ejb-ref-type&gt;Session&lt;/ejb-ref-type&gt;
 * &lt;local-home&gt;com.soliste.bolbec.commun.service.ejb.sb.jms.MessageHandlerLocalHome&lt;/local-home&gt;
 * &lt;local&gt;com.soliste.bolbec.commun.service.ejb.sb.jms.MessageHandlerLocal&lt;/local&gt;
 * &lt;ejb-link&gt;[nom du bean (ejb-name) g�rant les messages de cette queue]&lt;/ejb-link&gt;
 * &lt;/ejb-local-ref&gt;
 * </pre>
 * 
 * @author rgvs7490
 */
public class FacadeMdb implements MessageListener, MessageDrivenBean {

	private static final String MESSAGE_HANDLER_NAME = "java:comp/env/ejb/MessageHandler";

	protected MessageDrivenContext messageDrivenContext;
	private MessageHandlerLocal messageHandler;

	/**
	 * @see javax.jms.MessageListener#onMessage(javax.jms.Message)
	 */
	public void onMessage(Message message) {
		messageHandler.onMessage(message);
	}

	/**
	 * @see javax.ejb.MessageDrivenBean#setMessageDrivenContext(javax.ejb.MessageDrivenContext)
	 */
	public void setMessageDrivenContext(MessageDrivenContext messageDrivenContext) {
		this.messageDrivenContext = messageDrivenContext;
		try {
			InitialContext initCtx = new InitialContext();
			MessageHandlerLocalHome messageHandlerHome = (MessageHandlerLocalHome) initCtx.lookup(MESSAGE_HANDLER_NAME);
			this.messageHandler = messageHandlerHome.create();
		} catch (NamingException e) {
			throw new EJBException(e);
		} catch (CreateException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * 
	 */
	public void ejbCreate() {
	}

	/**
	 * @see javax.ejb.MessageDrivenBean#ejbRemove()
	 */
	public void ejbRemove() {
	}
}
