/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.ejb.sb.agent;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import aps.Agent;
import aps.AgentHome;
import aps.Habilitation;
import aps.UniteActiviteHome;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.HabilitationDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.commun.service.model.UniteActiviteDTO;
import com.soliste.bolbec.commun.service.util.ReferenceSpaceNavigatorAdaptateur;
import com.soliste.bolbec.commun.service.util.jdbc.RowMapper;
import com.soliste.bolbec.commun.service.util.pagination.PaginatedList;
import com.soliste.bolbec.commun.service.util.pagination.PaginationCommand;
import com.soliste.bolbec.commun.service.util.pagination.PaginationUtil;
import com.soliste.bolbec.commun.service.util.sort.AgentSortCommand;
import com.soliste.bolbec.commun.service.util.sort.BasicSortTranslator;
import com.soliste.bolbec.commun.service.util.sort.SortTranslator;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.jndi.ServiceLocator;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.EncryptionUtils;
import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * Impl�mentation de l'EJB session AgentManager.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/10/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV000183 - Apostrof Corbeille IHM BIS</TD></TR>
 * <TR><TD>13/05/2013</TD><TD>EBA</TD><TD>G8R2C1 - DE-000824 (334 FT) : La cr�ation d'un nouvel utilisateur depuis une IHM G8R2 g�n�re une exception</TD></TR>
 * <TR><TD>15/10/2013</TD><TD>BPE</TD><TD>DE-000952 : Nouvelle methode ejb findAgentById</TD></TR>
 * </TABLE><BR>
 * 
 * @author rgvs7490
 */
public class AgentManagerBean extends FwkSessionBean implements AgentManager {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = -4374955108221258253L;

	/** The Constant TOUS_ROLES. */
	private static final String TOUS_ROLES = "TOUSROLES";

	/** The agent home. */
	private AgentHome agentHome;

	/** The unite activite home. */
	private UniteActiviteHome uniteActiviteHome;

	/** The data source. */
	private DataSource dataSource;

	/** The Constant COUNT_ALL_QUERY. */
	private static final String COUNT_ALL_QUERY = "SELECT count(DISTINCT a.id) FROM Agent a" + " WHERE a.gerable = 1";

	/** The Constant ALL_QUERY. */
	private static final String ALL_QUERY = "SELECT DISTINCT a.id AS id, a.actif AS actif, a.dateSupp AS dateSupp, a.email AS email, "
			+ "a.fax AS fax, a.nom AS nom, a.prenom AS prenom, a.telephone AS telephone, ua.id AS uniteActiviteId, ua.libelle AS uniteActiviteLibelle, "
			+ "uo.id AS uniteOrganisationId, uo.libelle AS uniteOrganisationLibelle, a.modifNote AS modifNote FROM Agent a LEFT JOIN UniteActivite ua ON a.fk_appartientUniteActivite = ua.id"
			+ " LEFT JOIN UniteOrganisation uo ON ua.fk_rattacheAUniteOrganisation = uo.id WHERE a.gerable = 1 ORDER BY $SORT$";

	/** The Constant COUNT_BY_ID_QUERY. */
	private static final String COUNT_BY_ID_QUERY = "SELECT count(DISTINCT a.id) FROM Agent a WHERE a.gerable = 1 AND UPPER(a.id) LIKE ?";

	/** The Constant BY_ID_QUERY. */
	private static final String BY_ID_QUERY = "SELECT DISTINCT a.id AS id, a.actif AS actif, a.dateSupp AS dateSupp, a.email AS email, "
			+ "a.fax AS fax, a.nom AS nom, a.prenom AS prenom, a.telephone AS telephone, ua.id AS uniteActiviteId, ua.libelle AS uniteActiviteLibelle, "
			+ "uo.id AS uniteOrganisationId, uo.libelle AS uniteOrganisationLibelle, a.modifNote AS modifNote FROM Agent a LEFT JOIN UniteActivite ua ON a.fk_appartientUniteActivite = ua.id"
			+ " LEFT JOIN UniteOrganisation uo ON ua.fk_rattacheAUniteOrganisation = uo.id WHERE a.gerable = 1 AND UPPER(a.id) LIKE ? ORDER BY $SORT$";

	/** The Constant COUNT_BY_NOM_QUERY. */
	private static final String COUNT_BY_NOM_QUERY = "SELECT count(DISTINCT a.id) FROM Agent a WHERE a.gerable = 1 AND UPPER(a.nom) LIKE ?";

	/** The Constant BY_NOM_QUERY. */
	private static final String BY_NOM_QUERY = "SELECT DISTINCT a.id AS id, a.actif AS actif, a.dateSupp AS dateSupp, a.email AS email, "
			+ "a.fax AS fax, a.nom AS nom, a.prenom AS prenom, a.telephone AS telephone, ua.id AS uniteActiviteId, ua.libelle AS uniteActiviteLibelle, "
			+ "uo.id AS uniteOrganisationId, uo.libelle AS uniteOrganisationLibelle, a.modifNote AS modifNote FROM Agent a LEFT JOIN UniteActivite ua ON a.fk_appartientUniteActivite = ua.id"
			+ " LEFT JOIN UniteOrganisation uo ON ua.fk_rattacheAUniteOrganisation = uo.id WHERE a.gerable = 1 AND UPPER(a.nom) LIKE ? ORDER BY $SORT$";

	/** The Constant COUNT_BY_UNITE_ACTIVITE_ID_QUERY. */
	private static final String COUNT_BY_UNITE_ACTIVITE_ID_QUERY = "SELECT count(DISTINCT a.id) FROM Agent a WHERE a.gerable = 1 AND UPPER(a.fk_appartientUniteActivite) LIKE ?";

	/** The Constant BY_UNITE_ACTIVITE_ID_QUERY. */
	private static final String BY_UNITE_ACTIVITE_ID_QUERY = "SELECT DISTINCT a.id AS id, a.actif AS actif, a.dateSupp AS dateSupp, a.email AS email, "
			+ "a.fax AS fax, a.nom AS nom, a.prenom AS prenom, a.telephone AS telephone, ua.id AS uniteActiviteId, ua.libelle AS uniteActiviteLibelle, "
			+ "uo.id AS uniteOrganisationId, uo.libelle AS uniteOrganisationLibelle, a.modifNote AS modifNote FROM Agent a LEFT JOIN UniteActivite ua ON a.fk_appartientUniteActivite = ua.id"
			+ " LEFT JOIN UniteOrganisation uo ON ua.fk_rattacheAUniteOrganisation = uo.id WHERE a.gerable = 1 AND UPPER(a.fk_appartientUniteActivite) LIKE ? ORDER BY $SORT$";

	/** The Constant COUNT_BY_UNITE_ORGANISATION_ID_QUERY. */
	private static final String COUNT_BY_UNITE_ORGANISATION_ID_QUERY = "SELECT count(DISTINCT a.id) FROM Agent a LEFT JOIN UniteActivite ua ON a.fk_appartientUniteActivite = ua.id"
			+ " LEFT JOIN UniteOrganisation uo ON ua.fk_rattacheAUniteOrganisation = uo.id WHERE a.gerable = 1 AND UPPER(ua.fk_rattacheAUniteOrganisation) LIKE ?";

	/** The Constant BY_UNITE_ORGANISATION_ID_QUERY. */
	private static final String BY_UNITE_ORGANISATION_ID_QUERY = "SELECT DISTINCT a.id AS id, a.actif AS actif, a.dateSupp AS dateSupp, a.email AS email, "
			+ "a.fax AS fax, a.nom AS nom, a.prenom AS prenom, a.telephone AS telephone, ua.id AS uniteActiviteId, ua.libelle AS uniteActiviteLibelle, "
			+ "uo.id AS uniteOrganisationId, uo.libelle AS uniteOrganisationLibelle, a.modifNote AS modifNote FROM Agent a LEFT JOIN UniteActivite ua ON a.fk_appartientUniteActivite = ua.id"
			+ " LEFT JOIN UniteOrganisation uo ON ua.fk_rattacheAUniteOrganisation = uo.id WHERE a.gerable = 1 AND UPPER(ua.fk_rattacheAUniteOrganisation) LIKE ? ORDER BY $SORT$";

	/** The agent sort translator. */
	private static SortTranslator agentSortTranslator = new BasicSortTranslator() {

		protected String translateSortCriterion(String sortCriterion) {
			if (AgentSortCommand.ACTIF_SORT.equals(sortCriterion)) {
				return "a.actif";
			} else if (AgentSortCommand.EMAIL_SORT.equals(sortCriterion)) {
				return "a.email";
			} else if (AgentSortCommand.FAX_SORT.equals(sortCriterion)) {
				return "a.fax";
			} else if (AgentSortCommand.NOM_SORT.equals(sortCriterion)) {
				return "a.nom";
			} else if (AgentSortCommand.PRENOM_SORT.equals(sortCriterion)) {
				return "a.prenom";
			} else if (AgentSortCommand.TELEPHONE_SORT.equals(sortCriterion)) {
				return "a.telephone";
			} else if (AgentSortCommand.UNITE_ACTIVITE_ID_SORT.equals(sortCriterion)) {
				return "ua.id";
			} else if (AgentSortCommand.UNITE_ACTIVITE_LIBELLE_SORT.equals(sortCriterion)) {
				return "ua.libelle";
			} else if (AgentSortCommand.UNITE_ORGANISATION_ID_SORT.equals(sortCriterion)) {
				return "uo.id";
			} else if (AgentSortCommand.UNITE_ORGANISATION_LIBELLE_SORT.equals(sortCriterion)) {
				return "uo.libelle";
			} else {
				return "a.id";
			}
		}
	};

	/** The agent row mapper. */
	private static RowMapper<AgentDTO> agentRowMapper = new RowMapper<AgentDTO>() {

		public AgentDTO mapRow(ResultSet rs) throws SQLException {
			String id = rs.getString(1);
			boolean actif = ("1".equals(rs.getString(2)));
			Date dateSupp = DateUtils.getDatabaseDate(Long.valueOf(rs.getLong(3)));
			String email = rs.getString(4);
			String fax = rs.getString(5);
			String nom = rs.getString(6);
			String prenom = rs.getString(7);
			String telephone = rs.getString(8);
			String uniteActiviteId = rs.getString(9);
			String uniteActiviteLibelle = rs.getString(10);
			String uniteOrganisationId = rs.getString(11);
			String uniteOrganisationLibelle = rs.getString(12);
			boolean modifNote = ("1".equals(rs.getString(13)));
			return new AgentDTO(id, actif, dateSupp, email, fax, nom, prenom, telephone, uniteActiviteId, uniteActiviteLibelle, uniteOrganisationId, uniteOrganisationLibelle, modifNote);
		}
	};

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#getAgent(java.lang.String)
	 */
	public AgentDTO getAgent(String id) {
		try {
			Agent agent = agentHome.findByPrimaryKey(new EntityBeanPK(id));
			return new AgentDTO(agent);
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#findAgentById(java.lang.String)
	 */
	public AgentDTO findAgentById(String id) {
		try {
			Agent agent = agentHome.findByPrimaryKey(new EntityBeanPK(id));
			return new AgentDTO(agent);
		} catch (FinderException e) {
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#insertAgent(java.lang.String, boolean, java.lang.String, java.lang.String, boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String,
	 * boolean)
	 */
	public void insertAgent(String id, boolean actif, String email, String fax, boolean gerable, String mdp, String nom, String prenom, String telephone, String uniteActiviteId, String modifNote) {
		try {
			HashMap<String, Object> values = new HashMap<String, Object>(9);
			if (!actif) {
				values.put(Agent.FIELD_ACTIF, "0");
				values.put(Agent.FIELD_DATE_SUPP, DateUtils.getDatabaseDate());
			} else {
				values.put(Agent.FIELD_ACTIF, "1");
				values.put(Agent.FIELD_DATE_SUPP, null);
			}

			values.put(Agent.FIELD_EMAIL, email);
			values.put(Agent.FIELD_FAX, fax);
			values.put(Agent.FIELD_GERABLE, (gerable) ? "1" : "0");
			values.put(Agent.FIELD_MOT_DE_PASSE, mdp);
			values.put(Agent.FIELD_NOM, nom);
			values.put(Agent.FIELD_PRENOM, prenom);
			values.put(Agent.FIELD_TELEPHONE, telephone);
			values.put(Agent.FIELD_MODIF_NOTE, modifNote);

			Agent agent = agentHome.create(id, values);
			agent.setLinkAppartientUniteActivite(uniteActiviteHome.findByPrimaryKey(new EntityBeanPK(uniteActiviteId)));
		} catch (CreateException e) {
			throw new EJBException(e);
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#updateAgent(java.lang.String, boolean, java.lang.String, java.lang.String, boolean, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public void updateAgent(String id, boolean actif, String email, String fax, boolean gerable, String mdp, String nom, String prenom, String telephone, String uniteActiviteId, int modifNote) {
		try {
			Agent agent = agentHome.findByPrimaryKey(new EntityBeanPK(id));
			if (!actif) {
				if ("1".equals(agent.getActif())) {
					agent.setActif("0");
					agent.setDateSupp(DateUtils.getDatabaseDate());
				}
			} else {
				if ("0".equals(agent.getActif())) {
					agent.setActif("1");
					agent.setDateSupp(null);
				}
			}
			agent.setEmail(email);
			agent.setFax(fax);
			agent.setGerable((gerable) ? "1" : "0");
			// le mot de passe n'est mis � jour que s'il est renseign�
			if (mdp != null && mdp.length() > 0) {
				agent.setMotDePasse(mdp);
			}
			agent.setNom(nom);
			agent.setPrenom(prenom);
			agent.setTelephone(telephone);
			agent.setModifNote(String.valueOf(modifNote));
			agent.setLinkAppartientUniteActivite(uniteActiviteHome.findByPrimaryKey(new EntityBeanPK(uniteActiviteId)));
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#deleteAgent(java.lang.String)
	 */
	public void deleteAgent(String id) {
		try {
			Agent agent = this.agentHome.findByPrimaryKey(new EntityBeanPK(id));
			agent.setActif("0");
			agent.setDateSupp(DateUtils.getDatabaseDate());
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#getCurrentAgent(java.lang.String, java.lang.String)
	 */
	public AgentDTO getCurrentAgent(String login, String applicationName) {
		AgentDTO agentDTO = ReferenceSpaceNavigatorAdaptateur.findInReferenceSpace(AgentDTO.class, login);
		if (agentDTO != null) {
			Map<String, Boolean> habilitations = getHabilitations(agentDTO, applicationName);
			agentDTO.setHabilitations(habilitations);
		}

		return agentDTO;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#authenticateAgent(java.lang.String, java.lang.String, java.lang.String)
	 */
	public AgentDTO authenticateAgent(String id, String password, String applicationName) {
		AgentDTO agentDTO = ReferenceSpaceNavigatorAdaptateur.findInReferenceSpace(AgentDTO.class, id);
		if (agentDTO != null && StringUtils.equals(password, EncryptionUtils.clear(agentDTO.getMotDePasse()))) {
			Map<String, Boolean> habilitations = getHabilitations(agentDTO, applicationName);
			agentDTO.setHabilitations(habilitations);
			return agentDTO;
		}
		return null;
	}

	/**
	 * Gets the habilitations.
	 * 
	 * @param applicationName the application name
	 * @param agentDTO the agent dto
	 * 
	 * @return the habilitations
	 */
	private Map<String, Boolean> getHabilitations(AgentDTO agentDTO, final String applicationName) {
		Set<String> roleIds = getRoleIds(agentDTO);
		Map<String, Boolean> result = new HashMap<String, Boolean>();
		List<HabilitationDTO> habilitations = ReferenceSpaceNavigatorAdaptateur.listInReferenceSpace(HabilitationDTO.class, Habilitation.FIELD_APPLICATION, applicationName);
		for (HabilitationDTO habilitationDTO : habilitations) {
			List<RoleDTO> roles = habilitationDTO.getRoles();
			boolean found = false;
			for (Iterator<RoleDTO> roleHabilitationIt = roles.iterator(); roleHabilitationIt.hasNext() && !found;) {
				RoleDTO role = roleHabilitationIt.next();
				String roleId = role.getId();
				if (TOUS_ROLES.equals(roleId)) {
					found = true;
				} else if (roleIds.contains(roleId)) {
					found = true;
				}
			}
			result.put(habilitationDTO.getId(), found);
		}
		return Collections.unmodifiableMap(result);
	}

	/**
	 * Gets the role ids.
	 * 
	 * @param agentDTO the agent dto
	 * 
	 * @return the role ids
	 */
	private Set<String> getRoleIds(AgentDTO agentDTO) {
		Set<String> result = new HashSet<String>();
		UniteActiviteDTO uniteActiviteDTO = agentDTO.getUniteActivite();
		List<RoleDTO> roles = uniteActiviteDTO.getRoles();
		for (RoleDTO roleDTO : roles) {
			result.add(roleDTO.getId());
		}
		return result;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#searchAll(com.soliste.bolbec.commun.service.util.pagination.PaginationCommand, com.soliste.bolbec.commun.service.util.sort.AgentSortCommand)
	 */
	public PaginatedList<AgentDTO> searchAll(PaginationCommand paginationCommand, AgentSortCommand sortCommand) {
		try {
			return PaginationUtil.search(this.dataSource, COUNT_ALL_QUERY, ALL_QUERY, null, paginationCommand, sortCommand, agentSortTranslator, agentRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#searchById(java.lang.String, com.soliste.bolbec.commun.service.util.pagination.PaginationCommand, com.soliste.bolbec.commun.service.util.sort.AgentSortCommand)
	 */
	public PaginatedList<AgentDTO> searchById(String id, PaginationCommand paginationCommand, AgentSortCommand sortCommand) {
		try {
			return PaginationUtil.search(this.dataSource, COUNT_BY_ID_QUERY, BY_ID_QUERY, new Object[] { id.toUpperCase() + '%' }, paginationCommand, sortCommand, agentSortTranslator, agentRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#searchByNom(java.lang.String, com.soliste.bolbec.commun.service.util.pagination.PaginationCommand, com.soliste.bolbec.commun.service.util.sort.AgentSortCommand)
	 */
	public PaginatedList<AgentDTO> searchByNom(String nom, PaginationCommand paginationCommand, AgentSortCommand sortCommand) {
		try {
			return PaginationUtil.search(this.dataSource, COUNT_BY_NOM_QUERY, BY_NOM_QUERY, new Object[] { nom.toUpperCase() + '%' }, paginationCommand, sortCommand, agentSortTranslator, agentRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#searchByUniteActiviteId(java.lang.String, com.soliste.bolbec.commun.service.util.pagination.PaginationCommand,
	 * com.soliste.bolbec.commun.service.util.sort.AgentSortCommand)
	 */
	public PaginatedList<AgentDTO> searchByUniteActiviteId(String uniteActiviteId, PaginationCommand paginationCommand, AgentSortCommand sortCommand) {
		try {
			return PaginationUtil.search(this.dataSource, COUNT_BY_UNITE_ACTIVITE_ID_QUERY, BY_UNITE_ACTIVITE_ID_QUERY, new Object[] { uniteActiviteId.toUpperCase() + '%' }, paginationCommand, sortCommand, agentSortTranslator, agentRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.agent.AgentManager#searchByUniteOrganisationId(java.lang.String, com.soliste.bolbec.commun.service.util.pagination.PaginationCommand,
	 * com.soliste.bolbec.commun.service.util.sort.AgentSortCommand)
	 */
	public PaginatedList<AgentDTO> searchByUniteOrganisationId(String uniteOrganisationId, PaginationCommand paginationCommand, AgentSortCommand sortCommand) {
		try {
			return PaginationUtil.search(this.dataSource, COUNT_BY_UNITE_ORGANISATION_ID_QUERY, BY_UNITE_ORGANISATION_ID_QUERY, new Object[] { uniteOrganisationId.toUpperCase() + '%' }, paginationCommand, sortCommand, agentSortTranslator, agentRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			agentHome = getEntityHome(AgentHome.class);
			uniteActiviteHome = getEntityHome(UniteActiviteHome.class);
			dataSource = ServiceLocator.getInstance().getDataSource(Constantes.DATASOURCE_NAME);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}
}
