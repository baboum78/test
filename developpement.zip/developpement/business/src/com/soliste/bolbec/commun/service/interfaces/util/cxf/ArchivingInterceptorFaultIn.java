package com.soliste.bolbec.commun.service.interfaces.util.cxf;

import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.message.Message;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.service.model.OperationInfo;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.constante.SoapTrameType;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.InfoMessageWebSrv;
import com.soliste.bolbec.commun.service.model.MessageWebSrvOutDTO;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Intercepteur capturant les fault entrantes
 * 
 * @author vDelamarre
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/10/2013</TD><TD>VDE</TD><TD>Migration : Ajout Intercepteurs CXF</TD></TR>
 * </TABLE>
 */
public abstract class ArchivingInterceptorFaultIn extends AbstractPhaseInterceptor<Message> {

	private static final String CLASS_NAME = ArchivingInterceptorFaultIn.class.getName();
	private InfoMessageWebSrv infoMessageWebSrv = new InfoMessageWebSrv();

	/**
	 * 
	 */
	public ArchivingInterceptorFaultIn(InfoMessageWebSrv infoMessageWebSrv) {
		super(Phase.POST_PROTOCOL);
		if (infoMessageWebSrv != null) {
			this.infoMessageWebSrv = infoMessageWebSrv;
		}
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		final String method = "handleMessage";
		OperationInfo opInfo = null;
		String operationName = "";
		if (message.getExchange() != null) {
			opInfo = message.getExchange().get(OperationInfo.class);
			if (opInfo != null) {
				if (opInfo.getName() != null) {
					operationName = opInfo.getName().getLocalPart();
				}
			}
		}
		String xml = (String) message.get(Constantes.XMLMESSAGE);
		message.remove(Constantes.XMLMESSAGE);
		Archivable messageToArchive = null;
		LoggerManager.getInstance().finest(CLASS_NAME, method, "XML Fault : " + xml);
		messageToArchive = new MessageWebSrvOutDTO(operationName, SoapTrameType.Fault, xml, infoMessageWebSrv.getRefCommande());
		try {
			archive(messageToArchive);
		} catch (ArchivingException e) {
			LoggerManager.getInstance().severe(CLASS_NAME, method, "Probl�me lors de l'archivage de la trame : " + messageToArchive, e);
		}

	}

	/**
	 * 
	 * @param archivable
	 * @throws ArchivingException
	 */
	public abstract void archive(Archivable archivable) throws ArchivingException;

}
