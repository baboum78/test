package com.soliste.bolbec.commun.service.ejb.sb.archiving;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

public interface ArchivingManagerRemoteHome extends EJBHome {
		/**
		 *
		 * @return
		 * @throws CreateException
		 */
		public ArchivingManagerRemote create() throws CreateException, RemoteException;
	}
