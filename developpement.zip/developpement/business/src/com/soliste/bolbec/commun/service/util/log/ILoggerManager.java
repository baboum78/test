package com.soliste.bolbec.commun.service.util.log;

import java.util.logging.Level;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>16/09/2010</TD><TD>GPA</TD><TD>EV-000053: Ajout du champ commandeId dans la signature qualif(...)</TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * </TABLE>
 * 
 */
public interface ILoggerManager {

	/**
	 * D�termine si le mode debug est activ� ou pas. <br>
	 * La g�n�ration de traces de bas niveau (finer, fine) - particuli�rement si
	 * cette g�n�ration est co�teuse (concat�nations, gros volume de donn�es �
	 * afficher, etc.) - devrait �tre �vit�e en production en entourant cette
	 * g�n�ration d'un test :
	 * 
	 * <pre>
	 * if (LoggerManager.getLogger().isDebugActivated()) {
	 * logger.finer(&quot;trace co�teuse: &quot; + bigObject);
	 * }
	 * </pre>
	 * 
	 * Concernant les traces de niveau finest, le test est d�j� inclu dans les
	 * m�thodes
	 * <ul>
	 * <li>{@link LoggerManager#finest(String, String, String)}</li>
	 * <li>{@link LoggerManager#finest(String, String, String, Throwable)}</li>
	 * </ul>
	 * L'ajout de ce dernier est donc inutile � moins que la g�n�ration du
	 * message soit vraiment tr�s co�teuse.
	 * 
	 * @return <code>true</code> si le mode debug est activ�,
	 * <code>false</code> sinon
	 */
	public abstract boolean isDebugActivated();

	/**
	 * Config.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void config(String sourceClass, String sourceMethod, String msg);

	/**
	 * Config.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public abstract void config(String sourceClass, String sourceMethod, String msg, Throwable thrown);

	/**
	 * Fine.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void fine(String sourceClass, String sourceMethod, String msg);

	/**
	 * Fine.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public abstract void fine(String sourceClass, String sourceMethod, String msg, Throwable thrown);

	/**
	 * Finer.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void finer(String sourceClass, String sourceMethod, String msg);

	/**
	 * Finer.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public abstract void finer(String sourceClass, String sourceMethod, String msg, Throwable thrown);

	/**
	 * Finest.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void finest(String sourceClass, String sourceMethod, String msg);

	/**
	 * Finest.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public abstract void finest(String sourceClass, String sourceMethod, String msg, Throwable thrown);

	/**
	 * Info.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void info(String sourceClass, String sourceMethod, String msg);

	/**
	 * Info.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public abstract void info(String sourceClass, String sourceMethod, String msg, Throwable thrown);

	/**
	 * Severe.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void severe(String sourceClass, String sourceMethod, String msg);

	/**
	 * Severe.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public abstract void severe(String sourceClass, String sourceMethod, String msg, Throwable thrown);

	/**
	 * Warning.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void warning(String sourceClass, String sourceMethod, String msg);

	/**
	 * M�thode permettant de faire un log de QUALIF afin de v�rifier l'enchainement des RG
	 * 
	 * @param className Le nom de la classe ou se log se trouve
	 * @param indentation Indentation de la log
	 * @param methodName Le nom de la m�thode ou ce log a �t� g�n�r�
	 * @param commandId L'id de la commande en cours
	 * @param templateMessage Un message template
	 * @param params Les param�tres a utiliser pour compl�ter le message template
	 */
	public abstract void qualif(String className, int indentation, String methodName, String commandId, String templateMessage, String... params);

	/**
	 * Warning.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public abstract void warning(String sourceClass, String sourceMethod, String msg, Throwable thrown);

	/**
	 * Check if a message of the given level would actually be logged
	 * by this logger. This check is based on the Loggers effective level,
	 * which may be inherited from its parent.
	 * 
	 * @param level a message logging level
	 * @return true if the given message level is currently being logged.
	 */
	public boolean isLoggable(Level level);
}