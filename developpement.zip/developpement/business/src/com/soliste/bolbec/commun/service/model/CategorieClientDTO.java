package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.CategorieClient;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>08/03/2012</TD><TD>GPA</TD><TD>Ajout des setters</TD></TR>
 * </TABLE><BR>
 */

/**
 * CategorieClientDTO fait partie de l'espace de r�f�rence
 */
public class CategorieClientDTO implements java.io.Serializable {

	private String id;
	private String libelle;

	/**
	 * 
	 * @param id
	 */
	public CategorieClientDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public CategorieClientDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(CategorieClient.FIELD_ID);
		this.libelle = (String) ep.getValue(CategorieClient.FIELD_LIBELLE);
	}

	/**
	 * 
	 * @param categorieClient
	 */
	public CategorieClientDTO(CategorieClient categorieClient) {
		this.id = categorieClient.getId();
		this.libelle = categorieClient.getLibelle();
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public String getLibelle() {
		return libelle;
	}

	public void setId(String id) {
		this.id = id;
	}

	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

}
