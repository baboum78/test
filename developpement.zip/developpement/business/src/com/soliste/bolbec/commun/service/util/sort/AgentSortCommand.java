/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.sort;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Commande de tri pour la recherche d'agents
 * 
 * @author afbu7552
 */
public class AgentSortCommand extends SortCommand {

	/**
	 * Le crit�re "par identifiant"
	 */
	public static final String ID_SORT = "id";

	/**
	 * Le crit�re "par actif"
	 */
	public static final String ACTIF_SORT = "actif";

	/**
	 * Le crit�re "par email"
	 */
	public static final String EMAIL_SORT = "email";

	/**
	 * Le crit�re "par fax"
	 */
	public static final String FAX_SORT = "fax";

	/**
	 * Le crit�re "par nom"
	 */
	public static final String NOM_SORT = "nom";

	/**
	 * Le crit�re "par prenom"
	 */
	public static final String PRENOM_SORT = "prenom";

	/**
	 * Le crit�re "par t�l�phone"
	 */
	public static final String TELEPHONE_SORT = "telephone";

	/**
	 * Le crit�re "par identifiant de l'unit� d'activit�"
	 */
	public static final String UNITE_ACTIVITE_ID_SORT = "uniteActiviteId";

	/**
	 * Le crit�re "par libell� de l'unit� d'activit�"
	 */
	public static final String UNITE_ACTIVITE_LIBELLE_SORT = "uniteActiviteLibelle";

	/**
	 * Le crit�re "par identifiant de l'unit� d'organisation"
	 */
	public static final String UNITE_ORGANISATION_ID_SORT = "uniteOrganisationId";

	/**
	 * Le crit�re "par libell� de l'unit� d'organisation"
	 */
	public static final String UNITE_ORGANISATION_LIBELLE_SORT = "uniteOrganisationLibelle";

	/**
	 * L'ensemble des crit�res de tri valides
	 */
	public static final Set<String> SORT_CRITERIA;
	static {
		Set<String> set = new HashSet<String>();
		set.add(ID_SORT);
		set.add(ACTIF_SORT);
		set.add(EMAIL_SORT);
		set.add(FAX_SORT);
		set.add(NOM_SORT);
		set.add(PRENOM_SORT);
		set.add(TELEPHONE_SORT);
		set.add(UNITE_ACTIVITE_ID_SORT);
		set.add(UNITE_ACTIVITE_LIBELLE_SORT);
		set.add(UNITE_ORGANISATION_ID_SORT);
		set.add(UNITE_ORGANISATION_LIBELLE_SORT);
		SORT_CRITERIA = Collections.unmodifiableSet(set);
	}

	/**
	 * Constructeur
	 * 
	 * @param criterion le crit�re. S'il est invalide, il est remplac� par VALEUR_EXTERNE_SORT
	 * @param direction la direction
	 */
	public AgentSortCommand(String criterion, Direction direction) {
		super(direction, getValidSortCriterion(criterion));
	}

	private static String getValidSortCriterion(String criterion) {
		if (!SORT_CRITERIA.contains(criterion)) {
			criterion = ID_SORT;
		}
		return criterion;
	}

}
