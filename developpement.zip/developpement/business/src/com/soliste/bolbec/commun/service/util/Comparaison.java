package com.soliste.bolbec.commun.service.util;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Simple �l�ment de comparaison sur un champ :
 * champ operateur valeur
 */
public class Comparaison {

	private String champ;
	private String operateur;
	@SuppressWarnings("unchecked")
	private Comparable valeur;

	/**
	 * 
	 * @param champ
	 * @param operateur
	 * @param valeur
	 */
	@SuppressWarnings("unchecked")
	public Comparaison(String champ, String operateur, Comparable valeur) {
		this.champ = champ;
		this.operateur = operateur;
		this.valeur = valeur;
	}

	public String getChamp() {
		return champ;
	}

	public void setChamp(String champ) {
		this.champ = champ;
	}

	public String getOperateur() {
		return operateur;
	}

	public void setOperateur(String operateur) {
		this.operateur = operateur;
	}

	@SuppressWarnings("unchecked")
	public Comparable getValeur() {
		return valeur;
	}

	public void setValeur(String valeur) {
		this.valeur = valeur;
	}

}
