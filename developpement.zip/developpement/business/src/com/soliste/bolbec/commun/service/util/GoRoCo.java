package com.soliste.bolbec.commun.service.util;

/**
 * Classe repr�sentant un GoRoCo de bolbec.<BR>
 * Par exemple: G7, G7R1, G7R1C1, G07R01C01, g7r1c1
 * 
 * <BR><B>HISTORIQUE:</B><BR>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>VERSION</TD><TD>DETAIL</TD></TR>
 * <TR><TD>20/08/2009</TD><TD>DBA</TD><TD>G7R16</TD><TD>Initialisation de la classe</TD></TR>
 * </TABLE>
 * 
 */
public class GoRoCo implements Comparable<GoRoCo> {

	/** La chaine utilis� pour initialiser l'objet */
	private String strGoRoCo;

	/** La valeur enti�re de G dans GoRoCO */
	private Integer g;

	/** La valeur enti�re de R dans GoRoCO */
	private Integer r;

	/** La valeur enti�re de C dans GoRoCO */
	private Integer c;

	/**
	 * Constructeur permettant d'initialiser l'objet <BR>
	 * � partir d'une chaine de la forme (G7, G7R1, G7R1C1, G07R01C01, g7r1c1)
	 * 
	 * @param strGoRoCo Une chaine repr�sentant un GoRoCo
	 */
	public GoRoCo(String strGoRoCo) {

		// Sauvegarde de la cha�ne repr�sentant le GoRoCo
		this.strGoRoCo = strGoRoCo;

		// Initialisation par d�faut des valeurs
		g = null;
		r = null;
		c = null;

		// Tout en majuscule avant l'analyse de la chaine
		String strGoRoCoUpperCase = strGoRoCo.toUpperCase().trim();

		// Recherche des valeurs pr�sentes
		boolean gOK = strGoRoCoUpperCase.indexOf("G") > -1;
		boolean rOK = strGoRoCoUpperCase.indexOf("R") > -1;
		boolean cOK = strGoRoCoUpperCase.indexOf("C") > -1;

		// R�cup�ration des valeurs
		String[] vals = strGoRoCoUpperCase.split("G|R|C");

		// Initialisation de l'objet avec les valeurs trouv�es
		if (gOK) {
			g = new Integer(vals[1]);
			if (rOK) {
				r = new Integer(vals[2]);
				if (cOK) {
					c = new Integer(vals[3]);
				}
			}
		}
	}

	/**
	 * M�thode permettant de r�cup�rer un chaine repr�sentant le GOROCO.<BR>
	 * Exemple: <BR>
	 * G7
	 * G7R1
	 * G7R1C1
	 */
	public String toString() {
		return strGoRoCo;
	}

	public int getG() {
		return g;
	}

	public int getR() {
		return r;
	}

	public int getC() {
		return c;
	}

	/**
	 * M�thode permettant de comparer deux GoRoCo.
	 * 
	 * @param gorocoToCompare Le GOROCO qu'il faut comparer.<BR>
	 * @return <B>1</B> si <code>gorocoToCompare</code> est plus petit que <code>this</code><BR>
	 * <B>0</B> si <code>gorocoToCompare</code> est identique � <code>this</code><BR>
	 * <B>-1</B> si <code>gorocoToCompare</code> est plus grand que <code>this</code>
	 */
	public int compareTo(GoRoCo gorocoToCompare) {

		if (g > gorocoToCompare.g) {
			return 1;
		}
		if (g < gorocoToCompare.g) {
			return -1;
		}

		// Ici la valeur de G est identique
		if (r != null && gorocoToCompare.r != null) {
			if (r > gorocoToCompare.r) {
				return 1;
			}
			if (r < gorocoToCompare.r) {
				return -1;
			}

			if (c != null && gorocoToCompare.c != null) {
				// Ici la valeur de G et de R sont identiques
				if (c > gorocoToCompare.c) {
					return 1;
				}
				if (c < gorocoToCompare.c) {
					return -1;
				}
			}
		}
		// Ici G, R, C sont identique
		return 0;
	}

}
