/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

/**
 * Interfaces d�finissant les m�thodes de gestion des alarmes.
 * Un AlarmHandler est responsable de la cr�ation et de la lev�e
 * d'un seul type d'alarme.
 * 
 * @author rgvs7490
 */
public interface AlarmHandler {

	/**
	 * Cr�e une alarme. Si l'alarme a d�j� �t� cr��e auparavant (et
	 * qu'elle n'a pas �t� lev�e), alors cette m�thode ne fait rien.
	 */
	void createAlarm();

	/**
	 * L�ve l'alarme. Si aucune alarme n'a �t� cr��e depuis la premi�re utilisation
	 * de cet objet, ou depuis la derni�re lev�e d'alarme, alors cette m�thode ne
	 * fait rien
	 */
	void removeAlarm();
}
