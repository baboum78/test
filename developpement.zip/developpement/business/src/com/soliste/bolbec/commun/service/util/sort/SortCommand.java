/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.util.sort;

import java.io.Serializable;

/**
 * Commande de tri. Elle contient une crit�re de tri, et une direction.
 * 
 * @author rgvs7490
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/02/2010</TD><TD>DBA</TD><TD>EV-000029: Gestion de plusieurs tris au lieu de 1</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>12/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1533 - EV98 - CAS080 - NullPointerException suite � l'application des crit�res de la corbeille de supervision</TD></TR>
 * </TABLE>
 */
public class SortCommand implements Serializable {

	public static final Direction ASC = Direction.ASC;
	public static final Direction DESC = Direction.DESC;

	// EV-000029: Ajout de deux nouveaux criterions possible pour la requ�te de tri
	/** Les crit�res de tri */
	protected String[] criterion;

	/**
	 * La direction du tri
	 */
	private Direction direction;

	/**
	 * Constructeur
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>12/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1533 - EV98 - CAS080 - NullPointerException suite � l'application des crit�res de la corbeille de supervision</TD></TR>
	 * </TABLE>
	 */
	public SortCommand() {
	}

	/**
	 * Constructeur
	 * 
	 * @param criterion le crit�re de tri
	 * @param direction la direction du tri
	 */
	public SortCommand(Direction direction, String... criterion) {
		if (criterion == null) {
			throw new NullPointerException("Le crit�re ne paut pas �tre null");
		}
		if (direction == null) {
			throw new NullPointerException("La direction ne paut pas �tre null");
		}

		this.direction = direction;
		this.criterion = criterion;
	}

	/**
	 * Retourne la direction
	 * 
	 * @return la direction
	 */
	public Direction getDirection() {
		return this.direction;
	}

	/**
	 * Retourne le crit�re de tri
	 * 
	 * @return le crit�re de tri
	 */
	public String[] getCriterion() {
		return this.criterion;
	}

	/**
	 * 
	 */
	public boolean equals(Object o) {
		if (o instanceof SortCommand) {
			SortCommand s = (SortCommand) o;
			return ((s.direction == this.direction) && s.criterion.equals(this.criterion));
		}
		return false;
	}

	/**
	 * 
	 */
	public int hashCode() {
		return (this.criterion.hashCode() * 31) + this.direction.hashCode();
	}

	/**
	 * @param criterion the criterion to set
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>12/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1533 - EV98 - CAS080 - NullPointerException suite � l'application des crit�res de la corbeille de supervision</TD></TR>
	 * </TABLE>
	 */
	public void setCriterion(String[] criterion) {
		this.criterion = criterion;
	}
}
