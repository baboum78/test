/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.MessageFormatException;
import javax.jms.ObjectMessage;
import javax.jms.QueueSession;
import javax.jms.TextMessage;

import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Classe repr�sentant l'action � effectuer d�termin�e par le rollback handler
 *
 * @author rgvs7490
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/07/2012</TD><TD>BPE</TD><TD>CAST: Correction catch vide</TD></TR>
 * </TABLE>
 */
public class RollbackHandlerNextAction {

	private static final String CLASS_NAME = RollbackHandlerNextAction.class.getName();

	/**
	 * Code de retour indiquant que le message doit �tre rejet�
	 */
	public static final int MESSAGE_MUST_BE_REJECTED = 1;

	/**
	 * Code de retour indiquant que le message doit �tre trait�
	 */
	public static final int MESSAGE_MUST_BE_HANDLED = 2;

	/**
	 * Code de retour indiquant que le message doit �tre republi� dans sa file
	 * d'entr�e
	 */
	public static final int MESSAGE_MUST_BE_REPUBLISHED = 3;

	/**
	 * Code de retour indiquant que le message va �tre republi� dans sa file
	 * d'entr�e de mani�re asynchrone
	 */
	public static final int MESSAGE_MUST_BE_REPUBLISHED_ASYNC = 4;

	/**
	 * Le code de retour
	 */
	protected int code;

	/**
	 * Le nombre de republications � �crire dans le message lorsqu'il est republi�
	 */
	protected int republicationCount;

	/**
	 * Le temps � attendre avant la republication du message
	 */
	protected long republicationDelay;

	/**
	 * Constructeur
	 *
	 * @param code le code de retour, indiquant l'action � effectuer
	 * @param republicationCount le nombre de republications � �crire dans le message
	 * dans le cas d'une republication. Dans le cas o� le code n'est pas
	 * MESSAGE_MUST_BE_REPUBLISHED, passer n'importe quoi pour cet argument.
	 */
	public RollbackHandlerNextAction(int code, int republicationCount) {
		this(code, republicationCount, 0);
	}

	/**
	 * Constructeur
	 *
	 * @param code le code de retour, indiquant l'action � effectuer
	 * @param republicationCount le nombre de republications � �crire dans le message
	 * dans le cas d'une republication. Dans le cas o� le code n'est pas
	 * MESSAGE_MUST_BE_REPUBLISHED, passer n'importe quoi pour cet argument.
	 * @param republicationDelay le temps � attendre avant la republication du message
	 */
	public RollbackHandlerNextAction(int code, int republicationCount, long republicationDelay) {
		if ((code != MESSAGE_MUST_BE_REJECTED) && (code != MESSAGE_MUST_BE_HANDLED) && (code != MESSAGE_MUST_BE_REPUBLISHED) && (code != MESSAGE_MUST_BE_REPUBLISHED_ASYNC)) {
			throw new IllegalArgumentException("Le code n'est pas valide");
		}

		this.code = code;
		this.republicationCount = republicationCount;
		this.republicationDelay = republicationDelay;
	}

	/**
	 * Retourne le code de retour, indiquant l'action � effectuer
	 *
	 * @return le code de retour
	 */
	public int getCode() {
		return this.code;
	}

	/**
	 * Retourne le nombre de republications, � �crire dans le message s'il doit �tre
	 * republi�. Pour les autres codes de retour, cette propri�t� n'a pas de sens.
	 *
	 * @return le nombre de republications, � �crire dans le message s'il doit �tre
	 * republi�.
	 */
	public int getRepublicationCount() {
		return this.republicationCount;
	}

	/**
	 * Retourne le temps � attendre avant republication du message s'il doit �tre
	 * republi� en asynchrone. Pour les autres codes de retour, cette propri�t� n'a
	 * pas de sens.
	 *
	 * @return le temps � attendre avant republication du message s'il doit �tre
	 * republi� en asynchrone.
	 */
	public long getRepublicationDelay() {
		return this.republicationDelay;
	}

	/**
	 * G�n�re un message de republication � partir du message original donn�.
	 * Le message g�n�r� est un clone du message original, dans lequel la propri�t�
	 * contenant le nombre de republications a �t� ajout�e ou modifi�e. On ajoute
	 * aussi, si elle ne s'y trouve pas d�j�, la propri�t� initialJmsTimestamp
	 *
	 * @param session la session permettant de cr�er le message
	 * @param originalMessage le message original, re�u
	 * @return le message g�n�r�
	 * @throws JMSException dans le cas o� une exception se produit pendant la
	 * g�n�ration du message.
	 */
	@SuppressWarnings("unchecked")
	public Message generateRepublicationMessage(QueueSession session, Message originalMessage) throws JMSException {
		Message result;
		final String methode = "generateRepublicationMessage";
		if (originalMessage instanceof TextMessage) {
			TextMessage originalTextMessage = (TextMessage) originalMessage;
			result = session.createTextMessage(originalTextMessage.getText());
		} else if (originalMessage instanceof ObjectMessage) {
			ObjectMessage originalObjectMessage = (ObjectMessage) originalMessage;
			result = session.createObjectMessage(originalObjectMessage.getObject());
		} else {
			throw new IllegalArgumentException("Seuls les TextMessage et les ObjectMessage sont support�s");
		}

		for (Enumeration<String> propertyNames = originalMessage.getPropertyNames(); propertyNames.hasMoreElements();) {
			// tout type de propri�t� peut �tre lu avec getStringProperty
			// et une propri�t� �crite avec setStringProperty peut �tre lue avac
			// n'importe quel type
			String propertyName = propertyNames.nextElement();
			String propertyValue = originalMessage.getStringProperty(propertyName);
			try {
				result.setStringProperty(propertyName, propertyValue);
			} catch (MessageFormatException e) {
				final StringBuilder message = new StringBuilder(100);
				message.append("Nom de propri�t� \"");
				message.append(propertyName);
				message.append("\" r�serv� � MQ Series (valeur=\"");
				message.append(propertyValue);
				message.append("\")");
				LoggerManager.getInstance().finest(CLASS_NAME, methode, message.toString());
			}
		}

		result.setIntProperty(RollbackHandler.REPUBLICATION_COUNT_PROPERTY, getRepublicationCount());
		if (!result.propertyExists(RollbackHandler.INITIAL_TIMESTAMP_PROPERTY)) {
			result.setLongProperty(RollbackHandler.INITIAL_TIMESTAMP_PROPERTY, originalMessage.getJMSTimestamp());
		}

		return result;
	}

	/**
	 * G�n�re un map cl�-valeur pour toutes les propri�t�s du message.
	 * Tout type de propri�t� peut �tre lu avec getStringProperty
	 * et une propri�t� �crite avec setStringProperty peut �tre lue avec
	 * n'importe quel type
	 *
	 * @param originalMessage le message original, re�u
	 * @param republicationCount le nombre de republications.
	 * @return la map contenant les propri�t�s du message
	 * @throws JMSException dans le cas o� une exception se produit pendant la
	 * g�n�ration de la map de propri�t�s.
	 */
	@SuppressWarnings("unchecked")
	public Map<String, String> generateRepublicationMessageProperties(Message originalMessage, int republicationCount) throws JMSException {
		Map<String, String> resultMap = new HashMap<String, String>();

		for (Enumeration<String> propertyNames = originalMessage.getPropertyNames(); propertyNames.hasMoreElements();) {
			String propertyName = propertyNames.nextElement();
			String propertyValue = originalMessage.getStringProperty(propertyName);
			resultMap.put(propertyName, propertyValue);
		}

		// Les cl�s sp�cifiques de republication
		resultMap.put(RollbackHandler.REPUBLICATION_COUNT_PROPERTY, Integer.toString(republicationCount));
		if (!resultMap.containsKey(RollbackHandler.INITIAL_TIMESTAMP_PROPERTY)) {
			resultMap.put(RollbackHandler.INITIAL_TIMESTAMP_PROPERTY, Long.toString(originalMessage.getJMSTimestamp()));
		}

		return resultMap;
	}

}
