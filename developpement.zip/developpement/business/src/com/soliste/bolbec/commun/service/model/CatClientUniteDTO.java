package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.CatClientUnite;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * CatClientUniteDTO fait partie de l'espace de r�f�rence
 */
public class CatClientUniteDTO implements java.io.Serializable {

	private String id;
	// FIXME OLD: GTA voir si on supprime cette reference?
	private UniteActiviteDTO uniteActivite;
	private RoleClientDTO roleClient;
	private CategorieClientDTO categorieClient;

	/**
	 * 
	 * @param id
	 */
	public CatClientUniteDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public CatClientUniteDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(CatClientUnite.FIELD_ID);
		// FIXME OLD: GTA On ne mets pas l'uniteActivite dans l'objet CatClientUniteDTO
		// car l'appel a CatClientUniteDTO ne se fait que par uniteActivite
		/*
		 * EntityProxy ua = (EntityProxy) ep.getLinkedObject(CatClientUnite.SLINK_GERE_PAR_UNITE_ACTIVITE);
		 * if (ua != null) {
		 * this.uniteActivite = new UniteActiviteDTO(ua);
		 * }
		 */
		EntityProxy rc = (EntityProxy) ep.getLinkedObject(CatClientUnite.SLINK_POUR_ROLE_CLIENT);
		if (rc != null) {
			this.roleClient = new RoleClientDTO(rc);
		}
		EntityProxy cc = (EntityProxy) ep.getLinkedObject(CatClientUnite.SLINK_ADMINISTRE_CATEGORIE_CLIENT);
		if (cc != null) {
			this.categorieClient = new CategorieClientDTO(cc);
		}
	}

	/**
	 * 
	 * @param catClientUnite
	 */
	public CatClientUniteDTO(CatClientUnite catClientUnite) {
		this.id = catClientUnite.getId();
		this.roleClient = new RoleClientDTO(catClientUnite.getLinkPourRoleClient());
		this.categorieClient = new CategorieClientDTO(catClientUnite.getLinkAdministreCategorieClient());
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public UniteActiviteDTO getUniteActivite() {
		return uniteActivite;
	}

	public RoleClientDTO getRoleClient() {
		return roleClient;
	}

	public CategorieClientDTO getCategorieClient() {
		return categorieClient;
	}

}
