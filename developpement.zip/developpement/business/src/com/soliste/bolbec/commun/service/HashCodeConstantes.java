package com.soliste.bolbec.commun.service;

/**
 * 
 * Interface de constantes pour les methodes hashCode.
 * Pour plus de facilit�, on cr�e la methode hashCode comme suit :
 * 
 * public int hashCode() {
 * return HashCodeConstantes.HASHVALUE * getId().hashCode();
 * }
 * 
 * getId ou n'importe quel String.
 * Le fait d'avoir des HashValues diff�rentes suffit pour les diff�rentier ensuite.
 * Elles sont donc centralis�es ici.
 * 
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>23/10/2013</TD><TD>EBA</TD><TD>G9R0C1 : Corrections sonar</TD></TR>
 * </TABLE><BR>
 * 
 * @author ebaali
 * 
 */
public interface HashCodeConstantes {

	int JALON_HASHVALUE = 13;
	int LDC_HASHVALUE = 14;
	int INST_RT_HASHVALUE = 15;
	int SYS_EXTERNE_HASHVALUE = 16;
	int URL_HASHVALUE = 16;
}
