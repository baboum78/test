package com.soliste.bolbec.commun.service.exception;

/**
 * Repr�sente une erreur de connexion
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2010</TD><TD>CCL</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 * 
 */
public class ConnException extends Exception {

	/**
	 * Constructeur par d�faut
	 */
	public ConnException() {
		super();
	}

	/**
	 * Constructeur d'initialisation avec simple message
	 * 
	 * @param msg Le message de l'exception
	 */
	public ConnException(String msg) {
		super(msg);
	}

	/**
	 * Constructeur d'initalisation
	 * 
	 * @param msg Le m�ssage de l'exception
	 * @param t L'erreur m�re
	 */
	public ConnException(String msg, Throwable t) {
		super(msg, t);
	}

}
