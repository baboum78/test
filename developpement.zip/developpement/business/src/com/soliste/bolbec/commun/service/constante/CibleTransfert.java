package com.soliste.bolbec.commun.service.constante;

/**
 * Extracteurs de la table routeur ExtractInfo
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>22/10/2010</TD><TD>GPA</TD><TD>EV-000087: Cr�ation de la classe</TD></TR>
 * <TR><TD>18/10/2010</TD><TD>GPA</TD><TD>EV-000144: Ajout de la cible InitSupDePro</TD></TR>
 * <TR><TD>11/01/2012</TD><TD>GPA</TD><TD>EV-000170: Ajout de la cible ExtrGrafic</TD></TR>
 * </TABLE>
 */
public enum CibleTransfert {
	Extract_Robot177, InitSupDePro, ExtrGrafic, Grafic, InterfaceRobotBANIP
}
