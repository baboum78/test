package com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.impl;

import javax.xml.xpath.XPath;
import javax.xml.xpath.XPathConstants;
import javax.xml.xpath.XPathExpressionException;
import javax.xml.xpath.XPathFactory;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.GraficXMLTransformCallBack;
import com.soliste.bolbec.commun.service.util.xml.XmlDomFactory;

/**
 * A partir d'un message Fault, retourne le contenu de l'�l�ment d�tail,
 * Cette impl�mentation n'est pas utilis� du fait que les messages de r�ponse "Fault" n'ont pas besoin d'�tre adapt�s
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 *
 */
public class GraficXMLTransformFaultCallBack extends GraficXMLTransformCallBack {

	public GraficXMLTransformFaultCallBack(XmlDomFactory xmlDomFactory) {
		super(xmlDomFactory);
	}

	@Override
	protected Element getRootMessage(Node body) {
		final String xpathRequest = "//*[namespace-uri()='http://schemas.xmlsoap.org/soap/envelope/' and local-name()='Fault']/detail/*[1]";
		XPath xPath = XPathFactory.newInstance().newXPath();

		NodeList contentNodeList;
		try {
			contentNodeList = (NodeList) xPath.evaluate(xpathRequest, body, XPathConstants.NODESET);
		} catch (XPathExpressionException e) {
			throw new RuntimeException("Impossible de r�cup�rer le corps du message Fault", e);
		}

		return (Element) contentNodeList.item(0);
	}
}
