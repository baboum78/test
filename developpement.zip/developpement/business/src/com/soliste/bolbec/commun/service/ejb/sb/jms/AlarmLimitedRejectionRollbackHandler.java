/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

/**
 * Sp�cialisation de LimitedRejectionRollbackHandler, qui permet de g�rer en plus
 * une alarme lorsque le maximum de rejets cons�cutifs est atteint, et de la lever
 * lorsque le compteur de rejets est remis � z�ro.
 * 
 * @author rgvs7490
 */
public class AlarmLimitedRejectionRollbackHandler extends LimitedRejectionRollbackHandler {

	private AlarmHandler alarmHandler;

	/**
	 * Constructeur
	 * 
	 * @param rejectCounter le compteur de rejet
	 * @param alarmHandler le gestionnaire d'alarmes
	 */
	public AlarmLimitedRejectionRollbackHandler(RejectCounter rejectCounter, AlarmHandler alarmHandler) {
		super(rejectCounter);
		this.alarmHandler = alarmHandler;
	}

	/**
	 * @param maxRejectCount le nombre maximum de rejets cons�cutifs
	 * @param rejectCounter le compteur de rejets
	 * @param alarmHandler le gestionnaire d'alarmes
	 */
	public AlarmLimitedRejectionRollbackHandler(int maxRejectCount, RejectCounter rejectCounter, AlarmHandler alarmHandler) {
		super(maxRejectCount, rejectCounter);
		this.alarmHandler = alarmHandler;
	}

	/**
	 * Remet le compteur � 0 et l�ve l'alarme
	 * 
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.LimitedRejectionRollbackHandler#resetCounter()
	 */
	public void resetCounter() {
		super.resetCounter();
		this.alarmHandler.removeAlarm();
	}

	/**
	 * Incr�mente le compteur et cr�e une alarme si le nombre maximum de rejets
	 * est atteint
	 * 
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.LimitedRejectionRollbackHandler#incrementCounter()
	 */
	protected void incrementCounter() {
		super.incrementCounter();
		if (getRejectCount() == getMaxRejectCount()) {
			this.alarmHandler.createAlarm();
		}
	}
}
