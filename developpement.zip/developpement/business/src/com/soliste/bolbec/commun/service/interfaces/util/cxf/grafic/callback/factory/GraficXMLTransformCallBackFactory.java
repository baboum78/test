package com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback.factory;

import org.apache.cxf.io.CachedOutputStreamCallback;

/**
 * Abstract Factory permettant de cr�er et retourner un objet GraficXMLTransformCallBack
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 */
public interface GraficXMLTransformCallBackFactory {
	/**
	 * @return cr�e et retourner un objet de type CachedOutputStreamCallback
	 */
	public CachedOutputStreamCallback createGraficXMLTransformCallBack();
}
