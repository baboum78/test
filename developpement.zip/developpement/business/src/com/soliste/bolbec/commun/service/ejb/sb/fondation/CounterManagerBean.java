/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import com.soliste.aps.foundation.ejb.counter.Counter;
import com.soliste.aps.foundation.ejb.counter.CounterHome;
import com.soliste.aps.foundation.ejb.counter.CounterPK;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.jndi.ServiceLocator;

/**
 * Impl�mentation de l'EJB session <code>CommandeManager</code>.
 * 
 * @see {@link com.soliste.bolbec.commun.service.ejb.sb.fondation.CounterManager}
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public class CounterManagerBean extends FwkSessionBean implements CounterManager, ICounterManagerRemote {

	/** Cl� du compteur par d�faut */
	public final static String DEFAULT_COUNTER_NAME = "Counter";

	/** R�f�rence sur l'interface home de l'EJB entit� Counter */
	private CounterHome counterHome;

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.CounterManager#next()
	 */
	public long next() {
		return next(DEFAULT_COUNTER_NAME);
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.fondation.CounterManager#next(java.lang.String)
	 */
	public long next(String counterName) {
		Counter counter;
		try {
			// on r�cup�re en base le compteur correspondant au type de contenu sp�cifi�
			CounterPK pk = new CounterPK(counterName);
			counter = counterHome.findByPrimaryKey(pk);
		} catch (FinderException fe) {
			try {
				// aucun compteur n'est initialis� en base pour le type decontenu sp�cifi� donc on le cr�e
				counter = counterHome.create(counterName);
			} catch (CreateException ce) {
				throw new EJBException("Erreur: impossible de cr�er le compteur " + counterName, ce);
			}
		}

		// l'appel � la m�thode "getNewId()" du compteur retourne la valeur
		// actuelle du compteur en base puis incr�mente ce dernier en vue de la prochaine utilisation
		return counter.getNewId();
	}

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			counterHome = (CounterHome) ServiceLocator.getInstance().getLocalHome("CounterHome");
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

}
