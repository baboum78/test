package com.soliste.bolbec.commun.service.ejb.sb.archiving;

import java.rmi.RemoteException;

import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;

public interface IArchivingManagerRemote {

	void archiveToDatabase(Archivable archivable) throws RemoteException, ArchivingException;

}
