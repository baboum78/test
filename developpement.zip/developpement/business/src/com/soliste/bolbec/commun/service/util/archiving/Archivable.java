package com.soliste.bolbec.commun.service.util.archiving;

import java.io.Serializable;
import java.util.Map;

/**
 * Interface d�finissant un objet archivable.
 * Pour un archivage en base, l'objet doit porter le nom de la table suffix� de "DTO"
 * 
 * /!!!!!!!!! Attention � la d�s�rialisation de l'objet � archiver c�t� Routeur si son impl�mentation change !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\
 * Prenons un exemple : On rajoute un attribut sur l'impl�mentation MessageWebSrvOutDTO.
 * Cette classe �tant dans le code du package commun, le Routeur sera mis � jour lors de la MEP et ne connaitra plus que la derni�re version de cette classe.
 * Il sera donc incapable de d�s�rialiser les objets MessageWebSrvOutDTO envoy�s par les versions pr�c�dente ou l�g�re.
 * 
 * Solutions envisageables :
 * 1- On ne fait rien => les messages seront ignor�s et donc pas archiv�s c�t� routeur
 * 2- On patch les versions pr�c�dente et l�g�re avec la nouvelle version de la classe MessageWebSrvOut (Attention aux messages r�siduels pr�sents dans les files MQ apr�s la MEP)
 * 3- On cr�e un objet Archivable diff�rent MessageWebSrvOutV2DTO. Le Routeur connaitra donc les 2 objets : MessageWebSrvOutDTO et MessageWebSrvOutV2DTO
 * /!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public interface Archivable extends Serializable {

	/**
	 * M�thode de transformation de l'Archivable en Map
	 * 
	 * @return la map reps�sentant l'Archivable
	 */
	public Map<String, Object> toMap();

}
