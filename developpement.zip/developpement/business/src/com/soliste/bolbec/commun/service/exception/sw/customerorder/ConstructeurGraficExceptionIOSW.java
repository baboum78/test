package com.soliste.bolbec.commun.service.exception.sw.customerorder;

import java.util.Collection;

import com.orange.bolbec.customerOrderIOSW.types.fault.CustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.fault.FaultDetail;
import com.orange.bolbec.supplierOrderIOSW.types.fault.FaultDetailFLTRDSO;
import com.orange.bolbec.supplierOrderIOSW.types.fault.SupplierOrderFault;

/**
 * <BR>
 * <B>HISTORIQUE DES MODIFICATIONS:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/12/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210 : Cr�ation de la classe pour le service compatible IOSW</TD></TR>
 * <TR><TD>16/01/2013</TD><TD>EBA</TD><TD>G8R1C2 - EV-000210: Modifs</TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * </TABLE>
 * <BR>
 */
public class ConstructeurGraficExceptionIOSW {

	/**
	 * Permet de construire une exception customerOrder (Grafic)
	 * 
	 * @param exceptionClass la classe de l'exception � g�n�rer
	 * @param graficTypeFaultEnum le type de la fault
	 * @param labelErreur le label erreur
	 * @return l'exception correctement construit
	 */
	public CustomerOrderFault contruireCustomerException(Class<? extends CustomerOrderFault> exceptionClass, GraficTypeFaultEnum graficTypeFaultEnum, String labelErreur, String customerOrderId) {
		CustomerOrderFault exception;
		try {
			exception = exceptionClass.newInstance();
		} catch (InstantiationException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		}
		exception.setCustomerOrderID(customerOrderId);
		FaultDetail faultDetail = new FaultDetail();
		faultDetail.getLocalErrorLabel().add(labelErreur);
		faultDetail.getLocalErrorCode().add(graficTypeFaultEnum.getCodeErreur());
		exception.getFaultDetail().add(faultDetail);
		exception.setFaultLabel(graficTypeFaultEnum.getLabel());

		return exception;
	}

	/**
	 * Permet de construire une exception customerOrder (Grafic)
	 * 
	 * @param exceptionClass la classe de l'exception � g�n�rer
	 * @param label le label
	 * @param faultDetailList le champ faultDetail
	 * @return l'exception correctement construit
	 */
	public CustomerOrderFault contruireCustomerException(Class<? extends CustomerOrderFault> exceptionClass, String label, Collection<? extends FaultDetail> faultDetailList) {
		CustomerOrderFault exception;
		try {
			exception = exceptionClass.newInstance();
		} catch (InstantiationException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		}
		exception.getFaultDetail().addAll(faultDetailList);
		exception.setFaultLabel(label);

		return exception;
	}

	/**
	 * Permet de construire une exception supplierOrder (Grafic)
	 * 
	 * @param exceptionClass la classe de l'exception � g�n�rer
	 * @param graficTypeFaultEnum le type de la fault
	 * @param labelErreur le label erreur
	 * @return l'exception correctement construit
	 */
	public SupplierOrderFault contruireSupplierException(Class<? extends SupplierOrderFault> exceptionClass, GraficTypeFaultEnum graficTypeFaultEnum, String labelErreur) {
		SupplierOrderFault exception;
		try {
			exception = exceptionClass.newInstance();
		} catch (InstantiationException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		}
		final FaultDetailFLTRDSO faultDetail = new FaultDetailFLTRDSO();
		faultDetail.getLocalErrorLabel().add(labelErreur);
		faultDetail.getLocalErrorCode().add(graficTypeFaultEnum.getCodeErreur());
		exception.getFaultDetail().add(faultDetail);
		exception.setFaultLabel(graficTypeFaultEnum.getLabel());

		return exception;
	}

	/**
	 * Permet de construire une exception supplierOrder (Grafic)
	 * 
	 * @param exceptionClass la classe de l'exception � g�n�rer
	 * @param label le label
	 * @param faultDetailList le champ faultDetail
	 * @return l'exception correctement construit
	 */
	public SupplierOrderFault contruireSupplierException(Class<? extends SupplierOrderFault> exceptionClass, String label, Collection<? extends FaultDetailFLTRDSO> faultDetailList) {
		SupplierOrderFault exception;
		try {
			exception = exceptionClass.newInstance();
		} catch (InstantiationException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		} catch (IllegalAccessException e) {
			throw new IllegalArgumentException("Impossible d'instancier l'exception");
		}
		exception.getFaultDetail().addAll(faultDetailList);
		exception.setFaultLabel(label);

		return exception;
	}

}
