package com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.callback;

/**
 * Constantes
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/11/2014</TD><TD>BPE</TD><TD>G9R0 Conversion des messages � destination de Grafic</TD></TR>
 * </TABLE>
 */
public interface GraficXMLTransformCallbackConstantes {
	String XML_NAMESPACE_PREFIX = "xmlns";
	String SOAP_NAMESPACE = "http://schemas.xmlsoap.org/soap/envelope/";
	String SOAP_BODY_ELEMENT_NAME = "Body";
	String SOAP_FAULT_ELEMENT_NAME = "Fault";
}
