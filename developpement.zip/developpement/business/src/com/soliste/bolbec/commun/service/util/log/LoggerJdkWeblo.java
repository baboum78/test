/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.util.log;

import java.io.File;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.LogManager;
import java.util.logging.Logger;
import java.util.logging.MemoryHandler;

import weblogic.logging.LoggingHelper;

/**
 * Cette classe de log est une classe permettant de logger, via le logger JDK,
 * les logs applicatives de l'application bolbec
 * <br><br>
 * Nouvelle classe : {@link com.soliste.bolbec.commun.service.util.log.LoggerManager}
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: en mode remote, r�cup�ration du logger client</TD></TR>
 * <TR><TD>21/11/2012</TD><TD>BPE</TD><TD>DE-000680: TestRegul ne fonctionne pas lorsque le mode "buffer" des log est activ�</TD></TR>
 * </TABLE>
 */
@Deprecated
public class LoggerJdkWeblo extends Logger {

	private static String CLASS_NAME = LoggerJdkWeblo.class.getName();
	private String className = null;
	private String loggerName = null;

	/** R�f�rence sur le LogManager. */
	private static LogManager logManager = LogManager.getLogManager();

	// Constantes de formatage
	private static final String MSG_EMPTY = "-";
	private static final String MSG_NEW_LINE = System.getProperty("line.separator", "\n");
	private static final String MSG_SEPARATOR = MSG_NEW_LINE + " | ";

	// Config par d�faut (�cras�e par la config lue depuis le fichier de config
	// bolbec-logging.properties s'il existe)
	private static final Level DEFAULT_LEVEL = Level.WARNING;
	private static final boolean DEFAULT_BUFFER_ON = true;
	private static final int DEFAULT_BUFFER_SIZE = 100;
	private static final Level DEFAULT_BUFFER_LEVEL = Level.WARNING;
	private static final boolean DEFAULT_STACK_TRACE_ON = true;
	private boolean bufferOn = DEFAULT_BUFFER_ON;
	private int bufferSize = DEFAULT_BUFFER_SIZE;
	private Level bufferPushLevel = DEFAULT_BUFFER_LEVEL;
	private static Handler bufferTargetHandler = null;
	private static Handler bufferHandler = null;
	private boolean stackTraceOn = DEFAULT_STACK_TRACE_ON;
	private static final String SYSPROP_WEBLOGIC_LOGGING_FILE_STREAM_HANDLER = "weblogic.logging.FileStreamHandler";

	/**
	 * Le flag d�terminant si le debug est activ� ou pas.<br> Le mode debug est activ� en passant
	 * la propri�t� syst�me <code>-Dbolbec.debug=true</code> au lancement de la JVM.
	 */
	private static final boolean isDebugActivated = Boolean.getBoolean("bolbec.debug");
	/**
	 * Le flag d�terminant si on acc�de � bolbec en remote ou non.<br> Le mode remote est activ� en passant
	 * la propri�t� syst�me <code>-Dbolbec.remote.acces=true</code> au lancement de la JVM.
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: en mode remote, r�cup�ration du logger client</TD></TR>
	 * </TABLE>
	 */
	private static final boolean REMOTE_BOLBEC_ACCES = Boolean.getBoolean("bolbec.remote.acces");

	// singleton's private instance
	private static LoggerJdkWeblo me;
	static {
		// on teste la pr�sence du fichier de config
		boolean configFilePresent = false;
		try {
			File f = new File(System.getProperty("java.util.logging.config.file"));
			configFilePresent = (f.exists() && f.isFile());
		} catch (SecurityException e) {
			configFilePresent = false;
			System.out.println("probleme de securite lors de l'acces a la ressource pointee par la propriete systeme 'java.util.logging.config.file'");
		} catch (NullPointerException e) {
			configFilePresent = false;
			System.out.println("la propriete systeme 'java.util.logging.config.file' n'est pas definie");
		} finally {
			if (configFilePresent) {
				System.out.println("la ressource pointee par la propriete systeme 'java.util.logging.config.file' est accessible");
			} else {
				System.out.println("la ressource pointee par la propriete systeme 'java.util.logging.config.file' n'est pas accessible");
			}
		}
		me = (LoggerJdkWeblo) logManager.getLogger(CLASS_NAME);
		if (me == null) {
			me = new LoggerJdkWeblo(CLASS_NAME, null);
			logManager.addLogger(me);
			// NOTE: la m�thode "addLogger()" initialise la config du logger donc il faut n�cessairement
			// appeler "initLogger()" apr�s l'appel � "addLogger()" sous peine de perdre la config lue et
			// initailis�e par "initLogger()"
			me.initLogger();
		}
	}

	/**
	 * The Constructor.
	 * 
	 * @param name the name
	 * @param resourceBundleName the resource bundle name
	 */
	private LoggerJdkWeblo(String name, String resourceBundleName) {
		super(name, resourceBundleName);
	}

	/**
	 * Gets the logger.
	 * 
	 * @return the logger
	 */
	public static LoggerJdkWeblo getLogger() {
		return me;
	}

	/**
	 * Inits the logger.
	 */
	private synchronized void initLogger() {
		// nom de la classe courante
		className = getClass().getName();
		if (className != null) {
			int index = className.lastIndexOf('.');
			if ((index != -1) && (index < className.length())) {
				loggerName = className.substring(index + 1);
			}
		}

		// on charge le niveau de trace du logger
		Level level = readConfigurationLevelProperty(className + ".level", DEFAULT_LEVEL);
		try {
			setLevel(level);
		} catch (SecurityException e) {
			config(CLASS_NAME, "initLogger()", "erreur de securite lors de l'appel a setLevel()", e);
		}

		// le logger doit-il se comporter en mode buffer ou pas?
		bufferOn = readConfigurationBooleanProperty(className + ".buffer.on", DEFAULT_BUFFER_ON);
		if (bufferOn) { // MODE BUFFER ACTIVE

			// si oui, on r�cup�re si il y a lieu l'objet cible du buffer,
			// en l'occurence le FileStreamHandler du logger weblogic 'server'...
			if (bufferTargetHandler == null) {
				bufferTargetHandler = getWLLogFileHandler();
			}

			// ...on r�cup�re �galement le niveau de d�clenchement...
			bufferPushLevel = readConfigurationLevelProperty(className + ".buffer.push", DEFAULT_BUFFER_LEVEL);

			// ...et la taille du buffer
			bufferSize = readConfigurationIntProperty(className + ".buffer.size", DEFAULT_BUFFER_SIZE);

			if (bufferSize <= 0) { // on teste la valididt� de la taille sp�cifi�e (doit �tre > 0)
				bufferSize = DEFAULT_BUFFER_SIZE;
			}
		}

		if (bufferTargetHandler == null) { // si aucune cible n'est d�finie => MODE BUFFER DESACTIVE

			// on d�finit le logger weblogic "server" comme le p�re de ce logger...
			setParent(REMOTE_BOLBEC_ACCES ? LoggingHelper.getClientLogger() : LoggingHelper.getServerLogger());

			// ...afin que ce dernier utilise les handlers de son p�re, ceci
			// permet, entre autres, d'�crire dans le fichier de traces weblogic
			setUseParentHandlers(true);
		} else { // sinon => MODE BUFFER ACTIVE

			// un MemoryHandler assure la fonction de buffer
			if (bufferHandler == null) {
				// NOTE: � la cr�ation du MemoryHandler, bufferTargetHandler n'est pas null et this.bufferSize est > � 0 (cf tests r�alis�s pr�c�demment)
				bufferHandler = new MemoryHandler(bufferTargetHandler, bufferSize, bufferPushLevel); // on cr�e et on 'plug' le buffer sur le FileStreamHandler du logger weblogic 'server'
			}
			addHandler(bufferHandler);
			setUseParentHandlers(false);
		}

		// le logger doit-il produire la stacktrace des exceptions lev�es ou pas?
		stackTraceOn = readConfigurationBooleanProperty(className + ".stacktrace.on", DEFAULT_STACK_TRACE_ON);
	}

	/**
	 * Do log.
	 * 
	 * @param level the level
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param cause the cause
	 */
	private void doLog(Level level, String sourceClass, String sourceMethod, String msg, Throwable cause) {
		if (!isLoggable(level)) {
			return;
		}

		// initialisation du StringBuffer
		StringBuilder sb = (stackTraceOn) ? new StringBuilder(1024) : new StringBuilder(256);

		// Niveau
		sb.append(MSG_NEW_LINE);
		sb.append(level.toString());
		sb.append(MSG_SEPARATOR);

		// Domaine
		if (loggerName != null) {
			sb.append(loggerName);
		} else {
			sb.append(MSG_EMPTY);
		}
		sb.append(MSG_SEPARATOR);

		// Message
		if (msg != null) {
			sb.append(msg);
		} else {
			sb.append(MSG_EMPTY);
		}
		sb.append(MSG_SEPARATOR);

		// Classe
		if (sourceClass != null) {
			sb.append(sourceClass);
		} else {
			sb.append(MSG_EMPTY);
		}
		sb.append(MSG_SEPARATOR);

		// M�thode
		if (sourceMethod != null) {
			sb.append(sourceMethod);
		} else {
			sb.append(MSG_EMPTY);
		}

		logp(level, sourceClass, sourceMethod, sb.toString(), cause);
	}

	/**
	 * D�termine si le mode debug est activ� ou pas. <br>
	 * La g�n�ration de traces de bas niveau (finer, fine) - particuli�rement si
	 * cette g�n�ration est co�teuse (concat�nations, gros volume de donn�es �
	 * afficher, etc.) - devrait �tre �vit�e en production en entourant cette
	 * g�n�ration d'un test :
	 * 
	 * <pre>
	 * if (LoggerJdkWeblo.isDebugActivated()) {
	 * logger.finer(&quot;trace co�teuse: &quot; + bigObject);
	 * }
	 * </pre>
	 * 
	 * Concernant les traces de niveau finest, le test est d�j� inclu dans les
	 * m�thodes
	 * <ul>
	 * <li>{@link LoggerJdkWeblo#finest(String, String, String)}</li>
	 * <li>{@link LoggerJdkWeblo#finest(String, String, String, Throwable)}</li>
	 * </ul>
	 * L'ajout de ce dernier est donc inutile � moins que la g�n�ration du
	 * message soit vraiment tr�s co�teuse.
	 * 
	 * @return <code>true</code> si le mode debug est activ�,
	 * <code>false</code> sinon
	 */
	public static boolean isDebugActivated() {
		return isDebugActivated;
	}

	/**
	 * Return Weblogic log file handler.
	 * 
	 * @return Weblogic log file handler
	 */
	private static Handler getWLLogFileHandler() {
		// on r�cup�re l'objet FileStreamHandler du logger weblogic
		Logger logger = REMOTE_BOLBEC_ACCES ? LoggingHelper.getClientLogger() : LoggingHelper.getServerLogger();
		Handler[] handlers = logger.getHandlers();
		Handler handler = null;
		if (handlers != null) {
			for (int i = 0; i < handlers.length; i++) {
				Handler h = handlers[i];
				if (SYSPROP_WEBLOGIC_LOGGING_FILE_STREAM_HANDLER.equals(h.getClass().getName())) {
					handler = h;
				}
			}
		}
		return handler;
	}

	/**
	 * Config.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public void config(String sourceClass, String sourceMethod, String msg) {
		doLog(Level.CONFIG, sourceClass, sourceMethod, msg, null);
	}

	/**
	 * Config.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public void config(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		doLog(Level.CONFIG, sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * Fine.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public void fine(String sourceClass, String sourceMethod, String msg) {
		doLog(Level.FINE, sourceClass, sourceMethod, msg, null);
	}

	/**
	 * Fine.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public void fine(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		doLog(Level.FINE, sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * Finer.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public void finer(String sourceClass, String sourceMethod, String msg) {
		doLog(Level.FINER, sourceClass, sourceMethod, msg, null);
	}

	/**
	 * Finer.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public void finer(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		doLog(Level.FINER, sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * Finest.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public void finest(String sourceClass, String sourceMethod, String msg) {
		if (isDebugActivated) {
			doLog(Level.FINEST, sourceClass, sourceMethod, msg, null);
		}
	}

	/**
	 * Finest.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public void finest(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		if (isDebugActivated) {
			doLog(Level.FINEST, sourceClass, sourceMethod, msg, thrown);
		}
	}

	/**
	 * Info.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public void info(String sourceClass, String sourceMethod, String msg) {
		doLog(Level.INFO, sourceClass, sourceMethod, msg, null);
	}

	/**
	 * Info.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public void info(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		doLog(Level.INFO, sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * Severe.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public void severe(String sourceClass, String sourceMethod, String msg) {
		doLog(Level.SEVERE, sourceClass, sourceMethod, msg, null);
	}

	/**
	 * Severe.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public void severe(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		doLog(Level.SEVERE, sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * Warning.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 */
	public void warning(String sourceClass, String sourceMethod, String msg) {
		doLog(Level.WARNING, sourceClass, sourceMethod, msg, null);
	}

	/**
	 * Warning.
	 * 
	 * @param sourceClass the source class
	 * @param sourceMethod the source method
	 * @param msg the msg
	 * @param thrown the thrown
	 */
	public void warning(String sourceClass, String sourceMethod, String msg, Throwable thrown) {
		doLog(Level.WARNING, sourceClass, sourceMethod, msg, thrown);
	}

	/**
	 * Return boolean value for property key if found either the default boolean
	 * value.
	 * 
	 * @param key the key
	 * @param defaultValue the default value
	 * 
	 * @return boolean value for property key if found either the default
	 * boolean value
	 */
	private boolean readConfigurationBooleanProperty(String key, boolean defaultValue) {
		String val = readConfigurationProperty(key, Boolean.toString(defaultValue));
		if (val == null) {
			return false;
		}
		val = val.trim();
		return Boolean.valueOf(val);
	}

	/**
	 * Return integer value for property key if found either the default integer
	 * value.
	 * 
	 * @param key the key
	 * @param defaultValue the default value
	 * 
	 * @return integer value for property key if found either the default
	 * integer value
	 */
	private int readConfigurationIntProperty(String key, int defaultValue) {
		String val = readConfigurationProperty(key, Integer.toString(defaultValue));
		if (val != null) {
			val = val.trim();
		}
		int intVal;
		try {
			intVal = Integer.parseInt(val);
		} catch (NumberFormatException e) {
			intVal = defaultValue;
		}
		return intVal;
	}

	/**
	 * Return {@link Level} value for property key if found either the default {@link Level} value.
	 * 
	 * @param key the key
	 * @param defaultValue the default value
	 * 
	 * @return {@link Level} value for property key if found either the default {@link Level} value
	 */
	private Level readConfigurationLevelProperty(String key, Level defaultValue) {
		String val = readConfigurationProperty(key, defaultValue.toString());
		if (val != null) {
			val = val.trim();
			val = val.toUpperCase();
		}
		Level level;
		try {
			level = Level.parse(val);
		} catch (IllegalArgumentException e) {
			level = defaultValue;
		}
		return level;
	}

	/**
	 * Return value for property key if found either the default value.
	 * 
	 * @param key the key
	 * @param defaultValue the default value
	 * 
	 * @return value for property key if found either the default value
	 */
	private String readConfigurationProperty(String key, String defaultValue) {
		if (key == null) {
			return null;
		}
		String value = logManager.getProperty(key); // valeur sp�cifique
		if ((value == null) || value.trim().length() <= 0) {
			String cname = getClass().getName();
			int l = cname.length();
			if (key.startsWith(cname) && (l < key.length())) {
				String globalKey = key.substring(l);
				value = logManager.getProperty(globalKey); // valeur globale
				if ((value == null) || value.trim().length() <= 0) {
					value = defaultValue; // valeur globale par d�faut
				}
			}
		}
		return value;
	}
}
