package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.ZoneGeographique;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * ZoneGeographiqueDTO fait partie de l'espace de r�f�rence
 */
public class ZoneGeographiqueDTO implements java.io.Serializable {

	private String id;
	private ZoneSiDTO zoneSi;
	private String libelleCourt;
	private String libelle;

	/**
	 * 
	 * @param id
	 */
	public ZoneGeographiqueDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public ZoneGeographiqueDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(ZoneGeographique.FIELD_ID);
		this.libelleCourt = (String) ep.getValue(ZoneGeographique.FIELD_LIBELLE_COURT);
		this.libelle = (String) ep.getValue(ZoneGeographique.FIELD_LIBELLE);
		EntityProxy zs = (EntityProxy) ep.getLinkedObject(ZoneGeographique.SLINK_EST_DANS_ZONE_S_I);
		if (zs != null) {
			this.zoneSi = new ZoneSiDTO(zs);
		}
	}

	/**
	 * 
	 * @param id
	 * @param libelleCourt
	 * @param libelle
	 * @param zoneSIId
	 * @param zoneSILibelle
	 */
	public ZoneGeographiqueDTO(String id, String libelleCourt, String libelle, String zoneSIId, String zoneSILibelle) {
		this.id = id;
		this.libelleCourt = libelleCourt;
		this.libelle = libelle;
		this.zoneSi = new ZoneSiDTO(zoneSIId, null, zoneSILibelle);
	}

	/**
	 * 
	 * @param zoneGeographiqueId
	 * @param zoneGeographiqueLibelle
	 */
	public ZoneGeographiqueDTO(String zoneGeographiqueId, String zoneGeographiqueLibelle) {
		this.id = zoneGeographiqueId;
		this.libelle = zoneGeographiqueLibelle;
	}

	/**
	 * 
	 * @param zg
	 */
	public ZoneGeographiqueDTO(ZoneGeographique zg) {
		this.id = zg.getId();
		this.libelle = zg.getLibelle();
		this.libelleCourt = zg.getLibelleCourt();
		this.zoneSi = new ZoneSiDTO(zg.getLinkEstDansZoneSI());
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public ZoneSiDTO getZoneSi() {
		return zoneSi;
	}

	public String getLibelleCourt() {
		return libelleCourt;
	}

	public String getLibelle() {
		return libelle;
	}

	/**
	 * @param zoneSi the zoneSi to set
	 */
	public void setZoneSi(ZoneSiDTO zoneSi) {
		this.zoneSi = zoneSi;
	}

	/**
	 * @param libelleCourt the libelleCourt to set
	 */
	public void setLibelleCourt(String libelleCourt) {
		this.libelleCourt = libelleCourt;
	}

	/**
	 * @param libelle the libelle to set
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

}
