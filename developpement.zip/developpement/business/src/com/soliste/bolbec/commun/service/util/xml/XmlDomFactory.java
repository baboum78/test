package com.soliste.bolbec.commun.service.util.xml;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.transform.Transformer;

/**
 * Interface XML Factory pour l'API DOM
 * 
 * @author bperrard
 *
 */
public interface XmlDomFactory {

	/**
	 * Cr�e un document builder XML
	 * 
	 * @return un document XML
	 */
	DocumentBuilder createDocumentBuilder();

	/**
	 * Cr�e un transformer XML
	 * 
	 * @return un transformer XML
	 */
	Transformer createTranformer();

}
