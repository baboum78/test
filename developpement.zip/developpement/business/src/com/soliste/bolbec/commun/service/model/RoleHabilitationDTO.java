package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.RoleHabilitation;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * RoleHabilitationDTO: table relation entre Habilitation et Role
 * fait partie de l'espace de r�f�rence
 */
public class RoleHabilitationDTO implements java.io.Serializable {

	private String id;
	private HabilitationDTO habilitation;
	private RoleDTO role;

	/**
	 * 
	 * @param id
	 */
	public RoleHabilitationDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public RoleHabilitationDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(RoleHabilitation.FIELD_ID);
		EntityProxy h = (EntityProxy) ep.getLinkedObject(RoleHabilitation.SLINK_A_HABILITATION);
		if (h != null) {
			this.habilitation = new HabilitationDTO(h);
		}
		EntityProxy r = (EntityProxy) ep.getLinkedObject(RoleHabilitation.SLINK_POUR_ROLE);
		if (r != null) {
			this.role = new RoleDTO(r);
		}
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public HabilitationDTO getHabilitation() {
		return habilitation;
	}

	public RoleDTO getRole() {
		return role;
	}

}
