/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import javax.ejb.EJBLocalObject;

/**
 * Interface Local de l'EJB session CounterManagerSB. Permet de g�rer la g�n�ration des
 * identifiants en base.
 * 
 * @author afbu7552
 */
public interface CounterManagerLocal extends CounterManager, EJBLocalObject {

}
