package com.soliste.bolbec.commun.service.interfaces.util.cxf;

import java.io.OutputStream;
import java.util.List;

import org.apache.cxf.headers.Header;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.io.CacheAndWriteOutputStream;
import org.apache.cxf.message.Exchange;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageUtils;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.service.model.OperationInfo;

import com.soliste.bolbec.commun.service.interfaces.util.cxf.accent.AccentXMLTransformInterceptor;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.grafic.GraficXMLTransform;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.InfoMessageWebSrv;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Intercepteur capturant les messages sortant
 * 
 * @author vDelamarre
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/10/2013</TD><TD>VDE</TD><TD>Migration : Ajout Intercepteurs CXF</TD></TR>
 * </TABLE>
 */
public abstract class ArchivingInterceptorOut extends AbstractPhaseInterceptor<Message> {

	private static final String CLASS_NAME = ArchivingInterceptorOut.class.getName();

	private InfoMessageWebSrv infoMessageWebSrv;

	/**
	 * 
	 */
	public ArchivingInterceptorOut(InfoMessageWebSrv infoMessageWebSrv) {
		super(Phase.PRE_STREAM);
		this.infoMessageWebSrv = infoMessageWebSrv;
		addBefore(GraficXMLTransform.class.getName());
		addBefore(AccentXMLTransformInterceptor.class.getName());
	}

	@Override
	public void handleMessage(Message message) throws Fault {
		final String method = "handleMessage";
		boolean requestor = MessageUtils.isRequestor(message);
		// Recuperation de la trame Soap
		Exchange exchange = message.getExchange();
		OperationInfo opInfo = exchange.get(OperationInfo.class);
		String service = null;
		if (opInfo != null) {
			service = opInfo.getName().getLocalPart();
			LoggerManager.getInstance().finest(CLASS_NAME, method, "R�cup�ration du service appel� : " + service);
		} else {
			LoggerManager.getInstance().finest(CLASS_NAME, method, "Impossible de r�cup�rer les infos sur l'op�ration.");
		}

		// Get the supplied SOAP envelope in the form of an InputStream
		OutputStream os = message.getContent(OutputStream.class);
		CacheAndWriteOutputStream cwos = new CacheAndWriteOutputStream(os);
		message.setContent(OutputStream.class, cwos);

		List<Header> headerList = (List<Header>) message.get(Header.HEADER_LIST);
		cwos.registerCallback(new InterceptorOutCallBack(this, requestor, service, infoMessageWebSrv, headerList));
		message.remove(Header.HEADER_LIST);
		exchange.remove(Header.HEADER_LIST);
		InterceptorUtils.misAJourHeaderAvecEmetteur(message, headerList);
	}

	/**
	 * Impl�mentation de la m�thode archive() de l'interface Archiver
	 * 
	 * @param archivable l'objet � archiver en BDD
	 */
	public abstract void archive(Archivable archivable) throws ArchivingException;

}
