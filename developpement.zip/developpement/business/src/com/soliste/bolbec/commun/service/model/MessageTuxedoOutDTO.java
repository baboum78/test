package com.soliste.bolbec.commun.service.model;

import java.util.HashMap;
import java.util.Map;

import com.soliste.bolbec.commun.service.util.archiving.Archivable;

/**
 * DTO d�crivant une trame d'un �change tuxedo
 * 
 * @author hcanosoriano
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/02/2020</TD><TD>HCS</TD><TD>US-709 Archivage des services Tuxedo</TD></TR>
 * </TABLE>
 */
public class MessageTuxedoOutDTO implements Archivable {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 9117433323461444104L;

	/** Clefs (les noms exacts des colonnes des tables routeur MessageTuxedoOut) */
	public static final String CLE_DATE_MESSAGE = "dateMessage";
	public static final String CLE_PARTENAIRE = "partenaire";
	public static final String CLE_SERVICE = "service";
	public static final String CLE_REFERENCE = "reference";
	public static final String CLE_IGD = "igd";
	public static final String CLE_REQUETE = "requete";
	public static final String CLE_REPONSE = "reponse";
	public static final String CLE_CODE_ERREUR = "codeErreur";

	/** Infos */
	private Long dateMessage;
	private String partenaire;
	private String service;
	private String reference;
	private String igd;
	private String requete;
	private String reponse;
	private String codeErreur;

	public MessageTuxedoOutDTO() {
		super();
	}

	public MessageTuxedoOutDTO(Long dateMessage, String partenaire, String service, String reference, String igd, String requete, String reponse, String codeErreur) {
		this.dateMessage = dateMessage;
		this.partenaire = partenaire;
		this.service = service;
		this.reference = reference;
		this.igd = igd;
		this.requete = requete;
		this.reponse = reponse;
		this.codeErreur = codeErreur;
	}

	public Long getDateMessage() {
		return dateMessage;
	}

	public void setDateMessage(Long dateMessage) {
		this.dateMessage = dateMessage;
	}

	public String getPartenaire() {
		return partenaire;
	}

	public void setPartenaire(String partenaire) {
		this.partenaire = partenaire;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getReference() {
		return reference;
	}

	public void setReference(String reference) {
		this.reference = reference;
	}

	public String getIgd() {
		return igd;
	}

	public void setIgd(String igd) {
		this.igd = igd;
	}

	public String getRequete() {
		return requete;
	}

	public void setRequete(String requete) {
		this.requete = requete;
	}

	public String getReponse() {
		return reponse;
	}

	public void setReponse(String reponse) {
		this.reponse = reponse;
	}

	public String getCodeErreur() {
		return codeErreur;
	}

	public void setCodeErreur(String codeErreur) {
		this.codeErreur = codeErreur;
	}

	@Override
	public Map<String, Object> toMap() {
		HashMap<String, Object> map = new HashMap<String, Object>();
		map.put(CLE_DATE_MESSAGE,dateMessage);
		map.put(CLE_PARTENAIRE,partenaire);
		map.put(CLE_SERVICE,service);
		map.put(CLE_REFERENCE, reference);
		map.put(CLE_IGD, igd);
		map.put(CLE_REQUETE,requete);
		map.put(CLE_REPONSE,reponse);
		map.put(CLE_CODE_ERREUR,codeErreur);

		return map;
	}

	@Override
	public String toString() {
		final StringBuilder sb = new StringBuilder("MessageTuxedoOutDTO{");
		sb.append("dateMessage=").append(dateMessage);
		sb.append(", partenaire='").append(partenaire).append('\'');
		sb.append(", service='").append(service).append('\'');
		sb.append(", reference='").append(reference).append('\'');
		sb.append(", igd='").append(igd).append('\'');
		sb.append(", requete='").append(requete).append('\'');
		sb.append(", reponse='").append(reponse).append('\'');
		sb.append(", codeErreur='").append(codeErreur).append('\'');
		sb.append('}');
		return sb.toString();
	}
}
