package com.soliste.bolbec.commun.service.model;

import org.apache.commons.lang.builder.ToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

import aps.TypeUnite;

import com.soliste.aps.foundation.ejb.EntityProxy;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * TypeUniteDTO fait partie de l'espace de r�f�rence
 */
public class TypeUniteDTO implements java.io.Serializable {

	private String id;
	private String libelle;

	/**
	 * 
	 * @param id
	 */
	public TypeUniteDTO(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @param ep
	 */
	public TypeUniteDTO(EntityProxy ep) {
		this.id = (String) ep.getValue(TypeUnite.FIELD_ID);
		this.libelle = (String) ep.getValue(TypeUnite.FIELD_LIBELLE);
	}

	/**
	 * 
	 */
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}

	public String getId() {
		return id;
	}

	public String getLibelle() {
		return libelle;
	}

}
