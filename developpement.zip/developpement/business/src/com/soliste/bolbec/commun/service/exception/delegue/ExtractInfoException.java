package com.soliste.bolbec.commun.service.exception.delegue;

import com.soliste.bolbec.commun.service.exception.BusinessException;

/**
 * Exception li�e au process d'extraction d'info
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>18/10/2010</TD><TD>GPA</TD><TD>EV-000087: Cr�ation de la classe</TD></TR>
 * </TABLE>
 */
public class ExtractInfoException extends BusinessException {

	/**
	 * @param msg
	 */
	public ExtractInfoException(String msg) {
		super(msg);
	}

	/**
	 * @param msg
	 * @param t
	 */
	public ExtractInfoException(String msg, Throwable t) {
		super(msg, t);
	}

}
