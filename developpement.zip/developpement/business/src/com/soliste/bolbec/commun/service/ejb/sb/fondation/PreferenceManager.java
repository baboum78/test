/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import java.util.List;
import java.util.Map;
import java.util.Properties;

import com.soliste.bolbec.commun.service.ejb.sb.commun.data.TablePreferences;

/**
 * Interface de l'EJB session PreferencesManager, permettant de g�rer les pr�f�rences
 * 
 * @author rgvs7490
 */
public interface PreferenceManager {

	/**
	 * Retourne les pr�f�rences utilisateur de la table donn�e pour l'utilisateur
	 * courant. Si l'utilisateur n'a pas de pr�f�rences pour cette table, les
	 * pr�f�rences syst�mes sont retourn�es
	 * 
	 * @param tableKey la cl� de la table
	 * @return les pr�f�rences, ou null si l'utilisateur et le syst�me n'ont aucune
	 * pr�f�rence d�finie pour cette table
	 */
	public TablePreferences getTablePreferences(String tableKey, String agentId);

	/**
	 * Retourne les pr�f�rences syst�me de la table donn�e
	 * 
	 * @param tableKey la cl� de la table
	 * @return les pr�f�rences, ou null si le syst�me n'a aucune pr�f�rence
	 * d�finie pour cette table
	 */
	public TablePreferences getSystemTablePreferences(String tableKey);

	/**
	 * Sauvegarde les pr�f�rences utilisateur de la table donn�e pour l'utilisateur
	 * courant.
	 * 
	 * @param tablePreferences les pr�f�rences
	 */
	public void saveTablePreferences(TablePreferences tablePreferences, String agentId);

	/**
	 * Retourne les pr�f�rences utilisateur de la cl� donn�e pour l'utilisateur
	 * courant. Si l'utilisateur n'a pas de pr�f�rences pour cette cl�, les
	 * pr�f�rences syst�mes sont retourn�es
	 * 
	 * @param key la cl� de pr�f�rence
	 * @return les pr�f�rences, ou null si l'utilisateur et le syst�me n'ont aucune
	 * pr�f�rence d�finie pour cette cl�
	 */
	public String getPreferences(String key, String agentId);

	/**
	 * Sauvegarde les pr�f�rences utilisateur de la cl� donn�e pour l'utilisateur
	 * courant.
	 * 
	 * @param key la cl� de pr�f�rence
	 * @param preferences les pr�f�rences
	 */
	public void savePreferences(String key, String preferences, String agentId);

	/**
	 * Retourne les pr�f�rences utilisateur de la cl� donn�e pour l'utilisateur
	 * courant, sous forme de Properties. Si l'utilisateur n'a pas de pr�f�rences pour
	 * cette cl�, les pr�f�rences syst�mes sont retourn�es
	 * 
	 * @param key la cl� de pr�f�rence
	 * @return les pr�f�rences, ou null si l'utilisateur et le syst�me n'ont aucune
	 * pr�f�rence d�finie pour cette cl�
	 */
	public Properties getPreferencesAsProperties(String key, String agentId);

	/**
	 * Sauvegarde les pr�f�rences utilisateur de la cl� donn�e pour l'utilisateur
	 * courant.
	 * 
	 * @param key la cl� de pr�f�rence
	 * @param preferences les pr�f�rences
	 */
	public void savePreferencesAsProperties(String key, Properties preferences, String agentId);

	/**
	 * Retourne la liste des pr�f�rences utilisateur de la cl� commen�ant par typeKey pour
	 * l'utilisateur courant
	 * 
	 * @param typeKey
	 * @return liste des pr�f�rences
	 */
	public List<String> getTypePreferences(String typeKey, String agentId);

	/**
	 * Supprime les pr�f�rences utilisateur de la cl� donn�e pour l'utilisateur
	 * courant.
	 * 
	 * @param key la cl� de pr�f�rence
	 * @param agentId l'id de l'agent
	 */
	public void deletePreferences(String key, String agentId);

	/**
	 * Supprime les pr�f�rences utilisateur de la cl� donn�e pour l'utilisateur
	 * courant.
	 * 
	 * @param key la cl� de pr�f�rence
	 * @param values les valeurs que doit contenir la pr�f�rence
	 * @param agentId l'id de l'agent
	 */
	public void deletePreferences(String key, Map<String, String> values, String agentId);
}
