/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.commun.service.ejb.sb.jms;

import javax.jms.JMSException;
import javax.jms.Message;

/**
 * Impl�mentation de RollbackHandler qui �vite d'envoyer trop de messages en
 * rejet. A partir d'un nombre donn� de rejets cons�cutifs, les messages qui
 * sont normalement rejet�s sont republi�s. Il appartient � l'utilisateur de cet
 * objet de remettre � z�ro le compteur de messages rejet�s.
 * 
 * @author rgvs7490
 */
public class LimitedRejectionRollbackHandler extends RollbackHandler {

	private static final int DEFAULT_MAX_REJECT_COUNT = 10;
	private int maxRejectCount;
	private RejectCounter rejectCounter;

	/**
	 * Constructeur.
	 * 
	 * @param maxRejectCount
	 * @param rejectCounter
	 */
	public LimitedRejectionRollbackHandler(int maxRejectCount, RejectCounter rejectCounter) {
		this.maxRejectCount = maxRejectCount;
		this.rejectCounter = rejectCounter;
	}

	/**
	 * Constructeur.
	 * 
	 * @param rejectCounter
	 */
	public LimitedRejectionRollbackHandler(RejectCounter rejectCounter) {
		this(DEFAULT_MAX_REJECT_COUNT, rejectCounter);
	}

	/**
	 * 
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackHandler#handleMessage(javax.jms.Message)
	 */
	public RollbackHandlerNextAction handleMessage(Message message) throws JMSException {
		if (message.getJMSRedelivered()) {
			int republicationCount = getRepublicationCountFromMessage(message);
			if (republicationCount >= getMaxRepublicationCount()) {
				int rejectCount = rejectCounter.getValue();
				if (rejectCount >= maxRejectCount) {
					/*
					 * on remet le republicationCount � 0, pour �viter que le
					 * message soit imm�diatemenr rejet� d�s que le compteur de
					 * rejets est remis � 0.
					 */
					return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_REPUBLISHED, 0);
				}
				incrementCounter();
				return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_REJECTED, 0);
			}
			int alertType = getAlertType(republicationCount);
			long sleepTime = getSleepTime(alertType);
			sleep(alertType, sleepTime);
			return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_REPUBLISHED, republicationCount + 1);
		}
		return new RollbackHandlerNextAction(RollbackHandlerNextAction.MESSAGE_MUST_BE_HANDLED, 0);
	}

	/**
	 * Reset counter
	 */
	public void resetCounter() {
		rejectCounter.reset();
	}

	/**
	 * Retourne le nombre de rejets maximum
	 * 
	 * @return le nombre de rejets maximum
	 */
	protected int getMaxRejectCount() {
		return maxRejectCount;
	}

	/**
	 * Retourne le nombre de rejets
	 * 
	 * @return le nombre de rejets
	 */
	protected int getRejectCount() {
		return rejectCounter.getValue();
	}

	/**
	 * M�thode appel�e quand le compteur de rejet est incr�ment�. Permet aux
	 * sous-classes d'ajouter une fonctionnalit� � ce moment
	 */
	protected void incrementCounter() {
		rejectCounter.increment();
	}
}