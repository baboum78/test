package com.soliste.bolbec.commun.service.ejb.sb.fondation;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * Interface remote home de l'EJB session CounterManager.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public interface CounterManagerRemoteHome extends EJBHome {

	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public CounterManagerRemote create() throws CreateException, RemoteException;
}
