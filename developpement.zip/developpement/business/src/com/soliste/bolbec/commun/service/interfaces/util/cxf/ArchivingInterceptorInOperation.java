package com.soliste.bolbec.commun.service.interfaces.util.cxf;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBException;
import javax.xml.namespace.QName;

import org.apache.cxf.binding.soap.interceptor.CheckFaultInterceptor;
import org.apache.cxf.headers.Header;
import org.apache.cxf.interceptor.Fault;
import org.apache.cxf.jaxb.JAXBDataBinding;
import org.apache.cxf.message.Message;
import org.apache.cxf.message.MessageUtils;
import org.apache.cxf.phase.AbstractPhaseInterceptor;
import org.apache.cxf.phase.Phase;
import org.apache.cxf.service.model.OperationInfo;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.constante.SoapTrameType;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.InfoMessageWebSrv;
import com.soliste.bolbec.commun.service.model.MessageWebSrvOutDTO;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;
import com.soliste.bolbec.commun.service.util.log.LoggerManager;

/**
 * Intercepteur qui capture les messages entrant, qui recupere la trame xml precedement intercept� et y ajoute l'operation
 * 
 * @author vDelamarre
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/10/2013</TD><TD>VDE</TD><TD>Migration : Ajout Intercepteurs CXF</TD></TR>
 * </TABLE>
 */
public abstract class ArchivingInterceptorInOperation extends AbstractPhaseInterceptor<Message> {

	private static final String CLASS_NAME = ArchivingInterceptorInMessage.class.getName();
	private InfoMessageWebSrv infoMessageWebSrv = new InfoMessageWebSrv();

	/**
	 * 
	 */
	public ArchivingInterceptorInOperation(InfoMessageWebSrv infoMessageWebSrv) {
		super(Phase.POST_PROTOCOL);
		if (infoMessageWebSrv != null) {
			this.infoMessageWebSrv = infoMessageWebSrv;
		}
		addAfter(CheckFaultInterceptor.class.getName());
	}

	@Override
	public void handleMessage(Message message) throws Fault {

		final String method = "handleMessage";

		OperationInfo opInfo = null;
		String operationName = "";
		if (message.getExchange() != null) {
			opInfo = message.getExchange().get(OperationInfo.class);
			if (opInfo != null) {
				if (opInfo.getName() != null) {
					operationName = opInfo.getName().getLocalPart();
				}
			}
		}
		String xml = (String) message.get(Constantes.XMLMESSAGE);
		message.remove(Constantes.XMLMESSAGE);

		if (MessageUtils.isRequestor(message)) {
			LoggerManager.getInstance().finest(CLASS_NAME, method, "XML r�ponse : " + xml);
			Archivable messageToArchive = new MessageWebSrvOutDTO(operationName, SoapTrameType.Response, xml, infoMessageWebSrv.getRefCommande());
			try {
				archive(messageToArchive);
			} catch (ArchivingException e) {
				LoggerManager.getInstance().severe(CLASS_NAME, method, "Probl�me lors de l'archivage de la trame : " + messageToArchive, e);
			}
		} else {
			LoggerManager.getInstance().finest(CLASS_NAME, method, "XML Requ�te : " + xml);
			List<Header> lstHeader = (List<Header>) message.get(Header.HEADER_LIST);
			if (lstHeader == null) {
				lstHeader = new ArrayList<Header>();
			}
			try {
				Header header = new Header(new QName(Constantes.URI_ORG_APACHE_CXF, Constantes.HEADER_ROU_MESSAGE_IN), xml, new JAXBDataBinding(String.class));
				lstHeader.add(header);
				message.put(Header.HEADER_LIST, lstHeader);
				message.getExchange().put(Header.HEADER_LIST, lstHeader);
			} catch (JAXBException e) {
				LoggerManager.getInstance().warning(CLASS_NAME, method, "Probl�me lors de l'archivage de la trame : " + xml);
			}
		}
	}

	/**
	 * 
	 * @param archivable
	 * @throws ArchivingException
	 */
	public abstract void archive(Archivable archivable) throws ArchivingException;
}
