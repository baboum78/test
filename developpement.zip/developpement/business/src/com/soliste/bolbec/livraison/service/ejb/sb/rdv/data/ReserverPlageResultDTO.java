/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import java.io.Serializable;

import com.soliste.bolbec.livraison.service.model.InterventionDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe contenant les r�sultats d'une r�servation de plage
 */
public class ReserverPlageResultDTO implements Serializable {

	private String reservationWarning;
	private boolean dateContractuelleModifiee;
	private boolean responsabiliteForceeInitiativeFT;
	private String interventionId;
	private String code;

	// IRMA_846: Permet de remonter l'intervention cr��e suite � un modifi� RDV
	private InterventionDTO nouvelleIntervention;

	public InterventionDTO getNouvelleIntervention() {
		return nouvelleIntervention;
	}

	public void setNouvelleIntervention(InterventionDTO interventionDTO) {
		this.nouvelleIntervention = interventionDTO;
	}

	/**
	 * 
	 */
	public ReserverPlageResultDTO() {

	}

	/**
	 * 
	 * @param reservationWarning
	 * @param dateContractuelleModifiee
	 * @param interventionId
	 * @param code
	 */
	public ReserverPlageResultDTO(String reservationWarning, boolean dateContractuelleModifiee, String interventionId, String code) {
		this(reservationWarning, dateContractuelleModifiee, false, interventionId, code);
	}

	/**
	 * 
	 * @param dateContractuelleModifiee
	 * @param responsabiliteForceeInitiativeFT
	 * @param interventionId
	 * @param code
	 */
	public ReserverPlageResultDTO(boolean dateContractuelleModifiee, boolean responsabiliteForceeInitiativeFT, String interventionId, String code) {
		this(null, dateContractuelleModifiee, responsabiliteForceeInitiativeFT, interventionId, code);
	}

	/**
	 * 
	 * @param reservationWarning
	 * @param dateContractuelleModifiee
	 * @param responsabiliteForceeInitiativeFT
	 * @param interventionId
	 * @param code
	 */
	public ReserverPlageResultDTO(String reservationWarning, boolean dateContractuelleModifiee, boolean responsabiliteForceeInitiativeFT, String interventionId, String code) {
		this.reservationWarning = reservationWarning;
		this.dateContractuelleModifiee = dateContractuelleModifiee;
		this.responsabiliteForceeInitiativeFT = responsabiliteForceeInitiativeFT;
		this.interventionId = interventionId;
		this.code = code;
	}

	public boolean isDateContractuelleModifiee() {
		return this.dateContractuelleModifiee;
	}

	public boolean isResponsabiliteForceeInitiativeFT() {
		return this.responsabiliteForceeInitiativeFT;
	}

	public String getReservationWarning() {
		return this.reservationWarning;
	}

	public String getInterventionId() {
		return this.interventionId;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public void setReservationWarning(String reservationWarning) {
		this.reservationWarning = reservationWarning;
	}
}
