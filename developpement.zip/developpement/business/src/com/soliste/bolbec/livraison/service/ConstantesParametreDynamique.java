package com.soliste.bolbec.livraison.service;

/**
 * Interface contenant les constantes correspondant aux cl�s et valeurs possibles dans la table ParametreDynamique
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/01/2012</TD><TD>GPA</TD><TD>EV-000168: Cr�ation de la classe</TD></TR>
 * <TR><TD>03/01/2013</TD><TD>MTE</TD><TD>EV-000216 : Fourniture de l'adresse d'installation dans les �tudes AS</TD></TR>
 * <TR><TD>21/01/2013</TD><TD>GPA</TD><TD>EV-000213 : Ajout de la constante CLE_BASE_ACTIVATION_ELIGIBILITE</TD></TR>
 * <TR><TD>08/11/2013</TD><TD>BPE</TD><TD>EV-000246 : Ajout de la constante CLE_ACTIVATION_RETOUR_NET_VERS_RTC</TD></TR>
 * <TR><TD>14/05/2014</TD><TD>VDE</TD><TD>EV-000278 : Mise en quarantaine des ND</TD></TR>
 * <TR><TD>06/08/2014</TD><TD>GCL</TD><TD>EV-000302 : Mise en place du bimode pour le CreateDossierRFSV3 d'IPON</TD></TR>
 * <TR><TD>27/10/2015</TD><TD>VDE</TD><TD> EV-248-OT envoye alors que le RDV est annule dans GPC</TD></TR>
 * <TR><TD>18/04/2017</TD><TD>GCL</TD><TD> EV-422 : Resil NET retour vers RTC</TD></TR>
 * <TR><TD>11/10/2017</TD><TD>SMO</TD><TD>EV-431 : FTTE offre active sur RIP</TD></TR>
 * </TABLE>
 */
public interface ConstantesParametreDynamique {

	public static final String CLE_BASE_ACTIVATIONLGASSOCIEE = "ACTIVATIONLGASSOCIEE_";
	public static final String CLE_BASE_ACTIVATION_ELIGIBILITE = "ACTIVATIONELIGIBILITE_";

	public static final String CLE_ACTIVATION_ADRESSE_AS = "ACTIVATION_ADRESSE_AS";
	public static final String CLE_ACTIVATION_RETOUR_NET_VERS_RTC = "ACTIVATION_RETOUR_NET_VERS_RTC";

	public static final String VALEUR_OUI = "OUI";

	// EV-278
	public static final String ANALYSE_ND_GEO_EFB = "ANALYSE_ND_GEO_EFB";

	// EV-302
	public static final String CREATE_DOSSIER_RFS_V3 = "CreateDossierRFSV3";

	// EV-248
	public static final String CLE_DESACTIV_CONTRINTERVGPC = "DESACTIV_CONTRINTERVGPC";

	// EV-422
	public static final String ACTIV_RESIL_NET_SEULE = "ACTIV_RESIL_NET_SEULE";

	// EV-431
	public static final String CREATE_DOSSIER_RFS_V4 = "CreateDossierRFSV4";
}
