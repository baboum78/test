/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Les infos d'AVP pour les AVP de type "AvpAffBLO"
 * 
 */
public class AvpOpeImbAbsDTO extends AvpInfoDTO {

	private String operatorImb;


	public String getType() {
		return AVP_OPE_IMB_ABS;
	}

	/**
	 * Getter of the operatorIMB
	 * @return
	 */
	public String getOperatorImb() {
		return operatorImb;
	}

	/**
	 * Setter of operatorIMB
	 * @param operatorIMB
	 */
	public void setOperatorImb(String operatorImb) {
		this.operatorImb = operatorImb;
	}
}
