package com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.OffreSeDTO;
import com.soliste.bolbec.livraison.service.model.ProduitServiceDTO;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.sw.custorder.ConstantesDeliverCustomerOrder;
import com.soliste.bolbec.livraison.service.sw.custorder.helper.IDeliverCustomerOrderNullHelper;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CustomerOrderItemType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.LocalSiteExternalIdentifierType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.InstalledProduct;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.LocalMarketSegment;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.Party;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.Party.LocalPersonName;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace.LocalInstalledResource;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace.LocalInstalledResource.ResourceSpecification;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace.SubAddress;

import aps.EtatInterventionConstantes;
import aps.OffreSE;
import aps.ProduitServiceConstantes;
import aps.ResponsabiliteConstantes;
import aps.SystemeExterneConstantes;
import aps.Traduction;
import aps.TypeOpProgrammeeConstantes;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.Intervention;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.OperationProgrammee;
import bolbec.injection.xml.generated.ParametreType;

/**
 * 
 * Classe sp�cifique Grafic du traitement des IC deliverCustomerOrder
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>16/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Cr�ation de la classe</TD></TR>
 * <TR><TD>22/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Fin du Dev</TD></TR>
 * <TR><TD>24/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Corrections suite � test d'int�gration</TD></TR>
 * <TR><TD>07/03/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210 - DE-000782 : Corrections suite � test d'int�gration</TD></TR>
 * <TR><TD>20/06/2013</TD><TD>EBA</TD><TD>G8R2C2 - Mise en place Sonar : suppression des accents dans noms de methodes</TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * <TR><TD>05/09/2013</TD><TD>BPE</TD><TD>DE-000936 "NullPointerException lors d'une injection d'une IC vers CustomerOrderServiceIOSW"</TD></TR>
 * <TR><TD>30/08/2013</TD><TD>VDE</TD><TD>EV-000250 "Process Vente-R�siliation automatis�e" </TD></TR>
 * <TR><TD>05/09/2013</TD><TD>BPE</TD><TD>DE-000936 "NullPointerException lors d'une injection d'une IC vers CustomerOrderServiceIOSW"</TD></TR>
 * <TR><TD>30/10/2013</TD><TD>VDE</TD><TD>EV-000227 "Mutation en masse DSLAM"</TD></TR>
 * <TR><TD>24/01/2014</TD><TD>VDE</TD><TD>DE-000990 "Mutation en masse DSLAM"</TD></TR>
 * <TR><TD>29/01/2014</TD><TD>FTE</TD><TD>EV-000283 Offre Multiligne sur commande Vente FTTH</TD></TR>
 * <TR><TD>31/10/2014</TD><TD>KRA</TD><TD>EV-000302_03 : PLP Fibre</TD></TR>
 * <TR><TD>22/02/2016</TD><TD>KWE</TD><TD>EV-367 - Injection commande avec bloc prises optiques</TD></TR>
 * <TR><TD>15/03/2018</TD><TD>CDS</TD><TD>QC-000948 Bitstream</TD></TR>
 * </TABLE>
 * 
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.4956</TD><TD>EP135 � Prendre en compte les commandes FTTH Op�rateur �mises par GRAFIC</TD></TR>
 * <TR><TD>REQ.7299</TD><TD>EP0170 - Prendre en compte les commandes issues du Frontal de Livraison</TD></TR>
 * <TR><TD>REQ.9321</TD><TD>EP0239 - Accepter les commandes de R�siliation de Vente FTTH</TD></TR>
 * <TR><TD>REQ.10376</TD><TD>EP0289 - Interpr�ter l'information concernant le type de prise existante re�ue dans les commandes de vente FTTH (EV283)</TD></TR>
 * <TR><TD>REQ.10376</TD><TD>EP0289 - Interpr�ter l'information concernant le type de prise existante re�ue dans les commandes de vente FTTH (EV283)</TD></TR>
 * <TR><TD>REQ.11787</TD><TD>EP0334 - Rep�rer et stocker les caract�ristiques des PLP Fibre dans le cadre de la vente FTTH (EV302)</TD></TR>
 * </TABLE>
 * 
 */
public class GraficTraitement extends CustomerOrderTraitement {

	/** The Constant CLASS_NAME. */
	private static final String CLASS_NAME = GraficTraitement.class.getName();

	private static final String Local_PersonName_lastName = "Local_PersonName.lastName";

	/**
	 * Constructeur
	 */
	public GraficTraitement() {
		EMETTEUR = SystemeExterneConstantes.GRAFIC;
	}

	/**
	 * @throws DeliverCustomerOrderFault
	 * @see CustomerOrderTraitement#verifLigneCommande()
	 */
	protected void verifLigneCommande() throws DeliverCustomerOrderFault {
		String method = "verifLigneCommande";
		loggerManager.fine(CLASS_NAME, method, "V�rification du nombre de lignes de commandes pour le cas m�tier " + getDeliverCustomerOrderData().getCasMetier());
		List<CustomerOrderItemType> custOrderItLst = customerOrder.getCustomerOrderItem();
		if (custOrderItLst.size() != 1) {

			throw anoCommandeMalStructuree();
		}
	}

	/**
	 * retourne la collection des fonctions obligatoires pour Grafic
	 */
	protected Collection<TraductionDTO> recupereFonctionsOblig() {
		if (Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType())) {
			return serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.FUNCTION_IC_GRAFIC_OBLIG),
					new Comparaison(Traduction.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, Constantes.CST_OUI), new Comparaison(Traduction.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.GRAFIC));
		}
		return new ArrayList<TraductionDTO>();
	}

	@Override
	protected void controleBooleans() throws DeliverCustomerOrderFault {
		// Rien � faire
	}

	@Override
	protected void controlesSpecifiques() throws DeliverCustomerOrderFault {
		final String methode = "controlesSpecifiques";

		loggerManager.fine(CLASS_NAME, methode, "Controles specifiques au cas metier " + getDeliverCustomerOrderData().getCasMetier());
		loggerManager.finest(CLASS_NAME, methode, "Contorle en fonction du type de raccordement");
		if (!ConstantesDeliverCustomerOrder.OI.equals(getKeyInAny(getDeliverCustomerOrderData().getFonctionsLc(), ConstantesDeliverCustomerOrder.TYPERACCO))) {
			return;
		}

		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(Local_PersonName_lastName, customerOrder.getCustomerOrderID());
		}
		Party party = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getUser().get(0).getParty();
		if (party == null || party.getLocalPersonName() == null) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(Local_PersonName_lastName, customerOrder.getCustomerOrderID());
		}
		final LocalPersonName loPersonName = party.getLocalPersonName();

		if (StringUtils.isBlank(loPersonName.getLastName())) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(Local_PersonName_lastName, customerOrder.getCustomerOrderID());
		}
	}

	@Override
	protected Map<String, List<ValeurParametreDTO>> recupererListeOffresElementaires() throws DeliverCustomerOrderFault {
		String method = "recupererListeOffresElementaires";
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration de la liste d'offres elementaires");
		final String offreGrafic = customerOrder.getCustomerOrderItem().get(0).getOfferSpecification().getOfferSpecificationCode();
		final Map<String, List<ValeurParametreDTO>> listeOffresElementaires;
		try {
			listeOffresElementaires = serviceManager.getTraductionManager().getTraductionOffreConcatDiff(offreGrafic, SystemeExterneConstantes.GRAFIC);
		} catch (AnomalieException ae) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(offreGrafic, customerOrder.getCustomerOrderID());
		}
		loggerManager.fine(CLASS_NAME, method, "Nombre d'offre elementaires trouv�es : " + listeOffresElementaires.size());
		return listeOffresElementaires;
	}

	@Override
	protected void valorisationChampDynamiqueOsirisOpPonctuelleOrigine(Collection<LigneCommandeType> lignesDeCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected String determineCodeClient() {
		return customerOrder.getBuyer().getPartyRoleID();
	}

	@Override
	protected String getLocalMarketSegmentLabelClientLivre() {
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return null;
		}
		final LocalMarketSegment localMarketSegment = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getUser().get(0).getLocalMarketSegment();
		if (localMarketSegment == null) {
			return null;
		}
		return localMarketSegment.getLabel();
	}

	/**
	 * RG12 : r�cup�re la valeur du champ Label dans Local_MarketSegment
	 * 
	 * @return le label du LocalMarketSegment s'il existe, sinon null
	 * @throws DeliverCustomerOrderFault
	 */
	protected String getTraductionCategorieClientLivre() throws DeliverCustomerOrderFault {
		final String methode = "getTraductionCategorieClientLivre";
		final String label = getLocalMarketSegmentLabelClientLivre();
		loggerManager.fine(CLASS_NAME, methode, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			return null;
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionCatClientInterfVersCatClientLivre(EMETTEUR, label);
		loggerManager.fine(CLASS_NAME, methode, "LocalMarketSegmentLabel traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(label, customerOrder.getCustomerOrderID());
		}
		return traduction;
	}

	@Override
	protected void fournirIdentifiantLigneDeCommande(final Collection<LigneCommandeType> lignesDeCommande, @SuppressWarnings("unused") String casMetier) {
		String method = "fournirIdentifiantLigneDeCommande";
		int indice = 1;
		String customerId = customerOrder.getCustomerOrderID();
		StringBuilder idLigneDeCommande;
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			idLigneDeCommande = new StringBuilder(30);
			idLigneDeCommande.append(customerId);
			idLigneDeCommande.append(StringUtils.leftPad(String.valueOf(indice), 2, '0'));
			ligneDeCommande.setIdLigneCommande(idLigneDeCommande.toString());
			loggerManager.finest(CLASS_NAME, method, "Identifiant ligne de commande cr�e : " + idLigneDeCommande.toString());
			indice++;
		}
	}

	@Override
	protected void fournirAccesEtTypeLivraison(final Collection<LigneCommandeType> lignesDeCommande) {
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return;
		}
		final InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			ligneDeCommande.setAccesLivraison(installedProduct != null ? installedProduct.getInstalledProductID() : null);
			ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_VIA);
		}
	}

	@Override
	protected Collection<ParametreType> creerParametresProduitServiceFunctionLc(int i) {
		final Collection<ParametreType> resultat = new ArrayList<ParametreType>();
		final List<Map<String, String>> fonctionsGraficLcLst = getDeliverCustomerOrderData().getFonctionsLc();
		if (fonctionsGraficLcLst.size() > i) {
			ParametreType parametreType;
			StringBuilder cle;
			String code;
			for (Entry<String, String> fonctionGraficLc : fonctionsGraficLcLst.get(i).entrySet()) {
				code = fonctionGraficLc.getKey();
				cle = new StringBuilder(30);
				parametreType = new ParametreType();
				if (ConstantesDeliverCustomerOrder.PROFIL.equals(code)) {
					cle.append(ConstantesDeliverCustomerOrder.PREFIX_PARAM_DET);
					cle.append(ConstantesDeliverCustomerOrder.PROFIL_MAJ);
				} else {
					cle.append(ConstantesDeliverCustomerOrder.PREFIX_FTTH);
					cle.append(code);
				}
				parametreType.setCle(cle.toString());
				parametreType.setValeur(fonctionGraficLc.getValue());
				resultat.add(parametreType);
			}
		}
		return resultat;
	}

	@Override
	protected Collection<ParametreType> creerParametresHorsFunctionSpecification() {
		final Collection<ParametreType> resultat = new ArrayList<ParametreType>();
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasLocalplace()) {
			return resultat;
		}

		// Valorisation des param�tres "VFTTH_PRISE", "VFTTH_PriseExistante" et "VFTTH_ContexteMultiligne" � partir de l'Id de la 1ere occurence Local_InstalledResource
		ParametreType parametreType;
		final List<LocalInstalledResource> listeLocalInstalledResource = customerOrder.getCouldBeRelatedToTemporarySite().getSite().get(0).getLocalPlace().get(0).getLocalInstalledResource();
		if (listeLocalInstalledResource == null || listeLocalInstalledResource.isEmpty()) {
			// Dans le cas d'une r�siliation venteFTTH, l'�l�ment localInstalledResource n'est pas pr�sent
			return resultat;
		}

		final LocalInstalledResource localInstalledResource = listeLocalInstalledResource.get(0);
		if (localInstalledResource == null) {
			// Dans le cas d'une r�siliation venteFTTH, l'�l�ment localInstalledResource n'est pas pr�sent
			return resultat;
		}

		parametreType = new ParametreType();
		parametreType.setCle(ConstantesDynamicPSSouhaite.VFTTH_PRISE_EXISTANTE);
		parametreType.setValeur(Boolean.toString(localInstalledResource.isLocalExistingInstalledResource()));
		resultat.add(parametreType);

		// Valorisation des param�tres types "PTOId" et "DTIO"
		String ptoId = null;
		String dtio = null;
		// Parcourt des LocalInstalledResource
		for (LocalInstalledResource localIR : listeLocalInstalledResource) {
			String installedResourceID = localIR.getInstalledResourceID();
			// PTOId
			if (StringUtils.isNotBlank(installedResourceID) && Constantes.PTO.equals(localIR.getResourceSpecification().getSpecificationCode())) {
				ptoId = installedResourceID;
			}
			// DTIO
			if (StringUtils.isNotBlank(installedResourceID) && Constantes.DTIO.equals(localIR.getResourceSpecification().getSpecificationCode())) {
				dtio = installedResourceID;
			}
		}

		// PtoId
		if (StringUtils.isNotBlank(ptoId)) {
			parametreType = new ParametreType();
			parametreType.setCle(ConstantesDynamicPSSouhaite.PTOID);
			parametreType.setValeur(ptoId);
			resultat.add(parametreType);
		}

		// DTIO
		if (StringUtils.isNotBlank(dtio)) {
			parametreType = new ParametreType();
			parametreType.setCle(ConstantesDynamicPSSouhaite.DTIO);
			parametreType.setValeur(dtio);
			resultat.add(parametreType);
		}

		return resultat;
	}

	/**
	 * Permet de r�cup�rer la valeur du champ sp�cification label pour la ressource sp�cification qui a un code �gal au param�tre code
	 * 
	 * @param listeLocalInstalledResource la liste des localInstalled resource
	 * @param code le code � rechercher
	 * @return le label associ� au code � rechercher ou null
	 */
	private String getValorisationLabel(List<LocalInstalledResource> listeLocalInstalledResource, String code) {
		// Recherche de la bonne occurence localInstalledResource pour le code pass� en param�tre
		for (LocalInstalledResource localInstalledResource : listeLocalInstalledResource) {
			final ResourceSpecification resourceSpecification = localInstalledResource.getResourceSpecification();
			if (resourceSpecification != null && code.equals(resourceSpecification.getSpecificationCode())) {
				return resourceSpecification.getSpecificationLabel();
			}
		}
		return null;
	}

	/**
	 * G�n�re un id intervention
	 * 
	 * @return l'idIntervention
	 */
	protected String genererIdIntervention() {
		final StringBuilder idGenere = new StringBuilder(15);
		final String counter = StringUtils.upperCase(serviceManager.getGeneratorManager().generateKey());
		idGenere.append('A');
		idGenere.append(DateUtils.format(DateUtils.getDate(), ConstantesDeliverCustomerOrder.SHORT_DATE_FORMAT));
		idGenere.append(counter);
		return idGenere.toString();
	}

	@Override
	protected void fournirInterventionEtParametresAssocies(final Commande commande, final Collection<LigneCommandeType> lignesDeCommande) throws DeliverCustomerOrderFault {
		String method = "fournirInterventionEtParametresAssocies";
		final List<Map<String, String>> fonctionsLc = getDeliverCustomerOrderData().getFonctionsLc();
		boolean typeRaccoOC, typeRaccoOI, typeRaccoMO, typeBrassageOC, typeBrassageOI;
		typeRaccoOC = estSpecificationCodeValue(fonctionsLc, ConstantesDeliverCustomerOrder.TYPERACCO, ConstantesDeliverCustomerOrder.OC);
		typeRaccoOI = estSpecificationCodeValue(fonctionsLc, ConstantesDeliverCustomerOrder.TYPERACCO, ConstantesDeliverCustomerOrder.OI);
		typeRaccoMO = estSpecificationCodeValue(fonctionsLc, ConstantesDeliverCustomerOrder.TYPERACCO, ConstantesDeliverCustomerOrder.MO);

		typeBrassageOC = estSpecificationCodeValue(fonctionsLc, ConstantesDeliverCustomerOrder.TYPEBRASSAGE, ConstantesDeliverCustomerOrder.OC);
		typeBrassageOI = estSpecificationCodeValue(fonctionsLc, ConstantesDeliverCustomerOrder.TYPEBRASSAGE, ConstantesDeliverCustomerOrder.OI);

		loggerManager.finest(CLASS_NAME, method, "TypeRaccoOC : " + typeRaccoOC + ",TypeRaccoOI : " + typeRaccoOI + ",TypeBrassageOC : " + typeBrassageOC + ",TypeBrassageOI : " + typeBrassageOI);
		loggerManager.finest(CLASS_NAME, method, "TypeRaccoMO : " + typeRaccoMO);

		if (typeRaccoOC) {
			if (typeBrassageOI) {
				fournirInterventionEtOperationProgrameeTypeBrassage(commande, lignesDeCommande);
			}
		} else if (typeRaccoOI && isAppointmentPresent()) {
			fournirInterventionEtOperationProgrameeTypeInterventionFTTH(commande, lignesDeCommande);
		}
		// pas d'operation program�e pour typeRaccoMO ou pour typeRaccoOI si aucun RDV n est present dans la cmd
	}

	/**
	 * RG15 : V�rifie si le code et la valeur pass�es en param�tre sont bien pr�sentes dans la Map fonctionsGraficLc
	 * 
	 * @param fonctionsGraficLc
	 * @param code
	 * @param value
	 * @return
	 */
	protected boolean estSpecificationCodeValue(final List<Map<String, String>> fonctionsGraficLc, final String code, final String value) {
		return value.equals(getKeyInAny(fonctionsGraficLc, code));
	}

	/**
	 * RG15 : Fournit � la ligne de commande une intervention et une op�ration programm�e de type brassage
	 * 
	 * @param commande
	 * @param lignesDeCommande
	 * @throws DeliverCustomerOrderFault
	 */
	private void fournirInterventionEtOperationProgrameeTypeBrassage(final Commande commande, final Collection<LigneCommandeType> lignesDeCommande) throws DeliverCustomerOrderFault {
		String idIntervention;
		Intervention intervention;
		Collection<ParametreType> parametreIntervention;
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			idIntervention = genererIdIntervention();
			final OperationProgrammee operationProgrammee = creerOperationProgrammeeTypeBrassage(idIntervention);
			ligneDeCommande.addOperationProgrammee(operationProgrammee);
			intervention = creerInterventionTypeBrassage(idIntervention);
			parametreIntervention = creerParametresInterventionTypeBrassage(ligneDeCommande);
			intervention.setParametre(parametreIntervention.toArray(new ParametreType[0]));
			commande.addIntervention(intervention);
		}
	}

	/**
	 * RG15 :Fournit � la ligne de commande une intervention de type brassage
	 *
	 * @param idintervention
	 */
	protected Intervention creerInterventionTypeBrassage(final String idintervention) {
		Intervention intervention = new Intervention();
		intervention.setIdIntervention(idintervention);
		intervention.setEtatIntervention(EtatInterventionConstantes.ARESERV);
		intervention.setResponsabilite(ResponsabiliteConstantes.INITIATIVE_OPERATEUR);
		intervention.setDateReservation(dateFormatee);
		return intervention;
	}

	/**
	 * RG15 : Fournit � la ligne de commande une op�ration programm�e de type brassage
	 *
	 * @param idintervention
	 */
	protected OperationProgrammee creerOperationProgrammeeTypeBrassage(final String idintervention) {
		OperationProgrammee operationProgrammee = new OperationProgrammee();
		operationProgrammee.setIdIntervention(idintervention);
		operationProgrammee.setTypeOp(TypeOpProgrammeeConstantes.BRASSAGE);
		return operationProgrammee;
	}

	/**
	 * RG15 : Cr�e les param�tres intervention pour les interventions de type brassage
	 * 
	 * @param ligneDeCommande
	 * @return
	 * @throws DeliverCustomerOrderFault
	 */
	protected Collection<ParametreType> creerParametresInterventionTypeBrassage(final LigneCommandeType ligneDeCommande) throws DeliverCustomerOrderFault {
		final String activ;
		final String prod;
		final Collection<ParametreType> resultat = new ArrayList<ParametreType>();
		final String valeurexterne = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_20Z, ConstantesTraduction.ACTIV_TYPEOPPROG, ConstantesTraduction.BRASSAGE);
		ParametreType parametreIntervention;
		if (valeurexterne == null) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(ConstantesTraduction.BRASSAGE, customerOrder.getCustomerOrderID());
		}
		activ = valeurexterne;
		final String refOffreCible = ligneDeCommande.getProduitServiceSouhaite().getRefOffreCible();
		final OffreSeDTO offreSe = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreSeDTO.class, new Comparaison(OffreSE.SLINK_EST_GERE_PAR_OFFRE_BOLBEC, Constantes.OPERATOR_EQUAL, refOffreCible),
				new Comparaison(OffreSE.SLINK_INTERFACE_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_20Z));
		if (offreSe == null) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(refOffreCible, customerOrder.getCustomerOrderID());
		}
		prod = offreSe.getCode();
		parametreIntervention = new ParametreType();
		parametreIntervention.setCle(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
		parametreIntervention.setValeur(activ);
		resultat.add(parametreIntervention);
		parametreIntervention = new ParametreType();
		parametreIntervention.setCle(ConstantesDynamicIntervention.INTERVENTION_PROD);
		parametreIntervention.setValeur(prod);
		resultat.add(parametreIntervention);
		return resultat;
	}

	/**
	 * RG15 : Fournit � la ligne de commande une intervention et une op�ration programm�e de type InterventionFTTH
	 * 
	 * @param commande
	 * @param lignesDeCommande
	 * @throws DeliverCustomerOrderFault
	 */
	private void fournirInterventionEtOperationProgrameeTypeInterventionFTTH(final Commande commande, final Collection<LigneCommandeType> lignesDeCommande) throws DeliverCustomerOrderFault {
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			final String idIntervention = genererIdIntervention();
			// QC-948 BitStream
			final OperationProgrammee operationProgrammee = new OperationProgrammee();
			operationProgrammee.setIdIntervention(idIntervention);
			operationProgrammee.setTypeOp(TypeOpProgrammeeConstantes.INTERVENTION_VENTE_FTTH);
			// offre recuperee via refOffreCible=id dans la table Offre
			String refOffreCible = ligneDeCommande.getProduitServiceSouhaite().getRefOffreCible();
			OffreDTO offre = serviceManager.getOffreManager().getOffreById(refOffreCible);
			if (offre != null) {
				ProduitServiceDTO produitService = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ProduitServiceDTO.class, offre.getProduitService().getId());
				if (ProduitServiceConstantes.VENTE_FTTH_ACTIVE_VALEUR_CONSTANTE.equalsIgnoreCase(produitService.getValeurConstante())) {
					operationProgrammee.setTypeOp(TypeOpProgrammeeConstantes.INSTALL_ONT_L);
				}
			}
			ligneDeCommande.addOperationProgrammee(operationProgrammee);
			commande.addIntervention(creerInterventionTypeInterventionFTTH(idIntervention, operationProgrammee.getTypeOp(), refOffreCible));
		}
	}

	/**
	 * RG15 : Cr�e l'intervention de type Intervention FTTH.
	 *
	 * @param idIntervention l'idIntervention
	 * @param typeOp the type operation programmee
	 * @param refOffreCible the ref offre cible
	 * @return l'intervention
	 * @throws DeliverCustomerOrderFault the deliver customer order fault
	 */
	protected Intervention creerInterventionTypeInterventionFTTH(final String idIntervention, final String typeOp, final String refOffreCible) throws DeliverCustomerOrderFault {
		final Intervention intervention = new Intervention();
		intervention.setIdIntervention(idIntervention);
		intervention.setIdPlanCharge(ConstantesDeliverCustomerOrder.ERDV);
		if (isAppointmentPresent()) {
			intervention.setRefRDV(customerOrder.getCustomerOrderItem().get(0).getAppointment().get(0).getAppointmentID());
		}
		intervention.setEtatIntervention(EtatInterventionConstantes.RESERV);
		intervention.setResponsabilite(ResponsabiliteConstantes.INITIATIVE_OPERATEUR);
		intervention.setDateReservation(dateFormatee);
		final ParametreType paramIntervOriginRDV = new ParametreType();
		paramIntervOriginRDV.setCle(ConstantesDynamicIntervention.INTERVENTION_ORIGINERDV);
		paramIntervOriginRDV.setValeur(ConstantesDynamicIntervention.INTERVENTION_ORIGINERDV_OP);
		intervention.addParametre(paramIntervOriginRDV);
		// QC-948 Bitstream
		String lActiv = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_20Z, ConstantesTraduction.ACTIV_TYPEOPPROG, typeOp);
		if (StringUtils.isBlank(lActiv)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(typeOp, customerOrder.getCustomerOrderID());
		}
		final ParametreType paramIntervLActive = new ParametreType();
		paramIntervLActive.setCle(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
		paramIntervLActive.setValeur(lActiv);
		intervention.addParametre(paramIntervLActive);
		final OffreSeDTO offreSe = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreSeDTO.class, new Comparaison(OffreSE.SLINK_EST_GERE_PAR_OFFRE_BOLBEC, Constantes.OPERATOR_EQUAL, refOffreCible),
				new Comparaison(OffreSE.SLINK_INTERFACE_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_20Z));
		if (null == offreSe) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(refOffreCible, customerOrder.getCustomerOrderID());
		}
		final ParametreType paramIntervLProd = new ParametreType();
		paramIntervLProd.setCle(ConstantesDynamicIntervention.INTERVENTION_PROD);
		paramIntervLProd.setValeur(offreSe.getCode());
		intervention.addParametre(paramIntervLProd);
		return intervention;
	}

	/**
	 * Retourne true si l'appointment est present sinon retourne false
	 * 
	 * @return
	 */
	protected boolean isAppointmentPresent() {
		return customerOrder.getCustomerOrderItem() != null && !customerOrder.getCustomerOrderItem().isEmpty() && customerOrder.getCustomerOrderItem().get(0).getAppointment() != null
				&& !customerOrder.getCustomerOrderItem().get(0).getAppointment().isEmpty();
	}

	@SuppressWarnings("unused")
	@Override
	protected void verifPrestaClipEtDebit(List<Map<String, String>> fonctionsLcTraduites) throws DeliverCustomerOrderFault {
		// Ne rien faire, champs non pr�sents dans le cas de Grafic
	}

	/**
	 * RG5
	 * 
	 * @return la categorie du client contractant (pas d'anomalie si le champ ou traduction absent)
	 */
	protected String determineCategorieClientContractant() throws DeliverCustomerOrderFault {
		final String method = "determineCategorieClientContractant";
		final String label = recupererLabelLocalMarketSegmentClientContractant();
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.SEGMENT_MARCHE, label);
		loggerManager.fine(CLASS_NAME, method, "LocalMarketSegmentLabels traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			return label;
		}
		return traduction;
	}

	@Override
	@SuppressWarnings("unused")
	protected void valorisationParametresLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		// Ne rien faire, Non utilis� dans le cas de grafic

	}

	@Override
	@SuppressWarnings("unused")
	protected void valorisationContexteLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		// Ne rien faire, Non utilis� dans le cas de grafic

	}

	@Override
	protected void valorisationChampsDynamiquesLC(Collection<LigneCommandeType> lignesCommande) {

		if (!lignesCommande.isEmpty()) {

			// R�cup�ration de la ligne de commande
			LigneCommandeType lc = lignesCommande.iterator().next();

			// Helper
			IDeliverCustomerOrderNullHelper helper = deliverCustomerOrderData.getDeliverCustomerOrderNullHelper();

			// Verification de pr�sence des champs n�cessaires aux traitements
			if (helper.hasCouldBeRelatedToTemporarySite() && helper.hasLocalplace()) {

				// R�cup�ration du site
				List<SiteType> sites = customerOrder.getCouldBeRelatedToTemporarySite().getSite();

				SiteType site = CollectionUtils.getFirstOrNull(sites);

				if (site != null) {
					// R�cup�ration du LocalPlace + subAddress + localSiteExternalIdentifier
					LocalPlace localPlace = site.getLocalPlace().get(0);
					SubAddress subAddress = localPlace.getSubAddress();
					LocalSiteExternalIdentifierType localSiteExternalIdentifier = site.getLocalSiteExternalIdentifier();
					if (subAddress != null && localSiteExternalIdentifier != null) {
						// Valorisation des champs dynamiques
						List<LocalInstalledResource> localInstalledResource = localPlace.getLocalInstalledResource();
						addParameterLivraison(lc, EFBConstantes.ID_SISSI, site.getSiteID());
						addParameterLivraison(lc, EFBConstantes.ID_SISSI_BAT, subAddress.getLocalBuildingID());
						addParameterLivraison(lc, EFBConstantes.ID_SISSI_ESC, subAddress.getLocalStaircaseID());
						addParameterLivraison(lc, EFBConstantes.ID_SISSI_ET, subAddress.getLocalFloorID());
						addParameterLivraison(lc, EFBConstantes.IMB, localSiteExternalIdentifier.getExternalID());
						if (localInstalledResource.get(0) != null) {
							addParameterLivraison(lc, EFBConstantes.PLP_SANS_PT_OID, localInstalledResource.get(0).isLocalExistingInstalledResource() ? Constantes.CST_SHORT_YES : Constantes.CST_SHORT_NO);
						}
					}
				}
			}
		}
	}

	/**
	 * Permet de r�cup�rer le site qui contient la r�f�rence "Optimum"
	 * 
	 * @return le site qui contient la r�f�rence "Optimum"
	 */
	private SiteType getSiteOptimum() {

		List<SiteType> sites = customerOrder.getCouldBeRelatedToTemporarySite().getSite();
		if (sites != null) {
			for (SiteType site : sites) {
				if (site.getLocalSiteExternalIdentifier() != null && OPTIMUM_NAME.equals(site.getLocalSiteExternalIdentifier().getExternalReferentiel().value())) {
					return site;
				}
			}
		}
		return null;
	}

	/**
	 * Permet l'ajout d'un param�tre de livraison � partir de sa cl� et de sa valeur
	 * 
	 * @param lc la ligne de commande concern�e
	 * @param key la cl� du param�tre
	 * @param value la valeur du param�tre
	 */
	private void addParameterLivraison(LigneCommandeType lc, String key, String value) {
		if (StringUtils.isNotBlank(value)) {
			ParametreType parameter = new ParametreType();
			parameter.setCle(key);
			parameter.setValeur(value);
			lc.addParametreLivraison(parameter);
		}
	}
}
