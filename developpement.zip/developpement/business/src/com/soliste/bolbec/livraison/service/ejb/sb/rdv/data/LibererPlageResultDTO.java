/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import java.io.Serializable;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe contenant les r�sultats d'une lib�ration de plage
 */
public class LibererPlageResultDTO implements Serializable {

	private String liberationWarning;
	private String newInterventionId;

	/**
	 * 
	 * @param liberationWarning
	 * @param newInterventionId
	 */
	public LibererPlageResultDTO(String liberationWarning, String newInterventionId) {
		this.liberationWarning = liberationWarning;
		this.newInterventionId = newInterventionId;
	}

	public String getLiberationWarning() {
		return this.liberationWarning;
	}

	public String getNewInterventionId() {
		return this.newInterventionId;
	}
}
