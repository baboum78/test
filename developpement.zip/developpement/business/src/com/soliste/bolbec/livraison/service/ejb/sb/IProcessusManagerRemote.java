package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;
import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.model.AttenduDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.PredossierDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusLcDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusSuspendusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;

/**
 * Interface metier de l'ejb <code>ProcessusManagerSB</code>.<br/>
 * Permet de rechercher des entit�es li�es � un processus<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>30/07/2012</TD><TD>BPE</TD><TD>EV-184 : ajout des m�thodes filtrerEvtByTypeEvenement et recupererEvtPlusRecente</TD></TR>
 * <TR><TD>27/05/2013</TD><TD>GPA</TD><TD>G8R2C2 � Tech : Passage du type de transaction des m�thodes des EJB Remote en RequiresNew</TD></TR>
 * <TR><TD>29/05/2013</TD><TD>EBA</TD><TD>G8R2C2 BackOffice : Cr�ation methodes necessaires avec NewTransaction</TD></TR>
 * <TR><TD>29/04/2016</TD><TD>JDE</TD><TD>Ajout de la m�thode findTacheByLibelleCourtAndProcessus</TD></TR>
 * </TABLE>
 */
public interface IProcessusManagerRemote {

	/**
	 * R�cup�re un processus.
	 * 
	 * @param processusId the processus id
	 * 
	 * @return the processus
	 */
	ProcessusDTO getProcessus(String processusId) throws RemoteException;

	/**
	 * Mets � jour les champs <code>BPIID</code> et <code>BPName</code> d'un processus
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusBp(ProcessusDTO processusDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>ModifManuelleEtat</code> d'un processus.
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusModifManuelleEtat(ProcessusDTO processusDTO) throws RemoteException;

	/**
	 * Cr�e un processus.
	 * Attention il faut que l'id <code>processusDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param processusDTO the processus dto
	 * 
	 * @return processusDTO
	 */
	ProcessusDTO createProcessus(ProcessusDTO processusDTO) throws RemoteException;

	/**
	 * R�cup�re la liste des Processus d'une commande
	 * 
	 * @param commandeId Identifiant de la commande
	 * 
	 * @return List de ProcessusDTO
	 */
	List<ProcessusDTO> findProcessusByCommandeWithNewTransaction(String commandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des processus d'une ligne de commande
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * 
	 * @return the list of ProcessusDTO
	 */
	List<ProcessusDTO> findProcessusByLigneCommande(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re le processus pere le plus recent d'une ligne de commande
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * 
	 * @return ProcessusDTO
	 */
	ProcessusDTO findProcessusByLigneCommandeAndPereAndPlusRecent(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des sous processus g�n�r�s par un processus donn�, n'�tant pas annul� par un processus et dont l'�tat est different etatId.
	 * 
	 * @param genereParProcessusId the genere par processus id
	 * @param etat the etat
	 * 
	 * @return the list< processus dt o>
	 */
	List<ProcessusDTO> findSousProcessusByGenereParProcessusAndNotAnnuleParProcessusAndNotEtat(String genereParProcessusId, String etat) throws RemoteException;

	/**
	 * R�cup�re la liste des processus dont l'�tat est etatId et appel�s par une t�che d'id tacheId
	 * 
	 * @param tacheId
	 * @return la liste des processus d'�tat etatId appel�s par une t�che d'id tacheId
	 */
	List<ProcessusDTO> findProcessusByEtatAndAppelerParTache(String etatId, String tacheId) throws RemoteException;

	/**
	 * Mets � jour les champs <code>EtatProcessus</code>
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusEtatWithNewTransaction(ProcessusDTO processusDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>AnnuleParProcessus</code>
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusAnnuleParProcessus(ProcessusDTO processusDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>AppelleParTache</code>
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusAppeleParTache(ProcessusDTO processusDTO) throws RemoteException;

	/**
	 * R�cup�re la liste des processus appel�s par une t�che d'id tacheId
	 * 
	 * @param tacheId
	 * @return la liste des processus appel�s par une t�che d'id tacheId
	 */
	List<ProcessusDTO> findProcessusAppelerParTache(String tacheId) throws RemoteException;

	/**
	 * R�cup�re le processus p�re d'une t�che d'id tacheId
	 *
	 * @param tacheId
	 * @return le processus p�re d'une t�che d'id tacheId
	 */
	ProcessusDTO findProcessusByTacheId(String tacheId) throws RemoteException;

	/**
	 * R�cup�re le processus p�re d'une t�che qui a d�clench� un evennement d'id evtId
	 *
	 * @param evtId
	 * @return le processus p�re d'une t�che qui a d�clench� un evennement d'id evtId
	 */
	ProcessusDTO findProcessusByEvtId(String evtId) throws RemoteException;

	/**
	 * R�cup�re la tache pour l'�venement evtId
	 * 
	 * @param evtId
	 * @return La tache
	 */
	TacheDTO findTacheByEvt(String evtId) throws RemoteException;

	/**
	 * R�cup�re la tache pour l'�venement evtId
	 *
	 * @param evtId
	 * @param bIncludeReferences
	 * @return La tache
	 */
	TacheDTO findTacheByEvt(String evtId, boolean bIncludeReferences) throws RemoteException;

	/**
	 * R�cup�re une liste de tache pour un processus donn�
	 *
	 * @param processusId the processus id
	 *
	 * @return the list
	 */
	List<TacheDTO> findTacheByLanceParProcessus(String processusId) throws RemoteException;

	/**
	 * R�cup�re une liste de tache pour un processus donn� rang� par date d'ex�cution
	 *
	 * @param processusId the processus id
	 *
	 * @return the list
	 */
	List<TacheDTO> findTacheByLanceParProcessusRangeParDate(String processusId) throws RemoteException;


	/**
	 * @see ProcessusManager#findTacheByLanceParProcessusAndIdExterneRangeParDate(String, String)
	 */
	List<TacheDTO> findTacheByLanceParProcessusAndIdExterneRangeParDate(String processusId, String tacheIdExterne) throws RemoteException ;

	/**
	 * R�cup�re une liste de tache pour un libell� court et un processus donn�
	 * 
	 * @param libelleCourt the libelle court
	 * @param processusId the processus id
	 * 
	 * @return the list
	 */
	List<TacheDTO> findTacheByLibelleCourtAndProcessus(String libelleCourt, String processusId) throws RemoteException;

	/**
	 * R�cup�re la tache plus recente dont le libell� court est tacheLibelleCourt , lanc�es par le processus d'identifiant processusId
	 * et dont l'id est diff�rent de tacheId.
	 * 
	 * @param tacheId the tache id
	 * @param tacheLibelleCourt the tache libelle court
	 * @param processusId the processus id
	 * 
	 * @return la tache
	 */
	TacheDTO findTacheByDifferentIdAndLibelleCourtAndProcessusAndSortReverseDPMAD(String tacheId, String tacheLibelleCourt, String processusId) throws RemoteException;



	/**
	 * Cr�e une tache
	 * 
	 * @param tacheDTO the tache dto
	 * 
	 * @return the tache dto
	 */
	TacheDTO createTache(TacheDTO tacheDTO) throws RemoteException;

	/**
	 * R�cup�re une tache.
	 * 
	 * @param tacheId the tache id
	 * 
	 * @return the tache
	 */
	TacheDTO getTache(String tacheId) throws RemoteException;

	/**
	 * R�cup�re une tache.
	 *
	 * @param tacheId the tache id
	 * @param bIncludeReferences whether include or not dependencies recursively
	 *
	 * @return the tache
	 */
	TacheDTO getTache(String tacheId, boolean bIncludeReferences) throws RemoteException;

	/**
	 * Mets � jour une tache
	 * 
	 * @param tacheDTO the tache dto
	 */
	void updateTache(TacheDTO tacheDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>lieeATache</code> d'une tache
	 * 
	 * @param tacheDTO the tache dto
	 */
	void updateTacheLieeATache(TacheDTO tacheDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>cleVariante</code> et
	 * le le champ <code>valeurVariante</code> d'une tache
	 * 
	 * @param tacheDTO the tache dto
	 */
	void updateTacheVariante(TacheDTO tacheDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>faitParRole</code> d'une tache
	 * 
	 * @param tacheDTO the tache dto
	 */
	void updateTacheFaitParRole(TacheDTO tacheDTO) throws RemoteException;

	/**
	 * Cr�e un evenement
	 * 
	 * @param evtDTO the evt dto
	 * 
	 * @return the evt dto
	 */
	EvtDTO createEvt(EvtDTO evtDTO) throws RemoteException;

	/**
	 * R�cup�re un evenement � partir de son id evtId
	 * 
	 * @param evtId
	 * @return un evenement
	 */
	EvtDTO getEvt(String evtId) throws RemoteException;

	/**
	 * Mets � jour la date de cr�ation d'un evenement
	 * 
	 * @param evtDTO the evt dto
	 */
	void updateEvtDateCreation(EvtDTO evtDTO) throws RemoteException;

	/**
	 * R�cup�re la liste des evenements pour un processus
	 * 
	 * @param processusId the process id
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByProcessus(String processusId) throws RemoteException;

	/**
	 * R�cup�re la liste des evenements pour un processus
	 * 
	 * @param processusId the process id
	 * 
	 * @return the list of EvtDTO
	 */
	Map<String, EvtDTO> findMapEvtByProcessus(String processusId) throws RemoteException;

	/**
	 * R�cup�re la liste des evenements pour une tache
	 * 
	 * @param tacheId the tache id
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByTache(String tacheId) throws RemoteException;

	/**
	 * R�cup�re la liste des evenements generes par une tache
	 * 
	 * @param tacheId the tache id
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findGeneratedEvtByTache(String tacheId) throws RemoteException;

	/**
	 * R�cup�re la liste des evenements pour un processus et un typeAbd donn�es
	 * 
	 * @param processusId the process id
	 * @param typeAbd the type abd
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByProcAndTypeAbd(String processusId, String typeAbd) throws RemoteException;

	/**
	 * R�cup�re la liste des evenements d'une certaine cause pour un processus donn�es
	 * 
	 * @param processusId the process id
	 * @param cause The cause
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByProcAndCause(String processusId, String cause) throws RemoteException;

	/**
	 * R�cup�re l'evenement le plus r�cent pour un processus et dont le type de la cause �v�nement vaut typeEvt
	 * 
	 * @param processusId the process id
	 * @param typeEvt the type evt
	 * 
	 * @return the list of EvtDTO
	 */
	EvtDTO findEvtByProcAndTypeEvtAndPlusRecent(String processusId, String typeEvt) throws RemoteException;

	/**
	 * R�cup�re les �v�nements li�s � la commande et dont le typeEvenement est celui pass� en param�tre.
	 * Pour information, il s'agit de la recherche d�crite dans la RG3 de IHM_LIV_ECRAN_Notes.doc.
	 * Cela consiste, � descendre depuis la commande, vers les lignes de commandes, puis les processus, puis
	 * les tache (de lancement), puis d'une part, vers les �v�nements, ou d'autre part, vers les
	 * (sous-)processus, puis vers les taches (du sous-processus), vers enfin les �v�nemnts.
	 * 
	 * @param commandeId
	 * @param typeEvenementValConst Valeur constante du TypeEvenement
	 * @return
	 */
	List<EvtDTO> findEvtByCommandeAndTypeEvenement(String commandeId, String typeEvenementValConst) throws RemoteException;

	/**
	 * Permet la r�cup�ration des EVT pour une commande
	 * 
	 * @param commandeId L'identifiant de la commande
	 * @return La liste des ev�nements pour la commande
	 */
	List<EvtDTO> findEvtByCommande(String commandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des evenements associ�s aux t�ches lanc�es par le processus pour un type evt donn�.
	 * 
	 * On passe par un finder pour r�cup�rer la liste de ces �v�nements.
	 * La raison : suite aux optimisations faites au niveau du chargement des donn�es de processus, dans l'espace de donn�es du processus courant
	 * il se peut qu'il n'y ait que la t�che courante d'accessible, et non pas toutes les t�ches lanc�es par le processus.
	 * Pour obtenir l'ensemble des �v�nements associ�s aux t�ches lanc�es par le processus, on passe donc par un finder sur la table Evt.
	 * A partir de ces �v�n�ments, on r�cup�re leur TypeEvenement via la CauseEvenement.
	 * On ne conserve que les �v�nement de type typeEvt.
	 * 
	 * @param processusId the process id
	 * @param typeEvt the type evt
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtParTacheLanceeParProcessusAndTypeEvt(String processusId, String typeEvt) throws RemoteException;

	/**
	 * R�cup�re une tache en cours.
	 * 
	 * @param tacheEnCoursId the tache tache en cours id
	 * 
	 * @return the tache en cours
	 */
	TacheEnCoursDTO getTacheEnCours(String tacheEnCoursId) throws RemoteException;

	/**
	 * R�cup�re une liste de tache en cours pour un processus donn�
	 * 
	 * @param processusId Le processus id
	 * 
	 * @return La liste de <code>TacheEnCoursDTO</code>
	 */
	List<TacheEnCoursDTO> findTacheEnCoursByProcessus(String processusId) throws RemoteException;

	/**
	 * R�cup�re une liste de tache en cours pour une commande donn�e
	 * 
	 * @param commandeId Le commande id
	 * 
	 * @return La liste de <code>TacheEnCoursDTO</code>
	 */
	List<TacheEnCoursDTO> findTacheEnCoursByCommande(String commandeId) throws RemoteException;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheEnCoursByProcessusAndIdExterne(java.lang.String, java.lang.String)
	 */
	List<TacheEnCoursDTO> findTacheEnCoursByProcessusAndIdExterne(String processusId, String tacheIdExterne) throws RemoteException;

	/**
	 * Cr�e une tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 * 
	 * @return the tache en cours dto
	 */
	TacheEnCoursDTO createTacheEnCours(TacheEnCoursDTO tacheEnCoursDTO) throws RemoteException;

	/**
	 * Mets � jour la tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 */
	void updateTacheEnCours(TacheEnCoursDTO tacheEnCoursDTO) throws RemoteException;

	/**
	 * Mets � jour le champ ZoneGeo de la tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 */
	void updateTacheEnCoursZoneGeo(TacheEnCoursDTO tacheEnCoursDTO) throws RemoteException;

	/**
	 * Mets � jour le champ Role de la tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 */
	void updateTacheEnCoursRole(TacheEnCoursDTO tacheEnCoursDTO) throws RemoteException;

	/**
	 * Supprime la tache en cours.
	 * 
	 * @param tacheEnCoursId the tache en cours id
	 */
	void deleteTacheEnCours(String tacheEnCoursId) throws RemoteException;

	/**
	 * Supprimer les occurrences de TacheEnCours telles que
	 * TacheEnCours.IdCommande = Id_Commande dont on veut interrompre le
	 * traitement automatique (pour Regul Manuel).
	 * 
	 * @param processusId
	 */
	void deleteTacheEnCoursByProcessus(String processusId) throws RemoteException;

	/**
	 * Supprimer les occurrences de TacheEnCours telles que
	 * TacheEnCours.IdCommande = Id_Commande, TacheEnCours.IdProcessus = Id_Processus
	 * et TacheEnCours.LibelleCourt = LibelleCourt dont on veut interrompre le
	 * traitement automatique (pour Regul Manuel).
	 * 
	 * @param commandeId
	 * @param processusId
	 * @param libelleCourt
	 */
	void deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt(String commandeId, String processusId, String libelleCourt) throws RemoteException;

	/**
	 * R�cup�re la liste des processus fils du processus pass� par son id
	 * 
	 * @param idProcessusPere
	 * @return La liste des <code>ProcessusDTO</code> fils
	 */
	List<ProcessusDTO> findProcessusFils(String idProcessusPere) throws RemoteException;

	/**
	 * Cr�ation d'un enregistrement ProcessusLc
	 * 
	 * @param processusLC
	 */
	ProcessusLcDTO createProcessusLC(ProcessusLcDTO processusLC) throws RemoteException;

	/**
	 * R�cup�re le processus d'un type donn�e et d'une ligne de commande donn�e par sa r�f�rence externe
	 * 
	 * @param refExterneLigneCommande
	 * @param typeProcessusId
	 * @return le <code>ProcessusDTO</code> correspondant (si trouv�, null sinon)
	 */
	ProcessusDTO findProcessusParRefExterneLigneCommandeEtType(String refExterneLigneCommande, String typeProcessusId) throws RemoteException;

	/**
	 * Retourne le processus p�re correspondant � la tache.
	 * 
	 * @param tacheId
	 * @return
	 */
	ProcessusDTO findProcessusByTacheAndPere(String tacheId) throws RemoteException;

	/**
	 * Retourne le processus en fonction de l'id de la commande, dont l'�tat n'est ni "ANNUL", ni "TERM" et qui n'est pas g�n�r� par un processus
	 * 
	 * @param commandeId
	 * @return Processus
	 */
	ProcessusDTO findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(String commandeId) throws RemoteException;

	/**
	 * Cr�ation d'un enregistrement ProcessusSuspendus
	 * 
	 * @param processusSuspendusDTO
	 * @return
	 */
	ProcessusSuspendusDTO createProcessusSuspendus(ProcessusSuspendusDTO processusSuspendusDTO) throws RemoteException;

	/**
	 * Supprime les instances de ProcessusSuspendus dont ProcessusSuspendus.IDPere = identifiant du processus fourni en entr�e
	 * 
	 * @param processusId
	 */
	void deleteProcessusSuspendusByIdPere(String processusId) throws RemoteException;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findeEvtDe(Collection)
	 */
	List<EvtDTO> findEvtDirectByCommande(String commandeId) throws RemoteException;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#recupererEvtPlusRecente(Collection)
	 */
	EvtDTO recupererEvtPlusRecente(Collection<EvtDTO> evtsList) throws RemoteException;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#filtrerEvtByTypeEvenement(Collection, String)
	 */
	Collection<EvtDTO> filtrerEvtByTypeEvenement(Collection<EvtDTO> evtsList, String typeEvenement) throws RemoteException;

	/**
	 * Cr�e une ligne dans la table Attendu
	 *
	 * @param attenduDTO la ligne � cr�er
	 *
	 * @return attenduDTO
	 */
	AttenduDTO createAttendu(AttenduDTO attenduDTO) throws RemoteException;

	/**
	 * Supprime une ligne dans la table Attendu
	 *
	 * @param idAttendu l'id de la ligne � supprimer
	 *
	 */
	void deleteAttendu(String idAttendu) throws RemoteException;

	/**
	 * Recherche une ligne dans la table Attendu
	 *
	 * @param idAttendu de la ligne � rechercher
	 *
	 * @return attenduDTO
	 */
	AttenduDTO rechercheAttendu(String idAttendu) throws RemoteException;

	/**
	 * Mets � jour le champs <code>PourCommande</code>
	 *
	 * @param idProcessus the id processus
	 * @param idComamnde the id commande
	 *
	 */
	void updateProcessusIdCommande(String idProcessus, String idComamnde) throws RemoteException;

	/**
	 * Cr�e une ligne dans la table Predossier
	 *
	 * @param predossierDTO la ligne � cr�er
	 *
	 * @return PredossierDTO
	 */
	PredossierDTO createPredossier(PredossierDTO predossierDTO) throws RemoteException;

	/**
	 * Modifie une ligne dans la table Predossier
	 *
	 * @param predossierDTO la ligne � modifier
	 *
	 * @return PredossierDTO
	 */
	void updatePredossier(PredossierDTO predossierDTO) throws RemoteException;

	/**
	 * Recherche une ligne dans la table Predossier
	 *
	 * @param idPredossier de la ligne � rechercher
	 *
	 * @return PredossierDTO
	 */
	PredossierDTO recherchePredossier(String idPredossier) throws RemoteException;
}
