/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.util;

import java.util.List;

import aps.FiltrageIC42C;
import aps.SystemeExterneConstantes;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.IC42CConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.IC_42C;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.FiltrageIc42CDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>08/12/2010</TD><TD>LBA</TD><TD>Refactoring CAST : passage constante en premier dans assertion equals</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>20/08/2017</TD><TD>AJO</TD><TD>EV-442 D�num�rotation</TD></TR>
 * </TABLE>
 * The Class ValidationUtil.
 * 
 * @author
 */
public class ValidationUtil {

	/** Nom de la classe. */
	private static final String CLASS_NAME = ValidationUtil.class.getName();

	protected static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	/**
	 * valider verifie la conformit� d'une intention de commande 42C.
	 * 
	 * @param a_message the a_message
	 * 
	 * @return the i c_42 c
	 */
	public static IC_42C valider(String a_message) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "valider", "Debut : message = " + a_message);

		String[] l_msgTokenizer = a_message.split(IC42CConstantes.SEPARATEUR, -1);

		// v�rifier les valeurs possibles et les champs obligatoires
		IC_42C l_ic42c = validerChamps(l_msgTokenizer);

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "valider", "Fin");
		return l_ic42c;
	}

	/**
	 * estAccepte v�rifie si l'IC 42C doit donner lieu � une IC Artemis : RG10.
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>03/05/2010</TD><TD>YTR</TD><TD>IRMA_805 : correction du filtrage pour els commandes de Denum </TD></TR>
	 * 
	 * @param a_ic42c the a_ic42c
	 * 
	 * @return true, if est accepte
	 */
	public static boolean estAccepte(IC_42C a_ic42c) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "estAccepte", "Debut");
		// Construction de la condition pour la recherche dans la table FiltrageIC42C

		Comparaison typeCommandeComparaison = new Comparaison(FiltrageIC42C.FIELD_TYPE_COMMANDE, Constantes.OPERATOR_LIKE, a_ic42c.getTypeCommande());

		// Le MotifResil peut etre null en base. Dans ce cas l'operateur � utiliser est "is null" et non like
		Comparaison motifResilComparaison = null;
		if (StringUtils.isNotEmpty(a_ic42c.getMotifResil())) {
			motifResilComparaison = new Comparaison(FiltrageIC42C.FIELD_MOTIF_RESIL, Constantes.OPERATOR_LIKE, a_ic42c.getMotifResil());
		} else {
			motifResilComparaison = new Comparaison(FiltrageIC42C.FIELD_MOTIF_RESIL, Constantes.OPERATOR_IS_NULL, null);
		}

		Comparaison offre42cComparaison = new Comparaison(FiltrageIC42C.FIELD_OFFRE42_C, Constantes.OPERATOR_LIKE, a_ic42c.getOffre());

		List<FiltrageIc42CDTO> filtrageIc42CDTOs = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(FiltrageIc42CDTO.class, typeCommandeComparaison, motifResilComparaison, offre42cComparaison);

		// Recherche des occurrences de la table FiltrageIC42C satisfaisant cette condition
		return filtrageIc42CDTOs.isEmpty();
	}

	// EV-442 V�rification que la commande 42C n'est pas d�j� une commande efb
	public static boolean estDoublon(IC_42C a_ic42c) {
		SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, "estDoublon", "Debut");

		if (IC42CConstantes.TYPE_CDE_DENUM.equals(a_ic42c.getTypeCommande())) {
			List<CommandeDTO> commandesByND = SERVICE_MANAGER.getCommandeManager().findCommandeByND(a_ic42c.getAncienNd());
			for (CommandeDTO commandeByND : commandesByND) {
				SystemeExterneDTO systemeExterne = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commandeByND.getSystemeExterne().getId());
				if (SystemeExterneConstantes.EFB_VALEUR_CONSTANTE.equals(systemeExterne.getValeurConstante())) {
					List<LigneCommandeDTO> lignesCommande = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(commandeByND.getId());
					for (LigneCommandeDTO ligneCommande : lignesCommande) {
						if (a_ic42c.getAncienNd().equals(ligneCommande.getNdFinder()) && EFBConstantes.DENUM.equals(ligneCommande.getTypeOpPonctuelles().getId())) {
							return true;
						}
					}
				}
			}
		}
		return false;
	}

	/**
	 * validerChamps v�rifie le format des champs de l'IC 42C et construit un
	 * objet IC_42C si tous les champs sont valides.
	 * 
	 * @param a_msgTokenizer the a_msg tokenizer
	 * 
	 * @return the i c_42 c
	 */
	private static IC_42C validerChamps(String[] a_msgTokenizer) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerChamps", "Debut");

		// V�rification du champ Type de Commande
		String l_typeCommande = a_msgTokenizer[0];
		validerTypeCommande(l_typeCommande);

		// R�cup�ration du champ Date de Publication
		String l_datePublication = a_msgTokenizer[1];

		// R�cup�ration du champ Date d'Ev�nement
		String l_dateEvt = a_msgTokenizer[2];

		// R�cup�ration du champ Ancien ND
		String l_ancienND = a_msgTokenizer[3];

		// V�rification du champ Nouveau ND
		String l_nouveauND = a_msgTokenizer[4];
		if (l_typeCommande.equals(IC42CConstantes.TYPE_CDE_DENUM)) {
			validerPresenceChamp(l_nouveauND, "Nouveau ND");
		}

		// R�cup�ration du champ Ancien Nom
		String l_ancienNom = a_msgTokenizer[5];

		// V�rification du champ Nouveau Nom
		String l_nouveauNom = a_msgTokenizer[6];
		if (l_typeCommande.equals(IC42CConstantes.TYPE_CDE_CNOM)) {
			validerPresenceChamp(l_nouveauNom, "Nouveau nom");
		}

		// R�cup�ration du champ Offre
		String l_offre = a_msgTokenizer[7];

		// R�cup�ration du champ Prestation
		String l_prestation = a_msgTokenizer[8];

		// R�cup�ration du champ Code Provider
		String l_codeProvider = a_msgTokenizer[9];

		// R�cup�ration du champ Renvoi R�partiteur
		String l_renvoiRepartiteur = a_msgTokenizer[10];

		// V�rification du champ Motif R�siliation
		String l_motifResiliation = a_msgTokenizer[11];
		validerMotifResil(l_motifResiliation, l_typeCommande);

		// R�cup�ration du champ Segment de March�
		String l_segmentMarche = a_msgTokenizer[12];

		// R�cup�ration du champ EDS Installation
		String l_edsInstallation = a_msgTokenizer[13];

		// R�cup�ration du champ Centre Rattachement
		String l_centreRattachement = a_msgTokenizer[14];

		// R�cup�ration du champ Op�rateur
		String l_operateur = a_msgTokenizer[15];

		// Cr�ation de l'objet IC_42C
		IC_42C l_ic42c = new IC_42C(l_typeCommande, l_datePublication, l_dateEvt, l_ancienND, l_nouveauND, l_ancienNom, l_nouveauNom, l_offre, l_prestation, l_codeProvider, l_renvoiRepartiteur, l_motifResiliation, l_segmentMarche, l_edsInstallation,
				l_centreRattachement, l_operateur);

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerChamps", "Fin");
		return l_ic42c;
	}

	/**
	 * validerTypeCommande valide les valeurs possible du champ Type de commande.
	 * 
	 * @param typeCommande the a_type commande
	 */
	private static void validerTypeCommande(String typeCommande) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerTypeCommande", "Debut");
		// V�rifier les valeurs possibles
		if ((typeCommande == null)
				|| (!typeCommande.equals(IC42CConstantes.TYPE_CDE_RESIL) && !typeCommande.equals(IC42CConstantes.TYPE_CDE_CNOM) && !typeCommande.equals(IC42CConstantes.TYPE_CDE_CHGT) && !typeCommande.equals(IC42CConstantes.TYPE_CDE_DENUM))) {
			// anomalie IC42C_SYNTAXE
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "validerTypeCommande", "La valeur du champ Type de commande (" + typeCommande + ") est incorrecte!");
			throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_SYNTAXE, "Anomalie format d'injection");
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerTypeCommande", "Fin");
	}

	/**
	 * validerMotifResil valide les valeurs possible du champ Motif r�siliation.
	 * 
	 * @param a_motifResiliation the a_motif resiliation
	 * @param a_typeCommande the a_type commande
	 */
	private static void validerMotifResil(String a_motifResiliation, String a_typeCommande) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerMotifResil", "Debut. MotifResil = " + a_motifResiliation);
		// V�rifier le format du champ Motif r�siliation
		if (a_typeCommande.equals(IC42CConstantes.TYPE_CDE_RESIL)) {
			validerPresenceChamp(a_motifResiliation, "Motif resiliation");

			// V�rifier les valeurs possibles
			if (!a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_PO) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_RD) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_RO)
					&& !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_TL) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_TS) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_SLS)
					&& !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_STX)) {
				// anomalie IC42C_SYNTAXE
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "validerMotifResil", "La valeur du champ Motif resiliation (" + a_motifResiliation + ") est incorrecte!");
				throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_SYNTAXE, "Anomalie format d'injection");
			}
		} else {
			// V�rifier les valeurs possibles
			if (!a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_PO) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_RD) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_RO)
					&& !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_TL) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_TS) && !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_SLS)
					&& !a_motifResiliation.equals(IC42CConstantes.MOTIF_RESIL_STX) && StringUtils.isNotEmpty(a_motifResiliation)) {
				// anomalie IC42C_SYNTAXE
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "validerMotifResil", "La valeur du champ Motif resiliation (" + a_motifResiliation + ") est incorrecte!");
				throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_SYNTAXE, "Anomalie format d'injection");
			}
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerMotifResil", "Fin");
	}

	/**
	 * validerPresenceChamp v�rifie la pr�sence d'un champ d'IC 42C.
	 * 
	 * @param a_champ the a_champ
	 * @param a_nomChamp the a_nom champ
	 */
	private static void validerPresenceChamp(String a_champ, String a_nomChamp) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerPresenceChamp", "Debut : v�rification de la pr�sence du champ " + a_nomChamp + " dont la valeur est '" + a_champ + "'");
		// V�rification de la pr�sence du champ
		if (StringUtils.isEmpty(a_champ)) {
			// anomalie IC42C_SYNTAXE
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "validerPresenceChamp", "Le champ " + a_nomChamp + " n'est pas renseigne!");
			throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_SYNTAXE, "Anomalie format d'injection");
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "validerPresenceChamp", "Fin");
	}
}
