/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedFieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedFieldDTOFactory;

/**
 * 
 * Factory pour SelectedFieldDTO workflow
 * 
 * @author gdzd8490
 * 
 */
public class WfSelectedFieldDTOFactory implements SelectedFieldDTOFactory {

	private static WfSelectedFieldDTOFactory instance = null;

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static WfSelectedFieldDTOFactory getInstance() {
		if (instance == null) {
			instance = new WfSelectedFieldDTOFactory();
		}
		return instance;
	}

	private WfSelectedFieldDTOFactory() {
		// pour �viter instanciation inutile
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedFieldDTOFactory#createSelectedField(java.lang.String)
	 */
	public SelectedFieldDTO createSelectedField(String id) {
		WfSelFilter wfField = (WfSelFilter) WfCorbeilleTranslator.getInstance().translate(id);
		SelectedField field = new WfSelectedField(wfField);
		SelectedFieldDTO dto = new SelectedFieldDTO();
		dto.setSelectedField(field);
		return dto;
	}

}
