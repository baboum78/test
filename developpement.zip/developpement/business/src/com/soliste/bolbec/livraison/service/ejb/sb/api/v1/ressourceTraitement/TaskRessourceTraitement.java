package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfException;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.ConstantesAPI;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager;
import com.soliste.bolbec.livraison.service.ejb.sb.WfServices;
import com.soliste.bolbec.livraison.service.ejb.sb.api.utils.TaskUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCause;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCauseRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Role;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Task;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.TaskStatus;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.AvpManager;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.CloturerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.ReassignerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfTache;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.WorkflowManager;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowLoadDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.exception.UnavailableTaskException;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.publication.INotificationGeneriqueManager;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.VersionArtemisUtil;

import aps.CategorieEvenementConstantes;
import aps.CauseEvenementConstantes;

/**
 * Traitement des ressources Task
 * 
 * @author mfayd
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>27/12/2015</TD><TD>MFA</TD><TD>Initialisation TaskRessourceTraitement</TD></TR>
 * <TR><TD>23/03/2016</TD><TD>KWE</TD><TD>EV_353_01 Ajout champ date dans cloturerAVP</TD></TR>
 * <TR><TD>20/10/2017</TD><TD>AJO</TD><TD>QC-896 Changement erreur renvoy�e pour r�assignation t�che r�serv�e</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>API REST</TD></TR>
 * </TABLE>
 */
public class TaskRessourceTraitement {
	/**
	 * Manager Utils
	 */
	protected final CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
	protected final ProcessusManager PROCESSUS_MANAGER = ServiceManager.getInstance().getProcessusManager();
	protected final ILoggerManager LOGGERMANAGER = ServiceManager.getInstance().getLoggerManager();
	protected final WfServices WFSERVICES = ServiceManager.getInstance().getWfServices();
	protected final AvpManager AVP_MANAGER = ServiceManager.getInstance().getAvpManager();
	protected final WorkflowManager WKF_MANAGER = ServiceManager.getInstance().getWorkflowManager();
	protected final INotificationGeneriqueManager NOTIFICATION_GENERIQUE_MANAGER = ServiceManager.getInstance().getNotificationGeneriqueManager();

	private static final String CLASS_NAME = TaskRessourceTraitement.class.getName();
	private static final String REASSIGNAVP = "REASSIGNAVP";
	private static final String STRING_UNDERSCORE = "_";

	public TaskRessourceTraitement() {

	}

	/**
	 * patchTask afin de cloturer la tache pour la commande d'id idCommande
	 * 
	 * @param idCommande
	 * @param idtache
	 * @param task
	 * @param context
	 * @return
	 * @throws WfException
	 */
	public Response cloturerAVP(String idCommande, String idtache, Task task, MessageContext context) {
		String methode = "patchTask";
		LOGGERMANAGER.fine(CLASS_NAME, methode, " mise a jour de la tache id :" + idtache + " pour la commande la commande id :" + idCommande);
		if (StringUtils.isBlank(idtache)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskidnotfound.createAPIException();
		}
		if (StringUtils.isBlank(idCommande)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskorderidnotfound.createAPIException();
		}

		CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByTache(idtache);

		if (commandeDTO == null) {
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		if ((!idCommande.equals(commandeDTO.getId()))) {
			// ERR 404
			throw APIExceptionEnum.taskidorderandorderidnotlinked.createAPIException(idCommande);
		}

		TacheDTO tacheDTO = PROCESSUS_MANAGER.getTache(idtache);

		if (tacheDTO == null) {
			// ERR 400 badRequest
			throw APIExceptionEnum.tasknotfound.createAPIException(idtache);
		}

		if (tacheDTO.getEvt() == null) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskeventnull.createAPIException(idtache);
		}

		if (tacheDTO.getEvt().getCauseEvenement() == null) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskcauseeventnull.createAPIException(idtache);
		}

		if (TaskStatus.unknown.equals(task.getState())) {
			throw APIExceptionEnum.taskbadstatus.createAPIException();
		}

		TacheEnCoursDTO tacheec = PROCESSUS_MANAGER.getTacheEnCours(idtache);
		if (tacheec == null) {
			throw APIExceptionEnum.tasknotinprogress.createAPIException();
		}
		if (StringUtils.isNotBlank(tacheDTO.getLibelle())) {
			task.setLabel(tacheDTO.getLibelle());
		}
		if (StringUtils.isNotBlank(tacheDTO.getLibelleCourt())) {
			task.setShortLabel(tacheDTO.getLibelleCourt());
		}

		task.setId(tacheDTO.getId());

		// Obtention de l'User et du workflow permettant d'acc�der aux causes ev�nement de la t�che.
		final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
		AgentDTO agent = ServiceManager.getInstance().getAgentManager().getCurrentAgent(agentName, StringUtils.lowerCase(Constantes.APPLICATION_TYPE));
		WfUser wfU = WFSERVICES.getWfUser(agent);
		WfActivity wfActivity = WKF_MANAGER.getWfActivity(wfU, idCommande, idtache);
		if (wfActivity == null) {
			throw APIExceptionEnum.taskwkfactivitynull.createAPIException();
		}
		WfTache wftache = new WfTache(wfActivity);
		ProcessusDTO process = PROCESSUS_MANAGER.findProcessusByTacheAndPere(idtache);

		// SI pas de date renseign�:
		Calendar date = Calendar.getInstance();
		// Si l'utilisateur veut juste changer le r�le de la tache
		if (!tacheDTO.getFaitParRole().getId().equals(task.getAssignatedRole()) && !TaskStatus.finished.equals(task.getState())) {
			if (task.getAssignatedRole() != null && !TaskUtils.estUnRolePourReassigner(wftache, (String) task.getAssignatedRole())) {
				throw APIExceptionEnum.taskrolenotreassignable.createAPIException();
			}
			// si le statut de la t�che n'est pas renseign�
			if (task.getAssignatedRole() == null) {
				throw APIExceptionEnum.taskstatusnull.createAPIException();
			}
			String info = task.getLabel();
			CauseEvenementDTO causeEvenement = CollectionUtils.getFirstOrNull(TaskUtils.getCauseEvenementAutoriseesPourCategorie(CategorieEvenementConstantes.REASSIGN, VersionArtemisUtil.getVersion(process)));
			if (!REASSIGNAVP.equals(causeEvenement.getValeurConstante())) {
				throw APIExceptionEnum.tasknotcausereassignable.createAPIException();
			}

			try {
				task.setDate(date);
				try {
					WKF_MANAGER.reserver(wfActivity, agent.getFullName());
				} catch (UnavailableTaskException e) {
					throw APIExceptionEnum.taskalreadyreserved.createAPIException(tacheDTO.getId());
				}
				AVP_MANAGER.reassignerAvp(tacheec.getId(), info, causeEvenement.getId(), (String) task.getAssignatedRole(), agent.getId(), wfActivity, agent);

			} catch (ReassignerAvpException e) {
				try {
					 if (!wfActivity.isAvailable() && wfActivity.isReservedBySameUser()) {
						 WKF_MANAGER.liberer(wfActivity);
					 }
				} catch (Exception e2) {
					LOGGERMANAGER.warning(CLASS_NAME, methode, " erreur dans la liberation de l'activity apr�s �chec de la reassignation de la commande " + idCommande);
				}
				throw APIExceptionEnum.tasknotcausereassignable.createAPIException();
			} finally {
				// US-678 Notification pour action de reasignation
				String valPrec = tacheDTO.getFaitParRole().getId();
				NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A, NotificationGeneriqueConstantes.TYPE_ASSIG,tacheDTO.getId(),
						valPrec,(String) task.getAssignatedRole(), agent.getId(), idCommande);
				NOTIFICATION_GENERIQUE_MANAGER.emettreNotification(ng);
			}
			
			return Response.ok(task).build();
		}

		// // Si on essaie de r�assigner une t�che au r�le qu'elle a d�j�
		if (tacheDTO.getFaitParRole().getId().equals(task.getAssignatedRole())) {
			throw APIExceptionEnum.taskrolenotreassignable.createAPIException(idtache);
		}

		// Si le r�le est identique et que la t�che du body n'est pas en statut finished
		if (!TaskStatus.finished.equals(task.getState())) {
			throw APIExceptionEnum.tasknotstatusfinished.createAPIException(idtache);
		}

		// Si l'on souhaite cl�turer la t�che.
		EventCauseRef eventCauseRef = task.getClosureEventCause();

		if (eventCauseRef == null) {
			throw APIExceptionEnum.taskeventcauserefnull.createAPIException(idtache);
		}

		if (StringUtils.isBlank(eventCauseRef.getId())) {
			// Err 404
			throw APIExceptionEnum.taskeventcauserefidnull.createAPIException(idtache);
		}

		// La � closureEventCause.Id � doit correspondre � une cause existante et autoris�e pour la t�che concern�e
		// R�cup�ration des causes evenements disponibles
		List<EventCause> causeEvenements;

		try {
			causeEvenements = TaskUtils.getCauseEvenementAutoriseesPourCloturer(wftache);
		} catch (DataException e2) {
			throw APIExceptionEnum.tasklisteventcausenull.createAPIException(tacheDTO.getId());
		}

		// On v�rifie que les �l�ments donn�s dans la t�che Task existent bien dans la liste de causes autoris�es pour cloturer.
		if (!TaskUtils.estDansListeCausePossiblePourCloturer(causeEvenements, eventCauseRef)) {
			// ERR 404 Task non trouv�
			throw APIExceptionEnum.taskcausenotpossible.createAPIException(tacheDTO.getId(), task.getClosureEventCause().getId());
		}

		// On modifie les objets EvtDTO et CauseEvenementDTO associ�s � la tache
		EvtDTO evt = tacheDTO.getEvt();
		CauseEvenementDTO causeEvenementDTO = evt.getCauseEvenement();

		if (causeEvenementDTO == null) {
			causeEvenementDTO = new CauseEvenementDTO(commandeDTO.getVersionArtemis() + STRING_UNDERSCORE + eventCauseRef.getId());
		} else {
			causeEvenementDTO.setId(commandeDTO.getVersionArtemis() + STRING_UNDERSCORE + eventCauseRef.getId());
		}

		evt.setCauseEvenement(causeEvenementDTO);

		if (StringUtils.isNotBlank(eventCauseRef.getComment())) {
			evt.setInfo(eventCauseRef.getComment());
		}

		// On met a jour je Evt associe a la tache
		tacheDTO.setEvt(evt);

		// Initialisation des valeurs WfTache et proprietesWorkflow permettant de cl�turer la t�che.
		Map<String, String> proprietesWorkflow = wfActivity.getValues();

		if (CauseEvenementConstantes.AFFECSATURATION_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId()) || (CauseEvenementConstantes.DESATBLFT_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId()))
				|| (CauseEvenementConstantes.DESATBLORT_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId())) || (CauseEvenementConstantes.AFFECSATURATIONBL_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId()))) {
			// Si on est dans le cas o� nous pouvons renseigner la date
			if (task.getDate() == null) {
				throw APIExceptionEnum.taskdatenotfound.createAPIException();
			}
			Date startOfToday = DateUtils.createStartOfDay(new Date());
			if (task.getDate().getTime().before(startOfToday)) {
				throw APIExceptionEnum.taskdatetoosoon.createAPIException();
			}
			date = org.apache.commons.lang3.time.DateUtils.toCalendar(task.getDate().getTime());
		}

		task.setDate(date);

		// Permet de reserver la t�che.
		try {
			WKF_MANAGER.reserver(wfActivity, agent.getFullName());
		} catch (UnavailableTaskException e1) {
			throw APIExceptionEnum.taskalreadyreserved.createAPIException(tacheDTO.getId());
		}
		try {
			CloturerAvpCommande commande = TaskUtils.createCommande(proprietesWorkflow, date.getTime(), wftache, tacheDTO.getId(), task.getClosureEventCause().getComment(), causeEvenementDTO.getId(), task.getData(), null);
			AVP_MANAGER.cloturerAvp(commande, wfU);
		} catch (CloturerAvpException e) {
			WKF_MANAGER.liberer(wfActivity);
			throw APIExceptionEnum.taskcloseexception.createAPIException(tacheDTO.getId());
		} catch (Exception e1) {
			WKF_MANAGER.liberer(wfActivity);
			throw APIExceptionEnum.generic415.createAPIException();
		} finally {
			// US-678 Notification pour action de cloturer
			NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A, NotificationGeneriqueConstantes.TYPE_TERM, idtache, wfU.getId(), idCommande);
			NOTIFICATION_GENERIQUE_MANAGER.emettreNotification(ng);
		}


		if (tacheDTO.getFaitParRole() != null) {
			task.setAssignatedRole(tacheDTO.getFaitParRole().getId());
		}
		return Response.ok(task).build();
	}

	/**
	 * getTask Retourner la tache associ�e � la commande d'id idCommande
	 * 
	 * @param idCommande
	 * @param idtache
	 * @param context
	 * @return
	 */
	public Response getTache(String idCommande, String idtache, @SuppressWarnings("unused") MessageContext context) {
		if (StringUtils.isBlank(idCommande)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskorderidnotfound.createAPIException();
		}

		if (StringUtils.isBlank(idtache)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskidnotfound.createAPIException();
		}

		CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByTache(idtache);

		if (commandeDTO == null) {
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		if ((!idCommande.equals(commandeDTO.getId()))) {
			// ERR 404
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		TacheDTO tacheDTO = PROCESSUS_MANAGER.getTache(idtache);
		if (tacheDTO == null) {
			// ERR 404 Task non trouv�
			throw APIExceptionEnum.taskidnotfound.createAPIException(idtache);
		}

		// On cree l objet de sortie
		Task task = new Task();

		task.setId(idtache);

		// Si la tache est presente dans TacheEncours alors status:inprogress,sinon status:finished
		TacheEnCoursDTO tacheEncours = PROCESSUS_MANAGER.getTacheEnCours(idtache);
		if (tacheEncours != null) {
			task.setState(TaskStatus.inprogress);
		} else {
			task.setState(TaskStatus.finished);
		}

		// On construit l objet eventCauseRef
		EventCauseRef eventCauseRefTache = new EventCauseRef();
		EvtDTO evtTache = tacheDTO.getEvt();

		TaskUtils.initialiserEventCauseRef(evtTache, eventCauseRefTache);
		task.setClosureEventCause(eventCauseRefTache);

		if (StringUtils.isNotBlank(tacheDTO.getLibelle())) {
			task.setLabel(tacheDTO.getLibelle());
		}
		if (StringUtils.isNotBlank(tacheDTO.getLibelleCourt())) {
			task.setShortLabel(tacheDTO.getLibelleCourt());
		}

		if (tacheDTO.getFaitParRole() != null) {
			task.setAssignatedRole(tacheDTO.getFaitParRole().getId());
		}

		return Response.ok(task).build();
	}

	/**
	 * getListEventCause
	 * Retourne la liste des cause evenements possibles
	 * 
	 * @param idCommande
	 * @param idtache
	 * @param context
	 * @return
	 */
	public Response getCausesEvenementsByTacheId(String idCommande, String idtache, MessageContext context) {
		if (StringUtils.isBlank(idCommande)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskorderidnotfound.createAPIException();
		}

		if (StringUtils.isBlank(idtache)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskidnotfound.createAPIException();
		}

		CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByTache(idtache);

		if (commandeDTO == null) {
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		if (!idCommande.equals(commandeDTO.getId())) {
			// ERR 404
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		TacheEnCoursDTO tacheDTO = PROCESSUS_MANAGER.getTacheEnCours(idtache);
		if (tacheDTO == null) {
			// ERR 404 Task non trouv�
			throw APIExceptionEnum.tasknotfound.createAPIException(idtache);
		}
		TacheDTO tache = PROCESSUS_MANAGER.getTache(idtache);
		// Obtention de l'User et du workflow permettant d'acc�der aux causes ev�nement de la t�che.
		final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
		AgentDTO agent = ServiceManager.getInstance().getAgentManager().getCurrentAgent(agentName, StringUtils.lowerCase(Constantes.APPLICATION_TYPE));
		WfUser wfU = WFSERVICES.getWfUser(agent);
		if (tache.getEvt() == null) {
			throw APIExceptionEnum.taskeventnull.createAPIException(idtache);
		}
		WfActivity wfActivity = WKF_MANAGER.getWfActivity(wfU, idCommande, idtache);
		if (wfActivity == null) {
			throw APIExceptionEnum.tasklisteventnotwkfactivity.createAPIException(tacheDTO.getId());
		}
		WfTache wftache = new WfTache(wfActivity);
		// R�cup�ration des causes evenements disponibles
		List<EventCause> eventlst;

		try {
			eventlst = TaskUtils.getCauseEvenementAutoriseesPourCloturer(wftache);
		} catch (DataException e2) {
			throw APIExceptionEnum.tasklisteventcausenull.createAPIException(tacheDTO.getId());
		}

		if (eventlst.isEmpty()) {
			throw APIExceptionEnum.tasklisteventcausenull.createAPIException(idtache);
		}
		return Response.ok(eventlst).build();
	}

	public Response getRolesByTacheId(String idCommande, String idtache, MessageContext context) {
		if (StringUtils.isBlank(idCommande)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskorderidnotfound.createAPIException();
		}

		if (StringUtils.isBlank(idtache)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskidnotfound.createAPIException();
		}

		CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByTache(idtache);

		if (commandeDTO == null) {
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		if (!idCommande.equals(commandeDTO.getId())) {
			// ERR 404
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		TacheEnCoursDTO tacheDTO = PROCESSUS_MANAGER.getTacheEnCours(idtache);
		if (tacheDTO == null) {
			// ERR 404 Task non trouv�
			throw APIExceptionEnum.tasknotfound.createAPIException(idtache);
		}

		TacheDTO tache = PROCESSUS_MANAGER.getTache(idtache);

		// Obtention de l'User et du workflow permettant d'acc�der aux r�les de la t�che.
		final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
		final AgentDTO agent = ServiceManager.getInstance().getAgentManager().getCurrentAgent(agentName, StringUtils.lowerCase(Constantes.APPLICATION_TYPE));
		final WfUser wfU = WFSERVICES.getWfUser(agent);
		final WorkflowLoadDTO wkf = WKF_MANAGER.load(idCommande, wfU);
		final WfActivity wfActivity = TaskUtils.recupererWfActivityViaTache(wkf, tache);
		final WfTache wftache = new WfTache(wfActivity);

		List<Role> roles = TaskUtils.getRoles(wftache);
		return Response.ok(roles).build();
	}

	public void validate(@SuppressWarnings("unused") Task task) {

	}

}
