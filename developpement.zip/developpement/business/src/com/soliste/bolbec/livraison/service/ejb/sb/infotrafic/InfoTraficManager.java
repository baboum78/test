package com.soliste.bolbec.livraison.service.ejb.sb.infotrafic;

import java.io.InputStream;
import java.util.Collection;
import java.util.List;

import javax.ejb.EJBLocalObject;

import com.soliste.bolbec.livraison.service.enumeration.infotrafic.EtatEnum;
import com.soliste.bolbec.livraison.service.model.InfoTraficDTO;
import com.soliste.bolbec.livraison.service.model.StatistiqueDTO;

/**
 * Interface de l'EJB Session InfoTraficManager
 * G�re les indicateurs infotrafic
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/02/2014</TD><TD>BPE</TD><TD>EV-000276 : G8R2C4 - Mise en place de l'infoTrafic</TD></TR>
 * </TABLE>
 * 
 */
public interface InfoTraficManager extends EJBLocalObject {

	/**
	 * @return la requ�te infotrafic correspondante, ou null si aucune requ�te trouv�e
	 */
	InfoTraficDTO findRequeteById(final String id);

	/**
	 * @return la collection de requ�tes infotrafic Actives
	 */
	Collection<InfoTraficDTO> findRequetesActives();

	/**
	 * @return l'�tat globale lorsque le mode manuel est activ�
	 */
	EtatEnum getEtatGlobal();

	/**
	 * En fonction des seuils et du r�sultat, met � jour l'�tat de l'ensemble des requ�tes
	 * 
	 * @param infosTraficListe la collection de requ�tes infotrafic
	 * @return l'�tat global une fois la mise � jour effectu�e
	 */
	EtatEnum updateEtatRequetes(final Collection<InfoTraficDTO> infosTraficListe);

	/**
	 * @param etat l'�tat � filtrer
	 * @return la collection de requ�tes infotrafic Actives en filtrant sur l'�tat
	 * 
	 * @throws NullPointerException si l'�tat est null
	 */
	Collection<InfoTraficDTO> findRequetesActivesFilterByEtat(final EtatEnum etat);

	/**
	 * @return true si mode automatique, sinon false
	 */
	boolean isModeAuto();

	/**
	 * @return la requ�te infoTrafic "mode manuel". retourne null si la requ�te n'existe pas
	 */
	InfoTraficDTO getRequeteModeManuel();

	/**
	 * Active le mode automatique. Ne fait rien sur le mode auto est d�j� activ�
	 */
	void activerModeAutomatique();

	/**
	 * Active le mode manuel. mets � jour la rubrique MODEMANUEL, l'�tat indicateur et fournit le contenu du fichier de r�sultat
	 * 
	 * @param descriptionRubrique la description de la rubrique
	 * @param libelle le libell� de la requ�te MODEMANUEL
	 * @param etatIndicateur l'�tat � mettre � jour
	 * @param commandeImpIs le contenu de fichiers de commandes impact�es � t�l�charger
	 */
	void activerModeManuel(String descriptionRubrique, String libelle, EtatEnum etatIndicateur, InputStream commandeImpIs);

	/**
	 * R�cup�re l'historique des �tats globaux tri�es par date du plus r�cent au plus ancien
	 */
	List<StatistiqueDTO> extraireHistoriqueListEtatsGlobaux();
}
