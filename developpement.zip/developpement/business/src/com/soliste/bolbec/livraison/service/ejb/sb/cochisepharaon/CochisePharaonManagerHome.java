package com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 * Interface home de l'EJB session CochisePharaonManager.
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * </TABLE>
 */
public interface CochisePharaonManagerHome extends EJBLocalHome {

	/** Permet de cr�er une instance de l'EJB */
	public CochisePharaonManager create() throws CreateException;

}