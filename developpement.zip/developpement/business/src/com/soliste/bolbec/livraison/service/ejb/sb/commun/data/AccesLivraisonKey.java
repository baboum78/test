/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.commun.data;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import aps.LigneCommande;

import com.soliste.bolbec.livraison.service.enumeration.TypeAccesLivraisonEnum;
import com.soliste.bolbec.livraison.service.model.EpCommercialDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>29/05/2012</TD><TD>AGR</TD><TD>EV-000188 : Vente FTTH</TD></TR>
 * <TR><TD>14/10/2013</TD><TD>BPE</TD><TD>EV-000250 : Refactoring + R�vision de l'algo</TD></TR>
 * </TABLE><BR>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQ.4963</TD><TD>Func - EP0142 - Utilise le num�ro VIA � la place du ND, pour les commandes FTTH op�rateur</TD></TR>
 * </TABLE>
 */

/**
 * Classe d�finissant la cl� d'un acc�s de livraison � partir d'une ligne de
 * commande. Les LCs ayant la m�me cl� d'acc�s de livraison font partie de ce
 * m�me acc�s
 * 
 */
public class AccesLivraisonKey implements Comparable<AccesLivraisonKey> {

	private final IServiceManager serviceManager = ServiceManager.getInstance();

	private String key;
	private String reference;
	private TypeAccesLivraisonEnum type;

	/**
	 * @param lc
	 */
	public AccesLivraisonKey(LigneCommande ligneCommande) {
		final LigneCommandeDTO lc = new LigneCommandeDTO(ligneCommande);
		final EpCommercialDTO epcSupport = serviceManager.getCommandeManager().findEpCommercialByLigneCommande(lc.getId());
		init(epcSupport, lc);
	}

	/**
	 * 
	 * @param lc
	 */
	public AccesLivraisonKey(LigneCommandeDTO lc) {
		final EpCommercialDTO epcSupport = serviceManager.getCommandeManager().findEpCommercialByLigneCommande(lc.getId());
		init(epcSupport, lc);
	}

	/**
	 * Comparateur
	 */
	public int compareTo(AccesLivraisonKey a) {
		int result = type.getValue() - a.type.getValue();
		if (result == 0) {
			result = key.compareTo(a.key);
		}
		return result;
	}

	/**
	 * 
	 */
	public boolean equals(Object o) {
		if (o instanceof AccesLivraisonKey) {
			AccesLivraisonKey a = (AccesLivraisonKey) o;
			return (a.type == type) && a.key.equals(key);
		}
		return false;
	}

	/**
	 * @return reference
	 */
	public String getReference() {
		return reference;
	}

	/**
	 * @return type
	 */
	public TypeAccesLivraisonEnum getType() {
		return type;
	}

	/**
	 * 
	 */
	public int hashCode() {
		return key.hashCode();
	}

	/**
	 * Initialise les attributs de classe
	 * 
	 * @param epcSupport
	 * @param lc
	 * @param commande
	 */
	private void init(final EpCommercialDTO epcSupport, final LigneCommandeDTO lc) {
		final LigneCommandeDTO lcTraitee;

		// Si une ligne de commande EtudeNA est trouv�e sur la commande, on r�cup�re les informations de celle-ci
		final LigneCommandeDTO ligneCommandeEtudeNA = getLigneCommandeEtudeNA(lc.getIdCommande());
		if (ligneCommandeEtudeNA != null) {
			lcTraitee = ligneCommandeEtudeNA;
		} else {
			lcTraitee = lc;
		}
		type = TypeAccesLivraisonEnum.valueOf(lcTraitee.getTypeAccesLivraison());
		key = lcTraitee.getAccesLivraison();
		reference = lcTraitee.getAccesLivraison();

		// Dans le cas o� le type est un ND, NDPLP, IDCLI ou FTTH, on r�cup�re le nd ou l'idexterne de l'epc seulement si cet epc est li� � une offre
		// Dans les autres cas, on s'arr�te ici
		if (!Arrays.asList(TypeAccesLivraisonEnum.NDPLP, TypeAccesLivraisonEnum.ND, TypeAccesLivraisonEnum.FTTH, TypeAccesLivraisonEnum.IDCLI).contains(type) || epcSupport == null || epcSupport.getOffre() == null) {
			return;
		}

		final String nd = epcSupport.getNd();
		final String idExterne = epcSupport.getIdExterne();

		if (StringUtils.isNotBlank(nd)) {
			key = nd;
			reference = nd;
			type = TypeAccesLivraisonEnum.ND;
		} else if (StringUtils.isNotBlank(idExterne)) {
			key = idExterne;
			reference = idExterne;
			type = TypeAccesLivraisonEnum.ND;
		}
	}

	/**
	 * R�cup�re la ligne de commande Etude NA, si elle existe
	 * 
	 * @param commande la commande
	 * @return la ligne de commande Etude NA si elle existe, sinon null
	 */
	private LigneCommandeDTO getLigneCommandeEtudeNA(final String idCommande) {
		final List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByCommande(idCommande);
		for (LigneCommandeDTO ligneCde : lignesCde) {
			if (Arrays.asList(TypeAccesLivraisonEnum.NDPLP.name(), TypeAccesLivraisonEnum.IDCLI.name()).contains(ligneCde.getTypeAccesLivraison())) {
				return ligneCde;
			}
		}

		return null;
	}
}