package com.soliste.bolbec.livraison.service.ejb.sb.infotrafic;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.rmi.RemoteException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.commons.io.IOUtils;
import org.apache.commons.lang3.StringUtils;

import aps.InfoTrafic;
import aps.InfoTraficHome;
import aps.ParametreArtemisConstantes;

import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.commun.service.util.IGeneratorManager;
import com.soliste.bolbec.fwk.jndi.ServiceLocator;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager;
import com.soliste.bolbec.livraison.service.ejb.sb.parametreDynamique.ParametreDynamiqueManager;
import com.soliste.bolbec.livraison.service.enumeration.infotrafic.EtatEnum;
import com.soliste.bolbec.livraison.service.enumeration.infotrafic.ModeEnum;
import com.soliste.bolbec.livraison.service.enumeration.infotrafic.TypeSeuilEnum;
import com.soliste.bolbec.livraison.service.model.InfoTraficDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.ParametreDynamiqueDTO;
import com.soliste.bolbec.livraison.service.model.RubriqueAccueilDTO;
import com.soliste.bolbec.livraison.service.model.StatistiqueDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Impl�mentation de l'EJB InfoTraficManager
 * 
 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/02/2014</TD><TD>BPE</TD><TD>EV-000276 : G8R2C4 - Mise en place de l'infoTrafic</TD></TR>
 * </TABLE>
 */
public class InfoTraficManagerBean implements SessionBean {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -9031706522709302424L;

	/** Nom de la classe */
	private static final String CLASSNAME = InfoTraficManagerBean.class.getSimpleName();

	/** Param�tre dynamique INFOTRAFIC_MODE */
	private static final String PARAM_DYN_INFOTRAFIC_MODE = "INFOTRAFIC_MODE";

	/** Param�tre dynamique INFOTRAFIC_ETAT_GLOBAL */
	private static final String PARAM_DYN_INFOTRAFIC_ETAT_GLOBAL = "INFOTRAFIC_ETAT_GLOBAL";

	/** Statistique INFOTRAFIC_ETATGLOBAL */
	private static final String STAT_INFOTRAFIC_ETAT_GLOBAL = "INFOTRAFIC_ETATGLOBAL";

	/** Mode par d�faut : AUTO */
	private static final boolean INFOTRAFIC_DEFAULT_MODE = true;

	/** ID table Statistique */
	private static final String ID_STAT = "id";

	/** Categorie table Statistique */
	private static final String CAT_STAT = "categorie";

	/** Jour table Statistique */
	private static final String JOUR_STAT = "jour";

	/** Format de la date pour stocker le fichier de r�sultat en mode manuel */
	private static final SimpleDateFormat FORMAT_DATE = new SimpleDateFormat("yyyyMMdd_HHmmss");

	/** requ�te infotrafic manuel manuel */
	private static final String INFOTRAFIC_REQUETE_MODE_MANUEL = "MODEMANUEL";

	/** Rubrique infotrafic */
	private static final String RUBRIQUE_INFOTRAFIC = "INFOTRAFIC_MANUEL";

	/** requ�te d'insertion dans la table statistique */
	private static final String SQL_REQUETE_INSERT_ETATGLOB_STAT = String.format("INSERT INTO STATISTIQUE (ID, CLE, JOUR, CATEGORIE) VALUES (?,'INFOTRAFIC_ETATGLOBAL', ?, ?)", STAT_INFOTRAFIC_ETAT_GLOBAL);

	/** requ�te de r�cup�ration des �tat global class�e par date */
	private static final String SQL_REQUETE_REQUETE_ETATGLOB_STAT = String.format("SELECT ID, JOUR, CATEGORIE FROM STATISTIQUE WHERE CLE='%s' ORDER BY JOUR DESC", STAT_INFOTRAFIC_ETAT_GLOBAL);

	/** EJB */
	private InfoTraficHome infoTraficHome;
	private ParametreDynamiqueManager parametreDynamiqueManager;
	private IServiceManager serviceManager;
	private AccueilManager accueilManager;
	private IGeneratorManager generatorManager;

	/** The data source. */
	private DataSource dataSource;

	/**
	 * Cr�e les ejb sous-jacents
	 */
	public void ejbCreate() {
		try {
			infoTraficHome = (InfoTraficHome) ServiceLocator.getInstance().getLocalHome(InfoTraficHome.class.getName());
			serviceManager = ServiceManager.getInstance();
			parametreDynamiqueManager = serviceManager.getParametreDynamiqueManager();
			accueilManager = serviceManager.getAccueilManager();
			generatorManager = serviceManager.getGeneratorManager();
			dataSource = ServiceLocator.getInstance().getDataSource(Constantes.DATASOURCE_NAME);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#getRequete(String)
	 */
	public InfoTraficDTO findRequeteById(final String id) {
		try {
			return new InfoTraficDTO(infoTraficHome.findByPrimaryKey(new EntityBeanPK(id)));
		} catch (FinderException e) {
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#findRequetesActives()
	 */
	@SuppressWarnings("unchecked")
	public Collection<InfoTraficDTO> findRequetesActives() {
		final Collection<InfoTrafic> requetesActives;
		final Collection<InfoTraficDTO> res = new ArrayList<InfoTraficDTO>();
		try {
			requetesActives = infoTraficHome.findRequetesActives();
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		for (InfoTrafic infoTrafic : requetesActives) {
			res.add(new InfoTraficDTO(infoTrafic));
		}
		return res;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#findRequetesActivesFilterByEtat()
	 */
	@SuppressWarnings("unchecked")
	public Collection<InfoTraficDTO> findRequetesActivesFilterByEtat(final EtatEnum etat) {
		final Collection<InfoTrafic> requetesActives;
		final Collection<InfoTraficDTO> res = new ArrayList<InfoTraficDTO>();
		try {
			requetesActives = infoTraficHome.findRequetesActivesByEtat(etat.name());
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		for (InfoTrafic infoTrafic : requetesActives) {
			res.add(new InfoTraficDTO(infoTrafic));
		}
		return res;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#getEtatGlobal
	 */
	public EtatEnum getEtatGlobal() {
		final String methode = "getEtatGlobal";
		final List<ParametreDynamiqueDTO> etatGlobalParamDyn = parametreDynamiqueManager.findParametreDynamiqueParCle(PARAM_DYN_INFOTRAFIC_ETAT_GLOBAL);
		if (etatGlobalParamDyn.isEmpty()) {
			return EtatEnum.INC;
		}
		if (etatGlobalParamDyn.size() > 1) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, String.format("Plusieurs cl�s %s trouv�s, prise en compte du premier trouv�", PARAM_DYN_INFOTRAFIC_MODE));
		}
		final int premierIndice = 0;
		final String valeurStr = etatGlobalParamDyn.get(premierIndice).getValeur();
		try {
			return EtatEnum.valueOf(valeurStr);
		} catch (RuntimeException re) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, String.format("%s est un �tat global invalide --> Etat inconnu", valeurStr));
			return EtatEnum.INC;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#getEtatModeManuel
	 */
	public InfoTraficDTO getRequeteModeManuel() {
		final String methode = "getEtatModeManuel";
		try {
			return new InfoTraficDTO(infoTraficHome.findByPrimaryKey(new EntityBeanPK(INFOTRAFIC_REQUETE_MODE_MANUEL)));
		} catch (FinderException e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Requ�te mode manuel introuvable");
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#updateEtatRequetes
	 */
	public EtatEnum updateEtatRequetes(final Collection<InfoTraficDTO> infosTraficListe) {
		// Ensemble des �tats recens�s
		final Set<EtatEnum> etatMax = new HashSet<EtatEnum>();
		for (InfoTraficDTO infoTrafic : infosTraficListe) {
			updateEtatRequete(infoTrafic);
			etatMax.add(infoTrafic.getEtat());
		}
		final EtatEnum etatGlobal = calculerEtatGlobal(etatMax);
		if (isModeAuto()) {
			updateEtatGlobal(etatGlobal);
		}
		return etatGlobal;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#isModeAuto
	 */
	public boolean isModeAuto() {
		final List<ParametreDynamiqueDTO> paramDyn = parametreDynamiqueManager.findParametreDynamiqueParCle(PARAM_DYN_INFOTRAFIC_MODE);
		if (paramDyn.isEmpty()) {
			return INFOTRAFIC_DEFAULT_MODE;
		}
		if (paramDyn.size() > 1) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "isModeAuto", String.format("Plusieurs cl�s %s trouv�s, prise en compte du premier trouv�", PARAM_DYN_INFOTRAFIC_MODE));
		}
		final int premierIndice = 0;
		return !ModeEnum.MANUEL.name().equals(paramDyn.get(premierIndice).getValeur());
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#activerModeAutomatique
	 */
	public void activerModeAutomatique() {
		modifierModeInfotrafic(ModeEnum.AUTO);
		supprimerInfoTraficModeManuel();
		updateEtatRequetes(findRequetesActives());
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#activerModeManuel
	 */
	public void activerModeManuel(String descriptionRubrique, String libelle, EtatEnum etatIndicateur, InputStream commandeImpIs) {
		modifierModeInfotrafic(ModeEnum.MANUEL);

		// Mise � jour du contenu de la rubrique
		final Collection<RubriqueAccueilDTO> rubriqueInfoTraficList = accueilManager.findRubriquesByTitre(RUBRIQUE_INFOTRAFIC);
		// Dans le cas o� aucun �l�ment n'a �t� trouv�
		if (rubriqueInfoTraficList.isEmpty()) {
			final RubriqueAccueilDTO rubriqueAccueil = new RubriqueAccueilDTO(generatorManager.generateKey());
			rubriqueAccueil.setTitre(RUBRIQUE_INFOTRAFIC);
			rubriqueAccueil.setTexte(descriptionRubrique);
			accueilManager.createRubrique(rubriqueAccueil);
		}
		// Normallement une seule it�ration
		for (RubriqueAccueilDTO rubriqueAccueil : rubriqueInfoTraficList) {
			accueilManager.modifyRubrique(rubriqueAccueil.getId(), descriptionRubrique);
		}

		// Mise � jour du libell�, de l'�tat et du fichier r�sultat de l'indicateur manuel
		final String fichierResultat;
		if (commandeImpIs != null) {
			fichierResultat = creerFichierCommandesImpactees(commandeImpIs).toString();
		} else {
			fichierResultat = null;
		}
		InfoTraficDTO requeteModeManuel = getRequeteModeManuel();
		if (requeteModeManuel == null) {
			requeteModeManuel = createInfoTraficModeManuel(libelle, etatIndicateur, fichierResultat);
		} else {
			requeteModeManuel.setLibelle(libelle);
			requeteModeManuel.setEtat(etatIndicateur);
			requeteModeManuel.setFichierResultat(fichierResultat);
			updateInfoTraficModeManuel(requeteModeManuel);
		}
		updateEtatGlobal(etatIndicateur);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.infotrafic.InfoTraficManager#extraireStatistiqueEtatGlobal
	 */
	public List<StatistiqueDTO> extraireHistoriqueListEtatsGlobaux() {
		final List<StatistiqueDTO> statistiquesListEtatGlobal = new ArrayList<StatistiqueDTO>();
		Connection connexion = null;
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		try {
			connexion = dataSource.getConnection();
			// Ex�cution de la requ�te et cr�ation de la liste de statistiques (les donn�es statistiques ne sont pas toutes remont�es)
			statement = connexion.prepareStatement(SQL_REQUETE_REQUETE_ETATGLOB_STAT);
			resultSet = statement.executeQuery();
			StatistiqueDTO statistique;
			while (resultSet.next()) {
				statistique = new StatistiqueDTO(resultSet.getString(ID_STAT));
				statistique.setCategorie(resultSet.getString(CAT_STAT));
				statistique.setJour(DateUtils.getDatabaseDate((Long) resultSet.getLong(JOUR_STAT)));
				statistiquesListEtatGlobal.add(statistique);
			}
		} catch (SQLException e) {
			throw new EJBException(e);
		} finally {
			try {
				if (resultSet != null) {
					resultSet.close();
				}
				if (statement != null) {
					statement.close();
				}
				if (connexion != null) {
					connexion.close();
				}
			} catch (SQLException e) {
				throw new EJBException(e);
			}
		}
		return statistiquesListEtatGlobal;
	}

	/**
	 * Cr�e le fichier de commandes impact�es
	 * 
	 * @param commandeImpIs le flux entrant
	 * @return le fichier cr�� contenu le flux entrant
	 */
	private File creerFichierCommandesImpactees(InputStream commandeImpIs) {
		// Cr�e le fichier
		final File fichierCommandesImp = controlerEtCreerFichier();

		// Copie du contenu dans le fichier sortant
		final BufferedOutputStream fichierCommandesImpSortie;
		try {
			fichierCommandesImpSortie = new BufferedOutputStream(new FileOutputStream(fichierCommandesImp));
		} catch (FileNotFoundException e) {
			throw new EJBException(String.format("Le fichier %s n'a pas pu �tre cr��", fichierCommandesImp.toString()));
		}
		try {
			IOUtils.copy(commandeImpIs, fichierCommandesImpSortie);
		} catch (IOException e) {
			throw new EJBException(String.format("Probl�me lors de la tentative de copie du contenu vers le fichier %s", fichierCommandesImp.toString()), e);
		}
		try {
			commandeImpIs.close();
			fichierCommandesImpSortie.flush();
			fichierCommandesImpSortie.close();
		} catch (IOException e) {
			throw new EJBException("Probl�me lors de la tentative de fermeture des flux", e);
		}
		return fichierCommandesImp;
	}

	/**
	 * Effectue les contr�les pr�alables et cr�e le fichier si OK
	 * 
	 * @return le fichier
	 */
	private File controlerEtCreerFichier() {
		final String methode = "creerFichierCommandesImpactees";
		final String directoryStr = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ParametreArtemisDTO.class, ParametreArtemisConstantes.INFOTRAFIC_REPERTOIRE).getValeurParametre();
		if (StringUtils.isBlank(directoryStr)) {
			throw new EJBException(String.format("%s n'est pas un r�pertoire valide", directoryStr));
		}
		final File directory = new File(directoryStr);

		// Contr�le pr�lable
		if (directory.exists() && !directory.isDirectory()) {
			throw new EJBException(String.format("%s n'est pas un r�pertoire", directoryStr));
		}
		// Cr�ation du r�pertoire s'il n'existe pas
		if (!directory.exists()) {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, String.format("Tentative de cr�ation du r�pertoire %s", directoryStr));
			if (!directory.mkdirs()) {
				throw new EJBException(String.format("Impossible de cr�er le r�pertoire %s", directoryStr));
			}
		}
		// Dernier contr�le : regarde si le r�pertoire est accessible en �criture
		if (directory.exists() && !directory.canWrite()) {
			throw new EJBException(String.format("%s ne poss�de pas les droits en �criture", directoryStr));
		}
		// Cr�ation du fichier
		final File fichierCommandesImp = new File(directory, String.format("INFOTRAFIC_MODE_MANUEL_%s.csv", FORMAT_DATE.format(GregorianCalendar.getInstance().getTime())));

		// Erreur si 2 ou + tentatives de cr�ation du fichier intervenant sur la m�me seconde
		if (fichierCommandesImp.exists()) {
			throw new EJBException(String.format("%s est d�j� existant", fichierCommandesImp.toString()));
		}
		return fichierCommandesImp;
	}

	/**
	 * Met � jour l'�tatGlobal et ins�re une nouvelle entr�e dans la table statistique
	 * 
	 * @param newEtatGlobal le nouvel �tat global
	 */
	private void updateEtatGlobal(final EtatEnum newEtatGlobal) {
		final EtatEnum oldEtatGlobal = getEtatGlobal();
		// Rien � faire si l'�tat de change pas
		if (oldEtatGlobal.equals(newEtatGlobal)) {
			return;
		}
		// Mise � jour du param�tre dynamique
		final ParametreDynamiqueDTO etatGlobalParam = new ParametreDynamiqueDTO(PARAM_DYN_INFOTRAFIC_ETAT_GLOBAL);
		etatGlobalParam.setCle(PARAM_DYN_INFOTRAFIC_ETAT_GLOBAL);
		etatGlobalParam.setValeur(newEtatGlobal.name());
		parametreDynamiqueManager.updateOrCreateParametreDynamique(etatGlobalParam);

		// ajout de l'�tat global dans la table statistique
		final String idEntree = generatorManager.generateKey();
		final Connection connexion;
		try {
			connexion = dataSource.getConnection();
		} catch (SQLException e) {
			throw new EJBException(e);
		}
		try {
			final PreparedStatement statement = connexion.prepareStatement(SQL_REQUETE_INSERT_ETATGLOB_STAT);
			int i = 1;
			statement.setString(i++, idEntree);
			statement.setLong(i++, DateUtils.getDatabaseDate());
			statement.setString(i++, newEtatGlobal.name());

			statement.execute();
			statement.close();
		} catch (SQLException e) {
			throw new EJBException(e);
		} finally {
			try {
				connexion.close();
			} catch (SQLException e) {
				throw new EJBException(e);
			}
		}
	}

	/**
	 * D�termine l'�tat global (Pire �tat de l'ensemble des �tats)
	 * 
	 * @param etats l'ensemble des �tats recens�s
	 * @return l'�tat global
	 */
	private EtatEnum calculerEtatGlobal(final Set<EtatEnum> etats) {
		for (EtatEnum etat : EtatEnum.getEtatslisteordonnes()) {
			if (etats.contains(etat)) {
				return etat;
			}
		}
		// Aucune requ�te active avec �tat trouv�e --> Inconnu
		return EtatEnum.INC;
	}

	/**
	 * D�termine et persiste (s'il y a eu modification) l'�tat d'une entr�e infoTrafic
	 * 
	 * @param infoTrafic l'entr�e infotrafic
	 */
	private void updateEtatRequete(final InfoTraficDTO infoTrafic) {
		final EtatEnum ancienEtat = infoTrafic.getEtat();
		final EtatEnum nouvelEtat = determinerEtat(infoTrafic);

		// Arr�t si aucun changement
		if (nouvelEtat.equals(ancienEtat)) {
			return;
		}

		infoTrafic.setEtat(nouvelEtat);
		updateInfoTraficEtat(infoTrafic);
	}

	/**
	 * D�termine l'�tat d'une entr�e infoTrafic
	 * 
	 * Cas d�une requ�te avec seuil de type � Plus Grand Que �
	 * Si la � valeur � est inf�rieure ou �gale au � SEUILMOYEN �, l�indicateur est � OK �
	 * Si la � valeur � est sup�rieure au � SEUILMOYEN � mais inf�rieure ou �gale au � SEUILFORT �, l�indicateur est � ATT �
	 * Si la � valeur � est sup�rieure au � SEUILFORT �, l�indicateur est � KO �
	 * 
	 * Cas d�une requ�te avec seuil de type � Plus Petit Que �
	 * Si la � valeur � est sup�rieure ou �gale au � SEUIL_MOYEN �, l�indicateur est � OK �
	 * Si la � valeur � est inf�rieure au � SEUIL_MOYEN � mais sup�rieure ou �gale au � SEUILFORT �, l�indicateur est � ATT �
	 * Si la � valeur � est inf�rieure au � SEUILFORT �, l�indicateur est � KO �
	 * 
	 * Si l'objet infotraffic est en erreur, l'�tat est � � INC �
	 * 
	 * @param infoTrafic l'entr�e infotrafic
	 * @return l'�tat
	 */
	private EtatEnum determinerEtat(final InfoTraficDTO infoTrafic) {
		final String methode = "determinerEtat";

		// Inconnu si l'objet n'est pas valide
		if (!isInfotraficValide(infoTrafic)) {
			return EtatEnum.INC;
		}

		// Les champs suivants sont forc�ment renseign�s car valid�s
		final long resultat = infoTrafic.getDernierResultat();
		final long seuilFort = infoTrafic.getSeuilFort();
		final long seuilMoyen = infoTrafic.getSeuilMoyen();
		final TypeSeuilEnum typeSeuil = infoTrafic.getTypeSeuil();

		// Si le typeSeuil est incoh�rent, tra�age de l'incoh�rence dans les logs, le seuilMoyen est ignor� : l'�tat sera seulement bas� sur le seuilFort
		if (seuilFort != seuilMoyen && (seuilFort < seuilMoyen) != (TypeSeuilEnum.PPQ.equals(typeSeuil))) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, String.format("Le typeSeuil de l'entr�e \"%s\" est incoh�rent", infoTrafic.getId()));
			// Cas � la marge : lorque le typeSeuil est incoh�rent, l'�tat est KO lorsque le r�sultat = seuilMoyen
			if (resultat == seuilFort) {
				return EtatEnum.ATT;
			}
			if ((resultat > seuilFort) != (TypeSeuilEnum.PPQ.equals(typeSeuil))) {
				return EtatEnum.KO;
			}
		}

		// Si le r�sultat est �gal au seuil moyen, etat = OK quoi qu'il en soit
		if (seuilMoyen == resultat) {
			return EtatEnum.OK;
		}

		// Si le r�sultat est �gal au seuil fort, etat = ATT quoi qu'il en soit
		if (seuilFort == resultat) {
			return EtatEnum.ATT;
		}

		// Sinon nous v�rifions si l'�tat est � ATT
		if (resultat > seuilMoyen != resultat > seuilFort) {
			return EtatEnum.ATT;
		}

		// �tat OK ou KO suivant le typeSeuil
		if ((resultat > seuilFort) != (TypeSeuilEnum.PPQ.equals(typeSeuil))) {
			return EtatEnum.KO;
		}
		return EtatEnum.OK;
	}

	/**
	 * V�rifie si l'objet infotrafic est valide
	 * 
	 * @param infoTrafic l'objet infotrafic
	 * @return true si valide, false sinon
	 */
	private boolean isInfotraficValide(final InfoTraficDTO infoTrafic) {
		// INC si l'objet infoTrafic est en erreur ou sans r�sultat ==> etat inconnu
		if (infoTrafic.isErreur() || infoTrafic.getDernierResultat() == null) {
			return false;
		}
		return true;
	}

	/**
	 * persiste (seulement) l'�tat de l'entr�e infoTrafic
	 * 
	 * @param infoTrafic l'entr�e infotrafic
	 */
	private void updateInfoTraficEtat(final InfoTraficDTO infoTrafic) {
		final InfoTrafic infoTraficEntity;
		try {
			infoTraficEntity = infoTraficHome.findByPrimaryKey(new EntityBeanPK(infoTrafic.getId()));
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		infoTraficEntity.setEtat(infoTrafic.getEtat().name());
	}

	/**
	 * Change le mode infotrafic (Manuel ou auto)
	 * 
	 * @param mode le nouveau mode
	 */
	private void modifierModeInfotrafic(final ModeEnum mode) {
		final String methode = "modifierModeInfotrafic";
		serviceManager.getLoggerManager().finest(CLASSNAME, methode, String.format("InfoTrafic : passage en mode %s", mode.name()));
		final List<ParametreDynamiqueDTO> paramDynModeInfoTrafic = parametreDynamiqueManager.findParametreDynamiqueParCle(PARAM_DYN_INFOTRAFIC_MODE);
		if (paramDynModeInfoTrafic.isEmpty()) {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, String.format("Cr�ation du param�tre dynamique %s car non trouv�", PARAM_DYN_INFOTRAFIC_MODE));
			final ParametreDynamiqueDTO parametreDynamique = new ParametreDynamiqueDTO(serviceManager.getGeneratorManager().generateKey());
			parametreDynamique.setCle(PARAM_DYN_INFOTRAFIC_MODE);
			parametreDynamique.setValeur(mode.name());
			parametreDynamiqueManager.createParametreDynamique(parametreDynamique);
		}
		if (paramDynModeInfoTrafic.size() > 1) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "isModeAuto", String.format("Plusieurs cl�s %s trouv�s, Mise � jour de toutes les entr�es", PARAM_DYN_INFOTRAFIC_MODE));
		}

		for (ParametreDynamiqueDTO parametreDynamique : paramDynModeInfoTrafic) {
			parametreDynamique.setValeur(mode.name());
			parametreDynamiqueManager.updateParametreDynamique(parametreDynamique);
		}
	}

	/**
	 * Cr�e la requ�te mode manuel. Attention ! La m�thode tente de cr�er la requ�te m�me si elle existe d�j�
	 * 
	 * @param libelle le nouveau libelle
	 * @param etat le nouvel etat
	 * @param fichierResultat le fichier Resultat
	 * 
	 * @return la requ�te mode manuel
	 */
	private InfoTraficDTO createInfoTraficModeManuel(final String libelle, final EtatEnum etat, final String fichierResultat) {
		final String requeteDesactivee = "N";
		final HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(InfoTrafic.FIELD_ACTIVE, requeteDesactivee);
		values.put(InfoTrafic.FIELD_ETAT, etat.name());
		values.put(InfoTrafic.FIELD_FICHIER_RESULTAT, fichierResultat);
		values.put(InfoTrafic.FIELD_LIBELLE, libelle);
		try {
			return new InfoTraficDTO(infoTraficHome.create(INFOTRAFIC_REQUETE_MODE_MANUEL, values));
		} catch (CreateException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Modifie le contenu de la requ�te mode manuel. Attention ! la requ�te doit �tre d�j� pr�sente en base
	 * 
	 * @param infoTrafic la requ�te ModeManuel � mettre � jour
	 * @return la requ�te mode manuel
	 */
	private void updateInfoTraficModeManuel(final InfoTraficDTO infoTrafic) {
		InfoTrafic infoTraficModeManuel;
		try {
			infoTraficModeManuel = infoTraficHome.findByPrimaryKey(new EntityBeanPK(INFOTRAFIC_REQUETE_MODE_MANUEL));
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		infoTraficModeManuel.setEtat(infoTrafic.getEtat().name());
		infoTraficModeManuel.setFichierResultat(infoTrafic.getFichierResultat());
		infoTraficModeManuel.setLibelle(infoTrafic.getLibelle());
	}

	/**
	 * Supprime l'entr�e mode manuel, ne remonte pas d'exception si aucune requ�te infotrafic trouv�e (ne fait rien)
	 */
	private void supprimerInfoTraficModeManuel() {
		final String methode = "supprimerInfoTraficModeManuel";
		InfoTrafic infoTraficModeManuel;
		try {
			infoTraficModeManuel = infoTraficHome.findByPrimaryKey(new EntityBeanPK(INFOTRAFIC_REQUETE_MODE_MANUEL));
		} catch (FinderException e) {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, "La requ�te ModeManuel n'a pas �t� trouv�e");
			return;
		}
		try {
			infoTraficModeManuel.remove();
		} catch (RemoveException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Le session context n'est pas r�cup�r�
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sc) throws EJBException, RemoteException {
	}

	/**
	 * M�thode non appel�e
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * M�thode non appel�e
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

	/**
	 * Rien � Nettoyer
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

}
