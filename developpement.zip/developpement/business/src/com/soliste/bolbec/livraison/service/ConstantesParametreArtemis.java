/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service;

/**
 * Interface contenant les constantes correspondant aux cl�s possibles dans
 * la table ParametreArtemis
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR bgcolor=green><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/04/2013</TD><TD>VDE</TD><TD>Ajout parametre ALTE_MAX_COMMANDES</TD></TR>
 * <TR><TD>03/12/2015</TD><TD>JDE</TD><TD>EV-000348 : Net commande unique</TD></TR>
 * <TR><TD>29/04/2016</TD><TD>JDE</TD><TD>Ajout parametre NB_MAX_TACHES_LIEES</TD></TR>
 * <TR><TD>15/07/2016</TD><TD>ARE</TD><TD>EV-000362 : PLP Fibre sans RDV</TD></TR>
 * <TR><TD>18/06/2018</TD><TD>RRU</TD><TD>QC-980 : Intrants FTTH</TD></TR>
 * </TABLE><BR>
 */

public interface ConstantesParametreArtemis {

	String BASICAT = "BASICAT";
	String CODE_INSTANCE = "CODE_INSTANCE";
	String VERSION_APPLICATIVE_COURANTE = "VERSION_APPLICATIVE_COURANTE";
	String DELAI_MES_BL = "DELAI_MES_BL";
	String DXF = "DXF";
	String NOMAPPLI = "NOMAPPLI";
	String MAIL_ADMIN = "MAIL_ADMIN";
	String ALTE_MAX_COMMANDES = "ALTE_MAX_COMMANDES";
	String NB_MAX_TACHES_LIEES = "NB_MAX_TACHES_LIEES";
	String DELAI_MAX_AVANT_FIN_DEMGT = "DELAI_MAX_AVANT_FIN_DEMGT";
	String DELAI_AVANT_RESIL_PLPA = "DELAI_AVANT_RESIL_PLPA";
	String DELAI_MAX_AVANT_FIN_RESIL_PLPA = "DELAI_MAX_AVANT_FIN_RESIL_PLPA";
	String DELAI_MAX_TEMPO = "DELAI_MAX_TEMPO";
	String CONTROL_COHERENCE_COMMANDE_MAX_RETRY_NUMBER = "ControlCoherenceCommande_MaxRetryNumber";
	String REQUALIF_PLP_AUTO = "REQUALIF_PLP_AUTO";
	String ACTIV_KYAKU = "ACTIV_KYAKU";
	String ACTPRO_EXCLU = "ACTPRO_EXCLU";
	String MODIF_RDV_OPER = "MODIF_RDV_OPER";

}
