/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

/**
 * DTO pour les champs ramen�s par une requ�te
 * 
 * @author gdzd8490
 * 
 */
public abstract class FieldDTO {

}
