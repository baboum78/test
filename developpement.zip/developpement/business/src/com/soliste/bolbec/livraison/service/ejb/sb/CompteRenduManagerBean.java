/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb;

import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import aps.CompteRendu;
import aps.CompteRenduHome;

import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.livraison.service.model.CompteRenduDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Impl�mentation de l'EJB session <code>CompteRenduManager</code>.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/09/2010</TD><TD>ALE</TD><TD>Correction IRMA_910 - Suppression de l'affichage de la stacktrace</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 * 
 * @see {@link com.soliste.bolbec.livraison.service.ejb.sb.CompteRenduManager}
 */
public class CompteRenduManagerBean extends FwkSessionBean implements CompteRenduManager, ICompteRenduManagerRemote {

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = CompteRenduManagerBean.class.getName();

	/** The compte rendu home. */
	private CompteRenduHome compteRenduHome;

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			compteRenduHome = getEntityHome(CompteRenduHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	// --------------------------------------------------------------
	// COMPTE_RENDU
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CompteRenduManager#getCompteRendu(java.lang.String)
	 */
	public CompteRenduDTO getCompteRendu(String compteRenduId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getCompteRendu", "Recherche du compte rendu " + compteRenduId);
		try {
			CompteRendu compteRendu = getCompteRenduEntity(compteRenduId);
			return new CompteRenduDTO(compteRendu);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getCompteRendu", "Pas de compte rendu avec id = " + compteRenduId);
			return null;
		}
	}

	/**
	 * Gets the compte rendu entity.
	 * 
	 * @param id the id
	 * 
	 * @return the compte rendu entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private CompteRendu getCompteRenduEntity(String id) throws FinderException {
		return compteRenduHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CompteRenduManager#deleteCompteRendu(java.lang.String)
	 */
	public void deleteCompteRendu(String compteRenduId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteCompteRendu", "Suppression du compte rendu " + compteRenduId);
		try {
			CompteRendu compteRendu = getCompteRenduEntity(compteRenduId);
			compteRendu.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getCompteRendu", "Pas de compte rendu avec id = " + compteRenduId, fe);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getCompteRendu", "Probleme de suppression du compte rendu = = " + compteRenduId, re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CompteRenduManager#createCompteRendu(com.soliste.bolbec.livraison.service.model.CompteRenduDTO)
	 */
	public CompteRenduDTO createCompteRendu(CompteRenduDTO compteRendu) {
		String compteRenduId = compteRendu.getId();
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createCompteRendu", "Cr�ation d'un compteRendu: id " + compteRenduId);
		try {
			CompteRendu cr = getCompteRenduEntity(compteRenduId);
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createCompteRendu", "Mise � jour du compte rendu: id " + compteRenduId);
			cr.setDateReception(compteRendu.getDateReception());
			cr.setMessage(compteRendu.getMessage());
			long timestamp = cr.getTimestamp() + 1;
			cr.setTimestamp(timestamp);
		} catch (FinderException e) {
			try {
				HashMap<String, Object> values = new HashMap<String, Object>();
				values.put(CompteRendu.FIELD_DATE_RECEPTION, compteRendu.getDateReception());
				values.put(CompteRendu.FIELD_MESSAGE, compteRendu.getMessage());
				compteRenduHome.create(compteRenduId, values);
			} catch (CreateException ce) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getCompteRendu", "Probleme de creation du compte rendu = = " + compteRenduId, ce);
				throw new EJBException(ce);
			}
		}
		return compteRendu;
	}
}
