/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.io.Serializable;
import java.util.Map;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;

/**
 * Interface pour les donn�es d'un item corbeille
 * 
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>25/02/2010</TD><TD>ALE</TD><TD>EV-000029: Ajout d'un getter sur l'idCommande</TD></TR>
 * 
 * @author gdzd8490
 * 
 */
public interface ItemData extends Serializable {

	/**
	 * R�cup�re l'ensemble cle/valeur des attributs de l'objet
	 * 
	 * @return liste cle/valeur
	 */
	Map<String, String> getValues();

	/**
	 * R�cup�re la valeur d'un attribut de l'objet selon sa cle return la valeur
	 * de l'attribut
	 * 
	 * @param keyName
	 * cle
	 * @return valeur
	 * @throws DataException
	 */
	String getValue(String keyName) throws DataException;

	/**
	 * Retourne l'identifiant de l'objet au sein de son syst�me
	 * 
	 * @return l'identifiant de l'objet au sein de son syst�me
	 */
	String getId();

	/**
	 * Renvoie true si l'item est r�serv� par un autre utilisateur que
	 * l'utilisateur courant
	 * 
	 * @return true si l'item est r�serv� par le user courant, false sinon
	 */
	boolean isReservedByAnotherUser();

	/**
	 * Renvoie l'id de la commande associ�e � l'item
	 * 
	 * @return String
	 */
	String getCommandeID();

}
