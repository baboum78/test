/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;

/**
 * Le DTO pour l'entit� CR Osiris
 * 
 * @author La�titia FABRE
 */
public class CROsirisDTO implements Serializable {

	private String id;

	private boolean validable;

	private String idEntite;
	private String formatExterne;
	private String instanceLocalisation;
	private String idFichier;
	private String dateTransfert;
	private String codeTransfert;
	private String version;

	private String libelleEtatPublication;

	/**
	 * 
	 * @param id
	 */
	public CROsirisDTO(String id) {
		super();
		this.id = id;
	}

	/**
	 * Retourne le <code>codeTransfert</code>
	 * 
	 * @return le <code>codeTransfert</code>
	 */
	public String getCodeTransfert() {
		return codeTransfert;
	}

	/**
	 * Affecte le <code>codeTransfert</code>
	 * 
	 * @param codeTransfert le <code>codeTransfert</code> � affecter
	 */
	public void setCodeTransfert(String codeTransfert) {
		this.codeTransfert = codeTransfert;
	}

	/**
	 * Retourne le <code>dateTransfert</code>
	 * 
	 * @return le <code>dateTransfert</code>
	 */
	public String getDateTransfert() {
		return dateTransfert;
	}

	/**
	 * Affecte le <code>dateTransfert</code>
	 * 
	 * @param dateTransfert le <code>dateTransfert</code> � affecter
	 */
	public void setDateTransfert(String dateTransfert) {
		this.dateTransfert = dateTransfert;
	}

	/**
	 * Retourne le <code>formatExterne</code>
	 * 
	 * @return le <code>formatExterne</code>
	 */
	public String getFormatExterne() {
		return formatExterne;
	}

	/**
	 * Affecte le <code>formatExterne</code>
	 * 
	 * @param formatExterne le <code>formatExterne</code> � affecter
	 */
	public void setFormatExterne(String formatExterne) {
		this.formatExterne = formatExterne;
	}

	/**
	 * Retourne le <code>id</code>
	 * 
	 * @return le <code>id</code>
	 */
	public String getId() {
		return id;
	}

	/**
	 * Affecte le <code>id</code>
	 * 
	 * @param id le <code>id</code> � affecter
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Retourne le <code>idEntite</code>
	 * 
	 * @return le <code>idEntite</code>
	 */
	public String getIdEntite() {
		return idEntite;
	}

	/**
	 * Affecte le <code>idEntite</code>
	 * 
	 * @param idEntite le <code>idEntite</code> � affecter
	 */
	public void setIdEntite(String idEntite) {
		this.idEntite = idEntite;
	}

	/**
	 * Retourne le <code>idFichier</code>
	 * 
	 * @return le <code>idFichier</code>
	 */
	public String getIdFichier() {
		return idFichier;
	}

	/**
	 * Affecte le <code>idFichier</code>
	 * 
	 * @param idFichier le <code>idFichier</code> � affecter
	 */
	public void setIdFichier(String idFichier) {
		this.idFichier = idFichier;
	}

	/**
	 * Retourne le <code>instanceLocalisation</code>
	 * 
	 * @return le <code>instanceLocalisation</code>
	 */
	public String getInstanceLocalisation() {
		return instanceLocalisation;
	}

	/**
	 * Affecte le <code>instanceLocalisation</code>
	 * 
	 * @param instanceLocalisation le <code>instanceLocalisation</code> � affecter
	 */
	public void setInstanceLocalisation(String instanceLocalisation) {
		this.instanceLocalisation = instanceLocalisation;
	}

	/**
	 * Retourne le <code>version</code>
	 * 
	 * @return le <code>version</code>
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * Affecte le <code>version</code>
	 * 
	 * @param version le <code>version</code> � affecter
	 */
	public void setVersion(String version) {
		this.version = version;
	}

	/**
	 * @return validable
	 */
	public boolean isValidable() {
		return validable;
	}

	/**
	 * @param validable
	 */
	public void setValidable(boolean validable) {
		this.validable = validable;
	}

	/**
	 * @return libelleEtatPublication
	 */
	public String getLibelleEtatPublication() {
		return libelleEtatPublication;
	}

	/**
	 * @param libelleEtatPublication
	 */
	public void setLibelleEtatPublication(String libelleEtatPublication) {
		this.libelleEtatPublication = libelleEtatPublication;
	}
}
