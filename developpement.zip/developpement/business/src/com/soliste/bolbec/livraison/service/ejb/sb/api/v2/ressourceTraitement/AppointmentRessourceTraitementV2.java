package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.AppointmentRessourceTraitement;

public class AppointmentRessourceTraitementV2 extends AppointmentRessourceTraitement {

}
