/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader;

import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCCondition;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCDataRetrieverException;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCFilter;
import com.soliste.bolbec.livraison.service.util.jdbc.TacheEnCoursDataRetriever;
import com.soliste.bolbec.livraison.service.util.jdbc.TacheEnCoursJDBCFields;

/**
 * Impl�mentation du chargement des processus d'une corbeille � partir de la
 * base de donn�es
 * 
 * @author gdzd8490
 */
public class JDBCProcessusLoaderImpl extends JDBCLoaderImpl {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.JDBCLoaderImpl#loadSynthesis(java.util.List, java.util.List, java.util.List, java.util.List)
	 */
	protected List<Map<String, String>> loadSynthesis(List<JDBCField> selectFields, List<JDBCCondition> conditions, List<JDBCField> orderByFields, List<JDBCField> groupByFields) throws JDBCDataRetrieverException {
		return TacheEnCoursDataRetriever.retrieveSuspendedTacheEnCoursSynthesisData(selectFields, conditions, orderByFields, groupByFields);
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>21/11/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV-000188 & DE-000516 : Vente FTTH : Tri par EPCidVIA </TD></TR>
	 * </TABLE>
	 * 
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.JDBCLoaderImpl#loadElementsIds(java.util.List, java.util.List)
	 */
	protected List<String> loadElementsIds(List<JDBCCondition> dataFilters, List<JDBCField> orderByFields) throws JDBCDataRetrieverException {
		List<JDBCField> groupByFields = buildGroupByFields(orderByFields);
		if (groupByFields != null) {
			groupByFields.add(TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ID));
		}
		return TacheEnCoursDataRetriever.retrieveSuspendedTacheEnCoursIds(dataFilters, orderByFields, groupByFields);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.JDBCLoaderImpl#loadElements(java.util.List, java.util.List, java.util.List, java.util.List)
	 */
	protected List<Map<String, String>> loadElements(List<String> elementsToLoadIds, List<JDBCField> fields, List<JDBCField> orderByFields, List<JDBCField> groupByFields) throws JDBCDataRetrieverException {
		JDBCField idField = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ID);
		JDBCFilter filter = new JDBCFilter(idField, JDBCFilter.OPERATOR_IN, elementsToLoadIds.toArray(new String[elementsToLoadIds.size()]));
		return TacheEnCoursDataRetriever.retrieveTachesEnCours(filter, fields, orderByFields, groupByFields);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.JDBCLoaderImpl#getFacadeList(java.util.List)
	 */
	protected List<ItemData> getFacadeList(List<Map<String, String>> elements) {
		return JDBCLoaderUtil.getProcessusFacadeList(elements);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.JDBCLoaderImpl#getIdField()
	 */
	protected JDBCField getIdField() {
		return JDBCLoaderUtil.ID_PROCESSUS_FIELD;
	}
}
