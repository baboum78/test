/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.ejb.sb.commun.data.KeyPair;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs Comp Com
 * 
 * @author rgvs7490
 */
public class CloturerAvpCompComCommande extends CloturerAvpCommande {

	private Map<String, List<KeyPair>> qtsByLigneCommande;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param qtsByLigneCommande
	 */
	public CloturerAvpCompComCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, Map<String, List<KeyPair>> qtsByLigneCommande) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.qtsByLigneCommande = qtsByLigneCommande;
	}

	/**
	 * Retourne l'ensemble des QTs, rang�s par ligne de commande. La Map contient,
	 * en cl�s, les IDs de ligne de commande. En valeurs, pour chaque ligne de
	 * commande, on y trouve une liste d'instances de bolbec.ihm.common.data.KeyPair.
	 * La cl� de la KeyPair est l'identifiant r�el du QT, et la valeur de la KeyPair est
	 * la nouvelle valeur pour ce QT.
	 */
	public Map<String, List<KeyPair>> getQtsByLigneCommande() {
		return this.qtsByLigneCommande;
	}
}
