package com.soliste.bolbec.livraison.service.ejb.sb;

import javax.ejb.EJBObject;

/**
 * Interface Remote de l'EJB session PublicationManagerSB.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>30/04/2018</TD><TD>AJO</TD><TD>QC974 : VADOR</TD></TR>
 * </TABLE>
 */

public interface PublicationManagerRemote extends IPublicationManagerRemote, EJBObject {

}
