package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;
import java.util.ArrayList;

import com.soliste.bolbec.livraison.service.model.PublicationATraiterDTO;

public interface IPublicationManagerRemote {
	/**
	 * Mets � jour le l'�tat d'une liste de publications
	 * 
	 * @param publications
	 */
	void updatePublicationEtat(ArrayList<PublicationATraiterDTO> publications) throws RemoteException;

	/**
	 * Mets � jour la date de r�cup�ration d'une liste de publications
	 * 
	 * @param publications
	 */
	void updatePublicationDateRecuperation(ArrayList<PublicationATraiterDTO> publications) throws RemoteException;
}
