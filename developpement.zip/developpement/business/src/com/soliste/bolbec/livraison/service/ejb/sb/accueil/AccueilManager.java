/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.accueil;

import java.util.List;

import aps.RubriqueAccueil;

import com.soliste.bolbec.livraison.service.ejb.sb.accueil.data.HistoriqueStatistiqueDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.accueil.data.StatistiqueRegionaleDTO;
import com.soliste.bolbec.livraison.service.model.RubriqueAccueilDTO;
import com.soliste.bolbec.livraison.service.model.StatistiqueDTO;

/**
 * Interface du session bean AccueilManager, permettant de g�rer la page d'accueil
 * 
 * <BR> <B>HISTORIQUE DES MODIFICATIONS:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>27/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>02/12/2013</TD><TD>FTE</TD><TD>Ajout d'un finder de r�cup�ration des rubriques tri�es par rang</TD></TR>
 * <TR><TD>11/02/2014</TD><TD>BPE</TD><TD>EV-000276 : G8R2C4 - Mise en place de l'infoTrafic</TD></TR>
 * </TABLE>
 * <BR>
 */
public interface AccueilManager {

	/**
	 * Retourne une rubrique d'accueil
	 * 
	 * @param id l'identifiant de la rubrique
	 * @return la rubrique
	 */
	RubriqueAccueilDTO getRubrique(String id);

	/**
	 * Cr�e une nouvelle rubrique
	 * 
	 * @param rubrique la rubrique
	 * @return la rubrique entit�
	 */
	RubriqueAccueil createRubrique(final RubriqueAccueilDTO rubrique);

	/**
	 * Hormis les entr�es infotrafic, retourne l'ensemble des rubriques d'accueil
	 * 
	 * @return une liste tri�e d'instances de RubriqueAccueilDTO
	 */
	List<RubriqueAccueilDTO> getRubriques();

	/**
	 * Hormis les entr�es infotrafic, retourne l'ensemble des rubriques d'accueil tri�es par rang,
	 * 
	 * @return une liste tri�e par rang d'instances de RubriqueAccueilDTO
	 */
	List<RubriqueAccueilDTO> getRubriquesSortByRang();

	/**
	 * R�cup�re les rubriques correspondant au titre pass� en param�tre
	 * 
	 * @param titre le titre de la rubrique
	 * @return la collection de rubriques
	 */
	List<RubriqueAccueilDTO> findRubriquesByTitre(final String titre);

	/**
	 * Modifie le texte de la rubrique donn�e
	 * 
	 * @param id l'identifiant de la rubrique
	 * @param texte le nouveau texte (html) de la rubrique
	 */
	void modifyRubrique(String id, String texte);

	/**
	 * Modifie le texte et le titre de la rubrique donn�e
	 * 
	 * @param id l'identifiant de la rubrique
	 * @param texte le nouveau texte (html) de la rubrique
	 * @param titre le nouveau titre de la rubrique
	 */
	void modifyRubrique(String id, String titre, String texte);

	/**
	 * Retourne les statistiques � afficher dans la page d'accueil.
	 * 
	 * @return les statistiques � afficher dans la page d'accueil.
	 */
	List<StatistiqueDTO> getStatistiquesNationales();

	/**
	 * Retourne les statistiques � afficher dans la page des statistiques r�gionales.
	 * 
	 * @return les statistiques � afficher dans la page des statistiques r�gionales.
	 */
	List<StatistiqueRegionaleDTO> getStatistiquesRegionales();

	/**
	 * Retourne l'historique des statistiques pour la cl� donn�e et la DR donn�e. La
	 * liste retourn�e est tri�e par date (de la plus ancienne � la plus r�cente)
	 * 
	 * @param cle la cl� de statistique pour laquelle on veut conna�tre l'historique
	 * @return l'historique de cette statistique
	 */
	HistoriqueStatistiqueDTO getHistoriqueStatistique(String cle, String dr);
}
