/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import java.util.ArrayList;
import java.util.List;

import com.soliste.aps.workflow.WfSynthesisObject;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData;

/**
 * Facade pour l'object workflow WfSynthesisObject
 * 
 * @author gdzd8490
 * 
 */
public class WfSynthesisData implements SynthesisData {

	/** Donn�es de regroupement */
	private List<String> values;

	/** Nb d'�l�ments dans ce regroupement */
	private int sum;

	/**
	 * Constructeur
	 * 
	 * @param wfSynthesisObject
	 */
	public WfSynthesisData(WfSynthesisObject wfSynthesisObject) {
		this.values = cleanValues(wfSynthesisObject);
		this.sum = wfSynthesisObject.getSum().intValue();
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData#getValues()
	 */
	public List<String> getValues() {
		return this.values;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData#getSum()
	 */
	public int getSum() {
		return this.sum;
	}

	/**
	 * On nettoie la liste renvoy�e par WfSynthesisObject.getValues<br/> Elle
	 * contient dans chaque �l�ment de rang pair (0,2..) des libell�s et dans
	 * les champs de rang impair (1,3...)des valeurs. Or seules les valeurs ont
	 * besoin d'�tre r�cup�r�s.
	 * 
	 * @param wfSynthesisObject
	 * @return la liste des valeurs (rang pair) de WfSynthesisObject.getValues
	 */
	private List<String> cleanValues(WfSynthesisObject wfSynthesisObject) {
		List<String> cleanList = new ArrayList<String>();
		List<String> originalList = wfSynthesisObject.getValues();
		int nbElements = originalList.size();
		for (int rang = 0; rang < nbElements; rang++) {
			String item = originalList.get(rang);
			if (rang % 2 != 0) {
				// rang impair : valeur � stocker
				cleanList.add(item);
			}
		}
		return cleanList;
	}
}
