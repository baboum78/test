package com.soliste.bolbec.livraison.service.ejb.sb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.PubRegManDTO;
import com.soliste.bolbec.livraison.service.model.PublicationATraiterDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.CompteRenduHome;
import aps.LigneCommande;
import aps.PublicationATraiter;
import aps.PublicationATraiterHome;

/**
 * Impl�mentation de l'EJB session <code>CommandeManager</code>.
 * 
 * @see {@link com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager}
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>30/04/2018</TD><TD>AJO</TD><TD>QC974 : VADOR</TD></TR>
 * </TABLE>
 */

public class PublicationManagerBean extends FwkSessionBean implements PublicationManager, IPublicationManagerRemote {

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = PublicationManagerBean.class.getName();

	private static final String ETAT_NON_RECUPERE = "NON_RECUPERE";

	/** The publication home. */
	private PublicationATraiterHome publicationATraiterHome;

	protected IServiceManager serviceManager = ServiceManager.getInstance();

	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			publicationATraiterHome = getEntityHome(PublicationATraiterHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	public void createPublicationATraiter(PublicationATraiterDTO publicationATraiterDTO) {
		final String methode = "createPublicationATraiter";
		serviceManager.getLoggerManager().fine(CLASSNAME, methode, "Cr�ation du publicationATraiter  " + publicationATraiterDTO);
		final HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(PublicationATraiter.SLINK_CONCERNE_COMMANDE, publicationATraiterDTO.getIdCommande());
		values.put(PublicationATraiter.FIELD_DATE_ECHEC_PUBLICATION, publicationATraiterDTO.getDatabaseDateEchecPublication());
		values.put(PublicationATraiter.FIELD_PUBLICATION, publicationATraiterDTO.getPublication());
		values.put(PublicationATraiter.FIELD_DATE_RECUPERATION, null);
		values.put(PublicationATraiter.FIELD_ETAT, ETAT_NON_RECUPERE);
		values.put(PublicationATraiter.FIELD_CODE_PARTENAIRE, publicationATraiterDTO.getCodePartenaire());
		values.put(PublicationATraiter.FIELD_ID, publicationATraiterDTO.getId());
		PublicationATraiter publicationATraiter;
		try {
			publicationATraiter = publicationATraiterHome.create(publicationATraiterDTO.getId(), values);
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Erreur cr�ation du pubRegMan " + publicationATraiterDTO, ce);
			throw new EJBException(ce);
		}
		publicationATraiter.setLinks(values);

	}

	public void updatePublicationEtat(ArrayList<PublicationATraiterDTO> publicationsDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePublicationEtat", "Mise � jour de la ligne de l'�tat des publications");
		for (PublicationATraiterDTO publicationDTO : publicationsDTO) {
			try {
				PublicationATraiter publicationATraiter = getPublicationATraiterEntity(publicationDTO.getId());
				publicationATraiter.setEtat(publicationDTO.getEtat());
			} catch (FinderException fe) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePublicationEtat", "Probl�me de mise � jour de la publication: id = " + publicationDTO.getId(), fe);
				throw new EJBException(fe);
			}
		}
	}

	public void updatePublicationDateRecuperation(ArrayList<PublicationATraiterDTO> publicationsDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePublicationDateRecuperation", "Mise � jour de la ligne de la date de r�cup�ration des publications");
		for (PublicationATraiterDTO publicationDTO : publicationsDTO) {
			try {
				PublicationATraiter publicationATraiter = getPublicationATraiterEntity(publicationDTO.getId());
				publicationATraiter.setDateRecuperation(publicationDTO.getDatabaseDateRecuperation());
			} catch (FinderException fe) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePublicationEtat", "Probl�me de mise � jour de la publication: id = " + publicationDTO.getId(), fe);
				throw new EJBException(fe);
			}
		}
	}

	private PublicationATraiter getPublicationATraiterEntity(String id) throws FinderException {
		return publicationATraiterHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.PublicationManager#findPublicationByApplicationEtEtat(java.lang.String)
	 */
	public ArrayList<PublicationATraiterDTO> findPublicationByApplicationEtEtat(String codePArtenaire, String etat) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findPublicationByApplicationEtEtat", "Recherche des publications non r�cup�r�es pour le partenaire " + codePArtenaire);
		ArrayList<PublicationATraiterDTO> publicationATraiterDTOs = new ArrayList<PublicationATraiterDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<PublicationATraiter> listePublicationATraiter = publicationATraiterHome.findByApplicationAndEtat(codePArtenaire, etat);
			for (PublicationATraiter publicationATraiter : listePublicationATraiter) {
				publicationATraiterDTOs.add(new PublicationATraiterDTO(publicationATraiter));
			}
			return publicationATraiterDTOs;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findPublicationByApplicationEtEtat", "Probleme lors de la recherche de la publication pour le partenaire " + codePArtenaire, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.PublicationManager#findPublicationByApplication(java.lang.String)
	 */
	public ArrayList<PublicationATraiterDTO> findPublicationByApplication(String codePArtenaire) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findPublicationByApplication", "Recherche des publications pour le partenaire " + codePArtenaire);
		ArrayList<PublicationATraiterDTO> publicationATraiterDTOs = new ArrayList<PublicationATraiterDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<PublicationATraiter> listePublicationATraiter = publicationATraiterHome.findByApplication(codePArtenaire);
			for (PublicationATraiter publicationATraiter : listePublicationATraiter) {
				publicationATraiterDTOs.add(new PublicationATraiterDTO(publicationATraiter));
			}
			return publicationATraiterDTOs;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findPublicationByApplicationEtEtat", "Probleme lors de la recherche de la publication pour le partenaire " + codePArtenaire, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.PublicationManager#findPublicationByEtat(java.lang.String)
	 */
	public ArrayList<PublicationATraiterDTO> findPublicationByEtat(String etat) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findPublicationByApplication", "Recherche des publications non r�cup�r�es");
		ArrayList<PublicationATraiterDTO> publicationATraiterDTOs = new ArrayList<PublicationATraiterDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<PublicationATraiter> listePublicationATraiter = publicationATraiterHome.findByEtat(etat);
			for (PublicationATraiter publicationATraiter : listePublicationATraiter) {
				publicationATraiterDTOs.add(new PublicationATraiterDTO(publicationATraiter));
			}
			return publicationATraiterDTOs;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findPublicationByApplicationEtEtat", "Probleme lors de la recherche de la publication non r�cup�r�e", fe);
			throw new EJBException(fe);
		}
	}

}
