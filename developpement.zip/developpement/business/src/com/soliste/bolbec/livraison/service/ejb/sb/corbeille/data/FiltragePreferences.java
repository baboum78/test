/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.io.Serializable;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>14/01/2014</TD><TD>FTE</TD><TD>EV-000268 : Crit�re de Filtre Multizones</TD></TR>
 * </TABLE><BR>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQ.10345</TD><TD>EP267 - Permettre aux utilisateurs des corbeilles de filtrer sur plusieurs zones SI � la fois. (EV268)</TD></TR>
 * </TABLE>
 * 
 * Pr�f�rences de filtrage
 * 
 * @author rgvs7490
 */
public class FiltragePreferences implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = -7564833804239582159L;

	private List<TexteFiltrePreference> textePreferenceList;
	private List<DateFiltrePreference> datePreferenceList;
	private List<SimpleFiltrePreference> simplePreferenceList;
	private List<TexteFiltrePreference> extendedTextePreferenceList;
	private List<MultiCriteresFiltrePreference> multiCriteresFiltrePreferenceList;

	private Map<String, TexteFiltrePreference> textePreferenceMap;
	private Map<String, DateFiltrePreference> datePreferenceMap;
	private Map<String, SimpleFiltrePreference> simplePreferenceMap;
	private Map<String, MultiCriteresFiltrePreference> multiCriteresPreferenceMap;

	/**
	 * 
	 * @param textePreferenceList
	 * @param datePreferenceList
	 * @param simplePreferenceList
	 * @param extendedTextePreferenceList
	 */
	public FiltragePreferences(List<TexteFiltrePreference> textePreferenceList, List<DateFiltrePreference> datePreferenceList, List<SimpleFiltrePreference> simplePreferenceList, List<TexteFiltrePreference> extendedTextePreferenceList,
			List<MultiCriteresFiltrePreference> multiCriteresFiltrePreferenceList) {
		this.textePreferenceList = textePreferenceList;
		this.datePreferenceList = datePreferenceList;
		this.simplePreferenceList = simplePreferenceList;
		this.extendedTextePreferenceList = extendedTextePreferenceList;
		this.multiCriteresFiltrePreferenceList = multiCriteresFiltrePreferenceList;

		textePreferenceMap = new HashMap<String, TexteFiltrePreference>();
		datePreferenceMap = new HashMap<String, DateFiltrePreference>();
		simplePreferenceMap = new HashMap<String, SimpleFiltrePreference>();
		multiCriteresPreferenceMap = new HashMap<String, MultiCriteresFiltrePreference>();
		for (TexteFiltrePreference pref : textePreferenceList) {
			textePreferenceMap.put(pref.getId(), pref);
		}
		for (DateFiltrePreference pref : datePreferenceList) {
			datePreferenceMap.put(pref.getId(), pref);
		}
		for (SimpleFiltrePreference pref : simplePreferenceList) {
			simplePreferenceMap.put(pref.getId(), pref);
		}
		for (TexteFiltrePreference pref : extendedTextePreferenceList) {
			textePreferenceMap.put(pref.getId(), pref);
		}
		for (MultiCriteresFiltrePreference pref : multiCriteresFiltrePreferenceList) {
			multiCriteresPreferenceMap.put(pref.getId(), pref);
		}
	}

	public List<DateFiltrePreference> getDatePreferenceList() {
		return this.datePreferenceList;
	}

	public List<TexteFiltrePreference> getTextePreferenceList() {
		return this.textePreferenceList;
	}

	public List<SimpleFiltrePreference> getSimplePreferenceList() {
		return this.simplePreferenceList;
	}

	public List<TexteFiltrePreference> getExtendedTextePreferenceList() {
		return this.extendedTextePreferenceList;
	}

	/**
	 * @param string
	 * @return
	 */
	public List<MultiCriteresFiltrePreference> getMultiCriteresFiltrePreferenceList() {
		return multiCriteresFiltrePreferenceList;
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public TexteFiltrePreference getTexteFiltrePreference(String id) {
		return textePreferenceMap.get(id);
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public DateFiltrePreference getDateFiltrePreference(String id) {
		return datePreferenceMap.get(id);
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public SimpleFiltrePreference getSimpleFiltrePreference(String id) {
		return simplePreferenceMap.get(id);
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public TexteFiltrePreference getExtendedTexteFiltrePreference(String id) {
		return textePreferenceMap.get(id);
	}

	/**
	 * 
	 * @param id
	 * @return
	 */
	public MultiCriteresFiltrePreference getMultiCriteresFiltrePreference(String id) {
		return multiCriteresPreferenceMap.get(id);
	}

}
