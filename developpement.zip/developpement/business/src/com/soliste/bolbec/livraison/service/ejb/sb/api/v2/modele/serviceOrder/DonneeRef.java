package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "donneeRef")
public class DonneeRef {

	private String nom;
	@XmlElement(name = "val")
	private ArrayList<DonneeRefVal> val;

	public String getNom() {
		return nom;
	}

	public void setNom(String nom) {
		this.nom = nom;
	}

	public List<DonneeRefVal> getVal() {
		return val;
	}

	public void setVal(ArrayList<DonneeRefVal> val) {
		this.val = val;
	}

}
