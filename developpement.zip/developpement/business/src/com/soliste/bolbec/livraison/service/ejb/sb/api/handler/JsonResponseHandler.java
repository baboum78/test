package com.soliste.bolbec.livraison.service.ejb.sb.api.handler;

import javax.ws.rs.core.Response;

import org.apache.cxf.jaxrs.ext.ResponseHandler;
import org.apache.cxf.jaxrs.model.OperationResourceInfo;
import org.apache.cxf.message.Message;

import com.soliste.bolbec.commun.service.ConstantesAPI;
import com.soliste.bolbec.commun.service.api.exception.APIException;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;

/**
 * Classe de gestion des r�ponses (pour afficher les erreurs si besoin)
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/02/2016</TD><TD>BPE</TD><TD>EV-000353 : Mise en place archi Rest de Base</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
public class JsonResponseHandler implements ResponseHandler {

	private static final int JALON_HTTP_CODE_ERREUR = 400;

	/**
	 * Cette m�thode permet d'ajouter un contenu JSON dans les r�ponses en erreur qui ne contiennent pas de Body.
	 * Certaines erreurs sont �mises directement par CXF donc l'entit� APIError n'est pas �mises.
	 * Exemple dans les cas o� la requ�te ne coorespond � aucune ressource ou que la m�thode ou le format n'est pas accept�e.
	 */
	@Override
	public Response handleResponse(@SuppressWarnings("unused") Message message, @SuppressWarnings("unused") OperationResourceInfo info, Response response) {

		// R�cup�ration du code http
		final int status = response.getStatus();

		// Si ce n'est pas une erreur, pas de traitement de la r�ponse
		if (status < JALON_HTTP_CODE_ERREUR) {
			return response;
		}

		// Si la r�ponse contient d�j� une entit� (Forc�ment une APIError dans ce cas), pas de traitement de la r�ponse
		if ((response.getEntity() != null)) {
			return response;
		}

		// Ici, nous avons donc une erreur sans body
		// Nous v�rifions s'il n'existe pas une erreur g�n�rique dans l'�num�ration
		final APIException apiException = APIExceptionEnum.createGenericApiException(status);

		// S'il n'y a pas de m�thode g�n�rique, pas de traitement de la r�ponse
		if (apiException == null) {
			return response;
		}

		// Si pr�sent nous retournons l'APIError g�n�rique en tant que r�ponse
		return Response.fromResponse(apiException.getReponse()).header(ConstantesAPI.HEADER_CONTENT_TYPE, ConstantesAPI.CONTENT_TYPE_JSON_UTF8).build();
	}

}
