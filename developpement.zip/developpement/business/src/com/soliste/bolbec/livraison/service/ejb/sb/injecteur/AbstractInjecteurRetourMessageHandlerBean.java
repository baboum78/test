/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur;

import java.io.Serializable;
import java.util.Map;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.util.jms.QueueHelper;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Message Handler pour injection de message en provenance du routeur avec
 * possibilit� de renvoi du message au routeur en cas de probl�me. <br/> Pour
 * que cela puisse fonctionner, il faut que le composant (EJB par exemple)
 * faisant appel � cette classe ait un descripteur de d�ploiement configur�
 * correctement:<br/> ejb-jar.xml:
 * 
 * <pre>
 * &lt;resource-ref&gt;
 * &lt;res-ref-name&gt;jms/retourRouteurQueueConnectionFactory&lt;/res-ref-name&gt;
 * &lt;res-type&gt;javax.jms.QueueConnectionFactory&lt;/res-type&gt;
 * &lt;res-auth&gt;Container&lt;/res-auth&gt;
 * &lt;res-sharing-scope&gt;Shareable&lt;/res-sharing-scope&gt;
 * &lt;/resource-ref&gt;
 * 
 * &lt;resource-env-ref&gt;
 * &lt;resource-env-ref-name&gt;jms/retourRouteurQueue&lt;/resource-env-ref-name&gt;
 * &lt;resource-env-ref-type&gt;javax.jms.Queue&lt;/resource-env-ref-type&gt;
 * &lt;/resource-env-ref&gt;
 * </pre>
 * 
 * weblogic-ejb-jar.xml:
 * 
 * <pre>
 * &lt;reference-descriptor&gt;
 * &lt;resource-description&gt;
 * &lt;res-ref-name&gt;jms/retourRouteurQueueConnectionFactory&lt;/res-ref-name&gt;
 * &lt;jndi-name&gt;queue.XAQueueFactory&lt;/jndi-name&gt;
 * &lt;/resource-description&gt;
 * &lt;resource-env-description&gt;
 * &lt;res-env-ref-name&gt;jms/retourRouteurQueue&lt;/res-env-ref-name&gt;
 * &lt;jndi-name&gt;queue.emission.CREvtLcEfb&lt;/jndi-name&gt;
 * &lt;/resource-env-description&gt;
 * &lt;/reference-descriptor&gt;
 * </pre>
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 *
 * @author gdzd8490
 */
public abstract class AbstractInjecteurRetourMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/** Nom JNDI de la factory pour le file de retour au routeur */
	private static final String RETOUR_ROUTEUR_QUEUE_CONNECTION_FACTORY_NAME = "jms/retourRouteurQueueConnectionFactory";
	/** Nom JNDI de la file pour le retour du message au routeur */
	private static final String RETOUR_ROUTEUR_QUEUE_NAME = "jms/retourRouteurQueue";
	/** QueueHelper pour le renvoi de messages au routeur via une file sp�cifique */
	private QueueHelper retourRouteurQueueHelper;

	/**
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext sessionContext) {
		super.setSessionContext(sessionContext);
		this.retourRouteurQueueHelper = new QueueHelper(RETOUR_ROUTEUR_QUEUE_CONNECTION_FACTORY_NAME, RETOUR_ROUTEUR_QUEUE_NAME);
	}

	/**
	 * Renvoie le message au routeur
	 * 
	 * @param message
	 * @param causeId
	 * @param diagnostic
	 */
	public void returnMessageToRouter(Serializable message, String causeId, String diagnostic) {
		QueueConnection queueConnection = null;
		try {
			queueConnection = retourRouteurQueueHelper.createConnection();
			QueueSession queueSession = queueConnection.createQueueSession(true, 0);
			QueueSender queueSender = queueSession.createSender(retourRouteurQueueHelper.getQueue());
			// Serializable msgContent = getMessageContent(message);
			ServiceManager.getInstance().getLoggerManager().finest(getClass().getName(), "returnMessageToRouter", "Message retourn� au routeur : " + message + " - cause : " + causeId + " - diagnostic : " + diagnostic);
			// ObjectMessage msg = queueSession.createObjectMessage(msgContent);
			ObjectMessage msg = queueSession.createObjectMessage(message);
			queueSender.send(msg);
			// } catch (InvalidJmsMessageException e) {
			// on ne fait rien: on ne peut pas rejeter le message proprement,
			// et �a ne sert � rien de faire un rollback sinon on va devoir
			// retraiter le message
		} catch (JMSException e) {
			retourRouteurQueueHelper.invalidate();
			throw new RuntimeException(e);
		} catch (NamingException e) {
			throw new EJBException(e);
		} finally {
			QueueHelper.closeConnection(queueConnection);
		}
	}

	/**
	 * Rejette le message vers le routeur si c'est possible ou vers la file
	 * d'erreur sinon
	 * 
	 * @param message
	 * message re�u
	 * @param causeId
	 * cause du probl�me
	 * @param diagnostic
	 * diagnostic
	 */
	protected void rejectMessage(Serializable message, String causeId, String diagnostic) {
		if (isRetourRouteurAutorise(message)) {
			// Cette instance de livraison n'est pas capable de g�rer ce
			// message mais il y a d'autres instances possibles en mode
			// d�grad�.
			// On renvoie donc le message au routeur pour qu'il d�termine
			// une autre instance de livraison � laquelle envoyer le message
			returnMessageToRouter(message, causeId, diagnostic);
		} else {
			// Cette instance de livraison n'est pas capable de g�rer ce
			// message et il n'y a pas d'autres instances possibles pour ce
			// message (mode d�grad�).
			// On renvoie donc un CR NOK pour ce message par la queue
			// generalRoutage
			super.rejectMessage(message, causeId, diagnostic);
		}
	}

	/**
	 * Renvoie un indicateur pour savoir si le message peut �tre retourn� au
	 * routeur en cas de commande inconnue. Cette m�thode renvoie un bool�en
	 * selon la valeur stock�e pour la cl� Constantes.FIELD_RETOUR_ROUTEUR_AUTORISE dans
	 * la HashMap fournie par le routeur.
	 * 
	 * @param message
	 * la HashMap fournie par le routeur
	 * @return un bool�en selon la valeur stock�e pour la cl�
	 * Constantes.FIELD_RETOUR_ROUTEUR_AUTORISE dans la HashMap fournie par le
	 * routeur
	 * @throws InvalidMessageException
	 */
	@SuppressWarnings("unchecked")
	protected boolean isRetourRouteurAutorise(Serializable message) throws InvalidMessageException {
		boolean retourRouteurAutorise;
		Map<String, String> messageMap = (Map<String, String>) message;
		String indicateurRetour = messageMap.get(Constantes.FIELD_RETOUR_ROUTEUR_AUTORISE);
		if (Constantes.RETOUR_ROUTEUR_AUTORISE.equals(indicateurRetour)) {
			retourRouteurAutorise = true;
		} else {
			retourRouteurAutorise = false;
		}
		ServiceManager.getInstance().getLoggerManager().finest(getClass().getName(), "isRetourRouteurAutorise", indicateurRetour);
		return retourRouteurAutorise;
	}
}
