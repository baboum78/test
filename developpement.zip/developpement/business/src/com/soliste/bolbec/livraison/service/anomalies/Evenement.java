/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

/**
 * $Workfile:   Evenement.java  $
 * $Revision:   1.5  $
 * $Date:   Jul 07 2004 11:02:18  $
 * $Log:   W:/00_PVCS_BOLBECG4/archives/developpement/uc_anomalies/src.ejb/bolbec/commun/anomalies/Evenement.java-arc  $
 * 
 *    Rev 1.5   Jul 07 2004 11:02:18   abudasca
 * Ajout attribut date fin pr�vue utile pour la cl�ture d'un AVP affectation XDSL (OGA 360)
 * 
 *    Rev 1.4   Nov 17 2003 14:43:32   HBOURDIN
 * fk_Role -> idRole
 * 
 *    Rev 1.3   Oct 17 2003 10:15:50   HBOURDIN
 * suppression Exception
 * 
 *    Rev 1.2   Oct 07 2003 16:14:38   pmeunier
 * Changement dans la gestion des exceptions
 * 
 *    Rev 1.1   Oct 07 2003 11:35:04   pmeunier
 * Changements des noms de champs et de m�thodes
 * 
 *    Rev 1.0   Oct 06 2003 16:05:00   pmeunier
 * Initial revision.
 * 
 *    Rev 1.0   Oct 06 2003 15:51:44   pmeunier
 * Initial revision.
 * 
 *    Rev 1.0   Sep 26 2003 10:25:08   pmeunier
 * Initial revision.
 */

package com.soliste.bolbec.livraison.service.anomalies;

import com.soliste.bolbec.commun.service.util.GeneratorManager;
import com.soliste.bolbec.commun.service.util.IGeneratorManager;
import com.soliste.bolbec.fwk.util.DateUtils;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>21/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * </TABLE>
 * 
 */
public class Evenement {

	private String id;
	private String libelle;
	private Long dateGeneration;
	private String idCauseEvenement;
	private String libCauseEvenement;
	private String idTypeEvenement;
	private String idCategorieEvenement;
	private String libCategorieEvenement;
	private String idRole;
	private Long dateFin;
	private String idAPourOrigineAgent;
	private String typeAbd;
	private String responsabiliteId;

	private static IGeneratorManager generatorManager = null;

	/**
	 * @return the prepareBrasilDem
	 */
	public static IGeneratorManager getGeneratorManager() {
		if (generatorManager == null) {
			generatorManager = GeneratorManager.getInstance();
		}
		return generatorManager;
	}

	/**
	 * @param pgeneratorManager the pgeneratorManager to set
	 */
	public static void setGeneratorManager(IGeneratorManager pgeneratorManager) {
		generatorManager = pgeneratorManager;
	}

	/**
     * 
     */
	public Evenement() {
		dateGeneration = DateUtils.getDatabaseDate();
		id = getGeneratorManager().generateKey();
	}

	/**
	 * @return
	 */
	public Long getDateGeneration() {
		return dateGeneration;
	}

	/**
	 * @param a_dateGeneration The dateGeneration to set.
	 */
	public void setDateGeneration(Long a_dateGeneration) {
		dateGeneration = a_dateGeneration;
	}

	/**
	 * @return
	 */
	public Long getDateFin() {
		return dateFin;
	}

	/**
	 * @param a_dateFin The dateFin to set.
	 */
	public void setDateFin(Long a_dateFin) {
		dateFin = a_dateFin;
	}

	/**
	 * @return
	 */
	public String getIdTypeEvenement() {
		return idTypeEvenement;
	}

	/**
	 * @return
	 */
	public String getIdCauseEvenement() {
		return idCauseEvenement;
	}

	/**
	 * @return
	 */
	public String getIdRole() {
		return idRole;
	}

	/**
	 * @return
	 */
	public String getIdCategorieEvenement() {
		return idCategorieEvenement;
	}

	/**
	 * @return
	 */
	public String getLibCategorieEvenement() {
		return libCategorieEvenement;
	}

	/**
	 * @return
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param a_id
	 */
	public void setId(String a_id) {
		id = a_id;
	}

	/**
	 * @return
	 */
	public String getLibCauseEvenement() {
		return libCauseEvenement;
	}

	/**
	 * @return
	 */
	public String getLibelle() {
		return libelle;
	}

	/**
	 * @param a_idTypeEvenement
	 */
	public void setIdTypeEvenement(String a_idTypeEvenement) {
		idTypeEvenement = a_idTypeEvenement;
	}

	/**
	 * @param a_idCauseEvenement
	 */
	public void setIdCauseEvenement(String a_idCauseEvenement) {
		idCauseEvenement = a_idCauseEvenement;
	}

	/**
	 * @param a_idRole
	 */
	public void setIdRole(String a_idRole) {
		idRole = a_idRole;
	}

	/**
	 * @param a_idCategorieEvenement
	 */
	public void setIdCategorieEvenement(String a_idCategorieEvenement) {
		idCategorieEvenement = a_idCategorieEvenement;
	}

	/**
	 * @param a_libCategorieEvenement
	 */
	public void setLibCategorieEvenement(String a_libCategorieEvenement) {
		libCategorieEvenement = a_libCategorieEvenement;
	}

	/**
	 * @param a_libCauseEvenement
	 */
	public void setLibCauseEvenement(String a_libCauseEvenement) {
		libCauseEvenement = a_libCauseEvenement;
	}

	/**
	 * @param a_libelle
	 */
	public void setLibelle(String a_libelle) {
		libelle = a_libelle;
	}

	/**
	 * @return
	 */
	public String getIdAPourOrigineAgent() {
		return idAPourOrigineAgent;
	}

	/**
	 * @param idAPourOrigineAgent
	 */
	public void setIdAPourOrigineAgent(String idAPourOrigineAgent) {
		this.idAPourOrigineAgent = idAPourOrigineAgent;
	}

	/**
	 * @return
	 */
	public String getTypeAbd() {
		return typeAbd;
	}

	/**
	 * @param typeAbd
	 */
	public void setTypeAbd(String typeAbd) {
		this.typeAbd = typeAbd;
	}

	public String getResponsabiliteId() {
		return responsabiliteId;
	}

	public void setResponsabiliteId(String responsabiliteId) {
		this.responsabiliteId = responsabiliteId;
	}
}
