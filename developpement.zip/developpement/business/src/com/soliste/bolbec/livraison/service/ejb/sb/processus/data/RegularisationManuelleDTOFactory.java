/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.List;
import java.util.SortedMap;

import aps.EtatLigneCdeConstantes;
import aps.EtatPublicationConstantes;
import aps.ProcessusTypeConstantes;
import aps.StatutCommandeConstantes;

import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.JalonDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.PubRegManDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.TacheManager;

/**
 * @author La�titia FABRE
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/11/2010</TD><TD>DBA</TD><TD>IRMA_70: Modification de TacheManager en EJB Session</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>04/04/2011</TD><TD>BPE</TD><TD>Renommage de la classe TacheManager</TD></TR>
 * <TR><TD>22/08/2011</TD><TD>GPA</TD><TD>EV-000155: Maj Cristal sur Stopper Regul</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'><TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.1316</TD><TD>EP0054 � Faire un appel automatique au service de Cristal</TD></TR>
 * </TABLE>
 */
public class RegularisationManuelleDTOFactory {

	static final protected IServiceManager serviceManager = ServiceManager.getInstance();

	private RegularisationManuelleDTOFactory() {
		//
	}

	/**
	 * @param tacheCourante
	 * @param evenementProvoquant
	 * @param modeOpName
	 * @param versionArtemis
	 * @param allPubRegMan
	 * 
	 * @param listeClasseeCRNonInfocentre
	 * @param listeCRSupDePro
	 * @param listeCROsiris
	 * 
	 * @return RegularisationManuelleDTO
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>22/08/2011</TD><TD>GPA</TD><TD>EV-000155: Maj Cristal sur Stopper Regul</TD></TR>
	 * </TABLE>
	 */
	public static RegularisationManuelleDTO create(TacheDTO tacheCourante, EvtDTO evenementProvoquant, String modeOpName, String versionArtemis, List<PubRegManDTO> allPubRegMan,
			SortedMap<JalonDTO, SortedMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>>> listeClasseeCRNonInfocentre, SortedMap<JalonDTO, List<ListCRSupDeProDTO>> listeCRSupDePro, List<CROsirisDTO> listeCROsiris) {

		RegularisationManuelleDTO dto = new RegularisationManuelleDTO();
		ProcessusDTO processus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheCourante.getId());
		dto.setIdProcessus(processus.getId());
		String causeEvenementId = null;
		if (evenementProvoquant != null && evenementProvoquant.getCauseEvenement() != null) {
			causeEvenementId = evenementProvoquant.getCauseEvenement().getId();
		}
		dto.setModeOperatoireUrl(ModeOperatoireUtil.getUrlModeOperatoire(modeOpName, causeEvenementId, versionArtemis));
		dto.setListeCRNonInfocentre(listeClasseeCRNonInfocentre);
		dto.setListeCRSupDePro(listeCRSupDePro);
		dto.setListeCROsiris(listeCROsiris);

		// R�cup�ration de la valeur constante du processusType du processus
		String idProcessusType = processus.getProcessusType().getId();
		ProcessusTypeDTO processusTypeDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, idProcessusType);
		String processusType = processusTypeDTO.getValeurConstante();

		// R�cup�ration de la valeur constante du catalogueTache de la tache
		String idCatalogueTache = tacheCourante.getCatalogueTache().getId();
		CatalogueTacheDTO catalogueTacheDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, idCatalogueTache);
		dto.setCatalogueTacheValConst(catalogueTacheDTO.getValeurConstante());

		// Est-ce qu'il existe au moins une publication � l'�tat ENVOYE ?
		boolean isUnePubEnvoye = false;
		for (PubRegManDTO pubRegMan : allPubRegMan) {
			if (EtatPublicationConstantes.ENVOYE.equals(pubRegMan.getEtatPublication().getId())) {
				isUnePubEnvoye = true;
				break;
			}
		}

		// Est-ce que parmi les lignecommande de la commade en cours, il en existe au moins une qui n'est pas � l'�tat 'ECREG'
		boolean isUneLigneCdeNonECREG = false;
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(tacheCourante.getLancerParProcessus().getId());
		for (LigneCommandeDTO lc : lignesCde) {
			if (!EtatLigneCdeConstantes.ECREG.equals(lc.getEtatLigneCde().getId())) {
				isUneLigneCdeNonECREG = true;
			}
		}

		// Affichage boutons Envoyer et Sortir
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByTache(tacheCourante.getId());
		if (!TacheManager.INDICATEUR_DONE.equals(tacheCourante.getIndicateurFin())) {
			if (listeClasseeCRNonInfocentre.isEmpty() && listeCROsiris.isEmpty()) {
				if ((StatutCommandeConstantes.AGREGEE.equals(commande.getStatutCommande().getId())) && ConstantesDynamicCommande.VALEUR_NON.equals(commande.getDynamicCommandes().get(ConstantesDynamicCommande.CLE_DOSSIER_CRISTAL_MAJ))) {
					dto.setEnvoyable(true);
					dto.setSortable(false);
				} else {
					dto.setEnvoyable(false);
					dto.setSortable(true);
				}
			} else {
				dto.setEnvoyable(true);
				dto.setSortable(false);
			}
		} else {
			dto.setEnvoyable(false);
			dto.setSortable(false);
		}

		// Affichage bouton RetourAuto
		if (!ProcessusTypeConstantes.LIVRAISON_VALEUR_CONSTANTE.equals(processusType)) {
			dto.setRetournable(false);
		} else {
			if (isUnePubEnvoye) {
				dto.setRetournable(false);
			} else {
				if (isUneLigneCdeNonECREG) {
					dto.setRetournable(false);
				} else {
					if (StatutCommandeConstantes.AGREGEE.equals(commande.getStatutCommande().getId())) {
						if (ConstantesDynamicCommande.VALEUR_NON.equals(commande.getDynamicCommandes().get(ConstantesDynamicCommande.CLE_DOSSIER_CRISTAL_MAJ))) {
							dto.setRetournable(true);
						} else {
							dto.setRetournable(false);
						}
					} else {
						dto.setRetournable(true);
					}
				}
			}
		}

		return dto;
	}
}