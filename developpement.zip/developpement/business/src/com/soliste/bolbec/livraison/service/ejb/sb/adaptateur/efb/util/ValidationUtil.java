/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ITraductionManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.CasMetierConstantes;
import aps.Offre;
import aps.SystemeExterneConstantes;
import aps.TypeOpPonctuellesConstantes;
import bolbec.adaptateur.efb.xml.generated.Commande;
import bolbec.adaptateur.efb.xml.generated.CommandeEfb;
import bolbec.adaptateur.efb.xml.generated.LigneCde;
import bolbec.adaptateur.efb.xml.generated.SpecificiteCommande;
import bolbec.adaptateur.efb.xml.generated.ValeurFonctionEdP;

/**
 * Classe ValidationUtil qui fait la validation que Castor n'est pas capable de faire.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>????????</TD><TD>SICOR LYON</TD><TD>Premi�re version de la classe</TD></TR>
 * <TR><TD>20091126</TD><TD>DBA</TD><TD>EV-000039: Impl�mentation de l'�volution</TD></TR>
 * <TR><TD>03/09/2010</TD><TD>YTR</TD><TD>Modification log qualif</TD></TR>
 * <TR><TD>16/09/2010</TD><TD>GPA</TD><TD>EV-000053 : Ajout du champ commandeId dans les logs qualif</TD></TR>
 * <TR><TD>08/04/2013</TD><TD>GPA</TD><TD>G8R2C2 - EV-000238 : Rejet automatique des commandes EFB non conformes</TD></TR>
 * <TR><TD>20/05/2013</TD><TD>EBA</TD><TD>G8R2C2 - EV-000238 : Complement logs</TD></TR>
 * <TR><TD>08/12/2015</TD><TD>JDE</TD><TD>EV-000348 : Net commande unique</TD></TR>
 * <TR><TD>11/01/2016</TD><TD>BPE</TD><TD>QC-000724 : R�impl�mentation validateCommandeNonNsdSansPrestation</TD></TR>
 * <TR><TD>23/08/2016</TD><TD>JDE</TD><TD>QC-000775 : Ajout contr�le fonction NDEDP obligatoire</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.7425</TD><TD>EP0201 - Rep�rer et rejeter les commandes correspondant � des cas non pr�vus dans le SI</TD></TR>
 * </TABLE>
 */
public class ValidationUtil {

	private static final String CLASS_NAME = ValidationUtil.class.getName();

	protected static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	/**
	 * Validate ref op commerciale.
	 * 
	 * @param codeAction the a_code action
	 * 
	 * @return true, if successful
	 */
	public static boolean validateRefOpCommerciale(String codeAction) {
		if (!TypeOpPonctuellesConstantes.CR.equals(codeAction) && !TypeOpPonctuellesConstantes.SU.equals(codeAction) && !TypeOpPonctuellesConstantes.MO.equals(codeAction) && !"DEM".equals(codeAction) && !"IN1".equals(codeAction)
				&& !"IN2".equals(codeAction) && !"IN3".equals(codeAction) && !"DN".equals(codeAction)) {
			return false;
		}
		return true;
	}

	/**
	 * Validate statut op lc.
	 * 
	 * @param statutOperation the a_statut operation
	 * 
	 * @return true, if successful
	 */
	public static boolean validateStatutOpLC(String statutOperation) {
		if (!EFBConstantes.STATUT_OP_LC_VALIDE.equals(statutOperation) && !EFBConstantes.STATUT_OP_LC_INCONNU.equals(statutOperation) && !EFBConstantes.STATUT_OP_LC_A_TRAITER.equals(statutOperation)) {
			return false;
		}
		return true;
	}

	/**
	 * EV-000039: Mise en place de la validation des offres incompatibles
	 * 
	 * @param cmdEFB L'intention de commande
	 * @return true si l'IC EFB est compatible au niveau offre PSS, false sinon
	 */
	public static boolean validateOffreCompatible(CommandeEfb cmdEFB) {
		// R�cup�ration des managers
		ITraductionManager traductionManager = SERVICE_MANAGER.getTraductionManager();
		ILoggerManager loggerManager = SERVICE_MANAGER.getLoggerManager();

		// Liste de valeurs � construire
		List<String> valeurs = new ArrayList<String>();

		// R�cup�ration de la cl� � rechercher (Peut a terme devenir multiple !)
		String cle = traductionManager.getTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, "CHAMP_IC_EFB", "OUI");

		// Si une cl� existe
		if (cle != null) {

			// R�cup�ration de la liste des valeurs pour cette cl�
			if ("CodeOffrePSS".equals(cle)) {

				for (LigneCde lcEFB : cmdEFB.getStructureMetier().getCommande().getLigneCde()) {
					valeurs.add(lcEFB.getCodeOffrePSS());
				}
			}

			// R�cup�ration des valeurs incompatible (Peut a terme devenir multiple !)
			String valeursIncompatible = traductionManager.getTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, "VALEURS_INCOMPATIBLES", "OUI");
			if (valeursIncompatible != null) {

				// D�coupage des valeurs (S�parateur /)
				List<String> listValeursIncompatible = Arrays.asList(valeursIncompatible.split("/"));

				// Si toutes les valeurs incompatibles sont pr�sente
				if (valeurs.containsAll(listValeursIncompatible)) {
					loggerManager.qualif("ValidationUtil", 1, "validateOffreCompatible", cmdEFB.getStructureMetier().getCommande().getRefCommande(), " - L'IC EFB contient toutes les offres incompatibles");
					return false;
				}
			}
		}

		return true;
	}

	/**
	 * Validation du fait que les commandes non-agreg�es ne poss�dent pas d'offre de Prestation
	 * 
	 * Artemis peut recevoir des commandes Parsifal (via PFB) qui poss�dent des offres de prestation
	 * Lorsque les commandes NSD+ sont r�alis�es sur ligne inactive/inexistante, la commande peut inclure des prestations.
	 * Par contre il n�existe pas de cas o� une commande EFB non NSD+ sur ligne en service puisse livrer une prestation.
	 * 
	 * @param icEFB l'IC EFB
	 * @param commandeAgregee le bool�en d�crivant si la commande est de type NSD+
	 * @return <code>false</code> si la commande n'est pas de type NSD+ mais poss�de une offre de Prestation, <code>true</code> dans tous les autres cas
	 */
	public static boolean validateCommandeNonNsdSansPrestation(CommandeEfb icEFB, boolean commandeAgregee) {
		String method = "validateCommandeNonNsdSansPrestation";

		if (commandeAgregee) {
			return true;
		}

		SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Commande non agreg�e. Recherche des offres de nature PREST.");

		// R�cup�ration de la liste des Lignes de Commande de l'IC EFB
		OffreDTO offre;
		for (LigneCde lcEFB : icEFB.getStructureMetier().getCommande().getLigneCde()) {
			offre = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpaceByVersion(OffreDTO.class, new Comparaison(Offre.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, lcEFB.getCodeOffrePSS()));
			if (offre != null && Constantes.NATURE_OFFRE_PREST.equals(offre.getNatureOffre())) {
				return false;
			}
		}
		SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Validation commandes non-agreg�es sans d'offre de Prestation OK.");
		return true;
	}

	/**
	 * Validation du fait que les commandes agreg�es ne poss�dent au moins une offre de Prestation
	 * 
	 * @param icEFB l'IC EFB
	 * @param commandeAgregee le bool�en d�crivant si la commande est de type NSD+
	 * @param casMetier le cas m�tier de la commande
	 * @return <code>false</code> si la commande est de type NSD+ et le cas m�tier est CR_FTTH mais ne poss�de aucune offre de Prestation, <code>true</code> dans tous les autres cas
	 */
	public static boolean validateCommandeNsdAvecPrestation(CommandeEfb icEFB, boolean commandeAgregee, String casMetier) {
		String method = "validateCommandeNsdAvecPrestation";
		// Les intentions de commande de cr�ation FTTH, taggu�es NSD+, mais ne poss�dant pas d�offre de prestation sont rejet�es et remontent un compte-rendu

		if (commandeAgregee && CasMetierConstantes.CR_FTTH.equals(casMetier)) {
			// R�cup�ration des codes des offres de Prestation
			List<String> listeValeursExterne = SERVICE_MANAGER.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.PRESTATION_FIBRE, Constantes.CST_OUI);
			// R�cup�ration de la liste des Lignes de Commande de l'IC EFB
			LigneCde[] listeLC = icEFB.getStructureMetier().getCommande().getLigneCde();

			for (LigneCde lcEFB : listeLC) {
				if (listeValeursExterne.contains(lcEFB.getCodeOffrePSS())) {
					SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Commande non agreg�e et non CR_FTTH, l'IC contient au moins une offre de Prestation, validation OK");
					return true; // L'IC contient au moins une offre de Prestation
				}
			}
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, method, "La commande est agreg�e mais ne poss�de aucune offre de Prestation");
			return false; // L'IC ne contient aucune offre de Prestation
		}

		SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Commande non agreg�e ou non CR_FTTH, validation OK");
		return true; // On ignore les commandes non-agreg�es ou ayant un cas m�tier autre que CR_FTTH
	}

	/**
	 * M�thode permettant le rejet des commandes PLPA sans date de livraison
	 * 
	 * @param icEfb l'ic de la commande venant d'EFB
	 * @return true si la commande est valide, false sinon
	 */
	public static boolean validateCommandePlpaSansDateLivraison(CommandeEfb icEfb) {
		// R�cup�ration de l'�tat ligne
		// On prend le premier valoris� (s'il existe)
		String etatLigne = "";
		LigneCde[] lignesCde = icEfb.getStructureMetier().getCommande().getLigneCde();
		for (LigneCde ligneCde : lignesCde) {
			if (ligneCde.getPartageRessTechniques() != null) {
				String tmp = ligneCde.getPartageRessTechniques().getEtatLigne();
				if (!StringUtils.isBlank(tmp)) {
					etatLigne = tmp;
					break;
				}
			}
		}

		// EtatLigne non valoris�, il ne s'agit pas d'une commande PLPA
		if (StringUtils.isBlank(etatLigne)) {
			return true;
		}

		String traduction = SERVICE_MANAGER.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_SOUHAITEECLIENT_ETATLIGNE, etatLigne);

		// Traduction non trouv�, il ne s'agit pas d'une commande PLPA
		if (StringUtils.isBlank(traduction)) {
			return true;
		}

		// Il s'agit forc�ment d'une commande PLPA
		// On v�rifie qu'au moins une LC contient une DateMESSouhaiteeLC valide
		if (validateDate(icEfb, EFBConstantes.SOUHAITEE_CLIENT)) {
			return true;
		}

		// Pas de DateMESSouhaiteeLC valide trouv�e
		// Commande PLPA non valide
		return false;
	}

	/**
	 * M�thode permettant le rejet des commandes de d�m�nagement sans date de livraison
	 * 
	 * @param icEfb l'ic de la commande venant d'EFB
	 * @param commandeAgregee le bool�en d�crivant s'il s'agit d'une commande agr�g�e
	 * @return true si la commande est valide, false sinon
	 */
	public static boolean validateCommandeDemenagementSansDateLivraison(CommandeEfb icEfb, boolean commandeAgregee) {
		// Les commandes qui nous int�ressent sont agr�g�es, les autres sont ignor�es
		if (!commandeAgregee) {
			return true;
		}

		Commande commandeEfb = icEfb.getStructureMetier().getCommande();

		// R�cup�ration de la typologie d�m�nagement
		String typoDemenagement = "";

		for (int i = 0; i < commandeEfb.getSpecificiteCommandeCount(); i++) {
			SpecificiteCommande specificiteCommande = commandeEfb.getSpecificiteCommande(i);
			if (specificiteCommande != null && EFBConstantes.TYPE_DEMGT.equalsIgnoreCase(specificiteCommande.getTypeCritere())) {
				typoDemenagement = specificiteCommande.getValCritereEnum();
				break;
			}
		}

		// TypoDemenagement non valoris�, on ignore la commande
		if (StringUtils.isBlank(typoDemenagement)) {
			return true;
		}

		String traduction = SERVICE_MANAGER.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_SOUHAITEECLIENT_TYPODEM, typoDemenagement);

		// Traduction non trouv�, on ignore la commande
		if (StringUtils.isBlank(traduction)) {
			return true;
		}

		// Il s'agit forc�ment d'une commande PLPA
		// On v�rifie qu'au moins une LC contient une DateMESSouhaiteeLC valide
		if (validateDate(icEfb, EFBConstantes.SOUHAITEE_CLIENT)) {
			return true;
		}

		// Pas de DateMESSouhaiteeLC valide trouv�e
		// Commande non valide
		return false;
	}

	/**
	 * M�thode permettant le rejet des commandes de d�m�nagement sans date de livraison ancienne adresse
	 * 
	 * @param icEfb l'ic de la commande venant d'EFB
	 * @param commandeAgregee le bool�en d�crivant s'il s'agit d'une commande agr�g�e
	 * @return true si la commande est valide, false sinon
	 */
	public static boolean validateCommandeDemenagementSansDateLivraisonAncienneAdresse(CommandeEfb icEfb, boolean commandeAgregee) {
		// Les commandes qui nous int�ressent sont agr�g�es, les autres sont ignor�es
		if (!commandeAgregee) {
			return true;
		}

		Commande commandeEfb = icEfb.getStructureMetier().getCommande();

		// R�cup�ration de la typologie d�m�nagement
		String typoDemenagement = "";

		for (int i = 0; i < commandeEfb.getSpecificiteCommandeCount(); i++) {
			SpecificiteCommande specificiteCommande = commandeEfb.getSpecificiteCommande(i);
			if (specificiteCommande != null && EFBConstantes.TYPE_DEMGT.equalsIgnoreCase(specificiteCommande.getTypeCritere())) {
				typoDemenagement = specificiteCommande.getValCritereEnum();
				break;
			}
		}

		// TypoDemenagement non valoris�, on ignore la commande
		if (StringUtils.isBlank(typoDemenagement)) {
			return true;
		}

		String traduction = SERVICE_MANAGER.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_DATEDESIRERESILANCIENNEBL_TYPOEDEM, typoDemenagement);

		// Traduction non trouv�, on ignore la commande
		if (StringUtils.isBlank(traduction)) {
			return true;
		}

		// Il s'agit forc�ment d'une commande PLPA
		// On v�rifie qu'au moins une LC contient une DateDesireResilAncienneBL valide
		if (validateDate(icEfb, EFBConstantes.DATE_DESIRE_RESIL_ANCIENNE_BL)) {
			return true;
		}

		// Pas de DateMESSouhaiteeLC valide trouv�e
		// Commande non valide
		return false;
	}

	/**
	 * M�thode permettant de valider la typeDate pass� en param�tre pour la commande sp�cifi�e
	 * 
	 * @param icEfb la commande a v�rifier
	 * @param typeDate la date a v�rifier
	 * @return true si la date existe et est valide
	 */
	private static boolean validateDate(CommandeEfb icEfb, String typeDate) {
		// On v�rifie qu'au moins une LC contient une date "typeDate" valide
		LigneCde[] lignesCde = icEfb.getStructureMetier().getCommande().getLigneCde();
		for (LigneCde ligneCde : lignesCde) {
			String dateStr = AdaptationUtil.getDate(ligneCde, typeDate);
			if (!StringUtils.isBlank(dateStr)) {
				try {
					DateUtils.parseDate(dateStr, EFBConstantes.FORMAT_DATE_HEURE);

					// Date valide
					return true;
				} catch (ParseException l_exc) {
					// Date non valide, on v�rifie la suivante
				}
			}
		}

		return false;
	}

	/**
	 * M�thode pour valider que les commandes de modification de portabilit� FTTH ont bien un ND en service
	 * 
	 * @param icEFB l'IC EFB
	 * @return false si la commande est de la modification de portabilit� FTTH et qu'elle n'a pas de ND en service
	 */
	public static boolean validateCommandeModifPortaFTTHAvecNDEnService(CommandeEfb icEFB) {
		for (LigneCde lcEFB : icEFB.getStructureMetier().getCommande().getLigneCde()) {
			String valeurExterne = lcEFB.getRefOpCommercialeLPA() + "|" + lcEFB.getCodeOffrePSS();
			String valeurArtemis = SERVICE_MANAGER.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_NDEDP_OBLIGATOIRE, valeurExterne);

			if (ConstantesTraduction.OUI.equals(valeurArtemis)) {
				String valeurFonctionNDEdP = SERVICE_MANAGER.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_NDEDP, ConstantesTraduction.REF_FONCTION_ND_EDP);

				if (valeurFonctionNDEdP != null) {
					boolean valid = false;

					int nbValeurFonctionEdp = lcEFB.getEltParcImpacteLC().getValeurFonctionEdPCount();
					for (int i = 0; i < nbValeurFonctionEdp; i++) {
						ValeurFonctionEdP valeurFonctionEdp = lcEFB.getEltParcImpacteLC().getValeurFonctionEdP(i);
						if (valeurFonctionNDEdP.equals(valeurFonctionEdp.getRefFonctionEdP())) {
							valid = true;
							break;
						}
					}

					if (!valid) {
						return false;
					}
				}
			}
		}

		return true;
	}

}