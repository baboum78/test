/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic48w.util;

import java.io.Serializable;
import java.text.MessageFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.tuple.Pair;

import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.anomalies.SFAno;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.model.ParametresDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamic;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.TraductionManager;

import aps.SystemeExterneConstantes;
import aps.TypeOpProgrammeeConstantes;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.ElementParcAffecte;
import bolbec.injection.xml.generated.InstanceOffreGroupee;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.Message;
import bolbec.injection.xml.generated.OperationProgrammee;
import bolbec.injection.xml.generated.ParametreType;
import bolbec.injection.xml.generated.ProduitServiceSouhaite;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/12/2010</TD><TD>LBA</TD><TD>CAST: suppression classe deprecated GestionAnomalie et ajout accolades pour blocs avec instruction seule</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>14/04/2011</TD><TD>CCL</TD><TD>BOLBEC-1236 Optimisation de l'utilisation des HashMap</TD></TR>
 * <TR><TD>24/05/2018</TD><TD>AJO</TD><TD>QC-1010 Avancement MESC FT : commandes regroup�es</TD></TR>
 * </TABLE><BR>
 */

/**
 * 
 * Classe de gestion de l'adaptation de l'intention de commande PDC au format
 * IC_Artemis
 */
public class AdaptationUtil {

	/** Nom de la classe */
	private static final String CLASS_NAME = AdaptationUtil.class.getName();

	private static final String FORMAT_DATE = EFBConstantes.FORMAT_DATE;
	private static final String FORMAT_DATE_HEURE = EFBConstantes.FORMAT_DATE_HEURE;
	private static final String OBSERVATIONS_SEP = ";";

	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * Adaptation de l'intention de commande PDC au format IC_Artemis
	 * 
	 * @param msg_result
	 * @return Serializable
	 */
	public static Message adapt(Message msg_result) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "adapt", "D�but de l'adaptation IC48W");
		// R�cup�ration du message, de la commande et des lignes de commande
		// aussi bien en suppression qu'en cr�ation
		msg_result.setIdEmetteur(SystemeExterneConstantes.NUM_48W);
		Commande l_cde = msg_result.getCommande();
		LigneCommandeType[] tab_ligneCommandeSupp = l_cde.getLigneCommande();
		InstanceOffreGroupee[] tab_instOffGrp = l_cde.getInstanceOffreGroupee();
		// QC-1010
		String observations = l_cde.getIntervention(0).getObservations();
		Pair<String, String> obsAndCodeOi = recuperationCodeOI(observations);
		Pair<String, String> obsAnddateAcCmd = recuperationDateAcceptationCommandeOI(obsAndCodeOi.getLeft());
		l_cde.getIntervention(0).setObservations(obsAnddateAcCmd.getLeft());
		// Adaptation lignes de commande en suppression
		List<LigneCommandeType> lst_lignesCdeSuppSubstitute = new ArrayList<LigneCommandeType>();
		for (int i = 0; i < tab_ligneCommandeSupp.length; i++) {
			LigneCommandeType ligneCommandeSupp = tab_ligneCommandeSupp[i];
			// Ref. Offre existante de l'Element de Parc affect�
			String refOffre = ligneCommandeSupp.getElementParcAffecte().getRefOffreExistante();
			// RG0 : Traduction de chaque offre concat�n�e en plusieurs offres
			// �l�mentaires
			// M�morisation de l'ensemble des lignes de commande avant
			// substitution � celles existantes en cours de lecture (�vite les
			// ConcurrentModificationException)
			lst_lignesCdeSuppSubstitute.addAll(traductionOffre(refOffre, ligneCommandeSupp, obsAndCodeOi.getRight(), obsAnddateAcCmd.getRight()));
		}
		// Substitutions avec les nouvelles lignes de commande
		l_cde.clearLigneCommande();
		l_cde.setLigneCommande(lst_lignesCdeSuppSubstitute.toArray(new LigneCommandeType[lst_lignesCdeSuppSubstitute.size()]));
		// Adaptation lignes de commande en cr�ation
		for (int i = 0; i < tab_instOffGrp.length; i++) {
			InstanceOffreGroupee instOffGrp = tab_instOffGrp[i];
			LigneCommandeType[] tab_ligneCommandeCreate = instOffGrp.getLigneCommande();
			List<LigneCommandeType> lst_lignesCdeCreateSubstitute = new ArrayList<LigneCommandeType>();
			for (int j = 0; j < tab_ligneCommandeCreate.length; j++) {
				LigneCommandeType ligneCommandeCreate = tab_ligneCommandeCreate[j];
				// Ref. Offre cible du Produit Service Souhait�
				String refOffre = ligneCommandeCreate.getProduitServiceSouhaite().getRefOffreCible();
				// RG0 : Traduction de chaque offre concat�n�e en plusieurs
				// offres �l�mentaires
				// M�morisation de l'ensemble des lignes de commande avant
				// substitution � celles existantes en cours de lecture (�vite
				// les ConcurrentModificationException)
				lst_lignesCdeCreateSubstitute.addAll(traductionOffre(refOffre, ligneCommandeCreate, obsAndCodeOi.getRight(), obsAnddateAcCmd.getRight()));
			}
			// Substitutions avec les nouvelles lignes de commande
			instOffGrp.clearLigneCommande();
			instOffGrp.setLigneCommande(lst_lignesCdeCreateSubstitute.toArray(new LigneCommandeType[lst_lignesCdeCreateSubstitute.size()]));
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "adapt", "Fin de l'adaptation IC48W ");
		return msg_result;
	}

	/**
	 * <i>RG0 </i>: Traduit l'offre en plusieurs offres �l�mentaires par appel
	 * du TG "Traduction Offre Concat-Diff"
	 * 
	 * @param refOffre
	 * @param ligneCommande
	 * @param opImmeubleValue
	 * @param dateAcceptationCmdValue
	 * @return List
	 */
	private static List<LigneCommandeType> traductionOffre(String refOffre, LigneCommandeType ligneCommande, String opImmeubleValue, String dateAcceptationCmdValue) {
		Map<String, List<ValeurParametreDTO>> hmp_OffreArtemis = TraductionManager.getInstance().getTraductionOffreConcatDiff(refOffre, SystemeExterneConstantes.NUM_48W);
		if ((hmp_OffreArtemis != null) && !hmp_OffreArtemis.isEmpty()) {
			List<LigneCommandeType> lst_ligneCdeSubstitute = new ArrayList<LigneCommandeType>(hmp_OffreArtemis.size());
			Iterator<Entry<String, List<ValeurParametreDTO>>> l_iterator = hmp_OffreArtemis.entrySet().iterator();
			while (l_iterator.hasNext()) {
				Entry<String, List<ValeurParametreDTO>> entry = l_iterator.next();
				String l_keyOffre = entry.getKey();
				List<ValeurParametreDTO> l_listeValeurParametre = entry.getValue();
				// Nouvelle ligne de commande par offre �l�mentaire avec recopie
				// des donn�es de l'offre traduite
				LigneCommandeType lgCde = new LigneCommandeType();
				lgCde.setIdLigneCommande(ligneCommande.getIdLigneCommande());
				lgCde.setEtatLigneCommande(ligneCommande.getEtatLigneCommande());
				lgCde.setInduiteParLigne(ligneCommande.getInduiteParLigne());
				lgCde.setDateContractuelle(ligneCommande.getDateContractuelle());
				lgCde.setDateSouhaitee(ligneCommande.getDateSouhaitee());
				lgCde.setQuantite(ligneCommande.getQuantite());
				lgCde.setJalon(ligneCommande.getJalon());
				lgCde.setRefOperationPonctuelle(ligneCommande.getRefOperationPonctuelle());
				lgCde.setCodeFacturationOffre(ligneCommande.getCodeFacturationOffre());
				lgCde.setMontantLigne(ligneCommande.getMontantLigne());
				lgCde.setCodeFacturationRemise(ligneCommande.getCodeFacturationRemise());
				lgCde.setMontantRemise(ligneCommande.getMontantRemise());
				lgCde.setTypeTVA(ligneCommande.getTypeTVA());
				lgCde.setRefContexteLivraison(ligneCommande.getRefContexteLivraison());
				lgCde.setElementParcAffecte(getEltParcAffecteClone(ligneCommande.getElementParcAffecte(), refOffre, l_listeValeurParametre));
				lgCde.setParametreLivraison(ligneCommande.getParametreLivraison());
				// RG3 : Sauvegarde de l'OpPonct. d'origine
				ArrayList<ParametreType> liste_paramLiv = new ArrayList<ParametreType>();
				ParametreType opPonctuelOrig = new ParametreType();
				ParametreType opImmeuble = new ParametreType();
				ParametreType dateAcceptationCmd = new ParametreType();
				// Sauvegarde de la cl� et valeur d'OpPonct d'origine
				opPonctuelOrig.setCle(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OSIRIS_OPPONCTORIG);
				opPonctuelOrig.setValeur(ligneCommande.getRefOperationPonctuelle());
				liste_paramLiv.add(opPonctuelOrig);
				// Sauvegarde de la cl� et valeur de l'Operateur Immeuble
				opImmeuble.setCle(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE);
				opImmeuble.setValeur(opImmeubleValue);
				liste_paramLiv.add(opImmeuble);
				// Sauvegarde de la cl� et valeur de la dateAcceptationCommande
				dateAcceptationCmd.setCle(ConstantesDynamicLigneCommande.CLE_DATE_DEBUT_ACCEPTATION_CMD_ACCES);
				dateAcceptationCmd.setValeur(dateAcceptationCmdValue);
				liste_paramLiv.add(dateAcceptationCmd);
				for (ParametreType pT : liste_paramLiv) {
					lgCde.addParametreLivraison(pT);
				}
				lgCde.setClientLivre(ligneCommande.getClientLivre());
				lgCde.setProduitServiceSouhaite(getProduitSSClone(ligneCommande.getProduitServiceSouhaite()));
				OperationProgrammee[] lstOpProgrammees = ligneCommande.getOperationProgrammee();
				for (OperationProgrammee opProgramme: lstOpProgrammees) {
					opProgramme.setTypeOp(TypeOpProgrammeeConstantes.CLIENT);
				}
				lgCde.setOperationProgrammee(lstOpProgrammees);
				if (ligneCommande.getElementParcAffecte() != null) {
					lgCde.setAccesLivraison(ligneCommande.getElementParcAffecte().getIdAccesClient());
				} else if (ligneCommande.getProduitServiceSouhaite() != null) {
					lgCde.setAccesLivraison(ligneCommande.getProduitServiceSouhaite().getIdAccesClient());
				}
				lgCde.setAccesLivraisonOrigine(ligneCommande.getAccesLivraisonOrigine());
				lgCde.setTypeAccesLivraison(Constantes.ND);
				lgCde.setTypeAccesLivraisonOrigine(ligneCommande.getTypeAccesLivraisonOrigine());
				// Valorisations avec l'offre �l�mentaire
				if (lgCde.getElementParcAffecte() != null) {
					lgCde.getElementParcAffecte().setRefOffreExistante(l_keyOffre);
				}
				if (lgCde.getProduitServiceSouhaite() != null) {
					lgCde.getProduitServiceSouhaite().setRefOffreCible(l_keyOffre);
				}
				// Suppressions de la r�f. d�tention existante et d�tention
				// produit service
				if (lgCde.getElementParcAffecte() != null) {
					lgCde.getElementParcAffecte().setRefDetentionExistante(null);
				}
				if (lgCde.getProduitServiceSouhaite() != null) {
					lgCde.getProduitServiceSouhaite().setDetentionProduitService(null);
					// RG1 : Valorisations Parametre Produit Service
					lgCde.getProduitServiceSouhaite().clearParametreProduitService();
					valorisationParametre(l_listeValeurParametre, lgCde.getProduitServiceSouhaite(), refOffre);
				}
				lst_ligneCdeSubstitute.add(lgCde);
			}
			return lst_ligneCdeSubstitute;
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "traductionOffre", "Probl�me de traduction de l'offre r�f�rence " + refOffre);
		throw serviceManager.getAnomalieManager().newAnomalieException(CLASS_NAME, SFAno.ERREUR_TRADUCTION, SFAno.TYPE_AV, "Anomalie traduction offre : r�f�rence offre '" + refOffre + "'");
	}

	/**
	 * <i>RG1 ou RG2</i>: Valorisation des ParametreProduitService pour un
	 * produit service souhait� ou des ParametreElementParc pour un �l�ment de
	 * parc
	 * 
	 * @param a_listeValeurParametre
	 * @param obj
	 * ParametreProduitService ou ParametreElementParc
	 * @param refOffre
	 */
	private static void valorisationParametre(List<ValeurParametreDTO> a_listeValeurParametre, Serializable obj, String refOffre) {
		if (!a_listeValeurParametre.isEmpty()) {
			for (ValeurParametreDTO valeurParametreDTO : a_listeValeurParametre) {
				String l_valeurParametre = valeurParametreDTO.getValeur();
				ParametresDTO parametresDTO = valeurParametreDTO.getParametres();
				String l_codeParametre = parametresDTO.getCode();
				if (l_codeParametre != null) {
					String l_codeParametrePrefixe = ConstantesDynamic.PREFIX_PARAM_DETENTION + l_codeParametre;
					ParametreType l_param = new ParametreType();
					l_param.setCle(l_codeParametrePrefixe);
					l_param.setValeur(l_valeurParametre);
					if (obj instanceof ProduitServiceSouhaite) {
						((ProduitServiceSouhaite) obj).addParametreProduitService(l_param);
					} else if (obj instanceof ElementParcAffecte) {
						((ElementParcAffecte) obj).addParametreElementParc(l_param);
					}
				}
			}
		}
		// Traitement de l'ID de l'offre d'origine
		ParametreType l_param = new ParametreType();
		l_param.setCle(ConstantesDynamicPSSouhaite.PSSOUHAITE_OSIRIS_IDOFFREORIG);
		l_param.setValeur(refOffre);
		if (obj instanceof ProduitServiceSouhaite) {
			((ProduitServiceSouhaite) obj).addParametreProduitService(l_param);
		} else if (obj instanceof ElementParcAffecte) {
			((ElementParcAffecte) obj).addParametreElementParc(l_param);
		}
	}

	/**
	 * Retourne un clone de l'ElementParcAffecte (les objets du package
	 * "bolbec.injection.xml.generated" �tant g�n�r�s et non clonables)
	 * 
	 * @param eltParcAffecte
	 * @param refOffre
	 * @param a_listeValeurParametre
	 * @return ElementParcAffecte
	 */
	private static ElementParcAffecte getEltParcAffecteClone(ElementParcAffecte eltParcAffecte, String refOffre, List<ValeurParametreDTO> a_listeValeurParametre) {
		if (eltParcAffecte != null) {
			ElementParcAffecte result = new ElementParcAffecte();
			result.setIdEPC(eltParcAffecte.getIdEPC());
			result.setIdAccesClient(eltParcAffecte.getIdAccesClient());
			result.setRefOffreExistante(eltParcAffecte.getRefOffreExistante());
			// champ non mapp�
			result.setRefDetentionExistante(null);
			result.setIdClientContractant(eltParcAffecte.getIdClientContractant());
			// RG2 : Valorisation des ParametreElementParc
			valorisationParametre(a_listeValeurParametre, result, refOffre);
			return result;
		}
		return null;
	}

	/**
	 * Retourne un clone de ProduitServiceSouhaite
	 * 
	 * ATTENTION : pas de clonage en profondeur Si un objet du package
	 * "bolbec.injection.xml.generated" dans le ProduitServiceSouhaite doit
	 * �tre modifi�, il doit �tre instanci� et clon� et non pas simplement
	 * affect� (les objets du package "bolbec.injection.xml.generated" �tant
	 * g�n�r�s et non clonables)
	 * 
	 * @param produitSS
	 * @return ProduitServiceSouhaite
	 */
	private static ProduitServiceSouhaite getProduitSSClone(ProduitServiceSouhaite produitSS) {
		if (produitSS != null) {
			ProduitServiceSouhaite result = new ProduitServiceSouhaite();
			result.setIdEPCFutur(produitSS.getIdEPCFutur());
			result.setRefOffreCible(produitSS.getRefOffreCible());
			result.setIdAccesClient(produitSS.getIdAccesClient());
			result.setIdElementParcSupport(produitSS.getIdElementParcSupport());
			result.setRefDescriptionProduitService(produitSS.getRefDescriptionProduitService());
			// champ non mapp�
			result.setDetentionProduitService(null);
			result.setParametreProduitService(produitSS.getParametreProduitService());
			result.setParametreContextuel(produitSS.getParametreContextuel());
			result.setDiagnosticFaisabilite(produitSS.getDiagnosticFaisabilite());
			return result;
		}
		return null;
	}

	private static Pair<String, String> recuperationCodeOI(String observations) {
		final String method = "recuperationCodeOI";

		String codeOI = null;
		String suffixe = StringUtils.EMPTY;
		MessageFormat mfObsSep = new MessageFormat("{0}" + OBSERVATIONS_SEP + "{1}");
		MessageFormat mfObsOi = new MessageFormat("{0}" + ConstantesDynamicLigneCommande.LIGNECOMMANDE_OPERATEUR_IMMEUBLE + "1={1}");

		try {
			// R�cup�ration du code OI (+ la fin des observations)
			codeOI = (String) mfObsOi.parse(observations)[1];

			// On s'arr�te au premier point virgule rencontr� (si il y en a un)
			try {
				codeOI = (String) mfObsSep.parse(codeOI)[0];
				suffixe = "; ";
			} catch (ParseException e) {
				// Il s'agit du dernier �l�ment des observations, pas de point virgule
			}

			observations = observations.replace(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OPERATEUR_IMMEUBLE + "1=" + codeOI + suffixe, StringUtils.EMPTY);
		} catch (ParseException e) {
			ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, method, "Code OI non pr�sent dans les observations");
		}

		return Pair.of(observations, codeOI);
	}

	private static Pair<String, String> recuperationDateAcceptationCommandeOI(String observations) {
		final String method = "recuperationDateAcceptationCommandeOI";

		String dateAcCo = null;
		String suffixe = StringUtils.EMPTY;
		MessageFormat mfObsSep = new MessageFormat("{0}" + OBSERVATIONS_SEP + "{1}");
		MessageFormat mfObsDateAcCo = new MessageFormat("{0}" + ConstantesDynamicLigneCommande.LIGNECOMMANDE_DATE_ACCEPTATION_CMDE + "1={1}");

		try {
			// R�cup�ration de la date d'acception commande (+ la fin des observations)
			dateAcCo = (String) mfObsDateAcCo.parse(observations)[1];

			// On s'arr�te au premier point virgule rencontr� (si il y en a un)
			try {
				dateAcCo = (String) mfObsSep.parse(dateAcCo)[0];
				suffixe = "; ";
			} catch (ParseException e) {
				// Il s'agit du dernier �l�ment des observations, pas de point virgule
			}

			observations = observations.replace(ConstantesDynamicLigneCommande.LIGNECOMMANDE_DATE_ACCEPTATION_CMDE + "1=" + dateAcCo + suffixe, StringUtils.EMPTY);
			dateAcCo = DateUtils.changeFormatDate(dateAcCo, FORMAT_DATE, FORMAT_DATE_HEURE);
		} catch (ParseException e) {
			ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, method, "Date acceptation commande non pr�sente dans les observations");
		}

		return Pair.of(observations, dateAcCo);
	}
}