/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.commande;

import java.util.Date;

import javax.ejb.EJBLocalObject;

import com.soliste.bolbec.commun.service.util.pagination.PaginatedList;
import com.soliste.bolbec.commun.service.util.pagination.PaginationCommand;
import com.soliste.bolbec.livraison.service.ejb.sb.commande.data.CommandeSearchResultDTO;
import com.soliste.bolbec.livraison.service.util.sort.CommandeSortCommand;

/**
 * Interface de l'EJB session CommandeSearchManager. Permet de rechercher des
 * commandes
 * 
 * @author rgvs7490
 */
public interface CommandeSearchManager extends EJBLocalObject {

	/**
	 * Recherche les commandes par client contractant. Le nom, ou le pr�nom, ou
	 * les deux doivent �tre fournis. Si les deux sont fournis, un ET logique
	 * est r�alis�. Le nom et le pr�nom sont compar�s avec ceux stock�s en base
	 * en ignorant la casse. une sous-cha�ne du pr�nom et du nom peuvent �tre
	 * pass�es (un like %valeur% est r�alis�)
	 * 
	 * @param nom
	 * le nom du client contractant, ou une partie de ce nom (ou null
	 * si on veut rechercher uniquement par pr�nom)
	 * @param prenom
	 * le pr�nom du client contractant, ou une partie de ce pr�nom
	 * (ou null si on veut rechercher uniquement par nom)
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByClientContractant(String nom, String prenom, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par client livr�. Le nom, ou le pr�nom, ou les
	 * deux doivent �tre fournis. Si les deux sont fournis, un ET logique est
	 * r�alis�. Le nom et le pr�nom sont compar�s avec ceux stock�s en base en
	 * ignorant la casse. une sous-cha�ne du pr�nom et du nom peuvent �tre
	 * pass�es (un like %valeur% est r�alis�)
	 * 
	 * @param nom
	 * le nom du client livr�, ou une partie de ce nom (ou null si on
	 * veut rechercher uniquement par pr�nom)
	 * @param prenom
	 * le pr�nom du client livr�, ou une partie de ce pr�nom (ou null
	 * si on veut rechercher uniquement par nom)
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByClientLivre(String nom, String prenom, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par date de cr�ation. Les deux dates doivent �tre
	 * fournies.
	 * 
	 * @param dateDebut
	 * la date minimale de cr�ation
	 * @param dateFin
	 * la date maximale de cr�ation
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByDateCreation(Date dateDebut, Date dateFin, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par identifiant. La recherche est effectu�e sur
	 * l'identifiant complet, en ignorant la casse
	 * 
	 * @param id
	 * l'identifiant
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchById(String id, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par ND. La recherche est effectu�e sur le ND
	 * complet
	 * 
	 * @param nd
	 * le ND
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByNd(String nd, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par Acces Livraison o� le type est ND. La
	 * recherche est effectu�e sur le ND complet
	 * 
	 * @param ndAccesLivraison
	 * le ND
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByNdAccesLivraison(String ndAccesLivraison, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par NDPLP. La recherche est effectu�e sur le
	 * NDPLP complet
	 * 
	 * @param ndplp
	 * le NDPLP
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByNdplp(String ndplp, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par r�f�rence externe. La recherche est effectu�e
	 * sur la r�f�rence compl�te, en ignorant la casse
	 * 
	 * @param refExterne
	 * la r�f�rence externe
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByRefExterne(String refExterne, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par r�f�rence d'�tude NA. La recherche est
	 * effectu�e sur la r�f�rence compl�te
	 * 
	 * @param refNa
	 * le r�f�rence d'�tude NA
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchByRefNa(String refNa, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par r�f�rence d'intervention. La recherche est
	 * effectu�e sur la r�f�rence compl�te
	 * 
	 * @param refIntervention
	 * le r�f�rence d'intervention
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByRefIntervention(String refIntervention, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par Siren et/ou Nic. Le Siren, ou le Nic, ou les
	 * deux doivent �tre fournis. Si les deux sont fournis, un ET logique est
	 * r�alis�.
	 * 
	 * @param siren
	 * le Siren complet du client contractant (ou null si on veut
	 * rechercher uniquement par Nic)
	 * @param nic
	 * le Nic complet du client contractant (ou null si on veut
	 * rechercher uniquement par Siren)
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	PaginatedList<CommandeSearchResultDTO> searchBySirenAndNic(String siren, String nic, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par id VIA.
	 * 
	 * @param epcIdVIA
	 * le r�f�rence d'intervention
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByEpcIdVIA(String epcIdVIA, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par Num�ro CLIP.
	 * 
	 * @param numeroCLIP
	 * le num�ro CLIP
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByNumeroCLIP(String numeroCLIP, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);

	/**
	 * Recherche les commandes par r�f�rence traitement en masse
	 * 
	 * @param referenceTraitementEnMasse
	 * @param commandesNonTerminees
	 * @param paginationCommand
	 * @param sortCommand
	 * @return
	 */
	PaginatedList<CommandeSearchResultDTO> searchByReferenceTraitementEnMasse(String referenceTraitementEnMasse, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand);


	/**
	 * Compl�ment de la recherche pour compl�ter avec les informations de dynamic commande
	 *
	 * @param commandeId
	 * l'identifiant de la commande r�cup�r� en amont.
	 * @param dynamicCommande
	 * la dynamique commande
	 * @return la valeur de la dynamic commande
	 */
	String searchComplementDynamicCommande(String commandeId, String dynamicCommande);

}