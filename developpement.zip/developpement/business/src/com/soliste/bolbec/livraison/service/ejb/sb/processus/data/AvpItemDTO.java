/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;

/**
 * Classe contenant les donn�es n�cessaires pour pouvoir manipuler un AVP
 * 
 * @author rgvs7490
 */
public class AvpItemDTO implements Serializable {

	/**
	 * Le type des �l�ments de type AVP. (1)
	 */
	public static final int AVP_TYPE = 1;

	/**
	 * Le type des �l�ments de type t�che manuelle. (2)
	 */
	public static final int TACHE_MANUELLE_TYPE = 2;

	/**
	 * Le type des �l�ments de type r�gularisation manuelle. (6)
	 */
	public static final int REGULARISATION_MANUELLE_TYPE = 6;

	/**
	 * Le type des �l�ments de type abandon manuel. (7)
	 */
	public static final int ABANDON_MANUEL_TYPE = 7;

	/**
	 * Le type des �l�ments de type t�che manuelle. (2)
	 */
	public static final int TACHE_ADHOC_TYPE = 4;

	/**
	 * Le type des �l�ments de type t�che manuelle. (2)
	 */
	public static final int PHASE_TYPE = 5;

	private String tacheId;
	private String papaProcessusId;
	private ItemData itemData;
	private int type;

	/**
	 * Constructeur
	 * 
	 * @param tacheId l'identifiant bolbec de la t�che correspondant � l'AVP
	 * dont les informations workflow se trouvent dans wfActivity
	 * @param papaProcessusId l'identifiant du PapaProcessus de la t�che
	 * @param itemData les donn�es workflow de l'AVP
	 * @param type le type (AVP ou Tache manuelle)
	 */
	public AvpItemDTO(String tacheId, String papaProcessusId, ItemData itemData, int type) {
		this.tacheId = tacheId;
		this.papaProcessusId = papaProcessusId;
		this.itemData = itemData;
		if ((type != AVP_TYPE) && (type != TACHE_MANUELLE_TYPE) && (type != REGULARISATION_MANUELLE_TYPE) && (type != ABANDON_MANUEL_TYPE) && (type != TACHE_ADHOC_TYPE) && (type != PHASE_TYPE)) {
			throw new IllegalArgumentException("Le type doit �tre AVP_TYPE ou TACHE_MANUELLE_TYPE ou REGULARISATION_MANUELLE_TYPE ou ABANDON_MANUEL_TYPE ou TACHE_ADHOC_TYPE ou PHASE_TYPE");
		}
		this.type = type;
	}

	/**
	 * Retourne l'identifiant bolbec de la t�che correspondant � l'AVP
	 * dont les informations workflow se trouvent dans wfActivity
	 * 
	 * @return l'identifiant bolbec de la t�che correspondant � l'AVP
	 * dont les informations workflow se trouvent dans wfActivity
	 */
	public String getPapaProcessusId() {
		return this.papaProcessusId;
	}

	/**
	 * Retourne l'identifiant du PapaProcessus de la t�che
	 * 
	 * @return l'identifiant du PapaProcessus de la t�che
	 */
	public String getTacheId() {
		return this.tacheId;
	}

	/**
	 * Retourne les informations m�tier de l'AVP
	 * 
	 * @return les informations m�tier de l'AVP
	 */
	public ItemData getItemData() {
		return this.itemData;
	}

	/**
	 * Retourne le type d'Item (AVP ou tache manuelle)
	 * 
	 * @return le type d'Item (AVP ou tache manuelle)
	 */
	public int getType() {
		return this.type;
	}
}
