/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.exception;

/**
 * Exception indiquant qu'une r�gularisation manuelle n'a pu �tre abandonn�e
 * 
 * @author La�titia FABRE
 */
public class AbandonnerRegulManException extends Exception {

	/**
	 * Indique si le message est une cl� devant servir � l'internationalisation
	 * d'un message <br/> Valeur : true si c'est une cl�, false si c'est un
	 * message � traiter tel quel
	 */
	private boolean ressourceBundleKey;

	/**
	 * @param message
	 * @param ressourceBundleKey
	 */
	public AbandonnerRegulManException(String message, boolean ressourceBundleKey) {
		super(message);
		setRessourceBundleKey(ressourceBundleKey);
	}

	/**
	 * @return boolean
	 */
	public boolean isRessourceBundleKey() {
		return ressourceBundleKey;
	}

	/**
	 * @param ressourceBundleKey
	 */
	public void setRessourceBundleKey(boolean ressourceBundleKey) {
		this.ressourceBundleKey = ressourceBundleKey;
	}
}
