/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.exception;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Exception indiquant qu'un processus ne peut �tre abandonn�, ou qu'il peut
 * l'�tre mais avec un avertissement
 * 
 * @author rgvs7490
 */
public class ControlerAbandonProcessusException extends Exception {

	private boolean warning;

	/**
	 * 
	 * @param message
	 * @param warning
	 */
	public ControlerAbandonProcessusException(String message, boolean warning) {
		super(message);
		this.warning = warning;
	}

	public boolean isWarning() {
		return this.warning;
	}
}
