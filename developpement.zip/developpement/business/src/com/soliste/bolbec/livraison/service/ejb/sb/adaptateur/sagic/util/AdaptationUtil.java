/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.SagicConstantes;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.DescGroupeOffresDTO;
import com.soliste.bolbec.livraison.service.model.DescOffreGroupeeDTO;
import com.soliste.bolbec.livraison.service.model.FamilleOffreComDTO;
import com.soliste.bolbec.livraison.service.model.FamilleOffreParcDTO;
import com.soliste.bolbec.livraison.service.model.GroupeOffresDTO;
import com.soliste.bolbec.livraison.service.model.InputDynamicCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.OffreOpProgDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.TraductionCatComDTO;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamic;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil;

import aps.AnomalieConstantes;
import aps.DescGroupeOffres;
import aps.DescOffreGroupee;
import aps.OffreOpProg;
import aps.ParametreArtemis;
import aps.ResponsabiliteConstantes;
import aps.SystemeExterneConstantes;
import aps.Traduction;
import aps.TraductionCatCom;
import aps.TypeOpPonctuellesConstantes;
import bolbec.adaptateur.sagic.xml.generated.CommandeSagic;
import bolbec.adaptateur.sagic.xml.generated.ComplementService;
import bolbec.adaptateur.sagic.xml.generated.IC;
import bolbec.adaptateur.sagic.xml.generated.types.ApplicConvDesa;
import bolbec.adaptateur.sagic.xml.generated.types.CodeAction;
import bolbec.adaptateur.sagic.xml.generated.types.CodeRegime;
import bolbec.adaptateur.sagic.xml.generated.types.ComplementServiceContexteEligibiliteDebitType;
import bolbec.adaptateur.sagic.xml.generated.types.LigneAssoc;
import bolbec.adaptateur.sagic.xml.generated.types.MaintienPort;
import bolbec.adaptateur.sagic.xml.generated.types.ModeAffectation;
import bolbec.adaptateur.sagic.xml.generated.types.NdActif;
import bolbec.adaptateur.sagic.xml.generated.types.PresConvDesa;
import bolbec.adaptateur.sagic.xml.generated.types.SiteParticulier;
import bolbec.adaptateur.sagic.xml.generated.types.StatutLigne;
import bolbec.adaptateur.sagic.xml.generated.types.SupportFO;
import bolbec.adaptateur.sagic.xml.generated.types.TypeDgrp;
import bolbec.adaptateur.sagic.xml.generated.types.TypePorta;
import bolbec.injection.xml.generated.Adresse;
import bolbec.injection.xml.generated.Annulation;
import bolbec.injection.xml.generated.ClientContractant;
import bolbec.injection.xml.generated.ClientLivre;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.Contact;
import bolbec.injection.xml.generated.ElementParcAffecte;
import bolbec.injection.xml.generated.InstanceOffreGroupee;
import bolbec.injection.xml.generated.Intervention;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.Message;
import bolbec.injection.xml.generated.OperationProgrammee;
import bolbec.injection.xml.generated.ParametreType;
import bolbec.injection.xml.generated.ProduitServiceSouhaite;

/**
 * D�l�gu� pour l'adaptation des IC SAGIC
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>28/04/2010</TD><TD>PHC</TD><TD>EV-000051: Ajout du champ biInjection</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Ajout accolades autour d'instruction seule</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Refactor CAST : suppression classe deprecated GestionAnomalie</TD></TR>
 * <TR><TD>08/12/2010</TD><TD>LBA</TD><TD>Refactoring CAST : passage constante en premier dans assertion equals</TD></TR>
 * <TR><TD>21/12/2010</TD><TD>BPE</TD><TD>EV-000103: Modif acc�s HD avec maintien porta</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>14/04/2011</TD><TD>CCL</TD><TD>BOLBEC-1236 Optimisation de l'utilisation des HashMap</TD></TR>
 * <TR><TD>16/06/2011</TD><TD>BPE</TD><TD>EV-000157: CR 402 non envoy�e (dateRdvOp vide)</TD></TR>
 * <TR><TD>24/02/2012</TD><TD>BPE</TD><TD>Corrections mineures</TD></TR>
 * <TR><TD>20/03/2012</TD><TD>EBA</TD><TD>EV-189-Pas de cr�neaux disponibles (DM 10-270)</TD></TR>
 * <TR><TD>02/01/2013</TD><TD>FTE</TD><TD>EV-000215 - Mise � Disposition Des Paires de Cuivre</TD></TR>
 * <TR><TD>09/01/2013</TD><TD>FTE</TD><TD>EV-000211 - Impacts Automatisation de la livraison des constructions d'acc�s VG isol�s</TD></TR>
 * <TR><TD>11/03/2013</TD><TD>BPE</TD><TD>DE-000786 - Sagic LignAssoc="" rejet�</TD></TR>
 * <TR><TD>15/04/2013</TD><TD>VDE</TD><TD>EV-000232 - Enrichissement interface Pilpro</TD></TR>
 * <TR><TD>16/04/2013</TD><TD>VDE</TD><TD>DE_000325 "Modification renseignement etat intervention"</TD></TR>
 * <TR><TD>20/11/2013</TD><TD>FTE</TD><TD>G8R2C4 - EV-000270 : V�rification de la coh�rence des commandes PSG+ 1.1</TD></TR>
 * <TR><TD>06/01/2014</TD><TD>EBA</TD><TD>G8R2C4 - EV-000280 : Rejeter les commandes WholeSale pour lesquelles la ligne associ�e est incoh�rente avec le statut de ligne re�ue</TD></TR>
 * <TR><TD>10/02/2014</TD><TD>VDE</TD><TD>EV-000289 "Verification date IC Sagic"</TD></TR>
 * <TR><TD>28/04/2014</TD><TD>GCL</TD><TD>G8R2C4 - EV-000278 : G�re l'info decrivant le ND identifiant de Boucle Locale VGA. Nouvelle valeure de CodeAction : "RV"</TD></TR>
 * <TR><TD>15/02/2016</TD><TD>JDE</TD><TD>G9R1C1 - EV-000348_02 : Net commande unique - adaptateur SAGIC</TD></TR>
 * <TR><TD>26/04/2016</TD><TD>FCV</TD><TD>G9R1C2 - EV-345 : MAPLPA Wholesale</TD></TR>
 * <TR><TD>23/06/2016</TD><TD>FCV</TD><TD>G9R1C2 - EV-345 : MAPLPA Wholesale - correction Defects 767/768</TD></TR>
 * <TR><TD>20/01/2017</TD><TD>JDE</TD><TD>G9R1C2 - EV-000387 : DSLAO</TD></TR>
 * <TR><TD>03/04/2017</TD><TD>ARE</TD><TD>G9R2C1 - EV-000426 : d�saturation cuivre</TD></TR>
 * <TR><TD>15/12/2017</TD><TD>SMO</TD><TD>G9R2C1 - EV-467 : PLP HD</TD></TR>
 * <TR><TD>15/05/2018</TD><TD>HME</TD><TD>G9R2C1 - : FOP - Eligiblit� sur d�bit mesur�</TD></TR>
 * <TR><TD>16/10/2018</TD><TD>RMA</TD><TD>G9R7C1 - G9R7C1 - QC-1066 : RG 22, RG6, Cat�gorie du client livr� et contractant pour OBS
 * <TR><TD>18/10/2018</TD><TD>RMA</TD><TD>G9R7C1 - G9R7C1 - QC-1066 : Refactorisation pour lest tests unitaires</TD></TR>
 * <TR><TD>24/10/2018</TD><TD>RMA</TD><TD>G9R7C1 - G9R7C1 - QC-1066 : Valorisation d'Id Client pour OBS</TD></TR>
 * <TR><TD>27/03/2019</TD><TD>RRU</TD><TD>G9R7C8 - US-024 : Sc�nario pr�-config - Config Input Dynamic Commande</TD></TR>
 * <TR><TD>29/03/2019</TD><TD>HCS</TD><TD>US 170: Suppression du bimode d'appel au service 42C<TD></TD></TR>
 * <TR><TD>10/05/2019</TD><TD>RRU</TD><TD>US-028 : Sc�nario pr�-config - G�n�ralisation traitement inputdynamiccommande</TD></TR>
 * </TABLE>
 * 
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.4325</TD><TD>Func - EP0003 - Interroger eRDV pour obtenir la r�f�rence GPC</TD></TR>
 * <TR><TD>REQ.7310</TD><TD>Func � EP0185 � D�tecter les nouvelles commandes MADPC issues de SAGIC</TD></TR>
 * <TR><TD>REQ.7412</TD><TD>Func � EP0181 - Accepter les commandes de cr�ations d'acc�s VG issues de Sagic</TD></TR>
 * <TR><TD>REQ.10325</TD><TD>Func - EP0253 - Rejeter les commandes PSG+ ne permettant pas de d�terminer un cas m�tier dans Artemis</TD></TR>
 * <TR><TD>REQ.10346</TD><TD>Func � EP0263 - Rejeter les commandes WholeSale pour lesquelles la ligne associ�e est incoh�rente avec le statut de ligne re�ue</TD></TR>
 * <TR><TD>REQ.10398</TD><TD>Func � EP0268 - Accepter et stocker l'information issue de Sagic d�crivant le ND identifiant de Boucle Locale VGA</TD></TR>
 * <TR><TD>REQ.18020</TD><TD>Func - EP345_01 - Sagic peut envoyer des commandes dites de PLPA qui ont pour but de cr�er un acc�s Wholesale sur l'acc�s d'un pr�d�cesseur avant que celui-ci n'est r�sili� son acc�s</TD></TR>
 * <TR><TD>REQ.18021</TD><TD>Func - EP345_02 - Les commandes de PLPA WS sont identifi�es d�s la r�ception par un �tat ligne sp�cifique dans l'intention de commande</TD></TR>
 * <TR><TD>REQ.18025</TD><TD>Func - EP345_05 - Les commande de PLPA WS doivent comporter une date de r�alisation souhait�e qui permettra de temporiser la demande de r�siliation automatique du pr�d�cesseur</TD></TR>
 * <TR><TD>REQ.18029</TD><TD>Func - EP345_08 - Les commandes de PLPA WS de d�groupage total comportent les informations plot et r�glette qui sont les ressources � r�utiliser lors de la livraison de l'acc�s</TD></TR>
 * </TABLE>
 * 
 */
public class AdaptationUtil {

	/** The Constant CLASS_NAME. */
	private static final String CLASS_NAME = AdaptationUtil.class.getName();

	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	/** String STATUT_ND_DEST_I. */
	private static final String STATUT_ND_DEST_I = "I";

	/** String DATE_PATTERN_YY_MM. */
	private static final String DATE_PATTERN_YY_MM = "yyMM";

	/** long HOUR_IN_MILLIS. */
	private static final long HOUR_IN_MILLIS = 1000 * 60 * 60;

	/** String STRING_A. */
	private static final String STRING_A = "A";

	/** The Constant STRING_P. */
	private static final String STRING_P = "P";

	/** The Constant STRING_BLANK. */
	private static final String STRING_BLANK = "";

	/** The Constant STRING_NON. */
	private static final String STRING_NON = "NON";

	/** The Constant STRING_OUI. */
	private static final String STRING_OUI = "OUI";

	/** String STRING_MIDNIGHT. */
	private static final String STRING_MIDNIGHT = " 00:00:00";

	private static final String SEPARATEUR_CONCATENATION = "_";

	/** Memorisation de la date souhaitee pour que cette date soit identique � chaque ligne de commande d'une m�me commande. */
	private String dateSouhaitee;

	/** The Constant STRING_POR. */
	private static final String STRING_POR = "POR";

	// QC-1066 RG 22: For�age de la cat�gorie du client livr�
	private static final String _SAGIC = "_SAGIC";

	/** The constant any string */
	private static final String STRING_RULE_ANY = "*";

	/** The constant does not start with */
	private static final String STRING_RULE_NOT_START_WITH = "!";

	/**
	 * No-arg constructor.
	 */
	public AdaptationUtil() {
		// Rien � faire
	}

	/**
	 * Adaptation de l'intention de commande SAGIC au format IC Injection
	 * Art�mis.
	 * 
	 * @param commandeSagic the commande sagic
	 * 
	 * @return Serializable
	 */
	public Message adapt(CommandeSagic commandeSagic) {
		Message message = new Message();
		message.setIdEmetteur(aps.SystemeExterneConstantes.SAGIC);
		String version = InjectionCdeUtil.getVersionInjecteur(aps.ServiceExterneConstantes.IC_SAGIC);
		if (version == null) {
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_IMPREVUE, "Erreur de configuration de la base : impossible de trouver la version d'IC pour  " + aps.ServiceExterneConstantes.IC_SAGIC + " sur cette instance");
		}
		message.setVersion(version);
		message.setDateEmission(DateUtils.format(DateUtils.getDate(), SagicConstantes.FORMAT_DATE_HEURE));
		if (CodeAction.AN.toString().equals(commandeSagic.getIC().getCodeAction().toString())) {
			message.setAnnulation(getAnnulation(commandeSagic));
		} else {
			message.setCommande(getCommande(commandeSagic));
		}
		return message;
	}

	/**
	 * M�thode permettant de cr�er un objet de type ParametreType (Objet de type cl� = valeur)<BR>
	 * 
	 * @param key La cl� utilis�e
	 * 
	 * @param value La valeur de la cl�
	 * 
	 * @return Un objet de type ParametreType
	 */
	protected static ParametreType createParametre(String key, String value) {
		ParametreType param = new ParametreType();
		param.setCle(key);
		param.setValeur(value);
		return param;
	}

	/**
	 * Valorisation du code r�gime.
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>05/05/2009</TD><TD>DBA</TD><TD>Dans le cadre du changement de version G7R05 -> G7R10, un m�canisme de forcage a �t� mis en place. Le champ "" est forc� avec la valeur NORMAL.</TD></TR>
	 * 
	 * 
	 * @param cs Le compl�ment service de l'intention de commande sagic
	 * 
	 * @param psSouhaite Le produit service souhaite � initialiser
	 */
	protected static void valoriserCodeRegime(ComplementService cs, ProduitServiceSouhaite psSouhaite) {

		// R�cup�ration de l'objet codeRegime de l'intention de commande SAGIC
		CodeRegime codeRegime = cs.getCodeRegime();
		if (codeRegime != null) {

			// Si le code r�gime a �t� envoy�, r�cup�rer sa valeur
			String code = codeRegime.toString();

			/*
			 * -----------------------------------------------------------
			 * 05/05/2009
			 * DBA: Gestion d'un nouveau champ "" envoy� par SAGIC.
			 * Lorsque ce champ arrive, il est forc� avec la valeur NORMAL.
			 * -----------------------------------------------------------
			 */
			if (StringUtils.isEmpty(code)) {
				psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_CODE_REGIME, "NORMAL"));
			} else {
				psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_CODE_REGIME, code));
			}

		}
	}

	/**
	 * From date to date heure.
	 * 
	 * @param date the date
	 * 
	 * @return the string
	 */
	private static String fromDateToDateHeure(String date) {
		return date + STRING_MIDNIGHT;
	}

	/**
	 * RG15.
	 * 
	 * @param ligneCde the ligne cde
	 * @param ic the ic
	 */
	protected static void getAccesLivraison(LigneCommandeType ligneCde, IC ic) {
		ComplementService complementService = ic.getComplementService();
		if (complementService.getStatutNDDest() != null) {
			if (STATUT_ND_DEST_I.equals(complementService.getStatutNDDest())) {
				ligneCde.setAccesLivraison(complementService.getNDDest());
				ligneCde.setTypeAccesLivraison(SagicConstantes.TYPEACCES_NDPLP);
			} else {
				ligneCde.setTypeAccesLivraison(SagicConstantes.TYPEACCES_IDCLI);
			}
		} else {
			StatutLigne statutLigne = complementService.getStatutLigne();
			if ((statutLigne == null) || (StatutLigne.A.toString()).equals(statutLigne.toString())) {
				ligneCde.setAccesLivraison(ic.getSupport());
				ligneCde.setTypeAccesLivraison(SagicConstantes.TYPEACCES_ND);
			} else if (StatutLigne.I.toString().equals(statutLigne.toString()) || StatutLigne.PLPP.toString().equals(statutLigne.toString()) || StatutLigne.PLPC.toString().equals(statutLigne.toString())
					|| StatutLigne.PLPA.toString().equals(statutLigne.toString())) {
				ligneCde.setAccesLivraison(ic.getSupport());
				ligneCde.setTypeAccesLivraison(SagicConstantes.TYPEACCES_NDPLP);
			} else {
				ligneCde.setTypeAccesLivraison(SagicConstantes.TYPEACCES_IDCLI);
			}
		}
	}

	/**
	 * Gets the annulation.
	 * 
	 * @param commandeSagic the commande sagic
	 * 
	 * @return the annulation
	 */
	protected static Annulation getAnnulation(CommandeSagic commandeSagic) {
		IC ic = commandeSagic.getIC();
		Annulation annulation = new Annulation();
		annulation.setIdCommande(ic.getIdIceSagic());
		annulation.setIdElementParcSupport(ic.getSupport());
		return annulation;
	}

	/**
	 * Gets the client contractant.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param parc the parc
	 * @param catClient the cat client
	 * @param categorieClientOBS QC-1066 Si non-OBS, son valeur est null; si OBS, son valeur est valeurArtemis
	 * 
	 * @return the client contractant
	 */
	protected static ClientContractant getClientContractant(CommandeSagic commandeSagic, String parc, String catClient) {
		ClientContractant client = new ClientContractant();
		if (SagicConstantes.TYPE_OFFRE_DE_GROS.equals(parc)) {
			client.setIdClient(commandeSagic.getIC().getCodeRevendeur());
			client.setNomOuRaisonSociale(commandeSagic.getIC().getComplementService().getLibOperateur());
			if (null != catClient && !catClient.equals(SagicConstantes.VALEUR_INCONNUE)) {
				// QC-1066: OBS
				client.setCategorie(catClient);
			} else {
				// QC-1066: Non-OBS
				client.setCategorie(serviceManager.getTraductionManager().getTraductionCatClientInterfVersCatClientLivre(SystemeExterneConstantes.SAGIC, SagicConstantes.OP));
			}
		} else if (SagicConstantes.TYPE_OFFRE_DETAIL.equals(parc)) {
			client.setNomOuRaisonSociale(commandeSagic.getIC().getIdentiteClient());
			client.setCategorie(catClient);
		}
		return client;
	}

	/**
	 * Gets the client livre.
	 * 
	 * @param ic the ic
	 * @param categoryClient the category client
	 * 
	 * @return the client livre
	 */
	protected static ClientLivre getClientLivre(IC ic, String categoryClient) {
		ClientLivre client = new ClientLivre();
		client.setNomOuRaisonSociale(ic.getIdentiteClient());
		client.setCategorie(categoryClient);
		Adresse adClient = new Adresse();
		adClient.setLigne1(ic.getComplementService().getAdresseCl());
		adClient.setCodePostal(ic.getComplementService().getCodePostalCl());
		adClient.setVille(ic.getComplementService().getCommuneCl());
		adClient.setLibelleVoie(ic.getComplementService().getLibVoieCli());
		adClient.setCodeRivoli(ic.getComplementService().getRIVOLI());
		adClient.setNumeroVoie(ic.getComplementService().getNumVoieCli());
		adClient.setEnsemble(ic.getComplementService().getEnsemble());
		adClient.setBatiment(ic.getComplementService().getBatiment());
		adClient.setEscalier(ic.getComplementService().getEscalier());
		adClient.setEtage(ic.getComplementService().getEtage());
		adClient.setPorte(ic.getComplementService().getPorte());
		adClient.setLogo(ic.getComplementService().getLogo());
		adClient.setCodeInsee(ic.getComplementService().getINSEEClient());
		client.setAdresse(adClient);
		return client;
	}

	/**
	 * Gets the commande.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param paramFonctNotification
	 * 
	 * @return the commande
	 */
	protected Commande getCommande(CommandeSagic commandeSagic) {
		String METHOD_NAME_GET_COMMANDE = "getCommande";
		IC ic = commandeSagic.getIC();
		ComplementService cs = ic.getComplementService();
		Commande commande = new Commande();
		commande.setIdCommande(ic.getIdIceSagic());
		if ((cs.getDateRecep() != null) && (cs.getDateRecep().length() > 0)) {
			commande.setDateDebutPriseCommandeFO(fromDateToDateHeure(cs.getDateRecep()));
		} else {
			commande.setDateDebutPriseCommandeFO(ic.getDatePriseCommande());
		}
		// RG4 : Adaptation de l'offre envoy�e par Sagic
		List<String> params = new ArrayList<String>();
		String valeurExterne = getTraductionOffre(commandeSagic, params);
		// Traduction de l'offre Sagic "adapt�e" en offre Artemis
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, METHOD_NAME_GET_COMMANDE, "appel TG Concat Diff avec l'offre = " + valeurExterne);
		Map<String, List<ValeurParametreDTO>> offreArtemisMap = serviceManager.getTraductionManager().getTraductionOffreConcatDiff(valeurExterne, SystemeExterneConstantes.SAGIC);
		if ((offreArtemisMap == null) || offreArtemisMap.isEmpty()) {
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Erreur de traduction de l'offre Sagic " + valeurExterne);
		}
		// RG6 : Client livr�
		String codeRevendeur = commandeSagic.getIC().getCodeRevendeur();
		TraductionDTO traductionDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.SAGIC),
				new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.CLE_OPERATEUR_OBS));
		String categorieClientOBS = null;
		if (traductionDTO != null && traductionDTO.getValeurExterne().contains(codeRevendeur)) {
			categorieClientOBS = traductionDTO.getValeurArtemis();
		}

		String catClient = serviceManager.getTraductionManager().getTraductionCatClientInterfVersCatClientLivre(SystemeExterneConstantes.SAGIC, SagicConstantes.VALEUR_INCONNUE);
		if (StringUtils.isNotEmpty(categorieClientOBS)) {
			catClient = categorieClientOBS;
		}
		commande.setDateValidationCommandeFO(ic.getDatePriseCommande());
		commande.setContact(getContact(commandeSagic));
		String codeActionArtemis = translate((SagicConstantes.KEY_CODE_ACTION), ic.getCodeAction().toString());
		Iterator<Entry<String, List<ValeurParametreDTO>>> entryIterator = offreArtemisMap.entrySet().iterator();
		Map<String, InstanceOffreGroupee> instanceOGMap = new HashMap<String, InstanceOffreGroupee>();
		Set<String> typeDeVenteMap = new HashSet<String>();// Liste des types de vente
		// initialis�e
		List<Intervention> intervs = new ArrayList<Intervention>();// Liste des interventions
		// initialis�e
		// parcours de la HashMap offreArtemisMap
		while (entryIterator.hasNext()) {
			Entry<String, List<ValeurParametreDTO>> entry = entryIterator.next();
			String offre = entry.getKey();
			OffreDTO offreDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, offre);
			String typeDeVente = offreDTO.getTypeDeVente();
			typeDeVenteMap.add(typeDeVente);
			List<ValeurParametreDTO> valeurParametreDTOs = entry.getValue();
			if (aps.TypeOpPonctuellesConstantes.CR.equals(codeActionArtemis) || aps.TypeOpPonctuellesConstantes.DEMMND.equals(codeActionArtemis)) {
				// Regroupement des Lignes de Commande par InstanceOffreGroupee
				String refOffreGroupee = getRefOffreGroupe(offreDTO);
				if (instanceOGMap.containsKey(refOffreGroupee)) {
					InstanceOffreGroupee instanceOG = instanceOGMap.get(refOffreGroupee);
					instanceOG.addLigneCommande(getLigneCommande(commandeSagic, offreDTO, valeurParametreDTOs, catClient, params, intervs));
				} else {
					InstanceOffreGroupee instanceOG = new InstanceOffreGroupee();
					instanceOG.setRefOffreGroupee(refOffreGroupee);
					instanceOG.addLigneCommande(getLigneCommande(commandeSagic, offreDTO, valeurParametreDTOs, catClient, params, intervs));
					commande.addInstanceOffreGroupee(instanceOG);
					instanceOGMap.put(refOffreGroupee, instanceOG);
				}
			} else {
				commande.addLigneCommande(getLigneCommande(commandeSagic, offreDTO, valeurParametreDTOs, catClient, params, intervs));
			}
		}

		// QC-1066 RG 0 Valorisation CLient Contractant, Cat�gorie Client Contractant, Nom Client Contractant
		String parc = getParc(typeDeVenteMap);
		commande.setClientContractant(getClientContractant(commandeSagic, parc, catClient));
		// Interventions
		commande.setIntervention(intervs.toArray(new Intervention[intervs.size()]));

		// attribut cas metier
		String attributCasMetier = valoriserCasMetier(commandeSagic);

		if (attributCasMetier != null && attributCasMetier.length() > 0) {
			commande.setCasMetier(attributCasMetier);
		}

		// Appel RG21
		valoriserParametresDynamiquesCommande(commandeSagic, commande);

		return commande;
	}

	/**
	 * Gets the contact.
	 * 
	 * @param commandeSagic the commande sagic
	 * 
	 * @return the contact
	 */
	protected static Contact getContact(CommandeSagic commandeSagic) {
		Contact contact = new Contact();
		contact.setTelephone(commandeSagic.getIC().getNDContact());
		contact.setNom(commandeSagic.getIC().getNomContact());
		return contact;
	}

	/**
	 * Gets the date contractuelle.
	 * 
	 * @param ic the ic
	 * 
	 * @return the date contractuelle
	 */
	protected static String getDateContractuelle(IC ic) {
		String sDate = ic.getDMADFOP();
		if ((sDate != null) && (sDate.length() > 0)) {
			return fromDateToDateHeure(sDate);
		}
		try {
			long lDatePriseCde = DateUtils.parseDate(ic.getDatePriseCommande(), SagicConstantes.FORMAT_DATE_HEURE).getTime();
			ParametreArtemisDTO parametreArtemisDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ParametreArtemisDTO.class, new Comparaison(ParametreArtemis.FIELD_CLE_PARAMETRE, Constantes.OPERATOR_EQUAL, SagicConstantes.DXF),
					new Comparaison(ParametreArtemis.FIELD_VERSION, Constantes.OPERATOR_EQUAL, Constantes.VERSION));
			Long dxf = new Long(parametreArtemisDTO.getValeurParametre());
			// on retourne la date de prise de commande plus le nombre donn� par 'DXF'
			return DateUtils.format(new Date(lDatePriseCde + (dxf * (HOUR_IN_MILLIS * 24))), SagicConstantes.FORMAT_DATE_HEURE);
		} catch (ParseException e) {
			// Doit pas arriver ici car validation d�ja fait !
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Erreur de format de date");
		} catch (NumberFormatException e) {
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_IMPREVUE, "Erreur de configuration de la base : le param�tre bolbec pour la cl� 'DXF' doit �tre un num�ro");
		}
	}

	/**
	 * Gets the date souhaite.
	 * 
	 * @param ic the ic
	 * @param sDateContractuelle the s date contractuelle
	 * 
	 * @return the date souhaite
	 */
	protected String getDateSouhaite(IC ic, String sDateContractuelle) {
		if (dateSouhaitee == null) {
			try {
				Date lDateSouhaitee;
				ComplementService complementService = ic.getComplementService();
				String plpaDateEm = complementService.getPLPADateEm();
				Date lDateContractuelle = DateUtils.parseDate(sDateContractuelle, SagicConstantes.FORMAT_DATE_HEURE);
				Calendar now = new GregorianCalendar();
				// Gestion des incoh�rences
				gestionCasIncoherence(ic);
				if (!StringUtils.isBlank(plpaDateEm)) {
					Date dateMesSouhaiteLc = DateUtils.parseDate(plpaDateEm, SagicConstantes.FORMAT_DATE);
					lDateSouhaitee = dateMesSouhaiteLc;
				} else if ((ic.getDSFOP() != null) && (ic.getDSFOP().length() > 0)) {
					Date dsFOP = DateUtils.parseDate(ic.getDSFOP(), SagicConstantes.FORMAT_DATE);
					// Si DSFOP est d�ja d�pass�e, on prend la date du jour
					if (now.getTime().after(dsFOP)) {
						lDateSouhaitee = now.getTime();
					} else if (lDateContractuelle.before(dsFOP)) {
						lDateSouhaitee = lDateContractuelle;
						// Si non, on prend DSFOP
					} else {
						lDateSouhaitee = dsFOP;
					}
				}

				// Si DSFOP n'est pas valoris�e on prend la date contractuelle
				else {
					lDateSouhaitee = lDateContractuelle;
				}
				// Pour le lissage des commandes, on ajoute un delai aleatoire
				int heure = now.get(Calendar.HOUR_OF_DAY);
				int min = now.get(Calendar.MINUTE);
				// g�n�ration d'un nb de secondes al�atoire compris entre 0 et
				// 14400(4*3600)
				// Math.random()*n renvoie des int compris entre 0 et n-1
				long nbsecondes = (long) (Math.random() * 14401L);
				heure = heure + (int) nbsecondes / 3600;
				min = min + (int) (nbsecondes % 3600) / 60;
				Calendar calendarDate = new GregorianCalendar();
				calendarDate.setTime(lDateSouhaitee);
				calendarDate.set(Calendar.HOUR_OF_DAY, heure);
				calendarDate.set(Calendar.MINUTE, min);
				dateSouhaitee = DateUtils.format(calendarDate.getTime(), SagicConstantes.FORMAT_DATE_HEURE);
				return dateSouhaitee;
			} catch (ParseException e) {
				// Doit pas arriver ici car validation d�ja fait !
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Erreur de format de date");
			}
		}
		return dateSouhaitee;
	}

	/**
	 * Gets the element parc affecte.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param offreDTO the offre dto
	 * @param hmp the hmp
	 * 
	 * @return the element parc affecte
	 */
	protected static ElementParcAffecte getElementParcAffecte(CommandeSagic commandeSagic, OffreDTO offreDTO, Map<String, String> hmp) {
		IC ic = commandeSagic.getIC();
		ElementParcAffecte eltParc = new ElementParcAffecte();
		eltParc.setIdEPC(getSupport(ic));
		eltParc.setIdAccesClient(getSupport(ic));
		eltParc.setRefOffreExistante(offreDTO.getId());
		eltParc.setIdClientContractant(ic.getCodeRevendeur());
		// Param�tres Element Parc Affecte
		// RG12 : Traitement de l'ID de l'offre origine
		eltParc.addParametreElementParc(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_OSIRIS_IDOFFREORIG, ic.getCodeOffre()));
		// RG13 : Valorisation de la HashMap Param�tre Element de Parc
		for (Iterator<Map.Entry<String, String>> iterHmp = hmp.entrySet().iterator(); iterHmp.hasNext();) {
			Map.Entry<String, String> element = iterHmp.next();
			String cle = element.getKey();
			String value = element.getValue();
			eltParc.addParametreElementParc(createParametre(cle, value));
		}
		return eltParc;
	}

	/**
	 * Gets the ligne commande.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param offreDTO the offre dto
	 * @param valeurParametreDTOs the valeur parametre dt os
	 * @param catClient the cat client
	 * @param listeParam the liste param
	 * @param lst_Interventions the lst_ interventions
	 * 
	 * @return the ligne commande
	 */
	protected LigneCommandeType getLigneCommande(CommandeSagic commandeSagic, OffreDTO offreDTO, List<ValeurParametreDTO> valeurParametreDTOs, String catClient, List<String> listeParam, List<Intervention> lst_Interventions) {
		IC ic = commandeSagic.getIC();
		LigneCommandeType ligneCde = new LigneCommandeType();
		ligneCde.setIdLigneCommande(ic.getIdIceSagic());
		String sDateContractuelle = getDateContractuelle(ic);
		ligneCde.setDateContractuelle(sDateContractuelle);
		ligneCde.setDateSouhaitee(getDateSouhaite(ic, sDateContractuelle));
		String opePonctuelleOrigine = translate((SagicConstantes.KEY_CODE_ACTION), ic.getCodeAction().toString());
		ligneCde.setRefOperationPonctuelle(opePonctuelleOrigine);
		// RG15 : Valeur et type de l'acc�s de livraison
		getAccesLivraison(ligneCde, ic);
		// Client livr�
		ligneCde.setClientLivre(getClientLivre(ic, catClient));
		// RG1 : Ligne de commande, valorisations EPC et PSSouhaite
		Map<String, String> hmp = serviceManager.getTraductionManager().transformeListeParametres(valeurParametreDTOs);
		if ((!aps.TypeOpPonctuellesConstantes.CR.equals(opePonctuelleOrigine)) && (!aps.TypeOpPonctuellesConstantes.DEMMND.equals(opePonctuelleOrigine))) {
			ligneCde.setElementParcAffecte(getElementParcAffecte(commandeSagic, offreDTO, hmp));
		}
		if (!aps.TypeOpPonctuellesConstantes.SU.equals(opePonctuelleOrigine)) {
			ligneCde.setProduitServiceSouhaite(getProduitServiceSouhaite(commandeSagic, offreDTO, hmp, listeParam));
		}
		// RG5 : Param�tres livraison Ligne de commande
		// Valorisation de OffreOrigine et OsirisOpPonctuelleOrigine
		ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OSIRIS_OPPONCTORIG, ic.getCodeAction().toString()));
		ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OPPONCTORIG, ic.getCodeAction().toString()));
		// ParamCtxContexte
		String value = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.SAGIC, SagicConstantes.KEY_CONTEXTE_OPERATION, ic.getCodeAction().toString());
		if (value != null) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamic.PC_CONTEXTE, value));
		}

		// R�cup�ration du complementService
		ComplementService complementService = ic.getComplementService();

		// LigneAssoc
		addLigneAssoc(ligneCde, complementService);

		// EV-000232
		// ReferenceFCI
		addRefFCI(ligneCde, complementService);

		// Support
		ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_SUPPORT, ic.getSupport()));

		// PresConvDesa
		PresConvDesa presConvDesa = complementService.getPresConvDesa();
		if (presConvDesa != null) {
			if (presConvDesa.toString().length() > 0) {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_PRES_CONV_DESA, presConvDesa.toString()));
			} else {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_PRES_CONV_DESA, STRING_NON));
			}
		}

		// EV-000426 : ApplicConvDesa
		ApplicConvDesa applicConvDesa = complementService.getApplicConvDesa();
		if (applicConvDesa != null) {
			if (applicConvDesa.toString().length() > 0) {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_APPLIC_CONV_DESA, applicConvDesa.toString()));
			} else {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_APPLIC_CONV_DESA, STRING_NON));
			}
		}

		/*
		 * EV-000051 : montee en debit
		 * Ajout de la recuperation de la donnee BiInjection
		 */
		// BiInjection
		String biInjection = complementService.getBiInjection();
		if (biInjection != null) {
			if (biInjection.length() > 0) {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_BIINJECTION, biInjection));
			} else {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_BIINJECTION, Constantes.CST_N));
			}
		}

		/*
		 * EV-000005 Portabilit� S�che
		 */
		// PortaSubsequente
		CodeAction codeAction = ic.getCodeAction();
		String portaSubsequenteValExt = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.SAGIC, SagicConstantes.KEY_CODE_ACTION_PORTA_SUB, codeAction.toString());
		if (!StringUtils.isEmpty(portaSubsequenteValExt)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_PORTA_SUBSEQUENTE, portaSubsequenteValExt));
		}

		// Motif Resil
		String motifResilValExt = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.SAGIC, SagicConstantes.KEY_CODE_ACTION_MOTIF_RESIL, codeAction.toString());

		if (!StringUtils.isEmpty(motifResilValExt)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_MOTIF_RESIL, motifResilValExt));
		}

		// MaintienPorta
		MaintienPort maintienPort = complementService.getMaintienPort();
		if (maintienPort != null) {
			String maitienPortValue = maintienPort.toString();
			if (STRING_BLANK.equals(maitienPortValue)) {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_MAINTIEN_PORT, STRING_NON));
			} else {
				// Maintien Port est non vide
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_MAINTIEN_PORT, maintienPort.toString()));

				// Z0BPQRMaintienPort, CodeOpICNXMaintienPort, LibOpICNXMaintienPort
				if (TypeOpPonctuellesConstantes.SU.equals(opePonctuelleOrigine)) {
					if (STRING_OUI.equals(maitienPortValue)) {
						if (complementService.getZ0BPQR() != null) {
							ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_Z0BPQ_MAITIEN_PORT, complementService.getZ0BPQR()));
						}
						if (complementService.getCodeOpICNX() != null) {
							ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_CODE_OP_ICNX_MAITIEN_PORT, complementService.getCodeOpICNX()));
						}
						if (complementService.getLibOpICNX() != null) {
							ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_LIB_OP_ICNX_MAITIEN_PORT, complementService.getLibOpICNX()));
						}
					}
				}
			}
		}

		// TypePorta
		TypePorta typePorta = complementService.getTypePorta();
		if ((typePorta != null) && (typePorta.toString().length() > 0)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_TYPE_PORTA, typePorta.toString()));
		}

		// Attributaire
		String attributaire = complementService.getAttributaire();
		if ((attributaire != null) && (attributaire.length() > 0)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_ATTRIBUTAIRE, attributaire));
		}

		// NDActif
		NdActif ndActif = complementService.getNDActif();
		if ((ndActif != null) && (ndActif.toString().length() > 0)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_NDACTIF, ndActif.toString()));
		}

		// SupportFibre
		SupportFO supportFO = complementService.getSupportFO();
		if ((supportFO != null) && (supportFO.toString().length() > 0)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_SUPPORTFIBRE, supportFO.toString()));
		}

		// NDFictifFibre
		String nds = complementService.getNDS();
		if ((nds != null) && (nds.length() > 0)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_NDFICTIF_FIBRE, nds));
		}

		// RG17 : Op�rations programm�es et interventions
		setOperationProgrammee(ligneCde, ic, offreDTO, lst_Interventions);
		return ligneCde;
	}

	/**
	 * Permet d'ajouter une ligne Assoc � une ligne de Commande
	 * 
	 * @param ligneCde
	 * @param complementService
	 */
	private void addLigneAssoc(LigneCommandeType ligneCde, ComplementService complementService) {
		LigneAssoc ligneAssoc = complementService.getLigneAssoc();
		if (ligneAssoc != null) {
			String chaineLigneAssoc = ligneAssoc.toString();
			if (StringUtils.isEmpty(chaineLigneAssoc)) {
				chaineLigneAssoc = Constantes.CST_NON;
			}
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_LIGNE_ASSOC, chaineLigneAssoc));
		} else {
			StatutLigne statLigne = complementService.getStatutLigne();
			if (statLigne != null) {
				if (StatutLigne.R.toString().equals(statLigne.toString())) {
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Le champ Ligne Assoc est obligatoire pour un StatutLigne de r�f�rence");
				}
			}
		}
	}

	/**
	 * Permet d'ajouter une reference FCI � une ligne de Commande
	 * EV-000232
	 * 
	 * @param ligneCde
	 * @param complementService
	 */
	private void addRefFCI(LigneCommandeType ligneCde, ComplementService complementService) {
		String referenceFCI = complementService.getReferenceFCI();
		if (StringUtils.isNotEmpty(referenceFCI)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_REFERENCE_FCI, referenceFCI));
		}
	}

	/**
	 * Gets the parc.
	 * 
	 * @param typeDeVenteMap the type de vente map
	 * 
	 * @return the parc
	 */
	protected static String getParc(Set<String> typeDeVenteMap) {
		String parc = null;
		if (typeDeVenteMap.contains(SagicConstantes.TYPE_DE_VENTE_WHOLESALE)) {
			parc = SagicConstantes.TYPE_OFFRE_DE_GROS;
		} else {
			parc = SagicConstantes.TYPE_OFFRE_DETAIL;
		}
		return parc;
	}

	/**
	 * Gets the produit service souhaite.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param offreDTO the offre dto
	 * @param hmp the hmp
	 * @param listeParam the liste param
	 * 
	 * @return the produit service souhaite
	 */
	protected static ProduitServiceSouhaite getProduitServiceSouhaite(CommandeSagic commandeSagic, OffreDTO offreDTO, Map<String, String> hmp, List<String> listeParam) {
		IC ic = commandeSagic.getIC();
		ProduitServiceSouhaite psSouhaite = new ProduitServiceSouhaite();
		psSouhaite.setRefOffreCible(offreDTO.getId());
		// RG16 : Acc�s client du PSSouhaite
		String statutDestination = null;

		if (CodeAction.DEMMND.equals(ic.getCodeAction()) && ic.getComplementService().getStatutNDDest() != null) {
			statutDestination = ic.getComplementService().getStatutNDDest();
		} else if (ic.getComplementService().getStatutLigne() != null) {
			statutDestination = ic.getComplementService().getStatutLigne().toString();
		}

		if ((statutDestination == null) || (StatutLigne.A.toString()).equals(statutDestination)) {
			psSouhaite.setIdAccesClient(getSupport(ic));
		}
		psSouhaite.setIdElementParcSupport(getSupport(ic));
		setParametresProduitService(commandeSagic, psSouhaite, hmp, listeParam);
		setParametresContextuelLivraison(commandeSagic, psSouhaite);
		setDiagnosticFaisabilite(commandeSagic, psSouhaite);
		return psSouhaite;
	}

	/**
	 * Gets the ref offre groupe.
	 * 
	 * @param offreDTO the offre dto
	 * 
	 * @return the ref offre groupe
	 */
	protected static String getRefOffreGroupe(OffreDTO offreDTO) {
		DescGroupeOffresDTO descGroupeOffresDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(DescGroupeOffresDTO.class, new Comparaison(DescGroupeOffres.SLINK_CONTIENT_OFFRE, Constantes.OPERATOR_EQUAL, offreDTO.getId()));
		GroupeOffresDTO groupeOffresDTO = descGroupeOffresDTO.getGroupeOffres();
		if (groupeOffresDTO == null) {
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Aucun groupe d'offres pour l'offre " + offreDTO.getId());
		}
		List<DescOffreGroupeeDTO> descOffreGroupeeDTOs = serviceManager.getReferenceSpaceManager().listInReferenceSpace(DescOffreGroupeeDTO.class,
				new Comparaison(DescOffreGroupee.SLINK_CONTIENT_GROUPE_OFFRES, Constantes.OPERATOR_EQUAL, groupeOffresDTO.getId()));
		if (descOffreGroupeeDTOs.size() == 0) {
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Aucun offre group�e pour le groupe d'offres " + offreDTO.getId());
		}
		return CollectionUtils.getFirstOrNull(descOffreGroupeeDTOs).getOffreGroupee().getId();
	}

	/**
	 * RG4 : Adaptation de l'offre envoy�e par Sagic.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param listeParam the liste param
	 * 
	 * @return offre traduite
	 */
	protected static String getTraductionOffre(CommandeSagic commandeSagic, List<String> listeParam) {
		IC ic = commandeSagic.getIC();
		ComplementService cs = ic.getComplementService();
		String offre = null;
		TypeDgrp typedgrp = cs.getTypeDgrp();
		MaintienPort maintienPort = cs.getMaintienPort();
		if (typedgrp != null) {
			offre = typedgrp.toString();
			if (maintienPort != null) {
				if (STRING_OUI.equals(maintienPort.toString())) {
					offre = offre + STRING_P;
				}
			}
			String valOffreArt = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(aps.SystemeExterneConstantes.SAGIC, SagicConstantes.TYPE_DEG, offre);
			offre = valOffreArt;
		}
		String codeOffre = ic.getCodeOffre();
		if (offre == null) {
			StatutLigne statut = cs.getStatutLigne();
			if (statut != null) {
				offre = codeOffre + statut.toString();
				if (StatutLigne.I.toString().equals(statut.toString()) || StatutLigne.PLPP.toString().equals(statut.toString()) || StatutLigne.PLPC.toString().equals(statut.toString())) {
					listeParam.add(ic.getSupport());
				}
			} else {
				String valeurMaintienPort = (maintienPort != null ? maintienPort.toString() : null);
				offre = gererNotionPortabilite(ic.getCodeAction(), valeurMaintienPort, codeOffre);
			}
		}
		ComplementService complementService = ic.getComplementService();
		String ndDest = complementService.getNDDest();
		if (ndDest != null) {
			String statutNDDest = complementService.getStatutNDDest();
			if (statutNDDest != null) {
				offre = codeOffre + statutNDDest;
				if (StatutLigne.I.toString().equals(statutNDDest)) {
					listeParam.add(ndDest);
				}
			} else {
				offre = codeOffre;
			}
		}
		return offre;
	}

	/**
	 * EV-000103
	 * Affecte � l'offre la notion de portabilit� ou non
	 * 
	 * @param ic
	 * @param offre
	 * @param maintienPort
	 * @param codeOffre
	 * @return l'offre
	 */
	protected static String gererNotionPortabilite(CodeAction ca, String valeurMaintienPort, String codeOffre) {
		String offre = codeOffre;
		if (ca != null && (CodeAction.MO.toString().equals(ca.toString()) || CodeAction.MC.toString().equals(ca.toString()) || CodeAction.MV.toString().equals(ca.toString()))) {
			if (Constantes.CST_OUI.equals(valeurMaintienPort)) {
				offre += STRING_POR;
			}
		}
		return offre;
	}

	/**
	 * Sets the diagnostic faisabilite.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param psSouhaite the ps souhaite
	 */
	protected static void setDiagnosticFaisabilite(CommandeSagic commandeSagic, ProduitServiceSouhaite psSouhaite) {
		ComplementService cs = commandeSagic.getIC().getComplementService();
		String avis = cs.getAvis();
		if (avis != null) {
			psSouhaite.addDiagnosticFaisabilite(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_LIBELLE_AVIS, avis));
		}
		String motif = cs.getMotif();
		if (motif != null) {
			psSouhaite.addDiagnosticFaisabilite(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_LIBELLE_MOTIF, motif));
		}
		String alerte = cs.getAlerte();
		if (alerte != null) {
			psSouhaite.addDiagnosticFaisabilite(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_LIBELLE_ALERTE, alerte));
		}
	}

	/**
	 * RG17.
	 * 
	 * @param ligneCde the ligne cde
	 * @param ic the ic
	 * @param lst_Interventions the lst_ interventions
	 * @param offreDTO the offre dto
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>16/06/2011</TD><TD>BPE</TD><TD>EV-000157: CR 402 non envoy�e (dateRdvOp vide)</TD></TR>
	 * <TR><TD>20/03/2012</TD><TD>EBA</TD><TD>EV-189-Pas de cr�neaux disponibles (DM 10-270)</TD></TR>
	 * <TR><TD>28/03/2013</TD><TD>VDE</TD><TD>DE_000312 "NullPointerException : controleIntervGlobale"</TD></TR>
	 * <TR><TD>16/04/2013</TD><TD>VDE</TD><TD>DE_000325 "Modification renseignement etat intervention"</TD></TR>
	 * </TABLE>
	 */
	protected static void setOperationProgrammee(LigneCommandeType ligneCde, IC ic, OffreDTO offreDTO, List<Intervention> lst_Interventions) {
		final String methodName = "setOperationProgrammee";
		// Contr�le si une op. prg. est associ�e � l'offre Art�mis valoris�e par
		// RG4
		OffreOpProgDTO offreOpProgDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreOpProgDTO.class, new Comparaison(OffreOpProg.SLINK_DEFINIT_OFFRE, Constantes.OPERATOR_EQUAL, offreDTO.getId()));
		if (offreOpProgDTO != null) {
			// Valorisation d'une op. prg. pour la ligne de commande courante
			OperationProgrammee opPrg = new OperationProgrammee();

			ComplementService complementService = ic.getComplementService();
			String refRdv = null;
			String[] refRdvSplit = null;
			String idIntervPlanCharge = StringUtils.EMPTY;
			if (complementService != null) {
				refRdv = complementService.getRefRDV();
				if (StringUtils.isNotEmpty(refRdv)) {

					// Correction du defect 649
					refRdv = refRdv.toUpperCase();

					refRdvSplit = refRdv.split(SagicConstantes.SEPARATOR_REFRDV);

					// EV-189
					idIntervPlanCharge = Constantes.CST_ERDV;
				}
			}
			Intervention interv = new Intervention();
			// modif pour defect 342
			// String refExterne = null;
			if (refRdv != null && refRdvSplit != null && refRdvSplit.length >= 4) {
				// IC_SAGIC.(4�me champ de RefRDV au sens du s�parateur � - � )

				// modif pour defect 342
				// refExterne = refRdvSplit[3];
				interv.setResponsabilite(ResponsabiliteConstantes.INITIATIVE_OPERATEUR);
				interv.setDateReservation(DateUtils.format(DateUtils.getDate(), SagicConstantes.FORMAT_DATE_HEURE));
			}
			// G�n�ration de l'ID d'intervention concat�nation de 'A'+ann�e(2
			// carac.)+mois(2 carac.)+ id de l'instance d'Art�mis + counter
			StringBuilder idIntervBuf = new StringBuilder(STRING_A);
			idIntervBuf.append(DateUtils.format(DateUtils.getDate(), DATE_PATTERN_YY_MM));
			idIntervBuf.append(serviceManager.getGeneratorManager().generateKey());
			String idInterv = idIntervBuf.toString();

			opPrg.setIdIntervention(idInterv.toUpperCase());
			opPrg.setTypeOp(offreOpProgDTO.getTypeOpProgrammee().getId());
			ligneCde.addOperationProgrammee(opPrg);
			// Valorisation d'une intervention
			interv.setIdIntervention(idInterv.toUpperCase());
			// EV 189: was refRdv
			// DE 312 modification renseignement Etat intervention
			interv.setRefRDV(refRdv);
			interv.setIdPlanCharge(idIntervPlanCharge);
			String creneau = complementService != null ? complementService.getCreneauRdvOp() : null;
			if (StringUtils.isNotEmpty(refRdv)) {
				interv.setEtatIntervention(SagicConstantes.ETATINTERV_RESERVE);
			} else {
				if (StringUtils.isNotEmpty(creneau)) {
					interv.setEtatIntervention(SagicConstantes.ETATINTERV_PLANIFIEE);
				} else {
					interv.setEtatIntervention(SagicConstantes.ETATINTERV_ARESERVER);
				}
			}
			serviceManager.getLoggerManager().finest(CLASS_NAME, methodName, "CreneauRdv : " + creneau + ", refRdv : " + refRdv + ", Etat Intervention : " + interv.getEtatIntervention());
			// Calcul des dates de d�but et fin de plage
			String heureDeb = STRING_BLANK;
			String heureFin = STRING_BLANK;
			if (creneau != null) {
				String[] heuresPlage = creneau.split(SagicConstantes.SEPARATOR_CRENEAURDVOP);
				if (heuresPlage.length == 2) {
					heureDeb = heuresPlage[0].substring(0, (heuresPlage[0]).length() - 1);
					heureFin = heuresPlage[1].substring(0, (heuresPlage[1]).length() - 1);
				}
			}
			Date dt = null;
			if (complementService != null && StringUtils.isNotEmpty(complementService.getDateRdvOp())) {
				try {
					dt = DateUtils.parseDate(complementService.getDateRdvOp(), SagicConstantes.FORMAT_DATE);
				} catch (ParseException e) {
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Erreur de format de date");
				}
			}
			if (dt != null) {
				Calendar cal = Calendar.getInstance();
				Calendar calLimite = Calendar.getInstance();
				// EV-289 Verrue : Verification date < 01/01/2038, pour eviter le bug en timestamp 32 bit
				Long limitDate = new Long("2145913200000");
				calLimite.setTimeInMillis(limitDate);
				cal.setTime(dt);
				if (cal.after(calLimite)) {
					cal.setTime(calLimite.getTime());
				}
				if ((heureDeb != null) && (heureDeb.length() > 0)) {
					cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(heureDeb));
				}
				interv.setDebutPlage(DateUtils.format(cal.getTime(), SagicConstantes.FORMAT_DATE_HEURE));
				if ((heureFin != null) && (heureFin.length() > 0)) {
					cal.set(Calendar.HOUR_OF_DAY, Integer.parseInt(heureFin));
				}
				interv.setFinPlage(DateUtils.format(cal.getTime(), SagicConstantes.FORMAT_DATE_HEURE));
			}
			interv.setDuree(SagicConstantes.DUREE_INTERV_DEFAUT);
			if (creneau != null && refRdvSplit != null && refRdvSplit.length >= 2) {
				interv.addParametre(createParametre(ConstantesDynamicIntervention.INTERVENTION_ACTIV, refRdvSplit[0]));
				interv.addParametre(createParametre(ConstantesDynamicIntervention.INTERVENTION_PROD, refRdvSplit[1]));
			}
			if (complementService != null) {
				interv.setObservations(complementService.getCpltRdvOp());
				if (complementService.getMescOp() != null) {
					interv.setMesc(complementService.getMescOp().toString());
				}
				if (complementService.getTechnoModem() != null) {
					interv.addParametre(createParametre(ConstantesDynamicIntervention.INTERVENTION_TYPE_TECHNO_DSL, complementService.getTechnoModem().toString()));
				}
				if (complementService.getNumHLISVI() != null) {
					interv.addParametre(createParametre(ConstantesDynamicIntervention.INTERVENTION_NUM_APPEL_MES, complementService.getNumHLISVI()));
				}
				if (StringUtils.isNotEmpty(complementService.getRefRDV()) || StringUtils.isNotEmpty(complementService.getDateRdvOp())) {
					interv.addParametre(createParametre(ConstantesDynamicIntervention.INTERVENTION_ORIGINERDV, ConstantesDynamicIntervention.INTERVENTION_ORIGINERDV_OP));
				}
			}

			// M�morisation de l'intervention
			lst_Interventions.add(interv);
		}
	}

	/**
	 * Sets the parametres contextuel livraison.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param psSouhaite the ps souhaite
	 */
	protected static void setParametresContextuelLivraison(CommandeSagic commandeSagic, ProduitServiceSouhaite psSouhaite) {
		String commentOp = commandeSagic.getIC().getComplementService().getCommentOp();
		if (commentOp != null) {
			psSouhaite.addParametreContextuel(createParametre(ConstantesDynamic.PC_COMMENTAIRE, commentOp));
		}
	}

	/**
	 * Sets the parametres produit service.
	 * 
	 * @param commandeSagic the commande sagic
	 * @param psSouhaite the ps souhaite
	 * @param hmp the hmp
	 * @param listeParam the liste param
	 * 
	 * <BR><BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border' bgcolor=green>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>02/01/2013</TD><TD>FTE</TD><TD>EV-000215 : Mise � disposition paire de cuivre - Mapping des nouvelles donn�es</TD></TR>
	 * </TABLE><BR>
	 */
	protected static void setParametresProduitService(CommandeSagic commandeSagic, ProduitServiceSouhaite psSouhaite, Map<String, String> hmp, List<String> listeParam) {
		// RG7 : HashMapS du PSSouhaite
		IC ic = commandeSagic.getIC();
		ComplementService cs = ic.getComplementService();

		String oeie = cs.getNumOEIE();
		if (oeie != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_OEIE, oeie));
		}

		String centreOEIE = cs.getCentreOEIE();
		if (centreOEIE != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_CENTREOEIE, centreOEIE));
		}

		String zoneOEIE = cs.getZoneOEIE();
		if (zoneOEIE != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_ZONEOEIE, zoneOEIE));
		}

		ModeAffectation modeAffectation = cs.getModeAffectation();
		if (modeAffectation != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_MODEAFFECTATION, modeAffectation.toString()));
		}

		String NDAppel = cs.getNDAppel();
		if (NDAppel != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_NDAPPELVGA, NDAppel));
		}

		SiteParticulier siteParculier = cs.getSiteParticulier();
		if (siteParculier != null && Constantes.CST_OUI.equals(siteParculier.toString())) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_SITEPARTICULIER, siteParculier.toString()));
		}

		String pc = cs.getPC();
		if (pc != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_PC, pc));
		}

		String ccl = cs.getCCL();
		if (ccl != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_CCL, ccl));
		}
		String numVC = cs.getNumVC();
		if (numVC != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_VC, numVC));
		}
		String regl = cs.getRegl();
		if (regl != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_REGLETTE, regl));
		}
		String prestCollect = cs.getPrestCollect();
		if (prestCollect != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_PREST_COLLECT, prestCollect));
		}
		String plot = cs.getPlot();
		if (regl != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_BROCHE, plot));
		}

		// Valorisation du code r�gime
		valoriserCodeRegime(cs, psSouhaite);

		// Renseignement de CodeOpPorta et LibOpPorta
		// Renseignement de Z0BPQR
		String z0bpq = cs.getZ0BPQR();
		if (z0bpq != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_Z0BPQ, z0bpq));
			String codeOpICNX = cs.getCodeOpICNX();
			if ((codeOpICNX != null) && (codeOpICNX.length() > 0)) {
				psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_CODE_OP_PORTA, codeOpICNX));
				psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_LIB_OP_PORTA, cs.getLibOpICNX()));
			} else {
				psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_CODE_OP_PORTA, ic.getCodeRevendeur()));
				psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_LIB_OP_PORTA, cs.getLibOperateur()));
			}
		}
		String cclBit = cs.getCCLBit();
		if (cclBit != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_CCL_BIT, cclBit));
		}
		String vcBit = cs.getNumVCBit();
		if (vcBit != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_VC_BIT, vcBit));
		}
		if ((cs.getNSD() != null) && (cs.getNSD().toString() != null)) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_PARAM_CTX_NSD, cs.getNSD().toString()));
		}
		if (cs.getNDRex() != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_PARAM_CTX_NDRex, cs.getNDRex()));
		}
		if (CodeAction.DEMMND.equals(ic.getCodeAction())) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_PARAM_CTX_NDPorte, ic.getSupport()));
		} else {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_PARAM_CTX_NDPorte, STRING_BLANK));
		}
		// Ajout du param�tre ANCIEN_ND issu de la RG4
		if (listeParam.size() > 0) {
			String ancienND = CollectionUtils.getFirstOrNull(listeParam);
			if (ancienND != null) {
				psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_ANCIEN_ND, ancienND));
			}
		}
		// RG8 : Valorisation de la HashMap Param�tre Produit Service
		for (Iterator<Map.Entry<String, String>> iterHmp = hmp.entrySet().iterator(); iterHmp.hasNext();) {
			Map.Entry<String, String> element = iterHmp.next();
			String cle = element.getKey();
			String value = element.getValue();
			psSouhaite.addParametreProduitService(createParametre(cle, value));
		}
		// RG11 : Traitement de l'ID de l'offre origine
		psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_OSIRIS_IDOFFREORIG, ic.getCodeOffre()));
		// RG14 : Param�tres PS en cas de d�groupage total/ADSL nu
		String valArtemis = null;
		String statutDestination = null;
		if (CodeAction.DEMMND.equals(ic.getCodeAction()) && cs.getStatutNDDest() != null) {
			statutDestination = cs.getStatutNDDest();
		} else if (cs.getStatutLigne() != null) {
			statutDestination = cs.getStatutLigne().toString();
		}
		if (statutDestination != null) {
			valArtemis = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.SAGIC, ConstantesTraduction.STATUT_LIGNE, statutDestination);
		}
		if (valArtemis != null) {
			psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_INFOOPSTATUTLIGNE, valArtemis));
		}
	}

	/**
	 * Translate.
	 * 
	 * @param key the key
	 * @param externalValue the external value
	 * 
	 * @return the string
	 */
	protected static String translate(String key, String externalValue) {
		return translate(key, externalValue, SystemeExterneConstantes.SAGIC);
	}

	/**
	 * Translate.
	 * 
	 * @param key the key
	 * @param externalValue the external value
	 * @param systemeExterne the systeme externe
	 * 
	 * @return the string
	 */
	protected static String translate(String key, String externalValue, String systemeExterne) {
		String returned = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(systemeExterne, key, externalValue);
		if (returned == null) {
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Erreur de traduction pour la cl� " + key + ", la valeur externe " + externalValue + " et le systeme externe " + systemeExterne);
		}
		return returned;
	}

	/**
	 * RG18 Gestion du support.
	 * 
	 * @param ic IC_Sagic
	 * 
	 * @return Support en fonction du code action de l'IC
	 */
	protected static String getSupport(IC ic) {
		return CodeAction.DEMMND.equals(ic.getCodeAction()) ? ic.getComplementService().getNDDest() : ic.getSupport();
	}

	/**
	 * RG20 : Valorisation de l'attribut cas metier
	 * 
	 * @author JPE
	 * @param commandeSagic
	 * @param paramFonctNotification
	 * @return valeur de l'attribut cas meter
	 */
	protected String valoriserCasMetier(CommandeSagic commandeSagic) {
		String attributCasMetier = null;

		IC ic = commandeSagic.getIC();
		ComplementService complementService = ic.getComplementService();

		String attributaire = complementService.getAttributaire();
		SupportFO supportFO = complementService.getSupportFO();
		CodeAction codeAction = ic.getCodeAction();
		NdActif ndActif = complementService.getNDActif();
		TypePorta typePorta = complementService.getTypePorta();

		// On va d�terminer une liste de code offre pour lesquels la d�termination du cas m�tier est obligatoire
		List<TraductionCatComDTO> listeTraductionCatCom = serviceManager.getReferenceSpaceManager().listInReferenceSpaceByVersion(TraductionCatComDTO.class,
				new Comparaison(TraductionCatCom.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.SAGIC), new Comparaison(TraductionCatCom.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.LISTE_OFFRE),
				new Comparaison(TraductionCatCom.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.OFFRE_CASMETIER_OBLIG));
		Boolean casMetierObligatoire = false;
		for (TraductionCatComDTO tcc : listeTraductionCatCom) {
			if (tcc.getValeurArtemis().equals(ic.getCodeOffre())) {
				// Cas m�tier obligatoire
				casMetierObligatoire = true;
				break;
			}
		}

		if ((typePorta == null || typePorta.toString().length() == 0) && ((ndActif != null && ndActif.toString().length() > 0) || (supportFO != null && supportFO.toString().length() > 0))) {
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Erreur : TypePorta est nulle et le NDActif ou SupportFO est non nulle");
		}

		if (typePorta == null || attributaire == null || supportFO == null || codeAction == null || ndActif == null) {
			if (casMetierObligatoire) {
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Erreur : Cas m�tier obligatoire");
			}
			return null;
		}

		// cr�ation de la cl� pour la traduction de l'attribut cas Metier
		StringBuffer sb = new StringBuffer();
		sb.append(typePorta.toString());
		sb.append(SEPARATEUR_CONCATENATION);
		sb.append(ndActif.toString());
		sb.append(SEPARATEUR_CONCATENATION);
		sb.append(codeAction.toString());
		sb.append(SEPARATEUR_CONCATENATION);
		sb.append(supportFO.toString());
		sb.append(SEPARATEUR_CONCATENATION);
		sb.append(attributaire.toString());

		try {
			attributCasMetier = translate(SagicConstantes.KEY_CASMETIER_SAGIC, sb.toString(), SystemeExterneConstantes.SAGIC);
		} catch (ReceptionCdeException rce) {
			// Cas m�tier nul
			if (casMetierObligatoire) {
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Erreur : Cas m�tier obligatoire");
			}
			throw rce;
		}

		return attributCasMetier;
	}

	/**
	 * RG21 : Valorisation des param�tres dynamique commande
	 * 
	 * @param commande la commande Art�mis
	 */
	private void valoriserParametresDynamiquesCommande(CommandeSagic commandeSagic, Commande commande) {
		final String method = "valoriserParametresDynamiquesCommande";
		ComplementService complementService = commandeSagic.getIC().getComplementService();
		// EV-387 DSLAO : v�rification de la pr�sence de la balise ModifDSLRenum
		String modifDSLRenum = commandeSagic.getIC().getComplementService().getModifDSLRenum();
		if (Constantes.CST_OUI.equals(modifDSLRenum)) {
			ParametreType nouveauParam = createParametre(ConstantesDynamicCommande.CLE_MODIF_DSL_RENUM, Constantes.CST_OUI);
			serviceManager.getLoggerManager().finer(CLASS_NAME, method, "Int�gration du param�tre " + nouveauParam);
			addParametreCommande(commande, nouveauParam);
		}

		// QC-962 : FOP - Eligiblit� sur d�bit mesur�
		ComplementServiceContexteEligibiliteDebitType contexteEligibiliteDebit = complementService.getContexteEligibiliteDebit();
		String contexteEligibiliteDebitValue = (contexteEligibiliteDebit == null) ? null : contexteEligibiliteDebit.toString();
		if (contexteEligibiliteDebit != null && StringUtils.isNotBlank(contexteEligibiliteDebitValue)) {
			// US58 RV 30 ContexteEligibilit�Debit
			int iContexteEligibiliteDebit = 0;
			try {
				iContexteEligibiliteDebit = Integer.valueOf(contexteEligibiliteDebitValue);
				if ((iContexteEligibiliteDebit < SagicConstantes.LIMITE_INFERIEUR_CONTEXTE_ELIGIBILITE_DEBIT) || (iContexteEligibiliteDebit > SagicConstantes.LIMITE_SUPERIEUR_CONTEXTE_ELIGIBILITE_DEBIT)) {
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Valeur du champ ContexteEligibiliteDebit " + iContexteEligibiliteDebit + " hors du interval [" + SagicConstantes.LIMITE_INFERIEUR_CONTEXTE_ELIGIBILITE_DEBIT + ","
							+ SagicConstantes.LIMITE_SUPERIEUR_CONTEXTE_ELIGIBILITE_DEBIT + "]");
				}
			} catch (NumberFormatException nfe) {
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Valeur du champ ContexteEligibiliteDebit " + contexteEligibiliteDebitValue + " ");
			}
			// Valorisation du dynamic commande
			// US58 RV 30 DebitMesur� (bimode)
			ParametreType nouveauParam = createParametre(ConstantesDynamicCommande.CLE_DEBIT_MESURE, contexteEligibiliteDebitValue);
			serviceManager.getLoggerManager().finer(CLASS_NAME, method, "Int�gration du param�tre " + nouveauParam);
			addParametreCommande(commande, nouveauParam);
		}

		determinerParametresDynamiquesConfig(commandeSagic, commande);
	}

	/**
	 * M�thode pour ajouter un param�tre dynamique sur la commande
	 * Cette m�thode v�rifie si le param�tre n'est pas d�j� pr�sent et s'il n'a pas une autre valeur
	 * 
	 * @param la commande sur laquelle ajouter le param�tre dynamique
	 * @param nouveauParam la cl� et la valeur du param�tre � ajouter
	 */
	protected void addParametreCommande(Commande commande, ParametreType nouveauParam) {
		final String method = "addParametreCommande";

		if (nouveauParam.getCle() == null || nouveauParam.getValeur() == null) {
			serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Erreur lors de la traduction input dynamic commande avec la cl� " + ConstantesTraduction.CLE_PARAMETRE_DYNAMIQUE_COMMANDE_SAGIC + " valeur externe : " + nouveauParam.getValeur());
			return;
		}

		boolean found = false;
		for (ParametreType parametreType : commande.getParametresCommande()) {
			if (nouveauParam.getCle().equals(parametreType.getCle())) {
				if (nouveauParam.getValeur().equals(parametreType.getValeur())) {
					found = true;
					break;
				}

				if (ConstantesTraduction.CLE_STATUT_LIGNE_DYNAMIQUE_COMMANDE_SAGIC.equals(parametreType.getCle())) {
					// Erreur renvoy�e dans le cas de la recherche dans la table Traduction (EV-345)
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Parametre dynamique " + parametreType.getCle() + " d�j� pr�sent avec pour valeur " + parametreType.getValeur() + " au lieu de " + nouveauParam.getValeur());
				}

				// Si on est ici, c'est qu'un param�tre commande existe d�j� avec cette cl� mais avec une valeur diff�rente
				throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Parametre dynamique " + parametreType.getCle() + " d�j� pr�sent avec pour valeur " + parametreType.getValeur() + " au lieu de " + nouveauParam.getValeur());

			}
		}

		if (!found) {
			commande.addParametresCommande(nouveauParam);
		}
	}

	/**
	 * RG 22 : M�thode permettant la gestion des cas d'incoh�rence de la date souhait�e client, et du statut ligne.
	 * 
	 * @throws ParseException
	 */
	private void gestionCasIncoherence(IC ic) {
		ComplementService complementService = ic.getComplementService();
		StatutLigne statutLigne = complementService.getStatutLigne();
		String plpaDateEm = complementService.getPLPADateEm();
		if (statutLigne != null) {
			// La date de mise en service souhait�e doit �tre du format JJ/MM/AAAA
			if (!StringUtils.isBlank(plpaDateEm)) {
				try {
					Date dateMesSouhaiteLc = DateUtils.parseDate(plpaDateEm, SagicConstantes.FORMAT_DATE);
					if (!StatutLigne.PLPA.toString().equals(statutLigne.toString())) {
						throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Le statut ligne renseign� " + statutLigne.toString() + " est diff�rent de " + StatutLigne.PLPA.toString());
					}
				} catch (ParseException excep) {
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Le statut ligne renseign� " + statutLigne.toString() + " est diff�rent de " + StatutLigne.PLPA.toString());
				}
			} else {
				if (StatutLigne.PLPA.toString().equals(statutLigne.toString())) {
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Le statut ligne renseign� " + statutLigne.toString() + " est �gal � " + StatutLigne.PLPA.toString());
				}
			}
		}
	}

	/**
	 * Permet de d�terminer les param�tres dynamiques de commande � partir de la table de conf.
	 * 
	 * @param commandeSagic la commande SAGIC
	 * @param commande la commande bolbec
	 */
	protected void determinerParametresDynamiquesConfig(CommandeSagic commandeSagic, Commande commande) {
		String method = "determinerParametresDynamiquesConfig";

		List<InputDynamicCommandeDTO> lstInputDynamicCommandeDTO = serviceManager.getTraductionManager().findInputDynamicCommandeByOrigine(SystemeExterneConstantes.SAGIC_VALEUR_CONSTANTE);
		if (lstInputDynamicCommandeDTO.size() == 0) {
			serviceManager.getLoggerManager().finer(CLASS_NAME, method, "D�termination de param�tres dynamiques sans configuration de correspondances.");
		} else {
			serviceManager.getLoggerManager().finer(CLASS_NAME, method, "D�termination de param�tres dynamiques selon une liste de " + lstInputDynamicCommandeDTO.size() + " correspondances.");
			List<ParametreType> lstNouveauxParametres = new ArrayList<ParametreType>();

			// R�cup�ration des listes de famille offre parc et commerciel (commun � toutes les lignes)
			Set<String> ensembleFamillesOffreCom = getEnsembleFamilleOffreComm(commandeSagic, commande);
			// Set<String> ensembleFamillesOffreParc = getEnsembleFamilleOffreParc(commandeSagic, commande);

			// Parcours des lignes configur�es.
			for (InputDynamicCommandeDTO inputDynamicCommandeDTO : lstInputDynamicCommandeDTO) {
				// R�cup�ration de l'ensemble des lignes de commandes
				List<LigneCommandeType> lcs = new ArrayList<LigneCommandeType>(Arrays.asList(commande.getLigneCommande()));
				for (InstanceOffreGroupee iog : commande.getInstanceOffreGroupee()) {
					lcs.addAll(Arrays.asList(iog.getLigneCommande()));
				}
				for (LigneCommandeType ligneCommande : lcs) {
					ParametreType nouveauParam = getParametreDynamiqueConfig_X_Ligne(inputDynamicCommandeDTO, commandeSagic, ligneCommande, ensembleFamillesOffreCom);
					if (nouveauParam != null) {
						boolean existeDeja = false;
						for (ParametreType param : commande.getParametresCommande()) {
							if (StringUtils.equals(nouveauParam.getCle(), param.getCle())) {
								if (!StringUtils.equals(nouveauParam.getValeur(), param.getValeur())) {
									serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Rejet du param�tre " + nouveauParam.getCle() + " par raison de incoh�rence.");
									throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION,
											"Le param�tre avec pour cl� " + nouveauParam.getCle() + " est d�j� pr�sent sur la commande avec la valeur " + param.getValeur() + " et non pas la valeur " + nouveauParam.getValeur());
								}
								existeDeja = true;
							}
						}

						if (existeDeja) {
							serviceManager.getLoggerManager().finer(CLASS_NAME, method, "Rejet du param�tre " + nouveauParam.getCle() + " par raison de doublon.");
						} else {
							lstNouveauxParametres.add(nouveauParam);
							commande.addParametresCommande(nouveauParam);
							serviceManager.getLoggerManager().finer(CLASS_NAME, method, "Int�gration du param�tre " + nouveauParam.getCle());
						}
					}
				}
			}
			serviceManager.getLoggerManager().finer(CLASS_NAME, method, "R�cup�ration totale de " + lstNouveauxParametres.size() + " param�tres dynamiques");
		}
	}

	/**
	 * Permet de d�terminer le param�tre dynamique d'une ligne de commande � partir d'une ligne de la table de conf.
	 * 
	 * @param inputDynamicCommandeDTO la ligne de config input dynamique commande
	 * @param commandeSagic la commande sagic
	 * @param ligneCommande la ligne de commande sagic
	 * @param ensembleFamillesOffreCom l'ensemble de famille d'offre
	 */
	protected ParametreType getParametreDynamiqueConfig_X_Ligne(InputDynamicCommandeDTO inputDynamicCommandeDTO, CommandeSagic commandeSagic, LigneCommandeType ligneCommande, Set<String> ensembleFamillesOffreCom) {
		String method = "getParametreDynamiqueConfig_X_Ligne";

		String tradConfStatut = inputDynamicCommandeDTO.getStatut();
		String tradConfOperation = inputDynamicCommandeDTO.getOperation();
		String tradConfFamilleOffre = inputDynamicCommandeDTO.getOffre();

		boolean bCorrespondanceOk = true;

		// Comparer le statut (et variations d'expr. reg.)
		if (StringUtils.isBlank(tradConfStatut) || StringUtils.equals(tradConfStatut, STRING_RULE_ANY)) {
		} else {
			StatutLigne statutLigne = commandeSagic.getIC().getComplementService().getStatutLigne();
			String sStatutLigne = (statutLigne != null) ? statutLigne.toString() : null;
			bCorrespondanceOk = StringUtils.equals(tradConfStatut, sStatutLigne);
		}
		if (!bCorrespondanceOk) {
			return null;
		}

		// Comparer l'operation (et variations d'expr. reg.)
		if (StringUtils.isBlank(tradConfOperation) || StringUtils.equals(tradConfOperation, STRING_RULE_ANY)) {
		} else {
			String typeOpPonctuelle = ligneCommande.getRefOperationPonctuelle();
			bCorrespondanceOk = StringUtils.equals(tradConfOperation, typeOpPonctuelle);
		}
		if (!bCorrespondanceOk) {
			return null;
		}

		// Comparer la famille d'offre (et variations d'expr. reg.)
		if (StringUtils.isBlank(tradConfFamilleOffre) || StringUtils.equals(tradConfFamilleOffre, STRING_RULE_ANY)) {
		} else if (StringUtils.startsWith(tradConfFamilleOffre, STRING_RULE_NOT_START_WITH)) {
			bCorrespondanceOk = true;
			for (String sFamilleOffre : ensembleFamillesOffreCom) {
				if (StringUtils.startsWith(sFamilleOffre, tradConfFamilleOffre.substring(1))) {
					bCorrespondanceOk = false;
					break;
				}
			}
		} else {
			String familleOffre = getFamilleOffreComm(ligneCommande);
			bCorrespondanceOk = StringUtils.equals(tradConfFamilleOffre, familleOffre);
		}
		if (!bCorrespondanceOk) {
			return null;
		}

		// Construire le parametre, et valider la composition
		ParametreType valeurParametre = null;
		if (bCorrespondanceOk) {
			String tradConfValeur = inputDynamicCommandeDTO.getValeurArtemis();
			valeurParametre = createParametre(inputDynamicCommandeDTO.getCle(), tradConfValeur);
			serviceManager.getLoggerManager().finer(CLASS_NAME, method, "La traduction " + inputDynamicCommandeDTO.getId() + " g�n�re le param�tre : " + valeurParametre.getCle() + " pour la ligne " + ligneCommande.getIdLigneCommande());
		}

		return valeurParametre;
	}

	/**
	 * @param commandeSagic the commande sagic
	 * @param commande la commande bolbec
	 * 
	 * @return ensemble de familles d'offre comm
	 */
	protected Set<String> getEnsembleFamilleOffreComm(CommandeSagic commandeSagic, Commande commande) {
		Set<String> famillesOffreCom = new HashSet<String>();

		// R�cup�ration de l'ensemble des lignes de commandes
		List<LigneCommandeType> lcs = new ArrayList<LigneCommandeType>(Arrays.asList(commande.getLigneCommande()));
		for (InstanceOffreGroupee iog : commande.getInstanceOffreGroupee()) {
			lcs.addAll(Arrays.asList(iog.getLigneCommande()));
		}

		// R�cup�ration de l'ensemble de familles d'offre comm
		String sFamilleOffreComm = StringUtils.EMPTY;
		for (LigneCommandeType lc : lcs) {
			sFamilleOffreComm = getFamilleOffreComm(lc);
			if (StringUtils.isNotBlank(sFamilleOffreComm)) {
				famillesOffreCom.add(sFamilleOffreComm);
			}
		}
		return famillesOffreCom;
	}

	/**
	 * @param commandeSagic the commande sagic
	 * @param commande la commande bolbec
	 * 
	 * @return ensemble de familles d'offre parc
	 */
	protected Set<String> getEnsembleFamilleOffreParc(CommandeSagic commandeSagic, Commande commande) {
		Set<String> famillesOffreParc = new HashSet<String>();

		// R�cup�ration de l'ensemble des lignes de commandes
		List<LigneCommandeType> lcs = new ArrayList<LigneCommandeType>(Arrays.asList(commande.getLigneCommande()));
		for (InstanceOffreGroupee iog : commande.getInstanceOffreGroupee()) {
			lcs.addAll(Arrays.asList(iog.getLigneCommande()));
		}

		// R�cup�ration de l'ensemble de familles d'offre Parc
		String sFamilleOffreParc = StringUtils.EMPTY;
		for (LigneCommandeType lc : lcs) {
			sFamilleOffreParc = getFamilleOffreParc(lc);
			if (StringUtils.isNotBlank(sFamilleOffreParc)) {
				famillesOffreParc.add(sFamilleOffreParc);
			}
		}
		return famillesOffreParc;
	}

	/**
	 * @param commandeSagic the commande sagic
	 * @param commande la commande bolbec
	 * @param ls la ligne de commande bolbec
	 * 
	 * @return la famille d'offre
	 */
	protected String getFamilleOffreComm(LigneCommandeType lc) {
		String sFamilleOffreComm = StringUtils.EMPTY;
		String idOffre = StringUtils.EMPTY;
		if (lc.getProduitServiceSouhaite() != null) {
			idOffre = lc.getProduitServiceSouhaite().getRefOffreCible();
		} else if (lc.getElementParcAffecte() != null) {
			idOffre = lc.getElementParcAffecte().getRefOffreExistante();
		}

		OffreDTO offre = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, idOffre);
		FamilleOffreComDTO familleOffreCom = serviceManager.getReferenceSpaceManager().findInReferenceSpace(FamilleOffreComDTO.class, offre.getFamilleOffreCom().getId());
		if (familleOffreCom != null) {
			sFamilleOffreComm = familleOffreCom.getValeurConstante();
		}

		return sFamilleOffreComm;
	}

	/**
	 * @param ls la ligne de commande bolbec
	 * 
	 * @return la famille d'offre
	 */
	protected String getFamilleOffreParc(LigneCommandeType lc) {
		String sFamilleOffreParc = StringUtils.EMPTY;
		String idOffre = StringUtils.EMPTY;
		if (lc.getProduitServiceSouhaite() != null) {
			idOffre = lc.getProduitServiceSouhaite().getRefOffreCible();
		} else if (lc.getElementParcAffecte() != null) {
			idOffre = lc.getElementParcAffecte().getRefOffreExistante();
		}

		OffreDTO offre = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, idOffre);
		FamilleOffreParcDTO familleOffreParc = serviceManager.getReferenceSpaceManager().findInReferenceSpace(FamilleOffreParcDTO.class, offre.getFamilleOffreParc().getId());
		if (familleOffreParc != null) {
			sFamilleOffreParc = familleOffreParc.getId();
		}

		return sFamilleOffreParc;
	}
}