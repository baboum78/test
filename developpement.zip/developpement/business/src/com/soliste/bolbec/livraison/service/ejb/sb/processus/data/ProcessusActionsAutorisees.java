/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>13/01/2011</TD><TD>LBA</TD><TD>EV-000089: NSD+ Ajout bouton abandon provisoire</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe contenant les droits sur les processus. Ces droits sont uniquement les
 * droits relatifs aux donn�es. Il faut encore combiner ces droits avec les
 * habilitations de l'utilisateur et avec ceux li�s aux �crans pour obtenir
 * le droit final
 * 
 * @author rgvs7490
 */
public class ProcessusActionsAutorisees {

	private boolean complet;
	private boolean abandonnable;
	private boolean abandonnablePartiellement;
	private boolean abandonnableProvisoirement;
	private boolean suspendable;
	private boolean retablissable;
	private boolean stoppable;
	private boolean regularisable;

	/**
	 * 
	 * @param complet
	 * @param abandonnable
	 * @param abandonnablePartiellement
	 * @param suspendable
	 * @param retablissable
	 * @param stoppable
	 * @param regularisable
	 */
	public ProcessusActionsAutorisees(boolean complet, boolean abandonnable, boolean abandonnablePartiellement, boolean abandonnableProvisoirement, boolean suspendable, boolean retablissable, boolean stoppable, boolean regularisable) {
		this.complet = complet;
		this.abandonnable = abandonnable;
		this.abandonnablePartiellement = abandonnablePartiellement;
		this.abandonnableProvisoirement = abandonnableProvisoirement;
		this.suspendable = suspendable;
		this.retablissable = retablissable;
		this.stoppable = stoppable;
		this.regularisable = regularisable;
	}

	public boolean isComplet() {
		return this.complet;
	}

	public boolean isAbandonnable() {
		return this.abandonnable;
	}

	public boolean isAbandonnablePartiellement() {
		return this.abandonnablePartiellement;
	}

	public boolean isAbandonnableProvisoirement() {
		return abandonnableProvisoirement;
	}

	public boolean isRetablissable() {
		return this.retablissable;
	}

	public boolean isSuspendable() {
		return this.suspendable;
	}

	public boolean isRegularisable() {
		return regularisable;
	}

	public boolean isStoppable() {
		return stoppable;
	}
}
