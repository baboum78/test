package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.NoteRessourceTraitement;

public class NoteRessourceTraitementV2 extends NoteRessourceTraitement {

}
