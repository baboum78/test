package com.soliste.bolbec.livraison.service;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>28/04/2010</TD><TD>PHC</TD><TD>EV-000051: montee en debit </TD></TR>
 * <TR><TD>30/07/2010</TD><TD>GPA</TD><TD>EV-000053: FBN </TD></TR>
 * <TR><TD>17/04/2012</TD><TD>AGR</TD><TD>EV-000181: POR_ANTICIPE </TD></TR>
 * <TR><TD>18/07/2013</TD><TD>EBA</TD><TD>G8R2C2 EV-000234 : Ajout POR_FSIP/InstLocCommut</TD></TR>
 * <TR><TD>29/04/2014</TD><TD>GCL</TD><TD>G8R2C4 EV-000278 : Ajout CLE_POR_CU</TD></TR>
 * <TR><TD>14/08/2014</TD><TD>GCL</TD><TD>G8R2C5 EV-000303 : Ajout CLE_CCOM</TD></TR>
 * <TR><TD>17/03/2015</TD><TD>GCL</TD><TD>G8R2C7 EV-000314 : Ajout CLE_AVERTISSEMENT_IPON</TD></TR>
 * <TR><TD>14/11/2016</TD><TD>FCV</TD><TD>G9R2C1 EV-362_03 Ajout de la cl� ONT</TD></TR>
 * <TR><TD>11/10/2017</TD><TD>SMO</TD><TD>EV-431 : FTTE offre active sur RIP</TD></TR>
 * </TABLE>
 * 
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public interface ConstantesRessourcesTech {

	// Constantes correspondant aux cl�s
	String CLE_CATM = "CATM";
	String CLE_CATMMS = "CATMMS";
	String CLE_CBL = "CBL";
	String CLE_CBL_THD = "CBL_THD";
	String CLE_CBL_THD_MAN = "CBL_THD_MAN";
	String CLE_CCOM = "CCOM";
	String CLE_COMMUT = "COMMUT";
	String CLE_CSHD = "CSHD";
	String CLE_CSHD_THD = "CSHD_THD";
	String CLE_CSHD_EUA = "CSHD_EUA";
	String CLE_JONC = "JONC";
	String CLE_JONCBD = "JONCBD";
	String CLE_JONCDGP = "JONCDGP";
	String CLE_JONCDGTOT = "JONCDGTOT";
	String CLE_JONC_SANS_DGTOT = "JONC_SANS_DGTOT";
	String CLE_PORTABILITE = "PORTABILITE";
	String CLE_PORTB = "PORTB";
	String CLE_PORTBADSL = "PORTBADSL";
	String CLE_PORTBBASDEBIT = "PORTBBASDEBIT";
	String CLE_PORTBADSLBROCHE= "PORTBADSL/BROCHE";
	String CLE_PORTBADSLREGLETTE= "PORTBADSL/REGLETTE";
	String CLE_PORTBBD = "PORTBBD";
	String CLE_PORTBBDetDGTOT = "PORTBBDetDGTOT";
	String CLE_PORTBBDetDG = "PORTBBDetDG";
	String CLE_PORTBDG = "PORTBDG";
	String CLE_PORTBDGP = "PORTBDGP";
	String CLE_PORTBDGTOT = "PORTBDGTOT";
	String CLE_RESS_CLI_PMC = "RESSCLIPMC";
	String CLE_RESS_INTERV = "RESS_INTERV";
	String CLE_CBL_CENTRE_TRANSPORT = "CBL/CentreTransport";
	String CLE_CBL_CNATL = "CBL/CNATL";
	String CLE_CBL_CCENT = "CBL/CCENT";
	String CLE_CBL_CATRAC = "CBL/CATRAC";
	String CLE_CBL_CUC = "CBL/CodeUC";
	String CLE_CBL_NE = "CBL/NE";
	String CLE_CBL_SERV_SUPP_BD = "CBL/ServSuppBD";
	String CLE_CBL_INST_LOC_COMMUT = "CBL/InstLocCommut";
	String CLE_CBL_CTYPO = "CBL/CTYPO";
	String CLE_CBL_SERVADDBD = "CBL/ServAddBD";
	String CLE_CBL_CCOM = "CBL/CCOM";
	String CLE_POR_SECH = "POR_SECH";
	String CLE_POR_FSIP = "POR_FSIP";
	String CLE_POR_FSIP_INST_LOC_COMMUT = "POR_FSIP/InstLocCommut";
	String CLE_X_NUMREF = "/NumRef";
	String CLE_X_CNATL = "/CNATL";
	String CLE_X_CCENT = "/CCENT";
	String CLE_X_CATRAC = "/CATRAC";
	String CLE_X_CUC = "/CodeUC";
	String CLE_X_NE = "/NE";
	String CLE_X_SERV_SUPP_BD = "/ServSuppBD";
	String CLE_X_INST_LOC_COMMUT = "/InstLocCommut";
	String CLE_X_CTYPO = "/CTYPO";
	String CLE_X_SERVADDBD = "/ServAddBD";
	String CLE_X_CCOM = "/CCOM";
	// EV-000051
	String CLE_CBL_CENTRE_TRANSPORTSRHD = "CBL/CentreTransportSRHD";
	String CLE_CBL_CCOMSRHD = "CBL/CCOMSRHD";

	// EV-000181
	String CLE_POR_ANTICIPE = "POR_ANTICIPE";

	// EV-000188
	String CLE_JONCO_FOURNISSEUR = "JONCO_FOURNISSEUR";
	String CLE_JONCO = "JONCO";

	// EV-000278
	String CLE_POR_CU = "POR_CU";

	// EV-000314
	String CLE_AVERTISSEMENT_IPON = "AvertissementIPON";

	// EV-362_03
	String CLE_ONT = "ONT";

	// EV-431
	String CLE_TETE_NRO = "TETE_NRO";

}
