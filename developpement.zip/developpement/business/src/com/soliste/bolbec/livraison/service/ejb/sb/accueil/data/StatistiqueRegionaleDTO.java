/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : StatistiqueDTO.java
 *   Revision  : 06_00#1
 *   DateRev   : 13-JAN-2006 11:34:36
 *   Chemin    : ARTE/developpement/ihm/src.ejb/bolbec/ihm/livraison/accueil/data/StatistiqueDTO.java
 * --------------------------------------------
 *   Historique  : 
 *    Revision 06_00#1 (CREE)
 *      Created:  13-JAN-2006 11:34:36 RGVS7490
 *        creation
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.accueil.data;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.model.DrDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE>
 * 
 * @author edba8262
 */
public class StatistiqueRegionaleDTO implements Serializable {

	private DrDTO dr;
	private Map<String, Integer> valeursParCle;
	private Date jour;

	/**
	 * 
	 * @param cle
	 * @param valeur
	 * @param dr
	 * @param jour
	 */
	public StatistiqueRegionaleDTO(String cle, Integer valeur, DrDTO dr, Long jour) {
		this.dr = dr;
		this.valeursParCle = new HashMap<String, Integer>();
		this.putValeurParCle(cle, valeur);
		this.jour = DateUtils.getDatabaseDate(jour);
	}

	public DrDTO getDr() {
		return this.dr;
	}

	void setDr(DrDTO dr) {
		this.dr = dr;
	}

	public Map<String, Integer> getValeursParCle() {
		return this.valeursParCle;
	}

	public void setValeursParCle(Map<String, Integer> valeursParCle) {
		this.valeursParCle = valeursParCle;
	}

	/**
	 * 
	 * @param cle
	 * @param valeur
	 */
	public void putValeurParCle(String cle, int valeur) {
		valeursParCle.put(cle, new Integer(valeur));
	}

	/**
	 * 
	 * @param cle
	 * @return
	 */
	public int getValeur(String cle) {
		return valeursParCle.get(cle);
	}

	public Integer getNOMBRE_COMMANDES_CREEES() {
		return valeursParCle.get(StatistiqueConstantes.NOMBRE_COMMANDES_CREEES);
	}

	public Integer getNOMBRE_COMMANDES_SOLDEES() {
		return valeursParCle.get(StatistiqueConstantes.NOMBRE_COMMANDES_SOLDEES);
	}

	public Integer getNOMBRE_COMMANDES_SOLDEES_SANS_AVP() {
		return valeursParCle.get(StatistiqueConstantes.NOMBRE_COMMANDES_SOLDEES_SANS_AVP);
	}

	public Integer getNOMBRE_COMMANDES_ANNULEES() {
		return valeursParCle.get(StatistiqueConstantes.NOMBRE_COMMANDES_ANNULEES);
	}

	public Integer getNOMBRE_COMMANDES_EN_TACHE_MANUELLE() {
		return valeursParCle.get(StatistiqueConstantes.NOMBRE_COMMANDES_EN_TACHE_MANUELLE);
	}

	public Integer getNOMBRE_COMMANDES_EN_AVP() {
		return valeursParCle.get(StatistiqueConstantes.NOMBRE_COMMANDES_EN_AVP);
	}

	public Integer getNOMBRE_TACHES_AUTO_EN_COURS() {
		return valeursParCle.get(StatistiqueConstantes.NOMBRE_TACHES_AUTO_EN_COURS);
	}

	public Date getJour() {
		return this.jour;
	}

	public void setJour(Date jour) {
		this.jour = jour;
	}
}