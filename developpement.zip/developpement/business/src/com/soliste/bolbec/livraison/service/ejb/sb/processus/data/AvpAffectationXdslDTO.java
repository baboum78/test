/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Les infos d'AVP pour les AVP de type "AVPAffectationXDSL"
 * 
 * @author rgvs7490
 */
public class AvpAffectationXdslDTO extends AvpInfoDTO {

	private String centre;
	private String reglette;
	private String broche;
	private String vcOperateur;
	private String vcCible;

	/**
	 * 
	 */
	AvpAffectationXdslDTO() {
	}

	public String getType() {
		return AVP_AFFECTATION_XDSL_TYPE;
	}

	public String getBroche() {
		return this.broche;
	}

	void setBroche(String broche) {
		this.broche = broche;
	}

	public String getCentre() {
		return this.centre;
	}

	void setCentre(String centre) {
		this.centre = centre;
	}

	public String getReglette() {
		return this.reglette;
	}

	void setReglette(String reglette) {
		this.reglette = reglette;
	}

	public String getVcCible() {
		return this.vcCible;
	}

	void setVcCible(String vcCible) {
		this.vcCible = vcCible;
	}

	public String getVcOperateur() {
		return this.vcOperateur;
	}

	void setVcOperateur(String vcOperateur) {
		this.vcOperateur = vcOperateur;
	}
}
