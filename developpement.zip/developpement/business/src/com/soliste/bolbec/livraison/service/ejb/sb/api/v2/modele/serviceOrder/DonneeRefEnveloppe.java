package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder;

import java.util.ArrayList;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "donneeRefEnveloppe")
public class DonneeRefEnveloppe {

	@XmlElement(name = "donneeRef")
	private ArrayList<DonneeRef> donneeRef;

	public ArrayList<DonneeRef> getDonneeRef() {
		return donneeRef;
	}

	public void setDonneeRef(ArrayList<DonneeRef> donneeRef) {
		this.donneeRef = donneeRef;
	}

}
