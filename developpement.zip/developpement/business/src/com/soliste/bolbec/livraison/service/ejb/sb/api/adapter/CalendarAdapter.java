package com.soliste.bolbec.livraison.service.ejb.sb.api.adapter;

import java.text.ParseException;
import java.util.Calendar;
import java.util.GregorianCalendar;

import javax.xml.bind.annotation.adapters.XmlAdapter;

import org.codehaus.jackson.map.util.ISO8601DateFormat;
import org.codehaus.jackson.map.util.ISO8601Utils;

/**
 * Classe de gestion des dates
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/02/2016</TD><TD>BPE</TD><TD>EV-000353 : Ajout Adapter pour les calendar</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
public class CalendarAdapter extends XmlAdapter<String, Calendar> {

	/**
	 * Format choisi pour l'API
	 */
	private ISO8601DateFormat df = new ISO8601DateFormat();

	/**
	 * Transforme la date ISO-8601 en objet Calendar
	 * 
	 * @param date la date au format ISO-8601
	 * @throws ParseException
	 */
	@Override
	public Calendar unmarshal(String date) throws ParseException {
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(df.parse(date));
		return cal;
	}

	/**
	 * Transforme l'objet Calendar en date ISO-8601
	 * 
	 * @param calendar l'objet calendar � convertir en chaine de caract�res
	 */
	@Override
	public String marshal(Calendar calendar) {
		return ISO8601Utils.format(calendar.getTime(), false, calendar.getTimeZone());
	}

}
