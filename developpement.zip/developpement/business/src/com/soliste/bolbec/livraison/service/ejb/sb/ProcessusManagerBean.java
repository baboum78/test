/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.model.AttenduDTO;
import com.soliste.bolbec.livraison.service.model.CatalogueActiviteDTO;
import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.PredossierDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusLcDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusSuspendusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.Attendu;
import aps.AttenduHome;
import aps.EtatProcessusConstantes;
import aps.Evt;
import aps.EvtHome;
import aps.LigneCommande;
import aps.LigneCommandeHome;
import aps.Predossier;
import aps.PredossierHome;
import aps.Processus;
import aps.ProcessusHome;
import aps.ProcessusLC;
import aps.ProcessusLCHome;
import aps.ProcessusSuspendus;
import aps.ProcessusSuspendusHome;
import aps.Tache;
import aps.TacheEnCours;
import aps.TacheEnCoursHome;
import aps.TacheHome;

/**
 * Impl�mentation de l'EJB session ProcessusManager.
 * 
 * @see {@link com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager}
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>18/10/2010</TD><TD>DBA</TD><TD>IRMA_232 : optimisation finder</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>30/07/2012</TD><TD>BPE</TD><TD>EV-184 : ajout des m�thodes filtrerEvtByTypeEvenement et recupererEvtPlusRecente</TD></TR>
 * <TR><TD>27/05/2013</TD><TD>GPA</TD><TD>G8R2C2 � Tech : Passage du type de transaction des m�thodes des EJB Remote en RequiresNew</TD></TR>
 * <TR><TD>29/05/2013</TD><TD>EBA</TD><TD>G8R2C2 BackOffice : Cr�ation methodes necessaires avec NewTransaction</TD></TR>
 * <TR><TD>29/04/2016</TD><TD>JDE</TD><TD>Ajout de la m�thode findTacheByLibelleCourtAndProcessus</TD></TR>
 * </TABLE><BR>
 */
public class ProcessusManagerBean extends FwkSessionBean implements ProcessusManager, IProcessusManagerRemote {
	/**
	 * UID
	 */
	private static final long serialVersionUID = -9056965252587199699L;

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = ProcessusManagerBean.class.getName();
	private static final String LOG_MESSAGE_DEBUT_TRAITEMENT = "Debut du traitement.";
	private static final String LOG_MESSAGE_FIN_TRAITEMENT = "Fin du traitement.";
	private static final String LOG_MESSAGE_ERR_TRAITEMENT = "Erreur dans le traitement. ";
	public static final String NON_TROUVEE = " non trouv�e";

	/** The processus home. */
	private ProcessusHome processusHome;

	/** The processus lc home. */
	private ProcessusLCHome processusLCHome;

	/** The processus Suspendus home. */
	private ProcessusSuspendusHome processusSuspendusHome;

	/** The ligne commande home. */
	private LigneCommandeHome ligneCommandeHome;

	/** The tache home. */
	private TacheHome tacheHome;

	/** The tache en cours home. */
	private TacheEnCoursHome tacheEnCoursHome;

	/** The evt home. */
	private EvtHome evtHome;

	/** The attendu home. */
	private AttenduHome attenduHome;

	/** The predossier home. */
	private PredossierHome predossierHome;


	/** Le service manager */
	protected IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			processusHome = getEntityHome(ProcessusHome.class);
			processusLCHome = getEntityHome(ProcessusLCHome.class);
			processusSuspendusHome = getEntityHome(ProcessusSuspendusHome.class);
			ligneCommandeHome = getEntityHome(LigneCommandeHome.class);
			tacheHome = getEntityHome(TacheHome.class);
			tacheEnCoursHome = getEntityHome(TacheEnCoursHome.class);
			evtHome = getEntityHome(EvtHome.class);
			attenduHome = getEntityHome(AttenduHome.class);
			predossierHome = getEntityHome(PredossierHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	// --------------------------------------------------------------
	// PROCESSUS
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#getProcessus(java.lang.String)
	 */
	public ProcessusDTO getProcessus(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getProcessus", "Recherche processus " + processusId);
		try {
			Processus processus = getProcessusEntity(processusId);
			return new ProcessusDTO(processus);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getProcessus", "Pas de processus avec id = " + processusId, fe);
			return null;
		}
	}

	/**
	 * Gets the processus entity.
	 * 
	 * @param id the processus id
	 * 
	 * @return the processus entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Processus getProcessusEntity(String id) throws FinderException {
		return processusHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateProcessusBp(com.soliste.bolbec.livraison.service.model.ProcessusDTO)
	 */
	public void updateProcessusBp(ProcessusDTO processusDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateProcessusBp", "Mise � jour du processus " + processusDTO.getId());
		try {
			Processus processus = getProcessusEntity(processusDTO.getId());
			processus.setBPIID(processusDTO.getBpiid());
			processus.setBPName(processusDTO.getBpName());
			long timestamp = processus.getTimestamp() + 1;
			processus.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateProcessusBp", "Probl�me de mise � jour du processus = " + processusDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateProcessusModifManuelleEtat(com.soliste.bolbec.livraison.service.model.ProcessusDTO)
	 */
	public void updateProcessusModifManuelleEtat(ProcessusDTO processusDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateProcessusModifManuelleEtat", "Mise � jour du processus " + processusDTO.getId());
		try {
			Processus processus = getProcessusEntity(processusDTO.getId());
			processus.setModifManuelleEtat(processusDTO.getModifManuelleEtat());
			long timestamp = processus.getTimestamp() + 1;
			processus.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateProcessusModifManuelleEtat", "Probl�me de mise � jour du processus = " + processusDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateProcessusAppeleParTache(com.soliste.bolbec.livraison.service.model.ProcessusDTO)
	 */
	public void updateProcessusAppeleParTache(ProcessusDTO processusDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateProcessusAppeleParTache", "Mise � jour du processus " + processusDTO.getId());
		try {
			Processus processus = getProcessusEntity(processusDTO.getId());
			Tache tache = getTacheEntity(processusDTO.getAppelleParTacheId());
			processus.setLinkAppelleParTache(tache);
			long timestamp = processus.getTimestamp() + 1;
			processus.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateProcessusAppeleParTache", "Probl�me de mise � jour du processus = " + processusDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateProcessusEtat(com.soliste.bolbec.livraison.service.model.ProcessusDTO)
	 */
	public void updateProcessusEtat(ProcessusDTO processusDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateProcessusEtat", "Mise � jour du processus  " + processusDTO.getId());
		try {
			Processus processus = getProcessusEntity(processusDTO.getId());
			processus.setEstEtatProcessus(processusDTO.getEtatProcessus().getId());
			long timestamp = processus.getTimestamp() + 1;
			processus.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateProcessusEtat", "Probl�me de mise � jour du processus = " + processusDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateProcessusAnnuleParProcessus(com.soliste.bolbec.livraison.service.model.ProcessusDTO)
	 */
	public void updateProcessusAnnuleParProcessus(ProcessusDTO processusDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateProcessusAnnuleParProcessus", "Mise � jour du processus  " + processusDTO.getId());
		try {
			Processus processus = getProcessusEntity(processusDTO.getId());
			processus.setLinkAnnuleParProcessus(processusDTO.getAnnuleParProcessus() != null ? getProcessusEntity(processusDTO.getAnnuleParProcessus().getId()) : null);
			long timestamp = processus.getTimestamp() + 1;
			processus.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateProcessusAnnuleParProcessus", "Probl�me de mise � jour du processus = " + processusDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateProcessusIdCommande(String, String)
	 */
	public void updateProcessusIdCommande(String idProcessus, String idCommande) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateProcessusIdCommande", "Mise � jour du processus  " + idProcessus);
		try {
			Processus processus = getProcessusEntity(idProcessus);
			processus.setPourCommande(idCommande);
			long timestamp = processus.getTimestamp() + 1;
			processus.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateProcessusAnnuleParProcessus", "Probl�me de mise � jour du processus = " + idProcessus, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createProcessus(com.soliste.bolbec.livraison.service.model.ProcessusDTO)
	 */
	public ProcessusDTO createProcessus(ProcessusDTO processusDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createProcessus", "Cr�ation du processus  " + processusDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(Processus.FIELD_DATE_CREATION, processusDTO.getDatabaseDateDateCreation());
		values.put(Processus.FIELD_MODIF_MANUELLE_ETAT, processusDTO.getModifManuelleEtat());
		values.put(Processus.FIELD_B_P_I_I_D, processusDTO.getBpiid());
		values.put(Processus.FIELD_B_P_NAME, processusDTO.getBpName());
		if (processusDTO.getProcessusType() != null) {
			values.put(Processus.FIELD_INSTANCIE_PROCESSUS_TYPE, processusDTO.getProcessusType().getId());
		}
		if (processusDTO.getEtatProcessus() != null) {
			values.put(Processus.FIELD_EST_ETAT_PROCESSUS, processusDTO.getEtatProcessus().getId());
		}
		if (processusDTO.getParamInstanciation() != null) {
			values.put(Processus.FIELD_A_POUR_PARAM_INSTANCIATION, processusDTO.getParamInstanciation().getId());
		}
		ProcessusDTO genereParProcessusDTO = processusDTO.getGenereParProcessus();
		if (genereParProcessusDTO != null && StringUtils.isNotBlank(genereParProcessusDTO.getId())) {
			values.put(Processus.SLINK_GENERE_PAR_PROCESSUS, genereParProcessusDTO.getId());
		}
		String tacheId = processusDTO.getAppelleParTacheId();
		if (StringUtils.isNotBlank(tacheId)) {
			values.put(Processus.SLINK_APPELLE_PAR_TACHE, tacheId);
		}
		ProcessusDTO annuleParProcessusDTO = processusDTO.getAnnuleParProcessus();
		if (annuleParProcessusDTO != null && StringUtils.isNotBlank(annuleParProcessusDTO.getId())) {
			values.put(Processus.SLINK_ANNULE_PAR_PROCESSUS, annuleParProcessusDTO.getId());
		}
		values.put(Processus.FIELD_POUR_COMMANDE, processusDTO.getIdCommande());
		String processusId = processusDTO.getId();
		try {
			Processus processus = processusHome.create(processusId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			processus.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createProcessus", "Erreur cr�ation du processus " + processusId, ce);
			throw new EJBException(ce);
		}
		return processusDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusAppelerParTache(java.lang.String)
	 */
	public List<ProcessusDTO> findProcessusAppelerParTache(String tacheId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusAppelerParTache", "Recherche de processus appele par la tache processus " + tacheId);
		List<ProcessusDTO> processusDTOs = new ArrayList<ProcessusDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Processus> processuses = processusHome.findByAppelleParTache(tacheId);
			for (Processus processus : processuses) {
				processusDTOs.add(new ProcessusDTO(processus));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusAppelerParTache", "Pas de Processus appele par la tache " + tacheId, fe);
			throw new EJBException(fe);
		}
		return processusDTOs;
	}


	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByTacheId(String) 
	 */
	public ProcessusDTO findProcessusByTacheId(String tacheId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusByTacheId", "Recherche de processus qui a appell� la tache " + tacheId);
		ProcessusDTO processusDTO = null;
		try {
			@SuppressWarnings("unchecked")
			Processus processus = (Processus) CollectionUtils.getFirstOrNull(processusHome.findByTacheId(tacheId));
			if ( processus != null ) {
				processusDTO = new ProcessusDTO(processus);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusByTacheId", "Pas de Processus appele par la tache " + tacheId, fe);
			throw new EJBException(fe);
		}
		return processusDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByEvtId(String)
	 */
	public ProcessusDTO findProcessusByEvtId(String evtId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusByEvtId", "Recherche de processus qui a provoqu� l'�v�nement  " + evtId);
		ProcessusDTO processusDTO = null;
		try {
			@SuppressWarnings("unchecked")
			Processus processus = (Processus) CollectionUtils.getFirstOrNull(processusHome.findByEvtId(evtId));
			if ( processus != null ) {
				processusDTO = new ProcessusDTO(processus);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusByEvtId", "Pas de Processus a provoqu� l'�v�nement " + evtId, fe);
			throw new EJBException(fe);
		}
		return processusDTO;
	}



	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByEtatAndAppelerParTache(java.lang.String, java.lang.String)
	 */
	public List<ProcessusDTO> findProcessusByEtatAndAppelerParTache(String etatId, String tacheId) {
		// FIXME OLD: GTA Finder appropri�
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusByEtatAndAppelerParTache", "Recherche de processus appele par la tache processus " + tacheId + " et etat " + etatId);
		List<ProcessusDTO> processusDTOs = new ArrayList<ProcessusDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Processus> processuses = processusHome.findByAppelleParTache(tacheId);
			for (Processus processus : processuses) {
				if (StringUtils.equals(processus.getEstEtatProcessus(), etatId)) {
					processusDTOs.add(new ProcessusDTO(processus));
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusAppelerParTache", "Probleme lors de la recherche de processus appele par la tache processus " + tacheId + " et etat " + etatId, fe);
			throw new EJBException(fe);
		}
		return processusDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusParRefExterneLigneCommandeEtType(java.lang.String, java.lang.String)
	 */
	public ProcessusDTO findProcessusParRefExterneLigneCommandeEtType(String refExterneLigneCommande, String typeProcessusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusParRefExterneLigneCommandeEtType", "Recherche de processus pour la ligne de commande de refExterne : " + refExterneLigneCommande + " et type : " + typeProcessusId);
		ProcessusDTO processusDTO = null;
		try {
			@SuppressWarnings("unchecked")
			Collection<Processus> processuses = processusHome.findParRefExtLigneCmdEtType(refExterneLigneCommande, typeProcessusId);
			if (!processuses.isEmpty()) {
				processusDTO = new ProcessusDTO(processuses.iterator().next());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusParRefExterneLigneCommandeEtType",
					"Probleme lors de la recherche de processus pour la ligne de commande de refExterne : " + refExterneLigneCommande + " et type : " + typeProcessusId, fe);
			throw new EJBException(fe);
		}
		return processusDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(java.lang.String)
	 */
	public ProcessusDTO findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(String commandeId) {
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCommande> lignesCommande = ligneCommandeHome.findParCde(commandeId);
			for (LigneCommande ligneCommande : lignesCommande) {
				@SuppressWarnings("unchecked")
				Collection<ProcessusLC> processusLCs = ligneCommande.getLinkEstLivreParProcessus();
				for (ProcessusLC processusLC : processusLCs) {
					Processus processus = processusLC.getLinkEstLivreParProcessus();
					String etatProcessus = processus.getEstEtatProcessus();
					if ((!EtatProcessusConstantes.ANNUL.equals(etatProcessus) && !EtatProcessusConstantes.TERM.equals(etatProcessus)) && processus.getLinkGenereParProcessus() == null) {
						return new ProcessusDTO(processus);
					}
				}
			}
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		return null;
	}


	// --------------------------------------------------------------
	// TACHE
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#getTache(java.lang.String)
	 */
	public TacheDTO getTache(String tacheId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getTache", "Recherche de la tache  " + tacheId);
		try {
			Tache tache = getTacheEntity(tacheId);
			return new TacheDTO(tache);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getTache", "Probleme de recuperation de la tache = " + tacheId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#getTache(java.lang.String, boolean)
	 */
	public TacheDTO getTache(String tacheId, boolean bIncludeReferences) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getTache", "Recherche de la tache " + tacheId + " avec r�f�rences "+ bIncludeReferences);
		try {
			Tache tache = getTacheEntity(tacheId);
			return new TacheDTO(tache, bIncludeReferences);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getTache", "Probleme de recuperation de la tache = " + tacheId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheByEvt(java.lang.String)
	 */
	public TacheDTO findTacheByEvt(String evtId) {
		TacheDTO tacheDTO = null;
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTacheByEvt", "Recherche de tache pour l'evt " + evtId);
		try {
			Evt evt = getEvtEntity(evtId);
			Tache tache = evt.getLinkPourTache();
			if ( tache != null ) {
				tacheDTO =  new TacheDTO(tache);
			}
			return tacheDTO;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheByEvt", "Pas de Tache pour l'evt = " + evtId, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheByEvt(java.lang.String)
	 */
	public TacheDTO findTacheByEvt(String evtId, boolean bIncludeReferences) {
		TacheDTO tacheDTO = null;
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTacheByEvt", "Recherche de tache pour l'evt " + evtId  + " avec r�f�rences "+ bIncludeReferences);
		try {
			Evt evt = getEvtEntity(evtId);
			Tache tache = evt.getLinkPourTache();
			if ( tache != null ) {
				tacheDTO =  new TacheDTO(tache, bIncludeReferences);
			}
			return tacheDTO;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheByEvt", "Pas de Tache pour l'evt = " + evtId, fe);
			throw new EJBException(fe);
		}
	}



	/**
		 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheByLanceParProcessus(java.lang.String)
		 */
	public List<TacheDTO> findTacheByLanceParProcessus(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTacheByLanceParProcessus", "Recherche de tache appele par le processus  " + processusId);
		List<TacheDTO> tacheDTOs = new ArrayList<TacheDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Tache> taches = tacheHome.findByLanceParProcessus(processusId);
			for (Tache tache : taches) {
				tacheDTOs.add(new TacheDTO(tache));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheByLanceParProcessus", "Pas de Tache avec le processus = " + processusId, fe);
			throw new EJBException(fe);
		}
		return tacheDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheByLanceParProcessusRangeParDate(java.lang.String)
	 */
	public List<TacheDTO> findTacheByLanceParProcessusRangeParDate(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTacheByLanceParProcessusRangeParDate", "Recherche de tache appele par le processus  " + processusId);
		List<TacheDTO> tacheDTOs = new ArrayList<TacheDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Tache> taches = tacheHome.findByLanceParProcessus(processusId);
			for (Tache tache : taches) {
				tacheDTOs.add(new TacheDTO(tache));
			}

			// Range
			Collections.sort(tacheDTOs, new TacheDTO.SortByDateComparator());
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().finer(CLASSNAME, "findTacheByLanceParProcessusRangeParDate", "Pas de Tache avec le processus = " + processusId, fe);
			throw new EJBException(fe);
		}
		return tacheDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheByLanceParProcessusAndIdExterneRangeParDate(String, String)
	 */
	// TODO G10 : Cr�er un finder sur MagicDraw
	public List<TacheDTO> findTacheByLanceParProcessusAndIdExterneRangeParDate(String processusId, String tacheIdExterne) {
		final String methodName = "findTacheByLanceParProcessusAndIdExterneRangeParDate";

		// Log de d�but
		serviceManager.getLoggerManager().finest(CLASSNAME, methodName, LOG_MESSAGE_DEBUT_TRAITEMENT);

		List<TacheDTO> tacheDTOs = new ArrayList<TacheDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Tache> taches = tacheHome.findByLanceParProcessus(processusId);
			for (Tache tache : taches) {
				TacheDTO tacheDTO = new TacheDTO(tache);
				if (StringUtils.equals(tacheDTO.getIdExterne(), tacheIdExterne)) {
					tacheDTOs.add(tacheDTO);
				}
			}

			// Range
			Collections.sort(tacheDTOs, new TacheDTO.SortByDateComparator());

			// Log de l'op�ration
			serviceManager.getLoggerManager().finer(CLASSNAME, methodName, "R�cup�ration de " + tacheDTOs.size() + " t�ches.");
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().finer(CLASSNAME, methodName, "Pas de Tache avec le processus = " + processusId, fe);
			throw new EJBException(fe);
		}
		// Log de fin
		serviceManager.getLoggerManager().finest(CLASSNAME, methodName, LOG_MESSAGE_FIN_TRAITEMENT);
		return tacheDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheByLibelleCourtAndProcessus(java.lang.String, java.lang.String)
	 */
	public List<TacheDTO> findTacheByLibelleCourtAndProcessus(String libelleCourt, String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTacheByLibelleCourtAndProcessus", "Recherche des taches avec le libelle court " + libelleCourt + " et appelees par le processus " + processusId);
		List<TacheDTO> tacheDTOs = new ArrayList<TacheDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Tache> taches = tacheHome.findByLanceParProcessus(processusId);
			for (Tache tache : taches) {
				if (StringUtils.equals(libelleCourt, tache.getLibelleCourt())) {
					tacheDTOs.add(new TacheDTO(tache));
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheByLibelleCourtAndProcessus", "Pas de taches avec le libelle court " + libelleCourt + " et le processus " + processusId, fe);
			throw new EJBException(fe);
		}
		return tacheDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheByDifferentIdAndLibelleCourtAndProcessusAndSortReverseDPMAD(java.lang.String, java.lang.String, java.lang.String)
	 */
	public TacheDTO findTacheByDifferentIdAndLibelleCourtAndProcessusAndSortReverseDPMAD(String tacheId, String tacheLibelleCourt, String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTacheByDifferentIdAndLibelleCourtAndSortReverseDPMAD", "Recherche de la derniere tache qui a un id diff�rent de " + tacheId + " et un libelle court " + tacheLibelleCourt);
		try {
			@SuppressWarnings("unchecked")
			Collection<Tache> taches = tacheHome.findByDifferentIdAndLibelleCourtAndProcessusAndSortReverseDPMAD(tacheId, tacheLibelleCourt, processusId);
			// FIXME OLD: GTA ce finder ne trie pas dans le bon sens !!!!!!!!!!!!
			int tailleCollections = taches.size();
			if (tailleCollections != 0) {
				Tache[] tacheArray = new Tache[tailleCollections];
				tacheArray = taches.toArray(tacheArray);
				return new TacheDTO(tacheArray[tailleCollections - 1]);
			}
			return null;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheByDifferentIdAndLibelleCourtAndSortReverseDPMAD",
					"Probleme lors de la recherche de la derniere tache qui a un id diff�rent de " + tacheId + " et un libelle court " + tacheLibelleCourt, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateTache(com.soliste.bolbec.livraison.service.model.TacheDTO)
	 */
	public void updateTache(TacheDTO tacheDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateTache", "Mise � jour de la tache " + tacheDTO.getId());
		try {
			Tache tache = getTacheEntity(tacheDTO.getId());
			tache.setCleVariante(tacheDTO.getCleVariante());
			tache.setDateFinReelle(tacheDTO.getDatabaseDateDateFinReelle());
			tache.setDatePremiereExecution(tacheDTO.getDatabaseDateDatePremiereExecution());
			tache.setDatePremiereMADispo(tacheDTO.getDatabaseDateDatePremiereMADispo());
			tache.setDateProgrammation(tacheDTO.getDatabaseDateDateProgrammation());
			tache.setESD(tacheDTO.getEsd());
			CatalogueTacheDTO catalogueTacheDTO = tacheDTO.getCatalogueTache();
			if (catalogueTacheDTO != null) {
				tache.setEstTypeCatalogueTache(catalogueTacheDTO.getId());
			}
			tache.setIdExterne(tacheDTO.getIdExterne());
			tache.setIndicateurFin(tacheDTO.getIndicateurFin());
			tache.setLibelle(tacheDTO.getLibelle());
			tache.setLibelleCourt(tacheDTO.getLibelleCourt());
			tache.setNbRejeux(tacheDTO.getNbRejeux());
			tache.setOFD(tacheDTO.getOfd());
			tache.setValeurVariante(tacheDTO.getValeurVariante());
			tache.setLibelleIHM(tacheDTO.getLibelleIHM());
			tache.setIndicateurFinIHM(tacheDTO.getIndicateurFinIHM());
			AgentDTO agentDTO = tacheDTO.getRealiseeParAgent();
			if (agentDTO != null) {
				tache.setRealiseeParAgent(agentDTO.getId());
			}
			RoleDTO roleDTO = tacheDTO.getFaitParRole();
			if (roleDTO != null) {
				tache.setFaitParRole(roleDTO.getId());
			}
			ProcessusDTO lanceParProcessusDTO = tacheDTO.getLancerParProcessus();
			if (lanceParProcessusDTO != null && StringUtils.isNotBlank(lanceParProcessusDTO.getId())) {
				Processus lanceParProcessus = getProcessusEntity(lanceParProcessusDTO.getId());
				tache.setLinkLanceParProcessus(lanceParProcessus);
			}
			EvtDTO evtDTO = tacheDTO.getEvt();
			if (evtDTO != null && StringUtils.isNotBlank(evtDTO.getId())) {
				Evt evt = getEvtEntity(evtDTO.getId());
				tache.setLinkDeclencheParEvt(evt);
			}
			long timestamp = tache.getTimestamp() + 1;
			tache.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateTache", "Probleme de mise � jour de la tache = " + tacheDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateTacheLieeATache(com.soliste.bolbec.livraison.service.model.TacheDTO)
	 */
	public void updateTacheLieeATache(TacheDTO tacheDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateTacheLieeATache", "Mise � jour de la tache " + tacheDTO.getId());
		try {
			Tache tache = getTacheEntity(tacheDTO.getId());
			TacheDTO lieeATacheDTO = tacheDTO.getLieeATacheDTO();
			if (lieeATacheDTO != null && StringUtils.isNotBlank(lieeATacheDTO.getId())) {
				Tache lieeATache = getTacheEntity(lieeATacheDTO.getId());
				tache.setLinkLieeATache(lieeATache);
				long timestamp = tache.getTimestamp() + 1;
				tache.setTimestamp(timestamp);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateTacheLieeATache", "Probleme de mise � jour de la tache = " + tacheDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateTacheVariante(com.soliste.bolbec.livraison.service.model.TacheDTO)
	 */
	public void updateTacheVariante(TacheDTO tacheDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateTacheVariante", "Mise � jour de la tache " + tacheDTO.getId());
		try {
			Tache tache = getTacheEntity(tacheDTO.getId());
			tache.setCleVariante(tacheDTO.getCleVariante());
			tache.setValeurVariante(tacheDTO.getValeurVariante());
			long timestamp = tache.getTimestamp() + 1;
			tache.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateTacheVariante", "Probleme de mise � jour de la tache = " + tacheDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * 
	 * @inherit com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateTacheFaitParRole(com.soliste.bolbec.livraison.service.model.TacheDTO)
	 */
	public void updateTacheFaitParRole(TacheDTO tacheDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateTacheFaitParRole", "Mise � jour de la tache " + tacheDTO.getId());
		try {
			Tache tache = getTacheEntity(tacheDTO.getId());
			RoleDTO roleDTO = tacheDTO.getFaitParRole();
			if (roleDTO != null) {
				tache.setFaitParRole(roleDTO.getId());
				long timestamp = tache.getTimestamp() + 1;
				tache.setTimestamp(timestamp);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateTacheFaitParRole", "Probleme de mise � jour de la tache = " + tacheDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createTache(com.soliste.bolbec.livraison.service.model.TacheDTO)
	 */
	public TacheDTO createTache(TacheDTO tacheDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createTache", "Cr�ation de la tache " + tacheDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(Tache.FIELD_LIBELLE, tacheDTO.getLibelle());
		values.put(Tache.FIELD_ID_EXTERNE, tacheDTO.getIdExterne());
		values.put(Tache.FIELD_DATE_PROGRAMMATION, tacheDTO.getDatabaseDateDateProgrammation());
		values.put(Tache.FIELD_E_S_D, tacheDTO.getEsd());
		values.put(Tache.FIELD_DATE_PREMIERE_M_A_DISPO, tacheDTO.getDatabaseDateDatePremiereMADispo());
		values.put(Tache.FIELD_O_F_D, tacheDTO.getOfd());
		values.put(Tache.FIELD_DATE_FIN_REELLE, tacheDTO.getDatabaseDateDateFinReelle());
		values.put(Tache.FIELD_INDICATEUR_FIN, tacheDTO.getIndicateurFin());
		values.put(Tache.FIELD_CLE_VARIANTE, tacheDTO.getCleVariante());
		values.put(Tache.FIELD_VALEUR_VARIANTE, tacheDTO.getValeurVariante());
		values.put(Tache.FIELD_LIBELLE_COURT, tacheDTO.getLibelleCourt());
		values.put(Tache.FIELD_NB_REJEUX, tacheDTO.getNbRejeux());
		values.put(Tache.FIELD_DATE_PREMIERE_EXECUTION, tacheDTO.getDatabaseDateDatePremiereExecution());
		values.put(Tache.FIELD_LIBELLE_I_H_M, tacheDTO.getLibelleIHM());
		values.put(Tache.FIELD_INDICATEUR_FIN_I_H_M, tacheDTO.getIndicateurFinIHM());
		AgentDTO realiseeParAgentDTO = tacheDTO.getRealiseeParAgent();
		if (realiseeParAgentDTO != null) {
			values.put(Tache.FIELD_REALISEE_PAR_AGENT, realiseeParAgentDTO.getId());
		}
		RoleDTO faitParRoleDTO = tacheDTO.getFaitParRole();
		if (faitParRoleDTO != null) {
			values.put(Tache.FIELD_FAIT_PAR_ROLE, faitParRoleDTO.getId());
		}
		CatalogueTacheDTO catalogueTacheDTO = tacheDTO.getCatalogueTache();
		if (catalogueTacheDTO != null) {
			values.put(Tache.FIELD_EST_TYPE_CATALOGUE_TACHE, catalogueTacheDTO.getId());
		}
		CatalogueActiviteDTO catalogueActiviteDTO = tacheDTO.getCatalogueActivite();
		if (catalogueActiviteDTO != null) {
			values.put(Tache.FIELD_EST_CATALOGUE_ACTIVITE, catalogueActiviteDTO.getId());
		}
		ProcessusDTO lanceParProcessusProcessusDTO = tacheDTO.getLancerParProcessus();
		if (lanceParProcessusProcessusDTO != null && StringUtils.isNotBlank(lanceParProcessusProcessusDTO.getId())) {
			values.put(Tache.SLINK_LANCE_PAR_PROCESSUS, lanceParProcessusProcessusDTO.getId());
		}
		TacheDTO lieeATacheDTO = tacheDTO.getLieeATacheDTO();
		if (lieeATacheDTO != null && StringUtils.isNotBlank(lieeATacheDTO.getId())) {
			values.put(Tache.SLINK_LIEE_A_TACHE, lieeATacheDTO.getId());
		}
		EvtDTO evtDTO = tacheDTO.getEvt();
		if (evtDTO != null && StringUtils.isNotBlank(evtDTO.getId())) {
			values.put(Tache.SLINK_DECLENCHE_PAR_EVT, evtDTO.getId());
		}
		values.put(Tache.FIELD_TIMESTAMP_CREATION, new Timestamp(System.currentTimeMillis()));
		String tacheId = tacheDTO.getId();
		try {
			Tache tache = tacheHome.create(tacheId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			tache.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createTache", "Erreur cr�ation de la tache id " + tacheId, ce);
			throw new EJBException(ce);
		}
		return tacheDTO;
	}

	/**
	 * Gets the tache entity.
	 * 
	 * @param id the id
	 * 
	 * @return the tache entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Tache getTacheEntity(String id) throws FinderException {
		return tacheHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// TACHE_EN_COURS
	// --------------------------------------------------------------
	/**
	 * 
	 */
	public TacheEnCoursDTO getTacheEnCours(String tacheEnCoursId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getTacheEnCours", "Recherche de la tacheEnCours  " + tacheEnCoursId);
		try {
			TacheEnCours tache = getTacheEnCoursEntity(tacheEnCoursId);
			return new TacheEnCoursDTO(tache);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getTacheEnCours", "Probleme de recuperation de la tacheEnCours = " + tacheEnCoursId, fe);
			return null;
		}
	}

	/**
	 * 
	 * @inherit com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheEnCoursByProcessus(java.lang.String)
	 */
	public List<TacheEnCoursDTO> findTacheEnCoursByProcessus(String processusId) {
		List<TacheEnCoursDTO> tacheEnCoursDTOs = new ArrayList<TacheEnCoursDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<TacheEnCours> tacheEnCourss = tacheEnCoursHome.findParProcessus(processusId);
			for (TacheEnCours tacheEnCours : tacheEnCourss) {
				tacheEnCoursDTOs.add(new TacheEnCoursDTO(tacheEnCours));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheEnCoursByProcessus", "Probleme lors de la recherche des taches en cours pour le processus " + processusId, fe);
			throw new EJBException(fe);
		}
		return tacheEnCoursDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheEnCoursByProcessusAndIdExterne(java.lang.String, java.lang.String)
	 */
	// TODO G10 : Cr�er un finder sur MagicDraw
	// TODO G10 : Supprimer le finder tacheEnCoursHome.findByDatePremiereMADispoAndProcessus
	public List<TacheEnCoursDTO> findTacheEnCoursByProcessusAndIdExterne(String processusId, String tacheIdExterne) {
		List<TacheEnCoursDTO> tachesEnCoursDTOs = new ArrayList<TacheEnCoursDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<TacheEnCours> tachesEnCours = tacheEnCoursHome.findParProcessus(processusId);
			for (TacheEnCours tacheEnCours : tachesEnCours) {
				TacheEnCoursDTO tacheEnCoursDTO = new TacheEnCoursDTO(tacheEnCours);
				TacheDTO tacheDTO = this.getTache(tacheEnCoursDTO.getId());
				if ( (tacheDTO != null) && (StringUtils.equals(tacheIdExterne, tacheDTO.getIdExterne()))) {
					tachesEnCoursDTOs.add(tacheEnCoursDTO);
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheEnCoursByProcessus", "Probleme lors de la recherche des taches en cours pour le processus " + processusId, fe);
			throw new EJBException(fe);
		}
		return tachesEnCoursDTOs;
	}


	/**
	 * 
	 * @inherit com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findTacheEnCoursByCommande(java.lang.String)
	 */
	public List<TacheEnCoursDTO> findTacheEnCoursByCommande(String commandeId) {
		List<TacheEnCoursDTO> tacheEnCoursDTOs = new ArrayList<TacheEnCoursDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<TacheEnCours> tacheEnCourss = tacheEnCoursHome.findParCde(commandeId);
			for (TacheEnCours tacheEnCours : tacheEnCourss) {
				tacheEnCoursDTOs.add(new TacheEnCoursDTO(tacheEnCours));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTacheEnCoursByCommande", "Probleme lors de la recherche des taches en cours pour la commande " + commandeId, fe);
			throw new EJBException(fe);
		}
		return tacheEnCoursDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#deleteTacheEnCours(java.lang.String)
	 */
	public void deleteTacheEnCours(String tacheEnCoursId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteTacheEnCours", "Suppression de la tache en cours " + tacheEnCoursId);
		try {
			TacheEnCours tacheEnCours = getTacheEnCoursEntity(tacheEnCoursId);
			tacheEnCours.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCours", "Erreur suppression taches en cours");
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCours", "Erreur suppression taches en cours");
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCours", "Erreur suppression taches en cours");
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#deleteTacheEnCoursByProcessus(java.lang.String)
	 */
	public void deleteTacheEnCoursByProcessus(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteTacheEnCoursByProcessus", "Suppression des taches en cours pour le processus " + processusId);
		try {
			@SuppressWarnings("unchecked")
			Collection<TacheEnCours> tacheEnCoursList = tacheEnCoursHome.findParProcessus(processusId);
			for (TacheEnCours tacheEnCours : tacheEnCoursList) {
				tacheEnCours.remove();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCoursByProcessus", "Erreur suppression taches en cours", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCoursByProcessus", "Erreur suppression taches en cours", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCoursByProcessus", "Erreur suppression taches en cours", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt(String commandeId, String processusId, String libelleCourt) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt",
				"Suppression des taches en cours pour le processus " + processusId + " , la commande " + commandeId + " et libelleCourt " + libelleCourt);
		try {
			@SuppressWarnings("unchecked")
			Collection<TacheEnCours> tacheEnCoursList = tacheEnCoursHome.findParCde(commandeId);
			for (TacheEnCours tacheEnCours : tacheEnCoursList) {
				if (StringUtils.equals(processusId, tacheEnCours.getId_Process()) && StringUtils.equals(libelleCourt, tacheEnCours.getLibelleCourt())) {
					tacheEnCours.remove();
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt", "Erreur suppression taches en cours", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt", "Erreur suppression taches en cours", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt", "Erreur suppression taches en cours", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateTacheEnCours(com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO)
	 */
	public void updateTacheEnCours(TacheEnCoursDTO tacheEnCoursDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateTacheEnCours", "Mise � jour de la tache en cours " + tacheEnCoursDTO.getId());
		try {
			TacheEnCours tacheEnCours = getTacheEnCoursEntity(tacheEnCoursDTO.getId());
			tacheEnCours.setId_Process(tacheEnCoursDTO.getIdProcess());
			tacheEnCours.setAccesLivraison(tacheEnCoursDTO.getAccesLivraison());
			tacheEnCours.setLibelleCourt(tacheEnCoursDTO.getLibelleCourt());
			tacheEnCours.setLibelle(tacheEnCoursDTO.getLibelle());
			tacheEnCours.setDatePremiereMADispo(tacheEnCoursDTO.getDatePremiereMADispo());
			tacheEnCours.setIdEvt(tacheEnCoursDTO.getIdEvt());
			tacheEnCours.setLibCauseEvt(tacheEnCoursDTO.getLibCauseEvt());
			tacheEnCours.setLibCauseEvtInit(tacheEnCoursDTO.getLibCauseEvtInit());
			tacheEnCours.setESD(tacheEnCoursDTO.getEsd());
			tacheEnCours.setZoneGeo(tacheEnCoursDTO.getZoneGeo());
			tacheEnCours.setZoneGeoLib(tacheEnCoursDTO.getZoneGeoLib());
			tacheEnCours.setZoneSI(tacheEnCoursDTO.getZoneSi());
			tacheEnCours.setZoneSILib(tacheEnCoursDTO.getZoneSiLib());
			tacheEnCours.setIdCommande(tacheEnCoursDTO.getIdCommande());
			tacheEnCours.setAgent(tacheEnCoursDTO.getAgent());
			tacheEnCours.setRole(tacheEnCoursDTO.getRole());
			tacheEnCours.setOFD(tacheEnCoursDTO.getOfd());
			tacheEnCours.setDateProgrammation(tacheEnCoursDTO.getDateProgrammation());
			tacheEnCours.setCatCliCont(tacheEnCoursDTO.getCatCliCont());
			tacheEnCours.setCatCliLiv(tacheEnCoursDTO.getCatCliLiv());
			tacheEnCours.setDateContractuelle(tacheEnCoursDTO.getDateContractuelle());
			tacheEnCours.setInfoLC(tacheEnCoursDTO.getInfoLc());
			tacheEnCours.setFamilleOffre(tacheEnCoursDTO.getFamilleOffre());
			tacheEnCours.setJalon(tacheEnCoursDTO.getJalon());
			tacheEnCours.setRepartiteur(tacheEnCoursDTO.getRepartiteur());
			tacheEnCours.setDSLAM(tacheEnCoursDTO.getDslam());
			tacheEnCours.setAncDSLAM(tacheEnCoursDTO.getAncDslam());
			long timestamp = tacheEnCours.getTimestamp() + 1;
			tacheEnCours.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateTacheEnCours", "Probleme de mise � jour de la tache en cours = " + tacheEnCoursDTO.getId());
			throw new EJBException(fe);
		}
	}

	/**
	 * 
	 * @inherit com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateTacheEnCoursRole(com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO)
	 */
	public void updateTacheEnCoursRole(TacheEnCoursDTO tacheEnCoursDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateTacheEnCoursRole", "Mise � jour de la tache en cours " + tacheEnCoursDTO.getId());
		try {
			TacheEnCours tacheEnCours = getTacheEnCoursEntity(tacheEnCoursDTO.getId());
			tacheEnCours.setRole(tacheEnCoursDTO.getRole());
			long timestamp = tacheEnCours.getTimestamp() + 1;
			tacheEnCours.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateTacheEnCoursRole", "Probleme de mise � jour de la tache en cours = " + tacheEnCoursDTO.getId());
			throw new EJBException(fe);
		}
	}

	/**
	 * 
	 * @inherit com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateTacheEnCoursZoneGeo(com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO)
	 */
	public void updateTacheEnCoursZoneGeo(TacheEnCoursDTO tacheEnCoursDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateTacheEnCoursZoneGeo", "Mise � jour de la tache en cours " + tacheEnCoursDTO.getId());
		try {
			TacheEnCours tacheEnCours = getTacheEnCoursEntity(tacheEnCoursDTO.getId());
			tacheEnCours.setZoneGeo(tacheEnCoursDTO.getZoneGeo());
			long timestamp = tacheEnCours.getTimestamp() + 1;
			tacheEnCours.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateTacheEnCoursZoneGeo", "Probleme de mise � jour de la tache en cours = " + tacheEnCoursDTO.getId());
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createTacheEnCours(com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO)
	 */
	public TacheEnCoursDTO createTacheEnCours(TacheEnCoursDTO tacheEnCoursDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createTacheEnCours", "Cr�ation de la tache en cours " + tacheEnCoursDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(TacheEnCours.FIELD_LIBELLE, tacheEnCoursDTO.getLibelle());
		values.put(TacheEnCours.FIELD_LIBELLE_COURT, tacheEnCoursDTO.getLibelleCourt());
		values.put(TacheEnCours.FIELD_ID__PROCESS, tacheEnCoursDTO.getIdProcess());
		values.put(TacheEnCours.FIELD_ID_COMMANDE, tacheEnCoursDTO.getIdCommande());
		values.put(TacheEnCours.FIELD_ACCES_LIVRAISON, tacheEnCoursDTO.getAccesLivraison());
		values.put(TacheEnCours.FIELD_DATE_PREMIERE_M_A_DISPO, tacheEnCoursDTO.getDatePremiereMADispo());
		values.put(TacheEnCours.FIELD_ID_EVT, tacheEnCoursDTO.getIdEvt());
		values.put(TacheEnCours.FIELD_LIB_CAUSE_EVT, tacheEnCoursDTO.getLibCauseEvt());
		values.put(TacheEnCours.FIELD_LIB_CAUSE_EVT_INIT, tacheEnCoursDTO.getLibCauseEvtInit());
		values.put(TacheEnCours.FIELD_CAT_CLI_CONT, tacheEnCoursDTO.getCatCliCont());
		values.put(TacheEnCours.FIELD_CAT_CLI_LIV, tacheEnCoursDTO.getCatCliLiv());
		values.put(TacheEnCours.FIELD_ZONE_GEO, tacheEnCoursDTO.getZoneGeo());
		values.put(TacheEnCours.FIELD_ZONE_GEO_LIB, tacheEnCoursDTO.getZoneGeoLib());
		values.put(TacheEnCours.FIELD_ZONE_S_I, tacheEnCoursDTO.getZoneSi());
		values.put(TacheEnCours.FIELD_ZONE_S_I_LIB, tacheEnCoursDTO.getZoneSiLib());
		values.put(TacheEnCours.FIELD_AGENT, tacheEnCoursDTO.getAgent());
		values.put(TacheEnCours.FIELD_ROLE, tacheEnCoursDTO.getRole());
		values.put(TacheEnCours.FIELD_JALON, tacheEnCoursDTO.getJalon());
		values.put(TacheEnCours.FIELD_E_S_D, tacheEnCoursDTO.getEsd());
		values.put(TacheEnCours.FIELD_DATE_PROGRAMMATION, tacheEnCoursDTO.getDateProgrammation());
		values.put(TacheEnCours.FIELD_DATE_CONTRACTUELLE, tacheEnCoursDTO.getDateContractuelle());
		values.put(TacheEnCours.FIELD_O_F_D, tacheEnCoursDTO.getOfd());
		values.put(TacheEnCours.FIELD_REPARTITEUR, tacheEnCoursDTO.getRepartiteur());
		values.put(TacheEnCours.FIELD_D_S_L_A_M, tacheEnCoursDTO.getDslam());
		values.put(TacheEnCours.FIELD_ANC_D_S_L_A_M, tacheEnCoursDTO.getAncDslam());
		values.put(TacheEnCours.FIELD_INFO_L_C, tacheEnCoursDTO.getInfoLc());
		values.put(TacheEnCours.FIELD_FAMILLE_OFFRE, tacheEnCoursDTO.getFamilleOffre());
		String tacheEnCoursId = tacheEnCoursDTO.getId();
		try {
			tacheEnCoursHome.create(tacheEnCoursId, values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createTacheEnCours", "Erreur cr�ation de la tache en cours id " + tacheEnCoursId, ce);
			throw new EJBException(ce);
		}
		return tacheEnCoursDTO;
	}

	/**
	 * Gets the tache en cours entity.
	 * 
	 * @param id the id
	 * 
	 * @return the tache en cours entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private TacheEnCours getTacheEnCoursEntity(String id) throws FinderException {
		return tacheEnCoursHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// EVT
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#getEvt(java.lang.String)
	 */
	public EvtDTO getEvt(String evtId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getEvt", "Recherche de l'evenement  " + evtId);
		try {
			Evt evt = getEvtEntity(evtId);
			return new EvtDTO(evt);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getEvt", "Probleme de recuperation de l'evenement " + evtId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updateEvtDateCreation(com.soliste.bolbec.livraison.service.model.EvtDTO)
	 */
	public void updateEvtDateCreation(EvtDTO evtDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateEvtDateCreation", "Mise � jour de l'evenement " + evtDTO.getId());
		try {
			Evt evt = getEvtEntity(evtDTO.getId());
			evt.setDateCreation(evtDTO.getDatabaseDateDateCreation());
			long timestamp = evt.getTimestamp() + 1;
			evt.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateEvtDateCreation", "Probleme de mise � jour de l'evenement = " + evtDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createEvt(com.soliste.bolbec.livraison.service.model.EvtDTO)
	 */
	public EvtDTO createEvt(EvtDTO evtDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createEvt", "Cr�ation de l'evenement " + evtDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(Evt.FIELD_INFO, evtDTO.getInfo());
		values.put(Evt.FIELD_DATE_CREATION, evtDTO.getDatabaseDateDateCreation());
		values.put(Evt.FIELD_DATE_FIN_PREVUE, evtDTO.getDatabaseDateDateFinPrevue());
		CauseEvenementDTO causeEvenementDTO = evtDTO.getCauseEvenement();
		if (causeEvenementDTO != null) {
			values.put(Evt.FIELD_CAUSE_PAR_CAUSE_EVENEMENT, causeEvenementDTO.getId());
		}
		values.put(Evt.FIELD_TYPE_ABD, evtDTO.getTypeAbd());
		AgentDTO aPourOrigineAgentDTO = evtDTO.getAPourOrigineAgent();
		if (aPourOrigineAgentDTO != null) {
			values.put(Evt.FIELD_A_POUR_ORIGINE_AGENT, aPourOrigineAgentDTO.getId());
		}
		TacheDTO pourTacheTacheDTO = evtDTO.getTache();
		if (pourTacheTacheDTO != null) {
			values.put(Evt.SLINK_POUR_TACHE, pourTacheTacheDTO.getId());
		}
		ProcessusDTO pourProcProcessusProcessusDTO = evtDTO.getProcessus();
		if (pourProcProcessusProcessusDTO != null) {
			values.put(Evt.SLINK_POUR_PROC_PROCESSUS, pourProcProcessusProcessusDTO.getId());
		}
		String evtId = evtDTO.getId();
		try {
			Evt evt = evtHome.create(evtId, values);
			evt.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createEvt", "Erreur cr�ation de l'evenement " + evtId, ce);
			throw new EJBException(ce);
		}
		return evtDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByProcessus(java.lang.String)
	 */
	public List<EvtDTO> findEvtByProcessus(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByProcessus", "Recherche des evenements pour le processus " + processusId);
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = evtHome.findByPourProcProcessus(processusId);
			for (Evt evt : evts) {
				evtDTOs.add(new EvtDTO(evt));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtByProcessus", "Probleme lors de la recherche des evenements pour le processus " + processusId, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByTache(java.lang.String)
	 */
	public List<EvtDTO> findEvtByTache(String tacheId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByTache", "Recherche des evenements pour la tache " + tacheId);
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = evtHome.findByPourTache(tacheId);
			for (Evt evt : evts) {
				evtDTOs.add(new EvtDTO(evt));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtByTache", "Probleme lors de la recherche des evenements pour la tache " + tacheId, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findGeneratedEvtByTache(java.lang.String)
	 */
	public List<EvtDTO> findGeneratedEvtByTache(String tacheId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findGeneratedEvtByTache", "Recherche des evenements generes par la tache " + tacheId);
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();
		try {
			Tache tache = getTacheEntity(tacheId);
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = tache.getLinkGenereEvt();
			for (Evt evt : evts) {
				evtDTOs.add(new EvtDTO(evt));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findGeneratedEvtByTache", "Probleme lors de la recherche des evenements generes par la tache " + tacheId, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByProcAndTypeAbd(java.lang.String, java.lang.String)
	 */
	public List<EvtDTO> findEvtByProcAndTypeAbd(String processusId, String typeAbd) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByProcAndTypeAbd", "Recherche des evenements pour le processus " + processusId + " et le type d'abandon " + typeAbd);
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();
		try {
			// FIXME OLD: GTA faire un finder appropri�
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = evtHome.findByPourProcProcessus(processusId);
			for (Evt evt : evts) {
				if (StringUtils.equals(typeAbd, evt.getTypeAbd())) {
					evtDTOs.add(new EvtDTO(evt));
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtByProcAndTypeAbd", "Probleme lors de la recherche des evenements pour le processus " + processusId + " et le type d'abandon " + typeAbd, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByProcAndTypeEvtAndPlusRecent(java.lang.String, java.lang.String)
	 */
	public EvtDTO findEvtByProcAndTypeEvtAndPlusRecent(String processusId, String typeEvt) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByProcAndTypeEvtAndPlusRecent", "Recherche des evenements pour le processus " + processusId + " et le type d'�v�nement " + typeEvt);
		EvtDTO evtDTO = null;
		try {
			// FIXME OLD: GTA faire un finder appropri�
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = evtHome.findByPourProcProcessus(processusId);
			Long dateCreationAnc = 0L;
			for (Evt evt : evts) {
				String causeId = evt.getCauseParCauseEvenement();
				if (!StringUtils.isEmpty(causeId)) {
					CauseEvenementDTO cause = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, causeId);
					String typeEvtTrouve = cause.getTypeEvenement() != null ? cause.getTypeEvenement().getId() : null;
					if (StringUtils.equals(typeEvt, typeEvtTrouve)) {
						Long dateCreation = evt.getDateCreation();
						if (dateCreationAnc.compareTo(dateCreation) < 0) {
							evtDTO = new EvtDTO(evt);
							dateCreationAnc = dateCreation;
						}
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtByProcAndTypeEvtAndPlusRecent", "Probleme lors de la recherche des evenements pour le processus " + processusId + " et le type d'�v�nement " + typeEvt, fe);
			throw new EJBException(fe);
		}
		return evtDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtParTacheLanceeParProcessusAndTypeEvt(java.lang.String, java.lang.String)
	 */
	public List<EvtDTO> findEvtParTacheLanceeParProcessusAndTypeEvt(String processusId, String typeEvt) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtParTacheLanceeParProcessusAndTypeEvt", "Recherche la liste des evenements associ�s aux t�ches lanc�es par le processus " + processusId + ", pour le typeEvt : " + typeEvt);
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = evtHome.findParTacheLanceeParProcessus(processusId);
			for (Evt evt : evts) {
				String causeId = evt.getCauseParCauseEvenement();
				if (!StringUtils.isEmpty(causeId)) {
					CauseEvenementDTO cause = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, causeId);
					String typeEvtTrouve = cause.getTypeEvenement() != null ? cause.getTypeEvenement().getId() : null;
					if (StringUtils.equals(typeEvt, typeEvtTrouve)) {
						evtDTOs.add(new EvtDTO(evt));
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtParTacheLanceeParProcessusAndTypeEvt",
					"Probleme lors de la recherche des evenements des t�ches lanc�es par le processus " + processusId + " qui ont pour type " + typeEvt, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByCommandeAndTypeEvenement(java.lang.String, java.lang.String)
	 */
	@Deprecated
	public List<EvtDTO> findEvtByCommandeAndTypeEvenement(String commandeId, String typeEvenementValConst) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByCommandeAndTypeEvenement", "Recherche des evenements pour la commande " + commandeId);
		Map<String, Evt> evtSsDoublons = new HashMap<String, Evt>();
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();
		try {
			// FIXME OLD: faire un finder appropri� ?
			@SuppressWarnings("unchecked")
			Collection<LigneCommande> lcs = ligneCommandeHome.findParCde(commandeId);
			for (LigneCommande ligneCommande : lcs) {
				@SuppressWarnings("unchecked")
				Collection<ProcessusLC> plcs = ligneCommande.getLinkEstLivreParProcessus();
				for (ProcessusLC processusLC : plcs) {
					Processus processus = processusLC.getLinkEstLivreParProcessus();
					// Taches de lancement
					@SuppressWarnings("unchecked")
					Collection<Tache> taches = processus.getLinkOrdonnanceTache();
					for (Tache tache : taches) {
						@SuppressWarnings("unchecked")
						Collection<Evt> evts = tache.getLinkGenereEvt();
						for (Evt evt : evts) {
							evtSsDoublons.put(evt.getId(), evt);
						}
						// Descendre dans les sous-processus aussi
						@SuppressWarnings("unchecked")
						Collection<Processus> sousProcs = tache.getLinkAppelleProcessus();
						for (Processus sousProc : sousProcs) {
							// Taches du sous-processus
							@SuppressWarnings("unchecked")
							Collection<Tache> tachesSousProc = sousProc.getLinkOrdonnanceTache();
							for (Tache tacheSousProc : tachesSousProc) {
								@SuppressWarnings("unchecked")
								Collection<Evt> evtsSousProc = tacheSousProc.getLinkGenereEvt();
								for (Evt evtSousProc : evtsSousProc) {
									evtSsDoublons.put(evtSousProc.getId(), evtSousProc);
								}
							}
						}
					}
				}
			}
			for (Evt evt : evtSsDoublons.values()) {
				CauseEvenementDTO causeEvt = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseParCauseEvenement());
				if (causeEvt.getTypeEvenement() != null) {
					TypeEvenementDTO typeEvt = causeEvt.getTypeEvenement();
					if (typeEvenementValConst.equals(typeEvt.getValeurConstante())) {
						evtDTOs.add(new EvtDTO(evt));
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtByCommandeAndTypeEvenement", "Probleme lors de la recherche des evenements pour la commande " + commandeId, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	/**
	 * Gets the evt entity.
	 * 
	 * @param id the id
	 * 
	 * @return the evt entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Evt getEvtEntity(String id) throws FinderException {
		return evtHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// PROCESSUS
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByTacheAndPere(java.lang.String)
	 */
	public ProcessusDTO findProcessusByTacheAndPere(String tacheId) {
		try {
			Tache tache = getTacheEntity(tacheId);
			Processus processus = tache.getLinkLanceParProcessus();
			while (processus.getLinkGenereParProcessus() != null) {
				processus = processus.getLinkGenereParProcessus();
			}
			return new ProcessusDTO(processus);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusByTacheAndPere", "Pas de tache id = " + tacheId, fe);
			throw new EJBException(fe);
		}
	}

	// --------------------------------------------------------------
	// PROCESSUS_LC
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByLigneCommande(java.lang.String)
	 */
	public List<ProcessusDTO> findProcessusByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusByLigneCommande", "Recherche des processus pour la ligne de commande " + ligneCommandeId);
		List<ProcessusDTO> processusDTOs = new ArrayList<ProcessusDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> plcs = processusLCHome.findByLivreLigneCommande(ligneCommandeId);
			for (ProcessusLC processusLC : plcs) {
				processusDTOs.add(new ProcessusDTO(processusLC.getLinkEstLivreParProcessus()));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusByLigneCommande", "Pas de processus avec la ligne de commande id = " + ligneCommandeId, fe);
			throw new EJBException(fe);
		}
		return processusDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByLigneCommandeAndPereAndPlusRecent(java.lang.String)
	 */
	public ProcessusDTO findProcessusByLigneCommandeAndPereAndPlusRecent(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusByLigneCommandeAndPereAndPlusRecent", "Recherche du processus pere le plus r�cent pour la ligne de commande " + ligneCommandeId);
		List<ProcessusDTO> lstProcessus = findProcessusByLigneCommande(ligneCommandeId);

		// FIXME OLD: GTA faire un finder suppl�mentaire pour �viter d'avoir � filtrer dans le code ?

		// R�cup�ration du processus p�re le plus r�cent
		ProcessusDTO processusTrouve = null;
		Long dateCreationAnc = 0L;
		for (ProcessusDTO proc : lstProcessus) {
			ProcessusDTO procPere = proc.getGenereParProcessus();
			if (procPere == null) {
				Long dateCreation = proc.getDatabaseDateDateCreation();
				if (dateCreationAnc.compareTo(dateCreation) < 0) {
					processusTrouve = proc;
					dateCreationAnc = dateCreation;
				}
			}
		}

		return processusTrouve;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findSousProcessusByGenereParProcessusAndNotAnnuleParProcessusAndNotEtat(java.lang.String, java.lang.String)
	 */
	public List<ProcessusDTO> findSousProcessusByGenereParProcessusAndNotAnnuleParProcessusAndNotEtat(String genereParProcessusId, String etat) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findSousProcessusByGenereParProcessusAndAnnuleParProcessusAndEtat", "Recherche des sous processus g�n�r�s par le processus " + genereParProcessusId);
		List<ProcessusDTO> processusDTOs = new ArrayList<ProcessusDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Processus> processusList = processusHome.findByGenereParProcessus(genereParProcessusId);
			for (Processus processus : processusList) {
				String processusAnnule = processus.getLinkAnnuleParProcessus() != null ? processus.getLinkAnnuleParProcessus().getId() : null;
				if (StringUtils.isBlank(processusAnnule)) {
					if (!StringUtils.equals(etat, processus.getEstEtatProcessus())) {
						processusDTOs.add(new ProcessusDTO(processus));
					}
				}
			}
			// tri de la liste par date de cr�ation
			Collections.sort(processusDTOs, new Comparator<ProcessusDTO>() {

				public int compare(ProcessusDTO o1, ProcessusDTO o2) {
					if ((o1.getDatabaseDateDateCreation() != null) && (o2.getDatabaseDateDateCreation() != null)) {
						return o2.getDatabaseDateDateCreation().compareTo(o1.getDatabaseDateDateCreation());
					} else if (o1.getDatabaseDateDateCreation() == null) {
						return -1;
					} else if (o2.getDatabaseDateDateCreation() == null) {
						return 1;
					} else {
						return 0;
					}
				}
			});
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findSousProcessusByGenereParProcessusAndAnnuleParProcessusAndEtat", "Pas de sous processus g�n�r� par le processus = " + genereParProcessusId, fe);
			throw new EJBException(fe);
		}
		return processusDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusByCommande(java.lang.String)
	 */
	public List<ProcessusDTO> findProcessusByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusByCommande", "Recherche des processus pour la commande " + commandeId);
		List<ProcessusDTO> processusDTOs = new ArrayList<ProcessusDTO>();
		try {
			Set<String> processusIds = new HashSet<String>();
			@SuppressWarnings("unchecked")
			Collection<LigneCommande> lcs = ligneCommandeHome.findParCde(commandeId);
			for (LigneCommande ligneCommande : lcs) {
				String ligneCommandeId = ligneCommande.getId();
				@SuppressWarnings("unchecked")
				Collection<ProcessusLC> plcs = processusLCHome.findByLivreLigneCommande(ligneCommandeId);
				for (ProcessusLC processusLC : plcs) {
					Processus processus = processusLC.getLinkEstLivreParProcessus();
					String processusId = processus.getId();
					if (!processusIds.contains(processusId)) {
						processusDTOs.add(new ProcessusDTO(processus));
						processusIds.add(processusId);
					}
				}
			}

		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusByCommande", "Pas de processus avec la commande id = " + commandeId, fe);
			throw new EJBException(fe);
		}
		return processusDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findProcessusFils(java.lang.String)
	 */
	public List<ProcessusDTO> findProcessusFils(String idProcessusPere) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findProcessusByCommande", "Recherche des processus fils du processus " + idProcessusPere);
		List<ProcessusDTO> processusDTOs = new ArrayList<ProcessusDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Processus> listeProcessus = processusHome.findByGenereParProcessus(idProcessusPere);
			for (Processus processus : listeProcessus) {
				processusDTOs.add(new ProcessusDTO(processus));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findProcessusByCommande", "Pas de processus fils pour le processus = " + idProcessusPere, fe);
			throw new EJBException(fe);
		}
		return processusDTOs;

	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createProcessusLC(com.soliste.bolbec.livraison.service.model.ProcessusLcDTO)
	 */
	public ProcessusLcDTO createProcessusLC(ProcessusLcDTO processusLcDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createProcessusLC", "Cr�ation du processusLC " + processusLcDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		LigneCommandeDTO ligneCommandeDTO = processusLcDTO.getLigneCommande();
		if (ligneCommandeDTO != null && StringUtils.isNotBlank(ligneCommandeDTO.getId())) {
			values.put(ProcessusLC.SLINK_LIVRE_LIGNE_COMMANDE, ligneCommandeDTO.getId());
		}
		ProcessusDTO processusDTO = processusLcDTO.getProcessus();
		if (processusDTO != null && StringUtils.isNotBlank(processusDTO.getId())) {
			values.put(ProcessusLC.SLINK_EST_LIVRE_PAR_PROCESSUS, processusDTO.getId());
		}
		try {
			ProcessusLC processusLC = processusLCHome.create(processusLcDTO.getId(), values);
			processusLC.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createProcessusLC", "Erreur cr�ation du processusLC " + processusLcDTO.getId(), ce);
			throw new EJBException(ce);
		}
		return processusLcDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByProcAndCause(java.lang.String, java.lang.String)
	 */
	public List<EvtDTO> findEvtByProcAndCause(String processusId, String cause) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByProcAndTypeAbd", "Recherche des evenements pour le processus " + processusId + " et la cause " + cause);
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();
		try {
			// FIXME OLD: GTA faire un finder appropri�
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = evtHome.findByPourProcProcessus(processusId);
			for (Evt evt : evts) {
				if (StringUtils.equals(cause, evt.getCauseParCauseEvenement())) {
					evtDTOs.add(new EvtDTO(evt));
				}
			}
			@SuppressWarnings("unchecked")
			Collection<Tache> taches = tacheHome.findByLanceParProcessus(processusId);
			for (Tache tache : taches) {
				List<EvtDTO> evtsTache = findEvtByTache(tache.getId());
				for (EvtDTO evtDTO : evtsTache) {
					if (evtDTO.getCauseEvenement() != null && StringUtils.equals(cause, evtDTO.getCauseEvenement().getId())) {
						evtDTOs.add(evtDTO);
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtByProcAndTypeAbd", "Probleme lors de la recherche des evenements pour le processus " + processusId + " et la cause " + cause, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	// --------------------------------------------------------------
	// PROCESSUS SUSPENDUS
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createProcessusSuspendus(com.soliste.bolbec.livraison.service.model.ProcessusSuspendusDTO)
	 */
	public ProcessusSuspendusDTO createProcessusSuspendus(ProcessusSuspendusDTO processusSuspendusDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createProcessusSuspendus", "Cr�ation du processusSuspendus " + processusSuspendusDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(ProcessusSuspendus.FIELD_ID_PERE, processusSuspendusDTO.getIdPere());
		values.put(ProcessusSuspendus.FIELD_ID_FILS, processusSuspendusDTO.getIdFils());
		try {
			processusSuspendusHome.create(processusSuspendusDTO.getId(), values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createProcessusSuspendus", "Erreur cr�ation du processusSuspendus " + processusSuspendusDTO.getId(), ce);
			throw new EJBException(ce);
		}
		return processusSuspendusDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#deleteProcessusSuspendusByIdPere(java.lang.String)
	 */
	public void deleteProcessusSuspendusByIdPere(String processusId) {
		try {
			@SuppressWarnings("unchecked")
			Collection<ProcessusSuspendus> listProcessusASupprimer = processusSuspendusHome.findByIdPere(processusId);
			for (ProcessusSuspendus processusSuspendusASupprimer : listProcessusASupprimer) {
				processusSuspendusASupprimer.remove();
			}
		} catch (FinderException e) {
			throw new EJBException(e);
		} catch (EJBException e) {
			throw new EJBException(e);
		} catch (RemoveException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByProcessus(java.lang.String)
	 */
	public Map<String, EvtDTO> findMapEvtByProcessus(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByProcessus", "Recherche des evenements pour le processus " + processusId);
		Map<String, EvtDTO> evtDTOs = new HashMap<String, EvtDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Evt> evts = evtHome.findByPourProcProcessus(processusId);
			for (Evt evt : evts) {
				evtDTOs.put(evt.getId(), new EvtDTO(evt));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEvtByProcessus", "Probleme lors de la recherche des evenements pour le processus " + processusId, fe);
			throw new EJBException(fe);
		}
		return evtDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtByCommande(java.lang.String)
	 *
	 * @param commandeId l'id de la commande
	 * @return la liste des evt
	 */
	public List<EvtDTO> findEvtByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtByCommande", "Recherche des evenements pour la commande " + commandeId);
		Map<String, EvtDTO> evtDTOs = new HashMap<String, EvtDTO>();

		// Recherche des processus associ�s � la commande
		try {
			@SuppressWarnings("unchecked")
			Collection<Processus> listeProcessus = processusHome.findParIdCommande(commandeId);
			for (Processus processus : listeProcessus) {
				evtDTOs.putAll(findMapEvtByProcessus(processus.getId()));
			}

		} catch (FinderException e) {
			throw new EJBException(e);
		}
		return new ArrayList<EvtDTO>(evtDTOs.values());
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#findEvtDirectByCommande(java.lang.String)
	 *
	 * @param commandeId l'id de la commande
	 * @return la liste des evt
	 */
	public List<EvtDTO> findEvtDirectByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEvtDirectByCommande", "Recherche des evenements pour la commande " + commandeId);
		List<EvtDTO> evtDTOs = new ArrayList<EvtDTO>();

		// Recherche des �v�nements associ�s � la commande
		try {
			@SuppressWarnings("unchecked")
			Collection<Evt> listeEvt = evtHome.findDirectByCommandeId(commandeId);
			for (Evt evt : listeEvt) {
				evtDTOs.add(new EvtDTO(evt));
			}
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		return evtDTOs;
	}

	/**
	 * R�cup�re l'evenement le plus r�cent � partir d'une liste d'evenements
	 * 
	 * @param evtsList la liste d'evenements
	 * @return l'evenement le plus r�cent
	 */
	public EvtDTO recupererEvtPlusRecente(final Collection<EvtDTO> evtsList) {
		if (evtsList.isEmpty()) {
			return null;
		}
		EvtDTO evtPlusRecente = null;
		Date dateCreation = null;
		Date tmpDateCreation;
		for (EvtDTO evt : evtsList) {
			tmpDateCreation = evt.getDateCreation();
			if (tmpDateCreation == null) {
				continue;
			}
			if (dateCreation == null || dateCreation.before(tmpDateCreation)) {
				dateCreation = tmpDateCreation;
				evtPlusRecente = evt;
			}
		}
		return evtPlusRecente;
	}

	/**
	 * Filtre les evements en fonction du typeEvenement
	 * 
	 * @param evtsList la liste d'evenements
	 * @param typeEvenement la valeur constante du typeEvenement
	 * @return la liste d'evenements de type typeEvenement
	 */
	public Collection<EvtDTO> filtrerEvtByTypeEvenement(Collection<EvtDTO> evtsList, String typeEvenement) {
		final List<EvtDTO> evtsFiltresList = new ArrayList<EvtDTO>();
		if (evtsList.isEmpty()) {
			return evtsFiltresList;
		}
		CauseEvenementDTO causeEvenement;
		for (EvtDTO evt : evtsList) {
			causeEvenement = evt.getCauseEvenement();
			if (causeEvenement == null) {
				continue;
			}
			causeEvenement = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, causeEvenement.getId());
			if (typeEvenement.equals(causeEvenement.getTypeEvenement().getValeurConstante())) {
				evtsFiltresList.add(evt);
			}
		}
		return evtsFiltresList;
	}

	// BLOC MIGRATION G9 /////////////////////////////////////////////////////////////////////////////////////
	// M�thodes d�finies pour les EJB Remote.
	// Elles sont associ�es � une transaction de type "RequiresNew" dans le descripteur de d�ploiement des EJB.
	// La transaction est donc born�e � la m�thode app�l�e.

	/**
	 * @see
	 */
	public List<ProcessusDTO> findProcessusByCommandeWithNewTransaction(String commandeId) {
		return findProcessusByCommande(commandeId);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.IProcessusManagerRemote#updateProcessusEtatWithNewTransaction(com.soliste.bolbec.livraison.service.model.ProcessusDTO)
	 */
	public void updateProcessusEtatWithNewTransaction(ProcessusDTO processusDTO) throws RemoteException {
		updateProcessusEtat(processusDTO);
	}
	// FIN BLOC MIGRATION G9 /////////////////////////////////////////////////////////////////////////////////


	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createAttendu(AttenduDTO)
	 */
	public AttenduDTO createAttendu(AttenduDTO attenduDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createAttendu", "Cr�ation de la ligne attendue " + attenduDTO);
		String id = attenduDTO.getId();
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(Attendu.FIELD_ID, id);
		values.put(Attendu.FIELD_ID_COMMANDE, attenduDTO.getIdCommande());
		values.put(Attendu.FIELD_ID_CORRELATION, attenduDTO.getIdCorrelation());
		values.put(Attendu.FIELD_ID_TRAITEMENT, attenduDTO.getIdTraitement());
		values.put(Attendu.FIELD_TYPE_EVT, attenduDTO.getTypeEvt());
		attenduDTO.setTimestampCreation(new Timestamp(System.currentTimeMillis()));
		values.put(Attendu.FIELD_TIMESTAMP_CREATION, attenduDTO.getTimestampCreation());
		try {
			attenduHome.create(id, values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createAttendu", "Erreur cr�ation de la ligne attendue " + attenduDTO.getId());
			throw new EJBException(ce);
		}
		return attenduDTO;
	}


	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#deleteAttendu(String)
	 */
	public void deleteAttendu (String idAttendu) {
		try {
			Attendu attendu = getAttenduEntity(idAttendu);
			attendu.remove();
		} catch (FinderException e) {
			ServiceManager.getInstance().getLoggerManager().finer(CLASSNAME, "deleteAttendu", "Erreur suppression de la ligne attendue avec id " + idAttendu + " : ligne non trouv�e");
		} catch (RemoveException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteAttendu", "Erreur suppression de la ligne attendue avec id " + idAttendu);
			throw new EJBException(e);
		}
	}


	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#rechercheAttendu(String)
	 */
	public AttenduDTO rechercheAttendu (String idAttendu) {
		AttenduDTO attenduDTO = null;
		try {
			Attendu attendu = getAttenduEntity(idAttendu);
			attenduDTO = new AttenduDTO(attendu);
		} catch (FinderException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "rechercheAttendu", "Ligne attendu avec id " + idAttendu + NON_TROUVEE);
		}
		return attenduDTO;
	}

	/**
	 * Gets the attendu entity.
	 *
	 * @param id - the attendu id
	 *
	 * @return the attendu entity
	 *
	 * @throws FinderException the finder exception
	 */
	public Attendu getAttenduEntity (String id) throws FinderException {
		return attenduHome.findByPrimaryKey(new EntityBeanPK(id));
	}


	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#createPredossier(PredossierDTO)
	 */
	public PredossierDTO createPredossier(PredossierDTO predossierDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createPredossier", "Cr�ation de la ligne predossier " + predossierDTO);
		String id = predossierDTO.getId();
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(Predossier.FIELD_ID, id);
		values.put(Predossier.FIELD_HORODATAGE, predossierDTO.getDataBaseHorodatage());
		values.put(Predossier.FIELD_ENSERVICE, predossierDTO.isEnService() ? Constantes.CST_O : Constantes.CST_N);
		try {
			predossierHome.create(id, values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createPredossier", "Erreur cr�ation de la ligne predossier " + predossierDTO.getId());
			throw new EJBException(ce);
		}
		return predossierDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#updatePredossier(PredossierDTO)
	 */
	public void updatePredossier(PredossierDTO predossierDTO) {
		String id = predossierDTO.getId();
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePredossier", "Modification de la ligne predossier " + id);
		try {
			Predossier predossier = predossierHome.findByPrimaryKey(new EntityBeanPK(predossierDTO.getId()));
			predossier.setHorodatage(predossierDTO.getDataBaseHorodatage());
			predossier.setEnservice(predossierDTO.isEnService() ? Constantes.CST_O : Constantes.CST_N);
			long timestamp = predossier.getTimestamp() + 1;
			predossier.setTimestamp(timestamp);
		} catch (FinderException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePredossier", "Predossier avec id " + id + NON_TROUVEE);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager#recherchePredossier(String)
	 */
	public PredossierDTO recherchePredossier (String idPredossier) {
		PredossierDTO predossierDTO = null;
		try {
			Predossier predossier = predossierHome.findByPrimaryKey(new EntityBeanPK(idPredossier));
			predossierDTO = new PredossierDTO(predossier);
		} catch (FinderException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "recherchePredossier", "Predossier avec id " + idPredossier + NON_TROUVEE);
		}
		return predossierDTO;
	}

}