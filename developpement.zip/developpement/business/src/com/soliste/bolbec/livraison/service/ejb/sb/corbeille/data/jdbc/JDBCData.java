/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import java.util.Map;

import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;

/**
 * Facade pour l'utilisation des objets JDBC
 * 
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>25/02/2010</TD><TD>ALE</TD><TD>EV-000029: Ajout d'un getter sur l'idCommande</TD></TR>
 * 
 * @author gdzd8490
 * 
 */
public class JDBCData implements ItemData {

	private String id;

	private Map<String, String> values;

	/**
	 * Constructeur
	 * 
	 * @param id
	 * @param values
	 */
	public JDBCData(String id, Map<String, String> values) {
		this.id = id;
		this.values = values;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#getId()
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * ALE : suppression du throw comment�
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#getValue(java.lang.String)
	 */
	public String getValue(String keyName) {
		return values.get(keyName);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#getValues()
	 */
	public Map<String, String> getValues() {
		return values;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#isReservedByAnotherUser()
	 */
	public boolean isReservedByAnotherUser() {
		return Constantes.CST_OUI.equalsIgnoreCase(this.getValue(Constantes.IS_TRAITEMENT_EN_COURS));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#getCommandeID()
	 */
	public String getCommandeID() {
		return this.getValue(WorkflowConstantes.APPLICATION_ID);
	}

}
