/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.parsifal;

import java.util.Collection;
import java.util.HashMap;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import aps.Transit_PCMS;
import aps.Transit_PCMSHome;

import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.livraison.service.model.TransitPcmsDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Impl�mentation de l'EJB session <code>ParsifalManagerBean</code>.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 */
public class ParsifalManagerBean extends FwkSessionBean implements ParsifalManager {

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = ParsifalManagerBean.class.getName();

	/** The processus home. */
	private Transit_PCMSHome transitPcmsHome;

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			transitPcmsHome = getEntityHome(Transit_PCMSHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.parsifal.ParsifalManager#createTransitPcms(com.soliste.bolbec.livraison.service.model.TransitPcmsDTO)
	 */
	public void createTransitPcms(TransitPcmsDTO transitPcmsDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createTransitPcms", "Cr�ation d'un transitPcms " + transitPcmsDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(Transit_PCMS.FIELD_CODE_TRANSFERT, transitPcmsDTO.getCodeTransfert());
		values.put(Transit_PCMS.FIELD_DATE_TRANSFERT, transitPcmsDTO.getDateTransfert());
		values.put(Transit_PCMS.FIELD_FORMAT_EXTERNE, transitPcmsDTO.getFormatExterne());
		values.put(Transit_PCMS.FIELD_ID_FICHIER, transitPcmsDTO.getIdFichier());
		values.put(Transit_PCMS.FIELD_ID_L_C, transitPcmsDTO.getIdLc());
		String transitPcmsId = transitPcmsDTO.getId();
		try {
			Transit_PCMS transitPcms = transitPcmsHome.create(transitPcmsId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			transitPcms.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createTransitPcms", "Erreur cr�ation du transit pcms " + transitPcmsDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.parsifal.ParsifalManager#findTransitPcmsByIdLdcAndServiceExterneAndIdFichierNull(java.lang.String, java.lang.String)
	 */
	public Boolean findTransitPcmsByIdLdcAndServiceExterneAndIdFichierNull(String ligneCommandeId, String systemeExterne) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEpCommercialByAccesClient", "Recherche les ep commerciaux pour l'acces client " + ligneCommandeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<Transit_PCMS> listTransitPcms = transitPcmsHome.findParIdLdcEtServiceExterneEtIdFichierNull(ligneCommandeId, systemeExterne);
			return listTransitPcms.isEmpty();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEPCommercialByEpCommercialSupport", "Pas d'epCommercial ayant pour acces client = " + ligneCommandeId, fe);
			throw new EJBException(fe);
		}
	}

}
