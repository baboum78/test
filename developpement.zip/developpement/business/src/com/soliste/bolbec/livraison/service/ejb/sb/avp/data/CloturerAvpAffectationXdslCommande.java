/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;
import java.util.List;
import java.util.Map;

import aps.DynamicInstanceRT;

import com.soliste.bolbec.livraison.service.ConstantesRessourcesTech;
import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import com.google.common.base.Strings;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs affection XDSL
 * 
 * @author rgvs7490
 */
public class CloturerAvpAffectationXdslCommande extends CloturerAvpCommande {

	private String centre;
	private String reglette;
	private String broche;
	private String vcCible;
	private String vcOper;
	private final int NB_PARAM = 5;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param centre
	 * @param reglette
	 * @param broche
	 * @param vcCible
	 */
	public CloturerAvpAffectationXdslCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String centre, String reglette, String broche, String vcCible, String vcOper) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.centre = centre.toUpperCase();
		this.reglette = reglette.toUpperCase();
		this.broche = broche.toUpperCase();
		this.vcCible = vcCible;
		this.vcOper = vcOper;
	}

	/**
	 *
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 */
	public CloturerAvpAffectationXdslCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData) {
		super(tacheId, info, causeEvenementId, date, itemData);
	}

	public CloturerAvpAffectationXdslCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String centre, String reglette, String broche, String vcCible) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.centre = centre.toUpperCase();
		this.reglette = reglette.toUpperCase();
		this.broche = broche.toUpperCase();
		this.vcCible = vcCible;
	}

	public String getBroche() {
		return this.broche;
	}

	public String getCentre() {
		return this.centre;
	}

	public String getReglette() {
		return this.reglette;
	}

	public String getVcCible() {
		return this.vcCible;
	}

	public String getVcOper() {
		return this.vcOper;
	}

	public void setCentre(String centre) {
		this.centre = centre;
	}

	public void setReglette(String reglette) {
		this.reglette = reglette;
	}

	public void setBroche(String broche) {
		this.broche = broche;
	}

	public void setVcCible(String vcCible) {
		this.vcCible = vcCible;
	}

	public void setVcOper(String vcOper) {
		this.vcOper = vcOper;
	}

	public void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande){

		int cpt = 0;

		for (LigneCommandeDTO commandePrecedente : listeLigneCommande) {
			List<OpProgrammeeDTO> listOpProgrammeeDTO = ServiceManager.getInstance().getCommandeManager().findOpProgrammeByLigneCommande(commandePrecedente.getId());
			for (OpProgrammeeDTO opProgrammeeDTO: listOpProgrammeeDTO) {
				List<InstanceRtDTO> listInstanceRtDTO = ServiceManager.getInstance().getRessourceTechniqueManager().findInstanceRTByOpProgrammee(opProgrammeeDTO.getId());
				for (InstanceRtDTO instanceRtDTO : listInstanceRtDTO) {
					Map<String,String> dynamicInstanceRT = instanceRtDTO.getDynamicInstanceRts();
					if(this.getCentre() == null && dynamicInstanceRT.get(ConstantesRessourcesTech.CLE_CBL_CENTRE_TRANSPORT) != null){
						this.setCentre(dynamicInstanceRT.get(ConstantesRessourcesTech.CLE_CBL_CENTRE_TRANSPORT));
						cpt++;
					}
					if(this.getBroche() == null && dynamicInstanceRT.get(ConstantesRessourcesTech.CLE_PORTBADSLBROCHE) != null){
						this.setBroche(dynamicInstanceRT.get(ConstantesRessourcesTech.CLE_PORTBADSLBROCHE));
						cpt++;
					}
					if(this.getReglette() == null && dynamicInstanceRT.get(ConstantesRessourcesTech.CLE_PORTBADSLREGLETTE) != null){
						this.setReglette(dynamicInstanceRT.get(ConstantesRessourcesTech.CLE_PORTBADSLREGLETTE));
						cpt++;
					}
					//reste � impl�menter les conditions pour param vcOper et vcCible
					if(cpt>=NB_PARAM){
						break;
					}
				}
				if(cpt>=NB_PARAM){
					break;
				}
			}
			if(cpt>=NB_PARAM){
				break;
			}
		}

		if(dataToSet != null){
			if(dataToSet.getCentre() != null){
				setCentre(dataToSet.getCentre().toUpperCase());
			}
			if(dataToSet.getReglette() != null){
				setReglette(dataToSet.getReglette().toUpperCase());
			}
			if(dataToSet.getBroche() != null){
				setBroche(dataToSet.getBroche().toUpperCase());
			}
			if(dataToSet.getVcCible() != null){
				setVcCible(dataToSet.getVcCible());
			}
			if(dataToSet.getVcOper() != null){
				setVcOper(dataToSet.getVcOper());
			}
		}

	}
}
