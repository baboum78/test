package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.AddressRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.Customer;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * CustomerRessourceTraitementV2
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/10/2016</TD><TD>JDE</TD><TD>Cr�ation de la ressource Customer</TD></TR>
 * <TR><TD>09/11/2016</TD><TD>FCV</TD><TD>Ajout de nouvelles erreurs</TD></TR>
 * </TABLE>
 */
public class CustomerRessourceTraitementV2 {

	private IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * M�thode permettant de r�cup�rer la ressource Customer dont l'id est pass� en param�tre
	 * 
	 * @param serviceOrderId l'id de la ressource ServiceOrder � laquelle est rattach�e la ressource Customer � r�cup�rer
	 * @param customerId l'id de la ressource Customer � r�cup�rer
	 * @param context le contexte de la requ�te
	 * @return la ressource Customer dont l'id est pass� en param�tre
	 */
	public Response getCustomer(String serviceOrderId, String customerId, @SuppressWarnings("unused") MessageContext context) {
		// R�cup�ration de la commande
		CommandeDTO commande = null;
		if (!StringUtils.isBlank(serviceOrderId)) {
			commande = serviceManager.getCommandeManager().getCommande(serviceOrderId);
		}

		// On remonte une erreur si la commande n'existe pas
		if (commande == null) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(serviceOrderId);
		}

		// R�cup�ration du client
		ClientDTO client = null;
		if (!StringUtils.isBlank(customerId)) {
			client = serviceManager.getCommandeManager().getClient(customerId);
		}

		// On remonte une erreur si le client n'existe pas
		if (client == null) {
			throw APIExceptionEnum.customeridnotfound.createAPIException(customerId);
		}

		// On v�rifie que le client est bien li� � la commande
		if (!commande.getClient().getId().equals(client.getId())) {
			// Ou � une ligne de commande
			List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
			LigneCommandeDTO ligneCommande = CollectionUtils.getFirstOrNull(lignesCommande);
			if (!ligneCommande.getClient().getId().equals(client.getId())) {
				throw APIExceptionEnum.customerandordernotlinked.createAPIException(customerId, serviceOrderId);
			}
		}

		// Cr�ation de l'objet Customer qu'on va retourner
		Customer customer = new Customer();
		customer.setId(client.getId());
		customer.setTitle(client.getTitre());
		customer.setExternalId(client.getIdExterne());
		customer.setSiren(client.getSiren());
		customer.setNic(client.getNic());
		customer.setType(client.getTypeClient());
		customer.setLastName(client.getDenomination());
		customer.setFirstName(client.getPrenom());
		customer.setPhone(client.getTelContact());
		customer.setCategory(client.getCategorieClient().getId());

		// Cr�ation de l'objet AddressRef
		if (client.getAdresse() != null) {
			AddressRef address = new AddressRef();
			address.setId(client.getAdresse().getId());
			customer.setAddress(address);
		}

		return Response.ok(customer).build();
	}

}
