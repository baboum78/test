/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs Maj Parc Materiel
 * 
 * @author rgvs7490
 */
public class CloturerAvpMajParcMaterielCommande extends CloturerAvpCommande {

	private String usc;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param usc
	 */
	public CloturerAvpMajParcMaterielCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String usc) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.usc = usc.toUpperCase();
	}

	public String getUsc() {
		return this.usc;
	}
}
