package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * Classe cr��e pour la Artemis-2867 : Ajout d'une classe Data contenant une cl� et une valeur
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "taskData")
public class TaskData {

	private String key, value;

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public boolean equals(TaskData data){
		return data.key.equals(this.key) && data.value.equals(this.value);
	}

	public String toString(){
		return "TaskData - Key : " + this.getKey() + "; Value : " + this.getValue() + ";";
	}
}
