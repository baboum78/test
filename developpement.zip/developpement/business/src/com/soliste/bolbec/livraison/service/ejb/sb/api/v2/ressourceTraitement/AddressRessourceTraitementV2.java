package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.Address;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * AddressRessourceTraitementV2
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/10/2016</TD><TD>JDE</TD><TD>Cr�ation de la ressource Address</TD></TR>
 * <TR><TD>09/11/2016</TD><TD>FCV</TD><TD>Ajout de nouvelles erreurs</TD></TR>
 * </TABLE>
 */
public class AddressRessourceTraitementV2 {

	private static final int MAX_STREETNAME_SIZE = 128;
	private static final int MAX_STREETNUMBER_SIZE = 40;
	private static final int MAX_STREETLETTER_SIZE = 26;
	private static final int MAX_BUILDINGNAME_SIZE = 60;
	private static final int MAX_STREETTYPE_SIZE = 40;
	private static final int MAX_FLOOR_SIZE = 40;
	private static final int MAX_LOGO_SIZE = 40;
	private static final int MAX_STREETCODE_SIZE = 40;
	private static final int MAX_SET_SIZE = 40;
	private static final int MAX_STAIRCASENUMBER_SIZE = 40;
	private static final int MAX_DOOR_SIZE = 40;
	private static final int MAX_CITYCODE_SIZE = 5;
	private static final int MAX_POSTALCODE_SIZE = 40;
	private static final int MAX_CITYNAME_SIZE = 80;
	private static final int MAX_BUILDINGID_SIZE = 512;
	private static final int MAX_BUILDINGOPERATOR_SIZE = 512;
	private static final int MAX_OPTICALPLUGID_SIZE = 512;
	private static final int MAX_OPTICALPLUGALREADYINSTALLED_SIZE = 512;

	private IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * M�thode permettant de r�cup�rer la ressource Address dont l'id est pass� en param�tre
	 * 
	 * @param serviceOrderId l'id de la ressource ServiceOrder � laquelle est rattach�e la ressource Customer � laquelle est rattach�e la ressource Address � r�cup�rer
	 * @param customerId l'id de la ressource Customer � laquelle est rattach�e la ressource Address � r�cup�rer
	 * @param addressId l'id de la ressource Address � r�cup�rer
	 * @param context le contexte de la requ�te
	 * @return la ressource Address dont l'id est pass� en param�tre
	 */
	public Response getAddress(String serviceOrderId, String customerId, String addressId, @SuppressWarnings("unused") MessageContext context) {
		// R�cup�ration de la commande
		CommandeDTO commande = null;
		if (!StringUtils.isBlank(serviceOrderId)) {
			commande = serviceManager.getCommandeManager().getCommande(serviceOrderId);
		}

		// On remonte une erreur si la commande n'existe pas
		if (commande == null) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(serviceOrderId);
		}

		// R�cup�ration du client
		ClientDTO client = null;
		if (!StringUtils.isBlank(customerId)) {
			client = serviceManager.getCommandeManager().getClient(customerId);
		}

		// On remonte une erreur si le client n'existe pas
		if (client == null) {
			throw APIExceptionEnum.customeridnotfound.createAPIException(customerId);
		}

		// R�cup�ration de l'adresse
		AdresseDTO adresse = null;
		if (!StringUtils.isBlank(addressId)) {
			adresse = serviceManager.getCommandeManager().getAdresse(addressId);
		}

		// On remonte une erreur si l'adresse n'existe pas
		if (adresse == null) {
			throw APIExceptionEnum.addressidnotfound.createAPIException(addressId);
		}

		// On v�rifie que le client est bien li� � la commande
		List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
		LigneCommandeDTO ligneCommande = CollectionUtils.getFirstOrNull(lignesCommande);
		// PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(ligneCommande.getId());

		if (!commande.getClient().getId().equals(client.getId())) {
			// Ou � une ligne de commande
			if (!ligneCommande.getClient().getId().equals(client.getId())) {
				throw APIExceptionEnum.customerandordernotlinked.createAPIException(customerId, serviceOrderId);
			}
		}

		// On v�rifie que l'adresse est bien li�e au client
		if (!client.getAdresse().getId().equals(adresse.getId())) {
			throw APIExceptionEnum.customerandaddressnotlinked.createAPIException(customerId, addressId);
		}
		// R�cup�ration du psSouhait�

		// Cr�ation de l'objet Address qu'on va retourner
		Address address = new Address();
		address.setId(adresse.getId());
		address.setStreetName(adresse.getLibelleVoie());
		address.setStreetNumber(adresse.getNumeroVoie());
		address.setStreetLetter(adresse.getCpltnumVoie());
		address.setBuildingName(adresse.getBatiment());
		address.setStreetType(adresse.getTypeVoie());
		address.setFloor(adresse.getEtage());
		address.setLogo(adresse.getLogo());
		address.setStreetCode(adresse.getCodeRivoli());
		address.setSet(adresse.getEnsemble());
		address.setStaircaseNumber(adresse.getEscalier());
		address.setDoor(adresse.getPorte());
		address.setCityCode(adresse.getCodeInsee());
		address.setPostalCode(adresse.getCodePostal());
		address.setCityName(adresse.getVille());
		// QC-980 r�cup�ration des champs adresse compl�mentaires
		for (LigneCommandeDTO lc : lignesCommande) {
			PsSouhaiteDTO pss = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());

			String imb = lc.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.CLE_CODE_IMMEUBLE);
			if (StringUtils.isNotBlank(imb)) {
				address.setBuildingId(imb);
			}
			if (pss != null) {
				String ptoid = pss.getDynamicPsSouhaites().get(ConstantesDynamicPSSouhaite.PTOID);
				if (StringUtils.isNotBlank(ptoid)) {
					address.setOpticalPlugId(ptoid);
				}
			}
			String plpssptoid = lc.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.CLE_PRISE_EXISTANTE);
			if (StringUtils.isNotBlank(plpssptoid)) {
				address.setOpticalPlugAlreadyInstalled(plpssptoid);
			}
			String oi = lc.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE);
			if (StringUtils.isNotBlank(oi)) {
				address.setBuildingOperator(oi);
			}

		}
		return Response.ok(address).build();
	}

	/**
	 * M�thode permettant de modifier la ressource Address dont l'id est pass� en param�tre
	 * 
	 * @param serviceOrderId l'id de la ressource ServiceOrder � laquelle est rattach�e la ressource Customer � laquelle est rattach�e la ressource Address � r�cup�rer
	 * @param customerId l'id de la ressource Customer � laquelle est rattach�e la ressource Address � r�cup�rer
	 * @param addressId l'id de la ressource Address � r�cup�rer
	 * @param address l'address telle qu'on doit la modifier
	 * @param context le contexte de la requ�te
	 * @return la ressource Address dont l'id est pass� en param�tre
	 */
	public Response updateAddress(String serviceOrderId, String customerId, String addressId, Address address, MessageContext context) {
		// R�cup�ration de la commande
		CommandeDTO commande = null;
		if (!StringUtils.isBlank(serviceOrderId)) {
			commande = serviceManager.getCommandeManager().getCommande(serviceOrderId);
		}

		// On remonte une erreur si la commande n'existe pas
		if (commande == null) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(serviceOrderId);
		}

		// R�cup�ration du client
		ClientDTO client = null;
		if (!StringUtils.isBlank(customerId)) {
			client = serviceManager.getCommandeManager().getClient(customerId);
		}

		// On remonte une erreur si le client n'existe pas
		if (client == null) {
			throw APIExceptionEnum.customeridnotfound.createAPIException(customerId);
		}

		// R�cup�ration de l'adresse
		AdresseDTO adresse = null;
		if (!StringUtils.isBlank(addressId)) {
			adresse = serviceManager.getCommandeManager().getAdresse(addressId);
		}

		// On remonte une erreur si l'adresse n'existe pas
		if (adresse == null) {
			throw APIExceptionEnum.addressidnotfound.createAPIException(addressId);
		}

		// On v�rifie que le client est bien li� � la commande
		if (!commande.getClient().getId().equals(client.getId())) {
			// Ou � une ligne de commande
			List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
			LigneCommandeDTO ligneCommande = CollectionUtils.getFirstOrNull(lignesCommande);
			if (!ligneCommande.getClient().getId().equals(client.getId())) {
				throw APIExceptionEnum.customerandordernotlinked.createAPIException(customerId, serviceOrderId);
			}
		}

		// On v�rifie que l'adresse est bien li�e au client
		if (!client.getAdresse().getId().equals(adresse.getId())) {
			throw APIExceptionEnum.customerandaddressnotlinked.createAPIException(customerId, addressId);
		}
		List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());

		// MAJ de l'objet AdresseDTO
		if (address.getStreetName() != null) {
			adresse.setLibelleVoie(address.getStreetName());
		}
		if (address.getStreetNumber() != null) {
			adresse.setNumeroVoie(address.getStreetNumber());
		}
		if (address.getStreetLetter() != null) {
			adresse.setCpltnumVoie(address.getStreetLetter());
		}
		if (address.getBuildingName() != null) {
			adresse.setBatiment(address.getBuildingName());
		}
		if (address.getStreetType() != null) {
			adresse.setTypeVoie(address.getStreetType());
		}
		if (address.getFloor() != null) {
			adresse.setEtage(address.getFloor());
		}
		if (address.getLogo() != null) {
			adresse.setLogo(address.getLogo());
		}
		if (address.getStreetCode() != null) {
			adresse.setCodeRivoli(address.getStreetCode());
		}
		if (address.getSet() != null) {
			adresse.setEnsemble(address.getSet());
		}
		if (address.getStaircaseNumber() != null) {
			adresse.setEscalier(address.getStaircaseNumber());
		}
		if (address.getDoor() != null) {
			adresse.setPorte(address.getDoor());
		}
		if (address.getCityCode() != null) {
			adresse.setCodeInsee(address.getCityCode());
		}
		if (address.getPostalCode() != null) {
			adresse.setCodePostal(address.getPostalCode());
		}
		if (address.getCityName() != null) {
			adresse.setVille(address.getCityName());
		}

		// Persistance de l'objet AdresseDTO en BDD
		try {
			serviceManager.getCommandeManager().updateAdresse(adresse);
		} catch (Exception e) {
			throw APIExceptionEnum.addresserrorupdating.createAPIException(addressId);
		}

		// MAJ des dynamic LC et PSS
		for (LigneCommandeDTO lc : lignesCommande) {
			if (StringUtils.isNotBlank(address.getBuildingId())) {
				lc.getDynamicLigneCommandes().put(ConstantesDynamicLigneCommande.CLE_CODE_IMMEUBLE, address.getBuildingId());
			}

			if (StringUtils.isNotBlank(address.getBuildingOperator())) {
				lc.getDynamicLigneCommandes().put(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE, address.getBuildingOperator());
			}

			if (StringUtils.isNotBlank(address.getOpticalPlugAlreadyInstalled())) {
				lc.getDynamicLigneCommandes().put(ConstantesDynamicLigneCommande.CLE_PRISE_EXISTANTE, address.getOpticalPlugAlreadyInstalled());
			}

			// Persistance des dynamic LC en BDD
			try {
				serviceManager.getCommandeManager().updateDynamicLigneCommande(lc);
			} catch (Exception e) {
				throw APIExceptionEnum.addresserrorupdating.createAPIException(addressId);
			}

			PsSouhaiteDTO pss = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
			if (pss != null && StringUtils.isNotBlank(address.getOpticalPlugId())) {
				pss.getDynamicPsSouhaites().put(ConstantesDynamicPSSouhaite.PTOID, address.getOpticalPlugId());

				// Persistance des dynamic PSS en BDD
				try {
					serviceManager.getCommandeManager().updateDynamicPsSouhaite(pss);
				} catch (Exception e) {
					throw APIExceptionEnum.addresserrorupdating.createAPIException(addressId);
				}
			}
		}

		return getAddress(serviceOrderId, customerId, addressId, context);
	}

	/**
	 * M�thode permettant de valider la ressource Address
	 * 
	 * @param address la ressource Address � valider
	 */
	public void validate(Address address) {
		if (address.getStreetName() != null && address.getStreetName().length() > MAX_STREETNAME_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("streetName", String.valueOf(MAX_STREETNAME_SIZE));
		}

		if (address.getStreetNumber() != null && address.getStreetNumber().length() > MAX_STREETNUMBER_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("streetNumber", String.valueOf(MAX_STREETNUMBER_SIZE));
		}

		if (address.getStreetLetter() != null && address.getStreetLetter().length() > MAX_STREETLETTER_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("streetLetter", String.valueOf(MAX_STREETLETTER_SIZE));
		}

		if (address.getBuildingName() != null && address.getBuildingName().length() > MAX_BUILDINGNAME_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("buildingName", String.valueOf(MAX_BUILDINGNAME_SIZE));
		}

		if (address.getStreetType() != null && address.getStreetType().length() > MAX_STREETTYPE_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("streetType", String.valueOf(MAX_STREETTYPE_SIZE));
		}

		if (address.getFloor() != null && address.getFloor().length() > MAX_FLOOR_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("floor", String.valueOf(MAX_FLOOR_SIZE));
		}

		if (address.getLogo() != null && address.getLogo().length() > MAX_LOGO_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("logo", String.valueOf(MAX_LOGO_SIZE));
		}

		if (address.getStreetCode() != null && address.getStreetCode().length() > MAX_STREETCODE_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("streetCode", String.valueOf(MAX_STREETCODE_SIZE));
		}

		if (address.getSet() != null && address.getSet().length() > MAX_SET_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("set", String.valueOf(MAX_SET_SIZE));
		}

		if (address.getStaircaseNumber() != null && address.getStaircaseNumber().length() > MAX_STAIRCASENUMBER_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("staircaseNumber", String.valueOf(MAX_STAIRCASENUMBER_SIZE));
		}

		if (address.getDoor() != null && address.getDoor().length() > MAX_DOOR_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("door", String.valueOf(MAX_DOOR_SIZE));
		}

		if (address.getCityCode() != null && address.getCityCode().length() > MAX_CITYCODE_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("cityCode", String.valueOf(MAX_CITYCODE_SIZE));
		}

		if (address.getPostalCode() != null && address.getPostalCode().length() > MAX_POSTALCODE_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("postalCode", String.valueOf(MAX_POSTALCODE_SIZE));
		}

		if (address.getCityName() != null && address.getCityName().length() > MAX_CITYNAME_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("cityName", String.valueOf(MAX_CITYNAME_SIZE));
		}

		if (address.getBuildingId() != null && address.getBuildingId().length() > MAX_BUILDINGID_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("buildingId", String.valueOf(MAX_BUILDINGID_SIZE));
		}

		if (address.getBuildingOperator() != null && address.getBuildingOperator().length() > MAX_BUILDINGOPERATOR_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("buildingOperator", String.valueOf(MAX_BUILDINGOPERATOR_SIZE));
		}

		if (address.getOpticalPlugId() != null && address.getOpticalPlugId().length() > MAX_OPTICALPLUGID_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("opticalPlugId", String.valueOf(MAX_OPTICALPLUGID_SIZE));
		}

		if (address.getOpticalPlugAlreadyInstalled() != null && address.getOpticalPlugAlreadyInstalled().length() > MAX_OPTICALPLUGALREADYINSTALLED_SIZE) {
			throw APIExceptionEnum.addresserrorvalidating.createAPIException("opticalPlugAlreadyInstalled", String.valueOf(MAX_OPTICALPLUGALREADYINSTALLED_SIZE));
		}
	}
}
