/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Interface home de l'EJB session <code>CommandeManager</code>.
 */
public interface CommandeManagerHome extends EJBLocalHome {

	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public CommandeManagerLocal create() throws CreateException;

}
