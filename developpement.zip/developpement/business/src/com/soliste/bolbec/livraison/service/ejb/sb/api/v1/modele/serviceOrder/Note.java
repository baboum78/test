package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder;

import java.util.Calendar;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.soliste.bolbec.livraison.service.ejb.sb.api.adapter.CalendarAdapter;

/**
 * Modele Ressource Note
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/11/2015</TD><TD>MFA</TD><TD>Initialisation du Note</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "note")
public class Note {

	private String id;
	private String author;
	private NoteType type;
	@XmlJavaTypeAdapter(CalendarAdapter.class)
	private Calendar date;
	private String text;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the author
	 */
	public String getAuthor() {
		return author;
	}

	/**
	 * @param author the author to set
	 */
	public void setAuthor(String author) {
		this.author = author;
	}

	/**
	 * @return the type
	 */
	public NoteType getType() {
		return type;
	}

	/**
	 * @param type the type to set
	 */
	public void setType(NoteType type) {
		this.type = type;
	}

	/**
	 * @return the date
	 */
	public Calendar getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Calendar date) {
		this.date = date;
	}

	/**
	 * @return the text
	 */
	public String getText() {
		return text;
	}

	/**
	 * @param text the text to set
	 */
	public void setText(String text) {
		this.text = text;
	}

}
