/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;
import java.util.List;

import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO contenant les donn�es associ�es � une phase d'un processus
 * 
 * @author rgvs7490
 */
public class PhaseDTO implements Serializable {

	private ProcessusDTO processus;
	private TacheDTO phase;
	private List<EvtDTO> evenements;
	private List<ProcessusDTO> sousProcessusList;

	/**
	 * 
	 */
	PhaseDTO() {
	}

	public List<EvtDTO> getEvenements() {
		return this.evenements;
	}

	void setEvenements(List<EvtDTO> evenements) {
		this.evenements = evenements;
	}

	public TacheDTO getPhase() {
		return this.phase;
	}

	void setPhase(TacheDTO phase) {
		this.phase = phase;
	}

	public ProcessusDTO getProcessus() {
		return this.processus;
	}

	void setProcessus(ProcessusDTO processus) {
		this.processus = processus;
	}

	public List<ProcessusDTO> getSousProcessusList() {
		return this.sousProcessusList;
	}

	void setSousProcessusList(List<ProcessusDTO> sousProcessusList) {
		this.sousProcessusList = sousProcessusList;
	}
}
