/**
 * 
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>06/07/2018</TD><TD>AJO</TD><TD>QC980 : Intrants FTTH</TD></TR>
 * </TABLE><BR>
 */

/**
 * Les infos d'AVP pour les AVP de type "AvpCtrlCoherenceCmd"
 * 
 */
public class AvpCtrlCoherenceCmdDTO extends AvpInfoDTO {

	private String codeImmeuble;
	private String cpltNumVoie;
	private String numeroVoie;
	private String batiment;
	private String etage;
	private String codeRivoli;
	private String escalier;
	private String codeInsee;
	private String referencePrise;
	private String priseExistante;
	private String operateurImmeuble;

	public AvpCtrlCoherenceCmdDTO() {

	}

	public String getType() {
		return AVP_CTRL_COHERENCE_CMD;
	}

	/**
	 * @return the codeImmeuble
	 */
	public String getCodeImmeuble() {
		return codeImmeuble;
	}

	/**
	 * @param codeImmeuble the codeImmeuble to set
	 */
	public void setCodeImmeuble(String codeImmeuble) {
		this.codeImmeuble = codeImmeuble;
	}

	/**
	 * @return the cpltNumVoie
	 */
	public String getCpltNumVoie() {
		return cpltNumVoie;
	}

	/**
	 * @param cpltNumVoie the cpltNumVoie to set
	 */
	public void setCpltNumVoie(String cpltNumVoie) {
		this.cpltNumVoie = cpltNumVoie;
	}

	/**
	 * @return the numeroVoie
	 */
	public String getNumeroVoie() {
		return numeroVoie;
	}

	/**
	 * @param numeroVoie the numeroVoie to set
	 */
	public void setNumeroVoie(String numeroVoie) {
		this.numeroVoie = numeroVoie;
	}

	/**
	 * @return the batiment
	 */
	public String getBatiment() {
		return batiment;
	}

	/**
	 * @param batiment the batiment to set
	 */
	public void setBatiment(String batiment) {
		this.batiment = batiment;
	}

	/**
	 * @return the etage
	 */
	public String getEtage() {
		return etage;
	}

	/**
	 * @param etage the etage to set
	 */
	public void setEtage(String etage) {
		this.etage = etage;
	}

	/**
	 * @return the codeRivoli
	 */
	public String getCodeRivoli() {
		return codeRivoli;
	}

	/**
	 * @param codeRivoli the codeRivoli to set
	 */
	public void setCodeRivoli(String codeRivoli) {
		this.codeRivoli = codeRivoli;
	}

	/**
	 * @return the escalier
	 */
	public String getEscalier() {
		return escalier;
	}

	/**
	 * @param escalier the escalier to set
	 */
	public void setEscalier(String escalier) {
		this.escalier = escalier;
	}

	/**
	 * @return the codeInsee
	 */
	public String getCodeInsee() {
		return codeInsee;
	}

	/**
	 * @param codeInsee the codeInsee to set
	 */
	public void setCodeInsee(String codeInsee) {
		this.codeInsee = codeInsee;
	}

	/**
	 * @return the referencePrise
	 */
	public String getReferencePrise() {
		return referencePrise;
	}

	/**
	 * @param referencePrise the referencePrise to set
	 */
	public void setReferencePrise(String referencePrise) {
		this.referencePrise = referencePrise;
	}

	/**
	 * @return the priseExistante
	 */
	public String getPriseExistante() {
		return priseExistante;
	}

	/**
	 * @param priseExistante the priseExistante to set
	 */
	public void setPriseExistante(String priseExistante) {
		this.priseExistante = priseExistante;
	}

	/**
	 * @return the operateurImmeuble
	 */
	public String getOperateurImmeuble() {
		return operateurImmeuble;
	}

	/**
	 * @param operateurImmeuble the operateurImmeuble to set
	 */
	public void setOperateurImmeuble(String operateurImmeuble) {
		this.operateurImmeuble = operateurImmeuble;
	}

}
