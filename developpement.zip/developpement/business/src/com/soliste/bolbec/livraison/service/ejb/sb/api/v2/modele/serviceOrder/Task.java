package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Role;

/**
 * Modele Ressource Task v2
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/10/2016</TD><TD>JDE</TD><TD>Cr�ation de la ressource Task v2</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "task")
public class Task extends com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Task {

	private Role assignatedRole;

	/**
	 * @return the assignatedRole
	 */
	@Override
	public Object getAssignatedRole() {
		return assignatedRole;
	}

	/**
	 * @param assignatedRole the assignatedRole to set
	 */
	public void setAssignatedRole(Role assignatedRole) {
		this.assignatedRole = assignatedRole;
	}

}
