package com.soliste.bolbec.livraison.service.anomalies;

import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.exception.CancelException;
import com.soliste.bolbec.livraison.service.exception.DoneException;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.InterfaceException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.commun.GestionErreurInterface;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.commun.IOParam;
import com.soliste.bolbec.livraison.service.util.ExecStepAutoData;
import com.soliste.bolbec.livraison.service.util.IServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Ajout de la m�thode getGestionErreurInterface</TD></TR>
 * </TABLE><BR>
 */

public interface IAnomalieManager {

	/**
	 * Met � jour le role pour l'evenement en fonction de la propri�t� workflow FamilleOffre
	 * 
	 * @param evenement
	 * @param idTraitement
	 * @param proprietesWorkflow
	 * 
	 * @return l'�v�nement initial mis � jour.
	 */
	public Evenement majRoleEvenement(Evenement evenement, String idTraitement, Map<String, String> proprietesWorkflow);

	/**
	 * Retourne un �v�nement en fonction d'une anomalie pour un traitement
	 * donn�.
	 * 
	 * @param idTraitement
	 * @param sfAno
	 * @return un �v�nement en fonction d'une anomalie pour un traitement donn�.
	 */
	public Evenement traiter(String idTraitement, SFAno sfAno);

	/**
	 * newAnomalieException
	 * 
	 * @param nomSF
	 * @param erreur
	 * @param type
	 * @param message
	 * @return <code>AnomalieException</code>
	 */
	public AnomalieException newAnomalieException(String nomSF, String erreur, String type, String message);

	/**
	 * newAnomalieException
	 * 
	 * @param nomSF
	 * @param erreur
	 * @param message
	 * @return <code>AnomalieException</code>
	 */
	public AnomalieException newAnomalieException(String nomSF, String erreur, String message);

	/**
	 * newSFAno
	 * 
	 * @param nomSF
	 * @param erreur
	 * @param type
	 * @param message
	 * @return SFAno
	 */
	public SFAno newSFAno(String nomSF, String erreur, String type, String message);

	/**
	 * newSFAno
	 * 
	 * @param nomSF
	 * @param erreur
	 * @param type
	 * @param message
	 * @return SFAno
	 */
	public SFAno newSFAno(String nomSF, String erreur, String message);

	/**
	 * newAno
	 * 
	 * @param erreur
	 * @param type
	 * @param message
	 * @return SFAno
	 */
	public SFAno newAno(String erreur, String type, String message);

	/**
	 * 
	 * @param erreur
	 * @param type
	 * @param message
	 * @param nomSF
	 * @return
	 */
	public SFAno newAno(String erreur, String type, String message, String nomSF);

	/**
	 * cr�e uen nouvelle SFAno en r�cup�rant le type en base
	 * 
	 * @param erreur
	 * @param message
	 * @return SFAno
	 */
	public SFAno newAno(String erreur, String message);

	/**
	 * getMessage
	 * 
	 * @param messageId
	 * @param params
	 * @return un message format� dont les param�tres ont �t� remplac�s
	 */
	public String getMessage(String messageId, Object... params);

	/**
	 * getMessage
	 * 
	 * @param messageId
	 * @return un message format�
	 */
	public String getMessage(String messageId);

	/**
	 * Permet de changer le serviceManager
	 * 
	 * @param serviceManager
	 */
	public void setServiceManager(IServiceManager serviceManager);

	/**
	 * M�thode permettant de g�n�rer une SFAno et de la lancer
	 * 
	 * @param data Les informations du StepAuto
	 * @param staticAttributes Les attributs static du StepAuto
	 * @param erreur Le code de l'erreur {@link aps.AnomalieConstantes})
	 * @param type Le type d'erreur {@link aps.SFAno}
	 * @param messageId l'identifiant du message {@link aps.MessagesConstantes}
	 * @param paramMessage Les param�tres pour constituer le message
	 * @throws DoneException Pour arr�ter l'ex�cution du processus (Continuer)
	 * @throws CancelException Pour arr�ter l'ex�cution du processus (Annulation)
	 */
	public void genererAnomalie(ExecStepAutoData data, Map<String, List<String>> staticAttributes, String erreur, String type, String messageId, Object... paramMessage) throws CancelException, DoneException;

	/**
	 * Permet de d'obtenir une instance de la classe GestionErreurInterface
	 * 
	 * @param nomSf Le service fonctionnel
	 * @param io L'objet echang� entre le TRT et le SF
	 * @param codeErreurInterface Le code d'erreur de l'interface
	 * @param origineCodeErreur L'identifiant du serviceExterne qui � soulev� le code d'erreur
	 * 
	 * @return Une instance de la classe GestionErreurInterface
	 */
	public GestionErreurInterface getGestionErreurInterface(String nomSf, String origineCodeErreur, IOParam io, String codeErreurInterface);

	/**
	 * Permet de d'obtenir une instance de la classe GestionErreurInterface
	 * 
	 * @param nomSf Le service fonctionnel
	 * @param io L'objet echang� entre le TRT et le SF
	 * @param ie L'interfaceException
	 * @param origineCodeErreur L'identifiant du serviceExterne qui � soulev� le code d'erreur
	 * 
	 * @return Une instance de la classe GestionErreurInterface
	 */
	public GestionErreurInterface getGestionErreurInterface(String nomSf, String origineCodeErreur, IOParam io, InterfaceException ie);

}