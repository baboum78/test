/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception;

/**
 * Exception lors du chargement des donn�es corbeille
 * 
 * @author gdzd8490
 * 
 */
public class CorbeilleLoaderException extends Exception {

	/**
	 * Constructeur
	 * 
	 * @param arg0
	 */
	public CorbeilleLoaderException(String arg0) {
		super(arg0);
	}

	/**
	 * Constructeur
	 * 
	 * @param arg0
	 */
	public CorbeilleLoaderException(Throwable arg0) {
		super(arg0);
	}

	/**
	 * Constructeur
	 * 
	 * @param arg0
	 * @param arg1
	 */
	public CorbeilleLoaderException(String arg0, Throwable arg1) {
		super(arg0, arg1);
	}

}
