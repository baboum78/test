/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.util.Date;

import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;

/**
 * Interface pour la cr�ation de filtres corbeille
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/01/2014</TD><TD>FTE</TD><TD>EV-000268 : Crit�re de Filtre Multizones</TD></TR>
 * </TABLE><BR>
 *
 */
public interface FiltreDTOFactory {

	/** Role pour les step autos */
	public final String STEP_AUTO_PRIVILEGE = WorkflowConstantes.STEP_AUTO_PRIVILEGE;

	/** Valeur inexistante pour ne ramener aucun r�sultat */
	public final String VALEUR_INEXISTANTE = "VALEURINEXISTANTE";

	/** Op�rateur �gal */
	public final String FILTER_COMPARATOR_EQUAL = "EQUAL";

	/** Op�rateur inf�rieur */
	public final String FILTER_COMPARATOR_LOWER = "LOWER";

	/** Op�rateur sup�rieur */
	public final String FILTER_COMPARATOR_GREATER = "GREATER";

	/** Op�rateur like */
	public final String FILTER_COMPARATOR_LIKE = "LIKE";

	/* Op�rateur like upper */
	public final String FILTER_COMPARATOR_LIKE_UPPER = "LIKE UPPER";

	/** Op�rateur is null */
	public final String FILTER_COMPARATOR_IS_NULL = "IS NULL";

	/**
	 * Construit le filtre par d�faut pour les corbeille toutes t�ches et t�ches
	 * 
	 * @param agentId
	 * l'utilisateur courant
	 * @return le filtre par d�faut pour la corbeille toutes t�ches et t�ches
	 */
	public FiltreDTO createToutesTachesFilter(String agentId);

	/**
	 * Construit le filtre par d�faut pour la corbeille t�ches critiques *
	 * 
	 * @param agentId
	 * l'utilisateur courant
	 * @return le filtre par d�faut pour la corbeille t�ches critiques
	 */
	public FiltreDTO createTachesCritiquesFilter(String agentId);

	/**
	 * Construit le filtre par d�faut pour la corbeille processus suspendus *
	 * 
	 * @param agentId
	 * l'utilisateur courant
	 * @return le filtre par d�faut pour la corbeille processus suspendus
	 */
	public FiltreDTO createProcessusSuspendusFilter(String agentId);

	/**
	 * Creation d'un filtre texte *
	 * 
	 * @param infoId
	 * @param comparatorType
	 * @param texte
	 * @return un filtre DTO contenant le filtre sous forme de DataFiltre
	 */
	public FiltreDTO createTexteFiltreDataFilter(String infoId, String comparatorType, String texte);

	/**
	 * Creation d'un filtre multi criteres *
	 * 
	 * @param infoId
	 * @param valueArray
	 * @return un filtre DTO contenant le filtre sous forme de DataFiltre
	 */
	public FiltreDTO createMultiCriteresDataFilter(String infoId, String[] valueArray);

	/**
	 * Cr�ation d'un filtre pour une p�riode temporelle
	 * 
	 * @param infoId
	 * @param beginDate
	 * @param endDate
	 * @return un filtre DTO contenant le filtre sous forme de DataFiltre
	 */
	public FiltreDTO createDateIntervalFiltreDataFilter(String infoId, Date beginDate, Date endDate);

	/**
	 * Cr�ation d'un filtre pour une p�riode temporelle
	 * 
	 * @param infoId
	 * @param date
	 * @param greaterThan
	 * 
	 * @return un filtre DTO contenant le filtre sous forme de DataFiltre
	 */
	public FiltreDTO createDateCompareFiltreDataFilter(String infoId, Date date, boolean greaterThan);

	/**
	 * Cr�ation d'un filtre date
	 * 
	 * 
	 * @param infoId
	 * @param comparatorType
	 * @param date
	 * @return un filtre DTO contenant le filtre sous forme de DataFiltre
	 */
	public FiltreDTO createDateFiltreDataFilter(String infoId, String comparatorType, Date date);

}
