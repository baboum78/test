/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import aps.CatClientUnite;
import aps.RoleClientConstantes;
import aps.ZoneGeoUnite;
import aps.ZoneSIUnite;

import com.soliste.aps.workflow.WfAdvancedDataFilter;
import com.soliste.aps.workflow.WfBaseDataFilter;
import com.soliste.aps.workflow.WfDataFilter;
import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.CatClientUniteDTO;
import com.soliste.bolbec.commun.service.model.ZoneGeoUniteDTO;
import com.soliste.bolbec.commun.service.model.ZoneSiUniteDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/04/2010</TD><TD>DBA</TD><TD>EV-000047: Nouveau filtre pour s�lectionner une commande par son identifiant</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>14/01/2014</TD><TD>FTE</TD><TD>EV-000268 : Crit�re de Filtre Multizones</TD></TR>
 * </TABLE>
 * 
 * Factory pour les FiltreDTO contenant des filtres workflow
 * 
 * @author gdzd8490
 * 
 */
public class WfFiltreDTOFactory implements FiltreDTOFactory {

	private static WfFiltreDTOFactory instance = null;

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static WfFiltreDTOFactory getInstance() {
		if (instance == null) {
			instance = new WfFiltreDTOFactory();
		}
		return instance;
	}

	private WfFiltreDTOFactory() {
		// pour �viter instanciation inutile
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createToutesTachesFilter(java.lang.String)
	 */
	public FiltreDTO createToutesTachesFilter(String agentId) {
		List<WfDataFilter> filters = new ArrayList<WfDataFilter>();
		filters.add(createUniteActiviteFilter(agentId));
		filters.add(createEtatSuspensionFalseFilter());
		WfDataFilter wfFiltre = mergeWfFilters(filters);
		return new WfFiltreDTO(wfFiltre);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createTachesCritiquesFilter(java.lang.String)
	 */
	public FiltreDTO createTachesCritiquesFilter(String agentId) {
		List<WfDataFilter> filters = new ArrayList<WfDataFilter>();
		filters.add(createUniteActiviteFilter(agentId));
		filters.add(createEtatSuspensionFalseFilter());
		filters.add(createSansTacheAdHocFilter());
		filters.add(createCommandesCritiquesFilter());
		WfDataFilter wfFiltre = mergeWfFilters(filters);
		return new WfFiltreDTO(wfFiltre);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createProcessusSuspendusFilter(java.lang.String)
	 */
	public FiltreDTO createProcessusSuspendusFilter(String agentId) {
		List<WfDataFilter> filters = new ArrayList<WfDataFilter>();
		filters.add(createEtatSuspensionTrueFilter());
		filters.add(createAbandonFilter());
		filters.add(createUniteActiviteFilter(agentId));
		WfDataFilter wfFiltre = mergeWfFilters(filters);
		return new WfFiltreDTO(wfFiltre);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createTexteFiltreDataFilter(java.lang.String, java.lang.String, java.lang.String)
	 */
	public FiltreDTO createTexteFiltreDataFilter(String infoId, String comparatorType, String texte) {
		WfSelFilter filter = (WfSelFilter) WfCorbeilleTranslator.getInstance().translate(infoId);
		WfBaseDataFilter wfFiltre = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), new String[] { texte }, translateComparator(comparatorType));
		return new WfFiltreDTO(wfFiltre);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createDateIntervalFiltreDataFilter(java.lang.String, java.util.Date, java.util.Date)
	 */
	public FiltreDTO createDateIntervalFiltreDataFilter(String infoId, Date beginDate, Date endDate) {

		WfSelFilter filter = (WfSelFilter) WfCorbeilleTranslator.getInstance().translate(infoId);

		WfDataFilter beginDateDataFilter = null;
		WfDataFilter endDateDataFilter = null;
		WfAdvancedDataFilter wfFiltre = null;

		String dateDebut = converte2String(DateUtils.getDatabaseDate(beginDate));
		String dateFin = converte2String(DateUtils.getDatabaseDate(endDate));

		if (beginDate != null) {
			if (endDate != null) {
				// --------------------------------
				// Intervalle begin < ___ < end
				// --------------------------------
				beginDateDataFilter = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), new String[] { dateDebut }, WorkflowConstantes.FILTER_COMPARATOR_GREATER);
				endDateDataFilter = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), new String[] { dateFin }, WorkflowConstantes.FILTER_COMPARATOR_LOWER);
				wfFiltre = new WfAdvancedDataFilter(WorkflowConstantes.AND, new WfDataFilter[] { beginDateDataFilter, endDateDataFilter });
			} else {
				// --------------------------------
				// Intervalle begin < ___
				// --------------------------------
				beginDateDataFilter = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), new String[] { dateDebut }, WorkflowConstantes.FILTER_COMPARATOR_GREATER);
				wfFiltre = new WfAdvancedDataFilter(WorkflowConstantes.AND, new WfDataFilter[] { beginDateDataFilter, beginDateDataFilter });

			}
		} else {
			if (endDate != null) {
				// --------------------------------
				// Intervalle ___ < end
				// --------------------------------
				endDateDataFilter = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), new String[] { dateFin }, WorkflowConstantes.FILTER_COMPARATOR_LOWER);
				wfFiltre = new WfAdvancedDataFilter(WorkflowConstantes.AND, new WfDataFilter[] { endDateDataFilter, endDateDataFilter });
			}
		}

		return new WfFiltreDTO(wfFiltre);
	}

	private String converte2String(Long longValue) {
		if (longValue != null) {
			return longValue.toString();
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createDateCompareFiltreDataFilter(java.lang.String, java.util.Date, boolean)
	 */
	public FiltreDTO createDateCompareFiltreDataFilter(String infoId, Date date, boolean greaterThan) {

		WfSelFilter filter = (WfSelFilter) WfCorbeilleTranslator.getInstance().translate(infoId);

		String comparator = greaterThan ? WorkflowConstantes.FILTER_COMPARATOR_GREATER : WorkflowConstantes.FILTER_COMPARATOR_LOWER;

		if (date == null) {
			date = new Date();
		}

		WfDataFilter dateDataFilter = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), new String[] { DateUtils.getDatabaseDate(date).toString() }, comparator);

		WfAdvancedDataFilter wfFiltre = new WfAdvancedDataFilter(WorkflowConstantes.AND, new WfDataFilter[] { dateDataFilter, dateDataFilter });

		return new WfFiltreDTO(wfFiltre);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createDateFiltreDataFilter(java.lang.String, java.lang.String, java.util.Date)
	 */
	public FiltreDTO createDateFiltreDataFilter(String infoId, String comparatorType, Date date) {
		String strDate = DateUtils.getDatabaseDate(date).toString();
		WfSelFilter filter = (WfSelFilter) WfCorbeilleTranslator.getInstance().translate(infoId);
		WfBaseDataFilter wfFiltre = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), new String[] { strDate }, translateComparator(comparatorType));
		return new WfFiltreDTO(wfFiltre);
	}

	/**
	 * Cr�e un filtre pour l'unit� d'activit� de l'utilisateur courant
	 * 
	 * @param agentId utilisateur courant
	 * @return un filtre pour l'unit� d'activit� de l'utilisateur courant
	 */
	private WfDataFilter createUniteActiviteFilter(String agentId) {
		WfDataFilter filtreZone = createFiltreZone(agentId);
		WfBaseDataFilter filtreCatClientLivre = createFiltreCatClientLivre(agentId);
		WfBaseDataFilter filtreCatClientContractant = createFiltreCatClientContractant(agentId);
		WfDataFilter wfFiltre = new WfAdvancedDataFilter(WorkflowConstantes.AND, new WfDataFilter[] { filtreZone, filtreCatClientLivre, filtreCatClientContractant });
		return wfFiltre;
	}

	/**
	 * Cr�e un filtre de non suspension
	 * 
	 * @return un filtre de non suspension
	 */
	private WfDataFilter createEtatSuspensionFalseFilter() {
		String[] values = { WorkflowConstantes.RUNNING, WorkflowConstantes.AVAILABLE };
		WfDataFilter wfFiltre = new WfBaseDataFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.STATUS, values);
		return wfFiltre;
	}

	/**
	 * EV-000047: Nouveau filtre permettant de s�lectionner une commande
	 * Cr�e un filtre pour une commande
	 * 
	 * @param cmdId L'identifiant de la commande
	 * Le filtre permettant de cibler cette commande
	 */
	public static WfDataFilter createCommandIdFilter(String cmdId) {
		WfDataFilter wfFiltre = new WfBaseDataFilter(WorkflowConstantes.STEP_TYPE, Constantes.RS_IDCOMMANDE, new String[] { cmdId });
		return wfFiltre;
	}

	/**
	 * Cr�e un filtre pour ne pas afficher les taches ad-hoc, mais seulement les
	 * AVP et les t�ches manuelles.
	 * 
	 * @return un filtre pour ne pas afficher les taches ad-hoc, mais seulement
	 * les AVP et les t�ches manuelles.
	 */
	private WfDataFilter createSansTacheAdHocFilter() {
		String[] roleArtemis = { STEP_AUTO_PRIVILEGE };
		WfBaseDataFilter wfFiltre = new WfBaseDataFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.ROLE, roleArtemis, WorkflowConstantes.FILTER_COMPARATOR_NOT_EQUAL);
		return wfFiltre;
	}

	/**
	 * Cr�e un filtre pour r�cup�rer les commandes critiques. Elles sont
	 * critiques si leur date contractuelle est inf�rieure � la date du jour + 2
	 * jours.
	 * 
	 * @return un filtre pour r�cup�rer les commandes critiques
	 */
	private WfDataFilter createCommandesCritiquesFilter() {
		Date now = new Date();
		Date dateCritique = DateUtils.createOffsetDay(now, 2);
		String[] limite = { DateUtils.getDatabaseDate(dateCritique).toString() };
		WfBaseDataFilter wfFiltre = new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATE_CONTRACTUELLE, limite, WorkflowConstantes.FILTER_COMPARATOR_LOWER);
		return wfFiltre;
	}

	/**
	 * Cr�e un filtre de suspension
	 * 
	 * @return un filtre de suspension
	 */
	private WfDataFilter createEtatSuspensionTrueFilter() {
		String[] values = { "true" };
		WfBaseDataFilter wfFiltre = new WfBaseDataFilter(WorkflowConstantes.CASE_TYPE, WorkflowConstantes.SUSPENDED, values);
		return wfFiltre;
	}

	/**
	 * Cr�e un filtre d'abandon
	 * 
	 * @return un filtre d'abandon
	 */
	private WfDataFilter createAbandonFilter() {
		String[] valeurOUI = { Constantes.VALEUR_VARIANTE_OUI };
		WfBaseDataFilter partialAbandonFilter = new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_VAR_ABANDON, valeurOUI, WorkflowConstantes.FILTER_COMPARATOR_NOT_EQUAL);
		String[] valeurNull = { "" };
		WfBaseDataFilter nullFilter = new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_VAR_ABANDON, valeurNull, WorkflowConstantes.FILTER_COMPARATOR_EQUAL);
		WfAdvancedDataFilter wfFiltre = new WfAdvancedDataFilter(WorkflowConstantes.OR, new WfDataFilter[] { partialAbandonFilter, nullFilter });
		return wfFiltre;
	}

	/**
	 * Combine les filtres pr�sents dans la liste donn�es en un filtre, avec
	 * l'op�rateur AND.
	 * 
	 * @param filters
	 * les filtres � combiner
	 * @return un filtre combin�, ou null si la liste ne contient aucun filtre,
	 * ou le premier filtre de la liste si elle n'en contient qu'un
	 */
	private WfDataFilter mergeWfFilters(List<WfDataFilter> filters) {
		if (filters.isEmpty()) {
			return null;
		} else if (filters.size() == 1) {
			return CollectionUtils.getFirstOrNull(filters);
		} else {
			WfDataFilter[] filtersArray = filters.toArray(new WfDataFilter[filters.size()]);
			return new WfAdvancedDataFilter(WorkflowConstantes.AND, filtersArray);
		}
	}

	/**
	 * Cr�e le filtre pour la zone SI associ�e � l'unit� d'activit� d'un agent
	 * 
	 * @param agentId l'agent
	 * @return le filtre cr��
	 */
	private WfDataFilter createFiltreZone(String agentId) {
		// R�cup�re l'unit� d'activit� associ�e � l'agent courant
		AgentDTO agent = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AgentDTO.class, agentId);
		List<ZoneSiUniteDTO> zonesSiUnite = ServiceManager.getInstance().getReferenceSpaceManager()
				.listInReferenceSpace(ZoneSiUniteDTO.class, new Comparaison(ZoneSIUnite.SLINK_GERE_UNITE_UNITE_ACTIVITE, Constantes.OPERATOR_EQUAL, agent.getUniteActivite().getId()));
		List<ZoneGeoUniteDTO> zonesGeoUnite = ServiceManager.getInstance().getReferenceSpaceManager()
				.listInReferenceSpace(ZoneGeoUniteDTO.class, new Comparaison(ZoneGeoUnite.SLINK_GERE_PAR_UNITE_ACTIVITE, Constantes.OPERATOR_EQUAL, agent.getUniteActivite().getId()));
		if ((zonesGeoUnite.size() == 0) && (zonesSiUnite.size() == 0)) {
			// On retourne FAUX
			return new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ZONE, new String[] { VALEUR_INEXISTANTE });
		}
		// Corbeilles de traitement : construction d'un filtre commun pour les deux
		// types de zone reposant sur la constante RS_ZONE
		String[] possibleValuesZone = new String[zonesGeoUnite.size() + zonesSiUnite.size() + 1];
		int i = 0;
		for (ZoneGeoUniteDTO zoneGeoUnite : zonesGeoUnite) {
			possibleValuesZone[i] = zoneGeoUnite.getZoneGeographique().getId();
			i++;
		}
		for (ZoneSiUniteDTO zoneSIUnite : zonesSiUnite) {
			possibleValuesZone[i] = zoneSIUnite.getZoneSi().getId();
			i++;
		}
		possibleValuesZone[possibleValuesZone.length - 1] = null;
		WfDataFilter filtreZone = new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ZONE, possibleValuesZone);
		// Corbeilles de supervision : construction de deux filtres diff�rents associ�s par un AND
		// Construction du filtre sur ZoneGeo reposant sur la constante RS_ZONE_GEO
		String[] possibleValuesZoneGEO = new String[zonesGeoUnite.size() + 1];
		int j = 0;
		for (ZoneGeoUniteDTO zoneGeoUnite : zonesGeoUnite) {
			possibleValuesZoneGEO[j] = zoneGeoUnite.getZoneGeographique().getId();
			j++;
		}
		possibleValuesZoneGEO[possibleValuesZoneGEO.length - 1] = null;
		WfBaseDataFilter filtreZoneGEO = new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ZONE_GEO, possibleValuesZoneGEO);
		// Construction du filtre sur ZoneSI reposant sur la constante RS_ZONE_SI
		String[] possibleValuesZoneSI = new String[zonesSiUnite.size() + 1];
		int k = 0;
		for (ZoneSiUniteDTO zoneSIUnite : zonesSiUnite) {
			possibleValuesZoneSI[k] = zoneSIUnite.getZoneSi().getId();
			k++;
		}
		possibleValuesZoneSI[possibleValuesZoneSI.length - 1] = null;
		WfBaseDataFilter filtreZoneSI = new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ZONE_SI, possibleValuesZoneSI);
		// association de sdeux filtres
		WfAdvancedDataFilter filtreZoneGeoEtZoneSI = new WfAdvancedDataFilter(WorkflowConstantes.AND, new WfDataFilter[] { filtreZoneGEO, filtreZoneSI });
		// cr�ation et renvoi du filtre
		return new WfAdvancedDataFilter(WorkflowConstantes.OR, new WfDataFilter[] { filtreZoneGeoEtZoneSI, filtreZone });
	}

	/**
	 * Cr�e le filtre pour les cat�gories des clients livr�s associ�s � l'unit�
	 * d'activit� d'un agent
	 * 
	 * @param agentId l'agent
	 * @return le filtre cr��
	 */
	private WfBaseDataFilter createFiltreCatClientLivre(String agentId) {
		return createFiltreCatClient(agentId, RoleClientConstantes.LIV, Constantes.RS_CATEGORIE_LIVRE);
	}

	/**
	 * Cr�e le filtre pour les cat�gories des clients livr�s associ�s � l'unit�
	 * d'activit� d'un agent
	 * 
	 * @param agentId
	 * @param roleClientId
	 * @param attributeName
	 * @return le filtre pour les cat�gories des clients livr�s associ�s �
	 * l'unit� d'activit� d'un agent
	 */
	private WfBaseDataFilter createFiltreCatClient(String agentId, String roleClientId, String attributeName) {
		// R�cup�re l'unit� d'activit� associ�e � l'agent courant
		AgentDTO agent = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AgentDTO.class, agentId);
		List<CatClientUniteDTO> catClientUnites = ServiceManager.getInstance().getReferenceSpaceManager()
				.listInReferenceSpace(CatClientUniteDTO.class, new Comparaison(CatClientUnite.SLINK_GERE_PAR_UNITE_ACTIVITE, Constantes.OPERATOR_EQUAL, agent.getUniteActivite().getId()));
		List<CatClientUniteDTO> catClientLivreUnites = new ArrayList<CatClientUniteDTO>();
		for (CatClientUniteDTO catClientUnite : catClientUnites) {
			if (roleClientId.equals(catClientUnite.getRoleClient().getId())) {
				catClientLivreUnites.add(catClientUnite);
			}
		}
		// Cr�ation du filtre sur le champ CategorieClient
		if (catClientLivreUnites.size() == 0) {
			// On retourne FAUX
			return new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, attributeName, new String[] { VALEUR_INEXISTANTE });
		}
		String[] possibleValues = new String[catClientLivreUnites.size() + 1];
		int i = 0;
		for (CatClientUniteDTO catClientLivreUnite : catClientLivreUnites) {
			possibleValues[i] = catClientLivreUnite.getCategorieClient().getId();
			i++;
		}
		possibleValues[possibleValues.length - 1] = null;
		return new WfBaseDataFilter(WorkflowConstantes.ROOTSET_TYPE, attributeName, possibleValues);
	}

	/**
	 * Cr�e le filtre pour les cat�gories des clients contractants associ�s �
	 * l'unit� d'activit� d'un agent
	 * 
	 * @param agentId l'agent
	 * @return le filtre cr��
	 */
	private WfBaseDataFilter createFiltreCatClientContractant(String agentId) {
		return createFiltreCatClient(agentId, RoleClientConstantes.CO, Constantes.RS_CATEGORIE_CONTRACTANT);
	}

	/**
	 * Traduit un op�rateur g�n�rique en op�rateur workflow
	 * 
	 * @param genericComparator
	 * @return l'�quivalent workflow de l'op�rateur g�n�rique
	 */
	private String translateComparator(String genericComparator) {
		String comparator = null;
		if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_EQUAL)) {
			comparator = WorkflowConstantes.FILTER_COMPARATOR_EQUAL;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_LOWER)) {
			comparator = WorkflowConstantes.FILTER_COMPARATOR_LOWER;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_GREATER)) {
			comparator = WorkflowConstantes.FILTER_COMPARATOR_GREATER;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_LIKE) || genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_LIKE_UPPER)) {
			comparator = WorkflowConstantes.FILTER_COMPARATOR_LIKE;
		} else {
			throw new IllegalArgumentException(genericComparator + " n'est pas un comparateur de filtre valide");
		}
		return comparator;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createMultiCriteresDataFilter(java.lang.String, java.lang.String[])
	 */
	public FiltreDTO createMultiCriteresDataFilter(String infoId, String[] valueArray) {
		WfSelFilter filter = (WfSelFilter) WfCorbeilleTranslator.getInstance().translate(infoId);
		WfBaseDataFilter wfFiltre = new WfBaseDataFilter(filter.getAttributeType(), filter.getAttributeName(), valueArray);
		return new WfFiltreDTO(wfFiltre);
	}
}
