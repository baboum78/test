package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;

import javax.ws.rs.core.Response;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;
import org.codehaus.jackson.map.ObjectMapper;

import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.livraison.service.ejb.sb.PublicationManager;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.vador.ArtemisData;
import com.soliste.bolbec.livraison.service.model.PublicationATraiterDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * AddressRessourceTraitementV2
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/05/2018</TD><TD>AJO</TD><TD>Cr�ation de la ressource Publication</TD></TR>
 * </TABLE>
 */
public class PublicationRessourceTraitementV2 {
	/**
	 * Manager Utils
	 */
	private static final String ETAT_NON_RECUPERE = "NON_RECUPERE";
	private static final String ETAT_RECUPERE = "RECUPERE";
	private final IServiceManager serviceManager = ServiceManager.getInstance();
	private final PublicationManager publicationManager = serviceManager.getPublicationManager();
	private final ILoggerManager LOGGER_MANAGER = ServiceManager.getInstance().getLoggerManager();
	private final String CLASS_NAME = getClass().getSimpleName();

	public Response getPublications(String idPartenaire, @SuppressWarnings("unused") MessageContext context) {
		LOGGER_MANAGER.fine(CLASS_NAME, "getPublications", "R�cup�ration des publications");
		if (StringUtils.isBlank(idPartenaire)) {
			throw APIExceptionEnum.partenairenotfound.createAPIException(idPartenaire);
		}
		// R�cup�ration des publications VADOR non r�cup�r�s
		ArrayList<PublicationATraiterDTO> publicationsATraiterDTO = publicationManager.findPublicationByApplicationEtEtat(idPartenaire, ETAT_NON_RECUPERE);
		ArrayList<String> publications = new ArrayList<String>();
		for (int i = 0; i < publicationsATraiterDTO.size(); i++) {
			if (ETAT_NON_RECUPERE.equals(publicationsATraiterDTO.get(i).getEtat())) {
				// Construction de la liste d'objet � envoyer
				publications.add(publicationsATraiterDTO.get(i).getPublication());
				// MAJ des donn�es pour update en base
				publicationsATraiterDTO.get(i).setEtat(ETAT_RECUPERE);
				Date today = new Date();
				Timestamp todayTS = new Timestamp(today.getTime());
				Long dateRecuperation = todayTS.getTime() / 1000;
				publicationsATraiterDTO.get(i).setDateRecuperation(dateRecuperation);
			}
		}

		// Mise � jour table PublicationATraiter apr�s r�cup�ration VADOR
		publicationManager.updatePublicationEtat(publicationsATraiterDTO);
		publicationManager.updatePublicationDateRecuperation(publicationsATraiterDTO);

		return Response.ok(publications).build();
	}
}
