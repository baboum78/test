/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.fop;

import java.io.IOException;
import java.io.Serializable;
import java.util.Vector;

import org.apache.soap.Envelope;
import org.apache.soap.Header;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcescommerciales.data.FOPDeclarations;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 *
 * @author unknown
 */
public class InjecteurCRFopMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException {
		// EV-000020 : pas de tache d'activation si on est dans le cas d'ue publication anticipee
		// l'id de la requete contient alors un id de commande et non de processus
		// la diff�renctiation se fait sur la syntaxe :
		// id de processus commance par ln ou ls soit 2 alphabetiques
		// id de commande commance par 4 numeriques
		String idRequete = getIdRequete(a_message);
		ActivationParam l_activationParam = null;
		String idArtemis = null;
		// recuperation del'identifiat bolbece mis dans la requete (commande ou processus)
		// c'est le dernier champs de la requete avec le separateur "_"
		// Le lastIndexOf "_" permet de r�cup�rer l'idProcessus ou l'idCommande quelque soit l'idRequete (ex: LY_G6_ln1020162 ou ln1020162)
		idArtemis = idRequete.substring(idRequete.lastIndexOf("_") + 1);
		// si l'identifiant recupere ne commence pas par 4 chiffre, c'est un processus
		// sinon, c'est une commande, on est dans le cas d'une publication anticip�e
		// et il n'y a pas de tache � activer
		if (idArtemis.matches("^[0-9]{4}.*")) {
			l_activationParam = new ActivationParam("", getIdRequete(a_message));
		} else {
			l_activationParam = new ActivationParam("MESCOM", idRequete);
		}
		return l_activationParam;
	}

	/**
	 * getIdRequete
	 * 
	 * @param a_message message � traiter
	 * @return String
	 * @throws InvalidMessageException
	 */
	private String getIdRequete(Serializable a_message) throws InvalidMessageException {
		Envelope l_envelope = getMessageEnvelope(a_message);
		String l_idRequete = getMessageId(l_envelope);
		return l_idRequete;
	}

	/**
	 * Retourne l'enveloppe SOAP du message.
	 * 
	 * @param a_message
	 * Serializable : message.
	 * @return Envelope : enveloppe SOAP du message pass� en param�tre.
	 */
	private Envelope getMessageEnvelope(Serializable message) {
		Envelope envelope;
		try {
			envelope = XmlUtils.getMessageEnvelope((String) message);
		} catch (SAXException saxe) {
			throw new InvalidMessageException("SAXException pour recuperer l'enveloppe SOAP", message, saxe);
		} catch (IOException ioe) {
			throw new InvalidMessageException("IOException pour recuperer l'enveloppe SOAP", message, ioe);
		}
		return envelope;
	}

	/**
	 * getMessageId : retourne l'identifiant du message.
	 * 
	 * @param a_envelope
	 * Envelope : enveloppe SOAP du message.
	 * @return String : identifiant du message.
	 */
	private String getMessageId(Envelope a_envelope) {
		String l_messageId = null;
		Element l_Element;
		// R�cup�ration de l'identifiant du message
		Header l_Header = a_envelope.getHeader();
		@SuppressWarnings("unchecked")
		Vector<Element> l_HeaderEntries = l_Header.getHeaderEntries();
		for (int l_i = 0; l_i < l_HeaderEntries.size(); l_i++) {
			l_Element = l_HeaderEntries.elementAt(l_i);
			if (l_Element.getTagName().equals(FOPDeclarations.TAG_ID)) {
				Node l_node = l_Element.getFirstChild();
				l_messageId = l_node.getNodeValue();
				// FIXME OLD: GTA On doit pouvoir sortir de la boucle si le TAG_ID est trouv� (unicit� de ce TAG)
			}
		}
		ServiceManager.getInstance().getLoggerManager().finest(getClass().getName(), "getMessageId", "Message Id trouv� : " + l_messageId);
		return l_messageId;
	}
}