package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

public class InterventionModification {

	String interventionId;
	String refErdv;
	String observation;

	/**
	 * 
	 * @param interventionId
	 * @param observation
	 */
	public InterventionModification(String interventionId, String observation) {
		this.interventionId = interventionId;
		this.observation = observation;
	}

	/**
	 * 
	 * @param interventionId
	 * @param refErdv
	 * @param observation
	 */
	public InterventionModification(String interventionId, String refErdv, String observation) {
		this.interventionId = interventionId;
		this.refErdv = refErdv;
		this.observation = observation;
	}

	public String getInterventionId() {
		return interventionId;
	}

	public void setInterventionId(String interventionId) {
		this.interventionId = interventionId;
	}

	public String getObservation() {
		return observation;
	}

	public void setObservation(String observation) {
		this.observation = observation;
	}

	public String getRefErdv() {
		return refErdv;
	}

	public void setRefErdv(String refErdv) {
		this.refErdv = refErdv;
	}

}
