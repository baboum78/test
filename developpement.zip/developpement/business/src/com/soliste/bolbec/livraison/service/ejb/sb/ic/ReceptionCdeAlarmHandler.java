/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.ic;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.ejb.sb.jms.AlarmHandler;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.PropertiesUtils;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 *
 * @author rgvs7490
 */
public class ReceptionCdeAlarmHandler implements AlarmHandler {

	private static final String CLASS_NAME = ReceptionCdeAlarmHandler.class.getName();

	private static ReceptionCdeAlarmHandler instance = new ReceptionCdeAlarmHandler();

	/**
	 * Indique si une alarme a �t� cr��e
	 */
	private boolean alarmCreated = false;

	/**
	 * R�pertoire o� les fichiers alarmes sont g�n�r�s
	 */
	private String alarmDirectory = ".";

	/**
	 * Nom de la JVM
	 */
	private String jvmName;

	/**
	 * Nom du fichier d'alarme
	 */
	private String alarmFileName;

	/**
	 * Pr�fixe du nom du fichier d'alarme termin�e. La date courante est ajout�e � ce
	 * pr�fixe.
	 */
	private String removedAlarmFileNamePrefix;

	private final String FORMAT_DATE = "yyyy-MM-dd-HH-mm-ss";

	/**
	 * Constructeur (priv� car pattern singleton)
	 */
	private ReceptionCdeAlarmHandler() {
		this.alarmDirectory = PropertiesUtils.getConfig(Constantes.BOLBEC_PROP_FILE).getString("bolbec.ICGenerique.alarmDirectory", ".").trim();
		this.jvmName = System.getProperty("weblogic.Name");
		this.alarmFileName = jvmName + ".ICGenerique.alarme";
		this.removedAlarmFileNamePrefix = jvmName + ".ICGenerique.alarme_terminee_";
		File file = new File(alarmDirectory, alarmFileName);
		this.alarmCreated = file.exists();
	}

	public static ReceptionCdeAlarmHandler getInstance() {
		return instance;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.AlarmHandler#createAlarm()
	 */
	public synchronized void createAlarm() {
		if (!alarmCreated) {
			try (PrintWriter out = new PrintWriter(new BufferedWriter(new FileWriter(new File(alarmDirectory, alarmFileName))))){
				out.print("Nom de la JVM: ");
				out.println(jvmName);
				out.print("Date de l'alarme: ");
				out.println(DateUtils.format(new Date(), FORMAT_DATE));
				out.print("Description de l'alarme: ");
				out.println("Le nombre maximal de rejets cons�cutifs a �t� atteint");
				out.flush();
			} catch (IOException e) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "createAlarm", "Exception � la cr�ation de l'alarme", e);
			} finally {
				alarmCreated = true;
			}
		}
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.AlarmHandler#removeAlarm()
	 */
	public synchronized void removeAlarm() {
		if (alarmCreated) {
			try {
				File alarmFile = new File(alarmDirectory, alarmFileName);
				String removedAlarmFileName = removedAlarmFileNamePrefix + DateUtils.format(new Date(), FORMAT_DATE);
				File removedAlarmFile = new File(alarmDirectory, removedAlarmFileName);
				boolean removed = alarmFile.renameTo(removedAlarmFile);
				if (!removed) {
					ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "removeAlarm", "Impossible de lever l'alarme");
				}
			} finally {
				alarmCreated = false;
			}
		}
	}
}
