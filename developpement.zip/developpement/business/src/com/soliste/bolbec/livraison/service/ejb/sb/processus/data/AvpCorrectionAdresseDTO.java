/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import com.soliste.bolbec.livraison.service.model.AdresseDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * @author dxll7528
 */
public class AvpCorrectionAdresseDTO extends AvpInfoDTO {

	private boolean adresse42CRenseignee;
	private AdresseDTO adresseAttendue;
	private String messageErreurInterface;
	private AdresseDTO adresse;

	/**
	 * 
	 */
	AvpCorrectionAdresseDTO() {
		//
	}

	public String getType() {
		return AVP_CORRECTION_ADRESSE;
	}

	public AdresseDTO getAdresse() {
		return this.adresse;
	}

	void setAdresse(AdresseDTO adresse) {
		this.adresse = adresse;
	}

	public AdresseDTO getAdresseAttendue() {
		return this.adresseAttendue;
	}

	public void setAdresseAttendue(AdresseDTO adresseAttendue) {
		this.adresseAttendue = adresseAttendue;
	}

	public String getMessageErreurInterface() {
		return messageErreurInterface;
	}

	public void setMessageErreurInterface(String messageErreurInterface) {
		this.messageErreurInterface = messageErreurInterface;
	}

	/**
	 * Retourne le <code>adresse42CRenseignee</code>
	 * 
	 * @return le <code>adresse42CRenseignee</code>
	 */
	public boolean isAdresse42CRenseignee() {
		return adresse42CRenseignee;
	}

	/**
	 * Affecte le <code>adresse42CRenseignee</code>
	 * 
	 * @param adresse42CRenseignee le <code>adresse42CRenseignee</code> � affecter
	 */
	public void setAdresse42CRenseignee(boolean adresse42CRenseignee) {
		this.adresse42CRenseignee = adresse42CRenseignee;
	}

}
