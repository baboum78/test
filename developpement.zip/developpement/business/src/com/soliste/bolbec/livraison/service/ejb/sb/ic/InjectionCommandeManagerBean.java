/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.ic;

import java.math.BigInteger;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.commun.service.util.GeneratorManager;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.ConstantesParametreArtemis;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.InstanceSeDTO;
import com.soliste.bolbec.livraison.service.model.LocalisationSeDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.VersionManager;

import aps.AdresseHome;
import aps.AnomalieConstantes;
import aps.BlocNoteHome;
import aps.ClientHome;
import aps.CommandeHome;
import aps.DynamicCommande;
import aps.DynamicCommandeHome;
import aps.DynamicEPCommercialHome;
import aps.DynamicIntervention;
import aps.DynamicInterventionHome;
import aps.DynamicLigneCommande;
import aps.DynamicLigneCommandeHome;
import aps.DynamicPsSouhaite;
import aps.DynamicPsSouhaiteHome;
import aps.EPCommercialHome;
import aps.EtatCommandeConstantes;
import aps.EtatLigneCdeConstantes;
import aps.EtatProcessusConstantes;
import aps.InstanceOGHome;
import aps.InterlocuteurHome;
import aps.InterventionHome;
import aps.LienOpProgLdC;
import aps.LienOpProgLdCHome;
import aps.LigneCmdCatalogueHome;
import aps.LigneCmdModParcHome;
import aps.LigneCmdSupParcHome;
import aps.LigneCommandeHome;
import aps.LocalisationSE;
import aps.OpProgrammeeHome;
import aps.ParametreArtemis;
import aps.Processus;
import aps.ProcessusHome;
import aps.ProcessusLCHome;
import aps.ProcessusTypeConstantes;
import aps.PsSouhaite;
import aps.PsSouhaiteHome;
import aps.StatutCommandeConstantes;
import aps.SystemeExterneConstantes;
import aps.TypeOpPonctuellesConstantes;
import bolbec.injection.xml.generated.Adresse;
import bolbec.injection.xml.generated.BlocNote;
import bolbec.injection.xml.generated.ClientLivre;
import bolbec.injection.xml.generated.ClientType;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.Contact;
import bolbec.injection.xml.generated.DetentionProduitService;
import bolbec.injection.xml.generated.ElementParcAffecte;
import bolbec.injection.xml.generated.InstanceOffreGroupee;
import bolbec.injection.xml.generated.Intervention;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.Message;
import bolbec.injection.xml.generated.OperationProgrammee;
import bolbec.injection.xml.generated.ParametreType;
import bolbec.injection.xml.generated.ProduitServiceSouhaite;

/**
 * Impl�mentation de l'EJB session <code>InjectionCommandeManager</code>.
 * 
 * @see {@link com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager}
 * 
 * <BR/><TABLE>
 * <TR><TH>DATE</TH><TH>USER</TH><TH>DETAIL</TH></TR>
 * <TR><TD>20/04/2010</TD><TD>ALE</TD><TD>EV-000060 - Construction automatique des dynamicCommande</TD></TR>
 * <TR><TD>26/04/2010</TD><TD>ALE</TD><TD>EV-000060 - Correction du defect_50</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Ajout accolades autour d'instruction seule</TD></TR>
 * <TR><TD>13/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1236 Correction d'anomalies trouv�es par FindBugs</TD></TR>TD></TR>
 * <TR><TD>08/10/2013</TD><TD>GPA</TD><TD>G9R0C1 : Test des couches techniques</TD></TR>
 * </TABLE>
 */
public class InjectionCommandeManagerBean extends FwkSessionBean implements InjectionCommandeManager {

	/**
	 * Serialization UID
	 */
	private static final long serialVersionUID = 7590649312472245076L;

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = InjectionCommandeManagerBean.class.getName();

	/** The processus home. */
	protected ProcessusHome processusHome;

	public void setProcessusHome(ProcessusHome processusHome) {
		this.processusHome = processusHome;
	}

	/** The commande home. */
	protected CommandeHome commandeHome;

	public void setCommandeHome(CommandeHome commandeHome) {
		this.commandeHome = commandeHome;
	}

	/** The dynamicCommande home. */
	protected DynamicCommandeHome dynamicCommandeHome;

	public void setDynamicCommandeHome(DynamicCommandeHome dynamicCommandeHome) {
		this.dynamicCommandeHome = dynamicCommandeHome;
	}

	/** The client home. */
	protected ClientHome clientHome;

	public void setClientHome(ClientHome clientHome) {
		this.clientHome = clientHome;
	}

	/** The adresse home. */
	protected AdresseHome adresseHome;

	/** The interlocuteur home. */
	protected InterlocuteurHome interlocuteurHome;

	/** The bloc note home. */
	protected BlocNoteHome blocNoteHome;

	/** The ps souhaite home. */
	protected PsSouhaiteHome psSouhaiteHome;

	/** The dynamic ps souhaite home. */
	protected DynamicPsSouhaiteHome dynamicPsSouhaiteHome;

	/** The op programmee home. */
	protected OpProgrammeeHome opProgrammeeHome;

	/** The lien op prog ld c home. */
	protected LienOpProgLdCHome lienOpProgLdCHome;

	/** The processus lc home. */
	protected ProcessusLCHome processusLCHome;

	public void setProcessusLCHome(ProcessusLCHome processusLCHome) {
		this.processusLCHome = processusLCHome;
	}

	/** The intervention home. */
	protected InterventionHome interventionHome;

	/** The dynamic intervention home. */
	protected DynamicInterventionHome dynamicInterventionHome;

	/** The ligne cmd catalogue home. */
	protected LigneCmdCatalogueHome ligneCmdCatalogueHome;

	public void setLigneCmdCatalogueHome(LigneCmdCatalogueHome ligneCmdCatalogueHome) {
		this.ligneCmdCatalogueHome = ligneCmdCatalogueHome;
	}

	/** The ligne cmd sup parc home. */
	protected LigneCmdSupParcHome ligneCmdSupParcHome;

	public void setLigneCmdSupParcHome(LigneCmdSupParcHome ligneCmdSupParcHome) {
		this.ligneCmdSupParcHome = ligneCmdSupParcHome;
	}

	/** The ligne cmd mod parc home. */
	protected LigneCmdModParcHome ligneCmdModParcHome;

	public void setLigneCmdModParcHome(LigneCmdModParcHome ligneCmdModParcHome) {
		this.ligneCmdModParcHome = ligneCmdModParcHome;
	}

	/** The ligne commande home. */
	protected LigneCommandeHome ligneCommandeHome;

	public void setLigneCommandeHome(LigneCommandeHome ligneCommandeHome) {
		this.ligneCommandeHome = ligneCommandeHome;
	}

	/** The dynamic ligne commande home. */
	protected DynamicLigneCommandeHome dynamicLigneCommandeHome;

	public void setDynamicLigneCommandeHome(DynamicLigneCommandeHome dynamicLigneCommandeHome) {
		this.dynamicLigneCommandeHome = dynamicLigneCommandeHome;
	}

	/** The ep commercial home. */
	protected EPCommercialHome epCommercialHome;

	public void setEpCommercialHome(EPCommercialHome epCommercialHome) {
		this.epCommercialHome = epCommercialHome;
	}

	/** The dynamic ep commercial home. */
	protected DynamicEPCommercialHome dynamicEPCommercialHome;

	/** The instance og home. */
	protected InstanceOGHome instanceOGHome;

	/** Classe contenant tous les services m�tier d'Artemis */
	protected IServiceManager serviceManager = ServiceManager.getInstance();

	/** The Constant CONV_TABLE. */
	private static final char[] CONV_TABLE = { 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };

	/** The Constant INDEX_DE_COMMANDE. */
	private static final String INDEX_DE_COMMANDE = "COMMANDE";

	/** The Constant TYPEACCES_LIV_IDCLI. */
	private static final String TYPEACCES_LIV_IDCLI = "IDCLI";

	/** The Constant COUNTER_EPC_FUTUR. */
	private static final String COUNTER_EPC_FUTUR = "IC_EPC_FUTUR";

	/** The Constant BLANK_STRING. */
	private static final String BLANK_STRING = "";

	/** The Constant A_VALUE. */
	private static final String A_VALUE = "A";

	/** The Constant ONE_BILLION_VALUE. */
	private static final String ONE_BILLION_VALUE = "1000000000";

	/** The Constant TEN_VALUE. */
	private static final String TEN_VALUE = "10";

	/** The Constant DOUBLE_ZERO_VALUE. */
	private static final String DOUBLE_ZERO_VALUE = "00";

	/** The Constant QUESTION_MARK_VALUE. */
	private static final String QUESTION_MARK_VALUE = "?";

	/** The Constant INTERVENTION_VALUE. */
	private static final String INTERVENTION_VALUE = "Intervention";

	/** The Constant LIGNE_COMMANDE_VALUE. */
	private static final String LIGNE_COMMANDE_VALUE = "LigneCommande";

	/** The Constant FORMAT_DATE_HEURE. */
	private static final String FORMAT_DATE_HEURE = "dd/MM/yyyy HH:mm:ss";
	// FSC : Report G7R5
	private static final String FORMAT_DATE_HEURE_ERRONE = "dd/MM/yyyyHH:mm:ss";

	// FIN REPORT G7R5

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			processusHome = getEntityHome(ProcessusHome.class);
			commandeHome = getEntityHome(CommandeHome.class);
			clientHome = getEntityHome(ClientHome.class);
			adresseHome = getEntityHome(AdresseHome.class);
			interlocuteurHome = getEntityHome(InterlocuteurHome.class);
			blocNoteHome = getEntityHome(BlocNoteHome.class);
			psSouhaiteHome = getEntityHome(PsSouhaiteHome.class);
			opProgrammeeHome = getEntityHome(OpProgrammeeHome.class);
			lienOpProgLdCHome = getEntityHome(LienOpProgLdCHome.class);
			processusLCHome = getEntityHome(ProcessusLCHome.class);
			interventionHome = getEntityHome(InterventionHome.class);
			dynamicInterventionHome = getEntityHome(DynamicInterventionHome.class);
			ligneCmdCatalogueHome = getEntityHome(LigneCmdCatalogueHome.class);
			ligneCmdSupParcHome = getEntityHome(LigneCmdSupParcHome.class);
			ligneCmdModParcHome = getEntityHome(LigneCmdModParcHome.class);
			ligneCommandeHome = getEntityHome(LigneCommandeHome.class);
			dynamicLigneCommandeHome = getEntityHome(DynamicLigneCommandeHome.class);
			epCommercialHome = getEntityHome(EPCommercialHome.class);
			dynamicEPCommercialHome = getEntityHome(DynamicEPCommercialHome.class);
			instanceOGHome = getEntityHome(InstanceOGHome.class);
			dynamicPsSouhaiteHome = getEntityHome(DynamicPsSouhaiteHome.class);
			dynamicCommandeHome = getEntityHome(DynamicCommandeHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager#getCommandeById(String)
	 */
	public CommandeDTO getCommandeById(String idCommande) {
		try {
			aps.Commande commande = commandeHome.findByPrimaryKey(new EntityBeanPK(idCommande));

			return new CommandeDTO(commande);
		} catch (FinderException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "getCommandeById", "Commande non trouv�e " + idCommande, ce);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager#createCommande(bolbec.injection.xml.generated.Message, java.lang.String)
	 */
	public CommandeDTO createCommande(Message messageXml, String instanceLocalisation) {
		Commande commandeXml = messageXml.getCommande();
		serviceManager.getICValidationManager().validateMessage(messageXml, instanceLocalisation);
		serviceManager.getICValidationManager().validateCommande(commandeXml);
		aps.Processus processus = createProcessus(messageXml.getCommande().getProcessusSpecifique());
		aps.Commande commande = createCommande(messageXml);
		serviceManager.getProcessusManager().updateProcessusIdCommande(processus.getId(), commande.getId());
		setCdeLinks(commande, commandeXml, processus, messageXml.getIdEmetteur(), instanceLocalisation, messageXml.getVersion());
		return new CommandeDTO(commande);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager#createCommande(java.lang.String)
	 */
	public CommandeDTO createCommande(String refExterne) {
		String commandeId = getIdCommande();
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.Commande.FIELD_REF_EXTERNE, refExterne);
		values.put(aps.Commande.FIELD_EST_DANS_ETAT_COMMANDE, EtatCommandeConstantes.FO_INIT);
		values.put(aps.Commande.FIELD_DATE_CREATION_BOLBEC, DateUtils.getDatabaseDate());

		try {
			aps.Commande commande = commandeHome.create(commandeId, values);

			ClientType clientType = new ClientType();
			aps.Client client = createClient(clientType);
			commande.setLinkCommandeParClient(client);

			return new CommandeDTO(commande);
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createCommande", "Erreur cr�ation de la commande " + commandeId, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager#updateCommande(String, Message, String)
	 */
	public CommandeDTO updateCommande(String idCommande, Message messageXml, String instanceLocalisation) {
		Commande commandeXml = messageXml.getCommande();
		serviceManager.getICValidationManager().validateMessage(messageXml, instanceLocalisation);
		serviceManager.getICValidationManager().validateCommande(commandeXml);
		aps.Processus processus = createProcessus(messageXml.getCommande().getProcessusSpecifique());

		aps.Commande commande = null;
		try {
			commande = commandeHome.findByPrimaryKey(new EntityBeanPK(idCommande));
		} catch (FinderException e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "updateCommande", "Erreur recherche de la commande " + idCommande, e);
			throw new EJBException(e);
		}

		commande.setProvientSystemeExterne(messageXml.getIdEmetteur());
		Commande cde = messageXml.getCommande();
		String etat = cde.getEtatCommande();
		// si c'est un processus sp�cifique (migration), on passe la commanddirectement en �tat LIVR
		if (cde.getProcessusSpecifique() != null) {
			etat = EtatCommandeConstantes.LIVR;
		} else if (etat == null) {
			etat = EtatCommandeConstantes.FO_VALID;
		}
		commande.setEstDansEtatCommande(etat);
		if (org.apache.commons.lang.StringUtils.isBlank(messageXml.getStatutCommande())) {
			commande.setEstDansStatutCommande(StatutCommandeConstantes.NON_MIXTE);
		} else {
			commande.setEstDansStatutCommande(messageXml.getStatutCommande());
		}
		commande.setSeRefereCasMetier(cde.getCasMetier());
		commande.setDateDebutPriseCommandeFO(stringToDate(cde.getDateDebutPriseCommandeFO()));
		commande.setDateValidationFO(stringToDate(cde.getDateValidationCommandeFO()));
		commande.setIdVendeur(cde.getIdVendeur());
		commande.setVersionArtemis(Constantes.VERSION);
		commande.setVersionApplicative(VersionManager.getInstance().getCurrentApplicationVersion());

		serviceManager.getProcessusManager().updateProcessusIdCommande(processus.getId(), commande.getId());
		setCdeLinks(commande, commandeXml, processus, messageXml.getIdEmetteur(), instanceLocalisation, messageXml.getVersion());
		return new CommandeDTO(commande);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager#updateCommandeEtat(CommandeDTO)
	 */
	public void updateCommandeEtat(CommandeDTO commandeDTO) {
		aps.Commande commande;
		try {
			commande = commandeHome.findByPrimaryKey(new EntityBeanPK(commandeDTO.getId()));
		} catch (FinderException e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "updateCommandeEtat", "Erreur recherche de la commande pour modifier l'�tat " + commandeDTO.getId(), e);
			throw new EJBException(e);
		}
		commande.setEstDansEtatCommande(commandeDTO.getEtatCommande().getId());
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager#updateCommandeEtatWithNewTransaction(CommandeDTO)
	 */
	public void updateCommandeEtatWithNewTransaction(CommandeDTO commandeDTO) {
		aps.Commande commande;
		try {
			commande = commandeHome.findByPrimaryKey(new EntityBeanPK(commandeDTO.getId()));
		} catch (FinderException e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "updateCommandeEtat", "Erreur recherche de la commande pour modifier l'�tat " + commandeDTO.getId(), e);
			throw new EJBException(e);
		}
		commande.setEstDansEtatCommande(commandeDTO.getEtatCommande().getId());
	}


	/**
		 * @see com.soliste.bolbec.livraison.service.ejb.sb.ic.InjectionCommandeManager#createProcessus(String)
		 */
	public Processus createProcessus(String processusType) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createProcessus", "Cr�ation du processus");
		HashMap<String, Object> values = new HashMap<String, Object>();
		if (processusType == null) {
			processusType = ProcessusTypeConstantes.COMPLETUDE;
		}
		values.put(aps.Processus.FIELD_INSTANCIE_PROCESSUS_TYPE, processusType);
		values.put(aps.Processus.FIELD_DATE_CREATION, DateUtils.getDatabaseDate());
		values.put(aps.Processus.FIELD_EST_ETAT_PROCESSUS, EtatProcessusConstantes.CREE);
		String processusId = serviceManager.getGeneratorManager().generateKey();
		try {
			Processus processus = processusHome.create(processusId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// processus.setLinks(values);
			return processus;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createProcessus", "Erreur cr�ation du processus " + processusId, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the commande.
	 * 
	 * @param messageXml the message xml
	 * 
	 * @return the aps. commande
	 */
	private aps.Commande createCommande(Message messageXml) {
		String methode = "createCommande";
		serviceManager.getLoggerManager().fine(CLASSNAME, methode, "Cr�ation de la commande");
		HashMap<String, Object> values = new HashMap<String, Object>();
		Commande cde = messageXml.getCommande();
		values.put(aps.Commande.FIELD_PROVIENT_SYSTEME_EXTERNE, messageXml.getIdEmetteur());
		values.put(aps.Commande.FIELD_REF_EXTERNE, cde.getIdCommande());
		String etat = cde.getEtatCommande();
		// si c'est un processus sp�cifique (migration), on passe la commanddirectement en �tat LIVR
		if (cde.getProcessusSpecifique() != null) {
			etat = EtatCommandeConstantes.LIVR;
		} else if (etat == null) {
			etat = EtatCommandeConstantes.FO_VALID;
		}
		values.put(aps.Commande.FIELD_EST_DANS_ETAT_COMMANDE, etat);
		if (StringUtils.isBlank(messageXml.getStatutCommande())) {
			values.put(aps.Commande.FIELD_EST_DANS_STATUT_COMMANDE, StatutCommandeConstantes.NON_MIXTE);
		} else {
			values.put(aps.Commande.FIELD_EST_DANS_STATUT_COMMANDE, messageXml.getStatutCommande());
		}
		values.put(aps.Commande.FIELD_SE_REFERE_CAS_METIER, cde.getCasMetier());
		values.put(aps.Commande.FIELD_DATE_DEBUT_PRISE_COMMANDE_F_O, stringToDate(cde.getDateDebutPriseCommandeFO()));
		values.put(aps.Commande.FIELD_DATE_VALIDATION_F_O, stringToDate(cde.getDateValidationCommandeFO()));
		values.put(aps.Commande.FIELD_ID_VENDEUR, cde.getIdVendeur());
		values.put(aps.Commande.FIELD_VERSION_BOLBEC, Constantes.VERSION);
		values.put(aps.Commande.FIELD_VERSION_APPLICATIVE, VersionManager.getInstance().getCurrentApplicationVersion());
		values.put(aps.Commande.FIELD_DATE_CREATION_BOLBEC, DateUtils.getDatabaseDate());

		String commandeId = getIdCommande();
		try {
			aps.Commande commande = commandeHome.create(commandeId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// commande.setLinks(values);
			return commande;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Erreur cr�ation de la commande " + commandeId, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the adresse.
	 * 
	 * @param adresseXml the adresse xml
	 * 
	 * @return the aps. adresse
	 */
	private aps.Adresse createAdresse(Adresse adresseXml) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createAdresse", "Cr�ation de l'adresse");
		if (adresseXml == null) {
			serviceManager.getLoggerManager().fine(CLASSNAME, "createAdresse", "Aucune adresse � creer");
			return null;
		}
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.Adresse.FIELD_LIGNE1, adresseXml.getLigne1());
		values.put(aps.Adresse.FIELD_LIGNE2, adresseXml.getLigne2());
		values.put(aps.Adresse.FIELD_CODE_POSTAL, adresseXml.getCodePostal());
		values.put(aps.Adresse.FIELD_PAYS, adresseXml.getPays());
		values.put(aps.Adresse.FIELD_VILLE, adresseXml.getVille());
		values.put(aps.Adresse.FIELD_LIBELLE_VOIE, adresseXml.getLibelleVoie());
		values.put(aps.Adresse.FIELD_CODE_RIVOLI, adresseXml.getCodeRivoli());
		values.put(aps.Adresse.FIELD_NUMERO_VOIE, adresseXml.getNumeroVoie());
		values.put(aps.Adresse.FIELD_ENSEMBLE, adresseXml.getEnsemble());
		values.put(aps.Adresse.FIELD_BATIMENT, adresseXml.getBatiment());
		values.put(aps.Adresse.FIELD_ESCALIER, adresseXml.getEscalier());
		values.put(aps.Adresse.FIELD_ETAGE, adresseXml.getEtage());
		values.put(aps.Adresse.FIELD_PORTE, adresseXml.getPorte());
		values.put(aps.Adresse.FIELD_LOGO, adresseXml.getLogo());
		values.put(aps.Adresse.FIELD_CODE_INSEE, adresseXml.getCodeInsee());
		values.put(aps.Adresse.FIELD_TYPE_VOIE, adresseXml.getTypeVoie());
		values.put(aps.Adresse.FIELD_CPLT_NUM_VOIE, adresseXml.getCpltNumVoie());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.Adresse adresse = adresseHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// adresse.setLinks(values);
			return adresse;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createAdresse", "Erreur cr�ation de l'adresse " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the client.
	 * 
	 * @param clientXml the client xml
	 * 
	 * @return the aps. client
	 */
	private aps.Client createClient(ClientType clientXml) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createClient", "Cr�ation du client");
		aps.Adresse adresse = createAdresse(clientXml.getAdresse());
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.Client.FIELD_ID_EXTERNE, clientXml.getIdClient());
		// v�rification : aucune cat�gorie client � null
		String catClient = clientXml.getCategorie();
		if (catClient == null) {
			catClient = QUESTION_MARK_VALUE;
		}
		values.put(aps.Client.FIELD_APPARTIENT_CATEGORIE_CLIENT, catClient);
		values.put(aps.Client.FIELD_TYPE_CLIENT, clientXml.getType());
		values.put(aps.Client.FIELD_TITRE, clientXml.getCivilite());
		values.put(aps.Client.FIELD_DENOMINATION, clientXml.getNomOuRaisonSociale());
		values.put(aps.Client.FIELD_PRENOM, clientXml.getPrenom());
		values.put(aps.Client.FIELD_SIREN, clientXml.getSiren());
		values.put(aps.Client.FIELD_NIC, clientXml.getNic());
		if (adresse != null) {
			serviceManager.getLoggerManager().finest(CLASSNAME, "createClient", "adresse client livr�  non nulle");
			values.put(aps.Client.SLINK_A_ADRESSE, adresse.getId());
		}
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.Client client = clientHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			client.setLinks(values);
			return client;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createClient", "Erreur cr�ation du client " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the interlocuteur.
	 * 
	 * @param contactXml the contact xml
	 * 
	 * @return the aps. interlocuteur
	 */
	private aps.Interlocuteur createInterlocuteur(Contact contactXml) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createInterlocuteur", "Cr�ation de l'interlocuteur");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.Interlocuteur.FIELD_TITRE, contactXml.getTitre());
		values.put(aps.Interlocuteur.FIELD_NOM, contactXml.getNom());
		values.put(aps.Interlocuteur.FIELD_PRENOM, contactXml.getPrenom());
		values.put(aps.Interlocuteur.FIELD_EMAIL, contactXml.getEmail());
		values.put(aps.Interlocuteur.FIELD_PROFESSION, contactXml.getProfession());
		values.put(aps.Interlocuteur.FIELD_TELEPHONE, contactXml.getTelephone());
		values.put(aps.Interlocuteur.FIELD_MOBILE, contactXml.getMobile());
		values.put(aps.Interlocuteur.FIELD_TELECOPIE, contactXml.getFax());
		values.put(aps.Interlocuteur.FIELD_OBSERVATION, contactXml.getObservations());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.Interlocuteur interlocuteur = interlocuteurHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// interlocuteur.setLinks(values);
			return interlocuteur;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createInterlocuteur", "Erreur cr�ation de l'interlocuteur " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the bloc note.
	 * 
	 * @param blocNoteXml the bloc note xml
	 * @param commande the commande
	 * 
	 * @return the aps. bloc note
	 */
	private aps.BlocNote createBlocNote(BlocNote blocNoteXml, aps.Commande commande) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createBlocNote", "Cr�ation du bloc note");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.BlocNote.FIELD_DATE_CREATION, stringToDate(blocNoteXml.getDate()));
		values.put(aps.BlocNote.FIELD_INFO, blocNoteXml.getNote());
		values.put(aps.BlocNote.FIELD_ECRIT_PAR_AGENT, blocNoteXml.getIdAuteur());
		values.put(aps.BlocNote.SLINK_CONCERNE_COMMANDE, commande.getId());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.BlocNote blocNote = blocNoteHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			blocNote.setLinks(values);
			return blocNote;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createBlocNote", "Erreur cr�ation du bloc note " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the ps souhaite.
	 * 
	 * @param psSouhaiteXml the ps souhaite xml
	 * @param ligneCommande the ligne commande
	 * 
	 * @return the aps. ps souhaite
	 */
	private aps.PsSouhaite createPsSouhaite(ProduitServiceSouhaite psSouhaiteXml, aps.LigneCommande ligneCommande) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createPsSouhaite", "Cr�ation du ps souhaite");
		HashMap<String, Object> values = new HashMap<String, Object>();
		String idEPCFutur = psSouhaiteXml.getIdEPCFutur();
		if (idEPCFutur == null) {
			idEPCFutur = calculateIdEPCFutur();
		}
		values.put(PsSouhaite.FIELD_ID_EXTERNE, idEPCFutur);
		values.put(PsSouhaite.FIELD_PORTE_SUR_OFFRE, psSouhaiteXml.getRefOffreCible());
		DetentionProduitService detention = psSouhaiteXml.getDetentionProduitService();
		if (detention != null) {
			values.put(PsSouhaite.FIELD_DETIENT_DETENTION_P_S, detention.getRefDetention());
		}
		values.put(PsSouhaite.FIELD_EST_DESCRIPTION_P_S, psSouhaiteXml.getRefDescriptionProduitService());
		if (psSouhaiteXml.getIdAccesClient() != null) {
			values.put(PsSouhaite.FIELD_ND, psSouhaiteXml.getIdAccesClient());
			ligneCommande.setNdFinder(psSouhaiteXml.getIdAccesClient());
		}
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			PsSouhaite psSouhaite = psSouhaiteHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// psSouhaite.setLinks(values);
			return psSouhaite;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createPsSouhaite", "Erreur cr�ation du ps souhaite " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Construction de la dynamicCommande
	 * 
	 * @param commandeXml la commande au format XML (entr�e de l'injecteur)
	 * @param commande la commande au format Livraison (sortie de l'injecteur)
	 */
	protected void createDynamicCommande(Commande commandeXml, aps.Commande commande) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createDynamicCommande", "Cr�ation des champs dynamiques commande");
		HashMap<String, String> dynValues = new HashMap<String, String>(1);
		addDynamicValues(commandeXml.getParametresCommande(), dynValues);
		for (Entry<String, String> currentEntry : dynValues.entrySet()) {
			String value = currentEntry.getValue();
			if (StringUtils.isNotEmpty(value)) {
				HashMap<String, Object> values = new HashMap<String, Object>();
				values.put(DynamicCommande.FIELD_CLE, currentEntry.getKey());
				values.put(DynamicCommande.FIELD_VALEUR, value);
				values.put(DynamicCommande.SLINK_POUR_COMMANDE, commande.getId());
				String id = serviceManager.getGeneratorManager().generateKey();
				try {
					DynamicCommande dynamic = dynamicCommandeHome.create(id, values);
					// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
					dynamic.setLinks(values);
				} catch (CreateException ce) {
					serviceManager.getLoggerManager().warning(CLASSNAME, "createDynamicCommande", "Erreur cr�ation des champs dynamiques commande " + id, ce);
					throw new EJBException(ce);
				}
			}
		}
	}

	/**
	 * Creates the dynamic ps souhaite.
	 * 
	 * @param psSouhaiteXml the ps souhaite xml
	 * @param psSouhaite the ps souhaite
	 */
	private void createDynamicPsSouhaite(ProduitServiceSouhaite psSouhaiteXml, aps.PsSouhaite psSouhaite) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createDynamicPsSouhaite", "Cr�ation des champs dynamiques ps souhaite");
		HashMap<String, String> dynValues = new HashMap<String, String>(3);
		addDynamicValues(psSouhaiteXml.getParametreContextuel(), dynValues);
		addDynamicValues(psSouhaiteXml.getDiagnosticFaisabilite(), dynValues);
		addDynamicValues(psSouhaiteXml.getParametreProduitService(), dynValues);
		for (Entry<String, String> currentEntry : dynValues.entrySet()) {
			String value = currentEntry.getValue();
			if (StringUtils.isNotEmpty(value)) {
				HashMap<String, Object> values = new HashMap<String, Object>();
				values.put(DynamicPsSouhaite.FIELD_CLE, currentEntry.getKey());
				values.put(DynamicPsSouhaite.FIELD_VALEUR, value);
				values.put(DynamicPsSouhaite.SLINK_POUR_PS_SOUHAITE, psSouhaite.getId());
				String id = serviceManager.getGeneratorManager().generateKey();
				try {
					aps.DynamicPsSouhaite dynamic = dynamicPsSouhaiteHome.create(id, values);
					// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
					dynamic.setLinks(values);
				} catch (CreateException ce) {
					serviceManager.getLoggerManager().warning(CLASSNAME, "createDynamicPsSouhaite", "Erreur cr�ation des champs dynamiques ps souhaite " + id, ce);
					throw new EJBException(ce);
				}
			}
		}
	}

	/**
	 * Creates the op programmee.
	 * 
	 * @param operationProgrammeeXml the operation programmee xml
	 * @param interventions the interventions
	 * 
	 * @return the aps. op programmee
	 */
	private aps.OpProgrammee createOpProgrammee(OperationProgrammee operationProgrammeeXml, Map<String, aps.Intervention> interventions) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createOpProgrammee", "Cr�ation de l'op programmee");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.OpProgrammee.FIELD_EST_TYPE_OP_PROGRAMMEE, operationProgrammeeXml.getTypeOp());
		String refInterv = operationProgrammeeXml.getIdIntervention();
		if (!interventions.containsKey(refInterv)) {
			throw new ReceptionCdeException("message/commande(/instanceOffreGroupee)/ligneCommande/operationProgrammee/idIntervention : il n'existe pas d'intervention avec la r�f�rence " + refInterv);
		}
		values.put(aps.OpProgrammee.SLINK_FAITE_LORS_INTERVENTION, interventions.get(refInterv).getId());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.OpProgrammee opProgrammee = opProgrammeeHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			opProgrammee.setLinks(values);
			return opProgrammee;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createOpProgrammee", "Erreur cr�ation de l'op programmee " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the lien op prog ld c.
	 * 
	 * @param opProgrammee the op programmee
	 * @param ligneCommande the ligne commande
	 * 
	 * @return the aps. lien op prog ld c
	 */
	private aps.LienOpProgLdC createLienOpProgLdC(aps.OpProgrammee opProgrammee, aps.LigneCommande ligneCommande) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createLienOpProgLdC", "Cr�ation du lien entre op programmee et ligne de comande");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(LienOpProgLdC.SLINK_REQUIERE_OP_PROGRAMMEE, opProgrammee.getId());
		values.put(LienOpProgLdC.SLINK_APPARTIENT_LIGNE_COMMANDE, ligneCommande.getId());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.LienOpProgLdC lienOpProgLdC = lienOpProgLdCHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			lienOpProgLdC.setLinks(values);
			return lienOpProgLdC;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createLienOpProgLdC", "Erreur cr�ation du lien entre op programmee et ligne de comande " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the processus lc.
	 * 
	 * @param processus the processus
	 * @param ligneCommande the ligne commande
	 * 
	 * @return the aps. processus lc
	 */
	private aps.ProcessusLC createProcessusLC(aps.Processus processus, aps.LigneCommande ligneCommande) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createLienOpProgLdC", "Cr�ation du lien entre processus et ligne de comande");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.ProcessusLC.SLINK_EST_LIVRE_PAR_PROCESSUS, processus.getId());
		values.put(aps.ProcessusLC.SLINK_LIVRE_LIGNE_COMMANDE, ligneCommande.getId());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.ProcessusLC processusLC = processusLCHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			processusLC.setLinks(values);
			return processusLC;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createLienOpProgLdC", "Erreur cr�ation du lien entre processus et ligne de comande " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the intervention.
	 * 
	 * @param interventionXml the intervention xml
	 * 
	 * @return the aps. intervention
	 */
	private aps.Intervention createIntervention(Intervention interventionXml) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createIntervention", "Cr�ation de l'intervention");
		HashMap<String, Object> values = new HashMap<String, Object>();

		// Report IRMA 403
		// La r�f�rence de l'intervention n�cessite un traitement particulier, s'il existe une RefERDV,
		// alors la valoriser par le 3e champ de RefERDV (exemple : 295 si la ref est IML-IPM-295-0000007026680-ERDV)
		// sinon la valoriser avec l'id intervention qui a �t� attribu� dans l'IC g�n�rique (format d'injection)
		String reference = interventionXml.getIdIntervention();
		String refRDV = interventionXml.getRefRDV();
		if (refRDV != null) {
			String[] idIntervERDVSpliter = refRDV.split("-");
			if (idIntervERDVSpliter.length >= 3) {
				String newIdInterv = idIntervERDVSpliter[2];
				if (newIdInterv != null) {
					reference = newIdInterv;
				}
			} else {
				serviceManager.getLoggerManager().warning(getClass().getName(), "getInterventionValues", "Le RefRDV de l'intervention (" + reference + ") n'a pas la forme attendue : " + refRDV);
			}
		}

		values.put(aps.Intervention.FIELD_REFERENCE, reference);
		values.put(aps.Intervention.FIELD_REF_EXTERNE, interventionXml.getIdPlanCharge());
		values.put(aps.Intervention.FIELD_EST_DANS_ETAT_INTERVENTION, interventionXml.getEtatIntervention());
		values.put(aps.Intervention.FIELD_DATE_PRISE, stringToDate(interventionXml.getDateReservation()));
		values.put(aps.Intervention.FIELD_DEBUT_PLAGE, stringToDate(interventionXml.getDebutPlage()));
		values.put(aps.Intervention.FIELD_FIN_PLAGE, stringToDate(interventionXml.getFinPlage()));
		values.put(aps.Intervention.FIELD_DUREE, interventionXml.getDuree());
		values.put(aps.Intervention.FIELD_OBSERVATION, interventionXml.getObservations());
		values.put(aps.Intervention.FIELD_MESCONTR, interventionXml.getMesc());
		values.put(aps.Intervention.FIELD_REF_ERDV, interventionXml.getRefRDV());
		values.put(aps.Intervention.FIELD_EST_RESPONSABILITE, interventionXml.getResponsabilite());

		HashMap<String, String> dynValues = new HashMap<String, String>();
		addDynamicValues(interventionXml.getParametre(), dynValues);

		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.Intervention intervention = interventionHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// intervention.setLinks(values);
			// champs dynamiques
			createDynamicIntervention(id, dynValues);
			return intervention;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createIntervention", "Erreur cr�ation de l'intervention " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the dynamic intervention.
	 * 
	 * @param id the id
	 * @param dynValues the dyn values
	 */
	private void createDynamicIntervention(String id, HashMap<String, String> dynValues) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createDynamicIntervention", "Cr�ation dynamique intervention pour la intervention " + id);
		for (Entry<String, String> currentEntry : dynValues.entrySet()) {
			String value = currentEntry.getValue();
			if (StringUtils.isNotEmpty(value)) {
				HashMap<String, Object> values = new HashMap<String, Object>();
				values.put(aps.DynamicIntervention.FIELD_CLE, currentEntry.getKey());
				values.put(aps.DynamicIntervention.FIELD_VALEUR, value);
				values.put(aps.DynamicIntervention.SLINK_POUR_INTERVENTION, id);
				String dynamicId = serviceManager.getGeneratorManager().generateKey();
				try {
					DynamicIntervention dynamic = dynamicInterventionHome.create(dynamicId, values);
					// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
					dynamic.setLinks(values);
				} catch (CreateException ce) {
					serviceManager.getLoggerManager().warning(CLASSNAME, "createDynamicIntervention", "Erreur cr�ation dynamique intervention pour la intervention " + id, ce);
					throw new EJBException(ce);
				}
			}
		}
	}

	/**
	 * Creates the ligne cmd catalogue.
	 * 
	 * @return the aps. ligne cmd catalogue
	 */
	private aps.LigneCmdCatalogue createLigneCmdCatalogue() {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createLigneCmdCatalogue", "Cr�ation de la ligne commande catalogue");
		HashMap<String, Object> values = new HashMap<String, Object>();
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.LigneCmdCatalogue ligneCmdCatalogue = ligneCmdCatalogueHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// ligneCmdCatalogue.setLinks(values);
			return ligneCmdCatalogue;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createLigneCmdCatalogue", "Erreur cr�ation de la ligne commande catalogue " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the ligne cmd sup parc.
	 * 
	 * @return the aps. ligne cmd sup parc
	 */
	private aps.LigneCmdSupParc createLigneCmdSupParc() {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createLigneCmdSupParc", "Cr�ation de la ligne commande Sup Parc");
		HashMap<String, Object> values = new HashMap<String, Object>();
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.LigneCmdSupParc ligneCmdSupParc = ligneCmdSupParcHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// ligneCmdSupParc.setLinks(values);
			return ligneCmdSupParc;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createLigneCmdSupParc", "Erreur cr�ation de la ligne commande Sup Parc " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the ligne cmd mod parc.
	 * 
	 * @return the aps. ligne cmd mod parc
	 */
	private aps.LigneCmdModParc createLigneCmdModParc() {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createLigneCmdModParc", "Cr�ation de la ligne commande Mod Parc");
		HashMap<String, Object> values = new HashMap<String, Object>();
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.LigneCmdModParc ligneCmdModParc = ligneCmdModParcHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// ligneCmdModParc.setLinks(values);
			return ligneCmdModParc;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createLigneCmdModParc", "Erreur cr�ation de la ligne commande Mod Parc " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the ligne commande.
	 * 
	 * @param ligneXml the ligne xml
	 * @param idCommande the id commande
	 * @param systemeExterne the systeme externe
	 * @param instanceLocalisation the instance localisation
	 * 
	 * @return the aps. ligne commande
	 */
	private aps.LigneCommande createLigneCommande(LigneCommandeType ligneXml, String idCommande, String systemeExterne, String instanceLocalisation) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createLigneCommande", "Cr�ation de la ligne de commande");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.LigneCommande.FIELD_REF_EXTERNE, ligneXml.getIdLigneCommande());
		values.put(aps.LigneCommande.FIELD_QUANTITE, ligneXml.getQuantite());
		values.put(aps.LigneCommande.FIELD_DATE_CONTRACTUELLE, stringToDate(ligneXml.getDateContractuelle()));
		values.put(aps.LigneCommande.FIELD_DATE_SOUHAITEE, stringToDate(ligneXml.getDateSouhaitee()));
		values.put(aps.LigneCommande.FIELD_CODE_FACTURATION_OFFRE, ligneXml.getCodeFacturationOffre());
		if (ligneXml.getMontantLigne() != null) {
			values.put(aps.LigneCommande.FIELD_PRIX_OFFRE_H_T, ligneXml.getMontantLigne());
		} else {
			values.put(aps.LigneCommande.FIELD_PRIX_OFFRE_H_T, new Float(0));
		}
		values.put(aps.LigneCommande.FIELD_CODE_FACTURATION_REMISE, ligneXml.getCodeFacturationRemise());
		values.put(aps.LigneCommande.FIELD_PRIX_REMISE_H_T, ligneXml.getMontantRemise());
		values.put(aps.LigneCommande.FIELD_TVA, ligneXml.getTypeTVA());
		values.put(aps.LigneCommande.FIELD_DEPEND_CONTEXTE, ligneXml.getRefContexteLivraison());
		values.put(aps.LigneCommande.FIELD_A_TYPE_OP_PONCTUELLES, ligneXml.getRefOperationPonctuelle());
		values.put(aps.LigneCommande.FIELD_EST_ETAT_LIGNE_CDE, EtatLigneCdeConstantes.CREEE);
		values.put(aps.LigneCommande.FIELD_ID_COMMANDE, idCommande);
		values.put(aps.LigneCommande.FIELD_RECU_PAR_SYSTEME_EXTERNE, systemeExterne);
		values.put(aps.LigneCommande.FIELD_LIE_A_INSTANCE_LOCALISATION, instanceLocalisation);
		values.put(aps.LigneCommande.FIELD_DANS_Z_S_I_ZONE_S_I, getZoneSI(instanceLocalisation));
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.LigneCommande ligneCommande = ligneCommandeHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// ligneCommande.setLinks(values);
			return ligneCommande;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createLigneCommande", "Erreur cr�ation de la ligne de commande " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the dynamic ligne commande.
	 * 
	 * @param ligneXml the ligne xml
	 * @param ligneCommande the ligne commande
	 * @param version the version
	 */
	private void createDynamicLigneCommande(LigneCommandeType ligneXml, aps.LigneCommande ligneCommande, String version) {
		String ligneCommandeId = ligneCommande.getId();
		serviceManager.getLoggerManager().fine(CLASSNAME, "createDynamicLigneCommande", "Cr�ation des champs dynamiques ligne de commande pour la ligne " + ligneCommandeId);
		HashMap<String, String> dynValues = new HashMap<String, String>();
		addDynamicValues(ligneXml.getParametreLivraison(), dynValues);
		dynValues.put(ConstantesDynamicLigneCommande.LIGNECOMMANDE_VERSIONMODELELPA, version);
		for (Entry<String, String> currentEntry : dynValues.entrySet()) {
			String value = currentEntry.getValue();
			if (StringUtils.isNotEmpty(value)) {
				HashMap<String, Object> values = new HashMap<String, Object>();
				values.put(DynamicLigneCommande.FIELD_CLE, currentEntry.getKey());
				values.put(DynamicLigneCommande.FIELD_VALEUR, value);
				values.put(DynamicLigneCommande.SLINK_POUR_LIGNE_COMMANDE, ligneCommandeId);
				String id = serviceManager.getGeneratorManager().generateKey();
				try {
					aps.DynamicLigneCommande dynamic = dynamicLigneCommandeHome.create(id, values);
					// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
					dynamic.setLinks(values);
				} catch (CreateException ce) {
					serviceManager.getLoggerManager().warning(CLASSNAME, "createDynamicLigneCommande", "Erreur cr�ation des champs dynamiques ligne de commande pour la ligne " + ligneCommandeId, ce);
					throw new EJBException(ce);
				}
			}
		}
	}

	/**
	 * Creates the ep commercial.
	 * 
	 * @param epAffecte the ep affecte
	 * 
	 * @return the aps. ep commercial
	 */
	private aps.EPCommercial createEPCommercial(ElementParcAffecte epAffecte) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createEPCommercial", "Cr�ation de l'ep commercial");
		HashMap<String, Object> values = new HashMap<String, Object>(4);
		values.put(aps.EPCommercial.FIELD_ID_EXTERNE, epAffecte.getIdEPC());
		values.put(aps.EPCommercial.FIELD_ND, epAffecte.getIdAccesClient());
		values.put(aps.EPCommercial.FIELD_EST_OFFRE, epAffecte.getRefOffreExistante());
		values.put(aps.EPCommercial.FIELD_POUR_DETENTION_P_S, epAffecte.getRefDetentionExistante());

		HashMap<String, String> dynValues = new HashMap<String, String>();
		addDynamicValues(epAffecte.getParametreElementParc(), dynValues);

		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.EPCommercial epCommercial = epCommercialHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// epCommercial.setLinks(values);
			// champs dynamiques
			createDynamicEPCommercial(id, dynValues);
			return epCommercial;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createEPCommercial", "Erreur cr�ation de l'ep commercial " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the dynamic ep commercial.
	 * 
	 * @param id the id
	 * @param dynValues the dyn values
	 */
	private void createDynamicEPCommercial(String id, HashMap<String, String> dynValues) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createDynamicEPCommercial", "Cr�ation champs dynamiques epCommercial pour l'ep " + id);
		for (Entry<String, String> currentEntry : dynValues.entrySet()) {
			String value = currentEntry.getValue();
			if (StringUtils.isNotEmpty(value)) {
				HashMap<String, Object> values = new HashMap<String, Object>();
				values.put(aps.DynamicEPCommercial.FIELD_CLE, currentEntry.getKey());
				values.put(aps.DynamicEPCommercial.FIELD_VALEUR, value);
				values.put(aps.DynamicEPCommercial.SLINK_POUR_E_P_COMMERCIAL, id);
				String dynamicId = serviceManager.getGeneratorManager().generateKey();
				try {
					aps.DynamicEPCommercial dynamic = dynamicEPCommercialHome.create(dynamicId, values);
					// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
					dynamic.setLinks(values);
				} catch (CreateException ce) {
					serviceManager.getLoggerManager().warning(CLASSNAME, "createDynamicEPCommercial", "Erreur cr�ation champs dynamiques epCommercial pour l'ep " + id, ce);
					throw new EJBException(ce);
				}
			}
		}
	}

	/**
	 * Creates the ep commercial.
	 * 
	 * @param psSouhaiteXml the ps souhaite xml
	 * 
	 * @return the aps. ep commercial
	 */
	private aps.EPCommercial createEPCommercial(ProduitServiceSouhaite psSouhaiteXml) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createEPCommercial", "Cr�ation de l'ep commercial");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(aps.EPCommercial.FIELD_ID_EXTERNE, psSouhaiteXml.getIdElementParcSupport());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.EPCommercial epCommercial = epCommercialHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// epCommercial.setLinks(values);
			return epCommercial;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createEPCommercial", "Erreur cr�ation de l'ep commercial " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the instance og.
	 * 
	 * @param instanceOffreGroupee the instance offre groupee
	 * 
	 * @return the aps. instance og
	 */
	private aps.InstanceOG createInstanceOG(InstanceOffreGroupee instanceOffreGroupee) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createInstanceOG", "Cr�ation de l'instance OG");
		HashMap<String, Object> values = new HashMap<String, Object>(1);
		values.put(aps.InstanceOG.FIELD_CONCERNE_OFFRE_GROUPEE, instanceOffreGroupee.getRefOffreGroupee());
		String id = serviceManager.getGeneratorManager().generateKey();
		try {
			aps.InstanceOG instanceOG = instanceOGHome.create(id, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			// instanceOG.setLinks(values);
			return instanceOG;
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createInstanceOG", "Erreur cr�ation de l'instance OG " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Sets the cde links.
	 * 
	 * @param commande the commande
	 * @param commandeXml the commande xml
	 * @param processus the processus
	 * @param systemeExterne the systeme externe
	 * @param instanceLocalisation the instance localisation
	 * @param version the version
	 */
	private void setCdeLinks(aps.Commande commande, Commande commandeXml, aps.Processus processus, String systemeExterne, String instanceLocalisation, String version) {
		ClientType clientXml = commandeXml.getClientContractant();
		serviceManager.getICValidationManager().validateClient(clientXml);
		setClient(commande, clientXml);

		Contact contactXml = commandeXml.getContact();
		if (contactXml != null) {
			commande.setLinkContacteInterlocuteur(createInterlocuteur(contactXml));
		}

		Map<String, aps.Client> clientLivres = new HashMap<String, aps.Client>();
		serviceManager.getLoggerManager().finest(getClass().getName(), "setCdeLinks", "cr�ation arraylist client");
		Map<String, aps.Intervention> interventions = setInterventions(commandeXml.getIntervention());
		setLignesCommande(commande, commandeXml.getLigneCommande(), processus, commande.getId(), systemeExterne, instanceLocalisation, clientLivres, version, interventions);

		InstanceOffreGroupee[] instancesOG = commandeXml.getInstanceOffreGroupee();
		for (int i = 0; i < instancesOG.length; i++) {
			serviceManager.getICValidationManager().validateInstanceOffreGroupee(instancesOG[i]);
			aps.InstanceOG instanceOG = createInstanceOG(instancesOG[i]);
			setLignesCommande(instanceOG, instancesOG[i].getLigneCommande(), processus, commande.getId(), systemeExterne, instanceLocalisation, clientLivres, version, interventions);
			instanceOG.setLinkComposeCommande(commande);
		}

		BlocNote[] blocNotes = commandeXml.getBlocNote();
		for (int i = 0; i < blocNotes.length; i++) {
			createBlocNote(blocNotes[i], commande);
		}

		createDynamicCommande(commandeXml, commande);
	}

	/**
	 * Sets donn�es client.
	 *
	 * @param commande the commande
	 * @param clientXml the client xml
	 */
	private void setClient(aps.Commande commande, ClientType clientXml) {
		aps.Client client = commande.getLinkCommandeParClient();
		if (client == null) {
			client = createClient(clientXml);
			commande.setLinkCommandeParClient(client);
		} else {
			serviceManager.getLoggerManager().fine(CLASSNAME, "setCdeLinks", "Mis � jour du client");
			aps.Adresse adresse = createAdresse(clientXml.getAdresse());
			if (adresse != null) {
				serviceManager.getLoggerManager().finest(CLASSNAME, "createClient", "adresse client livr�  non nulle");
				client.setLinkAAdresse(adresse);
			}

			client.setIdExterne(clientXml.getIdClient());
			// v�rification : aucune cat�gorie client � null
			String catClient = clientXml.getCategorie();
			if (catClient == null) {
				catClient = QUESTION_MARK_VALUE;
			}
			client.setAppartientCategorieClient(catClient);
			client.setTypeClient(clientXml.getType());
			client.setTitre(clientXml.getCivilite());
			client.setDenomination(clientXml.getNomOuRaisonSociale());
			client.setPrenom(clientXml.getPrenom());
			client.setSiren(clientXml.getSiren());
			client.setNic(clientXml.getNic());
		}
	}

	/**
	 * M�thode qui parcourt les interventions et fait la liaison avec les
	 * op�rations programm�es qui sont d�j� dans l'espace d'entit�s. Une petite
	 * part de la validation est faite en m�me temps pour �viter de r�p�ter les
	 * it�rations sur les interventions et les op�rations programm�es.
	 * 
	 * @param interventions the interventions
	 * 
	 * @return the map< string,aps. intervention>
	 */
	private Map<String, aps.Intervention> setInterventions(Intervention[] interventions) {
		Map<String, aps.Intervention> intervsMap = new HashMap<String, aps.Intervention>();
		for (int i = 0; i < interventions.length; i++) {
			serviceManager.getICValidationManager().validateIntervention(interventions[i]);
			aps.Intervention intervention = createIntervention(interventions[i]);
			String id = interventions[i].getIdIntervention();
			if (intervsMap.get(id) != null) {
				throw new ReceptionCdeException("message/commande/intervention/idIntervention : il existe plus qu'une intervention avec la r�f�rence " + id + ". La r�f�rence doit �tre unique.");
			}
			intervsMap.put(id, intervention);
		}
		return intervsMap;
	}

	/**
	 * Sets the lignes commande.
	 * 
	 * @param commandeOuInstanceOG the commande ou instance og
	 * @param lignes the lignes
	 * @param processus the processus
	 * @param idCommande the id commande
	 * @param systemeExterne the systeme externe
	 * @param instanceLocalisation the instance localisation
	 * @param listeClientLivre the liste client livre
	 * @param version the version
	 * @param interventions the interventions
	 */
	protected void setLignesCommande(Object commandeOuInstanceOG, LigneCommandeType[] lignes, aps.Processus processus, String idCommande, String systemeExterne, String instanceLocalisation, Map<String, aps.Client> listeClientLivre, String version,
			Map<String, aps.Intervention> interventions) {
		for (int i = 0; i < lignes.length; i++) {
			String opPonctuelle = lignes[i].getRefOperationPonctuelle();
			if (aps.TypeOpPonctuellesConstantes.CR.equals(opPonctuelle) || aps.TypeOpPonctuellesConstantes.DEMMND.equals(opPonctuelle)) {
				serviceManager.getICValidationManager().validateLigneCommandeCr(lignes[i]);
				aps.LigneCmdCatalogue ligneCmdCatalogue = createLigneCmdCatalogue();
				setLigneCommandeCrLinks(ligneCmdCatalogue, lignes[i], processus, idCommande, systemeExterne, instanceLocalisation, listeClientLivre, version, interventions);
				ligneCmdCatalogue.setLinkComposeInstanceOG((aps.InstanceOG) commandeOuInstanceOG);
			} else if (aps.TypeOpPonctuellesConstantes.SU.equals(opPonctuelle) || aps.TypeOpPonctuellesConstantes.RESIL.equals(opPonctuelle)) {
				serviceManager.getICValidationManager().validateLigneCommandeSu(lignes[i]);
				aps.LigneCmdSupParc ligneCmdSupParc = createLigneCmdSupParc();
				setLigneCommandeSuLinks(ligneCmdSupParc, lignes[i], processus, idCommande, systemeExterne, instanceLocalisation, listeClientLivre, version, interventions);
				ligneCmdSupParc.setLinkComposeCommande((aps.Commande) commandeOuInstanceOG);
				// FTTH_Lot2 Ajout du cas des LC EQUALS
			} else if (aps.TypeOpPonctuellesConstantes.MO.equals(opPonctuelle) || aps.TypeOpPonctuellesConstantes.DENUM.equals(opPonctuelle) || aps.TypeOpPonctuellesConstantes.CGTIT.equals(opPonctuelle)
					|| TypeOpPonctuellesConstantes.EQUALS.equals(opPonctuelle)) {
				serviceManager.getICValidationManager().validateLigneCommandeMo(lignes[i]);
				aps.LigneCmdModParc ligneCmdModParc = createLigneCmdModParc();
				setLigneCommandeMoLinks(ligneCmdModParc, lignes[i], processus, idCommande, systemeExterne, instanceLocalisation, listeClientLivre, version, interventions);
				ligneCmdModParc.setLinkComposeCommande((aps.Commande) commandeOuInstanceOG);
			} else {
				throw new ReceptionCdeException(opPonctuelle, "ligneCommande/refOperationPonctuelle");
			}
		}
	}

	/**
	 * Sets the ligne commande cr links.
	 * 
	 * @param ligneCmdCatalogue the ligne cmd catalogue
	 * @param ligneXml the ligne xml
	 * @param processusPxy the processus pxy
	 * @param idCommande the id commande
	 * @param systemeExterne the systeme externe
	 * @param instanceLocalisation the instance localisation
	 * @param listeClientLivre the liste client livre
	 * @param version the version
	 * @param interventions the interventions
	 */
	private void setLigneCommandeCrLinks(aps.LigneCmdCatalogue ligneCmdCatalogue, LigneCommandeType ligneXml, aps.Processus processusPxy, String idCommande, String systemeExterne, String instanceLocalisation, Map<String, aps.Client> listeClientLivre,
			String version, Map<String, aps.Intervention> interventions) {
		aps.LigneCommande ligneCommande = createLigneCommande(ligneXml, idCommande, systemeExterne, instanceLocalisation);
		setLigneCommandeLinks(ligneCommande, ligneXml, processusPxy, listeClientLivre, version, interventions);

		ligneCmdCatalogue.setLinkEstLigneCommande(ligneCommande);

		// RG4 : valeur de l'acc�s de livraison
		setAccesLivraison(ligneCommande, ligneXml);

		ProduitServiceSouhaite psSouhaiteXml = ligneXml.getProduitServiceSouhaite();
		if (psSouhaiteXml != null) {
			serviceManager.getICValidationManager().validatePSSouhaite(psSouhaiteXml);
			PsSouhaite psSouhaite = createPsSouhaite(psSouhaiteXml, ligneCommande);
			setPsSouhaiteLinks(psSouhaiteXml, psSouhaite);
			ligneCmdCatalogue.setLinkDecriteParPsSouhaite(psSouhaite);
		}
	}

	/**
	 * Sets the ligne commande mo links.
	 * 
	 * @param ligneMoPxy the ligne mo pxy
	 * @param ligneXml the ligne xml
	 * @param a_processusPxy the a_processus pxy
	 * @param idCommande the id commande
	 * @param systemeExterne the systeme externe
	 * @param instanceLocalisation the instance localisation
	 * @param listeClientLivre the liste client livre
	 * @param version the version
	 * @param interventions the interventions
	 */
	private void setLigneCommandeMoLinks(aps.LigneCmdModParc ligneMoPxy, LigneCommandeType ligneXml, aps.Processus a_processusPxy, String idCommande, String systemeExterne, String instanceLocalisation, Map<String, aps.Client> listeClientLivre,
			String version, Map<String, aps.Intervention> interventions) {
		aps.LigneCommande ligneCommande = createLigneCommande(ligneXml, idCommande, systemeExterne, instanceLocalisation);

		setLigneCommandeLinks(ligneCommande, ligneXml, a_processusPxy, listeClientLivre, version, interventions);
		ligneMoPxy.setLinkEstLigneCommande(ligneCommande);

		// RG4 : valeur de l'acc�s de livraison
		setAccesLivraison(ligneCommande, ligneXml);

		ElementParcAffecte epAffecte = ligneXml.getElementParcAffecte();
		serviceManager.getICValidationManager().validateElementParcAffecte(epAffecte);
		if (TypeOpPonctuellesConstantes.DENUM.equals(ligneXml.getRefOperationPonctuelle())) {
			ligneCommande.setNdFinder(ligneXml.getAccesLivraison());
		} else {
			ligneCommande.setNdFinder(epAffecte.getIdAccesClient());
		}

		aps.EPCommercial epCommercial = createEPCommercial(epAffecte);
		ligneMoPxy.setLinkModifieEPCommercial(epCommercial);

		ProduitServiceSouhaite psSouhaiteXml = ligneXml.getProduitServiceSouhaite();
		if (psSouhaiteXml != null) {
			serviceManager.getICValidationManager().validatePSSouhaite(psSouhaiteXml);
			aps.PsSouhaite psSouhaite = createPsSouhaite(psSouhaiteXml, ligneCommande);
			createDynamicPsSouhaite(psSouhaiteXml, psSouhaite);
			psSouhaite.setLinkAppliqueSurEPCommercial(epCommercial);
			ligneMoPxy.setLinkDecriteParPsSouhaite(psSouhaite);
		}
	}

	/**
	 * Sets the ligne commande su links.
	 * 
	 * @param ligneCmdSupParc the ligne cmd sup parc
	 * @param ligneXml the ligne xml
	 * @param processus the processus
	 * @param idCommande the id commande
	 * @param systemeExterne the systeme externe
	 * @param instanceLocalisation the instance localisation
	 * @param listeClientLivre the liste client livre
	 * @param version the version
	 * @param interventions the interventions
	 */
	private void setLigneCommandeSuLinks(aps.LigneCmdSupParc ligneCmdSupParc, LigneCommandeType ligneXml, aps.Processus processus, String idCommande, String systemeExterne, String instanceLocalisation, Map<String, aps.Client> listeClientLivre,
			String version, Map<String, aps.Intervention> interventions) {
		aps.LigneCommande ligneCommande = createLigneCommande(ligneXml, idCommande, systemeExterne, instanceLocalisation);
		setLigneCommandeLinks(ligneCommande, ligneXml, processus, listeClientLivre, version, interventions);
		ligneCmdSupParc.setLinkEstLigneCommande(ligneCommande);

		// RG4 : valeur de l'acc�s de livraison
		setAccesLivraison(ligneCommande, ligneXml);

		ElementParcAffecte epAffecte = ligneXml.getElementParcAffecte();
		if (epAffecte != null) {
			serviceManager.getICValidationManager().validateElementParcAffecte(epAffecte);
			ligneCommande.setNdFinder(epAffecte.getIdAccesClient());
			aps.EPCommercial epCommercial = createEPCommercial(epAffecte);
			ligneCmdSupParc.setLinkSupprimeEPCommercial(epCommercial);
		}
	}

	/**
	 * Sets the acces livraison.
	 * 
	 * @param ligneCommande the ligne commande
	 * @param ligneXml the ligne xml
	 */
	private void setAccesLivraison(aps.LigneCommande ligneCommande, LigneCommandeType ligneXml) {
		// RG4 : valeur de l'acc�s de livraison
		String acces = null;
		if (TYPEACCES_LIV_IDCLI.equals(ligneXml.getTypeAccesLivraison())) {
			aps.Client clientLivre = ligneCommande.getLinkLivreClient();
			acces = clientLivre.getId();
		} else {
			acces = ligneXml.getAccesLivraison();
		}
		ligneCommande.setAccesLivraison(acces);
		ligneCommande.setAccesLivraisonOrigine(acces);
		String typeAcces = ligneXml.getTypeAccesLivraison();
		ligneCommande.setTypeAccesLivraison(typeAcces);
		ligneCommande.setTypeAccesLivraisonOrigine(typeAcces);
	}

	/**
	 * Sets the ps souhaite links.
	 * 
	 * @param psSouhaiteXml the ps souhaite xml
	 * @param psSouhaite the ps souhaite
	 */
	private void setPsSouhaiteLinks(ProduitServiceSouhaite psSouhaiteXml, aps.PsSouhaite psSouhaite) {
		createDynamicPsSouhaite(psSouhaiteXml, psSouhaite);
		aps.EPCommercial epCommercial = createEPCommercial(psSouhaiteXml);
		psSouhaite.setLinkAppliqueSurEPCommercial(epCommercial);
	}

	/**
	 * Adds the dynamic values.
	 * 
	 * @param params the params
	 * @param values the values
	 */
	private void addDynamicValues(ParametreType[] params, HashMap<String, String> values) {
		for (int i = 0; i < params.length; i++) {
			String valeur = params[i].getValeur();
			if (valeur != null && valeur.length() > 512) {
				valeur = valeur.substring(0, 512);
			}
			String cle = params[i].getCle();
			if (cle != null) {
				// Intervention
				int pos = cle.indexOf(INTERVENTION_VALUE);
				if (pos == 0) {
					cle = cle.substring(INTERVENTION_VALUE.length());
				}
				// LigneCommande
				pos = cle.indexOf(LIGNE_COMMANDE_VALUE);
				if (pos == 0) {
					cle = cle.substring(LIGNE_COMMANDE_VALUE.length());
				}
			}
			values.put(cle, valeur);
		}
	}

	/**
	 * Sets the ligne commande links.
	 * 
	 * @param ligneCommande the ligne commande
	 * @param ligneXml the ligne xml
	 * @param processus the processus
	 * @param listeClient the liste client
	 * @param version the version
	 * @param interventions the interventions
	 */
	private void setLigneCommandeLinks(aps.LigneCommande ligneCommande, LigneCommandeType ligneXml, aps.Processus processus, Map<String, aps.Client> listeClient, String version, Map<String, aps.Intervention> interventions) {
		serviceManager.getLoggerManager().finest(getClass().getName(), "setLigneCommandeLinks", "begin");
		ClientLivre clientXml = ligneXml.getClientLivre();
		if (clientXml != null) {
			String idClientLivre = clientXml.getIdClient();
			String nomRaisonSocClientLivre = clientXml.getNomOuRaisonSociale();
			serviceManager.getICValidationManager().validateClient(clientXml);
			aps.Client clientTrouve = existClientLivre(idClientLivre + nomRaisonSocClientLivre, listeClient);
			if (clientTrouve == null) {
				aps.Client client = createClient(clientXml);
				serviceManager.getLoggerManager().finest(getClass().getName(), "setLigneCommandeLinks", "Client livr� cr�� : " + client.getId());
				// Ajout dans la HashMap
				listeClient.put(idClientLivre + nomRaisonSocClientLivre, client);
				serviceManager.getLoggerManager().finest(getClass().getName(), "setLigneCommandeLinks", "ajout client livr�. total = " + listeClient.size());
				ligneCommande.setLinkLivreClient(client);
			} else {
				// Faire uniquement le lien avec la ligne de commande
				serviceManager.getLoggerManager().finest(getClass().getName(), "setLigneCommandeLinks", "Lien avec commande du proxy client : " + clientTrouve.getId());
				ligneCommande.setLinkLivreClient(clientTrouve);
			}
		}

		OperationProgrammee[] ops = ligneXml.getOperationProgrammee();
		for (int i = 0; i < ops.length; i++) {
			serviceManager.getICValidationManager().validateOperationProgrammee(ops[i]);
			aps.OpProgrammee opProgrammee = createOpProgrammee(ops[i], interventions);
			createLienOpProgLdC(opProgrammee, ligneCommande);
		}

		createDynamicLigneCommande(ligneXml, ligneCommande, version);
		createProcessusLC(processus, ligneCommande);
	}

	/**
	 * V�rification de l'existence du client.
	 * 
	 * @param idConcatNomClient :
	 * ID du client concat�n� avec le nom ou raison sociale
	 * @param client the client
	 * 
	 * @return Client
	 */
	private aps.Client existClientLivre(String idConcatNomClient, Map<String, aps.Client> client) {
		if (!client.isEmpty()) {
			serviceManager.getLoggerManager().finest(getClass().getName(), "existClientLivre", "nb client livr�  : " + client.size());
			// Parcours de la liste des clients livr�s
			if (client.containsKey(idConcatNomClient)) {
				return client.get(idConcatNomClient);
			}
			return null;
		}
		return null;
	}

	/**
	 * Construction de l'id de commande dont le format est YYMMXX[XX]NNNNNN[NN]
	 * <ul>
	 * <li> YYMM l'ann�e et le mois
	 * <li> XX[XX] le code DR de l'instance locale d'Artemis pass� en param�tre
	 * de d�marrage de la JVM (voir
	 * <code>{@link GeneratorManager#COUNTER_PREFIX}</code>)
	 * <li>NNNNNN[NN]: les 6 (ou 8) premiers caract�res de la cha�ne compos�e
	 * d'un entier de 0 � l'infini et "1000000000".
	 * </ul>
	 * 
	 * Exemple : 0603LN002931000
	 * <ul>
	 * <li> 0603 correspond � mars 2003
	 * <li> LN00293 est la valeur de retour de la m�thode
	 * <code>{@link InjectionCommandeManagerBean#getCommandeSerialId()}</code>
	 * <li>1000 correspond aux 4 premiers caract�res de ONE_BILLION_VALUE qui
	 * ont �t� conserv�s suite au substring(0,10)
	 * </ul>
	 * 
	 * @return id de la commande
	 */
	private String getIdCommande() {
		Calendar calendar = Calendar.getInstance();
		int mois = calendar.get(Calendar.MONTH) + 1;
		int annee = calendar.get(Calendar.YEAR);
		DecimalFormat decimalFormatTwoDigits = new DecimalFormat(DOUBLE_ZERO_VALUE);
		// i.e. numeroCommande �gale "0603"
		String numeroCommande = decimalFormatTwoDigits.format(annee % 100) + decimalFormatTwoDigits.format(mois);
		// i.e. numeroCommande �gale "0603LN002931000"
		// getCommandeSerialId() renvoyant LN00293 dans ce cas
		numeroCommande += (getCommandeSerialId() + ONE_BILLION_VALUE).substring(0, 10);
		return numeroCommande;
	}

	/**
	 * Retrourne un identifiant de 10 caract�res au maximum au format
	 * XX[XX]NNNNNN[NN] dont
	 * <ul>
	 * <li>XX[XX] le code DR de l'instance locale d'Artemis pass� en param�tre
	 * de d�marrage de la JVM (voir
	 * <code>{@link GeneratorManager#COUNTER_PREFIX}</code>)
	 * <li>NNNNNN[NN] id r�cup�r� dans la base � partir de la table foundation.
	 * Il faut utiliser un modulo pour rester dans un nombre compris entre 0 et
	 * 999 999 (ou 99 999 999 si sur 8 chiffres).
	 * </ul>
	 * i.e. LN00293 o�
	 * <ul>
	 * <li>LN00 est le pr�fixe du compteur
	 * <li>293 l'id
	 * </ul>
	 * 
	 * @return pr�fixe + id r�cup�r� dans la base � partir de la table
	 * foundation (i.e. LN00293)
	 */
	private String getCommandeSerialId() {
		String id = serviceManager.getGeneratorManager().generateKey(INDEX_DE_COMMANDE);
		String prefix = GeneratorManager.COUNTER_PREFIX;
		if (prefix == null) {
			prefix = BLANK_STRING;
		}
		// Garde les derniers [10 - longueur du prefix] chiffres de l'id
		// Par exemple si le pr�fixe est LN00 alors les 6 derniers chiffres de
		// l'id (id modulo 10 puissance 6) : 987654321 % 1000000 = 654321
		long longId = Long.parseLong(id.substring(prefix.length()));
		BigInteger big = new BigInteger(TEN_VALUE);
		big = big.pow(10 - prefix.length());
		longId = longId % big.intValue();
		return prefix + longId;
	}

	/**
	 * Retourne une date au format fondation.
	 * 
	 * @param date une date au format dd/MM/yyyy HH:mm:ss
	 * 
	 * @return une date en secondes
	 */
	private Long stringToDate(String date) {
		Long dateInSeconds = null;
		if (date != null) {
			try {
				Date dateTemp = DateUtils.parseDate(date, FORMAT_DATE_HEURE);
				dateInSeconds = DateUtils.getDatabaseDate(dateTemp);
			} catch (ParseException l_ex) {
				// FSC Report G7R5 (pour la fote � vairu s� pas ma fote)
				// throw new ReceptionCdeException(AnomalieConstantes.DATE_INJ, "Erreur sur le format de la date : " + date)
				// V�rue pour contourner IRMA 587
				try {
					Date dateTemp = DateUtils.parseDate(date, FORMAT_DATE_HEURE_ERRONE);
					dateInSeconds = DateUtils.getDatabaseDate(dateTemp);
				} catch (ParseException pe2) {
					throw new ReceptionCdeException(AnomalieConstantes.DATE_INJ, "Erreur sur le format de la date : " + date);
				}
				// Fin Report G7R5
			}
		}
		return dateInSeconds;
	}

	/**
	 * Incr�menter le compteur F_COUNTER.IC_EPC_FUTUR, <br>
	 * Cr�er une variable ID_EPC_Futur telle que :<br>
	 * 1er caract�re = "A" + Code_Instance + cha�ne de 16 caract�res, d'o�
	 * l'algorithme de conversion du compteur (modulo 36^16). <br>
	 * Exemple de calcul : 11111111 est traduit en GWFN9 <br>
	 * 11111111 / 36^5 = 0 reste 11111111 <br>
	 * 11111111 / 36^4 = 6 reste 1033415 <br>
	 * 1033415 / 36^3 = 22 reste 6983 <br>
	 * 6983 / 36^2 = 5 reste 503 <br>
	 * 503 / 36^1 = 13 reste 35 <br>
	 * 0,6,22,13,5,35 donnent AGWFN9 d'apr�s la table de conversion suivante
	 * (0->A, �, 25->Z, 26->0, �, 36->9
	 * 
	 * @return l'identifiant de l'EPC futur
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>13/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1236 Correction d'anomalies trouv�es par FindBugs</TD></TR>
	 * </TABLE>
	 */
	private String calculateIdEPCFutur() {
		String id = serviceManager.getGeneratorManager().generateKey(COUNTER_EPC_FUTUR);
		String prefix = GeneratorManager.COUNTER_PREFIX;
		if (GeneratorManager.COUNTER_PREFIX != null) {
			id = id.substring(prefix.length());
		}
		long value = Long.parseLong(id);
		// R�cup�ration du Code_Instance
		ParametreArtemisDTO paramArtemis = serviceManager.getReferenceSpaceManager().findInReferenceSpaceByVersion(ParametreArtemisDTO.class,
				new Comparaison(ParametreArtemis.FIELD_CLE_PARAMETRE, Constantes.OPERATOR_EQUAL, ConstantesParametreArtemis.CODE_INSTANCE));
		String codeInstance = paramArtemis.getValeurParametre();
		if (codeInstance != null) {
			codeInstance = codeInstance.substring(0, 2).toUpperCase();
		} else {
			codeInstance = BLANK_STRING;
			serviceManager.getLoggerManager().warning(getClass().getName(), "calculateIdEPCFutur",
					"Anomalie remont�e du traitement InjectionCommande : Lors du calcul de l'identifiant de l'EPC futur, le Code_Instance est nul." + "L'identifiant EPC Futur calcul� est donc susceptible de doublonner...");
		}
		// Calcul de la conversion du compteur
		StringBuilder compteurConverti = new StringBuilder(5000);
		for (int i = 6; i > 0; i--) {
			long div = (long) Math.pow(36, i);
			int result = (int) (value / div);
			value = value % div;
			compteurConverti.append(CONV_TABLE[result]);
		}
		compteurConverti.append(CONV_TABLE[(int) value]);
		// concat�nation
		return A_VALUE + codeInstance + compteurConverti.toString();
	}

	/**
	 * Retourne la zone SI de l'instanceSE tel que
	 * <code>InstanceSE.fk_concerneSystemeExterne</code> = � 42C � et
	 * <code>InstanceSE.id</code> =
	 * <code>LocalisationSE.fk_relieInstanceSE</code> et
	 * <code>LocalisationSE.fk_aInstanceLocalisation</code> = l'<code>InstanceLocalisation</code>
	 * donn�e
	 * 
	 * @param instanceLocalisation the instance localisation
	 * 
	 * @return la zone SI de l'instanceSE tel que
	 * <code>InstanceSE.fk_concerneSystemeExterne</code> = � 42C � et
	 * <code>InstanceSE.id</code> =
	 * <code>LocalisationSE.fk_relieInstanceSE</code> et
	 * <code>LocalisationSE.fk_aInstanceLocalisation</code> = l'<code>InstanceLocalisation</code>
	 * donn�e
	 */
	private String getZoneSI(String instanceLocalisation) {
		String zoneSI = null;
		// r�cup�ration des localisationSE telles que fk_aInstanceLocalisation = l'instanceLocalisation donn�e
		List<LocalisationSeDTO> localisationSeDTOs = serviceManager.getReferenceSpaceManager().listInReferenceSpace(LocalisationSeDTO.class, new Comparaison(LocalisationSE.SLINK_A_INSTANCE_LOCALISATION, Constantes.OPERATOR_EQUAL, instanceLocalisation));
		Iterator<LocalisationSeDTO> localisationSEIt = localisationSeDTOs.iterator();
		// parcours de toutes les localisationSE pour r�cuperer les instanceSE
		while (localisationSEIt.hasNext() && (zoneSI == null)) {
			LocalisationSeDTO localisationSEPxy = localisationSEIt.next();
			InstanceSeDTO instanceSeDTO = localisationSEPxy.getInstanceSe();
			if (instanceSeDTO != null) {
				// test sur instanceSE.fk_concerneSystemeExterne
				String systExt = instanceSeDTO.getSystemeExterne().getId();
				if (SystemeExterneConstantes.NUM_42C.equals(systExt)) {
					// r�cup�ration de la zoneSI de l'instanceSE
					zoneSI = instanceSeDTO.getZoneSi().getId();
				}
			}
		}
		return zoneSI;
	}
}
