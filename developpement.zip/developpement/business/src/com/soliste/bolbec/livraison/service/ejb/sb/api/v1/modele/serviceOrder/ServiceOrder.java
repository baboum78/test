package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * Modele Ressource ServiceOrder
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/11/2015</TD><TD>MFA</TD><TD>Initialisation du ServiceOrder</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "serviceOrder")
public class ServiceOrder {

	private String id;
	private String externalId;
	private String jobCase;
	private ServiceOrderStatus state;
	private TaskRef taskRef;
	@XmlElement(name = "orderItem")
	private List<OrderItem> orderItemsList;
	private AppointmentRef appointmentRef;
	private EventCauseRef abortEventCause;
	@XmlElement(name = "note")
	private List<Note> notesList;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the externalId
	 */
	public String getExternalId() {
		return externalId;
	}

	/**
	 * @param externalId the externalId to set
	 */
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	/**
	 * @return the jobCase
	 */
	public String getJobCase() {
		return jobCase;
	}

	/**
	 * @param jobCase the jobCase to set
	 */
	public void setJobCase(String jobCase) {
		this.jobCase = jobCase;
	}

	/**
	 * @return the state
	 */
	public ServiceOrderStatus getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(ServiceOrderStatus state) {
		this.state = state;
	}

	/**
	 * @return the taskRef
	 */
	public TaskRef getTaskRef() {
		return taskRef;
	}

	/**
	 * @param taskRef the taskRef to set
	 */
	public void setTaskRef(TaskRef taskRef) {
		this.taskRef = taskRef;
	}

	/**
	 * @param taskRefId the taskRefId to set
	 */
	public void setTaskRefId(String taskRefId) {
		this.taskRef = new TaskRef();
		this.taskRef.setId(taskRefId);
	}

	/**
	 * @return the orderItemsList
	 */
	public List<OrderItem> getOrderItemsList() {
		return orderItemsList;
	}

	/**
	 * @param orderItemsList the orderItemsList to set
	 */
	public void setOrderItemsList(List<OrderItem> orderItemsList) {
		this.orderItemsList = orderItemsList;
	}

	/**
	 * @return the appointmentRef
	 */
	public AppointmentRef getAppointmentRef() {
		return appointmentRef;
	}

	/**
	 * @param appointmentRef the appointmentRef to set
	 */
	public void setAppointmentRef(AppointmentRef appointmentRef) {
		this.appointmentRef = appointmentRef;
	}

	/**
	 * @return the abortEventCause
	 */
	public EventCauseRef getAbortEventCause() {
		return abortEventCause;
	}

	/**
	 * @param abortEventCause the abortEventCause to set
	 */
	public void setAbortEventCause(EventCauseRef abortEventCause) {
		this.abortEventCause = abortEventCause;
	}

	/**
	 * @return the notesList
	 */
	public List<Note> getNotesList() {
		return notesList;
	}

	/**
	 * @param notesList the notesList to set
	 */
	public void setNotesList(List<Note> notesList) {
		this.notesList = notesList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#equals(java.lang.Object)
	 */
	// EV-469 QC-955 suppression des doublons
	@Override
	public boolean equals(Object o) {
		if (o == this)
			return true;
		if (!(o instanceof ServiceOrder)) {
			return false;
		}
		ServiceOrder so = (ServiceOrder) o;
		return id.equalsIgnoreCase(so.getId());
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#hashCode()
	 */
	// EV-469 QC-955 suppression des doublons
	@Override
	public int hashCode() {
		int result = 469;
		result = 955 * result + id.hashCode();
		return result;
	}
}