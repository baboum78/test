/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur;

import java.io.Serializable;

public class ActivationParam implements Serializable {
	public static final String TYPE_REQUETE_PROCESSUS = "IdProcessus";
	public static final String TYPE_REQUETE_COMMANDE = "IdCommande";

	private final String idRequete;
	private final String activatedBy;
	private final String typeRequete;

	/**
	 * @param a_activatedBy l'identifiant d'activation
	 * @param a_idRequete l'identifiant de la requ�te
	 */
	public ActivationParam(String a_activatedBy, String a_idRequete) {
		this(a_activatedBy, a_idRequete, TYPE_REQUETE_PROCESSUS);
	}

	/**
	 * @param a_activatedBy l'identifiant d'activation
	 * @param a_idRequete l'identifiant de la requ�te
	 * @param a_typeRequete le type de requ�te
	 */
	public ActivationParam(String a_activatedBy, String a_idRequete, String a_typeRequete) {
		activatedBy = a_activatedBy;
		idRequete = a_idRequete;
		typeRequete = a_typeRequete;
	}

	/**
	 * @return Returns the activatedBy.
	 */
	public String getActivatedBy() {
		return activatedBy;
	}

	/**
	 * @return Returns the idRequete.
	 */
	public String getIdRequete() {
		return idRequete;
	}

	/**
	 * @return Returns the typeRequete
	 */
	public String getTypeRequete() {
		return typeRequete;
	}
}
