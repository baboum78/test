/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.commun;

import java.io.Serializable;
import java.util.Map;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackHandler;
import com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackHandlerNextAction;
import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.commun.service.util.jms.QueueHelper;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatCommandeDTO;
import com.soliste.bolbec.livraison.service.scheduler.ArtemisSchedulerException;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.EtatCommandeConstantes;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>23/10/2013</TD><TD>EBA</TD><TD>G9R0C1 : Corrections sonar</TD></TR>
 * </TABLE><BR>
 */

/**
 * Superclasse des injecteurs de messages jms. Cette classe est une
 * impl�mentation du session bean MessageHandlerLocal
 * 
 * @author
 */
public abstract class AbstractMessageHandlerBean implements SessionBean {

	/**
	 * AbstractMessageHandlerBean INVALID_JMS_MESSAGE_CAUSE
	 */
	private static final String INVALID_JMS_MESSAGE_CAUSE = "INVALID_JMS_MESSAGE";
	/**
	 * AbstractMessageHandlerBean TOO_MANY_ROLLBACKS_CAUSE
	 */
	public static final String TOO_MANY_ROLLBACKS_CAUSE = "TOO_MANY_ROLLBACKS";
	/**
	 * Propri�t� qui identifie l'UserId de la log.
	 */
	private static final String REPUBLICATION_QUEUE_CONNECTION_FACTORY_NAME = "jms/republicationQueueConnectionFactory";
	private static final String REPUBLICATION_QUEUE_NAME_JNDI = "jms/republicationQueueJndiName";
	private static final String REPUBLICATION_QUEUE_NAME = "jms/republicationQueue";

	/**
	 * Nom de la classe
	 */
	private static final String CLASS_NAME = AbstractMessageHandlerBean.class.getName();
	protected Context envContext;
	private QueueHelper republicationQueueHelper;
	protected RollbackHandler rollbackHandler = new RollbackHandler();
	protected SessionContext sessionContext;
	private String computedStatisticsInjectorName = computeStatisticsInjectorName();

	/**
	 * 
	 */
	public void ejbActivate() {
		// Ejb.spec.
	}

	/**
	 * Ejb.spec.
	 */
	public void ejbCreate() {
		// Ejb.spec.
	}

	/**
	 * 
	 */
	public void ejbPassivate() {
		// Ejb.spec.
	}

	/**
	 * 
	 */
	public void ejbRemove() {
		// Ejb.spec.
	}

	/**
	 * M�thode impos�e par l'interface <code>MessageHandler</code>.<br>
	 * Contient le traitement g�n�rique d'un recepteur de message JMS.
	 * 
	 * @param message
	 */
	public void onMessage(Message message) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, "onMessage", "Message re�u : " + message);
		RollbackHandlerNextAction nextStep;
		try {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "onMessage", "Appel au RollbackHandler pour conna�tre l'action � effectuer");
			nextStep = rollbackHandler.handleMessage(message);
		} catch (JMSException e) {
			// ne devrait jamais arriver. Dans ce cas, on lance une exception et
			// on
			// rollbacke
			throw new EJBException(e);
		}
		if (nextStep.getCode() == RollbackHandlerNextAction.MESSAGE_MUST_BE_REPUBLISHED) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "onMessage", "Action � effectuer: republication");
			tryRepublishMessage(message, nextStep);
		} else if (nextStep.getCode() == RollbackHandlerNextAction.MESSAGE_MUST_BE_REPUBLISHED_ASYNC) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "onMessage", "Action � effectuer: republication asynchrone");
			tryRepublishMessageAsync(message, nextStep);
		} else if (nextStep.getCode() == RollbackHandlerNextAction.MESSAGE_MUST_BE_REJECTED) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "onMessage", "Action � effectuer: rejet");
			try {
				Serializable msg = getMessageContent(message);
				CommandeDTO commandeDTO = getOrCreateCommande(msg);
				if (commandeDTO != null) {
					commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
					ServiceManager.getInstance().getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
				}
			} catch (InvalidJmsMessageException e) {
				ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "onMessage", "Action � effectuer: rejet");
			}
			tryRejectMessage(message, TOO_MANY_ROLLBACKS_CAUSE, "Le message a atteint son nombre maximum de tentatives de traitement");
		} else if (nextStep.getCode() == RollbackHandlerNextAction.MESSAGE_MUST_BE_HANDLED) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "onMessage", "Action � effectuer: traitement");
			tryProcessMessage(message);
		}
	}

	/**
	 * Traitement sp�cifique du message
	 * 
	 * @param a_message
	 * message � traiter
	 * @throws InvalidJmsMessageException
	 * dans le cas o� le message n'est pas valide
	 */
	public abstract void processMessage(Serializable a_message, CommandeDTO commandeDTO) throws InvalidJmsMessageException;

	/**
	 * 
	 */
	public void setSessionContext(SessionContext sessionContext) {
		this.sessionContext = sessionContext;
		try {
			envContext = (Context) new InitialContext().lookup("java:comp/env");
			republicationQueueHelper = new QueueHelper(REPUBLICATION_QUEUE_CONNECTION_FACTORY_NAME, REPUBLICATION_QUEUE_NAME);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * R�cup�ration du contenu du message. Doit �tre de type
	 * <code>javax.jms.TextMessage</code> ou
	 * <code>javax.jms.ObjectMessage</code>, sinon exception de avec un type
	 * d'anomalie <code>InvalidMessageException.ANO_JMS_TYPE_INCONNU</code>.
	 * 
	 * @param a_message
	 * @return Serializable qui est un String dans le cas d'un
	 * <code>javax.jms.TextMessage</code> et un Object dans le cas
	 * d'un <code>javax.jms.ObjectMessage</code>
	 * @throws InvalidJmsMessageException
	 */
	protected Serializable getMessageContent(Message a_message) throws InvalidJmsMessageException {
		try {
			if (a_message instanceof TextMessage) {
				return ((TextMessage) a_message).getText();
			} else if (a_message instanceof ObjectMessage) {
				return ((ObjectMessage) a_message).getObject();
			} else {
				throw new InvalidJmsMessageException("Ce type de message JMS n'est pas trait�");
			}
		} catch (JMSException a_ex) {
			throw new InvalidJmsMessageException("Exception JMS � la lecture du message", a_ex);
		}
	}

	/**
	 * Retourne le nom de l'injecteur, utilis� pour d�signer l'injecteur dans
	 * les statistiques d'injection. Par d�faut, cette impl�mentation retourne
	 * le nom (sans les packages) de la classe, duquel on ne conserve que ce
	 * qu'il y a avant la sous-cha�ne "MessageHandler" si elle est pr�sente. Les
	 * sous-classes peuvent surcharger cette m�thode pour donner un nom plus
	 * attractif
	 * 
	 * @return le nom de l'injecteur, utilis� pour d�signer l'injecteur dans les
	 * statistiques d'injection. Par d�faut, cette impl�mentation
	 * retourne le nom (sans les packages) de la classe, duquel on ne
	 * conserve que ce qu'il y a avant la sous-cha�ne "MessageHandler"
	 * si elle est pr�sente. Les sous-classes peuvent surcharger cette
	 * m�thode pour donner un nom plus attractif
	 */
	protected String getStatisticsInjectorName() {
		return computedStatisticsInjectorName;
	}

	/**
	 * Initialisation du recepteur. Par d�faut cette m�thode ne fait rien, mais
	 * peut �tre surcharg� par une instance pour faire les initialisations
	 * sp�cifiques au message
	 * 
	 * @param a_message
	 * Contenu du message JMS
	 */
	protected void initReceiver(@SuppressWarnings("unused") Serializable a_message) {
		// par defaut on fait rien
	}

	/**
	 * M�thode abstraite qui doit contenir le traitement sp�cifique du rejet
	 * d'un message. La valeur du param�tre cause peut �tre n'importe quoi.
	 * Cependant, cette classe passera comme valeur de cet argument:
	 * <ul>
	 * <li>la constante TOO_MANY_ROLLBACKS_CAUSE si le nombre maximal de
	 * tentatives de traitement est atteint</li>
	 * <li>la constante INVALID_JMS_MESSAGE_CAUSE si le message est invalide et
	 * ne pourra donc jamais �tre trait�</li>
	 * </ul>
	 * 
	 * @param a_message
	 * Message � rejeter
	 * @param cause
	 * la cause du rejet du message.
	 * @param a_diagnostic
	 * Diagnostic donn� pour le rejet
	 */
	protected abstract void rejectMessage(Message a_message, String cause, String a_diagnostic);

	/**
	 * Republie le message dans sa queue d'origine. Cette impl�mentation par
	 * d�faut recherche utilise la queue d�finie par
	 * java:comp/env/jms/republicationQueue et la connection factory d�finie par
	 * java:comp/env/jms/republicationQueueConnectionFactory
	 * 
	 * @param message
	 * le message � republier
	 * @param nextStep
	 * @throws JMSException
	 * si une erreur JMS survient pendant la republication
	 */
	protected void republishMessage(Message message, RollbackHandlerNextAction nextStep) throws JMSException {
		QueueConnection queueConnection = null;
		try {
			queueConnection = republicationQueueHelper.createConnection();
			QueueSession queueSession = queueConnection.createQueueSession(true, 0);
			Message messageToSend = nextStep.generateRepublicationMessage(queueSession, message);
			QueueSender queueSender = queueSession.createSender(republicationQueueHelper.getQueue());
			queueSender.send(messageToSend);
		} catch (JMSException e) {
			republicationQueueHelper.invalidate();
			throw e;
		} catch (NamingException e) {
			ServiceManager.getInstance().getLoggerManager().severe(getClass().getName(), "republishMessage", "Impossible d'utiliser le QueueHelper", e);
			rollback(e);
		} finally {
			QueueHelper.closeConnection(queueConnection);
		}
	}

	/**
	 * Rollback de la transaction. Le nombre de rollback pour ce message est
	 * incr�ment� et une <code>ProcessException</code> est lanc�e pour
	 * provoquer le rollback.
	 * 
	 * @param a_ex
	 * L'exception qui a provoqu�e le rollback
	 */
	protected void rollback(Throwable a_ex) {
		throw new TechnicalBusinessException("Exception impr�vue", a_ex);
	}

	/**
	 * Tentative de rejet du message. Rollback dans le cas d'une exception. La
	 * valeur du param�tre cause peut �tre n'importe quoi. Cependant, cette
	 * classe passera comme valeur de cet argument:
	 * <ul>
	 * <li>la constante TOO_MANY_ROLLBACKS_CAUSE si le nombre maximal de
	 * tentatives de traitement est atteint</li>
	 * <li>la constante INVALID_JMS_MESSAGE_CAUSE si le message est invalide et
	 * ne pourra donc jamais �tre trait�</li>
	 * </ul>
	 * 
	 * @param a_message
	 * Message � rejeter
	 * @param cause
	 * @param a_diagnostic
	 * Diagnostic donn� pour le rejet
	 */
	protected void tryRejectMessage(Message a_message, String cause, String a_diagnostic) {
		try {
			rejectMessage(a_message, cause, a_diagnostic);
		} catch (Exception a_rejEx) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "tryRejectMessage", "Exception dans le rejet du message, rollback de la transaction", a_rejEx);
			rollback(a_rejEx);
		}
	}

	/**
	 *
	 * @param message
	 * @param nextStep
	 */
	protected void tryRepublishMessage(Message message, RollbackHandlerNextAction nextStep) {
		try {
			republishMessage(message, nextStep);
		} catch (JMSException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "tryRepublishMessage", "Exception dans la republication du message, rollback de la transaction", e);
			rollback(e);
		}
	}

	/**
	 * M�thode pour tenter la republication du message de fa�on asynchrone
	 *
	 * @param message
	 * @param nextStep
	 */
	protected void tryRepublishMessageAsync(Message message, RollbackHandlerNextAction nextStep) {
		try {
			String jmsRepublicationQueueJndiName = (String) envContext.lookup(REPUBLICATION_QUEUE_NAME_JNDI);
			Serializable messageContent = getMessageContent(message);
			Map<String, String> messageProperties = nextStep.generateRepublicationMessageProperties(message, nextStep.getRepublicationCount());

			ServiceManager.getInstance().getArtemisSchedulerManager()
					.scheduleJMSMessage(jmsRepublicationQueueJndiName, messageContent, messageProperties, nextStep.getRepublicationDelay());
		} catch (ArtemisSchedulerException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "tryRepublishMessageAsync", "Exception dans la republication asynchrone du message, rollback de la transaction", e);
			rollback(e);
		} catch (InvalidJmsMessageException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "tryRepublishMessageAsync", "Exception dans la republication asynchrone du message, rollback de la transaction", e);
			rollback(e);
		} catch (JMSException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "tryRepublishMessageAsync", "Exception dans la republication asynchrone du message, rollback de la transaction", e);
			rollback(e);
		} catch (NamingException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "tryRepublishMessageAsync", "Exception dans la republication asynchrone du message, rollback de la transaction", e);
			rollback(e);
		}
	}

	private String computeStatisticsInjectorName() {
		String name = getClass().getName();
		name = name.substring(name.lastIndexOf('.') + 1);
		int index = name.indexOf("MessageHandler");
		if (index > 0) {
			name = name.substring(0, index);
		}
		return name;
	}

	private void tryProcessMessage(Message a_message) {
		CommandeDTO commandeDTO = null;
		try {
			Serializable l_msg = getMessageContent(a_message);
			if (l_msg == null) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "handleMessage", "Le message est vide.");
				// Si le message est vide on ne peut pas le traiter
				return;
			}
			ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, "handleMessage", "Contenu message : \n" + l_msg);
			initReceiver(l_msg);
			commandeDTO = getOrCreateCommande(l_msg);
			processMessage(l_msg, commandeDTO);
		} catch (InvalidJmsMessageException a_ex) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "onMessage", "Erreur sur le message", a_ex);
			if (commandeDTO != null && (commandeDTO.getEtatCommande() == null || !EtatCommandeConstantes.ANOINJ.equals(commandeDTO.getEtatCommande().getId()))) {
				commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
				ServiceManager.getInstance().getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
			}
			tryRejectMessage(a_message, INVALID_JMS_MESSAGE_CAUSE, a_ex.getMessage());
		} catch (TechnicalBusinessException a_ex) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "onMessage", "Exception dans le traitement, rollback de la transaction", a_ex);
			//s'il y a eu une erreur avant l'injection, l'�tat de la commande est � FO_INIT et
			//il faut le modifier � FO_ACOMP, car pour la reinjection on a besoin de cet �tat pour
			//ne pas cr�er � nouveau la commande dans chaque reinjection
			majEtatInit(commandeDTO);
			rollback(a_ex);
		} catch (Exception a_ex) {
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "onMessage", "Exception syst�me, rollback de la transaction", a_ex);
			//s'il y a eu une erreur avant l'injection, l'�tat de la commande est � FO_INIT et
			//il faut le modifier � FO_ACOMP, car pour la reinjection on a besoin de cet �tat pour
			//ne pas cr�er � nouveau la commande dans chaque reinjection
			majEtatInit(commandeDTO);
			rollback(a_ex);
		}
	}

	/**
	 * Appel au m�canisme g�n�rique MG_InitialisationCommandeArtemis � fin de cr�er ou r�cuperer la commande en base d�s qu�elle est re�ue sur l�adaptateur
	 *
	 * @param a_message
	 * message � traiter
	 * @throws InvalidJmsMessageException
	 * dans le cas o� le message n'est pas valide
	 */
	public abstract CommandeDTO getOrCreateCommande(Serializable a_message) throws InvalidJmsMessageException;

	/**
	 * Mettre � jour de l'�tat commande � l'�tat FO_ACOMP
	 * (on utilise une nouvelle transaction pour persister le nouvel �tat, m�me en cas de rollback)
	 *
	 * @param commandeDTO
	 */
	private void majEtatInit(CommandeDTO commandeDTO) {
		if (commandeDTO != null && commandeDTO.getEtatCommande() != null && EtatCommandeConstantes.FO_INIT.equals(commandeDTO.getEtatCommande().getId())) {
			commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.FO_ACOMP));
			ServiceManager.getInstance().getInjectionCommandeManager().updateCommandeEtatWithNewTransaction(commandeDTO);
		}
	}
}