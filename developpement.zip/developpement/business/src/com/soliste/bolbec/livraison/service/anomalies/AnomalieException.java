/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

/**
 * $Workfile:   AnomalieException.java  $
 * $Revision:   1.1  $
 * $Date:   Oct 08 2003 14:10:28  $
 * $Log:   //SRV_BOLBEC/PVCS/00_PVCS_BOLBECG4/archives/developpement/commun/src.lib/bolbec/commun/anomalies/AnomalieException.java-arc  $
 * 
 *    Rev 1.1   Oct 08 2003 14:10:28   cbonnard
 * ajout getSFAno
 * 
 *    Rev 1.0   Oct 08 2003 13:48:20   HBOURDIN
 * Initial revision.
 */

package com.soliste.bolbec.livraison.service.anomalies;

import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Title : AnomalieException
 * Description : Ces exceptions repr�sentent les incidents portant une SFAno
 * Copyright : Copyright (c) 2003
 * Soci�t� : FT - SICoR
 */
public class AnomalieException extends TechnicalBusinessException {

	private SFAno sfAno;

	/**
	 * 
	 * @param a_sfAno
	 */
	public AnomalieException(SFAno a_sfAno) {
		super(a_sfAno.getInfo());
		sfAno = a_sfAno;
	}

	/**
	 * getSfAno
	 * 
	 * @return
	 */
	public SFAno getSfAno() {
		return sfAno;
	}
}
