package com.soliste.bolbec.livraison.service.ejb.sb.processus;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.AvpItemDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;

/**
 * Cette classe regroupe tout ce qui concerne la "v�rue" consistant � utiliser le libell�
 * ou le libell� court pour connaitre le type de la tache. En effet, dans certains cas,
 * la notification s'emm�le les pinceaux avec les versions, et ne trouve pas de
 * CatalogueTache.
 * 
 * FIXME OLD: Classe � supprimer d�s lors o� toutes les taches seront aliment�es correctement
 * c'est-�-dire quand tache.FK_estTypeCatalogueTache ne sera pas vide
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/06/2012</TD><TD>AGR</TD><TD>EV000184 : Achat FTTH, tache manuelle local tech</TD></TR>
 * </TABLE><BR>
 */
public class TacheManuelleLibelleUtil {

	private static final String STRING_AVP = "AVP";

	private static final String COMPLETUDE_ADRESSE_NOM_TRAITEMENT = "CompletudeAdresse";
	private static final String AFFECT_INCOMPLETE_NOM_TRAITEMENT = "AffIncomplete";
	private static final String COMPLETER_CR_NOM_TRAITEMENT = "CompleterCR";
	private static final String COMPLETUDE_CRI_NOM_TRAITEMENT = "CompletudeCRI";
	private static final String MAJ_COM_MAN_NOM_TRAITEMENT = "MAJComMan";
	private static final String SUPPR_DEG_TOT_NOM_TRAITEMENT = "SupprDegTot";
	private static final String TCH_MAN_RES_INTERV_GLOB_NOM_TRAITEMENT = "TchManResIntervGlob";
	private static final String TCH_MAN_NOM_TRAITEMENT = "TchMan";
	private static final String CONTACT_CLI_NOM_TRAITEMENT = "ContactClient";
	private static final String TCH_MAN_RES_INTERV_NOM_TRAITEMENT = "TchManResInterv";
	private static final String TCH_MAN_COMPLETER_CR_NOM_TRAITEMENT = "Tch Man Completer CR";
	private static final String AFFECTATION_INCOMPLETE_NOM_TRAITEMENT = "Affectation Incompl�te";
	private static final String MAJ_COM_NOM_TRAITEMENT = "MAJ Commerciale";
	private static final String COMP_CRI_NOM_TRAITEMENT = "Compl�tude CRI";
	private static final String SUPPRESSION_DEGROUP_TOTAL_NOM_TRAITEMENT = "Suppression D�groupage Total";
	private static final String TCHMAN_INTERV_GLOB_A_PLANIFIER_NOM_TRAITEMENT = "TchMan Interv Glob � planifier";
	private static final String TCH_MAN_COMPLETUDE_ADRESSE_NOM_TRAITEMENT = "Tch Man Compl�tude Adresse";
	private static final String CONTACT_CLIENT_NOM_TRAITEMENT = "Contact Client";
	private static final String RESERVATION_INTERVENTION_NOM_TRAITEMENT = "Reservation Intervetion";
	private static final String MAJ_LOCAL_TECH_NOM_TRAITEMENT = "TchManMajLocalTech";

	private static final Set<String> TACHES_MANUELLES_LIBELLE_COURT;
	private static final Set<String> TACHES_MANUELLES_LIBELLE;

	static {
		Set<String> set = new HashSet<String>();
		set.add(COMPLETER_CR_NOM_TRAITEMENT);
		set.add(COMPLETUDE_CRI_NOM_TRAITEMENT);
		set.add(MAJ_COM_MAN_NOM_TRAITEMENT);
		set.add(SUPPR_DEG_TOT_NOM_TRAITEMENT);
		set.add(TCH_MAN_NOM_TRAITEMENT);

		set.add(AFFECT_INCOMPLETE_NOM_TRAITEMENT);
		set.add(COMPLETUDE_ADRESSE_NOM_TRAITEMENT);
		set.add(TCH_MAN_RES_INTERV_GLOB_NOM_TRAITEMENT);
		TACHES_MANUELLES_LIBELLE_COURT = Collections.unmodifiableSet(set);

		Set<String> setLong = new HashSet<String>();
		setLong.add(AFFECTATION_INCOMPLETE_NOM_TRAITEMENT);
		setLong.add(TCH_MAN_COMPLETER_CR_NOM_TRAITEMENT);
		setLong.add(TCH_MAN_COMPLETUDE_ADRESSE_NOM_TRAITEMENT);
		setLong.add(COMP_CRI_NOM_TRAITEMENT);
		setLong.add(MAJ_COM_NOM_TRAITEMENT);
		setLong.add(SUPPRESSION_DEGROUP_TOTAL_NOM_TRAITEMENT);
		setLong.add(TCHMAN_INTERV_GLOB_A_PLANIFIER_NOM_TRAITEMENT);

		TACHES_MANUELLES_LIBELLE = Collections.unmodifiableSet(setLong);
	}

	/**
	 * Retourne l'itemType pour la tache en utilisant le libell� court, puis le libell� long.
	 * Par d�faut, l'itemType est AvpItemDTO.PHASE_TYPE.
	 * 
	 * @param tache
	 * @return
	 */
	public static int getItemType(TacheDTO tache) {
		int itemType = AvpItemDTO.PHASE_TYPE;
		String libelleCourt = tache.getLibelleCourt();
		if (libelleCourt != null) {
			if (libelleCourt.startsWith(STRING_AVP)) {
				itemType = AvpItemDTO.AVP_TYPE;
			} else {
				if (TACHES_MANUELLES_LIBELLE_COURT.contains(libelleCourt)) {
					itemType = AvpItemDTO.TACHE_MANUELLE_TYPE;
				} else {
					ProcessusDTO pereDirect = tache.getLancerParProcessus();
					if (pereDirect.getGenereParProcessus() != null) {
						itemType = AvpItemDTO.TACHE_ADHOC_TYPE;
					}
				}
			}
		} else {
			String libelle = tache.getLibelle();
			if (libelle != null) {
				if (libelle.startsWith(STRING_AVP)) {
					itemType = AvpItemDTO.AVP_TYPE;
				} else {
					if (TACHES_MANUELLES_LIBELLE.contains(libelle)) {
						itemType = AvpItemDTO.TACHE_MANUELLE_TYPE;
					} else {
						ProcessusDTO pereDirect = tache.getLancerParProcessus();
						if (pereDirect.getGenereParProcessus() != null) {
							itemType = AvpItemDTO.TACHE_ADHOC_TYPE;
						}
					}
				}
			}
		}
		return itemType;
	}

	/**
	 * 
	 * @param tache
	 * @return
	 */
	public static boolean isTypeMajLocalTech(TacheDTO tache) {
		String libelleCourt = tache.getLibelleCourt();
		// on recherche d'abord par le libelle court s'il existe
		if (StringUtils.isNotEmpty(libelleCourt)) {
			return MAJ_LOCAL_TECH_NOM_TRAITEMENT.equals(libelleCourt);
		} else {
			// le libelleCourt de la tache est vide ==> on regarde le libelle
			String libelle = tache.getLibelle();
			return MAJ_LOCAL_TECH_NOM_TRAITEMENT.equals(libelle);
		}
	}

	/**
	 * 
	 * @param tache
	 * @return
	 */
	public static boolean isTypeCompletudeCri(TacheDTO tache) {
		String libelleCourt = tache.getLibelleCourt();
		// on recherche d'abord par le libelle court s'il existe
		if (StringUtils.isNotEmpty(libelleCourt)) {
			return COMPLETUDE_CRI_NOM_TRAITEMENT.equals(libelleCourt);
		} else {
			// le libelleCourt de la tache est vide ==> on regarde le libelle
			String libelle = tache.getLibelle();
			return COMP_CRI_NOM_TRAITEMENT.equals(libelle);
		}
	}

	/**
	 * 
	 * @param tache
	 * @return
	 */
	public static boolean isTypeCompletudeAdresse(TacheDTO tache) {
		String libelleCourt = tache.getLibelleCourt();
		// on recherche d'abord par le libelle court s'il existe
		if (StringUtils.isNotEmpty(libelleCourt)) {
			return COMPLETUDE_ADRESSE_NOM_TRAITEMENT.equals(libelleCourt);
		} else {
			// le libelleCourt de la tache est vide ==> on regarde le libelle
			String libelle = tache.getLibelle();
			return TCH_MAN_COMPLETUDE_ADRESSE_NOM_TRAITEMENT.equals(libelle);
		}
	}

	/**
	 * 
	 * @param tache
	 * @return
	 */
	public static boolean isTypeContactClient(TacheDTO tache) {
		String libelleCourt = tache.getLibelleCourt();
		// on recherche d'abord par le libelle court s'il existe
		if (StringUtils.isNotEmpty(libelleCourt)) {
			return CONTACT_CLI_NOM_TRAITEMENT.equals(libelleCourt);
		} else {
			// le libelleCourt de la tache est vide ==> on regarde le libelle
			String libelle = tache.getLibelle();
			return CONTACT_CLIENT_NOM_TRAITEMENT.equals(libelle);
		}
	}

	/**
	 * 
	 * @param tache
	 * @return
	 */
	public static boolean isTypeReservationIntervention(TacheDTO tache) {
		String libelleCourt = tache.getLibelleCourt();
		// on recherche d'abord par le libelle court s'il existe
		if (StringUtils.isNotEmpty(libelleCourt)) {
			return TCH_MAN_RES_INTERV_NOM_TRAITEMENT.equals(libelleCourt);
		} else {
			// le libelleCourt de la tache est vide ==> on regarde le libelle
			String libelle = tache.getLibelle();
			return RESERVATION_INTERVENTION_NOM_TRAITEMENT.equals(libelle);
		}
	}
}