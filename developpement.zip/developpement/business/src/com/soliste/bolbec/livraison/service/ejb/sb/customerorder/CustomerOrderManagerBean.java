package com.soliste.bolbec.livraison.service.ejb.sb.customerorder;

import java.io.IOException;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import javax.ejb.EJBException;

import org.apache.commons.lang3.StringUtils;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.exception.sw.customerorder.ConstructeurGraficExceptionIOSW;
import com.soliste.bolbec.commun.service.exception.sw.customerorder.GraficTypeFaultEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.Evenement;
import com.soliste.bolbec.livraison.service.anomalies.SFAno;
import com.soliste.bolbec.livraison.service.ejb.sb.api.utils.TaskUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.CloturerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfTache;
import com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements.CustomerOrderTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements.ErdvTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements.FrontalTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements.GraficTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements.InterneTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements.OpusTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.ic.InitialisationCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.ProcessusTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.exception.UnavailableTaskException;
import com.soliste.bolbec.livraison.service.model.CasMetierInjecteDTO;
import com.soliste.bolbec.livraison.service.model.CategorieEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatCommandeDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.RessourceTechDTO;
import com.soliste.bolbec.livraison.service.model.StatutCommandeDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TraductionCatComDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.model.TypeRtDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicInstanceRT;
import com.soliste.bolbec.livraison.service.stepauto.traitements.GestionAttenteDonePartial;
import com.soliste.bolbec.livraison.service.sw.custorder.ConstantesDeliverCustomerOrder;
import com.soliste.bolbec.livraison.service.sw.custorder.DeliverCustomerOrderDataIOSW;
import com.soliste.bolbec.livraison.service.sw.custorder.helper.DeliverCustomerOrderHelperIOSW;
import com.soliste.bolbec.livraison.service.sw.custorder.helper.DeliverCustomerOrderNullHelperIOSW;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.cxf.CXFTools;
import com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil;
import com.orange.bolbec.customerOrderIOSW.services.CancelDeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.services.InformOnCustomerOrderEventFault;
import com.orange.bolbec.customerOrderIOSW.types.cancelCustomerOrder.CancelDeliverCustomerOrderRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.cancelCustomerOrder.CancelDeliverCustomerOrderResponseMessage;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CustomerOrderItemType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.DeliverCustomerOrderRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.DeliverCustomerOrderResponseMessage;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.DeliverCustomerOrderWithLocalisationRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.fault.CancelDeliverCustomerOrderFaultMessage;
import com.orange.bolbec.customerOrderIOSW.types.fault.CustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.fault.DeliverCustomerOrderFaultMessage;
import com.orange.bolbec.customerOrderIOSW.types.fault.FaultDetail;
import com.orange.bolbec.customerOrderIOSW.types.fault.InformOnCustomerOrderEventFaultMessage;
import com.orange.bolbec.customerOrderIOSW.types.informCustomerOrder.InformOnCustomerOrderEventRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.informCustomerOrder.InformOnCustomerOrderEventResponseMessage;
import com.orange.bolbec.customerOrderIOSW.types.informCustomerOrder.InstalledProduct;
import com.orange.bolbec.customerOrderIOSW.types.informCustomerOrder.ProductOrderItem;

import aps.AnomalieConstantes;
import aps.CauseEvenement;
import aps.EtatCommandeConstantes;
import aps.JalonConstantes;
import aps.ProcessusTypeConstantes;
import aps.RessourceTechConstantes;
import aps.StatutCommandeConstantes;
import aps.SystemeExterneConstantes;
import aps.TraductionCatCom;

/**
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>31/12/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210 - Offre BVPN&BI FTTH(TRA-12-12) � Cr�ation de la classe </TD></TR>
 * <TR><TD>16/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Modifs</TD></TR>
 * <TR><TD>24/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Corrections suite � test d'int�gration</TD></TR>
 * <TR><TD>14/02/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Reprise du CancelCustomerOrder suite � FQR 317</TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * <TR><TD>21/10/2013</TD><TD>EBA</TD><TD>G9R0C1 - Suppression des catch Throwable</TD></TR>
 * <TR><TD>10/12/2014</TD><TD>KRA</TD><TD>EV-000320 : G8R2C6 - Effet de bord quarantaine</TD></TR>
 * <TR><TD>28/05/2015</TD><TD>JDE</TD><TD>EV-000315 : G8R2C7 - Commandes SCE</TD></TR>
 * <TR><TD>10/12/2015</TD><TD>JDE</TD><TD>EV-000348 : G9R2C1 - Net commande unique</TD></TR>
 * <TR><TD>15/09/2016</TD><TD>JDE</TD><TD>EV-000377 : G9R2C1 - ROME Offre - Commandes FTTE</TD></TR>
 * <TR><TD>11/10/2017</TD><TD>AJO</TD><TD>EV-000466 : G9R2C1 - Application messages Grafic aux bonnes commandes</TD></TR>
 * <TR><TD>02/07/2018</TD><TD>CDS</TD><TD>QC-984 : Relance automatique d'une commande suite r�ception message InformOnCustomerOrderEvent</TD></TR>
 * <TR><TD>16/05/2019</TD><TD>YNOURI</TD><TD>QC-260 : Rendre l'acceptation des commandes g�n�rique</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQ.5036</TD><TD>Func - EP0143 � G�rer l�abandon des commandes FTTH op�rateur</TD></TR>
 * <TR><TD>REQ.7307</TD><TD>Func - EP0175 - G�rer l'abandon des commandes FTTH Entreprises</TD></TR>
 * </TABLE>
 * 
 * @author ebaali
 * 
 */
public class CustomerOrderManagerBean extends FwkSessionBean implements CustomerOrderManager {

	/**
	 * serial version UID
	 */
	private static final long serialVersionUID = 7218904788314517002L;

	/** The Constant CLASS_NAME. */
	private static final String CLASS_NAME = CustomerOrderManagerBean.class.getName();

	/** Le service manager */
	protected static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	/** Any value in the CasMetierInjecte table **/
	private static final String ANY_CMI_VALUE = "*";
	private static final String INFORM_ON_CUSTOMER_ORDER_EVENT = "informOnCustomerOrderEvent";

	// dans weblogic-ejb-jar.xml
	// On utilise une entr�e JNDI sp�cifique pour l'injection par WS car ils sont appel�s c�t� IHM et de ce c�t� les entr�es JNDI d'injections pointent sur QA.vide
	// On ne peut donc pas utiliser l'entr�e JNDI "queue.ICInjecteur"
	// Dans l'annuaire JNDI IHM (launchlocal_ihm.dat) on fait pointer l'entr�e queue.ICInjecteurWS vers la file alias d'injection qui sera lue uniquement par les JVM auto

	/** Les erreurs remont�es par le WS InformOnCustomerOrder */
	protected static final String CUSTOMER_ORDER_ID_INCONNU = "CustomerOrderID inconnu ou multiple";
	protected static final String ERREUR_TRADUCTION_STATUS_CODE = "Erreur de traduction de statusCode";
	protected static final String ERREUR_TASK_NOT_FOUND = "Erreur : t�che non trouv�e";
	protected static final String ERREUR_TASK_WF_ACTIVITY_NULL = "Erreur : impossible de r�cup�rer les informations relatives � la t�che";
	protected static final String ERREUR_TASK_ALREADY_RESERVED = "Erreur : t�che d�j� r�serv�e";
	protected static final String ERREUR_TASK_CLOSE_EXCEPTION = "Erreur pendant la cl�ture de t�che";
	protected static final String ERREUR_MAL_FORMATE = "Erreur : format de requ�te non support�";

	/** Les erreurs remont�es par le WS CancelDeliverCustomerOrder */
	protected static final String ABANDON_BOLBEC_IMPOSSIBLE = "Abandon Art�mis impossible";
	protected static final String COMMANDE_AVEC_INTERVENTION = "Commande avec intervention";
	protected static final String ERREUR_LIBERATION_GPC = "Erreur de lib�ration dans GPC";
	protected static final String ERREUR_ABANDON_TEMP_IMPOSSIBLE = "Abandon Art�mis temporairement impossible : veuillez r�essayer dans quelques instants.";

	protected static final String PREFIXE_ABANDON = "ABANDON_PAR_";
	protected static final String STRING_UNDERSCORE = "_";
	protected static final String CLE_AGENT_CLORE_AVP_TO = "AGENT-CLORE-AVP-TO";

	protected static List<CasMetierInjecteDTO> casMetierInjecteList = null;

	/** objet constructeur d'exception */
	private final ConstructeurGraficExceptionIOSW constructeurGraficException = new ConstructeurGraficExceptionIOSW();

	/** Objets n�cessaires � la valorisation du casMetier, Emetteur et Statut commande */
	protected DeliverCustomerOrderDataIOSW deliverCustomerOrderData;
	protected String emetteur;

	/**
	 * 
	 * 
	 * 
	 * @param customerOrderWithLocalisation
	 * @return
	 * @throws DeliverCustomerOrderFaultMessage
	 * @throws CustomerOrderFault
	 */
	public DeliverCustomerOrderResponseMessage deliverCustomerOrderWithLocalisation(final DeliverCustomerOrderWithLocalisationRequestMessage customerOrderWithLocalisation) throws DeliverCustomerOrderFault {
		final String methode = "deliverCustomerOrder";
		final DeliverCustomerOrderRequestMessage customerOrder = customerOrderWithLocalisation.getDeliverCustomerOrderRequestMessage();
		final String instanceLocalisation = customerOrderWithLocalisation.getInstanceLocalisation();

		final String refExterne = customerOrder.getCustomerOrderID();
		CommandeDTO commandeDTO = null;
		try {
			//Faire appel au m�canisme g�n�rique MG_InitialisationCommandeArtemis avec la r�f�rence externe
			commandeDTO = InitialisationCommande.getOrCreateCommande(refExterne);
		} catch (Exception e) {
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, "deliverCustomerOrderWithLocalisation", "Erreur cr�ation de la commande " + refExterne, e);
			DeliverCustomerOrderFaultMessage deliverCustomerOrderFaultMessage = (DeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(DeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ErreurInterne, null, refExterne);
			throw new DeliverCustomerOrderFault("", deliverCustomerOrderFaultMessage);
		}

		CustomerOrderTraitement custOrderTraitement;
		try {
			valoriserCasMetierStatutCommandeEtEmetteur(customerOrder);
		} catch (DeliverCustomerOrderFault dcof) {
			commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
			SERVICE_MANAGER.getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
			throw dcof;
		}

		if (SystemeExterneConstantes.GRAFIC.equals(emetteur)) {
			// GRAFIC : VENTE_FTTH
			custOrderTraitement = new GraficTraitement();
		} else if (SystemeExterneConstantes.FRONTAL.equals(emetteur)) {
			// FRONTAL : CR_FTTH, SU_FTTH, MUT_DSLAM
			custOrderTraitement = new FrontalTraitement();
		} else if (SystemeExterneConstantes.NUM_49W.equals(emetteur)) {
			// 49W : COMMANDE INDUITE
			custOrderTraitement = new InterneTraitement();
		} else if (SystemeExterneConstantes.NUM_75B.equals(emetteur)) {
			// 75B : OPUS
			custOrderTraitement = new OpusTraitement(emetteur);
		} else if (SystemeExterneConstantes.NUM_48W.equals(emetteur)) {
			// 48W : eRdv
			custOrderTraitement = new ErdvTraitement(emetteur);
		} else {
			String casMetier = deliverCustomerOrderData.getCasMetier();
			if (casMetier == null) {
				casMetier = "non valoris� dans RG20";
			}
			// Si l'emetteur n'a pas �t� trouv�, une erreur est g�n�r�e.
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, "SOAPValidator", "Emetteur inconnu ou non g�r� par le service pour le cas m�tier : " + casMetier);
			commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
			SERVICE_MANAGER.getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
			DeliverCustomerOrderFaultMessage deliverCustomerOrderFaultMessage = (DeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(DeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ChampObligatoireAbsent, "OfferSpecificationCode", refExterne);
			throw new DeliverCustomerOrderFault("", deliverCustomerOrderFaultMessage);
		}

		try {
			final String xmlMessage = serialiserMessageCustomerOrder(customerOrder);
			SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, methode, "R�ception IC CustomerOrder \"" + refExterne + "\" : " + xmlMessage);
			SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, methode, "Instance Localisation \"" + refExterne + "\" : " + instanceLocalisation);

			// valide le message et construit l'IC Artemis
			String messageAdapte = custOrderTraitement.traiter(customerOrder, deliverCustomerOrderData);

			final HashMap<String, String> mapToInject = new HashMap<String, String>();
			mapToInject.put(Constantes.FIELD_INSTANCE_LOCALISATION, instanceLocalisation);
			mapToInject.put(Constantes.FIELD_MESSAGE, messageAdapte);
			mapToInject.put(Constantes.FIELD_ID_COMMANDE, commandeDTO.getId());

			InjectionCdeUtil.inject(mapToInject);
		} catch (DeliverCustomerOrderFault coe) {
			commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
			SERVICE_MANAGER.getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
			final StringBuilder messageErreur = new StringBuilder(150);
			messageErreur.append("erreur lors de l'adaptation de l'intention de commande ").append(emetteur).append(" : ");
			messageErreur.append(coe.getFaultInfo().getFaultLabel());
			final List<FaultDetail> faultDetail = coe.getFaultInfo().getFaultDetail();
			if (faultDetail != null && !faultDetail.isEmpty()) {
				List<String> errorLabel = faultDetail.get(0).getLocalErrorLabel();
				if (errorLabel != null && !errorLabel.isEmpty()) {
					messageErreur.append(" - ");
					messageErreur.append(errorLabel.get(0));
				}
			}
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, methode, messageErreur.toString(), coe);
			throw coe;
		} catch (Exception t) {
			commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
			SERVICE_MANAGER.getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, "Erreur interne" + " : " + t.getMessage(), t);
			DeliverCustomerOrderFaultMessage deliverCustomerOrderFaultMessage = (DeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(DeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ErreurInterne, null, refExterne);
			throw new DeliverCustomerOrderFault("", deliverCustomerOrderFaultMessage);
		}
		DeliverCustomerOrderResponseMessage deliverCustomerOrderResponseMessage = new DeliverCustomerOrderResponseMessage();
		deliverCustomerOrderResponseMessage.setCustomerOrderID(refExterne);
		return deliverCustomerOrderResponseMessage;
	}

	/**
	 * RG20
	 * valorisation du cas m�tier, du statut de la commande et de l'�metteur
	 * 
	 * @return
	 * @throws DeliverCustomerOrderFault
	 */
	private void valoriserCasMetierStatutCommandeEtEmetteur(final DeliverCustomerOrderRequestMessage customerOrder) throws DeliverCustomerOrderFault {
		emetteur = StringUtils.EMPTY;
		// On cr�e le customerOrderData utile au traitement
		creerCustomerOrderData(customerOrder);
		// On r�alise le traitement
		for (CustomerOrderItemType custOrderItType : customerOrder.getCustomerOrderItem()) {
			if (custOrderItType != null && custOrderItType.getOfferSpecification() != null) {
				// Recherche d'une correspondance de ligne
				CasMetierInjecteDTO cmiCorrespondance = trouverCorrespondanceCasMetierInjecte(custOrderItType, customerOrder);
				// Si on trouve une correspondance on valorise le cas m�tier, le statut et l'emetteur
				if (cmiCorrespondance != null) {
					deliverCustomerOrderData.setCasMetier(cmiCorrespondance.getCasMetier());
					deliverCustomerOrderData.setStatutCommande(cmiCorrespondance.getStatutCommande());
					// Valorisation de l'emetteur, si non pr�sent => 49W
					emetteur = valoriserEmetteur(cmiCorrespondance, customerOrder);
				}
			}
		}

		// Si aucun enregistrement de la table ne correspond � la recherche
		if (deliverCustomerOrderData.getCasMetier() == null) {
			// Une ligne avec le code "contexte"
			if (CustomerOrderTraitement.containsKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CONTEXTE)) {
				// Cas m�tier valoris� avec la valeur du contexte
				deliverCustomerOrderData.setCasMetier(CustomerOrderTraitement.getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CONTEXTE));
				deliverCustomerOrderData.setStatutCommande(StatutCommandeConstantes.NON_MIXTE);
				// L'identifiant �metteur est valoris� avec le champ Local_sender re�u et forc� � � 49W � si vide
				if (customerOrder.getLocalSender() != null) {
					emetteur = customerOrder.getLocalSender().getApplicationCode();
				} else {
					emetteur = SystemeExterneConstantes.NUM_49W_VALEUR_CONSTANTE;
				}
				// Correction de la valeur de l'emetteur
				if (!emetteur.startsWith(Constantes.VERSION_COURANTE)) {
					emetteur = Constantes.VERSION_COURANTE + "_" + emetteur;
				}
			}
		}

		// V�rification de la bonne valorisation du cas m�tier
		if ((deliverCustomerOrderData.getCasMetier() == null || StringUtils.isEmpty(deliverCustomerOrderData.getCasMetier())) && !SystemeExterneConstantes.NUM_48W.equals(emetteur)) {
			throw deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieChampMalFormate("La commande est mal structur�e : impossible de d�terminer le cas m�tier", customerOrder.getCustomerOrderID());
		}
	}

	private String valoriserEmetteur(CasMetierInjecteDTO cmiCorrespondance, DeliverCustomerOrderRequestMessage customerOrder) {
		String localEmetteur = "";
		if (cmiCorrespondance.getEmetteur() != null && !cmiCorrespondance.getEmetteur().isEmpty()) {
			localEmetteur = cmiCorrespondance.getEmetteur();
			if (SystemeExterneConstantes.NUM_75B_VALEUR_CONSTANTE.equals(localEmetteur) || SystemeExterneConstantes.FRONTAL_VALEUR_CONSTANTE.equals(emetteur)) {
				if (customerOrder.getLocalSender() == null) {
					localEmetteur = SystemeExterneConstantes.FRONTAL_VALEUR_CONSTANTE;
				} else {
					localEmetteur = customerOrder.getLocalSender().getApplicationCode();
				}
			}
		} else {
			if (customerOrder.getLocalSender() != null) {
				localEmetteur = customerOrder.getLocalSender().getApplicationCode();
			} else {
				localEmetteur = SystemeExterneConstantes.NUM_49W_VALEUR_CONSTANTE;
			}
		}

		if (localEmetteur.startsWith(Constantes.VERSION_COURANTE)) {
			return localEmetteur;
		}

		return Constantes.VERSION_COURANTE + "_" + localEmetteur;
	}

	protected void creerCustomerOrderData(final DeliverCustomerOrderRequestMessage customerOrder) throws DeliverCustomerOrderFault {
		deliverCustomerOrderData = new DeliverCustomerOrderDataIOSW();
		final DeliverCustomerOrderNullHelperIOSW nullHelper = new DeliverCustomerOrderNullHelperIOSW(customerOrder);
		final DeliverCustomerOrderHelperIOSW helper = new DeliverCustomerOrderHelperIOSW();
		deliverCustomerOrderData.setDeliverCustomerOrderHelper(helper);
		deliverCustomerOrderData.setDeliverCustomerOrderNullHelper(nullHelper);

		// 2.2.3.2 - R�cup�ration des fonctions LC
		List<Map<String, String>> listeFunctionSpecification = CustomerOrderTraitement.recupererFonctionLc(customerOrder, SERVICE_MANAGER.getLoggerManager());
		deliverCustomerOrderData.setFonctionsLc(listeFunctionSpecification);
	}

	/**
	 * RG20
	 * Cherche la correspondance � la commande du client dans la table CasMetierInjecte
	 * 
	 * @param custOrderItType
	 * @return
	 */
	private CasMetierInjecteDTO trouverCorrespondanceCasMetierInjecte(CustomerOrderItemType custOrderItType, final DeliverCustomerOrderRequestMessage customerOrder) {
		String offerSpecifCode = custOrderItType.getOfferSpecification().getOfferSpecificationCode();
		String commandType = customerOrder.getCustomerOrderType();
		String operationType = custOrderItType.getCommercialOperation().getCommercialOperationType();
		String contexte = null;
		// Correspondance sur le contexte
		if (CustomerOrderTraitement.containsKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CONTEXTE)) {
			contexte = CustomerOrderTraitement.getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CONTEXTE);
		}

		return chercherCorrespondancesCasMetierInjecte(offerSpecifCode, commandType, operationType, contexte);
	}

	/**
	 * Fonction qui cherche la correspondance la plus prioritaire suivant la RG20 de FA_Adaptateur_IC_DeliverCustomerOrder
	 * Les cas � ou vaut "*" � de la r�gle de gestion sont les autres collones non v�rifi�s lors de la recherche par un champ en particulier.
	 * 
	 * @param offerSpecifCode
	 * @param commandType
	 * @param operationType
	 * @param contexte
	 * @return
	 */
	protected CasMetierInjecteDTO chercherCorrespondancesCasMetierInjecte(String offerSpecifCode, String commandType, String operationType, String contexte) {
		String method = "chercherCorrespondancesCasMetierInjecte";
		SERVICE_MANAGER.getLoggerManager().info(CustomerOrderManagerBean.class.toString(), method, "Recherche CMI avec offre = " + offerSpecifCode + ", Type Commande = " + commandType + ", typeOper = " + operationType + ", contexte = " + contexte);

		List<CasMetierInjecteDTO> results = getCasMetierInjecteList();
		for (CasMetierInjecteDTO cmiDTO : results) {
			// Suppression des offres qui ne correspondent pas ou ne vallent pas "*"
			if (cmiDTO.getOffre() != null && !cmiDTO.getOffre().equals(offerSpecifCode) && !cmiDTO.getOffre().equals(ANY_CMI_VALUE)) {
				continue;
			}
			// Suppression des types de commande qui ne correspondent pas ou ne vallent pas "*"
			if (cmiDTO.getTypeCommande() != null && !cmiDTO.getTypeCommande().equals(commandType) && !cmiDTO.getTypeCommande().equals(ANY_CMI_VALUE)) {
				continue;
			}
			// Suppression des Types d'op�ration qui ne correspondent pas ou ne vallent pas "*"
			if (cmiDTO.getTypeOper() != null && !cmiDTO.getTypeOper().equals(operationType) && !cmiDTO.getTypeOper().equals(ANY_CMI_VALUE)) {
				continue;
			}
			// Suppression des Contextes d'op�ration qui ne correspondent pas ou ne vallent pas "*"
			if (contexte != null) {
				if (cmiDTO.getContexte() != null && !cmiDTO.getContexte().equals(contexte) && !cmiDTO.getContexte().equals(ANY_CMI_VALUE)) {
					continue;
				}
			}
			SERVICE_MANAGER.getLoggerManager().info(CustomerOrderManagerBean.class.toString(), method, "CMI tout d�fini trouv� : " + results.get(0).toString());
			return cmiDTO;
		}

		// Rien n'a �t� trouv�
		SERVICE_MANAGER.getLoggerManager().severe(CustomerOrderManagerBean.class.toString(), method, "CMI non trouv� !");

		return null;
	}

	protected synchronized static List<CasMetierInjecteDTO> getCasMetierInjecteList() {
		if (casMetierInjecteList != null) {
			return casMetierInjecteList;
		}

		casMetierInjecteList = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(CasMetierInjecteDTO.class);
		Collections.sort(casMetierInjecteList, new Comparator<CasMetierInjecteDTO>() {

			// Comparaison de priorit� selon la RG 20
			// Si "a" est plus prioritaire alors son compte est plus grand et le r�sultat doit �tre n�gatif
			public int compare(CasMetierInjecteDTO a, CasMetierInjecteDTO b) {
				int cntA = compterValeursDefiniesCasMetierInjecte(a);
				int cntB = compterValeursDefiniesCasMetierInjecte(b);
				if (cntA > cntB) {
					return -1;
				} else if (cntA < cntB) {
					return 1;
				} else {
					cntA = 0;
					cntB = 0;
					if (!a.getTypeCommande().equals(ANY_CMI_VALUE)) {
						cntA += 8;
					}
					if (!a.getOffre().equals(ANY_CMI_VALUE)) {
						cntA += 4;
					}
					if (!a.getTypeOper().equals(ANY_CMI_VALUE)) {
						cntA += 2;
					}
					if (!b.getTypeCommande().equals(ANY_CMI_VALUE)) {
						cntB += 8;
					}
					if (!b.getOffre().equals(ANY_CMI_VALUE)) {
						cntB += 4;
					}
					if (!b.getTypeOper().equals(ANY_CMI_VALUE)) {
						cntB += 2;
					}
					return cntB - cntA;
				}
			}

			/**
			 * Compte le nombre de valeurs d�finies dans la ligne CasMetierInjecte
			 * 
			 * @param cmiDTO
			 * @return
			 */
			private int compterValeursDefiniesCasMetierInjecte(CasMetierInjecteDTO cmiDTO) {
				int count = 0;
				if (!cmiDTO.getTypeCommande().equals(ANY_CMI_VALUE)) {
					count += 1;
				}
				if (!cmiDTO.getOffre().equals(ANY_CMI_VALUE)) {
					count += 1;
				}
				if (!cmiDTO.getTypeOper().equals(ANY_CMI_VALUE)) {
					count += 1;
				}
				if (!cmiDTO.getContexte().equals(ANY_CMI_VALUE)) {
					count += 1;
				}
				return count;
			}

		});

		casMetierInjecteList = Collections.unmodifiableList(casMetierInjecteList);

		return casMetierInjecteList;
	}

	/**
	 * S�rialise l'IC CustomerOrder en XML pour validation
	 * 
	 * @param customerOrder l'IC CustomerOrder
	 * @return la repr�sentation XML
	 * @throws CustomerOrderFault
	 */
	protected String serialiserMessageCustomerOrder(final DeliverCustomerOrderRequestMessage customerOrder) throws DeliverCustomerOrderFault {
		final String methode = "deliverCustomerOrderWithLocalisation";
		final String xmlMessage;
		try {
			xmlMessage = CXFTools.getInstance().serialiser(customerOrder, DeliverCustomerOrderRequestMessage.class.getName());
		} catch (IOException e) {
			final StringBuilder messageErreur = new StringBuilder(100);
			messageErreur.append("Erreur lors de la conversion de l'IC CustomerOrder en XML (CustomerId : ");
			messageErreur.append(customerOrder.getCustomerOrderID());
			messageErreur.append(")");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, messageErreur.toString(), e);
			DeliverCustomerOrderFaultMessage deliverCustomerOrderFaultMessage = (DeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(DeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.MessageMalFormate, null, customerOrder.getCustomerOrderID());
			throw new DeliverCustomerOrderFault("", deliverCustomerOrderFaultMessage);
		}
		return xmlMessage;
	}

	/**
	 * Le service InformOnCustomerOrderEvent est appel� afin d�envoyer � Art�mis des informations sur la commande en cours
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.customerorder.CustomerOrderManager#informOnCustomerOrderEvent(InformOnCustomerOrderEventRequestMessage)
	 */
	public InformOnCustomerOrderEventResponseMessage informOnCustomerOrderEvent(final InformOnCustomerOrderEventRequestMessage customerOrder) throws InformOnCustomerOrderEventFault {
		final String methode = INFORM_ON_CUSTOMER_ORDER_EVENT;
		final String customerOrderID = customerOrder.getCustomerOrderID();
		SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, methode, "CustomerOrder en entr�e : " + customerOrderID);

		try {
			// ERG1
			controlerDonneesEnEntree(customerOrder);

			// ERG2
			recupererInfo(customerOrder);

		} catch (InformOnCustomerOrderEventFault e) {
			// les erreurs de type CustomerOrderFault sont renvoy�es telles quelles � l'appelant
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, methode, "Echec lors de la r�ception du message informOnCustomerOrderEvent : " + customerOrderID, e);
			throw e;
		} catch (Exception t) {
			// les autres erreurs sont encapsul�es dans une InternalErrorException
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, "Echec lors de la r�ception du message informOnCustomerOrderEvent : " + customerOrderID, t);
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.ErreurInterne, null, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}

		// ERG3
		SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, INFORM_ON_CUSTOMER_ORDER_EVENT, "Fin du traitement du CustomerOrder : " + customerOrderID);
		return new InformOnCustomerOrderEventResponseMessage();
	}

	/**
	 * WS InformCustomerOrder - ERG1 : Contr�le du bon format des donn�es en entr�e
	 * 
	 * @param customerOrder l'objet r�cup�r� en entr�e du web service InformCustomerOrder
	 * @throws CustomerOrderFault
	 */
	private void controlerDonneesEnEntree(final InformOnCustomerOrderEventRequestMessage customerOrder) throws InformOnCustomerOrderEventFault {
		// RG1 : Contr�le des champs (CustomerOrderID, StatusCode et InstalledProductID
		// Les objets en entr�e ne peuvent �tre null car le xsd "InformOnCustomerOrderEvent_v1" l'emp�che => on ne teste que les chaines vides
		// il existe toujours au moins un customerOrder d'apr�s le xsd => on r�cup�re l'�l�ment "0" sans autre v�rification
		String customerOrderId = customerOrder.getCustomerOrderID();
		String statusCode = customerOrder.getCustomerOrderStatus().getStatusCode();
		String champEnErreur = null;
		String installedProductId = extraireInstalledProductID(customerOrder);
		Calendar date = customerOrder.getCustomerOrderItem().get(0).getActualEffectDate();
		// On teste si un champ est vide alors qu'il n'est pas cens� l'�tre
		if (StringUtils.isBlank(customerOrderId)) {
			champEnErreur = "CustomerOrderId";
		} else if (StringUtils.isBlank(statusCode)) {
			champEnErreur = "statusCode";
		} else if (StringUtils.isBlank(installedProductId)) {
			champEnErreur = "installedProductID";
		} else if (date == null) {
			champEnErreur = "actualEffectDate";
		}

		// Gestion du champ en erreur
		if (champEnErreur != null) {
			StringBuilder msgErreur = new StringBuilder("Le champ '").append(champEnErreur).append("' est mal format�");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, "controlerDonneesEnEntree", msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.MessageMalFormate,
					msgErreur.toString(), null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}
	}

	/**
	 * Extrait InstallProductID
	 * 
	 * @param customerOrder
	 * @return InstallProductID
	 */
	private String extraireInstalledProductID(final InformOnCustomerOrderEventRequestMessage customerOrder) {
		String installedProductId = null;
		List<ProductOrderItem> productItemList = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem();
		if (productItemList != null && !productItemList.isEmpty()) {
			InstalledProduct installedproduct = productItemList.get(0).getInstalledProduct();
			installedProductId = installedproduct != null ? installedproduct.getInstalledProductID() : null;
		}
		return installedProductId;
	}

	/**
	 * WS InformCustomerOrder - RG2 : Contr�le de la r�f�rence commande
	 * 
	 * @param customerOrder l'objet r�cup�r� en entr�e du web service InformCustomerOrder
	 * @throws InformOnCustomerOrderEventFault
	 */
	private CommandeDTO controleReferenceCommande(final InformOnCustomerOrderEventRequestMessage customerOrder) throws InformOnCustomerOrderEventFault {
		CommandeDTO commande = null;
		int nb = 0;
		List<CommandeDTO> commandes = SERVICE_MANAGER.getCommandeManager().findCommandeListByRefExterne(customerOrder.getCustomerOrderID());
		for (CommandeDTO cmd : commandes) {
			if (!Arrays.asList(EtatCommandeConstantes.ANN, EtatCommandeConstantes.TERM, EtatCommandeConstantes.REJ).contains(cmd.getEtatCommande().getId())) {
				commande = cmd;
				nb++;
			}
		}
		if (commande == null || nb > 1) {
			StringBuilder msgErreur = new StringBuilder("La commande ayant la r�f�rence externe '").append(customerOrder.getCustomerOrderID()).append("' n'existe pas dans la base de donn�es Artemis ou est multiple");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, "recupererInfo", msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.ParametresInvalides,
					CUSTOMER_ORDER_ID_INCONNU, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}
		return commande;
	}

	/**
	 * WS InformCustomerOrder - ERG2 : R�cup�ration des informations
	 * 
	 * @param customerOrder l'objet r�cup�r� en entr�e du web service InformCustomerOrder
	 * @throws InformOnCustomerOrderEventFault
	 */
	private void recupererInfo(final InformOnCustomerOrderEventRequestMessage customerOrder) throws InformOnCustomerOrderEventFault {
		// RG2 : Contr�le de la r�f�rence commande
		CommandeDTO commande = controleReferenceCommande(customerOrder);
		// RG3 : R�cup�ration de la date de mise en service
		String processusLivraisonId = null;
		List<ProcessusDTO> listeProcessus = SERVICE_MANAGER.getProcessusManager().findProcessusByCommande(commande.getId());
		for (ProcessusDTO processus : listeProcessus) {
			ProcessusTypeDTO processusType = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, processus.getProcessusType().getId());
			if (ProcessusTypeConstantes.LIVRAISON_VALEUR_CONSTANTE.equals(processusType.getValeurConstante())) {
				processusLivraisonId = processus.getId();
				break;
			}
		}
		if (processusLivraisonId != null) {
			List<InstanceRtDTO> listeInstanceRT = SERVICE_MANAGER.getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processusLivraisonId);

			Calendar date;
			for (InstanceRtDTO instanceRT : listeInstanceRT) {
				RessourceTechDTO rt = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, instanceRT.getRessourceTech().getId());
				TypeRtDTO typeRT = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(TypeRtDTO.class, rt.getTypeRt().getId());

				if (RessourceTechConstantes.JONCO_VALEUR_CONSTANTE.equals(typeRT.getValeurConstante())) {
					// on ne r�cup�re normalement ici qu'une seule Instance RT de type "JONCO"
					date = customerOrder.getCustomerOrderItem().get(0).getActualEffectDate();
					String dateFormatee = DateUtils.format(date.getTime(), DateUtils.ISO_DATETIME_FORMAT_PATTERN, Locale.FRANCE);
					instanceRT.getDynamicInstanceRts().put(ConstantesDynamicInstanceRT.INSTANCERT_DATE_MES, dateFormatee);
					SERVICE_MANAGER.getRessourceTechniqueManager().updateDynamicInstanceRts(instanceRT);
				}
			}
		}

		// RG4 : Traduction du statut
		String statusCode = customerOrder.getCustomerOrderStatus().getStatusCode();
		String valeurArtemisStatusCode = SERVICE_MANAGER.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.GRAFIC, ConstantesTraduction.STATUS_CODE_MINUSCULE, statusCode);
		if (StringUtils.isNotEmpty(valeurArtemisStatusCode)) {
			// Cr�ation du champ dynamique "MES_GRAFIC"
			// on attend la RG5 pour effectuer le commit en base car il peut �tre �cras�
			commande.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_MES_GRAFIC, valeurArtemisStatusCode);
		} else {
			StringBuilder msgErreur = new StringBuilder("La valeur Artemis associ� � la Traduction de la valeur externe '").append(statusCode).append("' n'existe pas dans la base de donn�es Artemis");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, "recupererInfo", msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.ErreurTraduction,
					ERREUR_TRADUCTION_STATUS_CODE, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}

		// RG5 : Contr�le du num�ro VIA
		// V�rifier si la commande trouv�e ci-dessus poss�de une ressource technique de type � CBL_THD �
		if (processusLivraisonId != null) {
			String installedProductId = extraireInstalledProductID(customerOrder);
			boolean instanceRtCblThdTrouvee = false;
			List<InstanceRtDTO> listeInstanceRT = SERVICE_MANAGER.getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processusLivraisonId);
			for (InstanceRtDTO instanceRT : listeInstanceRT) {
				RessourceTechDTO rt = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, instanceRT.getRessourceTech().getId());
				TypeRtDTO typeRT = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(TypeRtDTO.class, rt.getTypeRt().getId());

				if (RessourceTechConstantes.CBL_THD_VALEUR_CONSTANTE.equals(typeRT.getValeurConstante())) {
					if (instanceRT.getIdRt().equals(installedProductId)) {
						instanceRtCblThdTrouvee = true;
						break;
					}
				}
			}
			if (!instanceRtCblThdTrouvee) {
				commande.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_MES_GRAFIC, ConstantesDynamicCommande.VALEUR_ERREUR);
			}
		}

		// ici le dynamique commande "MES_GRAFIC" a potentiellement �t� �cras� (RG5), on peut faire l'update en base
		SERVICE_MANAGER.getCommandeManager().updateDynamicCommande(commande);

		GestionAttenteDonePartial.rechercherAttendu(Constantes.TYPE_EVT_MES, commande.getId(), INFORM_ON_CUSTOMER_ORDER_EVENT);
	}

	/**
	 * cloturerAVP.
	 *
	 * @param idtache the idtache
	 * @param closureCauseEvent the closure cause event
	 * @throws InformOnCustomerOrderEventFault the inform on customer order event fault
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>02/07/2018</TD><TD>CDS</TD><TD>QC-984 : Relance automatique d'une commande suite r�ception message InformOnCustomerOrderEvent</TD></TR>
	 * </TABLE>
	 */
	private void cloturerAVP(CommandeDTO commandeDto, String idtache, String closureCauseEvent) throws InformOnCustomerOrderEventFault {
		// Permet de reserver la t�che.
		final String methode = "cloturerAVP";
		SERVICE_MANAGER.getLoggerManager().fine(CLASS_NAME, methode, " mise a jour de la tache id :" + idtache + " pour la commande la commande id :" + commandeDto.getId());

		TacheDTO tacheDTO = SERVICE_MANAGER.getProcessusManager().getTache(idtache);

		if (tacheDTO == null) {
			StringBuilder msgErreur = new StringBuilder("El�ment introuvable : La tache d'id: ").append(idtache).append(" n'existe pas.");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.ErreurInterne,
					ERREUR_TASK_NOT_FOUND, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}

		// Obtention de l'User et du workflow permettant d'acc�der aux causes ev�nement de la t�che.
		TraductionCatComDTO traductionCatComDto = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(TraductionCatComDTO.class, new Comparaison(TraductionCatCom.FIELD_CLE, Constantes.OPERATOR_EQUAL, CLE_AGENT_CLORE_AVP_TO),
				new Comparaison(TraductionCatCom.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_49W));
		AgentDTO agent = SERVICE_MANAGER.getAgentManager().getAgent(traductionCatComDto.getValeurArtemis());
		WfUser wfU = SERVICE_MANAGER.getWfServices().getWfUser(agent);
		WfActivity wfActivity = SERVICE_MANAGER.getWorkflowManager().getWfActivity(wfU, commandeDto.getId(), idtache);
		if (wfActivity == null) {
			StringBuilder msgErreur = new StringBuilder("El�ment introuvable : Impossible de r�cup�rer les informations relatives � la t�che.");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.ErreurInterne,
					ERREUR_TASK_WF_ACTIVITY_NULL, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}
		WfTache wftache = new WfTache(wfActivity);

		// Initialisation des valeurs WfTache et proprietesWorkflow permettant de cl�turer la t�che.
		Map<String, String> proprietesWorkflow = wfActivity.getValues();

		// Permet de reserver la t�che.
		try {
			SERVICE_MANAGER.getWorkflowManager().reserver(wfActivity, agent.getFullName());
		} catch (UnavailableTaskException e1) {
			StringBuilder msgErreur = new StringBuilder("Une (ou plusieurs) information(s) de la requete est(sont) erron�e(s) : Il n'est pas possible de cl�turer la t�che d'id ").append(idtache).append(" car d�j� r�serv�e par un autre utilisateur.");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.AbandonInterdit,
					ERREUR_TASK_ALREADY_RESERVED, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}

		// Cl�ture de la t�che
		try {
			CloturerAvpCommande commande = TaskUtils.createCommande(proprietesWorkflow, Calendar.getInstance().getTime(), wftache, tacheDTO.getId(), "Relance automatique suite AVP Timeout",
					commandeDto.getVersionArtemis() + STRING_UNDERSCORE + closureCauseEvent, null, null);
			SERVICE_MANAGER.getAvpManager().cloturerAvp(commande, wfU);
		} catch (CloturerAvpException e) {
			SERVICE_MANAGER.getWorkflowManager().liberer(wfActivity);
			StringBuilder msgErreur = new StringBuilder("Erreur pendant la cl�ture de t�che : Erreur pendant la cl�ture de t�che d'id: ").append(idtache);
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.ErreurInterne,
					ERREUR_TASK_CLOSE_EXCEPTION, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		} catch (Exception e1) {
			SERVICE_MANAGER.getWorkflowManager().liberer(wfActivity);
			StringBuilder msgErreur = new StringBuilder("Format de requ�te non support� : Format de requ�te non support� pour une m�thode et une ressource donn�es.");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, msgErreur.toString());
			InformOnCustomerOrderEventFaultMessage informOnCustomerOrderEventFaultMessage = (InformOnCustomerOrderEventFaultMessage) constructeurGraficException.contruireCustomerException(InformOnCustomerOrderEventFaultMessage.class, GraficTypeFaultEnum.MessageMalFormate,
					ERREUR_MAL_FORMATE, null);
			throw new InformOnCustomerOrderEventFault("", informOnCustomerOrderEventFaultMessage);
		}
	}

	/**
	 * Le service CancelDeliverCustomerOrder est appel� afin de demander � Art�mis l�annulation d�une commande en cours
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.customerorder.CustomerOrderManager#cancelDeliverCustomerOrder(CancelDeliverCustomerOrderRequestMessage)
	 */
	public CancelDeliverCustomerOrderResponseMessage cancelDeliverCustomerOrder(final CancelDeliverCustomerOrderRequestMessage customerOrder) throws CancelDeliverCustomerOrderFault {
		final String methode = "cancelDeliverCustomerOrder";
		final String customerOrderID = customerOrder.getCustomerOrderID();
		SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, methode, "CustomerOrder en entr�e : " + customerOrderID);

		try {
			// ERG1 : Contr�le du message re�u
			controlerMsgRecu(customerOrder);

			// ERG2 : R�cup�ration des informations
			CommandeDTO cmd = recupererInfo(customerOrder);

			// ERG3 : Traitement d'abvandon dans Art�mis
			traiterAbandon(customerOrder, cmd);
		} catch (CancelDeliverCustomerOrderFault e) {
			// les erreurs de type CustomerOrderFault sont renvoy�es telles quelles � l'appelant
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, methode, "Echec lors de la r�ception du message cancelDeliverCustomerOrder : " + customerOrderID, e);
			throw e;
		} catch (Exception t) {
			// les autres erreurs sont encapsul�es dans une InternalErrorException
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, methode, "Echec lors de la r�ception du message cancelDeliverCustomerOrder : " + customerOrderID, t);
			CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ErreurInterne, null, customerOrder.getCustomerOrderID());
			throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
		}

		// ERG4 : Acquittement OK vers l'application appelante
		SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, "cancelDeliverCustomerOrder", "Fin du traitement du CustomerOrder : " + customerOrder.getCustomerOrderID());
		CancelDeliverCustomerOrderResponseMessage cancelDeliverCustomerOrderResponseMessage = new CancelDeliverCustomerOrderResponseMessage();
		cancelDeliverCustomerOrderResponseMessage.setCustomerOrderID(customerOrderID);
		return cancelDeliverCustomerOrderResponseMessage;
	}

	/**
	 * WS CancelDeliverCustomerOrder - ERG1 : Contr�le du bon format des donn�es en entr�e
	 * 
	 * @param customerOrder l'objet r�cup�r� en entr�e du web service CancelDeliverCustomerOrder
	 * @throws CustomerOrderFault
	 */
	private void controlerMsgRecu(CancelDeliverCustomerOrderRequestMessage customerOrder) throws CancelDeliverCustomerOrderFault {
		// RG1 : Contr�le des champs (CustomerOrderID, StatusCode et MissingFieldException
		// Les objets en entr�e ne peuvent �tre null car le xsd "InformOnCustomerOrderEvent-IOSW" l'emp�che => on ne teste que les chaines vides
		// il existe toujours au moins un customerOrder d'apr�s le xsd => on r�cup�re l'�l�ment "0" sans autre v�rification
		String customerOrderId = customerOrder.getCustomerOrderID();
		if (StringUtils.isBlank(customerOrderId)) {
			final String msgErreur = "Le champ customerOrderId est absent";
			CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ChampObligatoireAbsent, msgErreur, customerOrder.getCustomerOrderID());
			throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
		}
	}

	/**
	 * WS CancelDeliverCustomerOrder - ERG2 : R�cup�ration des informations
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border' bgcolor=green>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>12/02/2013</TD><TD>EBA</TD><TD>G8R1C2 - EV-000210 - DE-000748 : R�cup�ration de la bonne commande si mixte regroup�e</TD></TR>
	 * </TABLE>
	 * 
	 * @param customerOrder l'objet r�cup�r� en entr�e du web service CancelDeliverCustomerOrder
	 * @throws CustomerOrderFault
	 */
	private CommandeDTO recupererInfo(CancelDeliverCustomerOrderRequestMessage customerOrder) throws CancelDeliverCustomerOrderFault {
		// Contr�le de la r�f�rence commande
		int nb = 0;
		CommandeDTO commande = null;
		List<CommandeDTO> commandes = SERVICE_MANAGER.getCommandeManager().findCommandeListByRefExterne(customerOrder.getCustomerOrderID());
		for (CommandeDTO cmd : commandes) {
			if (StatutCommandeConstantes.MIXTE_THD_REGROUPEE_VALEUR_CONSTANTE.equals(cmd.getStatutCommande().getId())) {
				commande = cmd;
				nb = 1;
				break;
			}

			if (!Arrays.asList(EtatCommandeConstantes.ANN, EtatCommandeConstantes.TERM, EtatCommandeConstantes.REJ).contains(cmd.getEtatCommande().getId())) {
				commande = cmd;
				nb++;

				if (nb > 1) {
					break;
				}
			}
		}

		if (commande != null && nb == 1) {
			StatutCommandeDTO statutCommande = commande.getStatutCommande();
			if (statutCommande != null) {
				String statutCmdId = statutCommande.getId();
				if (StatutCommandeConstantes.MIXTE_THD_REGROUPEE_VALEUR_CONSTANTE.equals(statutCmdId)) {
					// on r�cup�re la commande mixte correspondante
					if (commande.getAPourCmdMixteCommande() != null) {
						commande = commande.getAPourCmdMixteCommande();
					} else {
						StringBuilder msgErreur = new StringBuilder("La commande '").append(customerOrder.getCustomerOrderID()).append("' n'a pas encore de commande mixte.");
						SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, "recupererInfo (cancel)", msgErreur.toString());
						CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ImpossibiliteTemporaire,
								ERREUR_ABANDON_TEMP_IMPOSSIBLE, customerOrder.getCustomerOrderID());
						throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
					}
				}

			}
		} else {
			StringBuilder msgErreur = new StringBuilder("La commande '").append(customerOrder.getCustomerOrderID()).append("' n'existe pas dans la base de donn�es Artemis, n'est pas abandonable � ce stade ou est multiple.");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, "recupererInfo (cancel)", msgErreur.toString());
			CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ParametresInvalides,
					CUSTOMER_ORDER_ID_INCONNU, customerOrder.getCustomerOrderID());
			throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);

		}

		return commande;
	}

	/**
	 * WS CancelDeliverCustomerOrder - ERG3 : Traitement de l'abandon dans Art�mis
	 * 
	 * <U>Validation</U> <BR>
	 * <B>HISTORIQUE DES MODIFICATIONS:</B>
	 * <TABLE frame='border' >
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/02/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210 - DE-000748 : Chargement de l'obj SystemeExterneDTO et generation d'anomalie si evt null</TD></TR>
	 * </TABLE>
	 * <BR>
	 * 
	 * @param customerOrder l'objet r�cup�r� en entr�e du web service CancelDeliverCustomerOrder
	 * @throws CustomerOrderFault
	 */
	private void traiterAbandon(CancelDeliverCustomerOrderRequestMessage customerOrder, CommandeDTO commande) throws CancelDeliverCustomerOrderFault {
		final String nomMethode = "traiterAbandon";
		// R�cup�ration du processus courant
		final ProcessusDTO processus = SERVICE_MANAGER.getProcessusManager().findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(commande.getId());
		if (processus == null) {
			final StringBuilder msgErreur = new StringBuilder("Abandon interdit : Aucun processus en cours pour la commande '").append(customerOrder.getCustomerOrderID()).append("'");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, nomMethode, msgErreur.toString());
			CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.AbandonInterdit,
					ABANDON_BOLBEC_IMPOSSIBLE, customerOrder.getCustomerOrderID());
			throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
		}

		// On contr�le si la commande est en jalon de mise en service technique et poss�de une intervention
		final List<LigneCommandeDTO> listeLC = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(commande.getId());
		final LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(listeLC);
		if ((premiereLC != null) && JalonConstantes.J_MES.equals(premiereLC.getJalon().getId())) {
			final Collection<InterventionDTO> listeIntervention = SERVICE_MANAGER.getInterventionManager().getInterventionsByIdCommande(commande.getId());
			if (!listeIntervention.isEmpty()) {
				final StringBuilder msgErreur = new StringBuilder("Abandon interdit : Commande '").append(customerOrder.getCustomerOrderID()).append("' avec intervention");
				SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, nomMethode, msgErreur.toString());
				CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.AbandonInterdit,
						COMMANDE_AVEC_INTERVENTION, customerOrder.getCustomerOrderID());
				throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
			}
		}

		// Identification de l'emetteur
		SystemeExterneDTO sysExt = commande.getSystemeExterne();
		sysExt = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, sysExt.getId());
		// G�n�ration d'un �v�nement
		CauseEvenementDTO causeEvt = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, new Comparaison(CauseEvenement.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, PREFIXE_ABANDON + sysExt.getValeurConstante()),
				new Comparaison(CauseEvenement.FIELD_VERSION, Constantes.OPERATOR_EQUAL, commande.getVersionArtemis()));

		final Evenement evenement;
		if (causeEvt != null) {
			final TypeEvenementDTO typeEvenement = causeEvt.getTypeEvenement();
			final CategorieEvenementDTO categorieEvt = typeEvenement.getCategorieEvenement();
			String role = null;
			if (causeEvt.getRole() != null) {
				role = causeEvt.getRole().getId();
			}

			evenement = new Evenement();
			evenement.setLibelle("Abandon d'une commande par l'application");
			evenement.setDateGeneration(DateUtils.getDatabaseDate());
			evenement.setIdCauseEvenement(causeEvt.getId());
			evenement.setLibCauseEvenement(causeEvt.getLibelle());
			evenement.setIdTypeEvenement(typeEvenement.getId());
			evenement.setIdCategorieEvenement(categorieEvt.getId());
			evenement.setIdRole(role);
			String agentId = sysExt.getValeurConstante();
			// Pour le systeme externe OPUS, la valeur constante est 75B.
			// Ce code n'est pas connu dans la table des agents qui ne r�f�rence que le nom des applications : Grafic, Sagic, Frontal....
			// On doit donc prendre le nom du systeme externe
			if (SystemeExterneConstantes.NUM_75B_VALEUR_CONSTANTE.equals(agentId)) {
				agentId = sysExt.getNom();
			}
			evenement.setIdAPourOrigineAgent(agentId);
			evenement.setTypeAbd(null);
			if (customerOrder.getCause() != null) {
				evenement.setResponsabiliteId(customerOrder.getCause().value());
			}

		} else {
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, nomMethode, "Impossible de r�cup�rer la causeEvenement abandon pour " + sysExt.getId());
			CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ErreurInterne, null, customerOrder.getCustomerOrderID());
			throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
		}
		// Appel au TRT Prep Abandon
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, nomMethode, "Appel au TRT_PrepAbandon");
		final WfUser wfUser = SERVICE_MANAGER.getWfServices().getWfUser();
		TacheEnCoursDTO tec = CollectionUtils.getFirstOrNull(SERVICE_MANAGER.getProcessusManager().findTacheEnCoursByCommande(commande.getId()));
		SFAno sfAno;
		try {
			sfAno = ProcessusTraitement.preparerAbandon(processus, evenement, false, sysExt.getId(), wfUser, null, tec);
		} catch (EJBException ejbEx) {
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, nomMethode, "Une EJBException a �t� lev�e lors du TRT_PrepAbandon");
			CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.ErreurInterne, null, customerOrder.getCustomerOrderID());
			throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
		}

		// Traitement du retour de l'appel au TRT_PrepAbandon
		if (sfAno != null) {
			if (AnomalieConstantes.LIBINTERV_ANO.equals(sfAno.getErreur())) {
				final StringBuilder msgErreur = new StringBuilder("Erreur de lib�ration dans GPC ");
				SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, nomMethode, msgErreur.toString());
				CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.AbandonInterdit,
						ERREUR_LIBERATION_GPC, customerOrder.getCustomerOrderID());
				throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
			}

			final StringBuilder msgErreur = new StringBuilder("Abandon Artemis impossible");
			SERVICE_MANAGER.getLoggerManager().severe(CLASS_NAME, nomMethode, msgErreur.toString());
			CancelDeliverCustomerOrderFaultMessage cancelDeliverCustomerOrderFaultMessage = (CancelDeliverCustomerOrderFaultMessage) constructeurGraficException.contruireCustomerException(CancelDeliverCustomerOrderFaultMessage.class, GraficTypeFaultEnum.AbandonInterdit,
					ABANDON_BOLBEC_IMPOSSIBLE, customerOrder.getCustomerOrderID());
			throw new CancelDeliverCustomerOrderFault("", cancelDeliverCustomerOrderFaultMessage);
		}

	}

}
