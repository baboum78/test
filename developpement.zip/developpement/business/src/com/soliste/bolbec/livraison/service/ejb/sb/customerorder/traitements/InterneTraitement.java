package com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.sw.custorder.ConstantesDeliverCustomerOrder;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CustomerOrderItemType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.InstalledProduct;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.LocalMarketSegment;

import aps.CasMetierConstantes;
import aps.SystemeExterneConstantes;
import aps.Traduction;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.ParametreType;

/**
 * Classe sp�cifique au traitement interne des IC deliverCustomerOrder
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/12/2014</TD><TD>KRA</TD><TD>G8R2C6 - EV-000320: Cr�ation de la classe</TD></TR>
 * <TR><TD>10/12/2014</TD><TD>KRA</TD><TD>EV-000320 : G8R2C6 - Effet de bord quarantaine</TD></TR>
 * <TR><TD>10/12/2015</TD><TD>JDE</TD><TD>EV-000348 : G9R2C1 - Net commande unique</TD></TR>
 * 
 * @author kRamage
 * 
 */
public class InterneTraitement extends CustomerOrderTraitement {

	/** The Constant CLASS_NAME. */
	private final static String CLASS_NAME = InterneTraitement.class.getName();

	public InterneTraitement() {
		EMETTEUR = SystemeExterneConstantes.NUM_49W;
	}

	@Override
	protected void controleBooleans() throws DeliverCustomerOrderFault {
		// NON UTILISE POUR CE CAS METIER
	}

	/**
	 * Permet de v�rifier les lignes de commandes (suite des contr�les XSD)
	 * RG2 - Validation Java
	 */
	@Override
	protected void verifLigneCommande() throws DeliverCustomerOrderFault {
		// Dans ce cas de gestion, on ne fait rien
	}

	/**
	 * Permet de r�cup�rer la liste des fonctions obligatoires
	 * RG3 - R�cup�ration de la liste des fonctions obligatoires
	 * Pas de contr�le dans le code JAVA, les controlent sont effectu�s c�t�s XSD
	 */
	@Override
	protected Collection<TraductionDTO> recupereFonctionsOblig() {
		return serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.CLE_FUNCTION_IC_INDUIT_OBLIG),
				new Comparaison(Traduction.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, Constantes.CST_OUI), new Comparaison(Traduction.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_49W));
	}

	/**
	 * Permet d'effectuer des controles suppl�mentaires sur la conformit� (contr�les non possible avec le XSD, sp�cifique au cas m�tier)
	 * RG4 - Contr�le sp�cifique
	 */
	@Override
	protected void controlesSpecifiques() throws DeliverCustomerOrderFault {
		// NON UTILISE POUR CE CAS METIER
	}

	/**
	 * Permet de v�rifier les donn�es prestaClip et le debit des fonctions obligatoire
	 * RG3 - R�cup�ration de la liste des fonctions obligatoires
	 */
	@SuppressWarnings("unused")
	@Override
	protected void verifPrestaClipEtDebit(List<Map<String, String>> fonctionsLcTraduites) throws DeliverCustomerOrderFault {
		// NON UTILISE POUR CE CAS METIER
	}

	/**
	 * Permet de r�cup�rer la cat�gorie du client contractant
	 * RG5 - D�termination du client contractant
	 * Copier-Coller de l'algorithme pour le cas m�tier MUTDSLAM
	 */
	@Override
	protected String determineCategorieClientContractant() throws DeliverCustomerOrderFault {
		final String method = "determineCategorieClientContractant";
		final String label = recupererLabelLocalMarketSegmentClientContractant();
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.SEGMENT_MARCHE, label);
		loggerManager.fine(CLASS_NAME, method, "LocalMarketSegmentLabels traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			return label;
		}
		return traduction;
	}

	/**
	 * Permet de r�cup�rer le code client
	 * RG5 - D�termination du client contractant
	 */
	@Override
	protected String determineCodeClient() {
		return customerOrder.getBuyer().getPartyRoleID();
	}

	/**
	 * Permer de r�cup�rer la liste des offres �l�mentaires � partir d'une offre concaten�e
	 * RG6 - D�termination des offres �l�mentaires
	 * Copier-Coller de l'algorithme pour le cas FRONTAL
	 */
	@Override
	protected Map<String, List<ValeurParametreDTO>> recupererListeOffresElementaires() {
		String method = "recupererListeOffresElementaires";
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration de la liste d'offres elementaires");
		Map<String, List<ValeurParametreDTO>> listeOffresElementaires = new LinkedHashMap<String, List<ValeurParametreDTO>>();

		for (CustomerOrderItemType custOrderType : customerOrder.getCustomerOrderItem()) {
			if (custOrderType.getOfferSpecification() != null && custOrderType.getOfferSpecification().getOfferSpecificationCode() != null) {
				String offreVersionne = Constantes.VERSION + "_" + custOrderType.getOfferSpecification().getOfferSpecificationCode();
				listeOffresElementaires.put(offreVersionne, new ArrayList<ValeurParametreDTO>());
			}
		}
		loggerManager.fine(CLASS_NAME, method, "Nombre d'offre elementaires trouv�es : " + listeOffresElementaires.size());
		return listeOffresElementaires;
	}

	@Override
	protected void valorisationChampDynamiqueOsirisOpPonctuelleOrigine(Collection<LigneCommandeType> lignesDeCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	/**
	 * Fixe l'identifiant de commande pour chaque ligne de commande
	 * RG8 - Identifiant de la ligne de commande
	 * Copier-Coller de l'algorithme pour le cas m�tier MUTDSLAM
	 */
	@SuppressWarnings("unused")
	@Override
	protected void fournirIdentifiantLigneDeCommande(Collection<LigneCommandeType> lignesDeCommande, String casMetier) {
		final int PREMIERE_LC_INDEX = 0;

		String method = "fournirIdentifiantLigneDeCommande";
		int i = 1;
		String idLdc = customerOrder.getCustomerOrderItem().get(PREMIERE_LC_INDEX).getCustomerOrderItemID();

		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			String suffixe = i == 1 ? StringUtils.EMPTY : Integer.toString(i);
			ligneDeCommande.setIdLigneCommande(idLdc + suffixe);
			loggerManager.fine(CLASS_NAME, method, "IdLigneCommande cr��e : " + idLdc + suffixe);
			i++;
		}
	}

	/**
	 * Pour chaque ligne de commande, fournit l'acc�s et le type de livraison
	 * RG11 - Acc�s et type de livraison
	 * Copier-Coller de l'algorithme pour le cas FRONTAL
	 */
	@Override
	protected void fournirAccesEtTypeLivraison(Collection<LigneCommandeType> lignesDeCommande) {
		String method = "fournirAccesEtTypeLivraison";

		final InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
		loggerManager.fine(CLASS_NAME, method, "Cas metier MUT_DSLAM, accesLivraison : " + installedProduct + ", typeAccesLivraison : " + ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_ND);
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			ligneDeCommande.setAccesLivraison(installedProduct != null ? installedProduct.getInstalledProductID() : null);
			ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_ND);
		}
	}

	/**
	 * Permet de r�cup�rer la traduction de la cat�gorie du client livr�
	 * RG12 - Cat�gorie client livr�
	 * Copier-Coller de l'algorithme pour le cas FRONTAL
	 */
	@Override
	protected String getTraductionCategorieClientLivre() throws DeliverCustomerOrderFault {
		final String methode = "getTraductionCategorieClientLivre";
		final String label = getLocalMarketSegmentLabelClientLivre();
		loggerManager.fine(CLASS_NAME, methode, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionCatClientInterfVersCatClientLivre(EMETTEUR, label);
		loggerManager.fine(CLASS_NAME, methode, "LocalMarketSegmentLabel traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(label, customerOrder.getCustomerOrderID());
		}
		return traduction;
	}

	/**
	 * Permet de r�cup�rer du label du segment de march� du client livr�
	 * RG12 - Cat�gorie du client livr�
	 * Copier-Coller de l'algorithme pour le cas FRONTAL
	 */
	@Override
	protected String getLocalMarketSegmentLabelClientLivre() {
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return null;
		}
		// On r�cup�re l'index de la ligne de commande possedant le Local_OrganisationName
		final int indexOrganisationName = getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().getIndexOrganisationName();
		final LocalMarketSegment localMarketSegment = customerOrder.getCustomerOrderItem().get(indexOrganisationName).getProductOrderItem().get(0).getUser().get(0).getLocalMarketSegment();
		if (localMarketSegment == null) {
			return null;
		}
		return localMarketSegment.getLabel();
	}

	/**
	 * Permet de cr�er les param�tres PSS pour une fonction LC
	 * RG23 - Valorisation de la Hashmap Element de parc commercial
	 * Copier-Coller de l'algorithme pour le cas FRONTAL
	 */
	@Override
	protected Collection<ParametreType> creerParametresProduitServiceFunctionLc(int i) {
		final Collection<ParametreType> resultat = new ArrayList<ParametreType>();

		final List<Map<String, String>> fonctionsGraficLcLst = getDeliverCustomerOrderData().getFonctionsLc();
		if (fonctionsGraficLcLst.size() > i) {
			ParametreType parametreType;
			StringBuilder cle;
			for (Entry<String, String> fonctionGraficLc : fonctionsGraficLcLst.get(i).entrySet()) {
				parametreType = new ParametreType();
				cle = new StringBuilder(30);
				cle.append(fonctionGraficLc.getKey());
				parametreType.setCle(cle.toString());
				parametreType.setValeur(fonctionGraficLc.getValue());
				resultat.add(parametreType);
			}
		}
		return resultat;
	}

	@Override
	protected Collection<ParametreType> creerParametresHorsFunctionSpecification() {
		return new ArrayList<ParametreType>();
	}

	/**
	 * Fournit � la ligne de commande une intervention et une op�ration programm�e de type InterventionFTTH
	 * RG15- Intervention et param�tres associ�s
	 */
	@SuppressWarnings("unused")
	@Override
	protected void fournirInterventionEtParametresAssocies(Commande commande, Collection<LigneCommandeType> lignesDeCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@SuppressWarnings("unused")
	@Override
	protected void valorisationParametresLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		// TODO REFACTORING A EFFECTUER
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	/**
	 * RG25 - Valorisation du contexte de chaque ligne de commande
	 */
	@Override
	protected void valorisationContexteLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		if (CasMetierConstantes.DENUM_INDUITE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
			for (LigneCommandeType ligneCde : lignesCommande) {
				ligneCde.setRefContexteLivraison(ConstantesDeliverCustomerOrder.SU_ECR_MMPA);
			}
		} else if (CasMetierConstantes.RESIL_PLPA_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
			for (LigneCommandeType ligneCde : lignesCommande) {
				ligneCde.setRefContexteLivraison(ConstantesDeliverCustomerOrder.RESIL_PLPA);
			}
		}
	}

	/**
	 * RG25 - Valorisation des param�tres dynamiques de chaque ligne de commande
	 * Dans le cadre du cas m�tier "D�num�rotation induite", ajout des cl�s "MaintienPort", "CodeOpICNXMaintienPort", "Z0BPQRMaintienPort"
	 */
	@Override
	protected void valorisationChampsDynamiquesLC(Collection<LigneCommandeType> listeLigneDeCommande) {

		String result;

		for (LigneCommandeType ligneCommande : listeLigneDeCommande) {

			// L'indicateur de maintien de la porta
			result = getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.MAINTIEN_PORTA);
			if (StringUtils.isNotEmpty(result)) {
				ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_MAINTIEN_PORTA, result));
			}

			// Le code op�rateur d'interconnexion
			result = getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CODE_OPERATEUR_INTERCO);
			if (StringUtils.isNotEmpty(result)) {
				ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_CODE_OP_INTERCO, result));
			}

			// La valeur du Z0BPQ
			result = getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.ADRESSSE_RATTACHEMENT_ABONNE_PORTE);
			if (StringUtils.isNotEmpty(result)) {
				ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_Z0BPQR, result));
			}
		}

	}
}
