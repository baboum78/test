package com.soliste.bolbec.livraison.service.ejb.sb;

import com.soliste.bolbec.livraison.service.model.CompteRenduDTO;

/**
 * Interface metier de l'ejb <code>CompteRenduSB</code><br/>
 * Permet de rechercher des entit�es li�es � un compte rendu<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * @author kyrw0678
 * 
 */
public interface CompteRenduManager {

	/**
	 * Supprime le compte rendu d'id compteRenduId.
	 * 
	 * @param compteRenduId the compteRendu id
	 */
	void deleteCompteRendu(String compteRenduId);

	/**
	 * R�cup�re le CompteRendu d'id compteRenduId
	 * 
	 * @param compteRenduId the compteRenduId
	 * @return compteRendu
	 */
	public CompteRenduDTO getCompteRendu(String compteRenduId);

	/**
	 * Cr�� ou mets � jour le compte rendu
	 * 
	 * @param compteRendu
	 * @return le compteRendu cr��
	 */
	CompteRenduDTO createCompteRendu(CompteRenduDTO compteRendu);

}
