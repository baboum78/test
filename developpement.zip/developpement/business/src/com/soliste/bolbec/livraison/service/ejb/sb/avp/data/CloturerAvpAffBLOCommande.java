/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;
import java.util.List;

import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;

import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionressourcestechniquesbl.data.Intervention;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;

import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import com.google.common.base.Strings;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs Maj Parc Materiel
 * 
 * @author ntwl4628
 */
public class CloturerAvpAffBLOCommande extends CloturerAvpCommande {

	private String codeInsee;
	private String ville;
	private String codeRivoli;
	private String libelleVoie;
	private String typeVoie;
	private String numeroVoie;
	private String cpltNumVoie;
	private String ensemble;
	private String batiment;
	private String escalier;
	private String etage;
	private String logo;
	private String porte;
	private String activ;
	private String prod;

	private final int NB_PARAM = 15;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param libelleVoie
	 * @param codeRivoli
	 * @param numeroVoie
	 * @param ensemble
	 * @param batiment
	 * @param escalier
	 * @param etage
	 * @param porte
	 * @param logo
	 * @param codeInsee
	 * @param ville
	 * @param typeVoie
	 * @param cpltNumVoie
	 */
	public CloturerAvpAffBLOCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String libelleVoie, String codeRivoli, String numeroVoie, String ensemble, String batiment, String escalier, String etage,
			String porte, String logo, String codeInsee, String ville, String typeVoie, String cpltNumVoie, String activ, String prod) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.libelleVoie = libelleVoie;
		this.codeRivoli = codeRivoli;
		this.numeroVoie = numeroVoie;
		this.ensemble = ensemble;
		this.batiment = batiment;
		this.escalier = escalier;
		this.etage = etage;
		this.porte = porte;
		this.logo = logo;
		this.codeInsee = codeInsee;
		this.ville = ville;
		this.typeVoie = typeVoie;
		this.cpltNumVoie = cpltNumVoie;
		this.activ = activ;
		this.prod = prod;
	}

	public CloturerAvpAffBLOCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String libelleVoie, String codeRivoli, String numeroVoie, String ensemble, String batiment, String escalier, String etage,
			String porte, String logo, String codeInsee, String ville, String typeVoie, String cpltNumVoie) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.libelleVoie = libelleVoie;
		this.codeRivoli = codeRivoli;
		this.numeroVoie = numeroVoie;
		this.ensemble = ensemble;
		this.batiment = batiment;
		this.escalier = escalier;
		this.etage = etage;
		this.porte = porte;
		this.logo = logo;
		this.codeInsee = codeInsee;
		this.ville = ville;
		this.typeVoie = typeVoie;
		this.cpltNumVoie = cpltNumVoie;
	}

	public CloturerAvpAffBLOCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData) {
		super(tacheId, info, causeEvenementId, date, itemData);
	}

	public String getBatiment() {
		return batiment;
	}

	public String getEnsemble() {
		return ensemble;
	}

	public String getEscalier() {
		return escalier;
	}

	public String getEtage() {
		return etage;
	}

	public String getLibelleVoie() {
		return libelleVoie;
	}

	public String getLogo() {
		return logo;
	}

	public String getPorte() {
		return porte;
	}

	public String getCodeInsee() {
		return codeInsee;
	}

	public String getCodeRivoli() {
		return codeRivoli;
	}

	public String getNumeroVoie() {
		return numeroVoie;
	}

	public String getVille() {
		return ville;
	}

	public String getTypeVoie() {
		return typeVoie;
	}

	public String getCpltNumVoie() {
		return cpltNumVoie;
	}

	public String getActiv() {
		return activ;
	}

	public String getProd() {
		return prod;
	}

	public void setCodeInsee(String codeInsee) {
		this.codeInsee = codeInsee;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public void setCodeRivoli(String codeRivoli) {
		this.codeRivoli = codeRivoli;
	}

	public void setLibelleVoie(String libelleVoie) {
		this.libelleVoie = libelleVoie;
	}

	public void setTypeVoie(String typeVoie) {
		this.typeVoie = typeVoie;
	}

	public void setNumeroVoie(String numeroVoie) {
		this.numeroVoie = numeroVoie;
	}

	public void setCpltNumVoie(String cpltNumVoie) {
		this.cpltNumVoie = cpltNumVoie;
	}

	public void setEnsemble(String ensemble) {
		this.ensemble = ensemble;
	}

	public void setBatiment(String batiment) {
		this.batiment = batiment;
	}

	public void setEscalier(String escalier) {
		this.escalier = escalier;
	}

	public void setEtage(String etage) {
		this.etage = etage;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public void setPorte(String porte) {
		this.porte = porte;
	}

	public void setActiv(String activ) {
		this.activ = activ;
	}

	public void setProd(String prod) {
		this.prod = prod;
	}

	public void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande){

		int cpt = 0;

		for (LigneCommandeDTO commandePrecedente : listeLigneCommande) {
			AdresseDTO adresseDTO = commandePrecedente.getClient().getAdresse();

			if(this.getLibelleVoie() == null && adresseDTO.getLibelleVoie() != null){
				this.setLibelleVoie(adresseDTO.getLibelleVoie());
				cpt++;
			}
			if(this.getCodeRivoli() == null && adresseDTO.getCodeRivoli() != null){
				this.setCodeRivoli(adresseDTO.getCodeRivoli());
				cpt++;
			}
			if(this.getNumeroVoie() == null && adresseDTO.getNumeroVoie() != null){
				this.setNumeroVoie(adresseDTO.getNumeroVoie());
				cpt++;
			}
			if(this.getEnsemble() == null && adresseDTO.getEnsemble() != null){
				this.setEnsemble(adresseDTO.getEnsemble());
				cpt++;
			}
			if(this.getEnsemble() == null && adresseDTO.getEnsemble() != null){
				this.setEnsemble(adresseDTO.getEnsemble());
				cpt++;
			}
			if(this.getBatiment() == null && adresseDTO.getBatiment() != null){
				this.setBatiment(adresseDTO.getBatiment());
				cpt++;
			}
			if(this.getEscalier() == null && adresseDTO.getEscalier() != null){
				this.setEscalier(adresseDTO.getEscalier());
				cpt++;
			}
			if(this.getEtage() == null && adresseDTO.getEtage() != null){
				this.setEtage(adresseDTO.getEtage());
				cpt++;
			}
			if(this.getPorte() == null && adresseDTO.getPorte() != null){
				this.setPorte(adresseDTO.getPorte());
				cpt++;
			}
			if(this.getPorte() == null && adresseDTO.getPorte() != null){
				this.setPorte(adresseDTO.getPorte());
				cpt++;
			}
			if(this.getLogo() == null && adresseDTO.getLogo() != null){
				this.setLogo(adresseDTO.getLogo());
				cpt++;
			}
			if(this.getCodeInsee() == null && adresseDTO.getCodeInsee() != null){
				this.setCodeInsee(adresseDTO.getCodeInsee());
				cpt++;
			}
			if(this.getVille() == null && adresseDTO.getVille() != null){
				this.setVille(adresseDTO.getVille());
				cpt++;
			}
			if(this.getTypeVoie() == null && adresseDTO.getTypeVoie() != null){
				this.setTypeVoie(adresseDTO.getTypeVoie());
				cpt++;
			}
			if(this.getCpltNumVoie() == null && adresseDTO.getCpltnumVoie() != null){
				this.setCpltNumVoie(adresseDTO.getCpltnumVoie());
				cpt++;
			}
			List<OpProgrammeeDTO> opProgrammeeDTOList = ServiceManager.getInstance().getCommandeManager().findOpProgrammeByLigneCommande(commandePrecedente.getId());
			if((this.getActiv() == null || this.getProd() == null) && opProgrammeeDTOList.size() > 0){
				for (OpProgrammeeDTO opProgrammeeDTO :opProgrammeeDTOList) {
					InterventionDTO interventionDTO = ServiceManager.getInstance().getCommandeManager().findInterventionByOpProgrammee(opProgrammeeDTO.getId());
					if(this.getActiv() == null){
						this.setActiv(interventionDTO.getDynamicInterventions().get(ConstantesDynamicIntervention.INTERVENTION_ACTIV));
						cpt++;
					}
					if(this.getProd() == null){
						this.setProd(interventionDTO.getDynamicInterventions().get(ConstantesDynamicIntervention.INTERVENTION_PROD));
						cpt++;
					}
				}
			}
		}

		if(dataToSet != null){
			if(dataToSet.getVoie() != null){
				setLibelleVoie(dataToSet.getVoie());
			}
			if(dataToSet.getCodeRivoli() != null){
				setCodeRivoli(dataToSet.getCodeRivoli());
			}
			if(dataToSet.getNumVoie() != null){
				setNumeroVoie(dataToSet.getNumVoie());
			}
			if(dataToSet.getEns() != null){
				setEnsemble(dataToSet.getEns());
			}
			if(dataToSet.getBatiment() != null){
				setBatiment(dataToSet.getBatiment());
			}
			if(dataToSet.getEscalier() != null){
				setEscalier(dataToSet.getEscalier());
			}
			if(dataToSet.getEtage() != null){
				setEtage(dataToSet.getEtage());
			}
			if(dataToSet.getPorte() != null){
				setPorte(dataToSet.getPorte());
			}
			if(dataToSet.getLogo() != null){
				setLogo(dataToSet.getLogo());
			}
			if(dataToSet.getLogo() != null){
				setCodeInsee(dataToSet.getLogo());
			}
			if(dataToSet.getVille() != null){
				setVille(dataToSet.getVille());
			}
			if(dataToSet.getTypeVoie() != null){
				setTypeVoie(dataToSet.getTypeVoie());
			}
			if(dataToSet.getCplVoie() != null){
				setCpltNumVoie(dataToSet.getCplVoie());
			}
			if(dataToSet.getActiv() != null){
				setActiv(dataToSet.getActiv());
			}
			if(dataToSet.getProd() != null){
				setProd(dataToSet.getProd());
			}
		}
	}
}
