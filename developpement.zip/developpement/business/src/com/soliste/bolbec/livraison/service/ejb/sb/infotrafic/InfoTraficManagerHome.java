package com.soliste.bolbec.livraison.service.ejb.sb.infotrafic;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 * Interface home de l'EJB session InfoTraficManagerHome.
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/02/2014</TD><TD>BPE</TD><TD>EV-000276 : G8R2C4 - Mise en place de l'infoTrafic</TD></TR>
 * </TABLE>
 */
public interface InfoTraficManagerHome extends EJBLocalHome {

	/** Permet de cr�er une instance de l'EJB */
	public InfoTraficManager create() throws CreateException;

}
