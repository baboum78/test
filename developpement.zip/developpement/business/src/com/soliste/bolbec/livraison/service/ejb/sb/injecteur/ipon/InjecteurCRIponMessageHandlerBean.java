/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ipon;

import java.io.IOException;
import java.io.Serializable;
import java.util.Vector;

import org.apache.soap.Envelope;
import org.apache.soap.Header;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesblo.ConstantesIPON;

/**
 * @author PQTV8886
 */
public class InjecteurCRIponMessageHandlerBean extends AbstractInjecteurMessageHandlerBean implements ConstantesIPON {

	private static final String UNDERSCORE_STRING = "_";

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable message) throws InvalidMessageException {
		Envelope envelope;
		try {
			envelope = XmlUtils.getMessageEnvelope((String) message);
		} catch (SAXException saxe) {
			throw new InvalidMessageException("SAXException pour recuperer l'enveloppe SOAP", message, saxe);
		} catch (IOException ioe) {
			throw new InvalidMessageException("IOException pour recuperer l'enveloppe SOAP", message, ioe);
		}
		ActivationParam ap = getActivationParam(envelope);
		return ap;
	}

	/**
	 * getActivationParam
	 * 
	 * @param envelope
	 * Envelope
	 * @return String
	 * @throws InvalidMessageException
	 */
	private ActivationParam getActivationParam(Envelope envelope) throws InvalidMessageException {
		// Affecter
		ActivationParam ap = null;
		String messageId = null;
		Element element;
		// R�cup�ration de l'identifiant du message
		Header header = envelope.getHeader();
		@SuppressWarnings("unchecked")
		Vector<Element> headerEntries = header.getHeaderEntries();
		for (int l_i = 0; l_i < headerEntries.size(); l_i++) {
			element = headerEntries.elementAt(l_i);
			if (element.getTagName().equals(TAG_RELATES_TO)) {
				Node node = element.getFirstChild();
				messageId = node.getNodeValue();
				break;
			}
		}

		// Le TAG RelatesTo indique la r�f�rence qui avait �t� envoy�e � Ipon par Artemis lors de la demande
		// Voici un exemple de Tag : LY_G7R0_Ln15882234_CreateDossierRFSCreation
		// La partie pr�c�dant le dernier '_' correspond � l'id de la requ�te, et la partie suivante correspond au nom du service
		// c'est pourquoi il faut d�couper le TAG pour collecter ces 2 informations permettant de constituer l'objet ActivationParam
		if (messageId != null && messageId.indexOf(UNDERSCORE_STRING) != -1) {
			String idRequete = messageId.substring(0, messageId.lastIndexOf(UNDERSCORE_STRING));
			String sf = messageId.substring(messageId.lastIndexOf(UNDERSCORE_STRING) + 1);
			ap = new ActivationParam(sf, idRequete);
		} else {
			throw new InvalidMessageException("Message invalide, tag " + TAG_RELATES_TO);
		}
		return ap;
	}

}