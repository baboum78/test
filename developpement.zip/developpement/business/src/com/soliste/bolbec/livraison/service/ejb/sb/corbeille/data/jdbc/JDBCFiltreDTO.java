/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import java.util.List;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCCondition;

/**
 * Facade pour les filtres corbeille JDBC
 * 
 * @author gdzd8490
 * 
 */
public class JDBCFiltreDTO extends FiltreDTO {

	/** List de JDBCCondition */
	private List<JDBCCondition> filter;

	/**
	 * Constructeur
	 * 
	 * @param filter
	 */
	public JDBCFiltreDTO(List<JDBCCondition> filter) {
		this.filter = filter;
	}

	/**
	 * Renvoie le filtre JDBC
	 * 
	 * @return le filtre JDBC
	 */
	public List<JDBCCondition> getFilter() {
		return filter;
	}

}