/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.exception;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Exception indiquant qu'un AVP n'a pu �tre diff�r�
 * 
 * @author rgvs7490
 */
public class DiffererAvpException extends MessageException {

	private static final String MESSAGE_KEY = "DiffererAvp.error.exception";

	/**
	 * 
	 */
	public DiffererAvpException() {
		super(MESSAGE_KEY);
	}
}
