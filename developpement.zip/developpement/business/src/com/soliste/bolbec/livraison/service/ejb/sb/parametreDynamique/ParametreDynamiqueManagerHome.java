package com.soliste.bolbec.livraison.service.ejb.sb.parametreDynamique;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 * Interface home de l'EJB session ParametreDynamiqueManager
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/01/2012</TD><TD>GPA</TD><TD>EV-000168: Cr�ation de l'interface</TD></TR>
 * </TABLE>
 */
public interface ParametreDynamiqueManagerHome extends EJBLocalHome {

	/** Permet de cr�er une instance de l'EJB */
	public ParametreDynamiqueManagerLocal create() throws CreateException;

}
