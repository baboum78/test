package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.gpc;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.commun.gestionintervention.data.GpcDeclarations;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatInterventionDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LienOpProgLdcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.RapportInterventionDTO;
import com.soliste.bolbec.livraison.service.model.ResponsabiliteDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TypeOpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicRapportIntervention;
import com.soliste.bolbec.livraison.service.stepauto.traitements.DelegueIntervention;
import com.soliste.bolbec.livraison.service.stepauto.traitements.GestionAttenteDonePartial;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.EtatCommandeConstantes;
import aps.EtatInterventionConstantes;
import aps.ResponsabiliteConstantes;
import aps.TypeOpProgrammeeConstantes;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/12/2010</TD><TD> </TD><TD>Creation de la classe pour le traitement des lignes d'intervention re�ues du routeur</TD></TR>
 * </TABLE><BR>
 */
public class InjecteurGPCNotificationInterventionMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {
	private static final IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();
	private static final String CLASS_NAME = InjecteurGPCNotificationInterventionMessageHandlerBean.class.getName();
	private static final String CONSTANTE_IT = "IT";
	private static final String DONNEES_INTERVENTION = "DONNEES_INTERVENTION";
	//Donn�es re�ues du message
	private DonneesIntervention donneesIntervention;

	@Override
	public ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException {
		String idRequete = StringUtils.EMPTY;
		if (StringUtils.isNotBlank(donneesIntervention.getIdCommande())) {
			CommandeDTO commandeDTO = SERVICE_MANAGER.getCommandeManager().findCommandeById(donneesIntervention.getIdCommande());
			List<TacheEnCoursDTO> tecs = SERVICE_MANAGER.getProcessusManager().findTacheEnCoursByCommande(commandeDTO.getId());
			TacheEnCoursDTO tec = CollectionUtils.getFirstOrNull(tecs);
			if (tec != null) {
				ProcessusDTO processusDTO = SERVICE_MANAGER.getProcessusManager().findProcessusByTacheId(tec.getId());
				String localisation = SERVICE_MANAGER.getLocalisationManager().getLocalisation(processusDTO.getId());
				idRequete = localisation + "_" + commandeDTO.getVersionArtemis() + "_" + processusDTO.getId();
			}
		}
		return new ActivationParam(DONNEES_INTERVENTION, idRequete, ActivationParam.TYPE_REQUETE_PROCESSUS);
	}

	/**
	 * Gestion du message re�u du routeur avec les donn�es d'une intervention
	 *
	 * @param message
	 * @throws RemoteException
	 * @throws Exception
	 */
	@Override
	public void processRequest(Serializable message) throws RemoteException, Exception {
		String method = "processRequest";
		SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Traitement du message : " + message);

		String donnesMessage = (String) message;
		donneesIntervention = new DonneesIntervention(donnesMessage);

		String ndClip = donneesIntervention.getNdOuPrestClip();
		Long dateDebut = formatDate(donneesIntervention.getDateDebut()+donneesIntervention.getHeureDebut()); // input au format dd/MM/yyyyHH:mm
		int dureeMinutes = formatDuree(donneesIntervention.getDuree()); // input au format HHmm (ou Hmm?)
		Date debutPlage = (new Date (dateDebut));	// INTERVENTION.DebutPlage = DateDebut + HeureDebut
		Date finPlage = org.apache.commons.lang3.time.DateUtils.addMinutes(debutPlage, dureeMinutes); // INTERVENTION.FinPlage = DateDebut + HeureDebut + Duree

		if (ndClip != null) {
			// Recuperation de la liste de commande associe au ND
			List<CommandeDTO> listCommandes = SERVICE_MANAGER.getCommandeManager().findCommandeByAccesLivraisonAndTypeAccesLivraison(ndClip, Constantes.TYPEACCES_PRESTACLIP);
			if (!org.springframework.util.CollectionUtils.isEmpty(listCommandes)) {
				// Pour chaque commande de la liste
				for (CommandeDTO commande : listCommandes) {
					SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Commande trouv�e pour le message en cours. Id commande : " + commande.getId());
					donneesIntervention.setIdCommande(commande.getId());
					// Verification que la commande n'est pas annulee ou terminee
					String etatCommande = commande.getEtatCommande().getId();
					if (!EtatCommandeConstantes.TERM.equals(etatCommande) && !EtatCommandeConstantes.ANN.equals(etatCommande)) {
						// Recuperation de l'intervention
						List<InterventionDTO> interventionList = SERVICE_MANAGER.getInterventionManager().recupererListeInterventionsLesPlusRecentesParLigneCommande(commande);
						InterventionDTO interventionExistante = null;
						InterventionDTO nouvelleIntervention = null;
						if (!interventionList.isEmpty()) {
							for (InterventionDTO intervention : interventionList) {
								String etatIntervention = intervention.getEtatIntervention().getId();
								SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Intervention trouv�e pour le message et la commande en cours. Traitement de l'intervention : " + intervention.getId());
								if (EtatInterventionConstantes.ARESERV.equals(etatIntervention)) {
									// Maj Dates
									majDateDebutEtFin(intervention, debutPlage, finPlage);
									// Maj Dynamic Intervention
									majDynamicIntervention(donneesIntervention, intervention);
									// MAJ des references
									intervention.setReference(donneesIntervention.getRefInt());
									intervention.setRefExterne(donneesIntervention.getNumInt());
									// Pas de MAJ Etat
									SERVICE_MANAGER.getCommandeManager().updateIntervention(intervention);
								} // si les reference en BDD et celle de la notification sont coherente, rien a faire
								else if (donneesIntervention.getRefInt().equals(intervention.getReference()) && donneesIntervention.getNumInt().equals(intervention.getRefExterne())) {
									// pas de MAJ
								} // Si la dateDebut + heureDebut de la notification > debutPlage de la BDD)
								else if (!CONSTANTE_IT.equals(donneesIntervention.getEtat()) || (intervention.getDebutPlage() != null && debutPlage.getTime() > intervention.getDebutPlage().getTime())) {
									// Creation de l'intervention sur la base de celle d�j� pr�sente, a laquelle on ajoute les nouveau �l�ments de la notification
									nouvelleIntervention = new DelegueIntervention().creerIntervFille(intervention, null);
									// Maj Dates
									majDateDebutEtFin(nouvelleIntervention, debutPlage, finPlage);
									// Maj Dynamic Intervention
									majDynamicIntervention(donneesIntervention, nouvelleIntervention);
									// Maj references
									nouvelleIntervention.setRefExterne(donneesIntervention.getNumInt());
									nouvelleIntervention.setReference(donneesIntervention.getRefInt());
									nouvelleIntervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.RESERV));
									nouvelleIntervention.setResponsabilite(new ResponsabiliteDTO(ResponsabiliteConstantes.INITIATIVE_EXTERIEURE));
									SERVICE_MANAGER.getCommandeManager().updateIntervention(nouvelleIntervention);

									// Maj de l'etat : Pour l�ancien intervention, RG 1
									if (EtatInterventionConstantes.RESERV.equals(etatIntervention)) {
										// Etat intervention (champ fk_estdansetatintervention) = � KO �
										intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.KO));
										SERVICE_MANAGER.getCommandeManager().updateInterventionEtat(intervention);
									}
								}
								interventionExistante = intervention;
							}
						} else {
							SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Aucune intervention trouv�e pour le message et la commande en cours : " + commande.getId());
							// Recuperation des lignes de commande li�es � la commande
							List<LigneCommandeDTO> ligneCommandList = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(commande.getId());
							if (!org.springframework.util.CollectionUtils.isEmpty(ligneCommandList)) {
								for (LigneCommandeDTO ligneCommande : ligneCommandList) {
									SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Cr�ation d'une intervention rattach�e � la ligne commande : " + ligneCommande.getId());
									// Creation d'une nouvelle intervention
									nouvelleIntervention = new InterventionDTO(SERVICE_MANAGER.getGeneratorManager().generateKey());
									// Maj Dates
									majDateDebutEtFin(nouvelleIntervention, debutPlage, finPlage);
									// Maj Dynamic Intervention
									majDynamicIntervention(donneesIntervention, nouvelleIntervention);
									// Maj references
									nouvelleIntervention.setRefExterne(donneesIntervention.getNumInt());
									nouvelleIntervention.setReference(donneesIntervention.getRefInt());
									// Maj Etat
									nouvelleIntervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.ARESERV));
									// Maj responsabilite
									nouvelleIntervention.setResponsabilite(new ResponsabiliteDTO(ResponsabiliteConstantes.INITIATIVE_EXTERIEURE));

									// Pour rattacher une intervention a une ligne de commande (et donc une commande)
									// il faut cr�er le LienOpProgLdc et l'OpProgrammee qui se rattachent � la nouvelle intervention
									OpProgrammeeDTO opProgrammee = new OpProgrammeeDTO(SERVICE_MANAGER.getGeneratorManager().generateKey());
									opProgrammee.setIntervention(new InterventionDTO(nouvelleIntervention.getId()));
									opProgrammee.setTypeOpProgrammee(new TypeOpProgrammeeDTO(TypeOpProgrammeeConstantes.INTERV_GLOBALE));

									LienOpProgLdcDTO lienOpProgrammee = new LienOpProgLdcDTO(SERVICE_MANAGER.getGeneratorManager().generateKey());
									lienOpProgrammee.setLigneCommande(ligneCommande);
									lienOpProgrammee.setOpProgrammee(opProgrammee);

									SERVICE_MANAGER.getCommandeManager().createIntervention(nouvelleIntervention);
									SERVICE_MANAGER.getCommandeManager().createOpProgrammee(opProgrammee);
									SERVICE_MANAGER.getCommandeManager().createLienOpProgLdc(lienOpProgrammee);
								}
							} else {
								SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Aucune ligne de commande trouv�e pour la commande : " + commande.getId());
							}
						}

						InterventionDTO interventionAModifier = interventionExistante;
						if (nouvelleIntervention != null) {
							interventionAModifier = nouvelleIntervention;
						}

						String etatIntervention = interventionAModifier.getEtatIntervention().getId();
						if (donneesIntervention.getRefInt().equals(interventionAModifier.getReference()) && donneesIntervention.getNumInt().equals(interventionAModifier.getRefExterne())
								&& !EtatInterventionConstantes.TERM.equals(etatIntervention) && !EtatInterventionConstantes.KO.equals(etatIntervention)) {
							// Si on a un CRINT dans la notification et un rapport d'intervention non encore rattach� au CRINT
							if (CONSTANTE_IT.equals(donneesIntervention.getEtat()) && donneesIntervention.getCrInt() != null && interventionAModifier.getRapportIntervention() == null) {
								// Cr�ation d'un Rapport d'intervention avec le parametre dynamique CRINT de la notification
								Map<String, String> dynamicRapportIntervention = new HashMap<String, String>();
								dynamicRapportIntervention.put(ConstantesDynamicRapportIntervention.RAPPORTINTERVENTION_CRINT, donneesIntervention.getCrInt());
								RapportInterventionDTO rapportInterventionDTO = new RapportInterventionDTO(SERVICE_MANAGER.getGeneratorManager().generateKey());
								rapportInterventionDTO.setDynamicRapportInterventions(dynamicRapportIntervention);
								SERVICE_MANAGER.getCommandeManager().createRapportIntervention(rapportInterventionDTO, interventionAModifier.getId());
								interventionAModifier.setRapportIntervention(rapportInterventionDTO);
								SERVICE_MANAGER.getCommandeManager().updateInterventionEtatEtRapport(interventionAModifier);
							}

							// Si l'etat est different de "IT" dans la notification on force l'�tat de l'intervention � RESERV
							if (!CONSTANTE_IT.equals(donneesIntervention.getEtat())) {
								// Mise � jour de l'etat de l'intervention � � RESERV �
								interventionAModifier.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.RESERV));
								SERVICE_MANAGER.getCommandeManager().updateInterventionEtat(interventionAModifier);
							} else {
								String etatTraduit = SERVICE_MANAGER.getTraductionManager().getTraductionInterfVersArtemis(GpcDeclarations.TRADUCTION_SYSTEME_EXTERNE, ConstantesTraduction.INTERVENTION_REUSSIE, donneesIntervention.getCrInt());
								if (StringUtils.isBlank(etatTraduit)) {
									interventionAModifier.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.KO));
									SERVICE_MANAGER.getCommandeManager().updateInterventionEtat(interventionAModifier);
								} else {
									interventionAModifier.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.TERM));
									SERVICE_MANAGER.getCommandeManager().updateInterventionEtat(interventionAModifier);
								}
							}
						}

						// Si une commande est en attente de la MAJ intervention ou du rapport d'intervention, on d�clenche la t�che pour mettre fin � l'attente (m�canisme ATTENDU)
						GestionAttenteDonePartial.rechercherAttendu(Constantes.TYPE_EVT_BLO_NON_SUP, ndClip, Constantes.CR_FLUX_PEPSAR);
					}
				}
			} else {
				SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "ATTENTION Aucune commande lie au ND : " + ndClip);
			}
		}
	}

	private void majDateDebutEtFin (InterventionDTO intervention, Date debutPlage, Date finPlage) {
		// Maj des dates
		intervention.setFinPlage(finPlage);
		intervention.setDebutPlage(debutPlage);
	}

	private void majDynamicIntervention(DonneesIntervention donneesIntervention, InterventionDTO intervention) {
		// MAJ Dynamic Intervention
		Map<String, String> dynamicIntervention = intervention.getDynamicInterventions();
		dynamicIntervention.put(ConstantesDynamicIntervention.INTERVENTION_UI, donneesIntervention.getCodeUI());
		dynamicIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ACTIV, donneesIntervention.getActivite());
		dynamicIntervention.put(ConstantesDynamicIntervention.INTERVENTION_PROD, donneesIntervention.getProduit());
		dynamicIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CENTRE, donneesIntervention.getCentre());
		dynamicIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ZONE, donneesIntervention.getZone());
		intervention.setDynamicInterventions(dynamicIntervention);
	}

	private Long formatDate(String sDate) {
		SimpleDateFormat df = new SimpleDateFormat("dd/MM/yyyyHH:mm");
		Date dDate = new Date();
		try {
			dDate = df.parse(sDate);
		} catch (ParseException e) {
			SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, "formatDate", "Echec formatage date souhait�e :" + e);
		}
		return dDate.getTime();
	}

	private int formatDuree(String sDuree) {
		String sDureeHHmm = sDuree;
		int minutes = 0;
		if (sDuree.length() == 3) {
			sDureeHHmm = "0" + sDuree;
		}
		if (sDureeHHmm.length() == 4) {
			minutes = DateUtils.getNbMinutesHHmm(sDureeHHmm);
		}
		return minutes;
	}

}

