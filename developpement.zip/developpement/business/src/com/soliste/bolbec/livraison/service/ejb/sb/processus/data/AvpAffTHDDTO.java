/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Les infos d'AVP pour les AVP de type "AvpAffTHD"
 * 
 */
public class AvpAffTHDDTO extends AvpInfoDTO {

	private String oltName;
	private String oltShelf;
	private String oltCard;
	private String oltPort;

	/**
	 * 
	 */
	AvpAffTHDDTO() {
	}

	public String getType() {
		return AVP_AFF_THD;
	}

	/**
	 * @return the oltName
	 */
	public String getOltName() {
		return oltName;
	}

	/**
	 * @param oltName the oltName to set
	 */
	public void setOltName(String oltName) {
		this.oltName = oltName;
	}

	/**
	 * @return the oltShelf
	 */
	public String getOltShelf() {
		return oltShelf;
	}

	/**
	 * @param oltShelf the oltShelf to set
	 */
	public void setOltShelf(String oltShelf) {
		this.oltShelf = oltShelf;
	}

	/**
	 * @return the oltCard
	 */
	public String getOltCard() {
		return oltCard;
	}

	/**
	 * @param oltCard the oltCard to set
	 */
	public void setOltCard(String oltCard) {
		this.oltCard = oltCard;
	}

	/**
	 * @return the oltPort
	 */
	public String getOltPort() {
		return oltPort;
	}

	/**
	 * @param oltPort the oltPort to set
	 */
	public void setOltPort(String oltPort) {
		this.oltPort = oltPort;
	}

}
