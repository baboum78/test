package com.soliste.bolbec.livraison.service.ejb.sb.notificationwf;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Level;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import javax.jms.Message;

import com.soliste.bolbec.commun.service.ejb.sb.jms.LevelledRollbackHandler;
import com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackHandler;
import com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackLevel;
import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.commun.service.util.jms.QueueHelper;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractMessageHandlerBean;
import com.soliste.bolbec.livraison.service.exception.CancelException;
import com.soliste.bolbec.livraison.service.exception.DoneException;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Gestionnaire des notifications envoy�es par le workflow
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>23/10/2013</TD><TD>EBA</TD><TD>G9R0C1 : Corrections sonar</TD></TR>
 * <TR><TD>02/04/2020</TD><TD>RRU</TD><TD>G9R7C10: Activation de la republication (5)</TD></TR>
 * <TR><TD>02/04/2020</TD><TD>RRU</TD><TD>G9R7C10: Activation de la republication (5)</TD></TR>
 * <TR><TD>11/01/2021</TD><TD>SOPRA</TD><TD>G10R0C0 : Adaptations Camunda</TD></TR>
 * </TABLE>
 */
public class GestionnaireNotificationTacheDispoMessageHandlerBean extends AbstractMessageHandlerBean {

	private static final String CLASS_NAME = GestionnaireNotificationTacheDispoMessageHandlerBean.class.getName();

	private static final String METHOD_NAME_SET_SESSION_CONTEXT = "setSessionContext";
	private static final String METHOD_NAME_INITIALISE_ROLLBACK_HANDLER = "initialiseRollbackHandler";
	private static final String METHOD_NAME_PROCESS_MESSAGE = "processMessage";
	private static final String METHOD_NAME_GERER_NOTIFICATION = "gererNotification";

	private static final String LOG_MESSAGE_DEBUT_TRAITEMENT = "Debut du traitement.";
	private static final String LOG_MESSAGE_FIN_TRAITEMENT = "Fin du traitement.";
	private static final String DOT = ".";

	/**
	 * Propri�t� qui identifie l'UserId de la log.
	 */
	protected static final String REJECTION_QUEUE_CONNECTION_FACTORY_NAME = "jms/republicationQueueConnectionFactory";
	private static final String REJECTION_QUEUE_NAME_JNDI = "jms/rejectionQueueJndiName";
	protected static final String REJECTION_QUEUE_NAME = "jms/rejectionQueue";


	private static final Log LOG = new Log(GestionnaireNotificationTacheDispoMessageHandlerBean.class);

	protected QueueHelper rejectionQueueHelper;

	protected final IServiceManager serviceManager = ServiceManager.getInstance();
	protected final ILoggerManager loggerManager = serviceManager.getLoggerManager();

	// Configuration par d�faut de la republication
	private final static int republicationDefaultMaxAttempts = 10;
	private final static double[] republicationDefaultLevelRatioThresholds = {0., 0.5, 0.70, 0.90, 1};
	private final static long[] republicationDefaultLevelSleeps = {10000L, 20000L, 60000L, 300000L, 3600000L};
//	private final static long[] republicationDefaultLevelSleeps = {1000L, 2000L, 5000L, 10000L, 3600000L};

	/**
	 * Classe nom pour le logging
	 */
	protected String className = CLASS_NAME;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext sessionContext) {
		// Initialisation du contexte GestionnaireNotificationTacheDispo
		final String methodName = METHOD_NAME_SET_SESSION_CONTEXT;

		// Log de debut des op�rations
		loggerManager.finest(className, methodName, LOG_MESSAGE_DEBUT_TRAITEMENT);

		// Initialisation de la classe m�re
		super.setSessionContext(sessionContext);

		// Initialisation de la file de reject
		try {
			rejectionQueueHelper = new QueueHelper(REJECTION_QUEUE_CONNECTION_FACTORY_NAME, REJECTION_QUEUE_NAME);
		} catch (Exception e) {
			throw new EJBException(e);
		}

		// Initialisation du RollbackHandler
		this.rollbackHandler = initialiseRollbackHandler(sessionContext);

		// Log de fin des op�rations
		loggerManager.finest(className, methodName, LOG_MESSAGE_FIN_TRAITEMENT);
	}

	/**
	 * Initialisation du contexte de l'EJB - Rollback Handler
	 * @param sessionContext
	 * @return
	 */
	private RollbackHandler initialiseRollbackHandler(SessionContext sessionContext) {
		final String methodName = METHOD_NAME_INITIALISE_ROLLBACK_HANDLER;

		// Log de debut des op�rations
		loggerManager.finest(className, methodName, LOG_MESSAGE_DEBUT_TRAITEMENT);

		// Propri�t�s de la republication (num max republication)
		int republicationMaxAttempts;
		try {
			republicationMaxAttempts = (Integer) envContext.lookup(REPUBLICATION_QUEUE_REPUBLICATION_MAX_ATTEMPTS);
			loggerManager.finer(className, methodName, "RollbackHandler - Nombre max. de republications : " + republicationMaxAttempts + ".");
		} catch (Exception e) {
			republicationMaxAttempts = republicationDefaultMaxAttempts;
			loggerManager.warning(className, methodName, "RollbackHandler - Exception � l'initialisation de republicationQueueMaxAttempts." +
					"Valeur par d�faut: " + republicationDefaultMaxAttempts, e);
		}

		// Propri�t�s de la republication (ratios et sleeps)
		double[] republicationLevelRatioThresholds;
		long[] republicationLevelSleeps;
		try {
			// Thresholds
			String sRepublicationThresholds = (String) envContext.lookup(REPUBLICATION_QUEUE_REPUBLICATION_THRESHOLDS);
			String[] arrRepublicationThresholds = sRepublicationThresholds.split(",");
			republicationLevelRatioThresholds = new double[arrRepublicationThresholds.length];
			for (int i=0; i<arrRepublicationThresholds.length; i++) {
				republicationLevelRatioThresholds[i] = Double.parseDouble(arrRepublicationThresholds[i].trim());
			}
			// Sleeps
			String sRepublicationSleeps = (String) envContext.lookup(REPUBLICATION_QUEUE_REPUBLICATION_SLEEPS);
			String[] arrRepublicationSleeps = sRepublicationSleeps.split(",");
			republicationLevelSleeps = new long[arrRepublicationSleeps.length];
			for (int i=0; i<arrRepublicationSleeps.length; i++) {
				republicationLevelSleeps[i] = Long.parseLong(arrRepublicationSleeps[i].trim());
			}
			loggerManager.finer(className, methodName, "RollbackHandler - Ratios et sleeps : " + republicationLevelRatioThresholds + ", " + republicationLevelSleeps + ".");
		} catch (Exception e) {
			republicationLevelRatioThresholds = republicationDefaultLevelRatioThresholds;
			republicationLevelSleeps = republicationDefaultLevelSleeps;
			loggerManager.warning(className, methodName, "RollbackHandler - Exception � l'initialisation del ratios et sleeps." +
					" Valeurs par d�faut: " + republicationDefaultLevelRatioThresholds + ", " + republicationDefaultLevelSleeps, e);
		}

		// Initialisation du rollback handler
		RollbackLevel[] arrRollbackLevel = RollbackLevel.generateRollbackLevels(republicationMaxAttempts, republicationLevelRatioThresholds, republicationLevelSleeps);
		LevelledRollbackHandler levelledRollbackHandler = new LevelledRollbackHandler();
		levelledRollbackHandler.setMaxRepublicationCount(republicationMaxAttempts);
		levelledRollbackHandler.setRollbackLevels(arrRollbackLevel);
		levelledRollbackHandler.setRepublishAsync(true);
		loggerManager.config(className, methodName, "RollbackHandler async initialis� avec " + arrRollbackLevel.length + " niveaux et nombre max. de republications de " + republicationMaxAttempts);

		// Log de fin des op�rations
		loggerManager.finest(className, methodName, LOG_MESSAGE_FIN_TRAITEMENT);

		// Return du rollback handler
		return levelledRollbackHandler;
	}

	/**
	 * Surcharg� afin de ne rien faire. Le message est consomm� sans republication.
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractMessageHandlerBean#rejectMessage(javax.jms.Message, java.lang.String, java.lang.String)
	 */
	@SuppressWarnings("unused")
	protected void rejectMessage(Message a_message, String cause, String a_diagnostic) {
		loggerManager.warning(className, "rejectMessage", "le message est quand m�me consomm� (pas de recyclage)");
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractMessageHandlerBean#processMessage(java.io.Serializable)
	 */
	public void processMessage(Serializable a_message) {
		final String methodName = METHOD_NAME_PROCESS_MESSAGE;
		final String fullMethodName = CLASS_NAME + DOT + METHOD_NAME_PROCESS_MESSAGE;
		StringBuilder sbLogMessage;

		long begin = System.currentTimeMillis();
		try {
			// Debut du traitement
			loggerManager.finest(className, methodName, LOG_MESSAGE_DEBUT_TRAITEMENT);

			// TODO G10 : Force un retard, de telle fa�on que la r�ponse sera toujours re�ue avant que la TC
			// Thread.sleep(10000L);

			// Traitement
			gererNotification(a_message);

			// Fin du traitement
			loggerManager.finest(className, methodName, LOG_MESSAGE_FIN_TRAITEMENT);
		} catch (TechnicalBusinessException l_error) {
			throw l_error;
		} catch (RemoteException l_error) {
			loggerManager.warning(className, methodName, "le message re�u a provoqu� une RemoteException.", l_error);
			throw new TechnicalBusinessException(fullMethodName + "RemoteException.");
		} catch (RuntimeException l_error) {
			loggerManager.warning(className, methodName, "Une exception de runtime non g�r�e est survenue.", l_error);
			throw new TechnicalBusinessException(fullMethodName + " - RuntimeException.");
		} catch (Exception l_error) {
			loggerManager.warning(className, methodName, "Une exception non g�r�e est survenue.", l_error);
			throw new TechnicalBusinessException(fullMethodName + " - Exception.");
		} finally {
			long end = System.currentTimeMillis();
			sbLogMessage = new StringBuilder(fullMethodName).append(" dur�e = ").append(end - begin).append(" ms.");
			LOG.metro(sbLogMessage.toString());
		}
	}

	/**
	 * traitement du message lu dans la file.
	 * 
	 * @param message message � traiter
	 * 
	 * @throws RemoteException the remote exception
	 * @throws InvalidMessageException the invalid message exception
	 */
	private void gererNotification(Serializable message) throws RemoteException, InvalidMessageException {
		final String methodName = METHOD_NAME_GERER_NOTIFICATION;
		final String fullMethodName = CLASS_NAME + DOT + METHOD_NAME_GERER_NOTIFICATION;
		StringBuilder sbLogMessage;

		// Debut du traitement
		loggerManager.finest(className, methodName, LOG_MESSAGE_DEBUT_TRAITEMENT);

		// G�n�re la HashMap
		@SuppressWarnings("unchecked")
		Map<String, String> mapMessage = (HashMap<String, String>) message;

		Map<String, String> proprietesWorkflow = new HashMap<String, String>();
		proprietesWorkflow.put(Constantes.RS_VERSION_BOLBEC, mapMessage.get(Constantes.RS_VERSION_BOLBEC));
		proprietesWorkflow.put(Constantes.RS_ID_COMMANDE, mapMessage.get(Constantes.RS_ID_COMMANDE));
		proprietesWorkflow.put(Constantes.RS_CASEID, mapMessage.get(Constantes.RS_CASEID));
		proprietesWorkflow.put(Constantes.RS_BPNAME, mapMessage.get(Constantes.RS_BPNAME));
		proprietesWorkflow.put(Constantes.RS_IDEXTERNE, mapMessage.get(Constantes.RS_IDEXTERNE));
		proprietesWorkflow.put(Constantes.RS_ID, mapMessage.get(Constantes.RS_ID));
		proprietesWorkflow.put(Constantes.RS_ACTIVITYNAME, mapMessage.get(Constantes.RS_ACTIVITYNAME));
		proprietesWorkflow.put(Constantes.RS_TASKNAME, mapMessage.get(Constantes.RS_TASKNAME));
		proprietesWorkflow.put(Constantes.RS_LABEL, mapMessage.get(Constantes.RS_LABEL));
		proprietesWorkflow.put(Constantes.RS_LABEL_IHM, mapMessage.get(Constantes.RS_LABEL_IHM));

		proprietesWorkflow.put(Constantes.RS_LIGNES_CMD_INFOS, mapMessage.get(Constantes.RS_LIGNES_CMD_INFOS));
		proprietesWorkflow.put(Constantes.RS_ND_FINDER, mapMessage.get(Constantes.RS_ND_FINDER));
		proprietesWorkflow.put(Constantes.RS_FAMILLE_OFFRE, mapMessage.get(Constantes.RS_FAMILLE_OFFRE));

		proprietesWorkflow.put(Constantes.RS_FIRST_START_DATE, null); // not been executed here
		proprietesWorkflow.put(Constantes.RS_FIRST_AVAILABLE_DATE, mapMessage.get(Constantes.RS_FIRST_AVAILABLE_DATE));
		proprietesWorkflow.put(Constantes.RS_ASSIGNED_TO, mapMessage.get(Constantes.RS_ASSIGNED_TO));
		proprietesWorkflow.put(Constantes.RS_DATA2, mapMessage.get(Constantes.RS_DATA2));
		proprietesWorkflow.put(Constantes.RS_LIBCAUSEEVT, mapMessage.get(Constantes.RS_LIBCAUSEEVT));
		proprietesWorkflow.put(Constantes.RS_LIBCAUSEEVTINIT, mapMessage.get(Constantes.RS_LIBCAUSEEVTINIT));
		proprietesWorkflow.put(Constantes.RS_DATE_CONTRACTUELLE, mapMessage.get(Constantes.RS_DATE_CONTRACTUELLE));
		proprietesWorkflow.put(Constantes.RS_DATE_PROGRAMMATION, mapMessage.get(Constantes.RS_DATE_PROGRAMMATION));
		proprietesWorkflow.put(Constantes.RS_EARLIEST_START_DATE, mapMessage.get(Constantes.RS_EARLIEST_START_DATE));
		proprietesWorkflow.put(Constantes.RS_OVER_FINISH_DATE, mapMessage.get(Constantes.RS_OVER_FINISH_DATE));
		proprietesWorkflow.put(Constantes.RS_ZONE_GEO, mapMessage.get(Constantes.RS_ZONE_GEO));
		proprietesWorkflow.put(Constantes.RS_LIB_ZONE_GEO, mapMessage.get(Constantes.RS_LIB_ZONE_GEO));
		proprietesWorkflow.put(Constantes.RS_ZONE_SI, mapMessage.get(Constantes.RS_ZONE_SI));
//		proprietesWorkflow.put(Constantes.RS_LIB_ZONE_SI, hashMapMessage.get(Constantes.RS_LIB_ZONE_SI));
		proprietesWorkflow.put(Constantes.RS_REPARTITEUR, mapMessage.get(Constantes.RS_REPARTITEUR));
		proprietesWorkflow.put(Constantes.RS_JALON_ACTUEL, mapMessage.get(Constantes.RS_JALON_ACTUEL));
		proprietesWorkflow.put(Constantes.RS_NBRE_REJEUX, mapMessage.get(Constantes.RS_NBRE_REJEUX));
		proprietesWorkflow.put(Constantes.RS_NBRE_REPET, mapMessage.get(Constantes.RS_NBRE_REPET));
		proprietesWorkflow.put(Constantes.RS_CATEGORIE_CONTRACTANT, mapMessage.get(Constantes.RS_CATEGORIE_CONTRACTANT));
		proprietesWorkflow.put(Constantes.RS_CATEGORIE_LIVRE, mapMessage.get(Constantes.RS_CATEGORIE_LIVRE));
//		proprietesWorkflow.put(Constantes.RS_DSLAM, hashMapMessage.get(Constantes.RS_DSLAM));
//		proprietesWorkflow.put(Constantes.RS_ANC_DSLAM, hashMapMessage.get(Constantes.RS_ANC_DSLAM));


		// r�cup�re les identifiants du processus, task, et le nom de la t�che � cr�er.
		String idProcessus = proprietesWorkflow.get(Constantes.RS_IDEXTERNE);
		String idTask = proprietesWorkflow.get(Constantes.RS_ID);
		String taskName = proprietesWorkflow.get(Constantes.RS_TASKNAME);

		// Chargement de la commande (pour le lock des objet Commande<-->Processus - Initialement pas pr�vu, mais existant dans le contr�le d'abandon, donc prioritaire)
		final CommandeDTO commandeDTO = serviceManager.getCommandeManager().findCommandeByProcessusId(idProcessus);

		// test si le processus n'existe pas : cas o� le workflow va plus vite que la livraison
		ProcessusDTO processusDTO = serviceManager.getProcessusManager().getProcessus(idProcessus);
		if (processusDTO == null) {
			// Effectuer le rollback
			throw new TechnicalBusinessException(fullMethodName + ": Le processus " + idProcessus + " n'existe pas encore.");
		}

		// Creation Tache
		try {
			TacheDTO newTacheDTO = null;
			TacheDTO tacheDTO;
			if ( (tacheDTO = serviceManager.getTacheManager().getTache(processusDTO, proprietesWorkflow)) == null) {
				newTacheDTO = serviceManager.getTacheManager().creerTache(processusDTO, null, proprietesWorkflow, new HashMap<String, List<String>>(0), null);
			}

			// Log de l'op�ration
			if (loggerManager.isLoggable(Level.FINE)) {
				sbLogMessage = new StringBuilder("La t�che avec workflowTaskId ").append(idTask).append(", et name: ").append(taskName);
				if ( tacheDTO != null) {
					sbLogMessage.append(" existait d�j� en base avec id: ").append(tacheDTO.getId());
				} else if ( newTacheDTO != null ) {
					sbLogMessage.append(" a �t� cr��e en base avec id: ").append(newTacheDTO.getId());
				} else {
					sbLogMessage.append(" n'a pas �t� cr��e en base.");
				}
				loggerManager.fine(className, methodName, sbLogMessage.toString());
			}
		} catch (DoneException de) {
			// On cr�e une tache d�ja cr��e.... ne devrait jamais arriver
			loggerManager.warning(className, methodName, "La cr�ation de tache a �chou�e car elle existe d�j�.", de);
		} catch (CancelException ce) {
			// Effectuer le rollback
			throw new TechnicalBusinessException(fullMethodName + ": CancelException dans processRequest processusId.", ce);
		}
		// Fin du traitement
		loggerManager.finest(className, methodName, LOG_MESSAGE_FIN_TRAITEMENT);
	}
}