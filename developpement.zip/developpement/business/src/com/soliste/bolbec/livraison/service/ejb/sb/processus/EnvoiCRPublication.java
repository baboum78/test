package com.soliste.bolbec.livraison.service.ejb.sb.processus;

import java.util.HashMap;

import javax.jms.JMSException;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.fwk.jms.JmsUtils;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.ConstantesJNDI;

/**
 * Classe utilis�e en IHM pour l'envoi des CR de publication
 * (cas des commandes en r�gularisation manuelle)
 * 
 * @author kfqd7402
 */
public class EnvoiCRPublication {

	private String queueName;
	private String traitement;
	private String typeService;

	/**
	 * Constructeur
	 * 
	 * @param systemeExterne
	 */
	public EnvoiCRPublication(String systemeExterne) {
		if ("Cristal".equals(systemeExterne)) {
			queueName = "queue.GeneralRoutage.Cristal";
			traitement = "CristalOut";
			typeService = "CristalOut";
		} else if ("EFB".equals(systemeExterne)) {
			queueName = "queue.GeneralRoutage.Efb";
			traitement = "EfbOut";
			typeService = "EfbOut";
		} else if ("SAGIC".equals(systemeExterne)) {
			queueName = "queue.GeneralRoutage.Sagic";
			traitement = "SagicOut";
			typeService = "SagicOut";
		} else if ("SupDePro".equals(systemeExterne)) {
			queueName = "queue.emission.SupDePro";
			traitement = "SupDeProOut";
			typeService = "SupDeProOut";
		}
	}

	/**
	 * Envoi du CR de publication dans la file MQ-Series ad�quate
	 * 
	 * @param message
	 */
	public void send(HashMap<String, String> message) {
		try {
			JmsUtils.sendMessage(ConstantesJNDI.QUEUE_FACTORY_XA, queueName, message, true);
		} catch (NamingException e) {
			throw new TechnicalBusinessException("EnvoiCRPublication - send() - Impossible d'utiliser le QueueHelper", e);
		} catch (JMSException e) {
			throw new TechnicalBusinessException("EnvoiCRPublication - send() - Unable to send message.", e);
		}
	}

	/**
	 * @return traitement
	 */
	public String getTraitement() {
		return traitement;
	}

	/**
	 * @return typeService
	 */
	public String getTypeService() {
		return typeService;
	}

}
