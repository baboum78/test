/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;

import com.soliste.bolbec.livraison.service.model.TacheDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>14/06/2012</TD><TD>AGR</TD><TD>EV000184 : Achat FTTH, tache manuelle local tech</TD></TR>
 * </TABLE><BR>
 */

/**
 * Le DTO pour l'entit� TacheManuelle
 * 
 * @author edba8262
 */
public class TacheManuelleDTO implements Serializable {

	/**
	 * TacheManuelleDTO TACHE_MANUELLE_STANDARD_TYPE
	 */
	public static final String TACHE_MANUELLE_STANDARD_TYPE = "TacheManuelleStandard";
	/**
	 * TacheManuelleDTO TACHE_MANUELLE_DECROCHAGE_TYPE
	 */
	public static final String TACHE_MANUELLE_DECROCHAGE_TYPE = "TacheManuelleDecrochage";
	/**
	 * TacheManuelleDTO TACHE_MANUELLE_COMPLETUDE_CRI_TYPE
	 */
	public static final String TACHE_MANUELLE_COMPLETUDE_CRI_TYPE = "TacheManuelleCompletudeCri";
	/**
	 * TacheManuelleDTO TACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE
	 */
	public static final String TACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE = "TacheManuelleCompletudeAdresse";
	/**
	 * TacheManuelleDTO TACHE_MANUELLE_CONTACT_CLIENT_TYPE
	 */
	public static final String TACHE_MANUELLE_CONTACT_CLIENT_TYPE = "TacheManuelleContactClient";
	/**
	 * TacheManuelleDTO TACHE_MANUELLE_RESERVATION_INTERVENTION_TYPE
	 */
	public static final String TACHE_MANUELLE_RESERVATION_INTERVENTION_TYPE = "TacheManuelleReservationIntervention";
	/**
	 * TacheManuelleDTO TACHE_MANUELLE_LOCAL_TECH_TYPE
	 */
	public static final String TACHE_MANUELLE_LOCAL_TECH_TYPE = "LocTech";
	private String idProcessus;
	private TacheDTO tache;
	private String modeOperatoireUrl;
	private boolean abandonnable;
	private boolean suspendable;
	private boolean retablissable;

	/**
	 * 
	 */
	TacheManuelleDTO() {
		// constructeur
	}

	/**
	 * @return idProcessus
	 */
	public String getIdProcessus() {
		return this.idProcessus;
	}

	void setIdProcessus(String idProcessus) {
		this.idProcessus = idProcessus;
	}

	/**
	 * @return tache
	 */
	public TacheDTO getTache() {
		return this.tache;
	}

	void setTache(TacheDTO tache) {
		this.tache = tache;
	}

	/**
	 * @return modeOperatoireUrl
	 */
	public String getModeOperatoireUrl() {
		return this.modeOperatoireUrl;
	}

	void setModeOperatoireUrl(String modeOperatoireUrl) {
		this.modeOperatoireUrl = modeOperatoireUrl;
	}

	/**
	 * @return TACHE_MANUELLE_STANDARD_TYPE
	 */
	public String getType() {
		return TACHE_MANUELLE_STANDARD_TYPE;
	}

	/**
	 * @return TACHE_MANUELLE_COMPLETUDE_CRI_TYPE
	 */
	public String getTACHE_MANUELLE_COMPLETUDE_CRI_TYPE() {
		return TACHE_MANUELLE_COMPLETUDE_CRI_TYPE;
	}

	/**
	 * @return TACHE_MANUELLE_DECROCHAGE_TYPE
	 */
	public String getTACHE_MANUELLE_DECROCHAGE_TYPE() {
		return TACHE_MANUELLE_DECROCHAGE_TYPE;
	}

	/**
	 * @return TACHE_MANUELLE_STANDARD_TYPE
	 */
	public String getTACHE_MANUELLE_STANDARD_TYPE() {
		return TACHE_MANUELLE_STANDARD_TYPE;
	}

	/**
	 * @return TACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE
	 */
	public String getTACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE() {
		return TACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE;
	}

	/**
	 * @return TACHE_MANUELLE_RESERVATION_INTERVENTION_TYPE
	 */
	public String getTACHE_MANUELLE_RESERVATION_INTERVENTION_TYPE() {
		return TACHE_MANUELLE_RESERVATION_INTERVENTION_TYPE;
	}

	/**
	 * @return TACHE_MANUELLE_CONTACT_CLIENT_TYPE
	 */
	public String getTACHE_MANUELLE_CONTACT_CLIENT_TYPE() {
		return TACHE_MANUELLE_CONTACT_CLIENT_TYPE;
	}

	/**
	 * @return TACHE_MANUELLE_LOCAL_TECH_TYPE
	 */
	public String getTACHE_MANUELLE_LOCAL_TECH_TYPE() {
		return TACHE_MANUELLE_LOCAL_TECH_TYPE;
	}

	/**
	 * @return abandonnable
	 */
	public boolean isAbandonnable() {
		return this.abandonnable;
	}

	void setAbandonnable(boolean abandonnable) {
		this.abandonnable = abandonnable;
	}

	/**
	 * @return retablissable
	 */
	public boolean isRetablissable() {
		return this.retablissable;
	}

	void setRetablissable(boolean retablissable) {
		this.retablissable = retablissable;
	}

	/**
	 * @return suspendable
	 */
	public boolean isSuspendable() {
		return this.suspendable;
	}

	void setSuspendable(boolean suspendable) {
		this.suspendable = suspendable;
	}
}