package com.soliste.bolbec.livraison.service.ejb.sb.rdv;

import javax.ejb.EJBLocalObject;

public interface RendezVousManagerLocal extends RendezVousManager, EJBLocalObject {

}
