package com.soliste.bolbec.livraison.service.ejb.sb.publication;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import javax.jms.Message;

import com.soliste.bolbec.commun.service.ejb.sb.jms.LevelledRollbackHandler;
import com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackHandler;
import com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackLevel;
import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * MDB pour les notifications g�n�riques MQ d�clenchant les publications g�n�riques
 */
public class NotificationGeneriqueMessageHandlerBean extends AbstractMessageHandlerBean {

    private static final String CLASS_NAME = NotificationGeneriqueMessageHandlerBean.class.getName();

    private static final Log LOG = new Log(NotificationGeneriqueMessageHandlerBean.class);
    private static final IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	protected static final String REPUBLICATION_QUEUE_REPUBLICATION_MAX_ATTEMPTS = "jms/republicationQueueMaxAttempts";
	protected static final String REPUBLICATION_QUEUE_REPUBLICATION_THRESHOLDS = "jms/republicationQueueThresholds";
	protected static final String REPUBLICATION_QUEUE_REPUBLICATION_SLEEPS = "jms/republicationQueueSleeps";

	private static final String LOG_MESSAGE_DEBUT_TRAITEMENT = "Debut du traitement.";
	private static final String LOG_MESSAGE_FIN_TRAITEMENT = "Fin du traitement.";

	// Configuration par d�faut de la republication
	private final static int republicationDefaultMaxAttempts = 48;
	private final static double[] republicationDefaultLevelRatioThresholds = {0};
	private final static long[] republicationDefaultLevelSleeps = {3600000L};

	/**
     * M�thode pour le traitement de la notification
     */
    private void processNotification(Map<String, String> map) {
        String method = "processNotification";
        SERVICE_MANAGER.getLoggerManager().finer(CLASS_NAME, method, "D�but");

        NotificationGenerique notificationGenerique = new NotificationGenerique(map);
        SERVICE_MANAGER.getNotificationGeneriqueManager().traiterNotification(notificationGenerique);

        SERVICE_MANAGER.getLoggerManager().finer(CLASS_NAME, method, "Fin");
    }

    @Override
	/*
	* Cette class re�oit une NotificationGenerique, la commande a d� �tre cr�e au moment de la reception du message de l'emetteur,
	* donc la m�thode create commande va retourner null et ce null c'est l'entr�e de cette m�thode (commandeDTOVide va �tre toujours null)
	*/
    public void processMessage(Serializable msg, CommandeDTO commandeDTOVide) throws InvalidJmsMessageException {
        long begin = System.currentTimeMillis();

        try {
            if (!(msg instanceof Map<?, ?>)) {
                throw new InvalidJmsMessageException("Le message n'est pas une Map");
            }

            @SuppressWarnings("unchecked")
            Map<String, String> map = (HashMap<String, String>) msg;

            processNotification(map);
        } catch (InvalidJmsMessageException e) {
            throw (e);
        } catch (Exception e) {
            throw new TechnicalBusinessException("Exception impr�vue", e);
        } finally {
            long end = System.currentTimeMillis();
            String messageMetro = "'processMessage' duree = " + (end - begin) + " ms";
            LOG.metro(messageMetro);
        }
    }

    @Override
    protected void rejectMessage(Message msg, String cause, String diagnostic) {
        SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, "rejectMessage", "Rejet du message :\n" + msg);
    }

	@Override
	/**
	 * Cette class re�oit une NotificationGenerique, la commande a d� �tre cr�e au moment de la reception du message de l'emetteur
	 */
	public CommandeDTO getOrCreateCommande(Serializable a_message) throws InvalidJmsMessageException {
		return null;
	}

	@Override
	public void ejbCreate() {
		this.rollbackHandler = initialiseRollbackHandler();
	}

	/**
	 * Initialisation du contexte de l'EJB - Rollback Handler
	 * @return
	 */
	private RollbackHandler initialiseRollbackHandler() {
		final String methodName = "initialiseRollbackHandler";

		// Log de debut des op�rations
		SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, methodName, LOG_MESSAGE_DEBUT_TRAITEMENT);

		// Propri�t�s de la republication (num max republication)
		int republicationMaxAttempts;
		try {
			republicationMaxAttempts = (Integer) envContext.lookup(REPUBLICATION_QUEUE_REPUBLICATION_MAX_ATTEMPTS);
			SERVICE_MANAGER.getLoggerManager().finer(CLASS_NAME, methodName, "RollbackHandler - Nombre max. de republications : " + republicationMaxAttempts + ".");
		} catch (Exception e) {
			republicationMaxAttempts = republicationDefaultMaxAttempts;
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, methodName, "RollbackHandler - Exception � l'initialisation de republicationQueueMaxAttempts." +
					"Valeur par d�faut: " + republicationDefaultMaxAttempts, e);
		}

		// Propri�t�s de la republication (ratios et sleeps)
		double[] republicationLevelRatioThresholds;
		long[] republicationLevelSleeps;
		try {
			// Thresholds
			String sRepublicationThresholds = (String) envContext.lookup(REPUBLICATION_QUEUE_REPUBLICATION_THRESHOLDS);
			String[] arrRepublicationThresholds = sRepublicationThresholds.split(",");
			republicationLevelRatioThresholds = new double[arrRepublicationThresholds.length];
			for (int i=0; i<arrRepublicationThresholds.length; i++) {
				republicationLevelRatioThresholds[i] = Double.parseDouble(arrRepublicationThresholds[i].trim());
			}
			// Sleeps
			String sRepublicationSleeps = (String) envContext.lookup(REPUBLICATION_QUEUE_REPUBLICATION_SLEEPS);
			String[] arrRepublicationSleeps = sRepublicationSleeps.split(",");
			republicationLevelSleeps = new long[arrRepublicationSleeps.length];
			for (int i=0; i<arrRepublicationSleeps.length; i++) {
				republicationLevelSleeps[i] = Long.parseLong(arrRepublicationSleeps[i].trim());
			}
			SERVICE_MANAGER.getLoggerManager().finer(CLASS_NAME, methodName, "RollbackHandler - Ratios et sleeps : " + republicationLevelRatioThresholds + ", " + republicationLevelSleeps + ".");
		} catch (Exception e) {
			republicationLevelRatioThresholds = republicationDefaultLevelRatioThresholds;
			republicationLevelSleeps = republicationDefaultLevelSleeps;
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, methodName, "RollbackHandler - Exception � l'initialisation del ratios et sleeps." +
					" Valeurs par d�faut: " + republicationDefaultLevelRatioThresholds + ", " + republicationDefaultLevelSleeps, e);
		}

		// Initialisation du rollback handler
		RollbackLevel[] arrRollbackLevel = RollbackLevel.generateRollbackLevels(republicationMaxAttempts, republicationLevelRatioThresholds, republicationLevelSleeps);
		LevelledRollbackHandler levelledRollbackHandler = new LevelledRollbackHandler();
		levelledRollbackHandler.setMaxRepublicationCount(republicationMaxAttempts);
		levelledRollbackHandler.setRollbackLevels(arrRollbackLevel);
		levelledRollbackHandler.setRepublishAsync(true);
		SERVICE_MANAGER.getLoggerManager().config(CLASS_NAME, methodName, "RollbackHandler async initialis� avec " + arrRollbackLevel.length + " niveaux et nombre max. de republications de " + republicationMaxAttempts);

		// Log de fin des op�rations
		SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, methodName, LOG_MESSAGE_FIN_TRAITEMENT);

		// Return du rollback handler
		return levelledRollbackHandler;
	}


}
