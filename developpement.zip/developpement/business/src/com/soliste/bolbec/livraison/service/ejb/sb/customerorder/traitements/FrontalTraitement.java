package com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang3.StringUtils;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.sw.custorder.ConstantesDeliverCustomerOrder;
import com.soliste.bolbec.livraison.service.sw.custorder.helper.IDeliverCustomerOrderNullHelper;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CouldBeRelatedToTemporarySiteType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CustomerOrderItemType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.LocalSiteExternalIdentifierType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.InstalledProduct;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.LocalMarketSegment;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace.LocalInstalledResource;

import aps.CasMetierConstantes;
import aps.SystemeExterneConstantes;
import aps.Traduction;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.ParametreType;

/**
 * Classe sp�cifique Frontal du traitement des IC deliverCustomerOrder
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>16/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Cr�ation de la classe</TD></TR>
 * <TR><TD>22/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Fin du Dev</TD></TR>
 * <TR><TD>24/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Corrections suite � test d'int�gration</TD></TR>
 * <TR><TD>20/06/2013</TD><TD>EBA</TD><TD>G8R2C2 - Mise en place Sonar : suppression des accents dans noms de methodes</TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * <TR><TD>05/09/2013</TD><TD>BPE</TD><TD>DE-000936 "NullPointerException lors d'une injection d'une IC vers CustomerOrderServiceIOSW"</TD></TR>
 * <TR><TD>30/10/2013</TD><TD>VDE</TD><TD>EV-000227 "Mutation en masse DSLAM"</TD></TR>
 * <TR><TD>24/01/2014</TD><TD>VDE</TD><TD>DE-000990 "Mutation en masse DSLAM"</TD></TR>
 * <TR><TD>21/03/2014</TD><TD>BPE</TD><TD>G8R2C4 - EV-000227_02 : Nouveau filtre '*'</TD></TR>
 * <TR><TD>31/10/2014</TD><TD>KRA</TD><TD>EV-000302_03 : PLP Fibre</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377 : ROME OFfre - Commandes FTTE</TD></TR>
 * <TR><TD>11/10/2017</TD><TD>SMO</TD><TD>EV-431 : FTTE offre active sur RIP</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.4956</TD><TD>EP135 � Prendre en compte les commandes FTTH Op�rateur �mises par GRAFIC</TD></TR>
 * <TR><TD>REQ.7299</TD><TD>EP0170 - Prendre en compte les commandes issues du Frontal de Livraison</TD></TR>
 * <TR><TD>REQ.9321</TD><TD>EP0239 - Accepter les commandes de R�siliation de Vente FTTH</TD></TR>
 * <TR><TD>REQ.9323</TD><TD>EP0228 - Accepter les commandes de mutation en masse</TD></TR>
 * <TR><TD>REQ.11787</TD><TD>EP0334 - Rep�rer et stocker les caract�ristiques des PLP Fibre dans le cadre de la vente FTTH (EV302)</TD></TR>
 * </TABLE>
 * 
 */
public class FrontalTraitement extends CustomerOrderTraitement {

	/** The Constant CLASS_NAME. */
	private final static String CLASS_NAME = FrontalTraitement.class.getName();

	private static final String FORMAT_DATE_HEURE = "dd/MM/yyyy HH:mm:ss";

	private static final String CAS_ACQUISITION = "acquisition";
	private static final String FILTRE_IGNORER_LC_PUBLICATION = "*";
	private static final int PREMIERE_LC_INDEX = 0;

	/**
	 * Constructeur
	 */
	public FrontalTraitement() {
		EMETTEUR = SystemeExterneConstantes.FRONTAL;
	}

	/**
	 * @see CustomerOrderTraitement#verifLigneCommande()
	 */
	protected void verifLigneCommande() throws DeliverCustomerOrderFault {
		String method = "verifLigneCommande";
		boolean isOK = false;
		loggerManager.fine(CLASS_NAME, method, "V�rification des offres et op�ration commerciales des lignes de commande pour le cas m�tier " + getDeliverCustomerOrderData().getCasMetier());
		List<CustomerOrderItemType> custOrderItLst = customerOrder.getCustomerOrderItem();
		if (custOrderItLst.size() == 2) {
			CustomerOrderItemType ldc1 = custOrderItLst.get(0);
			CustomerOrderItemType ldc2 = custOrderItLst.get(1);
			// Pas de tests de nullit� car tous ces champs sont obligatoires pour FRONTAL
			String offre1 = ldc1.getOfferSpecification().getOfferSpecificationCode();
			String offre2 = ldc2.getOfferSpecification().getOfferSpecificationCode();

			String operation1 = ldc1.getCommercialOperation().getCommercialOperationType();
			String operation2 = ldc2.getCommercialOperation().getCommercialOperationType();

			if (matchTwoByTwo(ConstantesDeliverCustomerOrder.OFFRE_FTH, ConstantesDeliverCustomerOrder.OFFRE_FTH_SERV, offre1, offre2)) {
				if (Constantes.ADD.equals(operation1) && Constantes.ADD.equals(operation2) || Constantes.REMOVE.equals(operation1) && Constantes.REMOVE.equals(operation2)) {
					isOK = true;
				}
			}
		} else if (custOrderItLst.size() == 1) {
			if (Constantes.CST_MIGRATION.equals(customerOrder.getCustomerOrderType())) {
				isOK = true;
			}
		}
		if (!isOK) {
			throw anoCommandeMalStructuree();
		}

	}

	/**
	 * Equivalement � equals de 2 Sets de 2 elements
	 * 
	 * @param offreFth
	 * @param offreFthserv
	 * @param offre1
	 * @param offre2
	 * @return
	 */
	private boolean matchTwoByTwo(String offreFth, String offreFthserv, String offre1, String offre2) {
		return offreFth.equals(offre1) && offreFthserv.equals(offre2) || offreFth.equals(offre2) && offreFthserv.equals(offre1);
	}

	/**
	 * retourne la collection des fonctions obligatoires pour Frontal
	 */
	protected Collection<TraductionDTO> recupereFonctionsOblig() {
		if (CasMetierConstantes.CR_FTTH.equals(getDeliverCustomerOrderData().getCasMetier()) || CasMetierConstantes.SU_FTTH.equals(getDeliverCustomerOrderData().getCasMetier())) {
			return serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.FUNCTION_IC_FRONTAL_OBLIG),
					new Comparaison(Traduction.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, Constantes.CST_OUI), new Comparaison(Traduction.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.FRONTAL));
		}
		return serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.FUNCTION_IC_MUTDSL_OBLIG),
				new Comparaison(Traduction.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, Constantes.CST_OUI), new Comparaison(Traduction.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.FRONTAL));

	}

	@Override
	protected void controleBooleans() throws DeliverCustomerOrderFault {
		String method = "controleBooleans";
		loggerManager.fine(CLASS_NAME, method, "Controle le Local_InstalledResource pour le cas m�tier " + getDeliverCustomerOrderData().getCasMetier());
		if (CAS_ACQUISITION.equals(customerOrder.getCustomerOrderType())) {
			CouldBeRelatedToTemporarySiteType couldBeRelated = customerOrder.getCouldBeRelatedToTemporarySite();
			if (couldBeRelated != null) {
				List<SiteType> siteList = couldBeRelated.getSite();
				for (SiteType site : siteList) {
					List<LocalPlace> localPlaceList = site.getLocalPlace();
					for (LocalPlace localPlace : localPlaceList) {
						LocalInstalledResource localInstalledResource = localPlace.getLocalInstalledResource().get(0);
						if (localInstalledResource != null && localInstalledResource.isLocalExistingInstalledResource()) {
							throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper()
									.genererAnomalieChampMalFormate("Le champ local_existingInstalledResource n'a pas une valeur permise pour le cas m�tier : " + getDeliverCustomerOrderData().getCasMetier(), customerOrder.getCustomerOrderID());
						}

					}
				}
			}
		}

	}

	@Override
	protected void controlesSpecifiques() throws DeliverCustomerOrderFault {
		String method = "controlesSpecifiques";
		loggerManager.fine(CLASS_NAME, method, "Controles sp�cifiques au cas m�tier " + getDeliverCustomerOrderData().getCasMetier());
		// le test sur CR_FTTH est r�alis� dans le xsd
		if (CasMetierConstantes.SU_FTTH_VALEUR_CONSTANTE.equals(getDeliverCustomerOrderData().getCasMetier())) {
			for (CustomerOrderItemType custOrderType : customerOrder.getCustomerOrderItem()) {
				if (ConstantesDeliverCustomerOrder.OFFRE_FTH.equals(custOrderType.getOfferSpecification().getOfferSpecificationCode())) {
					if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
						throw anoCommandeMalStructuree();
					}
				}
			}
		}
	}

	@Override
	protected Map<String, List<ValeurParametreDTO>> recupererListeOffresElementaires() throws DeliverCustomerOrderFault {
		String method = "recupererListeOffresElementaires";
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration de la liste d'offres elementaires");
		// LinkedHashMap pour conserver l'ordre des param�tres lors de la copie sur les lignes de commandes
		Map<String, List<ValeurParametreDTO>> listeOffresElementaires = new LinkedHashMap<String, List<ValeurParametreDTO>>();
		String offerSpecificationCode = null;
		try {
			for (CustomerOrderItemType custOrderType : customerOrder.getCustomerOrderItem()) {
				offerSpecificationCode = custOrderType.getOfferSpecification().getOfferSpecificationCode();
				// on peut m�langer les offres des diff�rentes lignes de commandes
				if (CasMetierConstantes.CR_FTTH.equals(getDeliverCustomerOrderData().getCasMetier()) || CasMetierConstantes.SU_FTTH.equals(getDeliverCustomerOrderData().getCasMetier())) {
					listeOffresElementaires.putAll(serviceManager.getTraductionManager().getTraductionOffreConcatDiff(offerSpecificationCode, SystemeExterneConstantes.FRONTAL));
				} else {
					listeOffresElementaires.putAll(serviceManager.getTraductionManager().getTraductionOffreConcatDiff(offerSpecificationCode, SystemeExterneConstantes.NUM_42C));
				}
			}
		} catch (AnomalieException ae) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(offerSpecificationCode, customerOrder.getCustomerOrderID());
		}
		loggerManager.fine(CLASS_NAME, method, "Nombre d'offre elementaires trouv�es : " + listeOffresElementaires.size());
		return listeOffresElementaires;
	}

	@Override
	protected void valorisationChampDynamiqueOsirisOpPonctuelleOrigine(Collection<LigneCommandeType> lignesDeCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected String determineCodeClient() {
		return customerOrder.getCustomerOrderItem().get(getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().getIndexOrganisationName()).getProductOrderItem().get(0).getUser().get(0).getParty().getLocalOrganisationName().getTradingName();
	}

	@Override
	protected String getLocalMarketSegmentLabelClientLivre() {
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return null;
		}
		// On r�cup�re l'index de la ligne de commande possedant le Local_OrganisationName
		final int indexOrganisationName = getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().getIndexOrganisationName();
		final LocalMarketSegment localMarketSegment = customerOrder.getCustomerOrderItem().get(indexOrganisationName).getProductOrderItem().get(0).getUser().get(0).getLocalMarketSegment();
		if (localMarketSegment == null) {
			return null;
		}
		return localMarketSegment.getLabel();
	}

	/**
	 * RG12 : r�cup�re la valeur du champ Label dans Local_MarketSegment
	 * 
	 * @return le label du LocalMarketSegment s'il existe, sinon null
	 * @throws DeliverCustomerOrderFault
	 */
	protected String getTraductionCategorieClientLivre() throws DeliverCustomerOrderFault {
		final String methode = "getTraductionCategorieClientLivre";
		final String label = getLocalMarketSegmentLabelClientLivre();
		loggerManager.fine(CLASS_NAME, methode, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionCatClientInterfVersCatClientLivre(EMETTEUR, label);
		loggerManager.fine(CLASS_NAME, methode, "LocalMarketSegmentLabel traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(label, customerOrder.getCustomerOrderID());
		}
		return traduction;
	}

	@Override
	protected void fournirIdentifiantLigneDeCommande(final Collection<LigneCommandeType> lignesDeCommande, String casMetier) {
		String method = "fournirIdentifiantLigneDeCommande";
		// On a besoin de l'index soit pour les ldc soit pour les customerOrderType
		// il y en a autant car on cr�� les ldc � partir des customerOrderType
		String idLdc;
		String suffixe;
		int i;
		if (CasMetierConstantes.MUT_DSLAM.equals(casMetier)) {
			i = 1;
			idLdc = customerOrder.getCustomerOrderItem().get(PREMIERE_LC_INDEX).getCustomerOrderItemID();
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				suffixe = i == 1 ? StringUtils.EMPTY : Integer.toString(i);
				ligneDeCommande.setIdLigneCommande(idLdc + suffixe);
				loggerManager.fine(CLASS_NAME, method, "IdLigneCommande cr��e : " + idLdc + suffixe);
				i++;
			}
		} else {
			i = 0;
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				idLdc = customerOrder.getCustomerOrderItem().get(i).getCustomerOrderItemID();
				loggerManager.fine(CLASS_NAME, method, "IdLigneCommande cr��e : " + idLdc);
				ligneDeCommande.setIdLigneCommande(idLdc);
				i++;
			}
		}
	}

	@Override
	/**
	 * RG11 : Acc�s et Type Livraison
	 * 
	 * @param lignesDeCommande
	 */
	protected void fournirAccesEtTypeLivraison(final Collection<LigneCommandeType> lignesDeCommande) {
		String method = "fournirAccesEtTypeLivraison";
		if (CasMetierConstantes.CR_FTTH.equals(getDeliverCustomerOrderData().getCasMetier())) {
			loggerManager.fine(CLASS_NAME, method, "Cas metier CR_FTTH, typeAccesLivraison : " + ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_IDCLI);
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_IDCLI);
			}
		} else if (CasMetierConstantes.SU_FTTH.equals(getDeliverCustomerOrderData().getCasMetier())) {
			final InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
			loggerManager.fine(CLASS_NAME, method, "Cas metier SU_FTTH, accesLivraison : " + installedProduct + ", typeAccesLivraison : " + ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_FTTH);
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				ligneDeCommande.setAccesLivraison(installedProduct != null ? installedProduct.getInstalledProductID() : null);
				ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_FTTH);
			}
		} else if (CasMetierConstantes.MUT_DSLAM.equals(getDeliverCustomerOrderData().getCasMetier())) {
			final InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
			loggerManager.fine(CLASS_NAME, method, "Cas metier MUT_DSLAM, accesLivraison : " + installedProduct + ", typeAccesLivraison : " + ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_ND);
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				ligneDeCommande.setAccesLivraison(installedProduct != null ? installedProduct.getInstalledProductID() : null);
				ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_ND);
			}
		}
	}

	@Override
	protected Collection<ParametreType> creerParametresProduitServiceFunctionLc(int i) {
		final String prefixeParamDet = "ParamDet";
		final String prefixeBVPN = "BVPN_";
		final Collection<ParametreType> resultat = new ArrayList<ParametreType>();

		final List<Map<String, String>> fonctionsGraficLcLst = getDeliverCustomerOrderData().getFonctionsLc();
		if (fonctionsGraficLcLst.size() > i) {
			ParametreType parametreType;
			StringBuilder cle;
			for (Entry<String, String> fonctionGraficLc : fonctionsGraficLcLst.get(i).entrySet()) {
				parametreType = new ParametreType();
				cle = new StringBuilder(30);
				if (ConstantesDeliverCustomerOrder.DEBIT.equals(fonctionGraficLc.getKey())) {
					cle.append(prefixeParamDet);
					cle.append(ConstantesDeliverCustomerOrder.DEBIT_MAJ);
				} else if (ConstantesDeliverCustomerOrder.SERVICE.equals(fonctionGraficLc.getKey())) {
					cle.append(prefixeParamDet);
					cle.append(ConstantesDeliverCustomerOrder.SERVICE_MAJ);
				} else if (CasMetierConstantes.CR_FTTH.equals(getDeliverCustomerOrderData().getCasMetier()) || CasMetierConstantes.SU_FTTH.equals(getDeliverCustomerOrderData().getCasMetier())) {
					cle.append(prefixeBVPN);
					cle.append(fonctionGraficLc.getKey());
				} else if (CasMetierConstantes.MUT_DSLAM.equals(getDeliverCustomerOrderData().getCasMetier())) {
					cle.append(fonctionGraficLc.getKey());
				}
				parametreType.setCle(cle.toString());
				parametreType.setValeur(fonctionGraficLc.getValue());
				resultat.add(parametreType);
			}
		}
		return resultat;
	}

	@Override
	protected Collection<ParametreType> creerParametresHorsFunctionSpecification() {
		// Rien a r�cup�rer pour Frontal
		// on retourne une liste vide
		return new ArrayList<ParametreType>();
	}

	@Override
	protected void fournirInterventionEtParametresAssocies(Commande commande, Collection<LigneCommandeType> lignesDeCommande) throws DeliverCustomerOrderFault {
		final String method = "fournirInterventionEtParametresAssocies";
	}

	@Override
	protected void verifPrestaClipEtDebit(List<Map<String, String>> fonctionsLcTraduitesLst) throws DeliverCustomerOrderFault {
		String method = "verifPrestaClipEtDebit";
		loggerManager.finest(CLASS_NAME, method, "V�rification sur PrestaCLIP et Debit.");
		String offerSpecificationCode = StringUtils.EMPTY;
		boolean isAddEtFTH = false;
		boolean isFTHSERV = false;
		for (CustomerOrderItemType custOrderItem : customerOrder.getCustomerOrderItem()) {
			offerSpecificationCode = custOrderItem.getOfferSpecification().getOfferSpecificationCode();
			if (Constantes.ADD.equals(custOrderItem.getCommercialOperation().getCommercialOperationType())) {
				if (ConstantesDeliverCustomerOrder.OFFRE_FTH.equals(offerSpecificationCode)) {
					isAddEtFTH = true;
				}
			}
			if (ConstantesDeliverCustomerOrder.OFFRE_FTH_SERV.equals(offerSpecificationCode)) {
				isFTHSERV = true;
			}
		}
		if (isAddEtFTH) {
			if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.PRESTA_CLIP)) {
				throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.PRESTA_CLIP, customerOrder.getCustomerOrderID());
			}
		}

		if (isFTHSERV) {
			if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.DEBIT)) {
				throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.DEBIT, customerOrder.getCustomerOrderID());
			}
		}
		loggerManager.finest(CLASS_NAME, method, "Fin de la v�rification sur PrestaCLIP et Debit.");
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements.CustomerOrderTraitement#verifFonctionsLcFTTEActiveOuPassive(java.util.List)
	 * 
	 * v�rifie la pr�sence des valeurs des FonctionsLc FTTE ACTIVE : 'OLTName', 'Shelf', 'Card', 'Port' ou FTTE PASSIVE : 'Ferme', 'Niveau', 'Plateau', 'Point de Connexion'
	 * 
	 */
/*	@Override
	protected void verifFonctionsLcFTTEActiveOuPassive(List<Map<String, String>> fonctionsLcTraduitesLst) throws DeliverCustomerOrderFault {
		String method = "verifFonctionsLcFTTEActiveOuPassive";
		loggerManager.finest(CLASS_NAME, method, "V�rification des FonctionsLc FTTE ACTIVE ou PASSIVE.");
		String offerSpecificationCode = StringUtils.EMPTY;
		for (CustomerOrderItemType custOrderItem : customerOrder.getCustomerOrderItem()) {
			offerSpecificationCode = custOrderItem.getOfferSpecification().getOfferSpecificationCode();
			if (Constantes.ADD.equals(custOrderItem.getCommercialOperation().getCommercialOperationType())) {
				if (Arrays.asList(ConstantesDeliverCustomerOrder.OFFRE_FTTE_ACTIVE, ConstantesDeliverCustomerOrder.OFFRE_FTTE_PASSIVE).contains(offerSpecificationCode)) {
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.NRO)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.NRO);
					}
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.CODEINSEENRO)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.CODEINSEENRO);
					}
				}
				if (ConstantesDeliverCustomerOrder.OFFRE_FTTE_ACTIVE.equals(offerSpecificationCode)) {
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.OLT)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.OLT);
					}
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.CHASSIS)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.CHASSIS);
					}
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.CARTE)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.CARTE);
					}
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.PORT)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.PORT);
					}
					loggerManager.finest(CLASS_NAME, method, "Fin de la v�rification des FonctionsLc FTTE ACTIVE : 'NRO', 'CodeINSEE_NRO', 'OLTName', 'Shelf', 'Card', 'Port'.");
				} else if (ConstantesDeliverCustomerOrder.OFFRE_FTTE_PASSIVE.equals(offerSpecificationCode)) {
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.FERME)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.FERME);
					}
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.NIVEAU)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.NIVEAU);
					}
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.PLATEAU)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.PLATEAU);
					}
					if (!containsKeyInAny(fonctionsLcTraduitesLst, ConstantesDeliverCustomerOrder.POINT_DE_CONNEXION)) {
						throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.POINT_DE_CONNEXION);
					}
					loggerManager.finest(CLASS_NAME, method, "Fin de la v�rification des FonctionsLc FTTE PASSIVE : 'NRO', 'CodeINSEE_NRO', 'Ferme', 'Niveau', 'Plateau', 'Point de Connexion'.");
				}
			}
		}
	} */

	/**
	 * RG5
	 * 
	 * @return la categorie du client contractant (Anomalie si champ ou traduction absente)
	 */
	protected String determineCategorieClientContractant() throws DeliverCustomerOrderFault {
		final String method = "determineCategorieClientContractant";
		final String label = recupererLabelLocalMarketSegmentClientContractant();
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.SEGMENT_MARCHE, label);
		loggerManager.fine(CLASS_NAME, method, "LocalMarketSegmentLabels traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			return label;
		}
		return traduction;
	}

	/**
	 * RG25 Valorisation ParametresLigneCommande
	 * 
	 */
	protected void valorisationParametresLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		String valeurArte = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.FRONTAL, ConstantesTraduction.PARAM_MUT_DSLAM, Constantes.CST_MIGRATE);
		for (LigneCommandeType ligneCde : lignesCommande) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CST_PARAM_CTX_CONTEXTE, valeurArte));
		}
		for (LigneCommandeType ligneCde : fournirListeCommandeSaufLaPremiere(lignesCommande)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.FILTRE_PUBLICATION, FILTRE_IGNORER_LC_PUBLICATION));
		}

	}

	/**
	 * @param lignesCommande les lignes de commande
	 * @return l'ensemble des lignes de commande fournies en param�tre sauf celle qui poss�de une r�f�rence externe �gale au � CustomerOrderItemID � sans concat�nation de Frontal ("la premi�re")
	 */
	private Collection<LigneCommandeType> fournirListeCommandeSaufLaPremiere(Collection<LigneCommandeType> lignesCommande) {
		final Iterator<LigneCommandeType> lcIterator = lignesCommande.iterator();
		final Collection<LigneCommandeType> lcSaufPremiere = new ArrayList<LigneCommandeType>();
		final String customerOrderItemID = customerOrder.getCustomerOrderItem().get(PREMIERE_LC_INDEX).getCustomerOrderItemID();

		LigneCommandeType ligneCommande;
		while (lcIterator.hasNext()) {
			ligneCommande = lcIterator.next();
			if (StringUtils.equals(customerOrderItemID, ligneCommande.getIdLigneCommande())) {
				break;
			}
			lcSaufPremiere.add(ligneCommande);
		}
		while (lcIterator.hasNext()) {
			lcSaufPremiere.add(lcIterator.next());
		}
		return lcSaufPremiere;
	}

	/**
	 * RG26 Valorisation ParametresLigneCommande
	 * 
	 */

	protected void valorisationContexteLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		for (LigneCommandeType ligneCde : lignesCommande) {
			ligneCde.setRefContexteLivraison(Constantes.CST_MUT_DSLAM);
		}
	}

	/**
	 * RG25 Valorisation des champs dynamique LC pour CR_FTTE
	 */
	@Override
	protected void valorisationChampsDynamiquesLC(Collection<LigneCommandeType> lignesCommande) {

		if (lignesCommande.size() > 0) {

			// R�cup�ration de la ligne de commande
			LigneCommandeType lc = lignesCommande.iterator().next();
			lc.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE, ConstantesDeliverCustomerOrder.NON_FT));

			// Helper
			IDeliverCustomerOrderNullHelper helper = deliverCustomerOrderData.getDeliverCustomerOrderNullHelper();

			// Verification de pr�sence des champs n�cessaires aux traitements
			if (helper.hasCouldBeRelatedToTemporarySite() && helper.hasLocalplace()) {

				// R�cup�ration du site
				SiteType site = getSiteOptimum();

				if (site != null) {

					// R�cup�ration du LocalPlace + subAddress + localSiteExternalIdentifier
					LocalPlace localPlace = site.getLocalPlace().get(0);
					LocalSiteExternalIdentifierType localSiteExternalIdentifier = site.getLocalSiteExternalIdentifier();

					if (localSiteExternalIdentifier != null) {

						// Valorisation des champs dynamiques
						List<LocalInstalledResource> localInstalledResource = localPlace.getLocalInstalledResource();
						lc.addParametreLivraison(createParametre(EFBConstantes.IMB, localSiteExternalIdentifier.getExternalID()));
						if (localInstalledResource != null && localInstalledResource.get(0) != null) {
							lc.addParametreLivraison(createParametre(EFBConstantes.PLP_SANS_PT_OID, localInstalledResource.get(0).isLocalExistingInstalledResource() ? Constantes.CST_SHORT_YES : Constantes.CST_SHORT_NO));
						}
					}
				}
			}
		}
	}

	/**
	 * Permet de r�cup�rer le site qui contient la r�f�rence "Optimum"
	 * 
	 * @return le site qui contient la r�f�rence "Optimum"
	 */
	private SiteType getSiteOptimum() {

		List<SiteType> sites = customerOrder.getCouldBeRelatedToTemporarySite().getSite();
		if (sites != null) {
			for (SiteType site : sites) {
				if (site.getLocalSiteExternalIdentifier() != null && OPTIMUM_NAME.equals(site.getLocalSiteExternalIdentifier().getExternalReferentiel().value())) {
					return site;
				}
			}
		}
		return null;
	}

}
