/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.commande.data;

import java.io.Serializable;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * DTO pour les r�sultats de recherche de commandes
 * 
 * @author rgvs7490
 */
public class CommandeSearchResultDTO implements Serializable {

	/**
	 * CommandeSearchResultDTO CLIENT_CONTRACTANT
	 */
	public static final String CLIENT_CONTRACTANT = "clientContractant";
	/**
	 * CommandeSearchResultDTO DATE_CREATION
	 */
	public static final String DATE_CREATION = "dateCreation";
	/**
	 * String DATE_DEBUT_PRISE
	 */
	public static final String DATE_DEBUT_PRISE = "dateDebutPrise";
	/**
	 * String DATE_FIN
	 */
	public static final String DATE_FIN = "dateFin";
	/**
	 * String DATE_VALIDATION
	 */
	public static final String DATE_VALIDATION = "dateValidation";
	/**
	 * CommandeSearchResultDTO ETAT
	 */
	public static final String ETAT = "etat";
	/**
	 * CommandeSearchResultDTO ID
	 */
	public static final String ID = "id";
	/**
	 * String JALON
	 */
	public static final String JALON = "jalon";
	/**
	 * String REFEXTERNE
	 */
	public static final String REFEXTERNE = "refExterne";
	/**
	 * String VENDEUR
	 */
	public static final String VENDEUR = "vendeur";
	/**
	 * String VERSION
	 */
	public static final String VERSION = "version";
	/**
	 * String ZONESI
	 */
	public static final String ZONESI = "zoneSI";
	/**
	 * String STATUT_COMMANDE
	 */
	public static final String STATUT_COMMANDE = "statutCommande";

	private String clientContractant;
	private Date dateCreation;
	private Date dateDebutPrise;
	private Date dateFin;
	private Date dateValidation;
	private String etat;
	private String id;
	private String jalon;
	private String refExterne;
	private String statutCommande;
	private String vendeur;
	private String version;
	private String zoneSI;

	/**
	 * Construit un CommandeSearchResultDTO
	 * 
	 * @param id
	 * @param etat
	 * @param dateCreation
	 * @param clientContractant
	 * @param vendeur
	 * @param dateFin
	 * @param dateValidation
	 * @param refExterne
	 * @param dateDebutPrise
	 * @param version
	 * @param jalon
	 * @param zoneSI
	 * @param statutCommande
	 */
	public CommandeSearchResultDTO(String id, String etat, Date dateCreation, String clientContractant, String vendeur, Date dateFin, Date dateValidation, String refExterne, Date dateDebutPrise, String version, String jalon, String zoneSI,
			String statutCommande) {
		this.id = id;
		this.etat = etat;
		this.dateCreation = dateCreation;
		this.clientContractant = clientContractant;
		this.vendeur = vendeur;
		this.dateFin = dateFin;
		this.dateValidation = dateValidation;
		this.refExterne = refExterne;
		this.dateDebutPrise = dateDebutPrise;
		this.version = version;
		this.jalon = jalon;
		this.zoneSI = zoneSI;
		this.statutCommande = statutCommande;
	}

	/**
	 * @return clientContractant
	 */
	public String getClientContractant() {
		return clientContractant;
	}

	/**
	 * @return dateCreation
	 */
	public Date getDateCreation() {
		return dateCreation;
	}

	/**
	 * @return dateDebutPrise
	 */
	public Date getDateDebutPrise() {
		return dateDebutPrise;
	}

	/**
	 * @return dateFin
	 */
	public Date getDateFin() {
		return dateFin;
	}

	/**
	 * @return dateValidation
	 */
	public Date getDateValidation() {
		return dateValidation;
	}

	/**
	 * @return etat
	 */
	public String getEtat() {
		return etat;
	}

	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return jalon
	 */
	public String getJalon() {
		return jalon;
	}

	/**
	 * @return refExterne
	 */
	public String getRefExterne() {
		return refExterne;
	}

	/**
	 * @return vendeur
	 */
	public String getVendeur() {
		return vendeur;
	}

	/**
	 * @return version
	 */
	public String getVersion() {
		return version;
	}

	/**
	 * @return zoneSI
	 */
	public String getZoneSI() {
		return zoneSI;
	}

	/**
	 * @return statutCommande
	 */
	public String getStatutCommande() {
		return statutCommande;
	}

	/**
	 * @return HashMap representation
	 */
	public Map<String, Object> toHashMap() {
		Map<String, Object> attributes = new HashMap<String, Object>();
		attributes.put(CommandeSearchResultDTO.ID, id);
		attributes.put(CommandeSearchResultDTO.ETAT, etat);
		attributes.put(CommandeSearchResultDTO.DATE_CREATION, dateCreation);
		attributes.put(CommandeSearchResultDTO.CLIENT_CONTRACTANT, clientContractant);
		attributes.put(CommandeSearchResultDTO.VENDEUR, vendeur);
		attributes.put(CommandeSearchResultDTO.DATE_FIN, dateFin);
		attributes.put(CommandeSearchResultDTO.DATE_VALIDATION, dateValidation);
		attributes.put(CommandeSearchResultDTO.REFEXTERNE, refExterne);
		attributes.put(CommandeSearchResultDTO.DATE_DEBUT_PRISE, dateDebutPrise);
		attributes.put(CommandeSearchResultDTO.VERSION, version);
		attributes.put(CommandeSearchResultDTO.JALON, jalon);
		attributes.put(CommandeSearchResultDTO.ZONESI, zoneSI);
		attributes.put(CommandeSearchResultDTO.STATUT_COMMANDE, statutCommande);
		return attributes;
	}
}