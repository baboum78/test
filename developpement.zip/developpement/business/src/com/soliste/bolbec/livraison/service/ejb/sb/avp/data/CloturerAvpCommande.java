/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * Classe de base des commandes de cl�ture d'AVP. Une commande de cl�ture
 * contient les donn�es n�cessaires � la cl�ture de l'AVP. Cette classe constitue
 * �galement la commande de cl^ture des AVPs standards
 * 
 * @author rgvs7490
 */
public class CloturerAvpCommande extends CloturerAvpCommandeAbstract implements Serializable {

	private String tacheId;
	private String info;
	private String causeEvenementId;
	private Date date;
	private WfItemData itemData;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 */
	public CloturerAvpCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData) {
		this.tacheId = tacheId;
		this.info = info;
		this.causeEvenementId = causeEvenementId;
		this.date = date;
		this.itemData = itemData;
	}

	public String getCauseEvenementId() {
		return this.causeEvenementId;
	}

	public Date getDate() {
		return this.date;
	}

	public String getInfo() {
		return this.info;
	}

	public String getTacheId() {
		return this.tacheId;
	}

	public WfItemData getTache() {
		return this.itemData;
	}

	@Override
	public void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande) {

	}
}
