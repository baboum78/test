/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : ReceptionICEFBMessageHandlerBean.java
 *   Revision  : 06_00#1
 *   DateRev   : 14-NOV-2005 14:30:06
 *   Chemin    : ARTE/developpement/uc_adaptateurs/src.ejb/bolbec/adaptateur/efb/ReceptionICEFBMessageHandlerBean.java
 * --------------------------------------------
 *   Historique  : 
 *    Revision 06_00#1 (CREE)
 *      Created:  14-NOV-2005 14:30:06 UDGE5525
 *        Cr ation
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.AdapatateurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.util.AdaptationUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.util.InjectionCdeUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.util.MarshalUtil;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import bolbec.adaptateur.efb.xml.generated.CommandeEfb;

/**
 * The Class ReceptionICEFBMessageHandlerBean.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 * 
 * @author SICOR
 */
public class ReceptionICEFBMessageHandlerBean extends AdapatateurMessageHandlerBean {

	private static final Log LOG = new Log(ReceptionICEFBMessageHandlerBean.class);

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#processMessage(java.io.Serializable, CommandeDTO)
	 */
	public void processMessage(Serializable a_message, CommandeDTO commandeDTO) throws InvalidJmsMessageException {
		long begin = System.currentTimeMillis();
		Map<String, Object> paramFonctNotification = new HashMap<String, Object>();
		paramFonctNotification.put(EFBConstantes.CLE_REF_COMMANDE, commandeDTO.getRefExterne());

		try {
			String l_xmlMsg = getXmlMessage(a_message);
			String instanceLocalisation = getInstanceLocalisation(a_message);
			CommandeEfb l_injectionMsg = MarshalUtil.unmarshalMessageBody(l_xmlMsg);

			LOG.metro("'ReceptionICEFB' ND = ; REFEXTERNE = " + l_injectionMsg.getStructureMetier().getCommande().getRefCommande() + " date = " + begin);

			AdaptationUtil adaptateur = new AdaptationUtil();
			bolbec.injection.xml.generated.Message messageToInject = adaptateur.adapt(l_injectionMsg, paramFonctNotification);
			ServiceManager.getInstance().getLoggerManager().finer(getClass().getName(), "processMessage", "Pas d'exception remont�e par l'adaptateur EFB");

			String xmlMessageToInject = MarshalUtil.marshal(messageToInject);

			HashMap<String, String> mapToInject = new HashMap<String, String>();
			mapToInject.put(Constantes.FIELD_INSTANCE_LOCALISATION, instanceLocalisation);
			mapToInject.put(Constantes.FIELD_MESSAGE, xmlMessageToInject);
			mapToInject.put(Constantes.FIELD_ID_COMMANDE, commandeDTO.getId());

			com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil.inject(mapToInject);
		} catch (ReceptionCdeException rce) {
			ServiceManager.getInstance().getLoggerManager().finer(getClass().getName(), "processMessage", "Traitement de l'exception remont�e par l'adaptateur EFB");
			paramFonctNotification.put(Constantes.FIELD_ID_COMMANDE, commandeDTO.getId());
			InjectionCdeUtil.throwExceptionForAnomalie(rce, paramFonctNotification);
		} finally {
			long end = System.currentTimeMillis();
			String messageMetro = "'ReceptionICEFB' duree = " + (end - begin) + " ms";
			LOG.metro(messageMetro);
		}

	}

	public String getBaliseRefExterne() {
		return "<RefCommande>";
	}

	@Override
	public String getBaliseFin() {
		return "</RefCommande>";
	}

}