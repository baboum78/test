/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.accueil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import aps.RubriqueAccueil;
import aps.RubriqueAccueilHome;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.commun.service.util.jdbc.JdbcUtils;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.jndi.ServiceLocator;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.accueil.data.HistoriqueStatistiqueDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.accueil.data.StatistiqueConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.accueil.data.StatistiqueRegionaleDTO;
import com.soliste.bolbec.livraison.service.model.DrDTO;
import com.soliste.bolbec.livraison.service.model.RubriqueAccueilDTO;
import com.soliste.bolbec.livraison.service.model.StatistiqueDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>02/12/2013</TD><TD>FTE</TD><TD>Ajout d'un finder de r�cup�ration des rubriques tri�es par rang</TD></TR>
 * <TR><TD>11/02/2014</TD><TD>BPE</TD><TD>EV-000276 : G8R2C4 - Mise en place de l'infoTrafic</TD></TR>
 * </TABLE>
 * The Class AccueilManagerBean.
 * 
 * @author rgvs7490
 */
public class AccueilManagerBean extends FwkSessionBean implements AccueilManager {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 313425931563764083L;

	/** The Constant ALIAS_DR. */
	private static final String ALIAS_DR = "dr";

	/** The Constant ALIAS_ID. */
	private static final String ALIAS_ID = "id";

	/** The Constant ALIAS_JOUR. */
	private static final String ALIAS_JOUR = "jour";

	/** The Constant ALIAS_VALEUR. */
	private static final String ALIAS_VALEUR = "valeur";

	/** The Constant LIMITE_HISTORIQUE. */
	private static final int LIMITE_HISTORIQUE = -15;

	/** Pr�fixe InfoTrafic */
	private static final String PREFIXE_INFOTRAFIC_TITRE = "INFOTRAFIC";

	/** The Constant SQL_SELECT_STATISTIQUE_HISTORIQUE. */
	private static final String SQL_SELECT_STATISTIQUE_HISTORIQUE = "SELECT s.id AS " + ALIAS_ID + ", s.jour AS " + ALIAS_JOUR + ", SUM(s.valeur) as " + ALIAS_VALEUR + " FROM Statistique s" + " WHERE s.cle = ? AND s.dr = ? AND s.jour > ? "
			+ " GROUP BY s.dr, s.id, s.jour";

	/** The Constant SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_CLE. */
	private static final int SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_CLE = 1;

	/** The Constant SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_DR. */
	private static final int SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_DR = 2;

	/** The Constant SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_JOUR. */
	private static final int SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_JOUR = 3;

	/** The Constant SQL_SELECT_STATISTIQUE_NATIONALE. */
	private static final String SQL_SELECT_STATISTIQUE_NATIONALE = "SELECT  s.dr AS " + ALIAS_DR + ", s.id AS " + ALIAS_ID + ", s.jour AS " + ALIAS_JOUR + ", SUM(s.valeur) as " + ALIAS_VALEUR + " FROM Statistique s" + " WHERE s.cle = ? AND s.jour < ?"
			+ " GROUP BY s.dr, s.id, s.jour" + " ORDER BY s.jour DESC";

	/** The Constant SQL_SELECT_STATISTIQUE_NATIONALE_INDEX_PARAM_JOUR. */
	private static final int SQL_SELECT_STATISTIQUE_NATIONALE_INDEX_PARAM_JOUR = 2;

	/** The Constant SQL_SELECT_STATISTIQUE_NATIONALE_PARAM_CLE. */
	private static final int SQL_SELECT_STATISTIQUE_NATIONALE_PARAM_CLE = 1;

	/** The Constant SQL_SELECT_STATISTIQUE_REGIONALE. */
	private static final String SQL_SELECT_STATISTIQUE_REGIONALE = "SELECT s.dr AS " + ALIAS_DR + ", s.jour AS " + ALIAS_JOUR + ", SUM(s.valeur) as " + ALIAS_VALEUR + " FROM Statistique s" + " WHERE s.cle = ? AND s.jour < ?" + " GROUP BY s.dr, s.jour"
			+ " ORDER BY s.jour DESC";

	/** The Constant SQL_SELECT_STATISTIQUE_REGIONALE_INDEX_PARAM_JOUR. */
	private static final int SQL_SELECT_STATISTIQUE_REGIONALE_INDEX_PARAM_JOUR = 2;

	/** The Constant SQL_SELECT_STATISTIQUE_REGIONALE_PARAM_CLE. */
	private static final int SQL_SELECT_STATISTIQUE_REGIONALE_PARAM_CLE = 1;

	/** The data source. */
	private DataSource dataSource;

	/** The rubrique accueil home. */
	private RubriqueAccueilHome rubriqueAccueilHome;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#getHistoriqueStatistique(java.lang.String, java.lang.String)
	 */
	public HistoriqueStatistiqueDTO getHistoriqueStatistique(String cle, String dr) {
		Connection connection = null;
		PreparedStatement statement = null;
		ResultSet resuletSet = null;
		GregorianCalendar dateAnterieure = (GregorianCalendar) GregorianCalendar.getInstance();
		dateAnterieure.add(GregorianCalendar.DAY_OF_YEAR, LIMITE_HISTORIQUE);
		Long fifteenDaysBefore = DateUtils.getDatabaseDate(dateAnterieure.getTime().getTime());
		try {
			DrDTO drDTO = null;
			if (!StatistiqueConstantes.TOTAL_DR_NAME.equals(dr)) {
				drDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(DrDTO.class, dr);
			}
			connection = dataSource.getConnection();
			statement = connection.prepareStatement(SQL_SELECT_STATISTIQUE_HISTORIQUE);
			statement.setObject(SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_CLE, cle);
			statement.setObject(SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_DR, dr);
			statement.setObject(SQL_SELECT_STATISTIQUE_HISTORIQUE_INDEX_PARAM_JOUR, fifteenDaysBefore);
			resuletSet = statement.executeQuery();
			List<StatistiqueDTO> result = new ArrayList<StatistiqueDTO>();
			while (resuletSet.next()) {
				String id = resuletSet.getString(ALIAS_ID);
				long jour = resuletSet.getLong(ALIAS_JOUR);
				int valeur = resuletSet.getInt(ALIAS_VALEUR);
				result.add(new StatistiqueDTO(id, cle, jour, valeur, dr));
			}
			return new HistoriqueStatistiqueDTO(drDTO, result);
		} catch (SQLException e) {
			throw new EJBException(e);
		} finally {
			JdbcUtils.closeResultSet(resuletSet);
			JdbcUtils.closeStatement(statement);
			JdbcUtils.closeConnection(connection);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public RubriqueAccueil createRubrique(final RubriqueAccueilDTO rubrique) {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(RubriqueAccueil.FIELD_RANG, rubrique.getRang());
		values.put(RubriqueAccueil.FIELD_TEXTE, rubrique.getTexte());
		values.put(RubriqueAccueil.FIELD_TITRE, rubrique.getTitre());
		try {
			return rubriqueAccueilHome.create(rubrique.getId(), values);
		} catch (CreateException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#getRubrique(java.lang.String)
	 */
	public RubriqueAccueilDTO getRubrique(String id) {
		try {
			RubriqueAccueil rubriqueAccueil = rubriqueAccueilHome.findByPrimaryKey(new EntityBeanPK(id));
			return new RubriqueAccueilDTO(rubriqueAccueil);
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#getRubriques()
	 */
	public List<RubriqueAccueilDTO> getRubriques() {
		try {
			@SuppressWarnings("unchecked")
			Collection<RubriqueAccueil> rubriques = rubriqueAccueilHome.findAll();
			List<RubriqueAccueilDTO> result = new ArrayList<RubriqueAccueilDTO>(rubriques.size());
			String titre;
			for (RubriqueAccueil rubriqueAccueil : rubriques) {
				titre = rubriqueAccueil.getTitre();
				// On ne prend pas en compte la rubrique infoTrafic
				if (titre == null || !titre.startsWith(PREFIXE_INFOTRAFIC_TITRE)) {
					result.add(new RubriqueAccueilDTO(rubriqueAccueil));
				}
			}
			return result;
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#getRubriquesByRang()
	 */
	public List<RubriqueAccueilDTO> getRubriquesSortByRang() {
		try {
			@SuppressWarnings("unchecked")
			Collection<RubriqueAccueil> rubriques = rubriqueAccueilHome.findAndSortByRang();
			List<RubriqueAccueilDTO> result = new ArrayList<RubriqueAccueilDTO>(rubriques.size());
			String titre;
			for (RubriqueAccueil rubriqueAccueil : rubriques) {
				titre = rubriqueAccueil.getTitre();
				// On ne prend pas en compte la rubrique infoTrafic
				if (titre == null || !titre.startsWith(PREFIXE_INFOTRAFIC_TITRE)) {
					result.add(new RubriqueAccueilDTO(rubriqueAccueil));
				}
			}
			return result;
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#findRubriquesByTitre(String)
	 */
	public List<RubriqueAccueilDTO> findRubriquesByTitre(final String titre) {
		try {
			@SuppressWarnings("unchecked")
			Collection<RubriqueAccueil> rubriques = rubriqueAccueilHome.findRubriqueByTitre(titre);
			List<RubriqueAccueilDTO> result = new ArrayList<RubriqueAccueilDTO>(rubriques.size());
			for (RubriqueAccueil rubriqueAccueil : rubriques) {
				result.add(new RubriqueAccueilDTO(rubriqueAccueil));
			}
			return result;
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#getStatistiquesNationales()
	 */
	public List<StatistiqueDTO> getStatistiquesNationales() {
		Connection connection = null;
		try {
			List<StatistiqueDTO> statistiquesNationales = new ArrayList<StatistiqueDTO>();
			connection = dataSource.getConnection();
			for (Iterator<String> iCles = StatistiqueConstantes.STATISTIQUES_ACCUEIL_CLES.iterator(); iCles.hasNext();) {
				String cle = iCles.next();
				addStatistiqueNationale(connection, cle, statistiquesNationales);
			}
			return statistiquesNationales;
		} catch (SQLException e) {
			throw new EJBException(e);
		} finally {
			JdbcUtils.closeConnection(connection);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#getStatistiquesRegionales()
	 */
	public List<StatistiqueRegionaleDTO> getStatistiquesRegionales() {
		Connection connection = null;
		try {
			List<StatistiqueRegionaleDTO> statistiquesRegionales = new ArrayList<StatistiqueRegionaleDTO>();
			connection = dataSource.getConnection();
			Iterator<String> iCles = StatistiqueConstantes.STATISTIQUES_ACCUEIL_CLES.iterator();
			while (iCles.hasNext()) {
				String cle = iCles.next();
				addStatistiqueRegionale(connection, cle, statistiquesRegionales);
			}
			return statistiquesRegionales;
		} catch (SQLException e) {
			throw new EJBException(e);
		} finally {
			JdbcUtils.closeConnection(connection);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#modifyRubrique(java.lang.String, java.lang.String)
	 */
	public void modifyRubrique(String id, String texte) {
		try {
			RubriqueAccueil rubrique = rubriqueAccueilHome.findByPrimaryKey(new EntityBeanPK(id));
			rubrique.setTexte(texte);
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.accueil.AccueilManager#modifyRubrique(java.lang.String, java.lang.String, java.lang.String)
	 */
	public void modifyRubrique(String id, String titre, String texte) {
		try {
			RubriqueAccueil rubrique = rubriqueAccueilHome.findByPrimaryKey(new EntityBeanPK(id));
			rubrique.setTexte(texte);
			rubrique.setTitre(titre);
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			rubriqueAccueilHome = getEntityHome(RubriqueAccueilHome.class);
			dataSource = ServiceLocator.getInstance().getDataSource(Constantes.DATASOURCE_NAME);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Adds the statistique nationale.
	 * 
	 * @param connection the connection
	 * @param cle the cle
	 * @param statistiauesNationales the statistiaues nationales
	 */
	private void addStatistiqueNationale(Connection connection, String cle, List<StatistiqueDTO> statistiauesNationales) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Long today = DateUtils.getDatabaseDate();
		try {
			statement = connection.prepareStatement(SQL_SELECT_STATISTIQUE_NATIONALE);
			statement.setObject(SQL_SELECT_STATISTIQUE_NATIONALE_PARAM_CLE, cle);
			statement.setObject(SQL_SELECT_STATISTIQUE_NATIONALE_INDEX_PARAM_JOUR, today);
			resultSet = statement.executeQuery();
			List<String> clesTraitees = new ArrayList<String>();
			while (resultSet.next()) {
				String id = resultSet.getString(ALIAS_ID);
				long jour = resultSet.getLong(ALIAS_JOUR);
				int valeur = resultSet.getInt(ALIAS_VALEUR);
				String dr = resultSet.getString(ALIAS_DR);
				if (StatistiqueConstantes.TOTAL_DR_NAME.equals(dr) && !clesTraitees.contains(cle)) {
					statistiauesNationales.add(new StatistiqueDTO(id, cle, jour, valeur, dr));
					clesTraitees.add(cle);
				}
			}
		} catch (SQLException e) {
			throw new EJBException(e);
		} finally {
			JdbcUtils.closeResultSet(resultSet);
			JdbcUtils.closeStatement(statement);
		}
	}

	/**
	 * Adds the statistique regionale.
	 * 
	 * @param connection the connection
	 * @param cle the cle
	 * @param statistiquesRegionales the statistiques regionales
	 */
	private void addStatistiqueRegionale(Connection connection, String cle, List<StatistiqueRegionaleDTO> statistiquesRegionales) {
		PreparedStatement statement = null;
		ResultSet resultSet = null;
		Long today = DateUtils.getDatabaseDate();
		try {
			statement = connection.prepareStatement(SQL_SELECT_STATISTIQUE_REGIONALE);
			statement.setObject(SQL_SELECT_STATISTIQUE_REGIONALE_PARAM_CLE, cle);
			statement.setObject(SQL_SELECT_STATISTIQUE_REGIONALE_INDEX_PARAM_JOUR, today);
			resultSet = statement.executeQuery();
			List<String> drTraitees = new ArrayList<String>();
			while (resultSet.next()) {
				Long jour = resultSet.getLong(ALIAS_JOUR);
				Integer valeur = resultSet.getInt(ALIAS_VALEUR);
				String dr = resultSet.getString(ALIAS_DR);
				if (!drTraitees.contains(dr)) {
					if (!StatistiqueConstantes.TOTAL_DR_NAME.equals(dr)) {
						if (statistiquesRegionales.size() == 0) {
							DrDTO drDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(DrDTO.class, dr);
							StatistiqueRegionaleDTO statRegionale = new StatistiqueRegionaleDTO(cle, valeur, drDTO, jour);
							statistiquesRegionales.add(statRegionale);
						} else {
							int index = 0;
							boolean filled = false;
							while ((index < statistiquesRegionales.size()) && (!filled)) {
								StatistiqueRegionaleDTO stat = statistiquesRegionales.get(index);
								if (stat.getDr().getId().equals(dr)) {
									stat.putValeurParCle(cle, valeur);
									stat.setJour(DateUtils.getDatabaseDate(jour));
									filled = true;
								} else {
									index++;
								}
							}
							if (!filled) {
								DrDTO drDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(DrDTO.class, dr);
								StatistiqueRegionaleDTO statRegionale = new StatistiqueRegionaleDTO(cle, valeur, drDTO, jour);
								statistiquesRegionales.add(statRegionale);
							}
						}
					}
					drTraitees.add(dr);
				}
			}
		} catch (SQLException e) {
			throw new EJBException(e);
		} finally {
			JdbcUtils.closeResultSet(resultSet);
			JdbcUtils.closeStatement(statement);
		}
	}
}