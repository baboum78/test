package com.soliste.bolbec.livraison.service.ejb.sb.avp;

import java.util.Date;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.CloturerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.DiffererAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.ReassignerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.RerouterAvpException;
import com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory.Action;
import com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory.GroupeCodeCR;

/**
 * Interface metier de l'ejb <code>AvpManagerSB</code><br/>
 * Permet de rechercher des entit�es li�es � aux AVP
 * Interface repr�sentant le Business Interface pattern
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>25/04/2013</TD><TD>GPA</TD><TD>G8R2C2 : Suppression du doublon sur le MG_ClotureTache</TD></TR>
 * <TR><TD>06/03/2017</TD><TD>JDE</TD><TD>G9R2C1 : Ajout de la m�thode de publication de CR EFB (notamment pour les t�ches manuelles)</TD></TR>
 * </TABLE>
 */
public interface AvpManager {

	/**
	 * Abandonne l'AVP ou la t�che manuelle donn�(e)
	 * 
	 * @param commande
	 * les donn�es n�cessaires � la cloture
	 * @param wfUser
	 * @throws CloturerAvpException
	 * si l'AVP n'a pu �tre clotur�. L'exception contient la cl� du
	 * message � pr�senter
	 */
	public void cloturerAvp(CloturerAvpCommande commande, WfUser wfUser) throws CloturerAvpException;

	/**
	 * Diff�re l'AVP ou la t�che manuelle donn�(e)
	 * 
	 * @param tacheId
	 * l'identifiant de la t�che
	 * @param info
	 * le texte de l'�v�nement
	 * @param causeEvenementId
	 * la cause de l'�v�nement
	 * @param idCurrentAgent
	 * Identifiant de l'agent
	 * @param date
	 * la date
	 * @param wfActivity
	 * les donn�es m�tier de l'AVP
	 * @throws DiffererAvpException
	 * si l'AVP n'a pu �tre diff�r�. L'exception contient la cl� du
	 * message � pr�senter
	 */
	public void differerAvp(String tacheId, String info, String causeEvenementId, String idCurrentAgent, Date date, WfActivity wfActivity) throws DiffererAvpException;

	/**
	 * Reroute l'AVP ou la t�che manuelle donn�(e)
	 * 
	 * @param tacheId
	 * l'identifiant de la t�che
	 * @param info
	 * le texte de l'�v�nement
	 * @param causeEvenementId
	 * la cause de l'�v�nement
	 * @param zoneGeographiqueId
	 * la zone g�ographique
	 * @param wfActivity
	 * le wfActivity de l'AVP
	 * @param agent
	 * @throws RerouterAvpException
	 * si l'AVP n'a pu �tre rerout�. L'exception contient la cl� du
	 * message � pr�senter
	 */
	public void rerouterAvp(String tacheId, String info, String causeEvenementId, String zoneGeographiqueId, WfActivity wfActivity, AgentDTO agent) throws RerouterAvpException;

	/**
	 * R�assigne l'AVP ou la t�che manuelle donn�(e)
	 * 
	 * @param tacheId
	 * l'identifiant de la t�che
	 * @param info
	 * le texte de l'�v�nement
	 * @param causeEvenementId
	 * la cause de l'�v�nement
	 * @param roleId
	 * le role
	 * @param idCurrentAgent
	 * Identifiant de l'agent
	 * @param wfActivity
	 * le wfActivity de l'AVP
	 * @param agent
	 * l'agent qui effectue la r�assignation
	 * @throws ReassignerAvpException
	 * si l'AVP n'a pu �tre r�assign�. L'exception contient la cl�
	 * du message � pr�senter
	 */
	public void reassignerAvp(String tacheId, String info, String causeEvenementId, String roleId, String idCurrentAgent, WfActivity wfActivity, AgentDTO agent) throws ReassignerAvpException;

	/**
	 * M�thode de publication de CR vers EFB (utilis�e aussi pour les t�ches manuelles)
	 * 
	 * @param groupeCodeCR
	 * @param idTacheEnCours
	 * @param actionIHM
	 * @param idEvt
	 */
	public void publierCrEfb(GroupeCodeCR groupeCodeCR, String idTacheEnCours, Action actionIHM, String idEvt);
}
