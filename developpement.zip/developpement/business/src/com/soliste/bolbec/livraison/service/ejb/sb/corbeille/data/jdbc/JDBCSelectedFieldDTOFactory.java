/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedFieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedFieldDTOFactory;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;

/**
 * 
 * Factory pour SelectedFieldDTO JDBC
 * 
 * @author gdzd8490
 * 
 */
public class JDBCSelectedFieldDTOFactory implements SelectedFieldDTOFactory {

	private static JDBCSelectedFieldDTOFactory instance = null;

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static JDBCSelectedFieldDTOFactory getInstance() {
		if (instance == null) {
			instance = new JDBCSelectedFieldDTOFactory();
		}
		return instance;
	}

	private JDBCSelectedFieldDTOFactory() {
		// pour �viter instanciation inutile
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedFieldDTOFactory#createSelectedField(java.lang.String)
	 */
	public SelectedFieldDTO createSelectedField(String id) {
		SelectedFieldDTO dto = null;
		JDBCField jdbcField = (JDBCField) JDBCCorbeilleTranslator.getInstance().translate(id);
		String jdbcFieldName = jdbcField.getFullyQualifiedName();
		SelectedField field = new JDBCSelectedField(jdbcFieldName);
		dto = new SelectedFieldDTO();
		dto.setSelectedField(field);
		return dto;
	}
}
