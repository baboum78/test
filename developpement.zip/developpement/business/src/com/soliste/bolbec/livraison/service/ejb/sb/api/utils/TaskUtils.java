package com.soliste.bolbec.livraison.service.ejb.sb.api.utils;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfException;
import com.soliste.aps.workflow.xpm.wfsessionin.ConstantesXPM;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.CancellingType;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCause;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCauseRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Role;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.TaskData;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpActivCommutCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpAffBLOCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpAffBLOImmNonTrouve;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpAffTHDCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpAffectationXdslCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCompComCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpControleAffCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCorrectionAdresseCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCtrlCoherenceCmdCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpMajParcMaterielCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpNouvelleBoucle;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpOpeImbAbs;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfTache;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.CauseEvenementUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.AvpInfoDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CloturerTacheManuelleCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.TacheManuelleDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.TacheManuelleDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowLoadDTO;
import com.soliste.bolbec.livraison.service.exception.TaskValidationException;
import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ParamAVPKEYDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.CauseEvenement;
import aps.CauseEvenementConstantes;
import aps.ParamAVPKEY;

public class TaskUtils {

	private static final String TREATMENT_NAME = "TreatmentName";
	private static final String MANUELLE = "MANUELLE";
	private static final String IMB = "Imb";

	private static final int MAX_IMB_SIZE = 30;

	protected static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	/**
	 * Fonction utilitaire permettant de savoir si la cause r�cup�r�e de cl�ture de la t�che est
	 * bien dans la liste des causes de cl�ture possible.
	 * 
	 * @param causeEvenements
	 * @param eventCauseRef
	 * @return true si la cause r�cup�r�e de cl�ture de la t�che est bien dans la liste des causes de cl�ture possible
	 */

	public static boolean estDansListeCausePossiblePourCloturer(List<EventCause> causeEvenements, EventCauseRef eventCauseRef) {
		for (EventCause causelst : causeEvenements) {
			if (causelst.getId().equals(eventCauseRef.getId())) { // eventCauseRef.getId() n'est jamais null
				return true;
			}
		}
		return false;
	}

	/**
	 * Fonction utilitaire permettant de retourner l'eventCause en fonction des causes �v�nements disponibles,
	 * selon le type d'evenement et le CancellingType.
	 * 
	 * @param causeEvenements
	 * @param type
	 * @return
	 */
	public static EventCause initialiserEventCause(CauseEvenementDTO causeEvenements, String TypeEvenement, CancellingType type) {

		EventCause event = new EventCause();
		event.setId(causeEvenements.getValeurConstante());
		event.setLabel(causeEvenements.getLibelle());
		if (TypeEvenement.equals(causeEvenements.getTypeEvenement().getId())) {
			event.setCancellingType(type);
		}
		return event;

	}

	/**
	 * Ev 362 PLP Fibre sans RDV : cl�ture d'une tache manuelle
	 *
	 * @param itemData
	 * @return
	 */
	public static CloturerTacheManuelleCommande createTacheManuelleCommande(String tacheId, String tacheType, WfItemData itemData) {
		if (TacheManuelleDTO.TACHE_MANUELLE_STANDARD_TYPE.equals(tacheType)) {
			return new CloturerTacheManuelleCommande(tacheId, itemData);
		}

		throw new RuntimeException("Type de t�che inconnu: " + tacheType);
	}

	/**
	 * Initialise toutes les cl�s en fonction du type de l'AVP concern�
	 *
	 * @param datas
	 * @param typeAvp
	 * 
	 */
	private static DataToSet initDatas(List<TaskData> datas, String typeAvp) throws TaskValidationException {
		List<ParamAVPKEYDTO> listeCles = getParamAVPKEYofTypeAVP(typeAvp);

		HashMap<String, String> mapTmp = new HashMap();

		for (TaskData data : datas) {
			mapTmp.put(data.getKey(), data.getValue());
		}

		DataToSet dataToSet = new DataToSet();

		for (ParamAVPKEYDTO cle : listeCles) {
			String cleArtemis = cle.getCleArtemis();
			if (cleArtemis.equals(DataToSet.CODE_IMMEUBLE)) {
				String imb = mapTmp.get(DataToSet.CODE_IMMEUBLE);
				if(imb != null && imb.length() > MAX_IMB_SIZE){
					throw new TaskValidationException(IMB ,String.valueOf(MAX_IMB_SIZE));
				} else {
					dataToSet.setImmeuble(mapTmp.get(DataToSet.CODE_IMMEUBLE));
				}
			} else if (cleArtemis.equals(DataToSet.CODE_BATIMENT)) {
				dataToSet.setBatiment(mapTmp.get(DataToSet.CODE_BATIMENT));
			} else if (cleArtemis.equals(DataToSet.CODE_ESCALIER)) {
				dataToSet.setEscalier(mapTmp.get(DataToSet.CODE_ESCALIER));
			} else if (cleArtemis.equals(DataToSet.CODE_ETAGE)) {
				dataToSet.setEtage(mapTmp.get(DataToSet.CODE_ETAGE));
			} else if (cleArtemis.equals(DataToSet.CODE_CPL_VOIE)) {
				dataToSet.setCplVoie(mapTmp.get(DataToSet.CODE_CPL_VOIE));
			} else if (cleArtemis.equals(DataToSet.CODE_NUM_VOIE)) {
				dataToSet.setNumVoie(mapTmp.get(DataToSet.CODE_NUM_VOIE));
			} else if (cleArtemis.equals(DataToSet.CODE_RIVOLI)) {
				dataToSet.setCodeRivoli(mapTmp.get(DataToSet.CODE_RIVOLI));
			} else if (cleArtemis.equals(DataToSet.CODE_CODE_INSEE)) {
				dataToSet.setCodeInsee(mapTmp.get(DataToSet.CODE_CODE_INSEE));
			} else if (cleArtemis.equals(DataToSet.CODE_PTO)) {
				dataToSet.setIdPTO(mapTmp.get(DataToSet.CODE_PTO));
			} else if (cleArtemis.equals(DataToSet.CODE_PRISE_EXISTANTE)) {
				dataToSet.setPriseExist(mapTmp.get(DataToSet.CODE_PRISE_EXISTANTE));
			} else if (cleArtemis.equals(DataToSet.CODE_OPE_IMMEUBLE)) {
				dataToSet.setOpImb(mapTmp.get(DataToSet.CODE_OPE_IMMEUBLE));
			} else if (cleArtemis.equals(DataToSet.CODE_CENTRE)) {
				dataToSet.setCentre(mapTmp.get(DataToSet.CODE_CENTRE));
			} else if (cleArtemis.equals(DataToSet.CODE_REGLETTE)) {
				dataToSet.setReglette(mapTmp.get(DataToSet.CODE_REGLETTE));
			} else if (cleArtemis.equals(DataToSet.CODE_BROCHE)) {
				dataToSet.setBroche(mapTmp.get(DataToSet.CODE_BROCHE));
			} else if (cleArtemis.equals(DataToSet.CODE_VC_OPER)) {
				dataToSet.setVcOper(mapTmp.get(DataToSet.CODE_VC_OPER));
			} else if (cleArtemis.equals(DataToSet.CODE_VC_CIBLE)) {
				dataToSet.setVcCible(mapTmp.get(DataToSet.CODE_VC_CIBLE));
			} else if (cleArtemis.equals(DataToSet.CODE_VOIE)) {
				dataToSet.setVoie(mapTmp.get(DataToSet.CODE_VOIE));
			} else if (cleArtemis.equals(DataToSet.CODE_ENSEMBLE)) {
				dataToSet.setEns(mapTmp.get(DataToSet.CODE_ENSEMBLE));
			} else if (cleArtemis.equals(DataToSet.CODE_PORTE)) {
				dataToSet.setPorte(mapTmp.get(DataToSet.CODE_PORTE));
			} else if (cleArtemis.equals(DataToSet.CODE_LOGO)) {
				dataToSet.setLogo(mapTmp.get(DataToSet.CODE_LOGO));
			} else if (cleArtemis.equals(DataToSet.CODE_NDPLP)) {
				dataToSet.setNdplp(mapTmp.get(DataToSet.CODE_NDPLP));
			} else if (cleArtemis.equals(DataToSet.CODE_NOM_OLT)) {
				dataToSet.setNomOlt(mapTmp.get(DataToSet.CODE_NOM_OLT));
			} else if (cleArtemis.equals(DataToSet.CODE_CHASS_OLT)) {
				dataToSet.setChassOlt(mapTmp.get(DataToSet.CODE_CHASS_OLT));
			} else if (cleArtemis.equals(DataToSet.CODE_CARTE_OLT)) {
				dataToSet.setCarteOlt(mapTmp.get(DataToSet.CODE_CARTE_OLT));
			} else if (cleArtemis.equals(DataToSet.CODE_PORT_OLT)) {
				dataToSet.setPortOlt(mapTmp.get(DataToSet.CODE_PORT_OLT));
			} else if (cleArtemis.equals(DataToSet.CODE_VILLE)) {
				dataToSet.setVille(mapTmp.get(DataToSet.CODE_VILLE));
			} else if (cleArtemis.equals(DataToSet.CODE_TYPE_VOIE)) {
				dataToSet.setTypeVoie(mapTmp.get(DataToSet.CODE_TYPE_VOIE));
			} else if (cleArtemis.equals(DataToSet.CODE_ACTIVE)) {
				dataToSet.setActiv(mapTmp.get(DataToSet.CODE_ACTIVE));
			} else if (cleArtemis.equals(DataToSet.CODE_PROD)) {
				dataToSet.setProd(mapTmp.get(DataToSet.CODE_PROD));
			}
		}
		return dataToSet;
	}

	/**
	 * 
	 * @param proprietesWorkflow
	 * @param date
	 * @param itemData
	 * @param idTache
	 * @param info
	 * @param causeEvenementId
	 * @return
	 */

	public static CloturerAvpCommande createCommande(Map<String, String> proprietesWorkflow, Date date, WfItemData itemData, String idTache, String info, String causeEvenementId, List<TaskData> datas, List<LigneCommandeDTO> listeLigneCommande) throws TaskValidationException {
		String typeAVP = proprietesWorkflow.get(TREATMENT_NAME);
		CloturerAvpCommande commande = null;

		if (AvpInfoDTO.AVP_STANDARD_TYPE.equals(typeAVP)) {
			commande = new CloturerAvpCommande(idTache, info, causeEvenementId, date, itemData);
		} else if (AvpInfoDTO.AVP_AFFECTATION_XDSL_TYPE.equals(proprietesWorkflow.get(ConstantesXPM.WF_ATTRIBUTE_TREATMENT))) {
			commande = new CloturerAvpAffectationXdslCommande(idTache, info, causeEvenementId, date, itemData);
		} else if (AvpInfoDTO.AVP_COMP_COM_TYPE.equals(typeAVP)) {
			commande = new CloturerAvpCompComCommande(idTache, info, causeEvenementId, date, itemData, null);
		} else if (AvpInfoDTO.AVP_CONTROLE_AFF_TYPE.equals(typeAVP)) {
			commande = new CloturerAvpControleAffCommande(idTache, info, causeEvenementId, date, itemData);
		} else if (AvpInfoDTO.AVP_MAJ_PARC_MATERIEL_TYPE.equals(typeAVP)) {
			commande = new CloturerAvpMajParcMaterielCommande(idTache, info, causeEvenementId, date, itemData, null);
		} else if (AvpInfoDTO.AVP_CORRECTION_ADRESSE.equals(typeAVP)) {
			commande = new CloturerAvpCorrectionAdresseCommande(idTache, info, causeEvenementId, date, itemData);
		} else if (AvpInfoDTO.AVP_AFFECTATION_NV_BL_TYPE.equals(typeAVP)) {
			commande = new CloturerAvpNouvelleBoucle(idTache, info, causeEvenementId, date, itemData);
		} else if (AvpInfoDTO.AVP_AFF_BLO.equals(typeAVP)) {
			if (CauseEvenementConstantes.IPON_IMMEUBLE_NON_TROUVE.equals(proprietesWorkflow.get(Constantes.RS_IDCAUSEEVT))) {
				commande = new CloturerAvpAffBLOImmNonTrouve(idTache, info, causeEvenementId, date, itemData);
			} else {
				commande = new CloturerAvpAffBLOCommande(idTache, info, causeEvenementId, date, itemData);
			}
		} else if (AvpInfoDTO.AVP_CTRL_COHERENCE_CMD.equals(typeAVP)) {
			commande = new CloturerAvpCtrlCoherenceCmdCommande(idTache, info, causeEvenementId, date, itemData);
		} else if (AvpInfoDTO.AVP_EVT_ABSENT.equals(typeAVP)) {
			commande = new CloturerAvpActivCommutCommande(idTache, info, causeEvenementId, date, itemData, "");
		} else if (AvpInfoDTO.AVP_AFF_THD.equals(typeAVP)) {
			commande = new CloturerAvpAffTHDCommande(idTache, info, causeEvenementId, date, itemData, datas);
		} else if (AvpInfoDTO.AVP_OPE_IMB_ABS.equals(typeAVP)){
			commande = new CloturerAvpOpeImbAbs(idTache, info, causeEvenementId, date, itemData);
		} else if (typeAVP.startsWith("AVP")) {
			commande = new CloturerAvpCommande(idTache, info, causeEvenementId, date, itemData);
		}

		DataToSet dataToSet = null;
		if (datas != null) {
			dataToSet = initDatas(datas, typeAVP);
		}

		if (commande != null) {
			commande.setDatas(dataToSet, listeLigneCommande);
			return commande;
		} else {
			throw new RuntimeException("Type d'AVP inconnu: " + typeAVP);
		}
	}

	/**
	 * Permet d'obtenir le WkfActivity � partir du workflowDTO et de l'id de l'�v�nement qui a engendr� la t�che
	 * 
	 * @param wkf
	 * @param tache
	 * @return
	 */
	// TODO G10 : Nettoyage XPM
	public static WfActivity recupererWfActivityViaTache(WorkflowLoadDTO wkf, TacheDTO tache) {
		List<WfActivity> wkfActList = wkf.getLoadedElements();
		if (wkfActList != null) {
			// Recherche par l'id workflow
			if (tache.getIdExterne() != null) {
				for (WfActivity wkfActlst : wkfActList) {
					if (wkfActlst.getId().equals(tache.getIdExterne())) {
						return wkfActlst;
					}
				}
			}

			// Recherche par l'evt
			if (tache.getEvt() != null) {
				for (WfActivity wkfActlst : wkfActList) {
					if (wkfActlst.getDynamicAttribute(Constantes.RS_DATA2).equals(tache.getEvt().getId())) {
						return wkfActlst;
					}
				}
			}

			// Pour les t�ches manuelles sans evt
			CatalogueTacheDTO catalogueTache = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tache.getCatalogueTache().getId());
			if (MANUELLE.equals(catalogueTache.getType())) {
				for (WfActivity wkfActlst : wkfActList) {
					if (wkfActlst.getId().equals(tache.getIdExterne())) {
						if (tache.getEsd() != null) {
							if (wkfActlst.getDynamicAttribute(Constantes.RS_EARLIEST_START_DATE).equals(String.valueOf(tache.getEsd()))) {
								return wkfActlst;
							}
						}
					}
				}
			}
		}
		// Si on ne trouve rien
		return null;
	}

	/**
	 * Initialisation de l'eventCauseRef � partir de l'�v�nement de la t�che.
	 * 
	 * @param evtTache
	 * @param eventCauseRefTache
	 * @return
	 */

	public static EventCauseRef initialiserEventCauseRef(EvtDTO evtTache, EventCauseRef eventCauseRefTache) {
		if (evtTache != null) {
			if (evtTache.getCauseEvenement() != null) {
				// CauseEvenementDTO causeEvtDTO = evtTache.getCauseEvenement();
				CauseEvenementDTO causeEvenement = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evtTache.getCauseEvenement().getId());
				// Initialisation de l'EventCauseRef
				if (StringUtils.isNotBlank(causeEvenement.getId())) {

					eventCauseRefTache.setId(causeEvenement.getValeurConstante());
				}
				if (StringUtils.isNotBlank(evtTache.getInfo())) {
					eventCauseRefTache.setComment(evtTache.getInfo());
				}
			}
		}

		return eventCauseRefTache;
	}

	/**
	 * Retourne la liste des causes �v�nements s�lectionnables pour clore la t�che manuelle en param�tre
	 * 
	 * @param tache la t�che manuelle pour laquelle on recherche les causes �v�nements de cloture
	 * @return la liste des causes �v�nements s�lectionnables pour clore la t�che manuelle en param�tre
	 */
	public static List<EventCause> getCauseEvenementAutoriseesPourTacheMan(TacheDTO tache) {
		List<EventCause> eventlst = new ArrayList<EventCause>();

		// On r�cup�re le type de la t�che manuelle (standard, d�crochage, completude, ...)
		String tacheManType = TacheManuelleDTOFactory.getCorrespondanceType(tache);

		// Si c'est une t�che manuelle standard on a une seule cause �v�nement de cloture : VALIDATE
		if (TacheManuelleDTO.TACHE_MANUELLE_STANDARD_TYPE.equals(tacheManType)) {
			List<CauseEvenementDTO> causeEvts = getCauseEvenementClotureAPI();
			for (CauseEvenementDTO causeEvt : causeEvts) {
				EventCause event = new EventCause();
				event.setId(causeEvt.getLibelle());
				event.setLabel(Constantes.TACHE_MANUELLE_STANDARD_LABEL);
				eventlst.add(event);
			}
		}

		// Si ce n'est pas une t�che manuelle Standard on retourne une liste vide
		return eventlst;
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour cloturer un AVP.
	 *
	 * @param wftache wftache
	 * 
	 * @return une liste d'instances d EventCause
	 * @throws DataException
	 */
	public static List<EventCause> getCauseEvenementAutoriseesPourCloturer(WfTache wftache) throws DataException {
		List<CauseEvenementDTO> causeEvenements;
		causeEvenements = CauseEvenementUtil.getCauseEvenementAutoriseesPourCloturer(wftache);
		// Init de l'EventCause
		List<EventCause> eventlst = new ArrayList<EventCause>();
		for (CauseEvenementDTO causeEvenementlst : causeEvenements) {
			EventCause event = TaskUtils.initialiserEventCause(causeEvenementlst, causeEvenementlst.getTypeEvenement().getId(), CancellingType.taskClosure);
			eventlst.add(event);
		}
		return eventlst;
	}

	/**
	 * Gets the cause evenement autorisees pour categorie.
	 * 
	 * @param categorie the categorie
	 * @param version the version
	 * 
	 * @return the cause evenement autorisees pour categorie
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourCategorie(String categorie, String version) {
		List<CauseEvenementDTO> result = new ArrayList<CauseEvenementDTO>();
		List<CauseEvenementDTO> causesEvenement = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(CauseEvenementDTO.class, new Comparaison(CauseEvenement.FIELD_VERSION, Constantes.OPERATOR_EQUAL, version));
		// Filtrage par typeEvenement (en dehors du premier filtrage car il s'agit de v�rifier la pr�sence dans une liste !)
		for (CauseEvenementDTO causeEvenement : causesEvenement) {
			TypeEvenementDTO typeEvenement = causeEvenement.getTypeEvenement();
			if (typeEvenement.getCategorieEvenement() != null && categorie.equals(typeEvenement.getCategorieEvenement().getId())) {
				result.add(causeEvenement);
			}
		}
		return result;
	}

	/**
	 * A partir du workflow WfTache, permet de tester si le role en param�tre appartient � la liste de r�les obtenus
	 * 
	 * @param wfTache
	 * @param role
	 * @return
	 */
	public static boolean estUnRolePourReassigner(WfTache wfTache, String role) {

		Map<String, List<String>> staticAttributes;
		List<String> roleIds;
		try {

			staticAttributes = wfTache.getWfObject().getStaticAttributes();
			roleIds = staticAttributes.get(WorkflowConstantes.ROLES_POSSIBLES);
		} catch (WfException e) {
			throw APIExceptionEnum.taskwkfactivitynull.createAPIException();
		}

		return roleIds.contains(role);
	}

	/**
	 * A partir du workflow WfTache, permet d'obtenir la liste de r�le
	 * 
	 * @param wfTache
	 * @return
	 */
	public static List<Role> getRoles(WfTache wfTache) {
		Map<String, List<String>> staticAttributes;
		List<String> roleIds;
		List<Role> roleList = new ArrayList<Role>();
		RoleDTO role;

		try {
			staticAttributes = wfTache.getWfObject().getStaticAttributes();
			roleIds = staticAttributes.get(WorkflowConstantes.ROLES_POSSIBLES);
			for (String roleid : roleIds) {
				Role roleAPI = new Role();
				role = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RoleDTO.class, roleid);
				roleAPI.setId(role.getId());
				roleAPI.setLabel(role.getLibelle());
				roleList.add(roleAPI);
			}
		} catch (WfException e) {
			throw APIExceptionEnum.taskwkfactivitynull.createAPIException();
		}

		return roleList;
	}

	private static List<CauseEvenementDTO> getCauseEvenementClotureAPI() {
		return SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(CauseEvenementDTO.class, new Comparaison(CauseEvenement.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_LIKE, Constantes.CLOTURE_API));
	}

	/**
	 * Return a list of ParamAVPKEYDTO which contains the typeAVP in parameter
	 *
	 * @param typeAVP the typeAVP needed in ParamAVPKEYDTO
	 * @return list of ParamAVPKEYDTO
	 */
	private static List<ParamAVPKEYDTO> getParamAVPKEYofTypeAVP(String typeAVP) {
		return SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(ParamAVPKEYDTO.class, new Comparaison(ParamAVPKEY.FIELD_TYPE_A_V_P, Constantes.OPERATOR_EQUAL, typeAVP));
	}
}
