/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;
import java.util.List;

import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * 
 * @author rgvs7490
 */
public class SousProcessusDTO implements Serializable {

	private ProcessusDTO papaProcessus;
	private TacheDTO phase;
	private ProcessusDTO sousProcessus;
	private List<TacheDTO> taches;

	/**
	 * 
	 */
	SousProcessusDTO() {
	}

	public ProcessusDTO getPapaProcessus() {
		return this.papaProcessus;
	}

	void setPapaProcessus(ProcessusDTO papaProcessus) {
		this.papaProcessus = papaProcessus;
	}

	public TacheDTO getPhase() {
		return this.phase;
	}

	void setPhase(TacheDTO phase) {
		this.phase = phase;
	}

	public ProcessusDTO getSousProcessus() {
		return this.sousProcessus;
	}

	void setSousProcessus(ProcessusDTO sousProcessus) {
		this.sousProcessus = sousProcessus;
	}

	public List<TacheDTO> getTaches() {
		return this.taches;
	}

	void setTaches(List<TacheDTO> taches) {
		this.taches = taches;
	}
}
