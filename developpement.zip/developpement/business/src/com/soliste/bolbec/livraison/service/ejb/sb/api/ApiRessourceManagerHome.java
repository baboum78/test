package com.soliste.bolbec.livraison.service.ejb.sb.api;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 * Interface home de l'EJB session ApiRessourceManager.
 * 
 * @author mfayd
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>27/11/2014</TD><TD>MFA</TD><TD>Initialisation</TD></TR>
 * </TABLE>
 */
public interface ApiRessourceManagerHome extends EJBLocalHome {

	/** Permet de cr�er une instance de l'EJB */
	public ApiRessourceManager create() throws CreateException;

}