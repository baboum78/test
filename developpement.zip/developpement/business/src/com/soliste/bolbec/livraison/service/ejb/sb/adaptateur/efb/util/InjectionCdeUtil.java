/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.util;

import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.AnomalieDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatCommandeDTO;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationEfb;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.EtatCommandeConstantes;
import aps.TypeAnomalieConstantes;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>28/02/2012</TD><TD>BPE</TD><TD>DE-000187: Pas de code compl�ment et libell� sur CR EFB de type NENHD + type NENMIX non g�r�</TD></TR>
 * </TABLE>
 * The Class InjectionCdeUtil.
 */
public class InjectionCdeUtil {

	/** The Constant CLASS_NAME. */
	private static final String CLASS_NAME = InjectionCdeUtil.class.getName();

	/** The Constant CODE_302. */
	private static final String CODE_302 = "302";

	/** The Constant INTERFACE_QUEUE_NAME. */
	private static final String INTERFACE_QUEUE_NAME = "jms/interfaceQueue";

	/** The Constant QUEUE_FULL_NAME. */
	private static final String QUEUE_FULL_NAME = "java:comp/env/" + INTERFACE_QUEUE_NAME;

	/** The Constant TRAITEMENT. */
	private static final String TRAITEMENT = "EfbOut";

	/** The Constant TYPE_SERVICE. */
	private static final String TYPE_SERVICE = "EfbOut";

	/**
	 * Throw exception for anomalie.
	 * 
	 * @param infosFonctionnel the infos fonctionnel
	 * @param rce the rce
	 * 
	 * @throws InvalidJmsMessageException the invalid jms message exception
	 */
	public static void throwExceptionForAnomalie(ReceptionCdeException rce, Map<String, Object> infosFonctionnel) throws InvalidJmsMessageException {
		Exception l_excep = getExceptionForAnomalie(rce, infosFonctionnel);
		if (l_excep != null) {
			if (l_excep instanceof InvalidJmsMessageException) {
				throw (InvalidJmsMessageException) l_excep;
			} else if (l_excep instanceof RuntimeException) {
				throw (RuntimeException) l_excep;
			} else {
				throw new RuntimeException(l_excep);
			}
		}
	}

	/**
	 * Retourne une exception selon le code anomalie et son type dans la base.
	 * <br>
	 * Exception est null : anomalie n'est pas � traiter <br>
	 * Exception est de type ProcessException, abandon du traitement et rollback
	 * <br>
	 * Exception est de type InvalidJmsMessageException : rejet du message
	 * 
	 * <BR><B>HISTORIQUE</B>
	 * <TABLE frame='border' >
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>22/07/2013</TD><TD>EBA</TD><TD>G8R2C2 EV-000238_01 -: Modification retour anomalie </TD></TR>
	 * <TR><TD>18/09/2013</TD><TD>BPE</TD><TD>G8R2C3 - DE-000940 "NPE sur rejet de commande avec anomalie sans traduction"</TD></TR>
	 * </TABLE><BR>
	 * 
	 * @param infosFonctionnel the infos fonctionnel
	 * @param rce the rce
	 * 
	 * @return ProcessException, InvalidMessageException ou null
	 */
	private static Exception getExceptionForAnomalie(ReceptionCdeException rce, Map<String, Object> infosFonctionnel) {
		final String l_nomMethode = "getExceptionForAnomalie";
		String code = rce.getId();
		ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, l_nomMethode, "traitement de l'exception " + code);
		AnomalieDTO anomalieDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AnomalieDTO.class, code);
		if (anomalieDTO == null) {
			return rce;
		}
		String l_anoType = anomalieDTO.getTypeAnomalie().getId();
		ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, l_nomMethode, "Anomalie de type " + l_anoType);
		if (TypeAnomalieConstantes.OK.equals(l_anoType)) {
			return null;
		} else if (TypeAnomalieConstantes.AV.equals(l_anoType)) {
			return rce;
			// Ca doit �tre DNR
		} else {
			// EV-238 : si pas d�j� valoris� (si pas de traduction FORMAT_NON_PEC_EFB pour cette ano)
			if (StringUtils.isEmpty((String) infosFonctionnel.get(EFBConstantes.CLE_CODE_CPLT_STATUT_OP))) {
				ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, l_nomMethode, "Envoi d'une notification de code  " + CODE_302);
				infosFonctionnel.put(EFBConstantes.CLE_CODE_CPLT_STATUT_OP, CODE_302);
			}
			String idCommande = (String) infosFonctionnel.get(Constantes.FIELD_ID_COMMANDE);
			if (StringUtils.isNotBlank(idCommande)) {
				CommandeDTO commandeDTO = ServiceManager.getInstance().getCommandeManager().findCommandeById(idCommande);
				commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
				ServiceManager.getInstance().getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
			}
			envoyerNotification(infosFonctionnel);

			return null;
		}
	}

	/**
	 * Appel � la publication.
	 * 
	 * @param infosFonctionnel the infos fonctionnel
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TR><TD>28/02/2012</TD><TD>BPE</TD><TD>DE-000187: Pas de code compl�ment et libell� sur CR EFB de type NENHD + type NENMIX non g�r�</TD></TR>
	 * </TABLE>
	 */
	private static void envoyerNotification(Map<String, Object> infosFonctionnel) {
		final String l_nomMethode = "envoyerNotification";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, l_nomMethode, "Debut");
		// Appeler la strategy de publication
		ServiceManager.getInstance().getLoggerManager().finer(CLASS_NAME, l_nomMethode, "Appel � PublicationEfbStrategy");
		DeleguePublicationEfb publication = new DeleguePublicationEfb(QUEUE_FULL_NAME, TRAITEMENT, TYPE_SERVICE);
		publication.creerCrEfbNonEnregistre(infosFonctionnel);
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, l_nomMethode, "Fin");
	}

}