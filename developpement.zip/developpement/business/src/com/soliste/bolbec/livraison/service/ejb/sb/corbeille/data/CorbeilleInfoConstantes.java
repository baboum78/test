/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

/**
 * Constantes pour les infos affich�es dans les corbeille
 * 
 * @author gdzd8490
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>20/07/2010</TD><TD>DBA</TD><TD>EV-000029: Impl�mentation de l'affichage de la date de d�saturation</TD></TR>
 * <TR><TD>17/09/2012</TD><TD>EBA</TD><TD>EV-000188: Vente FTTH - Ajout de l'EPCidVIA</TD></TR>
 * <TR><TD>12/11/2012</TD><TD>FTE</TD><TD>EV-000183: Apostrof - Ajout de REGIME_SAV</TD></TR>
 * <TR><TD>14/11/2013</TD><TD>FTE</TD><TD>EV-000272: Ajout de REFERENCE_FCI</TD></TR>
 * <TR><TD>15/04/2016</TD><TD>KWE</TD><TD>EV-000357_01: Ajout interligne</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377: Commandes FTTE - Ajout du num�ro CLIP</TD></TR>
 * <TR><TD>10/08/2018</TD><TD>AJO</TD><TD>QC-1025 Filtre AVP robot</TD></TR>
 * </TABLE>
 */
public final class CorbeilleInfoConstantes {
	
	public static final String ND_SUPPORT = "ndSupport";
	public static final String NDPLP = "ndplp";
	public static final String TACHE = "tache";
	public static final String CAUSE_EVENEMENT = "causeEvenement";
	public static final String CAUSE_EVENEMENT_INIT = "causeEvenementInit";
	public static final String DATE_SOUHAITEE = "dateSouhaitee";
	public static final String DATE_CONTRACTUELLE_EPC_SUPPORT = "dateContractuelleEpcSupport";
	public static final String DATE_CONTRACTUELLE_COMMANDE = "dateContractuelleCommande";
	public static final String DATE_CREATION_COMMANDE = "dateCreationCommande";
	public static final String GROUPE_OFFRE = "groupeOffre";
	public static final String FAMILLE_OFFRE = "familleOffre";
	public static final String LIGNES_COMMANDE = "lignesCommande";
	public static final String DEBUT_AU_PLUS_TOT = "debutAuPlusTot";
	public static final String FIN_AU_PLUS_TARD = "finAuPlusTard";
	public static final String RESSOURCES_TECHNIQUES = "ressourcesTechniques";
	public static final String REPARTITEUR = "repartiteur";
	public static final String ZONE_GEOGRAPHIQUE = "zoneGeographique";
	public static final String ZONE_SI = "zoneSI";
	public static final String EDSI = "edsi";
	public static final String INTERVENTIONS = "interventions";
	public static final String ID_COMMANDE = "idCommande";
	public static final String JALON = "jalon";
	public static final String TRAITE_PAR = "traitePar";
	public static final String ROLE = "role";
	public static final String NOM_VENDEUR = "nomVendeur";
	public static final String REF_CLIENT_CONTRACTANT = "refClientContractant";
	public static final String NOM_CONTRACTANT = "nomContractant";
	public static final String PRENOM_CONTRACTANT = "prenomContractant";
	public static final String CATEGORIE_CONTRACTANT = "categorieContractant";
	public static final String NOM_CLIENT_LIVRE = "nomClientLivre";
	public static final String CATEGORIE_CLIENT_LIVRE = "categorieClientLivre";
	public static final String DSLAM = "dslam";
	public static final String ANCIEN_DSLAM = "ancienDslam";
	public static final String DATE_PREMIERE_EXECUTION = "datePremiereExecution";
	public static final String DATE_MAX_EXECUTION = "dateMaxExecution";
	public static final String DATE_PROGRAMMATION = "dateProgrammation";
	public static final String DATE_VALIDATION_FO = "dateValidationFO";
	public static final String DEBUT_AU_PLUS_TARD = "debutAuPlusTard";
	public static final String DEBUT_REEL = "debutReel";
	public static final String DESCRIPTION_CONTRACTANT = "descriptionContractant";
	public static final String FIN_AU_PLUS_TOT = "finAuPlusTot";
	public static final String FIN_REELLE = "finReelle";
	public static final String NOMBRE_REJEUX = "nombreRejeux";
	public static final String REFEXTERNE_COMMANDE = "referenceExterneCommande";
	public static final String TRAITEMENT = "traitement";
	public static final String TYPE_EVENEMENT = "typeEvenement";
	public static final String VERSION_BOLBEC = "versionArtemis";
	public static final String NOTES = "notes";
	public static final String DIFFEREE = "tachesDifferees";
	public static final String EN_COURS = "tachesEnCours";
	public static final String STATUT_COMMANDE = "statutCommande";
	// TP_INTERFERE
	public static final String INTERFERE = "interfere";
	// EV-000014: Nouvelle constante car nouveau filtre dans les corbeille (Permet de retrouver la valeur du label)
	public static final String DATE_RDV = "dateRDV";
	public static final String INTERFERE_DATE_FIN = "interfereDateFin";

	// EV-000029: Nouveau champ pour la date de desaturation
	public static final String DATE_DESATURATION = "dateDesaturation";

	// EV-188 : Vente_FTTH ajout de l'epcIdVIA
	public static final String EPC_ID_VIA = "EPCidVIA";

	// EV-183
	public static final String REGIME_SAV = "regimeSAV";

	// EV-272
	public static final String REFERENCE_FCI = "referenceFCI";

	private CorbeilleInfoConstantes() {
		// pour eviter instanciation inutile.
	}

	// EV-317 Ajout de libelle et code erreur IPON
	public static final String LIBELLE_ERREUR_IPON = "libelleErreurIpon";

	// EV-357_01 Quickwins
	public static final String INTERLIGNE = "interligne";

	// EV-348_09
	public static final String CONTEXTE_LIVRAISON = "contexteLivraison";

	// EV-377 : Commande FTTE - Num�ro CLIP
	public static final String NUMERO_CLIP = "numeroCLIP";

	public static final String AVP_ROBOT = "avpRobot";

	// US-674
	public static final String ID_EVENEMENT = "idEvt";
	public static final String ID_CAUSE_EVT = "idCauseEvt";
	public static final String IS_TRAITEMENT_EN_COURS = "isTraitementEnCours";
	public static final String LAST_NOTE = "Note";
}
