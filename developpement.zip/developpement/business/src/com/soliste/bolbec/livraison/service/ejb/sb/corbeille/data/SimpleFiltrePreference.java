/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.io.Serializable;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

public class SimpleFiltrePreference implements Serializable {

	private String id;
	private boolean activated;

	/**
	 * 
	 * @param id
	 * @param activated
	 */
	public SimpleFiltrePreference(String id, boolean activated) {
		this.id = id;
		this.activated = activated;
	}

	public String getId() {
		return this.id;
	}

	public boolean getActivated() {
		return this.activated;
	}

}
