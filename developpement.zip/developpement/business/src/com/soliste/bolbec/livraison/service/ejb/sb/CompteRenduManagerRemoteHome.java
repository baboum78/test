package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * Interface remote de l'EJB session <code>CompteRenduManager</code>.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public interface CompteRenduManagerRemoteHome extends EJBHome {

	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public CompteRenduManagerRemote create() throws CreateException, RemoteException;
}
