package com.soliste.bolbec.livraison.service.ejb.sb.api.utils;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import com.soliste.aps.workflow.WfException;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.WfServices;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Note;
import com.soliste.bolbec.livraison.service.model.BlocNoteDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.EtatProcessusConstantes;

public class NoteUtils {
	private final static CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
	private final static WfServices WFSERVICES = ServiceManager.getInstance().getWfServices();
	private final static ILoggerManager LOGGER_MANAGER = ServiceManager.getInstance().getLoggerManager();
	private static final String CLASS_NAME = NoteUtils.class.getName();

	/**
	 * Permet de savoir si la note associ�e � la commande est la plus r�cente de toutes les notes.
	 * 
	 * @param blocNote
	 * @param id
	 * @param idCommande
	 * @return
	 */

	public static boolean EstLaNoteLaPlusRecente(BlocNoteDTO blocNote, String id, String idCommande) {
		blocNote = COMMANDE_MANAGER.findBlocNoteById(id);
		List<BlocNoteDTO> blocnotelst = COMMANDE_MANAGER.findBlocNoteByCommande(idCommande);
		for (BlocNoteDTO blocnoteiter : blocnotelst) {
			if (blocnoteiter.getDateCreation().getTime() > blocNote.getDateCreation().getTime()) {
				return false;
			}
		}
		return true;
	}

}
