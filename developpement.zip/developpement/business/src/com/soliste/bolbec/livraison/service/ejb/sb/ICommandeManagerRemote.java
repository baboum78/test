package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.ejb.sb.commande.data.InfosComplementairesCommandeDTO;
import com.soliste.bolbec.livraison.service.model.AccesClientDTO;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.BlocNoteDTO;
import com.soliste.bolbec.livraison.service.model.CasMetierDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.CompletudeRegroupementDTO;
import com.soliste.bolbec.livraison.service.model.EpCommercialDTO;
import com.soliste.bolbec.livraison.service.model.InstanceOgDTO;
import com.soliste.bolbec.livraison.service.model.InterferenceDTO;
import com.soliste.bolbec.livraison.service.model.InterlocuteurDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LienOpProgLdcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdCatalogueDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdModParcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdSupParcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.PrestationAFacturerDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusLcDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RapportInterventionDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatRegulDTO;

/**
 * Interface metier de l'ejb <code>CommandeManagerSB</code><br/>
 * Permet de rechercher des entit�es li�es � une commande<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>12/07/2012</TD><TD>EBA</TD><TD>EV-188 : Ajout du finder findInterventionPlusRecenteByLdc</TD></TR>
 * <TR><TD>24/10/2012</TD><TD>EBA</TD><TD>EV-183 : EB-58 : Ajout de getBlocNote et updateBlocNote</TD></TR>
 * <TR><TD>14/02/2013</TD><TD>EBA</TD><TD>G8R2CI � EV-000210 : Ajout de la m�thode isFTTHEntreprise</TD></TR>
 * <TR><TD>27/05/2013</TD><TD>GPA</TD><TD>G8R2C2 � Tech : Passage du type de transaction des m�thodes des EJB Remote en RequiresNew</TD></TR>
 * <TR><TD>29/05/2013</TD><TD>EBA</TD><TD>G8R2C2 BackOffice : Cr�ation methodes necessaires avec NewTransaction</TD></TR>
 * <TR><TD>23/09/2013</TD><TD>BPE</TD><TD>G8R2C3 � EV-000264 : Ajout de la m�thode findCommandeByRefeRDV</TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000304 : Fluidification ADSL vers Fibre </TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000298 - R�siliation acc�s FTTH en cas de porta sortante </TD></TR>
 * </TABLE>
 */
public interface ICommandeManagerRemote {

	/**
	 * R�cup�re une liste de ligne de commande pour un processus donn�
	 * 
	 * @param processusId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByEstLivreParProcessus(String processusId) throws RemoteException;

	/**
	 * R�cup�re une des lignes de commande pour un processus donn�
	 * 
	 * @param processusId
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByEstLivreParProcessusAndUneSeule(String processusId) throws RemoteException;

	/**
	 * R�cup�re la ligne de commande pour un reference externe donn�e
	 * (null si non trouv�e)
	 * 
	 * @param refExterne
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByRefExterne(String refExterne) throws RemoteException;

	/**
	 * R�cup�re la ligne de commande pour un reference externe donn�e et livr�es par un processus en etat non termin�
	 * (null si non trouv�e)
	 * 
	 * @param refExterne
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByRefExterneEtProcessusNonTerm(String refExterne) throws RemoteException;

	/**
	 * R�cup�re la liste des LigneCommande d'une Commande.
	 * 
	 * @param commandeId the id commande
	 * 
	 * @return Liste de LigneCommandeDTO
	 */
	List<LigneCommandeDTO> findLigneCommandeByCommandeWithNewTransaction(String commandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des LigneCommande d'un InstanceRT.
	 * 
	 * @param instanceRtId the id insatnceRT
	 * 
	 * @return Liste de LigneCommandeDTO
	 */
	List<LigneCommandeDTO> findLigneCommandeByInstanceRT(String instanceRtId) throws RemoteException;

	/**
	 * R�cup�re la ligne de commande pour l'EpCommercial pass� en param�tre par son id
	 * on essaye de trouver la ligne de commande en passant par LigneCmdModParc (modification)
	 * si non trouv� on essaye en passant par LigneCmdSupParc (suppression)
	 * 
	 * @param epCommercialId the id EpCommercial
	 * 
	 * @return ligneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByEpCommercial(String epCommercialId) throws RemoteException;

	/**
	 * R�cup�re la ligne de commande pour le PSSouhaite pass� en param�tre par son id
	 * on essaye de trouver la ligne de commande en passant par LigneCmdCatalogue (creation)
	 * si non trouv� on essaye en passant par LigneCmdModParc (modification)
	 * 
	 * @param psSouhaiteId PS souhaite
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByPsSouhaite(String psSouhaiteId) throws RemoteException;

	/**
	 * R�cup�re les lignes de commande correspondant au processus.
	 * 
	 * @param processusId
	 * @return
	 */
	List<LigneCommandeDTO> findLigneCommandeByProcessus(String processusId) throws RemoteException;

	/**
	 * Mets � jour le jalon d'une liste de ligne de commande
	 * 
	 * @param ligneCommandeDTOs
	 * @param jalonId
	 */
	void updateLigneCommandeJalon(List<LigneCommandeDTO> ligneCommandeDTOs, String jalonId) throws RemoteException;

	/**
	 * Sauvegarde de la date de fin de la commmande
	 * 
	 * @param ligneCommandeDTO the ligneCommande DTO
	 */
	void updateLigneCommandeDateFin(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Sauvegarde de la date de fin et de l'etat de la ligne de commande.
	 * 
	 * @param ligneCommandeDTO the ligne commande dto
	 */
	void updateLigneCommandeDateFinAndEtat(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>dateMadt</code> et <code>dateMes</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeDateMadtAndDateMes(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>dateMesTech</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeDateMesTech(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>dateSouhaite</code> et <code>dateContractuelle</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeDateSouhaiteAndDateContractuelle(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>dateContractuelle</code> de la ligne de commande
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>20090622</TD><TD>YTR</TD><TD>Nouvelle m�thode de mise � jour d�veloppement EV-000011</TD></TR>
	 * </TABLE>
	 * 
	 * @param ligneCommandeDTOs
	 */
	void updateLigneCommandeDateContractuelle(LigneCommandeDTO ligneCommandeDTOs) throws RemoteException;

	/**
	 * Mets � jour le champ <code>repartiteur</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeRepartiteur(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>client</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeClient(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Cr�e une relation Processus/Ligne de commande.<br/>
	 * Attention il faut que l'id <code>processusLcDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param processusLcDTO the processusLC dto
	 * 
	 * @return processusLcDTO
	 */
	ProcessusLcDTO createProcessusLC(ProcessusLcDTO processusLcDTO) throws RemoteException;

	/**
	 * R�cup�re une commande � partir de son id commandeId
	 * 
	 * @param commandeId
	 * @return une commande
	 */
	CommandeDTO getCommandeWithNewTransaction(String commandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des commandes composant la commande mixte pass�e en param�tre
	 * 
	 * @param commandeMixteId the id commande
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeByIdCommandeMixteWithNewTransaction(String commandeMixteId) throws RemoteException;

	/**
	 * R�cup�re la liste des CommandeDTO ayant pour commande mixte la commande dont on passe
	 * l'id en param�tre et ayant le statut pass� en param�tre
	 * 
	 * @param commandeId
	 * @param statutId
	 * @return List<CommandeDTO>
	 */
	List<CommandeDTO> findCommandeByIdCommandeMixteEtStatus(String commandeId, String statutId) throws RemoteException;

	/**
	 * R�cup�re la commande associ�e � un PSSouhait� donn�
	 * 
	 * @param psSouhaiteId
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByPsSouhaite(String psSouhaiteId) throws RemoteException;

	/**
	 * R�cup�re la commande associ�e � un EPCommercial donn�
	 * 
	 * @param epCommercialId
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByEpCommercial(String epCommercialId) throws RemoteException;

	/**
	 * R�cup�re la commande associ�e � une ligne de commande donn�e
	 * 
	 * @param ligneCommandeId
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByLigneCommandeWithNewTransaction(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des commandes concernant le ND
	 * 
	 * @param nd Le ND
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeByND(String nd) throws RemoteException;

	/**
	 * R�cup�re la liste des commandes concernant l'acces livraison de la commande et le type acces livraison
	 *
	 * @param accesLivraison acces livraison (ND) de l'acces
	 * @param typeAcces type acces livraison de l'acces
	 *
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeByAccesLivraisonAndTypeAccesLivraison(String accesLivraison, String typeAcces) throws RemoteException;

	/**
	 * R�cup�re la commande par son Id
	 * 
	 * @param id L'identifiant de la commande
	 * 
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByIdWithNewTransaction(String id) throws RemoteException;

	/**
	 * R�cup�re la liste de commande en utilisant la ref intervention
	 * 
	 * @param refIntervention La ref intervention � utiliser pour faire la recherche
	 * @return La liste de commande pour cette ref intervention
	 */
	List<CommandeDTO> findCommandeByRefIntervention(String refIntervention) throws RemoteException;

	/**
	 * R�cup�re la liste de commande en utilisant la r�f�rence eRDV
	 * 
	 * @param refeRDV La ref eRDV � utiliser pour faire la recherche
	 * @return La liste de commande pour cette ref intervention
	 */
	List<CommandeDTO> findCommandeByRefeRDV(String refeRDV) throws RemoteException;

	/**
	 * R�cup�re la liste des commandes en cours (dont l'�tat vaut COMP ou LIV) concernant le ND
	 * via LigneCmdCatalogue, LigneCmdModParc, LigneCmdSupParc
	 * 
	 * @param nd Le ND
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeEnCoursByNDWithNewTransaction(String nd) throws RemoteException;

	/**
	 * R�cup�re la liste des commandes (dont l'�tat vaut CREE) concernant le ND
	 * via LigneCmdCatalogue, LigneCmdModParc, LigneCmdSupParc
	 * 
	 * @param nd Le ND
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeEnCoursAVPInterfByNDWithNewTransaction(String nd) throws RemoteException;

	/**
	 * Find CommandeDTO by refExterne (de commande)
	 * 
	 * @param refExterne
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByRefExterne(String refExterne) throws RemoteException;

	/**
	 * Find list CommandeDTO by refExterne (de commande);
	 * 
	 * @param refExterne
	 * @return
	 */
	List<CommandeDTO> findCommandeListByRefExterne(String refExterne) throws RemoteException;

	/**
	 * Recherche la premiere commande non annul�e et ayant pour ref externe <code>refExterne</code>
	 *
	 * @param refExterne
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeNonAnnByRefExterne(String refExterne) throws RemoteException;

	/**
	 * Recherche la premiere commande non annul�e et ayant pour ref externe <code>refExterne</code>
	 *
	 * @param refExterne
	 * @return CommandeDTO
	 */
	List<CommandeDTO> findListCommandesNonAnnByRefExterne(String refExterne) throws RemoteException;

	/**
	 * Find CommandeDTO by processus.
	 * 
	 * @param processusId
	 * @return la commande
	 */
	CommandeDTO findCommandeByProcessus(String processusId) throws RemoteException;

	/**
	 * Find CommandeDTO by tache.
	 * 
	 * @param tacheId
	 * @return la commande
	 */
	CommandeDTO findCommandeByTache(String tacheId) throws RemoteException;

	/**
	 * Find CommandeDTO by interventionId.
	 *
	 * @param interventionId
	 * @return la commande
	 */
	CommandeDTO findCommandeByInterventionId(String interventionId) throws RemoteException;

	/**
	 * Mets � jour les champs <code>EtatCommande</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeEtat(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>RefExterne</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeRefExterne(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Mets � jour le champs <code>nombreAvp</code>
	 * 
	 * @param processusId
	 */
	void updateCommandeNombreAvp(String processusId) throws RemoteException;

	/**
	 * Mets � jour les champs <code>StatutCommande</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeStatutWithNewTransaction(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>dateFinCommande</code>
	 * 
	 * @param commandeDTO the Commande DTO
	 */
	void updateCommandeDateFin(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>dateFinCommande</code> et <code>EtatCommande</code>
	 * 
	 * @param commandeDTO the Commande DTO
	 */
	void updateCommandeDateFinAndEtat(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>aPourCmdMixteCommande</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeMixte(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>IndicateurRegul</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeIndicateurRegul(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Sauvegarde la ZoneGeo et la ZoneSI d'une ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeZoneGeoEtZoneSi(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>EtatLigneCde</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeEtat(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>Contexte</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeContexte(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>InduiteParLigneCommande</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeInduiteLigneCommande(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>AccesLivraison</code> <code>AccesLivraisonOrigine</code> <code>TypeAccesLivraison</code> <code>TypeAccesLivraisonOrigine</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeAccesLivraison(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>IndicateurRegul</code> et <code>DateFin</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeIndicateurRegulEtDateFin(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>Etat</code>, <code>Jalon</code> et <code>IndicateurRegul</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeEtatEtJalonEtIndicateurRegul(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>NdFinder</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeNdFinder(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Cr�e un PsSouhaite
	 * 
	 * @param psSouhaiteDTO the psSouhaiteDTO dto
	 */
	void createPsSouhaite(PsSouhaiteDTO psSouhaiteDTO) throws RemoteException;

	/**
	 * Cr�e une instance Og
	 * 
	 * @param instanceOgDTO the instanceOg dto
	 */
	void createInstanceOg(InstanceOgDTO instanceOgDTO) throws RemoteException;

	/**
	 * Cr�e une ligne de commande
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void createLigneCommande(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les donn�es dynamiques de la table commande.<br/>
	 * Pour supprimer une valeur en base, mettre null dans la map.
	 * 
	 * @param commandeDTO
	 */
	void updateDynamicCommandeWithNewTransaction(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * Mets � jour les donn�es dynamiques de la table intervention.
	 * 
	 * @param interventionDTO
	 */
	void updateDynamicIntervention(InterventionDTO interventionDTO) throws RemoteException;

	/**
	 * Sauvegarde les champs dynamiques d'une ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateDynamicLigneCommandeWithNewTransaction(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * Mets � jour les donn�es dynamiques de la table PS Souhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updateDynamicPsSouhaite(PsSouhaiteDTO psSouhaiteDTO) throws RemoteException;

	/**
	 * R�cup�re un psSouhaite � partir de son id psSouhaiteId
	 * 
	 * @param psSouhaiteId
	 * @return un psSouhaite
	 */
	public PsSouhaiteDTO getPsSouhaite(String psSouhaiteId) throws RemoteException;

	/**
	 * Mets � jour le champ EpCommercial du PS Souhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteEpCommercial(PsSouhaiteDTO psSouhaiteDTO) throws RemoteException;

	/**
	 * Mets � jour le champ InstanceFT du PS Souhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteInstanceFT(PsSouhaiteDTO psSouhaiteDTO) throws RemoteException;

	/**
	 * R�cup�re le PsSouhaite li� � la ligne de commande. S'il existe un
	 * LigneCmdCatalogue li� � la ligne de commande, alors le PsSouhaite est
	 * r�cup�r� depuis celui-ci. Sinon, il est r�cup�r� par un LigneCmdModParc
	 * si celui-ci existe.
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * @return PsSouhaiteDTO
	 */
	PsSouhaiteDTO findPsSouhaiteByLigneCommandeWithNewTransaction(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re le PsSouhaite li� � la ligne de commande s'il existe un
	 * LigneCmdCatalogue li� � la ligne de commande.
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * @return PsSouhaiteDTO
	 */
	PsSouhaiteDTO findPsSouhaiteByLigneCommandeCR(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re le PsSouhaite fournit par une InstanceFT.
	 * 
	 * @param instanceFTId the instanceFT id
	 * 
	 * @return the psSouhaite
	 */
	PsSouhaiteDTO findPsSouhaiteByFourniParInstanceFT(String instanceFTId) throws RemoteException;

	/**
	 * Find ps souhaite by acces client.
	 * 
	 * @param accesClientId the acces client id
	 * 
	 * @return the list of PsSouhaiteDTO
	 */
	List<PsSouhaiteDTO> findPsSouhaiteByAccesClient(String accesClientId) throws RemoteException;

	/**
	 * R�cup�re l'EPCommercial li� � la ligne de commande. S'il existe un
	 * LigneCmdCatalogue li� � la ligne de commande, alors on r�cup�re
	 * l'InstanceOG et � partir de celui-ci, on r�cup�re l'EPCommercial.
	 * S'il existe un LigneCmdModParc, l'EPCommercial est r�cup�r� depuis
	 * celui-ci. Enfin, s'il existe un LigneCmdSupParc, l'EPCommercial est
	 * r�cup�r� depuis celui-ci.
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * @return EpCommercialDTO
	 */
	EpCommercialDTO findEpCommercialByLigneCommandeWithNewTransaction(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re l'EPCommercial li� � la ligne de commande de suppression.
	 * S'il existe un LigneCmdSupParc, l'EPCommercial est r�cup�r� depuis celui-ci.
	 * 
	 * @param ligneCommandeSUId Identifiant de la ligne de commande.
	 * @return EpCommercialDTO
	 */
	EpCommercialDTO findEpCommercialByLigneCommandeSUWithNewTransaction(String ligneCommandeSUId) throws RemoteException;

	/**
	 * R�cup�re l'ensemble des EpCommercial support� par le PsSouhaite.
	 * (PsSouhaite.MLINK_SUPPORTE_E_P_COMMERCIAL)
	 * 
	 * @param pssSupportId Identifiant du PsSouhaite support
	 * @return List de EpCommercialDTO
	 */
	List<EpCommercialDTO> findEPCommercialByPsSouhaiteSupport(String pssSupportId) throws RemoteException;

	/**
	 * R�cup�re l'ensemble des EpCommercial support� par le EpCommercial.
	 * (EPCommercial.MLINK_SUPPORTE_E_P_COMMERCIAL)
	 * 
	 * @param epcSupportId Identifiant du EpCommercial support
	 * @return List de EpCommercialDTO
	 */
	List<EpCommercialDTO> findEPCommercialByEpCommercialSupport(String epcSupportId) throws RemoteException;

	/**
	 * Supprimer les donn�es dynamiques d'epCommercial pour un Id d'Ep Commrcial donn�.
	 * 
	 * @param epCommercialId the ep commercial Id
	 */
	void deleteDynamicEpCommercial(String epCommercialId) throws RemoteException;

	/**
	 * Charge une InterferenceDTO � partir de son id
	 * 
	 * @param interferenceId id de l'interference
	 * @return InterferenceDTO
	 */
	InterferenceDTO getInterference(String interferenceId) throws RemoteException;

	/**
	 * R�cup�re la liste des interferences relatives � la ligne de commande
	 * 
	 * @param ligneCommandeId Identifiant de la LigneCommande
	 * 
	 * @return List d'InterferenceDTO
	 */
	List<InterferenceDTO> findInterferenceByLigneCommandeWithNewTransaction(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des interferences relatives � un nd
	 * via LigneCmdCatalogue, LigneCmdModParc, LigneCmdSupParc
	 * 
	 * @param nd nd
	 * 
	 * @return List d'InterferenceDTO
	 */
	List<InterferenceDTO> findInterferenceByNd(String nd) throws RemoteException;

	/**
	 * Sauvegarde de la date de fin d'une interference
	 * 
	 * @param interferenceDTO the interference DTO
	 */
	void updateInterferenceDateFinWithNewTransaction(InterferenceDTO interferenceDTO) throws RemoteException;

	/**
	 * Cr�e une interference
	 * 
	 * @param interferenceDTO the interference DTO
	 */
	void createInterferenceWithNewTransaction(InterferenceDTO interferenceDTO) throws RemoteException;

	/**
	 * R�cup�re les interf�rences rattach�es � la commande
	 * 
	 * @param commandeId the id commande
	 * 
	 * @return the list of InterferenceDTO
	 */
	List<InterferenceDTO> findInterferenceByCommandeWithNewTransaction(String commandeId) throws RemoteException;

	/**
	 * Supprime l'interference.
	 * 
	 * @param interferenceId the interference id
	 */
	void deleteInterferenceWithNewTransaction(String interferenceId) throws RemoteException;

	/**
	 * Cr�e un CompletudeRegroupement
	 * 
	 * @param completudeRegroupement
	 */
	CompletudeRegroupementDTO createCompletudeRegroupement(CompletudeRegroupementDTO completudeRegroupement) throws RemoteException;

	/**
	 * Recherche d'une liste de CompletudeRegroupement pour la commande pass�e en param�tre
	 * 
	 * @param commandeId the id commande
	 */
	List<CompletudeRegroupementDTO> findCompletudeRegroupementByCommande(String commandeId) throws RemoteException;

	/**
	 * Recherche d'une liste de CompletudeRegroupement tel que CompletudeRegroupement.IDACCES = idAccess ET CompletudeRegroupement.FK_ESTDANSSTATUTCOMMANDE = idStatutCde pass�es en param�tres
	 * 
	 * @param idAcces the nd
	 * @param statutCde the StatutCde id
	 */
	List<CompletudeRegroupementDTO> findCompletudeRegroupementByIdAccesEtStatutCde(String idAcces, String statutCde) throws RemoteException;

	/**
	 * Recherche d'une liste de CompletudeRegroupement tel que CompletudeRegroupement.IDACCES = idAccess
	 * 
	 * @param idAcces the nd
	 */
	List<CompletudeRegroupementDTO> findCompletudeRegroupementByIdAcces(String idAcces) throws RemoteException;

	/**
	 * Supprime un CompletudeRegroupement pour la commande pass�e en param�tre
	 * 
	 * @param commandeId the id commande
	 */
	void deleteCompletudeRegroupementByCommande(String commandeId) throws RemoteException;

	/**
	 * Supprime un CompletudeRegroupement tel que CompletudeRegroupement.FK_LIEHDCOMMANDE = commandeId pass�e en param�tre
	 * 
	 * @param commandeId the id commande
	 */
	void deleteCompletudeRegroupementByLieHDCommande(String commandeId) throws RemoteException;

	/**
	 * Supprime un CompletudeRegroupement tel que CompletudeRegroupement.FK_LIEHDCOMMANDE = commandeId ET CompletudeRegroupement.IDACCES = idAccess ET CompletudeRegroupement.FK_ESTDANSSTATUTCOMMANDE = idStatutCde pass�es en param�tres
	 * 
	 * @param commandeId the id commande
	 * @param idAccess the nd
	 * @param idStatutCde the StatutCde id
	 */
	void deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde(String commandeId, String idAccess, String idStatutCde) throws RemoteException;

	/**
	 * R�cup�re la liste des TransitSystStatRegul pour une commande.
	 * 
	 * @param idCommande the id commande
	 * @param codeTransfert the code transfert
	 * 
	 * @return the list of TransitSystStatRegulDTO
	 */
	List<TransitSystStatRegulDTO> findTransitSystStatRegulByCmdAndCdTransfert(String idCommande, String codeTransfert) throws RemoteException;

	/**
	 * R�cup�re la liste des TransitSystStatDTO correspondant aux crit�res de recherche pass�s en param�tre
	 * 
	 * @param identite the identite
	 * @param formatExterne the format externe
	 * @param instanceLocalisation the instance localisation
	 * @param codeTransfert the code transfert
	 * 
	 * @return the list of TransitSystStatDTO
	 */
	List<TransitSystStatDTO> findTransitSystStatByIdentFormatInstLocCdTransfert(String identite, String formatExterne, String instanceLocalisation, String codeTransfert) throws RemoteException;

	/**
	 * Supprime le TransitSystStat du DTO pass� en param�tre.
	 * 
	 * @param transitSystStatDTO the transit syst stat dto
	 */
	void deleteTransitSystStat(TransitSystStatDTO transitSystStatDTO) throws RemoteException;

	/**
	 * Modifie un CompletudeRegroupement
	 * 
	 * @param completudeRegroupement
	 */
	void updateCompletudeRegroupement(CompletudeRegroupementDTO completudeRegroupement) throws RemoteException;

	/**
	 * Modifie le statut d'un CompletudeRegroupement
	 * 
	 * @param regroupementCourant
	 */
	void updateCompletudeRegroupementStatut(CompletudeRegroupementDTO regroupementCourant) throws RemoteException;

	/**
	 * R�cup�re l'intervention la plus r�cente
	 * (par debutPlage) parmi les interventions de la commande pass�e en param�tre.
	 * 
	 * @param commandeId the id commande
	 * 
	 * @return une intervention
	 */
	InterventionDTO findInterventionByCommande(String commandeId) throws RemoteException;

	/**
	 * Mise � jour des champs suivants de l'intervention:
	 * <ul>
	 * <li>les dynamics</li>
	 * <li>DatePrise, DateEnvoiOt, DebutPlage, FinPlage, Duree</li>
	 * <li>EtatIntervention</li>
	 * <li>RefExterne</li>
	 * <li>Responsabilite</li>
	 * </ul>
	 * 
	 * @param interventionDTO l'intervention
	 */
	void updateIntervention(InterventionDTO interventionDTO) throws RemoteException;

	/**
	 * R�cup�re une opProgammee � partir de son id opProgrammeeId
	 * 
	 * @param opProgrammeeId
	 * @return une opProgrammee
	 */
	OpProgrammeeDTO getOpProgrammee(String opProgrammeeId) throws RemoteException;

	/**
	 * Cr�e un opProgrammee. </br>
	 * Attention il faut que l'id <code>opProgrammeeDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param opProgrammeeDTO the opProgrammeeDTO dto
	 * 
	 * @return opProgrammeeDTO
	 */
	OpProgrammeeDTO createOpProgrammee(OpProgrammeeDTO opProgrammeeDTO) throws RemoteException;

	/**
	 * R�cup�re la liste des OpProgrammeeDTO pour l'intervention dont on passe l'id en param�tre
	 * 
	 * @param interventionId
	 * @return List<OpProgrammeeDTO>
	 */
	List<OpProgrammeeDTO> findOpProgrammeeByIntervention(String interventionId) throws RemoteException;

	/**
	 * R�cup�re la liste des OpProgrammeDTO pour la ligne de commande dont on passe l'id en param�tre
	 * 
	 * @param ligneCommandeId id de la ligne de commande
	 * @return List<OpProgrammeDTO>
	 */
	List<OpProgrammeeDTO> findOpProgrammeByLigneCommande(String ligneCommandeId) throws RemoteException;

	/**
	 * R�cup�re la liste des OpProgrammeDTO pour la commande dont on passe l'id en param�tre
	 * 
	 * @param commandeId id de la commande
	 * @return List<OpProgrammeDTO>
	 */
	List<OpProgrammeeDTO> findOpProgrammeeByCommande(String commandeId) throws RemoteException;

	/**
	 * Charge une InterventionDTO � partir de son id
	 * 
	 * @param interventionId id de l'intervention
	 * @return InterventionDTO
	 */
	InterventionDTO getIntervention(String interventionId) throws RemoteException;

	/**
	 * M�thode de mise � jour des champs de l'intervention pass�e en param�tre :
	 * <ul>
	 * <li>son etat</li>
	 * <li>la date d'envoi Ot</li>
	 * </ul>
	 * 
	 * @param interventionDTO the intervention
	 */
	void updateInterventionEtatEtDateEnvoiOt(InterventionDTO interventionDTO) throws RemoteException;

	/**
	 * Supprime l'intervention
	 * 
	 * @param interventionDTO
	 */
	void deleteIntervention(InterventionDTO interventionDTO) throws RemoteException;

	/**
	 * Cr�e un rapport d'intervention
	 * 
	 * @param rapportInterventionDTO
	 * @param interventionId
	 */
	void createRapportIntervention(RapportInterventionDTO rapportInterventionDTO, String interventionId) throws RemoteException;

	/**
	 * Mise � jour d'une intervention
	 * <ul>
	 * <li>son etat</li>
	 * <li>son rapport</li>
	 * </ul>
	 * 
	 * @param interventionDTO
	 */
	void updateInterventionEtatEtRapport(InterventionDTO interventionDTO) throws RemoteException;

	/**
	 * Mise � jour d'une OpProgrammee
	 * - intervention sur laquelle elle porte
	 * 
	 * @param opProgrammeeDTO
	 */
	void updateOpProgrammeeIntervention(OpProgrammeeDTO opProgrammeeDTO) throws RemoteException;

	/**
	 * Mise � jour d'une OpProgrammee
	 * - typeOPProgrammee sur laquelle elle porte
	 * 
	 * @param opProgrammeeDTO
	 */
	void updateOpProgrammeeTypeOPProgrammee(OpProgrammeeDTO opProgrammeeDTO) throws RemoteException;

	/**
	 * Cr�ation d'une intervention
	 * 
	 * @param interventionDTO
	 */
	void createIntervention(InterventionDTO interventionDTO) throws RemoteException;

	/**
	 * Mise � jour d'une intervention
	 * <ul>
	 * <li>etat</li>
	 * </ul>
	 * 
	 * @param interventionDTO
	 */
	void updateInterventionEtat(InterventionDTO interventionDTO) throws RemoteException;

	/**
	 * R�cup�re les lignes de commande � partir de l'id d'intervention donn�e
	 * (on passe par les op programm�e)
	 * 
	 * @param interventionId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByIntervention(String interventionId) throws RemoteException;

	/**
	 * R�cup�re les lignes de commande � partir de l'id d'intervention donn�e
	 * (on passe par une op programm�e pour r�cup�rer l'id de commande, puis,
	 * � partir de la commande, on r�cup�re toutes les lignes de commande)
	 * 
	 * @param interventionId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByInterventionViaCommande(String interventionId) throws RemoteException;

	/**
	 * R�cup�re les lignes de commande � partir de l'id d'op�ration programm�e donn�e.
	 * 
	 * @param opProgrammeeId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByOpProgrammee(String opProgrammeeId) throws RemoteException;

	/**
	 * R�cup�re les lignes de commande induites par la ligne de commande pass�e
	 * en param�tre.
	 * 
	 * @param ligneCommandeId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeInduiteByLigneCommande(String ligneCommandeId) throws RemoteException;

	/**
	 * Mise � jou d'une ligne de commande
	 * <ul>
	 * <li>codeFacturationOffre</li>
	 * <li>codeFacturationRemise</li>
	 * </ul>
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeCodeFacturation(LigneCommandeDTO ligneCommandeDTO) throws RemoteException;

	/**
	 * R�cup�re une ligne de commande � partir de son id ligneCmdId
	 * 
	 * @param ligneCmdId
	 * @return une ligne de commande
	 */
	LigneCommandeDTO getLigneCommandeWithNewTransaction(String ligneCmdId) throws RemoteException;

	/**
	 * Find acces client by commande.
	 * 
	 * @param commandeId the commande id
	 * 
	 * @return the list of AccesClientDTO
	 */
	List<AccesClientDTO> findAccesClientByCommande(String commandeId) throws RemoteException;

	/**
	 * Cr�e une relation Ligne de commande/OpProgrammee.<br/>
	 * Attention il faut que l'id <code>lienOpProgLdcDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param lienOpProgLdcDTO the lienOpProgLdc dto
	 * 
	 * @return lienOpProgLdcDTO
	 */
	LienOpProgLdcDTO createLienOpProgLdc(LienOpProgLdcDTO lienOpProgLdcDTO) throws RemoteException;

	/**
	 * Supprime les lien op�ration programm�e / ligne de commande pour l'op programm�e pass� en parametre.
	 * 
	 * @param opProgrammeeId the op programmee id
	 */
	void deleteLienOpProgLdcByOpProgrammee(String opProgrammeeId) throws RemoteException;

	/**
	 * Mets � jour les donn�es dynamiques de la table epCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateDynamicEpCommercial(EpCommercialDTO epCommercialDTO) throws RemoteException;

	/**
	 * Supprime la ligne de commande
	 * 
	 * @param ligneCommandeId
	 */
	void deleteLigneCommande(String ligneCommandeId) throws RemoteException;

	/**
	 * Supprime les ProcessusLC pour la ligne de commande dont l'id est pass� en param�tre
	 * 
	 * @param ligneCommandeId
	 */
	void deleteProcessusLCByLigneCommande(String ligneCommandeId) throws RemoteException;

	/**
	 * Supprime la LigneCmdSupParc
	 * 
	 * @param ligneCmdSupParcId
	 */
	void deleteLigneCmdSupParc(String ligneCmdSupParcId) throws RemoteException;

	/**
	 * Find LigneCmdSupParc by epCommercialId.
	 * 
	 * @param epCommercialId
	 * @return the list of LigneCmdSupParcDTO
	 */
	List<LigneCmdSupParcDTO> findLigneCmdSupParcByEpCommercial(String epCommercialId) throws RemoteException;

	/**
	 * Find LigneCmdModParc by epCommercialId.
	 * 
	 * @param epCommercialId
	 * @return the list of LigneCmdModParcDTO
	 */
	List<LigneCmdModParcDTO> findLigneCmdModParcByEpCommercial(String epCommercialId) throws RemoteException;

	/**
	 * Supprime l'AccesClient
	 * 
	 * @param accesClientId
	 */
	void deleteAccesClient(String accesClientId) throws RemoteException;

	/**
	 * Cr�e un AccesClient
	 * 
	 * @param accesClient
	 */
	void createAccesClient(AccesClientDTO accesClient) throws RemoteException;

	/**
	 * Supprime l'EpCommercial
	 * 
	 * @param epCommercialId
	 */
	void deleteEpCommercial(String epCommercialId) throws RemoteException;

	/**
	 * Cr�e un EpCommercial
	 * 
	 * @param epCommercial
	 */
	void createEpCommercial(EpCommercialDTO epCommercial) throws RemoteException;

	/**
	 * Supprime le Client
	 * 
	 * @param clientId
	 */
	void deleteClient(String clientId) throws RemoteException;

	/**
	 * Cr�e un Client
	 * 
	 * @param client
	 */
	void createClient(ClientDTO client) throws RemoteException;

	/**
	 * Modifie un Client
	 * 
	 * @param client
	 */
	void updateClient(ClientDTO client) throws RemoteException;

	/**
	 * Charge le Client correspondant � son id
	 * 
	 * @param clientId
	 * @return the clientDTO
	 */
	ClientDTO getClient(String clientId) throws RemoteException;

	/**
	 * Charge l'Adresse correspondant � son id
	 * 
	 * @param adresseId
	 * @return the adresseDTO
	 */
	AdresseDTO getAdresse(String adresseId) throws RemoteException;

	/**
	 * Cr�ation d'une adresse.
	 * 
	 * @param adresseDTO the adresse dto
	 */
	void createAdresse(AdresseDTO adresseDTO) throws RemoteException;

	/**
	 * Supprime l'Adresse
	 * 
	 * @param adresseId
	 */
	void deleteAdresse(String adresseId) throws RemoteException;

	/**
	 * Modifie l'Adresse
	 * 
	 * @param adresseDTO
	 */
	void updateAdresse(AdresseDTO adresseDTO) throws RemoteException;

	/**
	 * Mets � jour les donn�es de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercial(EpCommercialDTO epCommercialDTO) throws RemoteException;

	/**
	 * Mets � jour le champ InstanceFT de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercialInstanceFT(EpCommercialDTO epCommercialDTO) throws RemoteException;

	/**
	 * Mets � jour le champ nd de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercialNd(EpCommercialDTO epCommercialDTO) throws RemoteException;

	/**
	 * Find EpCommercialDTO by idAccesClient
	 * 
	 * @param idAccesClient
	 * @return the list of EpCommercialDTO
	 */
	List<EpCommercialDTO> findEpCommercialByAccesClient(String idAccesClient) throws RemoteException;

	/**
	 * Find EpCommercialDTO by instanceFT
	 * 
	 * @param instanceFTId
	 * @return the list of EpCommercialDTO
	 */
	List<EpCommercialDTO> findEPCommercialByInstanceFT(String instanceFTId) throws RemoteException;

	/**
	 * Mets � jour l'accesClient de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercialAccesClient(EpCommercialDTO epCommercialDTO) throws RemoteException;

	/**
	 * Charge l'EpCommercial correspondant � son Id
	 * 
	 * @param idEpCommercial
	 * @return the EpCommercialDTO
	 */
	EpCommercialDTO getEpCommercial(String idEpCommercial) throws RemoteException;

	/**
	 * Mets � jour l'accesClient du PsSouhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteAccesClient(PsSouhaiteDTO psSouhaiteDTO) throws RemoteException;

	/**
	 * Mets � jour l'offre du PsSouhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteOffre(PsSouhaiteDTO psSouhaiteDTO) throws RemoteException;

	/**
	 * Mets � jour le nd du PsSouhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteNd(PsSouhaiteDTO psSouhaiteDTO) throws RemoteException;

	/**
	 * Cr�e une occurence de LigneCmdCatalogue.<br/>
	 * 
	 * @param ligneCmdCatalogueDTO the ligneCmdCatalogue dto
	 * 
	 */
	void createLigneCmdCatalogue(LigneCmdCatalogueDTO ligneCmdCatalogueDTO) throws RemoteException;

	/**
	 * Cr�e une occurence de LigneCmdSuppParc.<br/>
	 * 
	 * @param ligneCmdSupParcDTO the ligneCmdSupParc dto
	 * 
	 */
	void createLigneCmdSupParc(LigneCmdSupParcDTO ligneCmdSupParcDTO) throws RemoteException;

	/**
	 * Find BlocNoteDTO by idCommande
	 * 
	 * @param idCommande
	 * @return the list of BlocNoteDTO
	 */
	List<BlocNoteDTO> findBlocNoteByCommande(String idCommande) throws RemoteException;

	/**
	 * Create the BlocNote.
	 * 
	 * @param blocNoteDTO
	 * @return
	 */
	BlocNoteDTO createBlocNote(BlocNoteDTO blocNoteDTO) throws RemoteException;

	/**
	 * Find InterventionDTO by idProcessus
	 * 
	 * @param idProcessus
	 * @return the list of InterventionDTO
	 */
	List<InterventionDTO> findInterventionByProcessus(String idProcessus) throws RemoteException;

	/**
	 * Find last intervention by idLdc
	 * 
	 * @param idLdc
	 * @return
	 */
	InterventionDTO findInterventionPlusRecenteByLdc(String idLdc) throws RemoteException;

	/**
	 * Find InterventionDTO by idOpProgrammee
	 * 
	 * @param idOpProgrammee
	 * @return InterventionDTO
	 */
	InterventionDTO findInterventionByOpProgrammee(String idOpProgrammee) throws RemoteException;

	/**
	 * Find PrestationAFacturerDTO by idLigneCommande
	 * 
	 * @param idLigneCommande
	 * @return the list of PrestationAFacturerDTO
	 */
	List<PrestationAFacturerDTO> findPrestationAFacturerByLigneCommande(String idLigneCommande) throws RemoteException;

	/**
	 * Cr�e une occurence de PrestationAFacturer.<br/>
	 * 
	 * @param prestationAFacturerDTO the prestationAFacturer dto
	 * 
	 * @return prestationAFacturerDTO
	 */
	PrestationAFacturerDTO createPrestationAFacturer(PrestationAFacturerDTO prestationAFacturerDTO) throws RemoteException;

	/**
	 * Find Interlocuteur by interventionId
	 * 
	 * @param interventionId
	 * @return InterlocuteurDTO
	 */
	InterlocuteurDTO findInterlocuteurByIntervention(String interventionId) throws RemoteException;

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>25/02/2010</TD><TD>DBA</TD><TD>IRMA_151: Nouveau find</TD></TR>
	 * </TABLE>
	 * l_casMetier = LienOpProgLdc.Fk_AppartientLigneCommande.IdCommande.FK_SEREFERECASMETIER
	 * pour LienOpProgLdc.Fk_requiereOpProgrammee = Op�ProgIntervention.Id
	 * 
	 * @param opProgrammeeInterventionId L'identifiant de l'OP programmee intervention
	 * @return Le cas m�tier trouv�<BR> Cette m�thode peut remonter une valeur null
	 */
	CasMetierDTO findCasMetierByOpProgrammeeInterventionId(String opProgrammeeInterventionId) throws RemoteException;

	/**
	 * Retourne les informations compl�mentaires pour la commande identifi�e par
	 * l'ID donn�
	 * 
	 * @param commandeId l'ID de la commande
	 * @return les infos compl�mentaires
	 */
	InfosComplementairesCommandeDTO getInfosComplementairesCommande(String commandeId) throws RemoteException;

	/**
	 * Recupere les champs dynamiques d'une commande
	 * 
	 * @param commandeId the commande id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsCommandeWithNewTransaction(String commandeId) throws RemoteException;

	/**
	 * Recupere les champs dynamiques d'une ligne de commande
	 * 
	 * @param ligneCommandeId the ligne commande id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsLigneCommandeWithNewTransaction(String ligneCommandeId) throws RemoteException;

	/**
	 * Recupere les champs dynamiques d'une intervention
	 * 
	 * @param interventionId the intervention id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsIntervention(String interventionId) throws RemoteException;

	/**
	 * Recupere les champs dynamiques d'un ep commercial
	 * 
	 * @param epCommercialId the ep commercial id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsEpCommercialWithNewTransaction(String epCommercialId) throws RemoteException;

	/**
	 * Recupere les champs dynamiques d'un ps souhaite
	 * 
	 * @param psSouhaiteId the ps souhaite id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsPsSouhaiteWithNewTransaction(String psSouhaiteId) throws RemoteException;

	/**
	 * Recupere les champs dynamiques d'une intervention
	 * 
	 * @param rapportInterventionId the rapport intervention id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsRapportIntervention(String rapportInterventionId) throws RemoteException;

	/**
	 * Renvoie true si la commande dont l'id est pass� en param�tre poss�de une note attach�e :
	 * <ul><li>sur la commande</li>
	 * <li>sur une ligne de commande</li>
	 * <li>sur une t�che</li>
	 * <li>sur un processus</li></ul>
	 * 
	 * @param commandeId id de la commande concern�e
	 * @return true si la commande poss�de une note
	 */
	boolean isMarked(String commandeId) throws RemoteException;

	/**
	 * @param commandeDTO La commande qu'il faut mettre � jour
	 * 
	 */
	void updateCommandeCasMetier(CommandeDTO commandeDTO) throws RemoteException;

	/**
	 * retourne le blocNote dont l'id est en param�tre
	 * 
	 * @param idBlocNote
	 * @return
	 */
	BlocNoteDTO getBlocNote(String idBlocNote) throws RemoteException;

	/**
	 * update le blocNote pass� en param�tre
	 * 
	 * @param blocNoteDTO
	 */
	void updateBlocNote(BlocNoteDTO blocNoteDTO) throws RemoteException;

	/**
	 * retourne vrai si le systeme externe de la commande est Frontal
	 * 
	 * @param commandeId
	 * @return
	 */
	boolean isFTTHEntreprise(String commandeId) throws RemoteException;

	/**
	 * retourne la valeur constante de l'offre
	 * 
	 * @param lcId
	 * @param load
	 * return
	 */
	OffreDTO getOffreForLigneCommandeCRNew(String lcId, boolean... load) throws RemoteException;

	/**
	 * retourne la valeur constante de l'offre
	 * 
	 * @param lcId
	 * @param load
	 * @return
	 */
	OffreDTO getOffreForLigneCommandeSUNew(String lcId, boolean... load) throws RemoteException;


	/**
	 * Find CommandeDTO by processus.
	 *
	 * @param processusId
	 * @return la commande
	 */
	CommandeDTO findCommandeByProcessusId(String processusId) throws RemoteException;

	/**
	 * Find CommandeDTO by tache.
	 *
	 * @param tacheId
	 * @return la commande
	 */
	CommandeDTO findCommandeByTacheId(String tacheId) throws RemoteException;

	/**
	 * Find CommandeDTO by EvtId.
	 *
	 * @param evtId
	 * @return la commande
	 */
	CommandeDTO findCommandeByEvtId(String evtId) throws RemoteException;


}
