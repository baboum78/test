package com.soliste.bolbec.livraison.service.ejb.sb.processus;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.InfoMessageWebSrv;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.Evenement;
import com.soliste.bolbec.livraison.service.anomalies.SFAno;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CRGenNonInfocentreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CROsirisDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CRPublicationDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.ChampCRGenNonInfocentreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.LigneCommandeAAnnuler;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.ListCRSupDeProDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.RegularisationManuelleDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.RegularisationManuelleDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.AbandonnerRegulManException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.AffecterTraitementManuelException;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.WorkflowManager;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.frontal.io.UpdateDeliverCustomerOrderFrontalIn;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gra.io.UpdateDeliverCustomerOrderIn;
import com.soliste.bolbec.livraison.service.interfaces.util.ServiceFonctionnelManager;
import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatCommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatLigneCdeDTO;
import com.soliste.bolbec.livraison.service.model.EtatProcessusDTO;
import com.soliste.bolbec.livraison.service.model.EtatPublicationDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.InterferenceDTO;
import com.soliste.bolbec.livraison.service.model.JalonDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ModificationParcDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.PubRegManDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatRegulDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.publication.GestionnairePublication;
import com.soliste.bolbec.livraison.service.publication.Notification;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.publication.Publication;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationCristal;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationEfb;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationFrontal;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationGrafic;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationSagic;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.VersionArtemisUtil;

import aps.AnomalieConstantes;
import aps.CatalogueTacheConstantes;
import aps.CauseEvenementConstantes;
import aps.EtatCommandeConstantes;
import aps.EtatLigneCdeConstantes;
import aps.EtatProcessusConstantes;
import aps.EtatPublicationConstantes;
import aps.JalonConstantes;
import aps.MessagesConstantes;
import aps.ModificationParc;
import aps.ProcessusType;
import aps.ProcessusTypeConstantes;
import aps.PublicationConstantes;
import aps.StatutCommandeConstantes;
import aps.SystemeExterne;
import aps.SystemeExterneConstantes;
import aps.TypeAnomalieConstantes;
import com.thoughtworks.xstream.XStream;
import com.thoughtworks.xstream.io.xml.DomDriver;

/**
 * Cette classe regroupe les m�thodes utiles lors de la r�gularisation manuelle, ainsi que lors de l'abandon manuel.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
 * <TR><TD>21/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Refactor CAST : suppression classe deprecated GestionAnomalie</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>19/07/2011</TD><TD>GPA</TD><TD>IRMA_987: Pb Retour Auto sur regularisation manuelle + REFACTORING</TD></TR>
 * <TR><TD>16/08/2011</TD><TD>GPA</TD><TD>EV-000155: Maj Cristal sur Stopper Regul</TD></TR>
 * <TR><TD>17/07/2012</TD><TD>BPE</TD><TD>EV-000188: Remonter les CR d�avancement attendus par GRAFIC</TD></TR>
 * <TR><TD>22/01/2013</TD><TD>EBA</TD><TD>G8R1C2 - EV-000210 : Offre BVPN&BI FTTH(TRA-12-12)</TD></TR>
 * <TR><TD>14/02/2013</TD><TD>FTE</TD><TD>G8R2C1 - EV-000210 : Offre BVPN&BI FTTH(TRA-12-12) - Affichage des CR Frontal</TD></TR>
 * <TR><TD>25/04/2013</TD><TD>GPA</TD><TD>G8R2C2 : Suppression du doublon sur le MG_ClotureTache</TD></TR>
 * <TR><TD>31/05/2013</TD><TD>BPE</TD><TD>DE-000846 : Suppression du marquage de la commande lors d'une r�gul manuelle sur une commande en compl�tude</TD></TR>
 * <TR><TD>07/06/2013</TD><TD>EBA</TD><TD>G8R2C2 BackOffice : Impact migration G9 : suppression d'interferences</TD></TR>
 * <TR><TD>21/10/2013</TD><TD>BPE</TD><TD>G9R0C1 Suppression de la classe AxisObjectUtils</TD></TR>
 * <TR><TD>08/11/2013</TD><TD>EBA</TD><TD>G8R2C4 EV-273 : Corrections Sonar </TD></TR>
 * <TR><TD>14/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * <TR><TD>27/04/2015</TD><TD>BPE</TD><TD>Durcissement m�canisme EJB Remote</TD></TR>
 * <TR><TD>22/07/2016</TD><TD>SDO</TD><TD>EV-392 - D�commissionnement G8</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'><TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.1314</TD><TD>EP0052 - Identifier les commandes n�cessitant une mise � jour du dossier Cristal</TD></TR>
 * <TR><TD>REQ.5060</TD><TD>EP0141 � Remonter les CR d�avancement attendus par GRAFIC</TD></TR>
 * </TABLE>
 */
public class RegularisationManuelleTraitement {

	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	private static final String CLASSNAME = "RegularisationManuelleTraitement";

	/**
	 * Valeur ECRIT pour le champ CodeTransfert d'un TransitSystStatRegul.
	 */
	public static final String CODE_TRANSFERT_ECRIT = "ECRIT";

	/**
	 * Valeur APURGER pour le champ CodeTransfert d'un TransitSystStatRegul.
	 */
	public static final String CODE_TRANSFERT_APURGER = "APURGER";

	// Nom des cl�s de donn�es dans la table HashMap utilis�es pour r�diger le compte-rendu SAGIC en format XML
	private static final String PARAM_CODE_CR = "PARAM_CODE_CR";
	private static final String PARAM_COMMENT_FAI = "PARAM_COMMENT_FAI";
	private static final String PARAM_COMMENT_FT = "PARAM_COMMENT_FT";
	private static final String PARAM_ID_ICE_SAGIC = "PARAM_ID_ICE_SAGIC";

	private static final String ERRMSG_KEY_ABANDONNER_REGUL_MAN_ERROR_ABANDON_IMPOSSIBLE = "AbandonnerRegulMan.error.abandonImpossible";

	private static final String SYSEXT_CRISTAL = "Cristal";
	private static final String SYSEXT_EFB = "EFB";
	private static final String SYSEXT_SAGIC = "SAGIC";
	private static final String SYSEXT_SUP_DE_PRO = "SupDePro";

	private static final String INDICATEUR_REGUL_O = "O";
	private static final String INDICATEUR_REGUL_R = "R";
	private static final String INDICATEUR_REGUL_A = "A";

	private static final String VAL_DONNEESWF_OUI = "oui";
	private static final String VAL_DONNEESWF_NON = "non";
	private static final String VAL_DONNEESWF_ABAN = "aban";
	private static final String VAL_DONNEESWF_RETOUR = "retour";

	private static final String ID_ACTIVATION_INTERFERENCE = "Interference";

	private static final String FORMAT_DATE_BOLBEC = "dd/MM/yyyy HH:mm:ss";
	private static final String STRING_0 = "0";
	private static final String STRING_123 = "123";
	private static final String STRING_COMMANDE49W = "COMMANDE49W";
	private static final String STRING_ECHEC_COMMANDE_ANNULEE = "Echec : Commande annul�e";
	private static final String STRING_G02R00C00 = "G02R00C00";
	private static final String STRING_NREHD = "NREHD";
	private static final String STRING_BLANK = "";
	private static final String STRING_SPACE = " ";

	private RegularisationManuelleTraitement() {
	}

	/**
	 * Construit un RegularisationManuelleDTO qui contient la liste des publications
	 * pour une r�gularisation manuelle.
	 * 
	 * @param tacheId
	 * @param evtId
	 * @param modeOpName
	 * @param versionArtemis
	 * @return tache manuelle avec evenement
	 */
	public static RegularisationManuelleDTO getRegularisationManuelle(String tacheId, String evtId, String modeOpName, String versionArtemis) {

		TacheDTO tache = ServiceManager.getInstance().getProcessusManager().getTache(tacheId);
		EvtDTO evt = null;
		if (StringUtils.isNotEmpty(evtId)) {
			evt = ServiceManager.getInstance().getProcessusManager().getEvt(evtId);
		}
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByTache(tacheId);
		// R�cup�ration des CRs SAGIC, CRs CRISTAL, CRs EFB, CRs SupDePro, CRs Frontal
		// (Remarque : JalonDTO impl�mente la m�thode Comparable pour que ce soit tri� sur le rang)
		SortedMap<JalonDTO, SortedMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>>> classementCRNonInfocentre = new TreeMap<JalonDTO, SortedMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>>>();
		SortedMap<JalonDTO, List<ListCRSupDeProDTO>> mapCRSupDepro = new TreeMap<JalonDTO, List<ListCRSupDeProDTO>>();
		// R�cup�rer toutes les publications tels que
		// PublicationRegularisationManuelle.IDCommande =
		// WF.ROOTSET.ID_COMMANDE
		List<PubRegManDTO> pubRegManDeLaCommande = ServiceManager.getInstance().getRegulManuelleManager().findPubRegManByCommande(commande.getId());
		for (PubRegManDTO pubRegMan : pubRegManDeLaCommande) {

			String sysExtValExt = null;
			SystemeExterneDTO sysExt = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, pubRegMan.getSystemeExterne().getId());
			if (sysExt != null) {
				sysExtValExt = sysExt.getValeurConstante();
			}
			if (SystemeExterneConstantes.SAGIC_VALEUR_CONSTANTE.equals(sysExtValExt) || SystemeExterneConstantes.NUM_45R_VALEUR_CONSTANTE.equals(sysExtValExt) || SystemeExterneConstantes.EFB_VALEUR_CONSTANTE.equals(sysExtValExt)
					|| SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(sysExtValExt) || SystemeExterneConstantes.FRONTAL_VALEUR_CONSTANTE.equals(sysExtValExt) || SystemeExterneConstantes.NUM_75B_VALEUR_CONSTANTE.equals(sysExtValExt)) {

				// Cr�ation du CR non infocentre
				CRGenNonInfocentreDTO crDTO = CRPublicationDTOFactory.createCRNonInfocentre(pubRegMan);

				// Ajout du CR dans le classement par jalon puis par syst�me externe
				JalonDTO jalon = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(JalonDTO.class, crDTO.getJalon());
				// SME : IRMA 763 : Recherche sur la valeur constante au lieu de l'id
				SystemeExterneDTO systemeExterne = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class,
						new Comparaison(SystemeExterne.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, crDTO.getSysExterne()));
				SortedMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>> mapParJalon = classementCRNonInfocentre.get(jalon);
				if (mapParJalon == null) {
					mapParJalon = new TreeMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>>();
					classementCRNonInfocentre.put(jalon, mapParJalon);
				}
				List<CRGenNonInfocentreDTO> lstParSE = mapParJalon.get(systemeExterne);

				if (lstParSE == null) {
					lstParSE = new ArrayList<CRGenNonInfocentreDTO>();
					mapParJalon.put(systemeExterne, lstParSE);
				}
				lstParSE.add(crDTO);
			} else if (SystemeExterneConstantes.SDP_VALEUR_CONSTANTE.equals(sysExtValExt)) {

				// Cr�ation du CR SupDePro
				ListCRSupDeProDTO listCRSupDePro = CRPublicationDTOFactory.createSupDePro(pubRegMan);

				// Ajout du CR dans la Map par Jalon
				JalonDTO jalon = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(JalonDTO.class, listCRSupDePro.getJalon());
				List<ListCRSupDeProDTO> listeParJalon = mapCRSupDepro.get(jalon);
				if (listeParJalon == null) {
					listeParJalon = new ArrayList<ListCRSupDeProDTO>();
					mapCRSupDepro.put(jalon, listeParJalon);
				}
				listeParJalon.add(listCRSupDePro);
			}
		}
		// R�cup�ration des CRs Osiris
		List<CROsirisDTO> listeCROsiris = new ArrayList<CROsirisDTO>();
		List<TransitSystStatRegulDTO> collectionTransitSystStatRegul = ServiceManager.getInstance().getRegulManuelleManager().findTransitSystStatRegulByCommande(commande.getId());
		for (TransitSystStatRegulDTO transitSystStatRegul : collectionTransitSystStatRegul) {
			CROsirisDTO crOsirisDTO = CRPublicationDTOFactory.createOsiris(transitSystStatRegul);
			listeCROsiris.add(crOsirisDTO);
		}
		// Construction de l'objet retourn�
		return RegularisationManuelleDTOFactory.create(tache, evt, modeOpName, versionArtemis, pubRegManDeLaCommande, classementCRNonInfocentre, mapCRSupDepro, listeCROsiris);
	}

	/**
	 * Affecte en traitement manuel un processus de livraison ou de compl�tude � partir d'un processus.
	 * 
	 * @param processus Processus
	 * @param info Le texte de l'�v�nement
	 * @param idCurrentAgent ID de l'agent
	 * @param idCauseEvenement ID de la cause �v�nement
	 * @param donneesWf Donn�es workflow
	 * @param wfUser WfUser permettant de contacter le workflow
	 * 
	 * @throws AffecterTraitementManuelException
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * <TR><TD>19/07/2011</TD><TD>GPA</TD><TD>Factorisation de code dans la m�thode regulariserManuellement()</TD></TR>
	 * </TABLE>
	 */
	public static void faireTraitementManuel(ProcessusDTO processus, String info, String idCurrentAgent, String idCauseEvenement, Map<String, String> donneesWf, WfUser wfUser) throws AffecterTraitementManuelException {
		String methodName = "faireTraitementManuel";
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "D�but (processus d'id=" + processus.getId() + ")");
		SFAno ano = null;

		// Construction de l'evenement
		Evenement evenement = ProcessusTraitement.createEvenement(idCauseEvenement, info, null, idCurrentAgent, null);

		// M�moriser l'�v�nement r�cup�r�
		ProcessusTraitement.createEvtPourProcessus(evenement, processus.getId(), processus.getIdCommande());
		String etatProcessusCourant = processus.getEtatProcessus().getId();
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "L'�tat du processus d'id=" + processus.getId() + " est " + etatProcessusCourant);

		if (!EtatProcessusConstantes.ABAN.equals(etatProcessusCourant) && !EtatProcessusConstantes.TERM.equals(etatProcessusCourant)) {
			// Pour chacun des processus fils dont l'�tat est EN_COURS
			// I_processus.EtatProcessus='REGUL' et marquage de l'�tat des
			// lignes de commande avec EtatLigneCde='ECREG'
			setEtatSousProcessusEtLigneCde(processus.getId(), EtatProcessusConstantes.EN_COURS, EtatProcessusConstantes.REGUL, EtatLigneCdeConstantes.ECREG, null, INDICATEUR_REGUL_O);

			// Lancement du traitement de r�gularisation manuelle
			regulariserManuellement(processus, donneesWf, wfUser, evenement, VAL_DONNEESWF_OUI);
		} else {
			// RG_ANO1 : Gestion des anomalies
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "Lev� de la RG_ANO1");
			String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.REGULMAN_000020);
			ano = serviceManager.getAnomalieManager().newAno(AnomalieConstantes.REGUL_MAN_IMP, message);
		}

		// Traitement des anomalies remont�es
		if (ano != null) {
			Evenement e = serviceManager.getAnomalieManager().traiter("PrepRegul", ano);
			boolean warning = SFAno.TYPE_AV.equals(ano.getType());
			throw new AffecterTraitementManuelException(e.getLibelle(), warning);
		}

		// Supprime les t�ches en cours li�s � la commande en cours.
		ServiceManager.getInstance().getProcessusManager().deleteTacheEnCoursByProcessus(processus.getId());

		// Retourner sur la corbeille courante (fait par l'appelant)

	}

	/**
	 * Affecte en abandon manuel un processus de livraison ou de compl�tude � partir d'un processus.
	 * 
	 * @param processus Processus
	 * @param info Le texte de l'�v�nement
	 * @param idCurrentAgent ID de l'agent
	 * @param idCauseEvenement ID de la cause �v�nement
	 * @param donneesWf Donn�es workflow
	 * @param wfUser WfUser permettant de contacter le workflow
	 * 
	 * @throws AffecterTraitementManuelException
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * <TR><TD>19/07/2011</TD><TD>GPA</TD><TD>Factorisation de code dans la m�thode regulariserManuellement()</TD></TR>
	 * </TABLE>
	 */
	public static void faireAbandonManuel(ProcessusDTO processus, String info, String idCurrentAgent, String idCauseEvenement, Map<String, String> donneesWf, WfUser wfUser) throws AffecterTraitementManuelException {
		String methodName = "faireAbandonManuel";
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "D�but (processus d'id=" + processus.getId() + ")");
		SFAno ano = null;

		// Construction de l'evenement
		Evenement evenement = ProcessusTraitement.createEvenement(idCauseEvenement, ConstantesTraduction.ABD_MANUEL + STRING_SPACE + info, null, idCurrentAgent, ConstantesTraduction.ABD_MANUEL);

		// Contr�le de la validit� de la cause d'abandon manuel : Le cas o�
		// on ne l'aurait pas ne devrait se produire qu'en phase de test,
		// mettre une trace dans le log et Terminer le traitement.
		// Cette v�rification est faite dans ProcessusManagerBean.

		// M�moriser l'evenement et le rattacher au processus p�re en
		// faisant appel au TRT GEN InstanciationEvenementProcessus (on lui
		// passe l'objet Evenement, l'id du processus p�re, le type
		// d'abandon ABD_MANUEL et l'identifiant de l'agent qui a demand�
		// l'abandon manuel)
		ProcessusTraitement.createEvtPourProcessus(evenement, processus.getId(), processus.getIdCommande());

		// Si Processus.EtatProcessus <> EtatProcessus.ABAN ou EtatProcessus.TERM
		String etatProcessusCourant = processus.getEtatProcessus().getId();
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "L'�tat du processus d'id=" + processus.getId() + " est " + etatProcessusCourant);
		if (!EtatProcessusConstantes.ABAN.equals(etatProcessusCourant) && !EtatProcessusConstantes.TERM.equals(etatProcessusCourant)) {

			// Pour chacun des processus fils dont l'�tat est EN_COURS
			// I_processus.EtatProcessus='ANNUL' et marquage de l'�tat des
			// lignes de commande avec EtatLigneCde='ECANN' et son jalon
			// � J_ABANMAN
			setEtatSousProcessusEtLigneCde(processus.getId(), EtatProcessusConstantes.EN_COURS, EtatProcessusConstantes.ANNUL, EtatLigneCdeConstantes.ECANN, JalonConstantes.J_ABANMAN, INDICATEUR_REGUL_A);

			// Lancement du traitement de r�gularisation manuelle
			regulariserManuellement(processus, donneesWf, wfUser, evenement, VAL_DONNEESWF_ABAN);
		} else {
			// RG_ANO1 : Gestion des anomalies
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "Lev� de la RG_ANO1");
			String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.PREPABAN__000040, evenement.getLibCauseEvenement(), JalonConstantes.J_ABANMAN);
			ano = serviceManager.getAnomalieManager().newAno(AnomalieConstantes.CAUSE_ABANDON_IMP, message);
		}

		// Traitement des anomalies remont�es du traitement g�n�rique
		// PrepAbandonManuel
		if (ano != null) {
			Evenement e = serviceManager.getAnomalieManager().traiter("PrepAbandon", ano);
			throw new AffecterTraitementManuelException(e.getLibelle(), false);
		}

		// Supprime les t�ches en cours li�s � la commande en cours.
		ServiceManager.getInstance().getProcessusManager().deleteTacheEnCoursByProcessus(processus.getId());

		// Retourner sur la corbeille courante (fait par l'appelant)
	}

	/**
	 * @param processus le processus en cours
	 * @param donneesWf les donn�es du workflow
	 * @param wfUser le user
	 * @param evenement l'�v�nement
	 * @param valeurRegulManuelle la valeur � placer dans le champ RegularisationManuelle dans le proprieteWorkflow
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>19/07/2011</TD><TD>GPA</TD><TD>IRMA_987: Cr�ation de la m�thode</TD></TR>
	 * <TR><TD>22/08/2011</TD><TD>GPA</TD><TD>EV-000155: Maj Cristal sur Stopper Regul</TD></TR>
	 * <TR><TD>25/10/2012</TD><TD>FTE</TD><TD>EV-000183 : Apostrof</TD></TR>
	 * </TABLE>
	 */
	private static void regulariserManuellement(ProcessusDTO processus, Map<String, String> donneesWf, WfUser wfUser, Evenement evenement, String valeurRegulManuelle) {
		String methodName = "regulariserManuellement";

		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(processus.getId());

		// D�tecter le besoin de mettre � jour le dossier Cristal
		if (isMiseAJourDossierCristalNecessaire(commande)) {
			// Cr�ation d�un champ dynamique sur la commande permettant de pr�ciser que le dossier Cristal doit �tre mis � jour et que cette action n�a pas �t� r�alis�e
			creerChampDynamiqueDossierCristal(commande);
		}

		// Publication Cochise/pharaon
		Notification notification = serviceManager.getCochisePharaonManager().creerNotificationAbandonRegul(PublicationConstantes.PUB_COCHISE_PHARAON_EVT, processus, evenement.getId());
		if (notification != null) {
			serviceManager.getCochisePharaonManager().publierMessage(notification);
		}

		// Supprime les t�ches en cours li�s � la commande en cours.
		ProcessusTraitement.rechercheEtSuppressionTacheEnCoursByProcessus(processus.getId());

		// R�cup�ration du type de processus
		String idProcessusType = processus.getProcessusType().getId();
		ProcessusTypeDTO processusType = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, idProcessusType);
		String processusTypeValConst = processusType.getValeurConstante();

		// R�initialiser toutes les variantes en mettant leur valeur � "non"
		setToutesVariantes(donneesWf, VAL_DONNEESWF_NON);

		// attribut Regularisation Manuelle : valeur=[valeurRegulManuelle]
		donneesWf.put(Constantes.RS_REGULARISATION_MANUELLE, valeurRegulManuelle);
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "Dans les donn�es workflow, la paire RegularisationManuelle a �t� mise � " + valeurRegulManuelle);

		WorkflowManager wfManager = ServiceManager.getInstance().getWorkflowManager();

		// Si le type du processus courant est COMPLETUDE alors :
		if (ProcessusTypeConstantes.COMPLETUDE_VALEUR_CONSTANTE.equals(processusTypeValConst)) {

			// - Ajouter � la hashmap Donnees un nouveau sous processus (c'est
			// bolbec qui d�termine l'id du sous processus cr�e et non pas
			// le workflow), ainsi que l'id de l'�v�nement initial (objet
			// Evenement fourni en entr�e de ce traitement) avec la cl�
			// "IDEVT" (NB : cet �v�nement peut �tre n�cessaire pour la publication).
			// - Rattacher les lignes de commandes � ce nouveau sous processus
			String regulProcessusTypeId = VersionArtemisUtil.versionnerValeurConstante(ProcessusTypeConstantes.ACTIONMAN_VALEUR_CONSTANTE, processus);
			ProcessusDTO processusCree = ProcessusTraitement.createProcessus(regulProcessusTypeId, processus);
			ProcessusTraitement.relierProcessusALignesCommandes(processus.getId(), processusCree);
			donneesWf.put(Constantes.RS_IDEXTERNE, processusCree.getId());
			donneesWf.put(Constantes.RS_IDEVT, evenement.getId());
			TypeEvenementDTO typeEvt = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(TypeEvenementDTO.class, evenement.getIdTypeEvenement());
			String typeEvtValConst = typeEvt.getValeurConstante();
			donneesWf.put(Constantes.RS_TYPE_EVT, typeEvtValConst);
			ProcessusTraitement.addIdempotence(donneesWf, processus.getId());
			// - Faire appel � la m�thode de cr�ation de sous processus
			// doCreateSubCase->param�tres : idName=IDExterne, idValue=id du
			// processus courant, nom de la t�che "ACTIONMAN" et la hashmap Donnees
			// - Faire appel au service de modification des donn�es du rootset
			// de l'API Workflow pour positionner les variantes Abandon et
			// Reprise (doSetBusinessDataValues->param�tres : idName=IDExterne,
			// idValue=id du processus courant et la hashmap Donn�es)
			processusCree.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.EN_COURS));
			ServiceManager.getInstance().getProcessusManager().updateProcessusEtat(processusCree);

			// wfManager.creerSousProcessus(processus.getBpiid(), ProcessusTypeConstantes.ACTIONMAN_VALEUR_CONSTANTE, donneesWf, Constantes.IDEMPOTENCE_ID_LIGNE_CMD, processus.getBpName(), wfUser);
			String sTypologieAbandon = determinerTypologieAbandon(valeurRegulManuelle, donneesWf, true);
			String sProcessusOrigineAbandon = Constantes.ORIGINE_ABANDON_COMPLETUDE;

			ServiceManager.getInstance().getLoggerManager().finer(CLASSNAME, methodName, "Appel au service workflow de r�gularisation du processus (WfUser.doAbandon)");
			wfManager.abandonner(donneesWf, wfUser, processus.getId(), sTypologieAbandon, sProcessusOrigineAbandon);
		} else {

			// Faire appel au service workflow de r�gularisation du
			// processus (WfUser.doRegul) :
			// - persister les donn�es de la hashmap dans le Bdoc
			// - appelle le service de la couche workflow qui transmettra
			// le message d'interruption MSG_ACTIONMAN avec en parametre
			// l'identifiant du processus p�re (c'est le processus p�re
			// COMPLETUDE ou LIVRAISON qui va propager l'interruption)
			String sTypologieAbandon = determinerTypologieAbandon(valeurRegulManuelle, donneesWf, false);
			String sProcessusOrigineAbandon = Constantes.ORIGINE_ABANDON_LIVRAISON;
			ServiceManager.getInstance().getLoggerManager().finer(CLASSNAME, methodName, "Appel au service workflow de r�gularisation du processus (WfUser.doAbandon)");
			wfManager.abandonner(donneesWf, wfUser, processus.getId(), sTypologieAbandon, sProcessusOrigineAbandon);
		}
	}

	/**
	 * Determine la typologie d'abandon � effectuer en fonction des crit�res
	 * 
	 * @param valeurRegulManuelle type de regularisation manuelle initialement pr�vue
	 * @param donneesWf donnees worklow, avec le typeEvt
	 * @param bIsCompletude true si la commande est encore en compl�tude
	 * @return la typologie d'abandon � r�aliser
	 */
	private static String determinerTypologieAbandon(String valeurRegulManuelle, Map<String, String> donneesWf, boolean bIsCompletude) {
		if (bIsCompletude) {
			return Constantes.TYPE_ABANDON_REGULMANUELLE;
		}
		if (StringUtils.equalsIgnoreCase(VAL_DONNEESWF_ABAN, valeurRegulManuelle)) {
			return Constantes.TYPE_ABANDON_STD;
		} else if (StringUtils.equalsIgnoreCase(VAL_DONNEESWF_OUI, valeurRegulManuelle)) {
			return Constantes.TYPE_ABANDON_REGULMANUELLE;
		} else {
			return Constantes.TYPE_ABANDON_REGULMANUELLE;
		}
	}

	/**
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param wfUser
	 *
	 * @throws AbandonnerRegulManException
	 */
	public static void abandonnerRegularisationManuelle(String tacheId, String info, String causeEvenementId, WfUser wfUser) throws AbandonnerRegulManException {

		ProcessusDTO papaProcessus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		Evenement evenement = ProcessusTraitement.createEvenement(causeEvenementId, info, null, null, null);

		// Contr�le de la validit� de la cause d'abandon vis � vis de l'�tat
		// d'avancement du processus
		Set<String> causeEvenementIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandon(papaProcessus.getId(), null, null);
		if (evenement != null && !causeEvenementIds.contains(evenement.getIdCauseEvenement())) {
			// FIXME OLD: SLO : voir si c'est normal que l'on n'utilise pas l'ano suivante
			/*
			 * String jalon = getJalon(papaProcessus.getId());
			 * String message = GestionAnomalie.getMessage(MessagesConstantes.PREPABAN_000030, new String[] { jalon, systemeExterneId });
			 * String anoId = VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.CAUSE_ABANDON_IMP_VALEUR_CONSTANTE, papaProcessus);
			 * SFAno sfAno = GestionAnomalie.newSFAno(TraitementConstantes.PREPABANDON, anoId, SFAno.TYPE_DNR, message);
			 */
			throw new AbandonnerRegulManException(ERRMSG_KEY_ABANDONNER_REGUL_MAN_ERROR_ABANDON_IMPOSSIBLE, true);
		}

		// Lib�ration des interventions �ventuelles
		String versionArtemis = VersionArtemisUtil.getVersion(papaProcessus);
		String responsabiliteId = null;
		if (evenement != null) {
			CauseEvenementDTO causeEvt = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evenement.getIdCauseEvenement());
			if (causeEvt.getResponsabilite() != null) {
				responsabiliteId = causeEvt.getResponsabilite().getId();
			}
		}
		ProcessusTraitement.libererInterventions(papaProcessus.getId(), versionArtemis, responsabiliteId);
		// M�moriser l'�v�nement r�cup�r�
		ProcessusTraitement.createEvtPourProcessus(evenement, papaProcessus.getId(), papaProcessus.getIdCommande());
		// R�cup�ration de la commande associ�e au processus avec son idCommande
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(papaProcessus.getId());

		// Pour chaque ligne de commande
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByProcessus(papaProcessus.getId());
		for (LigneCommandeDTO ligneCde : lignesCde) {
			// R�veil des commandes interf�rentes
			reveilCommandesInterferentes(wfUser, ligneCde.getId());
			// Mise � jour de l'�tat des lignes de commande
			ligneCde.setEtatLigneCde(new EtatLigneCdeDTO(EtatLigneCdeConstantes.ANN));
			ligneCde.setDatabaseDateDateFinLigneCommande(DateUtils.getDatabaseDate());
			ServiceManager.getInstance().getCommandeManager().updateLigneCommandeDateFinAndEtat(ligneCde);
		}
		// Mise � jour de l'�tat du processus
		ProcessusDTO processusPere = papaProcessus.getGenereParProcessus();
		if (processusPere != null) {
			processusPere.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.ABAN));
			papaProcessus.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.TERM));
		}
		papaProcessus.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.ABAN));
		// Mise � jour de l'�tat de la commande
		miseAJourEtatCommande(commande);
		// Envoi du message d'abandon
		envoiMessageAbandon(lignesCde, commande.getRefExterne(), evenement);

	}

	/**
	 * Envoie la publication au syst�me externe correspondant.
	 * 
	 * @param pubRegMan
	 */
	public static void envoyerPublication(PubRegManDTO pubRegMan) {
		String method = "envoyerPublication";

		// R�cup�ration du syst�me externe
		SystemeExterneDTO systemeExterneDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, pubRegMan.getSystemeExterne().getId());
		String systemeExterneValConst = systemeExterneDTO.getValeurConstante();

		// R�cup�rer PubRegMan.Contenu le message � envoyer et le poster dans
		// la file MQ-Series d'envoi du routeur correspondant au syst�me
		// destinataire = valeur de PubRegMan.fkdestineaSystemeExterne
		if (SystemeExterneConstantes.SAGIC_VALEUR_CONSTANTE.equals(systemeExterneValConst)) {
			EnvoiCRPublication envoiCRPublicationSagic = new EnvoiCRPublication(SYSEXT_SAGIC);
			// Poster le message dans la bonne file d'envoi
			HashMap<String, String> message = (HashMap<String, String>) ServiceFonctionnelManager.getInstance().buildHashMapMessage(pubRegMan.getContenu(), null, null, envoiCRPublicationSagic.getTraitement(), envoiCRPublicationSagic.getTypeService());
			// Envoi proprement dit du message
			envoiCRPublicationSagic.send(message);
		} else if (SystemeExterneConstantes.EFB_VALEUR_CONSTANTE.equals(systemeExterneValConst)) {
			EnvoiCRPublication envoiCRPublicationEFB = new EnvoiCRPublication(SYSEXT_EFB);
			// R�cup�ration de la ref commande directement dans le XML EFB (pubRegMan.contenu)
			String idExterne = getRefCommandeDansXmlEfb(pubRegMan.getContenu());
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, method, "Id externe de la commande = " + idExterne);
			// Poster le message dans la bonne file d'envoi
			HashMap<String, String> message = (HashMap<String, String>) ServiceFonctionnelManager.getInstance().buildHashMapMessage(pubRegMan.getContenu(), null, null, idExterne, envoiCRPublicationEFB.getTraitement(),
					envoiCRPublicationEFB.getTypeService());
			// Envoi proprement dit du message
			envoiCRPublicationEFB.send(message);
		} else if (SystemeExterneConstantes.NUM_45R_VALEUR_CONSTANTE.equals(systemeExterneValConst)) {
			EnvoiCRPublication envoiCRPublicationCristal = new EnvoiCRPublication(SYSEXT_CRISTAL);
			// Poster le message dans la bonne file d'envoi
			HashMap<String, String> message = (HashMap<String, String>) ServiceFonctionnelManager.getInstance().buildHashMapMessage(pubRegMan.getContenu(), null, null, envoiCRPublicationCristal.getTraitement(), envoiCRPublicationCristal.getTypeService());
			// Envoi proprement dit du message
			envoiCRPublicationCristal.send(message);
		} else if (SystemeExterneConstantes.SDP_VALEUR_CONSTANTE.equals(systemeExterneValConst)) {
			EnvoiCRPublication envoiCRPublicationSupDePro = new EnvoiCRPublication(SYSEXT_SUP_DE_PRO);
			// Poster le message dans la bonne file d'envoi
			HashMap<String, String> message = (HashMap<String, String>) ServiceFonctionnelManager.getInstance().buildHashMapMessage(pubRegMan.getContenu(), null, null, envoiCRPublicationSupDePro.getTraitement(),
					envoiCRPublicationSupDePro.getTypeService());
			// Envoi proprement dit du message
			envoiCRPublicationSupDePro.send(message);
		} else if (SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(systemeExterneValConst)) {
			XStream stream = new XStream(new DomDriver());
			UpdateDeliverCustomerOrderIn updateDeliverCustomerOrderIn = (UpdateDeliverCustomerOrderIn) stream.fromXML(pubRegMan.getContenu());
			DeleguePublicationGrafic deleguePublicationGrafic = new DeleguePublicationGrafic();
			deleguePublicationGrafic.envoyerNotification(updateDeliverCustomerOrderIn);
		} else if (SystemeExterneConstantes.FRONTAL_VALEUR_CONSTANTE.equals(systemeExterneValConst)) {
			DeleguePublicationFrontal deleguePublicationFrontal = new DeleguePublicationFrontal();
			UpdateDeliverCustomerOrderFrontalIn updateDeliverCustomerOrderIn = deleguePublicationFrontal.deserializeObjectUpdateDeliverCustomerOrderFrontalIn(pubRegMan.getContenu());
			updateDeliverCustomerOrderIn.setInfoMessageWebSrv(new InfoMessageWebSrv(pubRegMan.getIdCommande()));
			deleguePublicationFrontal.envoyerNotification(updateDeliverCustomerOrderIn);
		}

		// Modifier PubRegMan.fk_estdansetatpublication � 'ENVOYE'
		pubRegMan.setEtatPublication(new EtatPublicationDTO(EtatPublicationConstantes.ENVOYE));
		ServiceManager.getInstance().getRegulManuelleManager().updatePubRegManEtat(pubRegMan);

		// Mettre � jour le jalon des lignecommande telle que
		// lignecommande.idcommande=WF.ROOTSET.ID_COMMANDE
		// Lignecommande.fk_repereparjalon='PubRegMan.fk_Jalon'
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByCommande(pubRegMan.getIdCommande());
		ServiceManager.getInstance().getCommandeManager().updateLigneCommandeJalon(lignesCde, pubRegMan.getJalon().getId());
	}

	/**
	 * Mise � jour des publications infocentres (Osiris).
	 * 
	 * @param tacheId
	 */
	public static void miseAJourTransitSystStat(String tacheId) {
		TacheDTO tache = ServiceManager.getInstance().getProcessusManager().getTache(tacheId);
		String versionArtemis = VersionArtemisUtil.getVersion(tache);

		// R�cup�ration de la commande
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(processus.getId());
		String idCommande = commande.getId();

		// Les occurences de la table TransitSystStatReguul
		List<TransitSystStatRegulDTO> transitSystStatReguls = ServiceManager.getInstance().getRegulManuelleManager().findTransitSystStatRegulByCommandeAndCodeTransfert(idCommande, CODE_TRANSFERT_ECRIT);
		for (TransitSystStatRegulDTO transitSystStatRegul : transitSystStatReguls) {
			TransitSystStatDTO transitSystStat = ServiceManager.getInstance().getRegulManuelleManager().findTransitSystStatByIdEntiteAndFormatExterne(transitSystStatRegul.getIdEntite(), transitSystStatRegul.getFormatExterne());
			if (transitSystStat != null) {

				// L'occurence TransitSystStat existe d�j� ==> on la met � jour
				transitSystStat.setIdEntite(transitSystStatRegul.getIdEntite());
				transitSystStat.setFormatExterne(transitSystStatRegul.getFormatExterne());
				if (transitSystStatRegul.getInstanceLocalisation() != null) {
					transitSystStat.setInstanceLocalisation(transitSystStatRegul.getInstanceLocalisation());
				}
				transitSystStat.setVersion(versionArtemis);
				ServiceManager.getInstance().getRegulManuelleManager().updateTransitSystStat(transitSystStat);
			} else {

				// Ajouter une occurence dans la table TransistSystStat
				TransitSystStatDTO newTransitSystStat = new TransitSystStatDTO(transitSystStatRegul.getId());
				newTransitSystStat.setIdEntite(transitSystStatRegul.getIdEntite());
				newTransitSystStat.setFormatExterne(transitSystStatRegul.getFormatExterne());
				if (transitSystStatRegul.getInstanceLocalisation() != null) {
					newTransitSystStat.setInstanceLocalisation(transitSystStatRegul.getInstanceLocalisation());
				}
				newTransitSystStat.setVersion(versionArtemis);
				ServiceManager.getInstance().getRegulManuelleManager().createTransitSystStat(newTransitSystStat);
			}
			transitSystStatRegul.setCodeTransfert(CODE_TRANSFERT_APURGER);
			ServiceManager.getInstance().getRegulManuelleManager().updateTransitSystStatRegulCodeTransfert(transitSystStatRegul);
		}
		majIndicateurRegulation(tacheId);
	}

	/**
	 * Mise � jour de l'indicateur de r�gulation � O (si r�gul manuelle) ou
	 * A (si abandon manuel) dans les lignes de commande et dans la commande
	 * correspondant � la tache.
	 * 
	 * @param tacheId
	 */
	public static void majIndicateurRegulation(String tacheId) {

		// Est-on dans le cas de la r�gul ou de l'abandon manuel
		String indicateurRegulation = null;
		TacheDTO tache = ServiceManager.getInstance().getProcessusManager().getTache(tacheId);
		if (tache != null && tache.getCatalogueTache() != null) {
			CatalogueTacheDTO catalogueTache = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tache.getCatalogueTache().getId());
			String catalogueTacheValConst = catalogueTache.getValeurConstante();
			if (CatalogueTacheConstantes.COMPLETERCR_VALEUR_CONSTANTE.equals(catalogueTacheValConst)) {
				indicateurRegulation = INDICATEUR_REGUL_O;
			} else if (CatalogueTacheConstantes.COMPLETERCRABAN_VALEUR_CONSTANTE.equals(catalogueTacheValConst)) {
				indicateurRegulation = INDICATEUR_REGUL_A;
			}
		}
		// Charger toutes les lignes de commande de la commande
		// WF.ROOTSET.ID_COMMANDE dans l_LigneCommande
		// Pour chaque ligne de commande: l_LigneCommande
		// l_LigneCommande.IndicateurRegul='O' ou 'A'
		// l_LigneCommande. DateFinLignecommande = date du jour
		// FinPour
		// Commande.IndicateurRegul='O' ou 'A'
		// Faire persister ces donn�es en base (tables lignecommande et commande)
		ProcessusDTO papaProcessus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(papaProcessus.getId());
		for (LigneCommandeDTO lc : lignesCde) {
			lc.setDatabaseDateDateFinLigneCommande(DateUtils.getDatabaseDate());
			lc.setIndicateurRegul(indicateurRegulation);
			ServiceManager.getInstance().getCommandeManager().updateLigneCommandeIndicateurRegulEtDateFin(lc);
		}
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(papaProcessus.getId());
		commande.setIndicateurRegul(indicateurRegulation);
		ServiceManager.getInstance().getCommandeManager().updateCommandeIndicateurRegul(commande);
	}

	/**
	 * Mise � jour de la table PublicationRegularisationManuelle pour le CR
	 * 
	 * @param crNonInfocentre
	 * @param etatPublication Identifiant de l'�tat de la publication mise � jour
	 */
	public static void miseAJourPubRegManNonInfocentre(CRGenNonInfocentreDTO crNonInfocentre, String etatPublication) {
		final String chaineContenu = "Contenu";
		// R�cup�ration des cl�s valeurs modifi�s par IHM
		Map<String, String> mappingDataCR = new HashMap<String, String>();
		for (ChampCRGenNonInfocentreDTO champ : crNonInfocentre.getChamps()) {
			String cleCR = champ.getId();
			mappingDataCR.put(cleCR, champ.getValeur());
		}

		// Reconstruire le CR au format XML � partir des informations
		// saisies par l'utilisateur et en fonction du syst�me externe
		String xml = null;
		if (SystemeExterneConstantes.EFB_VALEUR_CONSTANTE.equals(crNonInfocentre.getSysExterne())) {

			xml = DeleguePublicationEfb.redigerXML(mappingDataCR);

		} else if (SystemeExterneConstantes.SAGIC_VALEUR_CONSTANTE.equals(crNonInfocentre.getSysExterne())) {

			// Dans le cas de SAGIC, on doit traduire les cl�s de 4 champs pour que le redigerXML fonctionne
			// - IdIceSagic -> PARAM_ID_ICE_SAGIC
			traduireCle(mappingDataCR, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_ID, PARAM_ID_ICE_SAGIC);
			// - CodeCr -> PARAM_CODE_CR
			traduireCle(mappingDataCR, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CODE, PARAM_CODE_CR);
			// - CommentaireFT -> PARAM_COMMENT_FT
			traduireCle(mappingDataCR, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_COMMENTAIRE_FT, PARAM_COMMENT_FT);
			// - CommentaireFAI -> PARAM_COMMENT_FAI
			traduireCle(mappingDataCR, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_COMMENTAIRE_FAI, PARAM_COMMENT_FAI);
			// Appel � redigerXML
			xml = DeleguePublicationSagic.redigerXML(mappingDataCR);

		} else if (SystemeExterneConstantes.NUM_45R_VALEUR_CONSTANTE.equals(crNonInfocentre.getSysExterne())) {

			// Dans le cas de Cristal, on doit traduire les cl�s de 2 champs pour que le redigerMsg fonctionne
			// - ND -> PARAM_ND
			traduireCle(mappingDataCR, CRPublicationDTOFactory.CLE_CR_CRISTAL_ND, DeleguePublicationCristal.PARAM_ND);
			// - Operation -> PARAM_OPERATION
			traduireCle(mappingDataCR, CRPublicationDTOFactory.CLE_CR_CRISTAL_OPERATION, DeleguePublicationCristal.PARAM_OPERATION);
			// Appel � redigerMsg
			xml = DeleguePublicationCristal.redigerMsg(mappingDataCR);

		} else if (SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(crNonInfocentre.getSysExterne())) {
			ChampCRGenNonInfocentreDTO champ = CollectionUtils.getFirstOrNull(crNonInfocentre.getChamps());
			if (champ == null || !chaineContenu.equals(champ.getLibelle())) {
				throw serviceManager.getAnomalieManager().newAnomalieException(Publication.PUBLICATION_GRAFIC, AnomalieConstantes.ERREUR_TECHNIQUE, TypeAnomalieConstantes.DNR, "Impossible de r�cup�rer le contenu XML");
			}
			xml = champ.getValeur();
		} else if (SystemeExterneConstantes.FRONTAL_VALEUR_CONSTANTE.equals(crNonInfocentre.getSysExterne())) {
			ChampCRGenNonInfocentreDTO champ = CollectionUtils.getFirstOrNull(crNonInfocentre.getChamps());
			if (champ == null || !chaineContenu.equals(champ.getLibelle())) {
				throw serviceManager.getAnomalieManager().newAnomalieException(Publication.PUBLICATION_GRAFIC, AnomalieConstantes.ERREUR_TECHNIQUE, TypeAnomalieConstantes.DNR, "Impossible de r�cup�rer le contenu XML");
			}
			xml = champ.getValeur();
		}

		// Mettre � jour la table PublicationR�gularisationManuelle
		PubRegManDTO pubRegMan = ServiceManager.getInstance().getRegulManuelleManager().getPubRegMan(crNonInfocentre.getId());
		pubRegMan.setContenu(xml);
		pubRegMan.setEtatPublication(new EtatPublicationDTO(etatPublication));
		ServiceManager.getInstance().getRegulManuelleManager().updatePubRegManEtatAndContenu(pubRegMan);
	}

	/**
	 * V�rifier s'il existe des publications dans la table TransitSystStatRegul
	 * telle que TransitSystStatRegul.IdCommande=WF.ROOTSET.ID_COMMANDE
	 * et TransitSystStatRegul.CodeTransfert == null, ce qui signifie
	 * qu'elles ne sont pas encore valid�es (CodeTransfert serait alors
	 * 'ECRIT'), ni envoy�es (CodeTransfert serait alors 'APURGER')
	 * 
	 * @param tacheId
	 * @return vrai s'il existe des publications
	 */
	public static boolean isExisteTransitSystStatNonEcrit(String tacheId) {
		// R�cup�ration de la commande
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(processus.getId());

		// Les occurences de la table TransitSystStatRegul
		List<TransitSystStatRegulDTO> collectionTransitSystStatRegul = ServiceManager.getInstance().getRegulManuelleManager().findTransitSystStatRegulByCommandeAndCodeTransfert(commande.getId(), null);

		return !collectionTransitSystStatRegul.isEmpty();
	}

	/**
	 * V�rifier si toutes toutes les publications ont �t� envoy�es
	 * (hors infocentre listePublicationsSE et infocentre listePublicationsOsiris)
	 * c'est-�-dire toutes les lignes de PubRegMan sont � l'etatpublication
	 * ENVOYE et Transitsysstatregul � APURGER
	 * 
	 * @param tacheId
	 * @return vrai si toutes toutes les publications ont �t� envoy�es
	 */
	public static boolean isToutesPublicationsEnvoyees(String tacheId) {
		// R�cup�ration de la commande
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(processus.getId());

		// V�rification dans les PubRegMan
		List<PubRegManDTO> publications = ServiceManager.getInstance().getRegulManuelleManager().findPubRegManByCommandeAndNotEtat(commande.getId(), EtatPublicationConstantes.ENVOYE);

		// V�rification dans les TransitSystStatReguul
		List<TransitSystStatRegulDTO> transitSystStatReguls = ServiceManager.getInstance().getRegulManuelleManager().findTransitSystStatRegulByCommandeAndNotCodeTransfert(commande.getId(), CODE_TRANSFERT_APURGER);

		return publications.isEmpty() && transitSystStatReguls.isEmpty();
	}

	/**
	 * ControleRetourAuto
	 * 
	 * @param tacheId
	 * @param libelle
	 * @param idCurrentAgent
	 * @param wfActivity
	 * @param wfUser
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>19/07/2011</TD><TD>GPA</TD><TD>IRMA_987: Pb Retour Auto sur regularisation manuelle</TD></TR>
	 * </TABLE>
	 */
	public static void controlerRetourAuto(String tacheId, String libelle, String idCurrentAgent, WfActivity wfActivity, WfUser wfUser) {
		WorkflowManager wfManager = ServiceManager.getInstance().getWorkflowManager();

		// R�cup�ration du processus
		TacheDTO tache = ServiceManager.getInstance().getProcessusManager().getTache(tacheId);
		ProcessusDTO papaProcessus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		Map<String, String> donneesWf = wfActivity.getValues();

		// Construction de l'evenement
		Evenement evenement = ProcessusTraitement.createEvenement(CauseEvenementConstantes.RETOUR_AUTO, libelle, new Date(), idCurrentAgent, null);

		// M�moriser l'�v�nement r�cup�r�
		ProcessusTraitement.createEvtPourProcessus(evenement, papaProcessus.getId(), papaProcessus.getIdCommande());

		// Supprimer les occurrences de la table PubRegMan de la commande
		ServiceManager.getInstance().getRegulManuelleManager().deletePubRegManByProcessus(papaProcessus.getId());

		// Supprimer les occurrences de la table TransitSystStatRegul de la commande
		ServiceManager.getInstance().getRegulManuelleManager().deleteTransitSystStatRegulByProcessus(papaProcessus.getId());

		// Pour chacun des processus fils dont l'�tat est REGUL, passer l'�tat des lignes de commande � LIVR
		setEtatSousProcessusEtLigneCde(papaProcessus.getId(), EtatProcessusConstantes.REGUL, EtatProcessusConstantes.EN_COURS, EtatLigneCdeConstantes.LIVR, null, INDICATEUR_REGUL_R);

		// R�initialiser tous les champs variant avec la valeur null
		setToutesVariantes(donneesWf, null);

		// R�initialiser le champ compteur � 0
		donneesWf.put(Constantes.RS_COMPTEUR, STRING_0);

		// R�initialiser le champ regularisationManuelle � retour
		donneesWf.put(Constantes.RS_REGULARISATION_MANUELLE, VAL_DONNEESWF_RETOUR);

		// Provoquer la mise � jour du contexte � patir des donn�es de la hashmap des propri�t�s workflow qu'on vient de modifier (comme pour cloturer tache manuelle)
		serviceManager.getTacheManager().cloturerTache(tache, donneesWf, false, false, false, wfUser);
		wfManager.cloturer(wfActivity, donneesWf);
	}

	/**
	 * Retourne vrai si le champ dont la cl� est pass�e en param�tre
	 * en un champ "variante".
	 * 
	 * @param key
	 * @return bool�en
	 */
	private static boolean isVariante(String key) {
		// TODO OLD: � reprendre en plus propre
		// WfProcessDefinition processModel = (WfProcessDefinition) getModelDefinitionById(processId);
		// WfRootsetDefinition rootsetDef = processModel.getRootset();
		// rootsetDef.getVariantAttributesNames().contains(currentKey);
		return Constantes.RS_VAR_ABANDON.equals(key) || Constantes.RS_VAR_BILAN.equals(key) || Constantes.RS_VAR_INAVP.equals(key) || Constantes.RS_VAR_NOUVABAN.equals(key) || Constantes.RS_VAR_NOUVACTIV.equals(key)
				|| Constantes.RS_VAR_NOUVAFF.equals(key) || Constantes.RS_VAR_NOUVCONF.equals(key) || Constantes.RS_VAR_NOUVIDENT.equals(key) || Constantes.RS_VAR_NOUVINTERVCLI.equals(key) || Constantes.RS_VAR_NOUVMES.equals(key)
				|| Constantes.RS_VAR_NOUVMESCOM.equals(key) || Constantes.RS_VAR_REPRISE.equals(key);
	}

	/**
	 * Met � "non" toutes les variantes dans les donn�es workflow.
	 * 
	 * @param donneesWf
	 * @param valeur
	 */
	private static void setToutesVariantes(Map<String, String> donneesWf, String valeur) {
		String methodName = "setToutesVariantes";
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "R�initialisation � non des variantes");
		for (String key : donneesWf.keySet()) {
			if (isVariante(key)) {
				donneesWf.put(key, valeur);
				ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "R�initialisation � non de la variante " + key);
			}
		}
	}

	/**
	 * Modifie l'�tat des sous-processus ainsi que l'�tat des lignes de commande.
	 * 
	 * @param processusId
	 * @param etatProcAvant
	 * @param etatProcApres
	 * @param etatLigneCde
	 * @param jalonLigneCde
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>14/01/2016</TD><TD>BPE</TD><TD>QC-000709: Affichage de commandes en doublon</TD></TR>
	 * </TABLE>
	 * 
	 */
	private static void setEtatSousProcessusEtLigneCde(String processusId, String etatProcAvant, String etatProcApres, String etatLigneCde, String jalonLigneCde, String indicateurRegulLigneCde) {
		String methodName = "setEtatSousProcessusEtLigneCde";

		// Construction de la liste des processus fils
		List<ProcessusDTO> processusFils = ServiceManager.getInstance().getProcessusManager().findProcessusFils(processusId);

		// Pour chacun des processus fils dont l'�tat est etatProcAvant
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "Bouclage sur les processus fils dont l'�tat est " + etatProcAvant);
		for (ProcessusDTO procTmp : processusFils) {
			if (procTmp.getEtatProcessus() != null && etatProcAvant.equals(procTmp.getEtatProcessus().getId())) {
				ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName,
						"Sous-processus d'id=" + procTmp.getId() + " : �tat du processus est mis � " + etatProcApres + " et marquage de l'�tat des lignes de commande � " + etatLigneCde + " et du jalon � " + jalonLigneCde);

				// I_processus.EtatProcessus=etatProcApres
				procTmp.setEtatProcessus(new EtatProcessusDTO(etatProcApres));
				ServiceManager.getInstance().getProcessusManager().updateProcessusEtat(procTmp);
			}
		}
		flaguerLignesCde(processusId, etatLigneCde, jalonLigneCde, indicateurRegulLigneCde);
	}

	/**
	 * R�cup�re les lignes de commandes trait�es par le processus et marque
	 * leur �tat avec etatLigneCde (si non null) et leur jalon avec
	 * repereParJalon (si non null).
	 * 
	 * @param processusId
	 * @param etatLigneCde
	 * @param repereParJalon
	 * @param indicateurRegul
	 */
	private static void flaguerLignesCde(String processusId, String etatLigneCde, String repereParJalon, String indicateurRegul) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, "flaguerLignesCde", "Flague � '" + etatLigneCde + "' des lignes de commande du processus d'id=" + processusId);
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		for (LigneCommandeDTO lc : lignesCde) {
			if (etatLigneCde != null) {
				lc.setEtatLigneCde(new EtatLigneCdeDTO(etatLigneCde));
			}
			if (repereParJalon != null) {
				lc.setJalon(new JalonDTO(repereParJalon));
			}
			if (indicateurRegul != null) {
				lc.setIndicateurRegul(indicateurRegul);
			}
			ServiceManager.getInstance().getCommandeManager().updateLigneCommandeEtatEtJalonEtIndicateurRegul(lc);
		}
	}

	/**
	 * Renvoie la r�f�rence externe de la commande stock�e dans le message XML pour EFB
	 * 
	 * @param xml
	 * @return La r�f�rence externe de la commande
	 */
	private static String getRefCommandeDansXmlEfb(String xml) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, "getRefCommande", "Recherche de RefCommande directement dans le XML=" + xml);
		try {
			Document doc = XmlUtils.getDocument(xml);
			Element root = doc.getDocumentElement();
			NodeList refCommandeNodeList = root.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_REF_CDE);
			if (refCommandeNodeList != null && refCommandeNodeList.getLength() == 1) {
				Node refCommandeNode = refCommandeNodeList.item(0);
				return refCommandeNode.getFirstChild().getNodeValue();
			}
		} catch (Exception e) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + "format du message invalide (ref commande introuvable)", xml, e);
		}
		throw new InvalidMessageException("Erreur de recuperation du document : " + "format du message invalide (ref commande introuvable)", xml);
	}

	private static void traduireCle(Map<String, String> map, String oldKey, String newKey) {
		String valeur = map.get(oldKey);
		map.remove(oldKey);
		map.put(newKey, valeur);
	}

	/**
	 * R�veil des commandes interf�rentes
	 * 
	 * @param wfUser Point d'entr�e dans le workflow
	 * @param ligneCommandeId Ligne de commande fournie en entr�e
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>25/10/2012</TD><TD>FTE</TD><TD>EV-000183 : Apostrof</TD></TR>
	 * </TABLE>
	 */
	private static void reveilCommandesInterferentes(WfUser wfUser, String ligneCommandeId) {
		final String methodName = "reveilCommandesInterferentes";
		WorkflowManager wfManager = ServiceManager.getInstance().getWorkflowManager();

		// date du jour
		Long dateCourante = DateUtils.getDatabaseDate();
		List<InterferenceDTO> interferences = ServiceManager.getInstance().getCommandeManager().findInterferenceByLigneCommande(ligneCommandeId);
		for (InterferenceDTO interference : interferences) {
			// Valorisation de la date de fin avec la date courante
			interference.setDateFin(dateCourante);
			ServiceManager.getInstance().getCommandeManager().updateInterferenceDateFin(interference);
			// Reveil de la t�che de Workflow
			String processusId = null;
			String idRequete = interference.getId();
			// Le lastIndexOf "_" permet de r�cup�rer l'idProcessus quelque soit l'idRequete (ex: LY_G6_ln1020162 ou ln1020162)
			if ((idRequete != null) && (idRequete.length() > 0)) {
				processusId = idRequete.substring(idRequete.lastIndexOf('_') + 1);
			}
			try {
				wfManager.envoyerNotifTimerSansAttente(wfUser, processusId);
			} catch (Exception e) {
				/*
				 * on ignore l'exception. En effet, l'exception peut �tre remont�e par le workflow m�me si la notification a bien
				 * �t� re�ue. Et si elle n'a pas �t� re�ue, le workflow lancera la t�che suivante tout de m�me au bout d'un certain temps.
				 */
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, methodName, "Echec d'envoi de CR avec l'id requ�te " + idRequete + " exception ignor�e", e);
			}
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "Fin R�veil des Commandes Interferentes");
	}

	/**
	 * Envoi du message d'abandon
	 * 
	 * @param lignesCde Lignes de commande du processus
	 * @param commandeRefExterne
	 * @param evenement
	 */
	private static void envoiMessageAbandon(List<LigneCommandeDTO> lignesCde, String commandeRefExterne, Evenement evenement) {
		Set<LigneCommandeAAnnuler> listeLigneCommandeAAnnuler = new HashSet<LigneCommandeAAnnuler>();
		for (LigneCommandeDTO ligneCde : lignesCde) {
			String sysExterne = null;
			if (ligneCde.getSystemeExterne() != null) {
				sysExterne = ligneCde.getSystemeExterne().getId();
			}
			LigneCommandeAAnnuler ligneCdeAAnnuler = new LigneCommandeAAnnuler(ligneCde.getRefExterne(), sysExterne, commandeRefExterne);
			listeLigneCommandeAAnnuler.add(ligneCdeAAnnuler);
		}
		for (LigneCommandeAAnnuler ligneCdeAAnnuler : listeLigneCommandeAAnnuler) {
			// date du jour
			String today = DateUtils.format(new Date(), FORMAT_DATE_BOLBEC);
			SystemeExterneDTO systemeExterne = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, ligneCdeAAnnuler.getSystemeExterne());
			if (SystemeExterneConstantes.SAGIC_VALEUR_CONSTANTE.equals(systemeExterne.getValeurConstante())) {
				// Systeme Externe = SAGIC
				Map<String, String> mappingDataSAGIC = new HashMap<String, String>();
				// Attention, les 4 premieres cl�s sont fausses, mais puisque �a a l'air de marcher jusqu'� maintenant... !
				mappingDataSAGIC.put(com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CDE_ID, ligneCdeAAnnuler.getIdExterne());
				mappingDataSAGIC.put(com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CODE, STRING_123);
				mappingDataSAGIC.put(com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_COMMENTAIRE_FT, evenement.getLibelle());
				mappingDataSAGIC.put(com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_COMMENTAIRE_FAI, evenement.getLibCauseEvenement());
				mappingDataSAGIC.put(com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_EFFET, today);
				// R�daction du message XML du CR SAGIC
				String xmlSAGIC = DeleguePublicationSagic.redigerXML(mappingDataSAGIC);
				EnvoiCRPublication envoiCRPublication = new EnvoiCRPublication(SYSEXT_SAGIC);
				// Poster le message dans la bonne file d'envoi
				HashMap<String, String> message = (HashMap<String, String>) ServiceFonctionnelManager.getInstance().buildHashMapMessage(xmlSAGIC, null, null, envoiCRPublication.getTraitement(), envoiCRPublication.getTypeService());
				// Envoi proprement dit du message
				envoiCRPublication.send(message);
			} else if (SystemeExterneConstantes.EFB_VALEUR_CONSTANTE.equals(systemeExterne.getValeurConstante())) {
				// Systeme Externe = EFB
				Map<String, String> mappingDataEFB = DeleguePublicationEfb.mapperDonneesCommunes();
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_MODELE_LPA, STRING_COMMANDE49W);
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_VERSION_MODELE_LPA, STRING_G02R00C00);
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_REF_CDE, ligneCdeAAnnuler.getIdCommandeExterne());
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_REF_LIGNE_CDE, ligneCdeAAnnuler.getIdExterne());
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CODE_STATUT_OP, STRING_NREHD);
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_DATE_STATUT_OP, today);
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CODE_CPLT_STATUT_OP, STRING_123);
				mappingDataEFB.put(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_LIBELLE_CPLT_STATUT_OP, STRING_ECHEC_COMMANDE_ANNULEE);
				List<String> refExterneLigne = new ArrayList<String>();
				refExterneLigne.add(ligneCdeAAnnuler.getIdExterne());
				// R�daction du message XML du CR EFB
				String xmlEFB = DeleguePublicationEfb.redigerXML(mappingDataEFB, refExterneLigne);
				EnvoiCRPublication envoiCRPublication = new EnvoiCRPublication(SYSEXT_EFB);
				// Poster le message dans la bonne file d'envoi
				HashMap<String, String> message = (HashMap<String, String>) ServiceFonctionnelManager.getInstance().buildHashMapMessage(xmlEFB, null, null, envoiCRPublication.getTraitement(), envoiCRPublication.getTypeService());
				// Envoi proprement dit du message
				envoiCRPublication.send(message);
			}
		}
	}

	/**
	 * Pour mettre la commande � l'�tat termin�, il faut que tous les processus
	 * instanci�s pour livrer cette commande soient achev�s - soit normalement,
	 * soit par abandon. <br/> <li/> Si tous ses processus sont � l'�tat
	 * abandonn�, la commande est consid�r� abandonn�e �galement. <br/> <li/> Si
	 * une partie seulementdes processus a �t� abandonn� et l'autre termin�e
	 * "normalement", la commande sera mise � l'�tat termin�. <br/> <li/> Tant
	 * que certains processus sont en cours, l'�tat de la commande ne varie pas.
	 * <br/><br/>
	 * 
	 * @param commande
	 * Commande dont on veut mettre � jour l'�tat
	 */
	private static void miseAJourEtatCommande(CommandeDTO commande) {
		String methodName = "miseAJourEtatCommande";
		if (commande == null) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methodName, "D�but MAJ de l'�tat de la commande - PB : l'id de la commande est null");
		} else {
			// R�cup�ration de l'�tat de la commande
			String etatCde = getEtatCommande(commande.getId());
			boolean isEtatModifie = false;
			if (EtatProcessusConstantes.ABAN.equals(etatCde)) {
				// Commande abandonn�e : etatCde = ABAN
				isEtatModifie = !EtatCommandeConstantes.ANN.equals(commande.getEtatCommande().getId());
				commande.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.ANN));
				ServiceManager.getInstance().getCommandeManager().updateCommandeEtat(commande);

				// US-678 Notification pour la commande termin�
				NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_C, NotificationGeneriqueConstantes.TYPE_TERM, commande.getId(), commande.getId());
				serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);
			} else {
				if (EtatProcessusConstantes.TERM.equals(etatCde)) {
					// Commande termin�e : etatCde = TERM
					isEtatModifie = !EtatCommandeConstantes.TERM.equals(commande.getEtatCommande().getId());
					commande.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.TERM));
					ServiceManager.getInstance().getCommandeManager().updateCommandeEtat(commande);

					// US-678 Notification pour la commande termin�
					NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_C, NotificationGeneriqueConstantes.TYPE_TERM, commande.getId(), commande.getId());
					serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);
				}
			}
			if (isEtatModifie) {
				// L'�tat de la commande a �t� modifi�e : publication de la cl�ture de la commande
				commande.setDatabaseDateDateFinCommande(DateUtils.getDatabaseDate());
				ServiceManager.getInstance().getCommandeManager().updateCommandeDateFin(commande);
				// Transmission d'une notification
				Notification notification = new Notification(PublicationConstantes.CLOT_CDE, commande.getId());
				GestionnairePublication.publierFromEJB(notification);
			}
		}
	}

	private static String getEtatCommande(String commandeId) {
		String methodName = "getEtatCommande";
		// Initialiser une variable temporaire EtatCde � ""
		String etatCde = STRING_BLANK;
		// Chargement de toutes les lignes de commande de la commande r�cup�r�e
		List<LigneCommandeDTO> ligneCdeList = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByCommande(commandeId);
		if ((ligneCdeList == null) || (ligneCdeList.size() == 0)) {
			// Cas normalement impossible !
			ServiceManager.getInstance().getLoggerManager().severe(CLASSNAME, methodName, "Lignes de Commande non trouv�es.");
			return null;
		}
		// Parcours des lignes de commande
		for (LigneCommandeDTO ligneCommande : ligneCdeList) {
			// R�cup�ration de tous les processus (en �vitant les
			// sous-processus) de la ligne de commande
			// ==> Chaque ligne de commande a au plus 2 processus: 1 de
			// compl�tude et 1 de livraison.
			// Si celui de livraison est instanci�, on peut �viter le processus
			// de compl�tude
			ProcessusDTO processusTrouve = ServiceManager.getInstance().getProcessusManager().findProcessusByLigneCommandeAndPereAndPlusRecent(ligneCommande.getId());
			if (processusTrouve != null) {
				String etatProcessusId = null;
				if (processusTrouve.getEtatProcessus() != null) {
					etatProcessusId = processusTrouve.getEtatProcessus().getId();
				}
				// processusTrouve est le processus le plus r�cent
				if (!EtatProcessusConstantes.ABAN.equals(etatProcessusId) && !EtatProcessusConstantes.TERM.equals(etatProcessusId)) {
					// Processus non termin� ni abandonn�e (cas d'un processus encore EN_COURS)
					etatCde = etatProcessusId;
					return etatCde;
				} else if (!EtatCommandeConstantes.TERM.equals(etatCde)) {
					etatCde = etatProcessusId;
				}
			}
		}
		return etatCde;
	}

	/**
	 * Le dossier Cristal doit �tre mis � jour pour les commandes r�pondant aux crit�res suivants :
	 * - la commande est au statut � Agr�g�e �
	 * - la commande aurait d� instancier le SP Notification Parc FT (c'est-�-dire qu�au moins une des lignes de commandes porte un type op�ration ponctuelle et une famille offre parc param�tr�e dans la table MODIFICATIONPARC pour d�clencher le
	 * SPNOTPARCFT)
	 * - la commande n�a instanci� ni le SP Notification Parc FT ni le SP AnnNotification parcFT
	 * 
	 * Si la commande r�pond � ces crit�res, on positionne une information au niveau de la commande pour effectuer la mise � jour du dossier Cristal lors de la 1�re demande d�envoi d�un CR demand� de la commande.
	 * 
	 * @param commande la commande courante
	 * @return <code>true</code> si la mise � jour est n�cessaire, <code>false</code> sinon
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>16/08/2011</TD><TD>GPA</TD><TD>EV-000155: Cr�ation de la m�thode</TD></TR>
	 * <TR><TD>30/08/2011</TD><TD>GPA</TD><TD>EV-000155: Correction defect 244</TD></TR>
	 * </TABLE>
	 */
	protected static boolean isMiseAJourDossierCristalNecessaire(CommandeDTO commande) {
		String methode = "isMiseAJourDossierCristalNecessaire";
		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "d�but de la m�thode");

		boolean miseAJourDossierCristalNecessaire = false;
		if ((commande != null) && (StatutCommandeConstantes.AGREGEE.equals(commande.getStatutCommande().getId()) || isCmdeNotParcFTSpecifique(commande))) {
			// On v�rifie la n�cessit� d�instanciation de la notification Parc FT et la non r�alisation de celle-ci

			List<LigneCommandeDTO> ligneCommandeListe = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
			for (LigneCommandeDTO lc : ligneCommandeListe) {
				OffreDTO offre = serviceManager.getOffreManager().getOffreForLigneCommandeCR(lc, true);
				if (offre == null) {
					offre = serviceManager.getOffreManager().getOffreForLigneCommandeSU(lc, true);
				}

				if ((offre != null) && (offre.getFamilleOffreParc() != null) && (lc.getTypeOpPonctuelles() != null)) {
					ModificationParcDTO modificationParc = null;
					if (lc.getContexte() == null || lc.getContexte().getId() == null) {
						modificationParc = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ModificationParcDTO.class,
								new Comparaison(ModificationParc.SLINK_DANS_PROCESSUS_TYPE, Constantes.OPERATOR_EQUAL, ProcessusTypeConstantes.SPNOTPARCFT),
								new Comparaison(ModificationParc.SLINK_CONCERNE_FAMILLE_OFFRE_PARC, Constantes.OPERATOR_EQUAL, offre.getFamilleOffreParc().getId()),
								new Comparaison(ModificationParc.SLINK_POUR_TYPE_OP_PONCTUELLES, Constantes.OPERATOR_EQUAL, lc.getTypeOpPonctuelles().getId()), new Comparaison(ModificationParc.SLINK_DEPEND_CONTEXTE, Constantes.OPERATOR_IS_NULL, null));
					} else {
						modificationParc = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ModificationParcDTO.class,
								new Comparaison(ModificationParc.SLINK_DANS_PROCESSUS_TYPE, Constantes.OPERATOR_EQUAL, ProcessusTypeConstantes.SPNOTPARCFT),
								new Comparaison(ModificationParc.SLINK_CONCERNE_FAMILLE_OFFRE_PARC, Constantes.OPERATOR_EQUAL, offre.getFamilleOffreParc().getId()),
								new Comparaison(ModificationParc.SLINK_POUR_TYPE_OP_PONCTUELLES, Constantes.OPERATOR_EQUAL, lc.getTypeOpPonctuelles().getId()),
								new Comparaison(ModificationParc.SLINK_DEPEND_CONTEXTE, Constantes.OPERATOR_EQUAL, lc.getContexte().getId()));
					}

					if (modificationParc != null) {
						miseAJourDossierCristalNecessaire = true;

						// Rechercher si la commande aurait pu instancier la notification ParcFT en phase de mise en service commerciale
						ProcessusTypeDTO ptSPNOTPARCFT = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class,
								new Comparaison(ProcessusType.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, ProcessusTypeConstantes.SPNOTPARCFT_VALEUR_CONSTANTE));

						// Rechercher si la commande a instanci� la notification ParcFT en phase de mise en service commerciale ou l�annulation de la notification Parc FT
						ProcessusTypeDTO ptSPANNNOTPARCFT = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class,
								new Comparaison(ProcessusType.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, ProcessusTypeConstantes.SPANNNOTPARCFT_VALEUR_CONSTANTE));

						List<ProcessusDTO> listeProcessus = serviceManager.getProcessusManager().findProcessusByCommande(commande.getId());

						for (ProcessusDTO processus : listeProcessus) {
							ProcessusTypeDTO currentPT = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, processus.getProcessusType().getId());

							if (ptSPNOTPARCFT.getValeurConstante().equals(currentPT.getValeurConstante()) || ptSPANNNOTPARCFT.getValeurConstante().equals(currentPT.getValeurConstante())) {
								miseAJourDossierCristalNecessaire = false;
							}
						}
					}
				}
			}
		}

		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "fin de la m�thode - miseAJourDossierCristalNecessaire=" + miseAJourDossierCristalNecessaire);
		return miseAJourDossierCristalNecessaire;
	}

	/**
	 * Cr�ation d�un champ dynamique sur la commande permettant de pr�ciser que le dossier Cristal doit �tre mis � jour et que cette action n�a pas �t� r�alis�e
	 * 
	 * @param commande la commande courante
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>16/08/2011</TD><TD>GPA</TD><TD>EV-000155: Cr�ation de la m�thode</TD></TR>
	 * </TABLE>
	 */
	protected static boolean creerChampDynamiqueDossierCristal(CommandeDTO commande) {
		String methode = "creerChampDynamiqueDossierCristal";
		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "d�but de la m�thode");

		boolean champDossierCristalCree = false;

		// V�rifier l�absence du champ dynamique sur la commande
		if (commande != null) {
			Map<String, String> dynamicsCommande = commande.getDynamicCommandes();

			if (!dynamicsCommande.containsKey(ConstantesDynamicCommande.CLE_DOSSIER_CRISTAL_MAJ)) {
				// Si ce champ n�existe pas, alors ajout du champ dynamique sur la commande
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "cr�ation du champ dynamique " + ConstantesDynamicCommande.CLE_DOSSIER_CRISTAL_MAJ + " sur la commande");
				dynamicsCommande.put(ConstantesDynamicCommande.CLE_DOSSIER_CRISTAL_MAJ, ConstantesDynamicCommande.VALEUR_NON);
				serviceManager.getCommandeManager().updateDynamicCommande(commande);
				champDossierCristalCree = true;
			}
		}

		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "fin de la m�thode");
		return champDossierCristalCree;

	}

	/**
	 * M�thode permettant de savoir s'il s'agit d'une commande sp�cifique pouvant instancier le SP NOTPARCFT
	 * 
	 * @param commande
	 * @return true s'il s'agit d'une commande sp�cifique pouvant instancier le SP NOTPARCFT
	 */
	private static boolean isCmdeNotParcFTSpecifique(CommandeDTO commande) {
		if (commande != null && commande.getCasMetier() != null && commande.getCasMetier().getId() != null) {
			String valExterne = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.CLE_NOTPARCFT_SPECIFIQUE, commande.getCasMetier().getId());
			return !StringUtils.isBlank(valExterne);
		}

		return false;
	}
}
