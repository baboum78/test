package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.seba;

import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesxdsl.data.SebaDeclarations;
import com.soliste.bolbec.livraison.service.model.PredossierDTO;
import com.soliste.bolbec.livraison.service.stepauto.traitements.GestionAttenteDonePartial;

/**
 * Class pour g�rer les messaes re�us de SEBA (SEBANotifications)
 *
 * @author lherraiz
 */
public class InjecteurCRSebaNotifMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	public static final String ERREUR_DE_RECUPERATION_DU_DOCUMENT = "Erreur de recuperation du document : ";
	public static final String ERREUR_DANS_LE_MESSAGE = "Erreur dans le message re�u : ";
	final String CLASS_NAME = getClass().getName();

	/**
	 * @see AbstractInjecteurMessageHandlerBean#getActivationParam(Serializable)
	 */
	public ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException {
		return null;
	}

	/**
	 * traitement du message lu dans la file
	 *
	 * @param a_message message � traiter
	 * @throws RemoteException
	 * @throws Exception
	 */
	public void processRequest(Serializable a_message) throws RemoteException, Exception {
		final String methodName = "processRequest";
		StringBuilder sbMessage;

		loggerManager.fine(CLASS_NAME, methodName, "Traitement du message " + a_message);

		PredossierDTO predossierMessage = recupererPredossierMessage (a_message);
		if (predossierMessage != null) {
			// RG1 : Recherche d�un pr�-dossier existant
			//Si PREDOSSIER.ID = valeur champ � IAR �, sans prise en compte du � z�ro � initial (si on l�a)
			PredossierDTO predossierDTO = serviceManager.getProcessusManager().recherchePredossier(predossierMessage.getId());
			if (predossierDTO != null) {
				//RG2 : V�rification que la modification est assez r�cente
				if (predossierMessage.getDataBaseHorodatage() != null && predossierMessage.getDataBaseHorodatage() > predossierDTO.getDataBaseHorodatage()) {
					//RG4 : Mise � jour du pr�-dossier
					predossierDTO.setHorodatage(predossierMessage.getHorodatage());
					predossierDTO.setEnService(predossierMessage.isEnService());
					serviceManager.getProcessusManager().updatePredossier(predossierDTO);
				}
			} else {
				//RG3 : Cr�ation d�un pr�-dossier
				Long dataBaseDate = predossierMessage.getDataBaseHorodatage();
				if (dataBaseDate == null) {
					dataBaseDate = DateUtils.getDatabaseDate();
				}
				predossierDTO = new PredossierDTO(predossierMessage.getId(), dataBaseDate, predossierMessage.isEnService());
				serviceManager.getProcessusManager().createPredossier(predossierDTO);
			}
			// Faire appel au traitement MG_GestionAttenteDonePartial pour rechercher s�il y a un attendu
			// correspondant au TYPEEVT = � ONT � et IDCORRELATION = ID de la table PREDOSSIER
			GestionAttenteDonePartial.rechercherAttendu(Constantes.TYPE_EVT_ONT, predossierDTO.getId(), SebaDeclarations.TAG_CONFIGURER_SN_SUR_OLT);
		} else {
			loggerManager.fine(CLASS_NAME, methodName, "Erreur dans le message re�u " + a_message);
			throw new InvalidMessageException(ERREUR_DANS_LE_MESSAGE + "donn�es vides ou incoh�rentes" , a_message);
		}
	}

	/**
	 * getDocument
	 * 
	 * @param a_message
	 * Serializable
	 * @return Document
	 * @throws InvalidMessageException
	 */
	private Document getDocument(Serializable a_message) throws InvalidMessageException {
		Document l_doc;
		try {
			l_doc = XmlUtils.getDocument((String) a_message, InjecteurCRSebaNotifMessageHandlerBean.class.getResource(SebaDeclarations.SEBA_NOTIFICATIONS_XSD).getFile());
		} catch (IOException ioe) {
			throw new InvalidMessageException(ERREUR_DE_RECUPERATION_DU_DOCUMENT + ioe.getMessage(), a_message, ioe);
		} catch (SAXException saxe) {
			throw new InvalidMessageException(ERREUR_DE_RECUPERATION_DU_DOCUMENT + saxe.getMessage(), a_message, saxe);
		}
		return l_doc;
	}

	/**
	 * recuperer l'information re�u du message
	 *
	 * @param a_message
	 * @return
	 */
	public PredossierDTO recupererPredossierMessage (Serializable a_message) {
		final String methodName = "recupererPredossierMessage";
		Document xmlSeba = getDocument(a_message);
		Element l_root = xmlSeba.getDocumentElement();
		NodeList nodeList = l_root.getElementsByTagName(SebaDeclarations.TAG_CONFIGURER_SN_SUR_OLT);
		if (nodeList.getLength() == 1) {
			String iarStr = recupererValeurTag(nodeList, SebaDeclarations.TAG_IAR);
			if (StringUtils.isBlank(iarStr)) {
				return null;
			}
			//sans prise en compte du � z�ro � initial (si on l�a)
			if (iarStr.startsWith(Constantes.STRING_0)) {
				iarStr = iarStr.substring(1);
			}
			Long dataBasedate = null;
			String dateStr = recupererValeurTag(nodeList, SebaDeclarations.TAG_DATE_MODIFICATION);
			if (StringUtils.isBlank(dateStr)) {
				dateStr = recupererValeurTag(nodeList, SebaDeclarations.TAG_DATE_CREATION);
			}
			if (StringUtils.isNotBlank(dateStr)) {
				try {
					Date date = DateUtils.parseDate(dateStr, SebaDeclarations.SEBA_DATE_PATTERN);
					dataBasedate = DateUtils.getDatabaseDate(date);
				} catch (ParseException e) {
					loggerManager.fine(CLASS_NAME, methodName, ERREUR_DANS_LE_MESSAGE + "Date re�u mal format�e");
					return null;
				}
			}
			String etatDossier = recupererValeurTag(nodeList, SebaDeclarations.TAG_ETAT_DOSSIER);
			return new PredossierDTO(iarStr, dataBasedate, SebaDeclarations.VALEUR_ETAT_DOSSIER_SUCCES.equals(etatDossier));
		}
		return null;
	}

	/**
	 * recuperer la valeur du "tagName" du nodeList du message re�u
	 *
	 * @param nodeList
	 * @param tagName
	 * @return
	 */
	private String recupererValeurTag (NodeList nodeList, String tagName) {
		Element node = (Element) nodeList.item(0);
		NodeList nodeListTagName = node.getElementsByTagName(tagName);
		if (nodeListTagName.getLength() == 1) {
			Element element = (Element) nodeListTagName.item(0);
			Node firstChild = element.getFirstChild();
			if (firstChild != null) {
				return firstChild.getNodeValue();
			}
		}
		return null;
	}

}