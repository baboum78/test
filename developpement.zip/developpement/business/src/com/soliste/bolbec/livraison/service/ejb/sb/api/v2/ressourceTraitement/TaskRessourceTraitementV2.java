package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.ConstantesAPI;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.utils.TaskUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCause;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCauseRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Role;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.TaskStatus;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.TaskRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.Task;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.CloturerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.ReassignerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfTache;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.ProcessusTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CloturerTacheManuelleCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.TacheManuelleDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.exception.UnavailableTaskException;
import com.soliste.bolbec.livraison.service.exception.TaskValidationException;
import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.VersionArtemisUtil;

import aps.CategorieEvenementConstantes;
import aps.CauseEvenementConstantes;

/**
 * 
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/01/2018</TD><TD>AJO</TD><TD>QC-931: Pb deadlock</TD></TR>
 * 
 */
public class TaskRessourceTraitementV2 extends TaskRessourceTraitement {

	protected static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	private static final String CLASS_NAME = TaskRessourceTraitementV2.class.getName();

	private static final String REASSIGNAVP = "REASSIGNAVP";
	private static final String STRING_UNDERSCORE = "_";
	private static final String MANUELLE = "MANUELLE";

	@Override
	public Response getTache(String idCommande, String idtache, @SuppressWarnings("unused") MessageContext context) {
		if (StringUtils.isBlank(idCommande)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskorderidnotfound.createAPIException();
		}

		if (StringUtils.isBlank(idtache)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskidnotfound.createAPIException();
		}

		CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByTache(idtache);

		if (commandeDTO == null) {
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		if ((!idCommande.equals(commandeDTO.getId()))) {
			// ERR 404
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		TacheDTO tacheDTO = PROCESSUS_MANAGER.getTache(idtache);
		if (tacheDTO == null) {
			// ERR 404 Task non trouv�
			throw APIExceptionEnum.taskidnotfound.createAPIException(idtache);
		}

		// On cree l objet de sortie
		Task task = new Task();

		task.setId(idtache);

		// Si la tache est presente dans TacheEncours alors status:inprogress,sinon status:finished
		TacheEnCoursDTO tacheEncours = PROCESSUS_MANAGER.getTacheEnCours(idtache);
		if (tacheEncours != null) {
			task.setState(TaskStatus.inprogress);
		} else {
			task.setState(TaskStatus.finished);
		}

		// On construit l objet eventCauseRef
		EventCauseRef eventCauseRefTache = new EventCauseRef();
		EvtDTO evtTache = tacheDTO.getEvt();

		TaskUtils.initialiserEventCauseRef(evtTache, eventCauseRefTache);
		task.setClosureEventCause(eventCauseRefTache);

		if (StringUtils.isNotBlank(tacheDTO.getLibelle())) {
			task.setLabel(tacheDTO.getLibelle());
		}
		if (StringUtils.isNotBlank(tacheDTO.getLibelleCourt())) {
			task.setShortLabel(tacheDTO.getLibelleCourt());
		}

		if (tacheDTO.getFaitParRole() != null) {
			RoleDTO roleDTO = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(RoleDTO.class, tacheDTO.getFaitParRole().getId());
			Role role = new Role();
			role.setId(roleDTO.getId());
			role.setLabel(roleDTO.getLibelle());
			task.setAssignatedRole(role);
		}

		return Response.ok(task).build();
	}

	public Response cloturerAVP(String idCommande, String idtache, Task task, MessageContext context) {
		String methode = "patchTask";
		LOGGERMANAGER.fine(CLASS_NAME, methode, " mise a jour de la tache id :" + idtache + " pour la commande la commande id :" + idCommande);
		if (StringUtils.isBlank(idtache)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskidnotfound.createAPIException();
		}
		if (StringUtils.isBlank(idCommande)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskorderidnotfound.createAPIException();
		}

		CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByTache(idtache);

		if (commandeDTO == null) {
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		if ((!idCommande.equals(commandeDTO.getId()))) {
			// ERR 404
			throw APIExceptionEnum.taskidorderandorderidnotlinked.createAPIException(idCommande);
		}

		TacheDTO tacheDTO = PROCESSUS_MANAGER.getTache(idtache);

		if (tacheDTO == null) {
			// ERR 400 badRequest
			throw APIExceptionEnum.tasknotfound.createAPIException(idtache);
		}

		if (TaskStatus.unknown.equals(task.getState())) {
			throw APIExceptionEnum.taskbadstatus.createAPIException();
		}

		TacheEnCoursDTO tacheec = PROCESSUS_MANAGER.getTacheEnCours(idtache);
		if (tacheec == null) {
			throw APIExceptionEnum.tasknotinprogress.createAPIException();
		}
		if (StringUtils.isNotBlank(tacheDTO.getLibelle())) {
			task.setLabel(tacheDTO.getLibelle());
		}
		if (StringUtils.isNotBlank(tacheDTO.getLibelleCourt())) {
			task.setShortLabel(tacheDTO.getLibelleCourt());
		}

		task.setId(tacheDTO.getId());

		// Obtention de l'User et du workflow permettant d'acc�der aux causes ev�nement de la t�che.
		final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
		AgentDTO agent = ServiceManager.getInstance().getAgentManager().getCurrentAgent(agentName, StringUtils.lowerCase(Constantes.APPLICATION_TYPE));
		WfUser wfU = WFSERVICES.getWfUser(agent);
		WfActivity wfActivity = WKF_MANAGER.getWfActivity(wfU, idCommande, idtache);
		if (wfActivity == null) {
			throw APIExceptionEnum.taskwkfactivitynull.createAPIException();
		}
		WfTache wftache = new WfTache(wfActivity);
		ProcessusDTO process = PROCESSUS_MANAGER.findProcessusByTacheAndPere(idtache);
		// SI pas de date renseign�:
		Calendar date = Calendar.getInstance();
		// Si l'utilisateur veut juste changer le r�le de la tache
		String newRole = null;
		if (task.getAssignatedRole() != null) {
			newRole = ((Role) task.getAssignatedRole()).getId();
		}

		if (!tacheDTO.getFaitParRole().getId().equals(newRole) && !TaskStatus.finished.equals(task.getState())) {
			if (task.getAssignatedRole() != null && !TaskUtils.estUnRolePourReassigner(wftache, newRole)) {
				throw APIExceptionEnum.taskrolenotreassignable.createAPIException();
			}
			// si le statut de la t�che n'est pas renseign�
			if (task.getAssignatedRole() == null) {
				throw APIExceptionEnum.taskstatusnull.createAPIException();
			}
			String info = task.getLabel();
			CauseEvenementDTO causeEvenement = CollectionUtils.getFirstOrNull(TaskUtils.getCauseEvenementAutoriseesPourCategorie(CategorieEvenementConstantes.REASSIGN, VersionArtemisUtil.getVersion(process)));
			if (!REASSIGNAVP.equals(causeEvenement.getValeurConstante())) {
				throw APIExceptionEnum.tasknotcausereassignable.createAPIException();
			}

			try {
				task.setDate(date);
				try {
					WKF_MANAGER.reserver(wfActivity, agent.getFullName());
				} catch (UnavailableTaskException e) {
					throw APIExceptionEnum.taskalreadyreserved.createAPIException(tacheDTO.getId());
				}

				AVP_MANAGER.reassignerAvp(tacheec.getId(), info, causeEvenement.getId(), ((Role) task.getAssignatedRole()).getId(), agent.getId(), wfActivity, agent);

			} catch (ReassignerAvpException e) {
				try {
					if (!wfActivity.isAvailable() && wfActivity.isReservedBySameUser()) {
						WKF_MANAGER.liberer(wfActivity);
					}
				} catch (Exception e2) {
					LOGGERMANAGER.warning(CLASS_NAME, methode, " erreur dans la liberation de l'activity apr�s �chec de la reassignation de la commande " + idCommande);
				}
				throw APIExceptionEnum.tasknotcausereassignable.createAPIException();
			} finally {
				// US-678 Notification pour action de reasignation
				String valPrec = tacheDTO.getFaitParRole().getId();
				NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A, NotificationGeneriqueConstantes.TYPE_ASSIG,tacheDTO.getId(),valPrec,newRole,agent.getId(),idCommande);
				SERVICE_MANAGER.getNotificationGeneriqueManager().emettreNotification(ng);
			}

			return getTache(idCommande, idtache, context);
		}

		// // Si on essaie de r�assigner une t�che au r�le qu'elle a d�j�
		if (task.getAssignatedRole() != null && tacheDTO.getFaitParRole().getId().equals(((Role) task.getAssignatedRole()).getId())) {
			throw APIExceptionEnum.taskrolenotreassignable.createAPIException(idtache);
		}

		// Si le r�le est identique et que la t�che du body n'est pas en statut finished
		if (!TaskStatus.finished.equals(task.getState())) {
			throw APIExceptionEnum.tasknotstatusfinished.createAPIException(idtache);
		}

		// Si l'on souhaite cl�turer la t�che.
		EventCauseRef eventCauseRef = task.getClosureEventCause();

		if (eventCauseRef == null) {
			throw APIExceptionEnum.taskeventcauserefnull.createAPIException(idtache);
		}

		if (StringUtils.isBlank(eventCauseRef.getId())) {
			// Err 404
			throw APIExceptionEnum.taskeventcauserefidnull.createAPIException(idtache);
		}

		// La � closureEventCause.Id � doit correspondre � une cause existante et autoris�e pour la t�che concern�e
		// R�cup�ration des causes evenements disponibles
		List<EventCause> causeEvenements;

		// On regarde si on est dans le cas d'une t�che manuelle
		CatalogueTacheDTO catalogueTache = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tacheDTO.getCatalogueTache().getId());
		if (MANUELLE.equals(catalogueTache.getType())) {
			// On r�cup�re la liste des causes �v�nements autoris�es pour les t�ches manuelles
			causeEvenements = TaskUtils.getCauseEvenementAutoriseesPourTacheMan(tacheDTO);
		} else {
			try {
				causeEvenements = TaskUtils.getCauseEvenementAutoriseesPourCloturer(wftache);
			} catch (DataException e2) {
				throw APIExceptionEnum.tasklisteventcausenull.createAPIException(tacheDTO.getId());
			}
		}

		// On v�rifie que les �l�ments donn�s dans la t�che Task existent bien dans la liste de causes autoris�es pour cloturer.
		if (!TaskUtils.estDansListeCausePossiblePourCloturer(causeEvenements, eventCauseRef)) {
			// ERR 404 Task non trouv�
			throw APIExceptionEnum.taskcausenotpossible.createAPIException(tacheDTO.getId(), task.getClosureEventCause().getId());
		}

		// Initialisation des valeurs WfTache et proprietesWorkflow permettant de cl�turer la t�che.
		Map<String, String> proprietesWorkflow = wfActivity.getValues();

		if (CauseEvenementConstantes.AFFECSATURATION_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId()) || (CauseEvenementConstantes.DESATBLFT_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId()))
				|| (CauseEvenementConstantes.DESATBLORT_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId())) || (CauseEvenementConstantes.AFFECSATURATIONBL_VALEUR_CONSTANTE.equals(task.getClosureEventCause().getId()))) {
			// Si on est dans le cas o� nous pouvons renseigner la date
			if (task.getDate() == null) {
				throw APIExceptionEnum.taskdatenotfound.createAPIException();
			}
			Date startOfToday = DateUtils.createStartOfDay(new Date());
			if (task.getDate().getTime().before(startOfToday)) {
				throw APIExceptionEnum.taskdatetoosoon.createAPIException();
			}
			date = org.apache.commons.lang3.time.DateUtils.toCalendar(task.getDate().getTime());
		}
		if (tacheDTO.getFaitParRole() != null) {
			RoleDTO roleDTO = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(RoleDTO.class, tacheDTO.getFaitParRole().getId());
			Role role = new Role();
			role.setId(roleDTO.getId());
			role.setLabel(roleDTO.getLibelle());
			task.setAssignatedRole(role);
		}
		task.setDate(date);
		// Remplace l'appel � getTache QC-931
		task.setState(TaskStatus.finished);
		EventCauseRef eventCauseRefTache = new EventCauseRef();
		EvtDTO evtTache = tacheDTO.getEvt();
		TaskUtils.initialiserEventCauseRef(evtTache, eventCauseRefTache);
		task.setClosureEventCause(eventCauseRefTache);
		// Permet de reserver la t�che.
		try {
			WKF_MANAGER.reserver(wfActivity, agent.getFullName());
		} catch (UnavailableTaskException e1) {
			throw APIExceptionEnum.taskalreadyreserved.createAPIException(tacheDTO.getId());
		}

		// Si c'est une t�che manuelle, on la clos comme dans le cas d'une action IHM
		if (MANUELLE.equals(catalogueTache.getType())) {
			CloturerTacheManuelleCommande commande = TaskUtils.createTacheManuelleCommande(tacheDTO.getId(), TacheManuelleDTOFactory.getCorrespondanceType(tacheDTO), wftache);
			ProcessusTraitement.cloturerTacheManuelle(commande, wfU);

			// US-678 Notification pour action de cloturer
			NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A, NotificationGeneriqueConstantes.TYPE_TERM, idtache, wfU.getId(),idCommande);
			SERVICE_MANAGER.getNotificationGeneriqueManager().emettreNotification(ng);
		} else {
			try {
				List<LigneCommandeDTO> listeLigneCommande = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByCommande(commandeDTO.getId());
				CloturerAvpCommande commande = TaskUtils.createCommande(proprietesWorkflow, date.getTime(), wftache, tacheDTO.getId(), task.getClosureEventCause().getComment(), commandeDTO.getVersionArtemis() + STRING_UNDERSCORE + eventCauseRef.getId(), task.getData(), listeLigneCommande);
				AVP_MANAGER.cloturerAvp(commande, wfU);
			} catch (CloturerAvpException e) {
				WKF_MANAGER.liberer(wfActivity);
				throw APIExceptionEnum.taskcloseexception.createAPIException(tacheDTO.getId());
			}catch (TaskValidationException tve) {
				WKF_MANAGER.liberer(wfActivity);
				throw APIExceptionEnum.taskerrorvalidating.createAPIException(tve.getChamp(), tve.getSize());
			} catch (Exception e1) {
				WKF_MANAGER.liberer(wfActivity);
				throw APIExceptionEnum.generic415.createAPIException();
			} finally {
				// US-678 Notification pour action de cloturer
				NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A, NotificationGeneriqueConstantes.TYPE_TERM, idtache, wfU.getId(),idCommande);
				SERVICE_MANAGER.getNotificationGeneriqueManager().emettreNotification(ng);
			}
		}
		return Response.ok(task).build();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.TaskRessourceTraitement#getCausesEvenementsByTacheId(java.lang.String, java.lang.String, org.apache.cxf.jaxrs.ext.MessageContext)
	 */
	@Override
	public Response getCausesEvenementsByTacheId(String idCommande, String idtache, MessageContext context) {
		if (StringUtils.isBlank(idCommande)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskorderidnotfound.createAPIException();
		}

		if (StringUtils.isBlank(idtache)) {
			// ERR 400 badRequest
			throw APIExceptionEnum.taskidnotfound.createAPIException();
		}

		CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByTache(idtache);

		if (commandeDTO == null) {
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		if (!idCommande.equals(commandeDTO.getId())) {
			// ERR 404
			throw APIExceptionEnum.taskidandorderidnotlinked.createAPIException(idtache, idCommande);
		}

		TacheEnCoursDTO tacheDTO = PROCESSUS_MANAGER.getTacheEnCours(idtache);
		if (tacheDTO == null) {
			// ERR 404 Task non trouv�
			throw APIExceptionEnum.tasknotfound.createAPIException(idtache);
		}
		TacheDTO tache = PROCESSUS_MANAGER.getTache(idtache);

		List<EventCause> eventlst;

		// On regarde si on est dans le cas d'une t�che manuelle
		CatalogueTacheDTO catalogueTache = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tache.getCatalogueTache().getId());
		if (MANUELLE.equals(catalogueTache.getType())) {
			// On r�cup�re la liste des causes �v�nements autoris�es pour les t�ches manuelles
			eventlst = TaskUtils.getCauseEvenementAutoriseesPourTacheMan(tache);
		} else {
			// Obtention de l'User et du workflow permettant d'acc�der aux causes ev�nement de la t�che.
			final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
			AgentDTO agent = ServiceManager.getInstance().getAgentManager().getCurrentAgent(agentName, StringUtils.lowerCase(Constantes.APPLICATION_TYPE));
			WfUser wfU = WFSERVICES.getWfUser(agent);
			if (tache.getEvt() == null) {
				throw APIExceptionEnum.taskeventnull.createAPIException(idtache);
			}
			WfActivity wfActivity = WKF_MANAGER.getWfActivity(wfU, idCommande, idtache);
			if (wfActivity == null) {
				throw APIExceptionEnum.tasklisteventnotwkfactivity.createAPIException(tacheDTO.getId());
			}
			WfTache wftache = new WfTache(wfActivity);
			// R�cup�ration des causes evenements disponibles

			try {
				eventlst = TaskUtils.getCauseEvenementAutoriseesPourCloturer(wftache);
			} catch (DataException e2) {
				throw APIExceptionEnum.tasklisteventcausenull.createAPIException(tacheDTO.getId());
			}
		}

		if (eventlst.isEmpty()) {
			throw APIExceptionEnum.tasklisteventcausenull.createAPIException(idtache);
		}

		return Response.ok(eventlst).build();
	}

	public void validate(@SuppressWarnings("unused") Task task) {

	}
}
