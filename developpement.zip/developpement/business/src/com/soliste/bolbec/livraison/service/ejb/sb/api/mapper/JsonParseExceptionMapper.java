package com.soliste.bolbec.livraison.service.ejb.sb.api.mapper;

import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import org.codehaus.jackson.JsonParseException;

import com.soliste.bolbec.commun.service.ConstantesAPI;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;

/**
 * JsonParseExceptionMapper
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@Provider
@Produces({ "application/json" })
public class JsonParseExceptionMapper implements ExceptionMapper<JsonParseException> {

	@Override
	public Response toResponse(@SuppressWarnings("unused") JsonParseException e) {
		return Response.fromResponse(APIExceptionEnum.generic400.createAPIException().getReponse()).header(ConstantesAPI.HEADER_CONTENT_TYPE, ConstantesAPI.CONTENT_TYPE_JSON_UTF8).build();
	}

}