package com.soliste.bolbec.livraison.service.ejb.sb.api.utils;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Appointment;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.AppointmentStatus;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

public class AppointmentUtils {

	protected static CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();

	/**
	 * Transforme un interventionDTO en Appointment object
	 * getAppointmentByInterventionDTO
	 * 
	 * @param interventionDTO
	 * @return
	 */
	public static Appointment getAppointmentByInterventionDTO(InterventionDTO interventionDTO) {

		final Appointment appointment = new Appointment();

		if (interventionDTO.getEtatIntervention() != null && StringUtils.isNotBlank(interventionDTO.getEtatIntervention().getId())) {
			AppointmentStatus status = AppointmentStatus.getEtatById(interventionDTO.getEtatIntervention().getId());
			appointment.setState(status);
		}

		if (StringUtils.isNotBlank(interventionDTO.getId())) {
			appointment.setId(interventionDTO.getId());
		}

		if (StringUtils.isNotBlank(interventionDTO.getReference())) {
			appointment.setAppointmentRef(interventionDTO.getReference());
		}

		if (interventionDTO.getDebutPlage() != null) {
			Calendar dateDebutIterv = DateUtils.toCalendar(interventionDTO.getDebutPlage());
			appointment.setStartDate(dateDebutIterv);
		}

		if (interventionDTO.getFinPlage() != null) {
			Calendar dateFinIterv = DateUtils.toCalendar(interventionDTO.getFinPlage());
			appointment.setEndDate(dateFinIterv);
		}

		if (interventionDTO.getDatePrise() != null) {
			Calendar dateReservIterv = DateUtils.toCalendar(interventionDTO.getDatePrise());
			appointment.setReservationDate(dateReservIterv);
		}

		if (StringUtils.isNotBlank(interventionDTO.getObservation())) {
			appointment.setAppointmentObservation(interventionDTO.getObservation());
		}

		if (StringUtils.isNotBlank(interventionDTO.getRefExterne())) {
			appointment.setExternalId(interventionDTO.getRefExterne());
		}

		if (interventionDTO.getDateEnvoiOt() != null) {
			Calendar dateEnvoieIterv = DateUtils.toCalendar(interventionDTO.getDateEnvoiOt());
			appointment.setSentOTDate(dateEnvoieIterv);
		}
		if (interventionDTO.getRefErdv() != null) {
			appointment.setErdvId(interventionDTO.getRefErdv());
		}
		return appointment;
	}

	/**
	 * R�cup�re une liste d'interventions pour chacune d'elles la plus r�cente par ligne de commande
	 * 
	 * @param lignesCommandeListe la liste de lignes de commande
	 * @return la liste d'intervention la plus r�cente
	 */
	public static List<InterventionDTO> recupererListeInterventionsLesPlusRecentesParLigneCommande(final List<LigneCommandeDTO> lignesCommandeListe) {
		final List<InterventionDTO> interventionsList = new ArrayList<InterventionDTO>();
		InterventionDTO intervention;
		for (LigneCommandeDTO ligneCommande : lignesCommandeListe) {
			intervention = COMMANDE_MANAGER.findInterventionPlusRecenteByLdc(ligneCommande.getId());
			if (intervention != null) {
				interventionsList.add(intervention);
			}
		}
		return interventionsList;
	}

	/**
	 * On v�rifie si la commande a bien une intervention d'id idIntervention
	 * 
	 * @param idIntervention
	 * @param idCommande
	 * @return
	 */
	public static boolean interventionLieeACommande(String idIntervention, String idCommande) {
		// On recherche les lignes de commande li�es � la commande
		List<LigneCommandeDTO> ldcList = COMMANDE_MANAGER.findLigneCommandeByCommande(idCommande);

		// On r�cup�re la liste d'intervention la plus r�cente par liste de ligne de commande
		List<InterventionDTO> interventionsList = recupererListeInterventionsLesPlusRecentesParLigneCommande(ldcList);

		for (InterventionDTO interventionDTO : interventionsList) {
			if (interventionDTO != null && idIntervention.equals(interventionDTO.getId())) {
				return true;
			}
		}
		return false;
	}

}
