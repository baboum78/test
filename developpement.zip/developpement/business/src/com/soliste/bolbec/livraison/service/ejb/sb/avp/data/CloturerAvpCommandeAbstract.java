package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;

import java.util.List;

/**
 * Classe abstraite cr��e pour la Artemis-2867 : ajout d'une m�thode setDatas commune � toutes les classes filles, le contenu sera diff�rent en fonction des param�tres de chaque classe fille
 */
public abstract class CloturerAvpCommandeAbstract {

	public abstract void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande);
}
