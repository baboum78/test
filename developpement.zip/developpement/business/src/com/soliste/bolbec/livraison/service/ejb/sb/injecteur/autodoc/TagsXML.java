/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.autodoc;

/**
 */
public interface TagsXML {

	/** Balise contenu */
	String TAG_CONTENU = "Contenu";
	/** Balise IDroutage */
	String TAG_IDROUTAGE = "IDroutage";
	/** Balise racine */
	String TAG_ROOT = "Blocxml";
}