/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;

/**
 * Le DTO pour l'entit� champ d'un CR non infocentre
 */
public class ChampCRGenNonInfocentreDTO implements Serializable {

	private String id;

	private String libelle;
	private String valeur;
	private boolean obligatoire;
	private boolean modifiable;

	/**
	 * 
	 * @param id
	 */
	public ChampCRGenNonInfocentreDTO(String id) {
		super();
		this.id = id;
	}

	/**
	 * Retourne le <code>id</code>
	 * 
	 * @return le <code>id</code>
	 */
	public String getId() {
		return id;
	}

	/**
	 * Affecte le <code>id</code>
	 * 
	 * @param id le <code>id</code> � affecter
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Retourne le <code>libelle</code>
	 * 
	 * @return le <code>libelle</code>
	 */
	public String getLibelle() {
		return libelle;
	}

	/**
	 * Affecte le <code>libelle</code>
	 * 
	 * @param libelle le <code>libelle</code> � affecter
	 */
	public void setLibelle(String libelle) {
		this.libelle = libelle;
	}

	/**
	 * Retourne le <code>valeur</code>
	 * 
	 * @return le <code>valeur</code>
	 */
	public String getValeur() {
		return valeur;
	}

	/**
	 * Affecte le <code>valeur</code>
	 * 
	 * @param valeur le <code>valeur</code> � affecter
	 */
	public void setValeur(String valeur) {
		this.valeur = valeur;
	}

	/**
	 * Retourne le <code>obligatoire</code>
	 * 
	 * @return le <code>obligatoire</code>
	 */
	public boolean isObligatoire() {
		return obligatoire;
	}

	/**
	 * Affecte le <code>obligatoire</code>
	 * 
	 * @param obligatoire le <code>obligatoire</code> � affecter
	 */
	public void setObligatoire(boolean obligatoire) {
		this.obligatoire = obligatoire;
	}

	/**
	 * Retourne le <code>modifiable</code>
	 * 
	 * @return le <code>modifiable</code>
	 */
	public boolean isModifiable() {
		return modifiable;
	}

	/**
	 * Affecte le <code>modifiable</code>
	 * 
	 * @param modifiable le <code>modifiable</code> � affecter
	 */
	public void setModifiable(boolean modifiable) {
		this.modifiable = modifiable;
	}

}
