/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

import aps.ParametreArtemis;
import aps.Repartiteur;
import aps.ServiceExterneConstantes;
import aps.SystemeExterneConstantes;
import aps.TraductionCatClient;
import aps.TraductionCatalogue;
import bolbec.injection.xml.generated.ClientContractant;
import bolbec.injection.xml.generated.ClientLivre;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.ElementParcAffecte;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.Message;
import bolbec.injection.xml.generated.ParametreType;
import bolbec.injection.xml.generated.ProduitServiceSouhaite;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.IC42CConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.IC_42C;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.InstanceSeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.ProduitServiceDTO;
import com.soliste.bolbec.livraison.service.model.RepartiteurDTO;
import com.soliste.bolbec.livraison.service.model.TraductionCatClientDTO;
import com.soliste.bolbec.livraison.service.model.TraductionCatalogueDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.TraductionManager;
import com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/06/2010</TD><TD>DBA</TD><TD>EV-000072: Maintien de la portabilit� dans le parc VIO lors de la ResilHD </TD></TR>
 * <TR><TD>15/09/2010</TD><TD>YTR</TD><TD>IRMA_906 ajout de la recherche de l'offre avec une "cle is NULL" pour l'adaptateur 42C </TD></TR>
 * <TR><TD>02/12/2010</TD><TD>GPA</TD><TD>Suppression des appels � la classe LocalisationTraitement</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>GPA</TD><TD>Modification de cartouches</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>14/04/2011</TD><TD>CCL</TD><TD>BOLBEC-1236 Optimisation de l'utilisation des HashMap</TD></TR>
 * <TR><TD>27/03/2012</TD><TD>BPE</TD><TD>DE-000292 : Logs avec accent partiellement erron�s</TD></TR>
 * </TABLE>
 * The Class AdaptationUtil.
 * 
 * @author
 */
public class AdaptationUtil {

	/** Manager permettant l'utilisation des m�canismes m�tiers */
	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	/** Nom de la classe. */
	private static final String CLASS_NAME = AdaptationUtil.class.getName();

	/** String CLIENT_INCONNU. */
	private static final String CLIENT_INCONNU = "INCONNU";

	/** long HOUR_IN_MILLIS. */
	private static final long HOUR_IN_MILLIS = 1000 * 60 * 60;

	/** String SEPARATEUR. */
	private static final String SEPARATEUR = "_";

	/** String MSG_BEGIN. */
	private static final String MSG_BEGIN = "Debut";

	/** String MSG_END. */
	private static final String MSG_END = "Fin";

	/** String STRING_MIDNIGHT. */
	private static final String STRING_MIDNIGHT = " 00:00:00";

	/** String STRING_ND. */
	private static final String STRING_ND = "ND";

	/** The date ligne cde. */
	private String dateLigneCde;

	/** The map r g0. */
	private Map<String, List<ValeurParametreDTO>> mapRG0;

	/** The map r g2. */
	private Map<String, Object> mapRG2;

	/** The map r g6. */
	private Map<String, String> mapRG6;

	/** The prefixe. */
	private String prefixe;

	/**
	 * Constructor.
	 * 
	 * @param prefixe the prefixe
	 */
	public AdaptationUtil(String prefixe) {
		this.prefixe = prefixe;
		mapRG0 = null;
		mapRG2 = null;
		mapRG6 = null;
	}

	/**
	 * traduire convertit l'objet IC_42C en intention de commande au format
	 * interne Artemis.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * @param instanceLocalisation l'instance localisation � utiliser pour cette IC
	 * 
	 * @return Serializable message au format Artemis
	 */
	public Message traduire(IC_42C ic42c, String instanceLocalisation) {
		final String method = "traduire";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		Date l_dateCourante = new Date();

		// Cr�ation du message d'intention de commande au format interne Artemis
		Message l_message = new Message();
		l_message.setIdEmetteur(SystemeExterneConstantes.NUM_42C);
		l_message.setVersion(getVersionInjecteur());
		l_message.setDateEmission(DateUtils.format(l_dateCourante, IC42CConstantes.FORMAT_DATE_HEURE));
		l_message.setCommande(getCommande(ic42c, instanceLocalisation));

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_message;
	}

	/**
	 * estValideFormat v�rifie si le ND est dans un format valide.
	 * 
	 * @param nd the nd
	 * 
	 * @return boolean
	 */
	private boolean estValideND(String nd) {
		final String method = "estValideND";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		boolean l_estValide = true;
		try {
			// V�rifier le format du ND
			Integer.parseInt(nd);
			if (nd.length() != 8) {
				// trop ou pas assez de chiffre dans le ND
				l_estValide = false;
			}
		} catch (NumberFormatException l_numExc) {
			l_estValide = false;
		}

		if (!l_estValide) {
			// anomalie IC42C_SYNTAXE
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Mauvais format pour le ND : " + nd + " d'IC pour " + SystemeExterneConstantes.NUM_42C + " sur cette instance");
			throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_SYNTAXE, "Probleme format ND");
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_estValide;
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/06/2010</TD><TD>DBA</TD><TD>EV-000072: Maintien de la portabilit� dans le parc VIO lors de la ResilHD </TD></TR>
	 * </TABLE>
	 * 
	 * @param ic42c L'intention de commande 42C
	 * @return La valeur du champ conserverPorta de la forme ParametreType
	 */
	protected ParametreType getParamConserverPorta(IC_42C ic42c) {

		String cle = ConstantesDynamicLigneCommande.LIGNECOMMANDE_CONSERVER_PORTA;

		// Valeur par d�faut
		String conserverPorta = "NON";

		// Recherche dans la table traduction
		String typeCommande = ic42c.getTypeCommande();
		String motifResil = ic42c.getMotifResil();
		String valExtATraduire = typeCommande + motifResil;
		String valArtemis = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_42C, cle, valExtATraduire);
		if (StringUtils.isNotEmpty(valArtemis)) {

			// Si valeur traduite EXISTANTE (On prend cette valeur comme conserverPorta)
			conserverPorta = valArtemis;
		}

		ParametreType paramType = new ParametreType();
		paramType.setCle(cle);
		paramType.setValeur(conserverPorta);
		return paramType;
	}

	/**
	 * fromDateToDateHeure ajoute l'heure � une date.
	 * 
	 * @param date the date
	 * 
	 * @return String
	 */
	private String fromDateToDateHeure(String date) {
		return date + STRING_MIDNIGHT;
	}

	/**
	 * RG6 : getCategorieClientContractant r�cup�re la cat�gorie du client
	 * contractant.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getCategorieClientContractant(IC_42C ic42c) {
		final String method = "getCategorieClientContractant";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		if (mapRG6 == null) {
			mapRG6 = rg6(ic42c);
		}
		String categorie = mapRG6.get(IC42CConstantes.CLE_CATEGORIE);
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : categorie = " + categorie);
		return categorie;
	}

	/**
	 * RG5 : getCategorieClientLivre r�cup�re la cat�gorie du client livr�.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String cat�gorie du client livr�
	 */
	private String getCategorieClientLivre(IC_42C ic42c) {
		final String method = "getCategorieClientLivre";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		TraductionCatClientDTO traductionCatClientDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(TraductionCatClientDTO.class,
				new Comparaison(TraductionCatClient.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, ic42c.getSegmentMarche()), new Comparaison(TraductionCatalogue.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_42C));
		if (traductionCatClientDTO == null) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method,
					"Erreur de configuration de la base : impossible de trouver la traduction de la categorie du client : " + ic42c.getSegmentMarche() + " d'IC pour  " + SystemeExterneConstantes.NUM_42C + " sur cette instance");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Categorie Client livr�");
		}
		String l_categorie = traductionCatClientDTO.getLivreCategorieClient().getId();
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_categorie;
	}

	/**
	 * getClientContractant construit l'objet ClientContractant au format
	 * interne Artemis � partir de l'objet IC_42C.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ClientContractant
	 */
	private ClientContractant getClientContractant(IC_42C ic42c) {
		final String method = "getClientContractant";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		ClientContractant clientContractant = new ClientContractant();
		clientContractant.setIdClient(getIdentifiantClientContractant(ic42c));
		clientContractant.setCategorie(getCategorieClientContractant(ic42c));
		clientContractant.setNomOuRaisonSociale(getNomClientContractant(ic42c));
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return clientContractant;
	}

	/**
	 * getClientLivre construit un objet ClientLivre au format interne Artemis �
	 * partir de l'objet IC_42C.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ClientLivre
	 */
	private ClientLivre getClientLivre(IC_42C ic42c) {
		final String method = "getClientLivre";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		ClientLivre clientLivre = new ClientLivre();
		clientLivre.setNomOuRaisonSociale(ic42c.getAncienNom());
		clientLivre.setCategorie(getCategorieClientLivre(ic42c));
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return clientLivre;
	}

	/**
	 * getCommande construit l'objet Commande au format interne Artemis � partir
	 * de l'objet IC_42C.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * @param instanceLocalisation instance de localisation
	 * 
	 * @return Commande commande g�n�r�e au format Artemis
	 */
	private Commande getCommande(IC_42C ic42c, String instanceLocalisation) {
		final String method = "getCommande";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		mapRG0 = rg0(ic42c);
		mapRG2 = rg2(ic42c);
		Commande commande = new Commande();
		String idCommande = (String) mapRG2.get(IC42CConstantes.CLE_ID_COMMANDE);
		commande.setIdCommande(idCommande);
		commande.setDateDebutPriseCommandeFO(fromDateToDateHeure(ic42c.getDatePublication()));
		commande.setDateValidationCommandeFO(fromDateToDateHeure(ic42c.getDateEvt()));
		// rensigne la map mapRG6
		commande.setClientContractant(getClientContractant(ic42c));
		Iterator<String> l_keyIterator = mapRG0.keySet().iterator();
		// parcours de la HashMap
		while (l_keyIterator.hasNext()) {
			String l_offre = l_keyIterator.next();
			mapRG2.put(IC42CConstantes.CLE_OFFRE, l_offre);
			mapRG2.put(IC42CConstantes.CLE_PARAMETRES, mapRG0.get(l_offre));
			commande.addLigneCommande(getLigneCde(ic42c, instanceLocalisation));
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return commande;
	}

	/**
	 * RG9 : getDateContractuelle r�cup�re la date contractuelle.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getDateContractuelle(IC_42C ic42c) {
		final String method = "getDateContractuelle";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		if (dateLigneCde == null) {
			dateLigneCde = rg9(ic42c);
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : date contractuelle = " + dateLigneCde);
		return dateLigneCde;
	}

	/**
	 * RG9 : getDateSouhaitee r�cup�re la date souhait�e.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return la date souhait�e
	 */
	private String getDateSouhaitee(IC_42C ic42c) {
		final String method = "getDateSouhaitee";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		if (dateLigneCde == null) {
			dateLigneCde = rg9(ic42c);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : date souhaitee = " + dateLigneCde);
		return dateLigneCde;
	}

	/**
	 * getEltParcAffecte construit un objet ElementParcAffecte au format interne
	 * Artemis � partir de l'objet IC_42C.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ElementParcAffecte
	 */
	private ElementParcAffecte getEltParcAffecte(IC_42C ic42c) {
		final String method = "getEltParcAffecte";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ElementParcAffecte l_eltParc = new ElementParcAffecte();
		l_eltParc.setIdEPC(getIdEPC(ic42c));
		l_eltParc.setIdAccesClient(getIdAccesClient(ic42c));
		String refOffre = (String) mapRG2.get(IC42CConstantes.CLE_OFFRE);
		l_eltParc.setRefOffreExistante(refOffre);
		l_eltParc.setParametreElementParc(getParametreEltParc(ic42c));

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_eltParc;
	}

	/**
	 * RG7 : getIdAccesClientEP r�cup�re l'idAccesClient.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getIdAccesClient(IC_42C ic42c) {
		final String method = "getIdAccesClient";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		String l_idAccesClient = null;
		String l_ancienND = ic42c.getAncienNd();
		if (estValideND(l_ancienND)) {
			l_idAccesClient = prefixe.concat(l_ancienND);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_idAccesClient;
	}

	/**
	 * RG6 : getIdentifiantClientContractant r�cup�re l'identifiant du client
	 * contractant.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getIdentifiantClientContractant(IC_42C ic42c) {
		final String method = "getIdentifiantClientContractant";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		if (mapRG6 == null) {
			mapRG6 = rg6(ic42c);
		}
		String l_identifiant = mapRG6.get(IC42CConstantes.CLE_ID_CLIENT_CONTRACTANT);
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : categorie = " + l_identifiant);
		return l_identifiant;
	}

	/**
	 * RG7 : getIdEPC r�cup�re l'identifiant EPC de l'�l�ment parc aff�ct�.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getIdEPC(IC_42C ic42c) {
		final String method = "getIdEPC";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String l_idEPC = null;
		String l_ancienND = ic42c.getAncienNd();
		if (estValideND(l_ancienND)) {
			l_idEPC = prefixe.concat(l_ancienND);
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_idEPC;
	}

	/**
	 * getLigneCde construit l'objet LigneCommandeType au format interne Artemis
	 * � partir de l'objet IC_42C.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * @param instanceLocalisation instance de localisation
	 * 
	 * @return LigneCommandeType Ligne de commande g�n�r�e au format Artemis
	 */
	private LigneCommandeType getLigneCde(IC_42C ic42c, String instanceLocalisation) {
		final String method = "getLigneCde";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		LigneCommandeType l_ligneCde = new LigneCommandeType();
		String idLigneCde = (String) mapRG2.get(IC42CConstantes.CLE_ID_LIGNE_CDE);
		l_ligneCde.setIdLigneCommande(idLigneCde);
		l_ligneCde.setDateContractuelle(getDateContractuelle(ic42c));
		l_ligneCde.setDateSouhaitee(getDateSouhaitee(ic42c));
		l_ligneCde.setRefOperationPonctuelle(getRefOpPonctuelle(ic42c));
		l_ligneCde.setRefContexteLivraison(getRefContexteLiv(ic42c));
		l_ligneCde.setAccesLivraison(getIdAccesClient(ic42c));
		l_ligneCde.setTypeAccesLivraison(STRING_ND);
		l_ligneCde.setElementParcAffecte(getEltParcAffecte(ic42c));
		l_ligneCde.setParametreLivraison(getParamLivraison(ic42c, instanceLocalisation));
		l_ligneCde.setClientLivre(getClientLivre(ic42c));

		String typeCommande = ic42c.getTypeCommande();
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, "TypeCommande : " + typeCommande);
		if (IC42CConstantes.TYPE_CDE_DENUM.equals(typeCommande) || IC42CConstantes.TYPE_CDE_CNOM.equals(typeCommande)) {
			l_ligneCde.setProduitServiceSouhaite(getPSSouhaite(ic42c));
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_ligneCde;
	}

	/**
	 * RG6 : getNomClientContractant r�cup�re le nom du client contractant.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getNomClientContractant(IC_42C ic42c) {
		final String method = "getNomClientContractant";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		if (mapRG6 == null) {
			mapRG6 = rg6(ic42c);
		}
		String l_nom = mapRG6.get(IC42CConstantes.CLE_NOM);
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : nom = " + l_nom);
		return l_nom;
	}

	/**
	 * RG 11 : getParametreEltParc construit la liste de ParametreType pour
	 * l'�l�ment de parc.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ParametreType[]
	 */
	@SuppressWarnings("unchecked")
	private ParametreType[] getParametreEltParc(IC_42C ic42c) {
		final String method = "getParametreEltParc";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		List<ParametreType> l_params = new ArrayList<ParametreType>();

		// Param�tres ParamDet* : parcours de la collection de param�tres associ�s � l'offre
		Map<String, String> l_paramDetList = TraductionManager.getInstance().transformeListeParametres((List<ValeurParametreDTO>) mapRG2.get(IC42CConstantes.CLE_PARAMETRES));
		if (l_paramDetList != null) {
			Iterator<Entry<String, String>> l_paramDetIt = l_paramDetList.entrySet().iterator();
			while (l_paramDetIt.hasNext()) {
				Entry<String, String> entry = l_paramDetIt.next();
				String l_cleParamDet = entry.getKey();
				ParametreType l_paramDet = new ParametreType();
				l_paramDet.setCle(l_cleParamDet);
				l_paramDet.setValeur(entry.getValue());
				l_params.add(l_paramDet);
			}
		}

		// Param�tre OsirisIdOffreOrigine
		ParametreType l_paramOsirisIdOffreOrigine = getParamOsirisIdOffreOrigine(ic42c);
		if (l_paramOsirisIdOffreOrigine != null) {
			l_params.add(l_paramOsirisIdOffreOrigine);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_params.toArray(new ParametreType[1]);
	}

	/**
	 * RG4 : getParametrePS construit la liste de ParametreType pour le produit
	 * service souhait�.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return la liste de ParametreType pour le produit service souhait�
	 */
	@SuppressWarnings("unchecked")
	private ParametreType[] getParametrePS(IC_42C ic42c) {
		final String method = "getParametrePS";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		List<ParametreType> l_params = new ArrayList<ParametreType>();
		if (IC42CConstantes.TYPE_CDE_DENUM.equals(ic42c.getTypeCommande())) {
			// Param�tre NOUVEAU_ND
			ParametreType l_paramNouveauNd = null;
			String l_nouveauND = ic42c.getNouveauNd();
			if ((l_nouveauND.length() > 0) && estValideND(l_nouveauND)) {
				l_paramNouveauNd = new ParametreType();
				l_paramNouveauNd.setCle(IC42CConstantes.CLE_NOUVEAU_ND);
				l_paramNouveauNd.setValeur(prefixe.concat(l_nouveauND));
				l_params.add(l_paramNouveauNd);
			}
		} else if (IC42CConstantes.TYPE_CDE_CNOM.equals(ic42c.getTypeCommande())) {
			// Param�tre NOUVEAU_NOM
			ParametreType l_paramNouveauNom = null;
			String l_nouveauNom = ic42c.getNouveauNom();
			if ((l_nouveauNom != null) && (l_nouveauNom.length() > 0)) {
				l_paramNouveauNom = new ParametreType();
				l_paramNouveauNom.setCle(IC42CConstantes.CLE_NOUVEAU_NOM);
				l_paramNouveauNom.setValeur(l_nouveauNom);
				l_params.add(l_paramNouveauNom);
			}
		}

		// Param�tres ParamDet* : parcours de la collection de param�tres
		// associ�s � l'offre
		Map<String, String> l_paramDetList = TraductionManager.getInstance().transformeListeParametres((List<ValeurParametreDTO>) mapRG2.get(IC42CConstantes.CLE_PARAMETRES));
		if (l_paramDetList != null) {
			Iterator<Entry<String, String>> l_paramDetIt = l_paramDetList.entrySet().iterator();
			while (l_paramDetIt.hasNext()) {
				Entry<String, String> entry = l_paramDetIt.next();
				String l_cleParamDet = entry.getKey();
				ParametreType l_paramDet = new ParametreType();
				l_paramDet.setCle(l_cleParamDet);
				l_paramDet.setValeur(entry.getValue());
				l_params.add(l_paramDet);
			}
		}

		// Param�tre OsirisIdOffreOrigine
		ParametreType l_paramOsirisIdOffreOrigine = getParamOsirisIdOffreOrigine(ic42c);
		if (l_paramOsirisIdOffreOrigine != null) {
			l_params.add(l_paramOsirisIdOffreOrigine);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_params.toArray(new ParametreType[1]);
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/06/2010</TD><TD>DBA</TD><TD>EV-000072: Valorisation du conserverPorta</TD></TR>
	 * </TABLE>
	 * RG3 : getParamLivraison construit un tableau de ParametreType au format
	 * interne Artemis � partir de l'objet IC_42C.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * @param instanceLocalisation the instance localisation
	 * 
	 * @return ParametreType[]
	 */
	private ParametreType[] getParamLivraison(IC_42C ic42c, String instanceLocalisation) {
		final String method = "getParamLivraison";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		List<ParametreType> l_listeParams = new ArrayList<ParametreType>();

		// Param�tre PRESTATION
		ParametreType l_paramPrestation = getParamPrestation(ic42c);
		if (l_paramPrestation != null) {
			l_listeParams.add(l_paramPrestation);
		}

		// Param�tre RENVOI_REPARTITEUR
		ParametreType l_paramRenvoiRepart = getParamRenvoiRepart(ic42c);
		if (l_paramRenvoiRepart != null) {
			l_listeParams.add(l_paramRenvoiRepart);
		}

		// Param�tre MOTIF_RESIL
		ParametreType l_paramMotifResil = getParamMotifResil(ic42c);
		if (l_paramMotifResil != null) {
			l_listeParams.add(l_paramMotifResil);
		}

		// Param�tre CODE_EDSI
		ParametreType l_paramCodeEDSI = getParamCodeEDSI(ic42c);
		if (l_paramCodeEDSI != null) {
			l_listeParams.add(l_paramCodeEDSI);
		}

		// Param�tre CODE_USC
		ParametreType l_paramCodeUSC = getParamCodeUSC(ic42c);
		if (l_paramCodeUSC != null) {
			l_listeParams.add(l_paramCodeUSC);
		}

		// Param�tre REPARTITEUR
		ParametreType l_paramRepartiteur = getParamRepartiteur(ic42c, instanceLocalisation);
		if (l_paramRepartiteur != null) {
			l_listeParams.add(l_paramRepartiteur);
		}

		// Param�tre OsirisOpPonctuelleOrigine
		ParametreType l_paramOsirisOpPonctuelleOrigine = getParamOsirisOpPonctuelleOrigine(ic42c);
		if (l_paramOsirisOpPonctuelleOrigine != null) {
			l_listeParams.add(l_paramOsirisOpPonctuelleOrigine);
		}

		// EV-000072: Param�tre conserverPorta
		ParametreType paramConserverPorta = getParamConserverPorta(ic42c);
		if (paramConserverPorta != null) {
			l_listeParams.add(paramConserverPorta);
		}

		ParametreType[] l_params = l_listeParams.toArray(new ParametreType[1]);

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_params;
	}

	/**
	 * getPSSouhaite construit un objet ProduitServiceSouhaite au format interne
	 * Artemis � partir de l'objet IC_42C.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ProduitServiceSouhaite
	 */
	private ProduitServiceSouhaite getPSSouhaite(IC_42C ic42c) {
		final String method = "getPSSouhaite";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ProduitServiceSouhaite l_psSouhaite = new ProduitServiceSouhaite();
		l_psSouhaite.setIdAccesClient(getIdAccesClient(ic42c));
		String refOffre = (String) mapRG2.get(IC42CConstantes.CLE_OFFRE);
		l_psSouhaite.setRefOffreCible(refOffre);
		l_psSouhaite.setParametreProduitService(getParametrePS(ic42c));

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_psSouhaite;
	}

	/**
	 * RG8 : getRefContexteLiv r�cup�re la r�f�rence contexte livraison.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getRefContexteLiv(IC_42C ic42c) {
		final String method = "getRefContexteLiv";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String l_refContexte = TraductionManager.getInstance().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_42C, IC42CConstantes.CONTEXTE, ic42c.getTypeCommande());
		if (l_refContexte == null) {
			String refContexteTemp = TraductionManager.getInstance().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_42C, IC42CConstantes.CONTEXTE, ic42c.getMotifResil());
			if (refContexteTemp != null) {
				l_refContexte = refContexteTemp;
			}
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_refContexte;
	}

	/**
	 * RG1 : getRefOpPonctuelle r�cup�re la r�f�rence de l'op�ration ponctuelle
	 * de la ligne de commande.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getRefOpPonctuelle(IC_42C ic42c) {
		final String method = "getRefOpPonctuelle";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String l_refOpPonctuelle = TraductionManager.getInstance().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_42C, IC42CConstantes.CODE_ACTION, ic42c.getTypeCommande());
		if (l_refOpPonctuelle == null) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method,
					"Erreur de configuration de la base " + ": impossible de trouver la traduction du CODE_ACTION : " + ic42c.getTypeCommande() + " d'IC pour  " + SystemeExterneConstantes.NUM_42C + " sur cette instance");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction code operation ponctuelle");
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : refOpPonctuelle = " + l_refOpPonctuelle);
		return l_refOpPonctuelle;
	}

	/**
	 * getVersionInjecteur r�cup�re la version de l'injecteur.
	 * 
	 * @return String Version de l'injecteur
	 */
	private String getVersionInjecteur() {
		final String method = "getVersionInjecteur";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String l_version = InjectionCdeUtil.getVersionInjecteur(ServiceExterneConstantes.IC_42C);
		if (l_version == null) {
			// anomalie ERREUR_INTERNE
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de configuration de la base : impossible de trouver la version d'IC pour  " + ServiceExterneConstantes.IC_42C + " sur cette instance");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_INTERNE, "Anomalie interne");
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_version;
	}

	/**
	 * rg9 renseigne la date contractuelle et la date souhait�e de la ligne de
	 * commande.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String rg9(IC_42C ic42c) {
		final String method = "rg9";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		String l_stDate = null;

		try {
			ParametreArtemisDTO parametreArtemisDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ParametreArtemisDTO.class,
					new Comparaison(ParametreArtemis.FIELD_CLE_PARAMETRE, Constantes.OPERATOR_EQUAL, IC42CConstantes.DXF), new Comparaison(ParametreArtemis.FIELD_VERSION, Constantes.OPERATOR_EQUAL, Constantes.VERSION));
			Long dxf = new Long(parametreArtemisDTO.getValeurParametre());

			// R�cup�rer la date evenement
			String l_stDateEvt = fromDateToDateHeure(ic42c.getDateEvt());
			long l_dateEvt = DateUtils.parseDate(l_stDateEvt, IC42CConstantes.FORMAT_DATE_HEURE).getTime();
			// Valoriser la date contractuelle = date evenement + DXF jours
			long l_date = l_dateEvt + (dxf * HOUR_IN_MILLIS * 24);
			l_stDate = DateUtils.format(l_date, IC42CConstantes.FORMAT_DATE_HEURE);
		} catch (ParseException e) {
			// Doit pas arriver ici car validation d�ja fait !
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de format de date au niveau de l'IC 42C");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Erreur de format de date");
		} catch (NumberFormatException e) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de configuration de la base " + ": le parametre bolbec pour la cle " + "'DXF' doit etre un numero");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie Parametre Artemis DXF");
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : date = " + l_stDate);
		return l_stDate;
	}

	/**
	 * getCategorieRg6 valorise la cat�gorie du client contractant suivant la
	 * famille offre com.
	 * 
	 * @param ic42c the ic42c
	 * @param parc the parc
	 * 
	 * @return String
	 */
	private String getCategorieRg6(IC_42C ic42c, String parc) {
		final String method = "getCategorieRg6";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String categorie = null;
		if (ConstantesTraduction.TYPE_OFFRE_DE_GROS.equals(parc)) {
			// Cas d'une offre de gros, le client est un FAI ou un Op�rateur
			// R�cup�rer la cat�gorie de la table TraductionCatClient
			TraductionCatClientDTO traductionCatClientDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(TraductionCatClientDTO.class,
					new Comparaison(TraductionCatClient.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, IC42CConstantes.OP), new Comparaison(TraductionCatalogue.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_42C));
			if (traductionCatClientDTO == null) {
				// anomalie ERREUR_TRADUCTION
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de configuration de la base " + ": impossible de trouver la traduction de la categorie client OP");
				throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Categorie Client Contractant");
			}
			categorie = traductionCatClientDTO.getContractantCategorieClient().getId();
		} else if (ConstantesTraduction.TYPE_OFFRE_DETAIL.equals(parc)) {
			// Cas d'une offre d�tail, le client contractant est le client livr�
			categorie = getCategorieClientLivre(ic42c);
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : categorie = " + categorie);
		return categorie;
	}

	/**
	 * getFonctionTechnique.
	 * 
	 * @return String
	 */
	private String getFonctionTechnique() {
		final String method = "getFonctionTechnique";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String fctTechnique = null;
		// r�cup�ration de l'offre (on prend la 1�re)
		Iterator<String> keyIterator = mapRG0.keySet().iterator();
		if (keyIterator.hasNext()) {
			String offreId = keyIterator.next();
			OffreDTO offreDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, offreId);
			if (offreDTO != null) {
				// r�cup�ration du produit service
				ProduitServiceDTO produitServiceDTO = offreDTO.getProduitService();
				// r�cup�ration de la fonction technique
				if (produitServiceDTO != null) {
					fctTechnique = produitServiceDTO.getFonctionTechnique().getId();
				}
			}
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : fonction technique = " + fctTechnique);
		return fctTechnique;
	}

	/**
	 * getIsntanceSE d�termine l'instance de syst�me externe 42C.
	 * 
	 * @param critereLocalisation the critere localisation
	 * 
	 * @return String
	 */
	private String getInstanceSE(String critereLocalisation) {
		final String method = "getInstanceSE";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String l_idInstanceSE = null;
		InstanceSeDTO l_instanceSE = serviceManager.getLocalisationManager().getInstanceSEDTO(IC42CConstantes.CONSLIEN, critereLocalisation);
		if (l_instanceSE == null) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de configuration de la base : impossible de trouver l'instanceSE pour le systeme externe CONSLIEN et le critere de localisation : " + critereLocalisation);
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Repartiteur");
		}
		l_idInstanceSE = l_instanceSE.getId();
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_idInstanceSE;
	}

	/**
	 * getMotifResil r�cup�re le motif de r�siliation.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return String
	 */
	private String getMotifResil(IC_42C ic42c) {
		final String method = "getMotifResil";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String l_motifResil42C = ic42c.getMotifResil();
		String l_motifResil = null;
		if (StringUtils.isNotEmpty(l_motifResil42C)) {
			l_motifResil = TraductionManager.getInstance().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_42C, IC42CConstantes.MOTIF_RESIL, l_motifResil42C);
			if (l_motifResil == null) {
				// anomalie ERREUR_TRADUCTION
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method,
						"Erreur de configuration de la base : impossible de trouver la traduction du MOTIF_RESIL : " + l_motifResil42C + " d'IC pour  " + SystemeExterneConstantes.NUM_42C + " sur cette instance");
				throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Motif Resiliation");
			}
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_motifResil;
	}

	/**
	 * getNomEtIdRg6 valorise le nom et l'identifiant du client contractant
	 * suivant la famille offre com.
	 * 
	 * @param ic42c the ic42c
	 * @param parc the parc
	 */
	private void getNomEtIdRg6(IC_42C ic42c, String parc) {
		final String method = "getNomEtIdRg6";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String l_nom = null;
		String l_identifiant = null;

		if (ConstantesTraduction.TYPE_OFFRE_DE_GROS.equals(parc)) {
			// Cas d'une offre de gros, le client est un FAI ou un Op�rateur
			// D�termination de la fonction technique impact�e par la
			// publication
			String l_fonctionTechnique = getFonctionTechnique();
			if (l_fonctionTechnique == null) {
				// anomalie ERREUR_PARAM_LIV
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method,
						"Erreur de configuration de la base " + ": impossible de recuperer la fonction technique a partir du detentionPS : " + (String) mapRG2.get(IC42CConstantes.CLE_DETENTION));
				throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie parametrage de livraison entre fonction technique et detention PS");
			}

			// D�termination du type contractant
			String typeContractant = TraductionManager.getInstance().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TYPE_CONTRACTANT, l_fonctionTechnique);
			if (typeContractant == null) {
				// anomalie ERREUR_TRADUCTION
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de configuration de la base " + ": impossible de traduire le type contractant pour la fonction technique : " + l_fonctionTechnique);
				throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction TypeContractant");
			}

			TraductionCatalogueDTO traductionCatalogueDTO;
			// Construire la condition pour r�cup�rer le nom
			String l_codeClientContractant = null;
			if (IC42CConstantes.PROVIDER.equals(typeContractant)) {
				String l_codeProvider = ic42c.getCodeProvider();
				if ((l_codeProvider != null) && (l_codeProvider.length() > 0)) {
					l_codeClientContractant = l_codeProvider;
				} else {
					l_codeClientContractant = CLIENT_INCONNU;
				}
				traductionCatalogueDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(TraductionCatalogueDTO.class,
						new Comparaison(TraductionCatalogue.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, l_codeClientContractant),
						new Comparaison(TraductionCatalogue.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_42C), new Comparaison(TraductionCatalogue.FIELD_CLE, Constantes.OPERATOR_EQUAL, IC42CConstantes.PROVID));
			} else if (IC42CConstantes.OPERATEUR.equals(typeContractant)) {
				String l_operateur = ic42c.getOperateur();
				if ((l_operateur != null) && (l_operateur.length() > 0)) {
					l_codeClientContractant = l_operateur;
				} else {
					l_codeClientContractant = CLIENT_INCONNU;
				}
				traductionCatalogueDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(TraductionCatalogueDTO.class,
						new Comparaison(TraductionCatalogue.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, l_codeClientContractant),
						new Comparaison(TraductionCatalogue.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_42C), new Comparaison(TraductionCatalogue.FIELD_CLE, Constantes.OPERATOR_EQUAL, IC42CConstantes.COPCO));
			} else {
				traductionCatalogueDTO = null;
			}
			if (traductionCatalogueDTO == null) {
				// anomalie ERREUR_TRADUCTION
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de configuration de la base " + ": impossible de trouver la traduction du code provider/de l'operateur : " + ic42c.getCodeProvider() + "/"
						+ ic42c.getOperateur() + " d'IC pour  " + SystemeExterneConstantes.NUM_42C + " sur cette instance");
				throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Code Provider/Operateur");
			}

			l_nom = traductionCatalogueDTO.getValeurArtemis();
			l_identifiant = traductionCatalogueDTO.getValeurArtemis();
		} else if (ConstantesTraduction.TYPE_OFFRE_DETAIL.equals(parc)) {
			// Cas d'une offre d�tail, le client contractant est le client livr�
			l_nom = ic42c.getAncienNom();
		}

		if (l_nom == null) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Impossible de valoriser le nom du client contractant");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Nom Client Contractant");
		}

		// Compl�ter la HashMap correspondant � RG6
		mapRG6.put(IC42CConstantes.CLE_NOM, l_nom);
		mapRG6.put(IC42CConstantes.CLE_ID_CLIENT_CONTRACTANT, l_identifiant);

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : nom = " + l_nom + "; identifiant = " + l_identifiant);
	}

	/**
	 * getParamCodeEDSI.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ParametreType
	 */
	private ParametreType getParamCodeEDSI(IC_42C ic42c) {
		final String method = "getParamCodeEDSI";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramCodeEDSI = null;
		String l_codeEDSI = ic42c.getEdsInstallation();
		if ((l_codeEDSI != null) && (l_codeEDSI.length() > 0)) {
			l_paramCodeEDSI = new ParametreType();
			l_paramCodeEDSI.setCle(IC42CConstantes.CLE_CODE_EDSI);
			l_paramCodeEDSI.setValeur(l_codeEDSI);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramCodeEDSI;
	}

	/**
	 * getParamCodeUSC.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ParametreType
	 */
	private ParametreType getParamCodeUSC(IC_42C ic42c) {
		final String method = "getParamCodeUSC";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramCodeUSC = null;
		String l_codeEDSI = ic42c.getEdsInstallation();
		if ((l_codeEDSI != null) && (l_codeEDSI.length() > 3)) {
			l_paramCodeUSC = new ParametreType();
			l_paramCodeUSC.setCle(IC42CConstantes.CLE_CODE_USC);
			l_paramCodeUSC.setValeur(l_codeEDSI.substring(0, 3));
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramCodeUSC;
	}

	/**
	 * getParamMotifResil.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ParametreType
	 */
	private ParametreType getParamMotifResil(IC_42C ic42c) {
		final String method = "getParamMotifResil";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramMotifResil = null;
		String l_motifResil = getMotifResil(ic42c);
		if (l_motifResil != null) {
			l_paramMotifResil = new ParametreType();
			l_paramMotifResil.setCle(IC42CConstantes.CLE_MOTIF_RESIL);
			l_paramMotifResil.setValeur(l_motifResil);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramMotifResil;
	}

	/**
	 * getParamOsirisIdOffreOrigine.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ParametreType
	 */
	private ParametreType getParamOsirisIdOffreOrigine(IC_42C ic42c) {
		final String method = "getParamOsirisIdOffreOrigine";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramOsirisIdOffreOrigine = null;
		String l_idOffreOrigine = ic42c.getOffre();
		if (l_idOffreOrigine != null) {
			l_paramOsirisIdOffreOrigine = new ParametreType();
			l_paramOsirisIdOffreOrigine.setCle(IC42CConstantes.CLE_OSIRIS_IDOFFREORIG);
			l_paramOsirisIdOffreOrigine.setValeur(l_idOffreOrigine);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramOsirisIdOffreOrigine;
	}

	/**
	 * *************************************************************************
	 * D�claration des m�thodes d�crivant les r�gles de gestion *
	 * ************************************************************************.
	 * 
	 * @param ic42c the ic42c
	 * 
	 * @return the param osiris op ponctuelle origine
	 */

	/**
	 * getParamOsirisOpPonctuelleOrigine
	 * 
	 * @param ic42c
	 * Intention de Commande 42C
	 * @return ParametreType
	 */
	private ParametreType getParamOsirisOpPonctuelleOrigine(IC_42C ic42c) {
		final String method = "getParamOsirisOpPonctuelleOrigine";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramOsirisOpPonctuelleOrigine = null;
		String l_opPonctuelleOrigine = ic42c.getTypeCommande();
		if (l_opPonctuelleOrigine != null) {
			l_paramOsirisOpPonctuelleOrigine = new ParametreType();
			l_paramOsirisOpPonctuelleOrigine.setCle(IC42CConstantes.CLE_OSIRIS_OPPONCTORIG);
			l_paramOsirisOpPonctuelleOrigine.setValeur(l_opPonctuelleOrigine);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramOsirisOpPonctuelleOrigine;
	}

	/**
	 * getParamPrestation.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ParametreType
	 */
	private ParametreType getParamPrestation(IC_42C ic42c) {
		final String method = "getParamPrestation";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramPrestation = null;
		String l_prestation = ic42c.getPrestation();
		if ((l_prestation != null) && (l_prestation.length() > 0)) {
			l_paramPrestation = new ParametreType();
			l_paramPrestation.setCle(IC42CConstantes.CLE_PRESTATION);
			l_paramPrestation.setValeur(l_prestation);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramPrestation;
	}

	/**
	 * getParamRenvoiRepart.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return ParametreType
	 */
	private ParametreType getParamRenvoiRepart(IC_42C ic42c) {
		final String method = "getParamRenvoiRepart";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramRenvoiRepart = null;
		String l_renvoiRepart = ic42c.getRenvoiRepartiteur();
		if ((l_renvoiRepart != null) && (l_renvoiRepart.length() > 0)) {
			l_paramRenvoiRepart = new ParametreType();
			l_paramRenvoiRepart.setCle(IC42CConstantes.CLE_RENVOI_REPART);
			l_paramRenvoiRepart.setValeur(l_renvoiRepart);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramRenvoiRepart;
	}

	/**
	 * getParamRepartiteur.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * @param instanceLocalisation the instance localisation
	 * 
	 * @return ParametreType
	 */
	private ParametreType getParamRepartiteur(IC_42C ic42c, String instanceLocalisation) {
		final String method = "getParamRepartiteur";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		ParametreType l_paramRepartiteur = null;
		String l_repartiteur = getRepartiteur(ic42c, instanceLocalisation);
		if (l_repartiteur != null) {
			l_paramRepartiteur = new ParametreType();
			l_paramRepartiteur.setCle(IC42CConstantes.CLE_REPARTITEUR);
			l_paramRepartiteur.setValeur(l_repartiteur);
		}

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return l_paramRepartiteur;
	}

	/**
	 * getParc r�cup�re le Parc ("Gros" ou "D�tail").
	 * 
	 * @param typeDeVentes the type de ventes
	 * 
	 * @return String
	 */
	private String getParc(Set<String> typeDeVentes) {
		final String method = "getParc";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		String parc = null;
		if (typeDeVentes.contains(IC42CConstantes.TYPE_DE_VENTE_WHOLESALE)) {
			parc = ConstantesTraduction.TYPE_OFFRE_DE_GROS;
		} else {
			parc = ConstantesTraduction.TYPE_OFFRE_DETAIL;
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : Parc = " + parc);
		return parc;
	}

	/**
	 * getRepartiteur r�cup�re l'id du r�partiteur.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * @param instanceLocalisation the instance localisation
	 * 
	 * @return String
	 */
	private String getRepartiteur(IC_42C ic42c, String instanceLocalisation) {
		final String method = "getRepartiteur";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		String l_instanceSE = getInstanceSE(instanceLocalisation);

		RepartiteurDTO repartiteurDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RepartiteurDTO.class, new Comparaison(Repartiteur.SLINK_GEREE_PAR_INSTANCE_S_E, Constantes.OPERATOR_EQUAL, l_instanceSE),
				new Comparaison(Repartiteur.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, ic42c.getCentreRattachement()));
		if (repartiteurDTO == null) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method,
					"Erreur de configuration de la base " + ": impossible de trouver le repartiteur pour l'instanceSE : " + l_instanceSE + " et le centre de rattachement  " + ic42c.getCentreRattachement());
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Repartiteur");
		}

		String l_idRepartiteur = repartiteurDTO.getId();

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + ", repartiteur : " + l_idRepartiteur);
		return l_idRepartiteur;
	}

	/**
	 * getTypeDeVente r�cup�re le TypeDeVente d'une Offre.
	 * 
	 * @return HashMap
	 */
	private Set<String> getTypeDeVente() {
		final String method = "getTypeDeVente";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);
		Set<String> l_typeDeVenteMap = new HashSet<String>();
		Iterator<String> l_keyIterator = mapRG0.keySet().iterator();
		// parcours de la liste des offres
		while (l_keyIterator.hasNext()) {
			String l_offre = l_keyIterator.next();
			OffreDTO offreDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, l_offre);
			if (offreDTO != null) {
				String typeDeVente = offreDTO.getTypeDeVente();
				if (StringUtils.isEmpty(typeDeVente)) {
					// anomalie ERREUR_TRADUCTION
					ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Erreur de configuration de la base " + ": TypeDeVente non renseigne pour l'offre Artemis : " + l_offre);
					throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction nom et categorie client contractant");
				}
				l_typeDeVenteMap.add(typeDeVente);
			}
		}
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END + " : TypeDeVente = " + l_typeDeVenteMap.toString());
		return l_typeDeVenteMap;
	}

	/**
	 * rg0 renseigne les offres diff.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return les offres diff
	 */
	private Map<String, List<ValeurParametreDTO>> rg0(IC_42C ic42c) {
		final String method = "rg0";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		mapRG0 = TraductionManager.getInstance().getTraductionOffreConcatDiffCleNull(ic42c.getOffre(), SystemeExterneConstantes.NUM_42C);

		if ((mapRG0 == null) || mapRG0.isEmpty()) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method,
					"Erreur de configuration de la base " + ": impossible de trouver la traduction de l'offre : " + ic42c.getOffre() + " d'IC pour  " + SystemeExterneConstantes.NUM_42C + " sur cette instance");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction offre");
		}

		return mapRG0;

	}

	/**
	 * rg2 renseigne l_id de la commande, l'id de la ligne de commande.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return l_id de la commande, l'id de la ligne de commande
	 */
	private Map<String, Object> rg2(IC_42C ic42c) {
		final String method = "rg2";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		mapRG2 = new HashMap<String, Object>();

		// Calcul de l'id de la commande
		Long l_dateHeureArtemis = DateUtils.getDatabaseDate();
		String l_dateHeure = String.valueOf(l_dateHeureArtemis);
		String l_idCommande = l_dateHeure.concat(SEPARATEUR).concat(ic42c.getTypeCommande()).concat(SEPARATEUR).concat(ic42c.getAncienNd()).concat(SEPARATEUR).concat(ic42c.getOffre());

		// Calcul de l'id de la ligne de commande
		String l_idLigneCde = l_idCommande;

		// Compl�ter la HashMap correspondant � RG2
		mapRG2.put(IC42CConstantes.CLE_ID_COMMANDE, l_idCommande);
		mapRG2.put(IC42CConstantes.CLE_ID_LIGNE_CDE, l_idLigneCde);

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return mapRG2;
	}

	/**
	 * rg6 renseigne le nom et la cat�gorie du client contractant.
	 * 
	 * @param ic42c Intention de Commande 42C
	 * 
	 * @return HashMap
	 */
	private Map<String, String> rg6(IC_42C ic42c) {
		final String method = "rg6";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_BEGIN);

		mapRG6 = new HashMap<String, String>();

		// D�termination du type de vente
		Set<String> typeDeVentes = getTypeDeVente();

		// D�termination du parc ("Gros" ou "D�tail")
		String l_parc = getParc(typeDeVentes);

		// Valorisation du nom et de l'identifiant du client contractant
		getNomEtIdRg6(ic42c, l_parc);

		// Valorisation de la cat�gorie du client contractant
		String l_categorie = getCategorieRg6(ic42c, l_parc);
		if (l_categorie == null) {
			// anomalie ERREUR_TRADUCTION
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, method, "Impossible de valoriser la categorie du client contractant pour le type de vente " + typeDeVentes + "' et le parc '" + l_parc + "'!");
			throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_TRADUCTION, "Anomalie traduction Categorie Client Contractant");
		}

		// Compl�ter la HashMap correspondant � RG6
		mapRG6.put(IC42CConstantes.CLE_CATEGORIE, l_categorie);

		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, method, MSG_END);
		return mapRG6;
	}
}