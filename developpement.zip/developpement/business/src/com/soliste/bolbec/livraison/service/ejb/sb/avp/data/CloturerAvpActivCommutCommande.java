/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs Activ Commut
 * 
 * @author pqtv8886
 */
public class CloturerAvpActivCommutCommande extends CloturerAvpCommande {

	private String z0bpq;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param z0bpq
	 */
	public CloturerAvpActivCommutCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String z0bpq) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.z0bpq = z0bpq.toUpperCase();
	}

	public String getZ0bpq() {
		return this.z0bpq;
	}
}
