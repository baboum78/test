/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/06/2012</TD><TD>AGR</TD><TD>EV000184 : Achat FTTH, tache manuelle local tech</TD></TR>
 * </TABLE>
 */
public class TacheManuelleLocalTechDTO extends TacheManuelleDTO {

	private String identificationAcces;
	private String localisationPB;
	private String dossier;
	private String avertissement;

	/**
	 * @return TACHE_MANUELLE_LOCAL_TECH_TYPE
	 */
	public String getType() {
		return TACHE_MANUELLE_LOCAL_TECH_TYPE;
	}

	/**
	 * @return the identificationAcces
	 */
	public String getIdentificationAcces() {
		return identificationAcces;
	}

	/**
	 * @param identificationAcces the identificationAcces to set
	 */
	public void setIdentificationAcces(String identificationAcces) {
		this.identificationAcces = identificationAcces;
	}

	/**
	 * @return the localisationPB
	 */
	public String getLocalisationPB() {
		return localisationPB;
	}

	/**
	 * @param localisationPB the localisationPB to set
	 */
	public void setLocalisationPB(String localisationPB) {
		this.localisationPB = localisationPB;
	}

	/**
	 * @return the dossier
	 */
	public String getDossier() {
		return dossier;
	}

	/**
	 * @param dossier the dossier to set
	 */
	public void setDossier(String dossier) {
		this.dossier = dossier;
	}

	/**
	 * @return the avertissement
	 */
	public String getAvertissement() {
		return avertissement;
	}

	/**
	 * @param avertissement the avertissement to set
	 */
	public void setAvertissement(String avertissement) {
		this.avertissement = avertissement;
	}
}
