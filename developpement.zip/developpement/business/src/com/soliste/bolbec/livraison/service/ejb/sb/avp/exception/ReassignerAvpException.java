/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.exception;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Exception indiquant qu'un AVP n'a pu �tre r�assign�
 * 
 * @author rgvs7490
 */
public class ReassignerAvpException extends MessageException {

	private static final String MESSAGE_KEY = "ReassignerAvp.error.exception";

	/**
	 * 
	 */
	public ReassignerAvpException() {
		super(MESSAGE_KEY);
	}
}
