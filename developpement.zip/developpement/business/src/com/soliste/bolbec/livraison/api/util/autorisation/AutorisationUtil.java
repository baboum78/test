package com.soliste.bolbec.livraison.api.util.autorisation;

import java.util.Set;

import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.bolbec.commun.service.model.AgentDTO;

/**
 * M�thode utilitaire g�rant les agents pour l'API Rest
 * 
 * @author bperrard
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>29/10/2015</TD><TD>BPE</TD><TD>EV-000353 : Mise en place archi Rest de Base</TD></TR>
 * </TABLE>
 */
public interface AutorisationUtil {
	/**
	 * R�cup�re l'agent via l'object MessageContext
	 * 
	 * @param messageContext le context
	 * @return un agentDTO
	 */
	AgentDTO getCurrentAgentFromMessageContext(MessageContext messageContext);

	/**
	 * Regarde si l'agent est habilit� � effectuer cette action
	 * 
	 * 
	 * @param habilitationsSet l'ensemble des habilitations n�cessaires pour effectuer l'action
	 * @param agent l'agent
	 * @return true si l'agent est habilit�, sinon false
	 */
	boolean isHabilitated(Set<String> habilitationsSet, AgentDTO agent);
}
