package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

public enum NatureIntervention {
	INTERVENTION_CLIENT, INTERVENTION_GLOBALE
}
