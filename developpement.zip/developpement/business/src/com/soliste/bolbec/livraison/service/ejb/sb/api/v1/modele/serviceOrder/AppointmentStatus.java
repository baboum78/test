package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * Modele Ressource Enum AppointmentStatus
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/11/2015</TD><TD>MFA</TD><TD>Initialisation du AppointmentStatus</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "appointmentStatus")
public enum AppointmentStatus {

	reserved("RESERV"), cancelled("ANN"), aborted("KO"), toReserve("ARESERV"), planned("PLANIF"), closed("TERM"), unknown("unknown");

	private final String etatId;

	AppointmentStatus(String etatId) {
		this.etatId = etatId;
	}

	/**
	 * Permet de faire correspondre le status � l'id
	 * 
	 * @param id
	 * @return status
	 */
	public static AppointmentStatus getEtatById(String id) {
		for (AppointmentStatus status : AppointmentStatus.values()) {
			if (status.etatId.equals(id)) {
				return status;
			}
		}

		return AppointmentStatus.unknown;
	}

}
