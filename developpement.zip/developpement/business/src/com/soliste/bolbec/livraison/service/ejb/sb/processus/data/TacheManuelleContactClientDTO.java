/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * @author dxll7528
 */
public class TacheManuelleContactClientDTO extends TacheManuelleDTO {

	public String getType() {
		return TACHE_MANUELLE_CONTACT_CLIENT_TYPE;
	}
}
