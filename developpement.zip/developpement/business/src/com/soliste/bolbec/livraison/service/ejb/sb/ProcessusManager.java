package com.soliste.bolbec.livraison.service.ejb.sb;

import java.util.Collection;
import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.model.AttenduDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.PredossierDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusLcDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusSuspendusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;

/**
 * Interface metier de l'ejb <code>ProcessusManagerSB</code>.<br/>
 * Permet de rechercher des entit�es li�es � un processus<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * @author kyrw0678
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>21/07/2010</TD><TD>DBA</TD><TD>EV-000029: Nouveau finder findEvtByCommande</TD></TR>
 * <TR><TD>23/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>18/10/2010</TD><TD>DBA</TD><TD>IRMA_232 : optimisation finder</TD></TR>
 * <TR><TD>30/07/2012</TD><TD>BPE</TD><TD>EV-184 : ajout des m�thodes filtrerEvtByTypeEvenement et recupererEvtPlusRecente</TD></TR>
 * <TR><TD>29/04/2016</TD><TD>JDE</TD><TD>Ajout de la m�thode findTacheByLibelleCourtAndProcessus</TD></TR>
 * </TABLE>
 * 
 */
public interface ProcessusManager {

	/**
	 * R�cup�re un processus.
	 * 
	 * @param processusId the processus id
	 * 
	 * @return the processus
	 */
	ProcessusDTO getProcessus(String processusId);

	/**
	 * Mets � jour les champs <code>BPIID</code> et <code>BPName</code> d'un processus
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusBp(ProcessusDTO processusDTO);

	/**
	 * Mets � jour le champ <code>ModifManuelleEtat</code> d'un processus.
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusModifManuelleEtat(ProcessusDTO processusDTO);

	/**
	 * Cr�e un processus.
	 * Attention il faut que l'id <code>processusDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param processusDTO the processus dto
	 * 
	 * @return processusDTO
	 */
	ProcessusDTO createProcessus(ProcessusDTO processusDTO);

	/**
	 * R�cup�re la liste des Processus d'une commande
	 * 
	 * @param commandeId Identifiant de la commande
	 * 
	 * @return List de ProcessusDTO
	 */
	List<ProcessusDTO> findProcessusByCommande(String commandeId);

	/**
	 * R�cup�re la liste des processus d'une ligne de commande
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * 
	 * @return the list of ProcessusDTO
	 */
	List<ProcessusDTO> findProcessusByLigneCommande(String ligneCommandeId);

	/**
	 * R�cup�re le processus pere le plus recent d'une ligne de commande
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * 
	 * @return ProcessusDTO
	 */
	ProcessusDTO findProcessusByLigneCommandeAndPereAndPlusRecent(String ligneCommandeId);

	/**
	 * R�cup�re la liste des sous processus g�n�r�s par un processus donn�, n'�tant pas annul� par un processus et dont l'�tat est different etatId.
	 * 
	 * @param genereParProcessusId the genere par processus id
	 * @param etat the etat
	 * 
	 * @return the list< processus dt o>
	 */
	List<ProcessusDTO> findSousProcessusByGenereParProcessusAndNotAnnuleParProcessusAndNotEtat(String genereParProcessusId, String etat);

	/**
	 * R�cup�re la liste des processus dont l'�tat est etatId et appel�s par une t�che d'id tacheId
	 * 
	 * @param tacheId
	 * @return la liste des processus d'�tat etatId appel�s par une t�che d'id tacheId
	 */
	List<ProcessusDTO> findProcessusByEtatAndAppelerParTache(String etatId, String tacheId);

	/**
	 * Mets � jour les champs <code>EtatProcessus</code>
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusEtat(ProcessusDTO processusDTO);

	/**
	 * Mets � jour le champ <code>AnnuleParProcessus</code>
	 * 
	 * @param processusDTO the processus dto
	 */
	void updateProcessusAnnuleParProcessus(ProcessusDTO processusDTO);

	/**
	 * Mets � jour les champs <code>AppelleParTache</code>
	 *
	 * @param processusDTO the processus dto
	 */
	void updateProcessusAppeleParTache(ProcessusDTO processusDTO);

	/**
	 * Mets � jour le champs <code>PourCommande</code>
	 *
	 * @param idProcessus the id processus
	 * @param idComamnde the id commande
	 *
	 */
	void updateProcessusIdCommande(String idProcessus, String idComamnde);

	/**
	 * R�cup�re la liste des processus appel�s par une t�che d'id tacheId
	 * 
	 * @param tacheId
	 * @return la liste des processus appel�s par une t�che d'id tacheId
	 */
	List<ProcessusDTO> findProcessusAppelerParTache(String tacheId);


	/**
	 * R�cup�re le processus p�re d'une t�che d'id tacheId
	 *
	 * @param tacheId
	 * @return le processus p�re d'une t�che d'id tacheId
	 */
	ProcessusDTO findProcessusByTacheId(String tacheId);

	/**
	 * R�cup�re le processus p�re d'une t�che qui a d�clench� un evennement d'id evtId
	 *
	 * @param evtId
	 * @return le processus p�re d'une t�che qui a d�clench� un evennement d'id evtId
	 */
	ProcessusDTO findProcessusByEvtId(String evtId);

	/**
	 * R�cup�re la tache pour l'�venement evtId
	 *
	 * @param evtId
	 * @return La tache
	 */
	TacheDTO findTacheByEvt(String evtId);

	/**
	 * R�cup�re la tache pour l'�venement evtId
	 *
	 * @param evtId
	 * @param bIncludeReferences
	 * @return La tache
	 */
	TacheDTO findTacheByEvt(String evtId, boolean bIncludeReferences);

	/**
	 * R�cup�re une liste de tache pour un processus donn�
	 *
	 * @param processusId the processus id
	 *
	 * @return the list
	 */
	List<TacheDTO> findTacheByLanceParProcessus(String processusId);

	/**
	 * R�cup�re une liste de tache pour un processus donn� sorted
	 *
	 * @param processusId the processus id
	 *
	 * @return the list
	 */
	List<TacheDTO> findTacheByLanceParProcessusRangeParDate(String processusId);

	/**
	 * R�cup�re une liste de taches pour un processus et une identifiant externe de la t�che. Donn� sorted
	 *
	 * @param processusId the processus id
	 * @param tacheIdExterne the task external id
	 *
	 * @return the list
	 */
	List<TacheDTO> findTacheByLanceParProcessusAndIdExterneRangeParDate(String processusId, String tacheIdExterne);

	/**
	 * R�cup�re une liste de tache pour un libell� court et un processus donn�
	 * 
	 * @param libelleCourt the libelle court
	 * @param processusId the processus id
	 * 
	 * @return the list
	 */
	List<TacheDTO> findTacheByLibelleCourtAndProcessus(String libelleCourt, String processusId);

	/**
	 * R�cup�re la tache plus recente dont le libell� court est tacheLibelleCourt , lanc�es par le processus d'identifiant processusId
	 * et dont l'id est diff�rent de tacheId.
	 * 
	 * @param tacheId the tache id
	 * @param tacheLibelleCourt the tache libelle court
	 * @param processusId the processus id
	 * 
	 * @return la tache
	 */
	TacheDTO findTacheByDifferentIdAndLibelleCourtAndProcessusAndSortReverseDPMAD(String tacheId, String tacheLibelleCourt, String processusId);

	/**
	 * Cr�e une tache
	 * 
	 * @param tacheDTO the tache dto
	 * 
	 * @return the tache dto
	 */
	TacheDTO createTache(TacheDTO tacheDTO);

	/**
	 * R�cup�re une tache.
	 *
	 * @param tacheId the tache id
	 *
	 * @return the tache
	 */
	TacheDTO getTache(String tacheId);

	/**
	 * R�cup�re une tache.
	 *
	 * @param tacheId the tache id
	 * @param bIncludeReferences
	 *
	 * @return the tache
	 */
	TacheDTO getTache(String tacheId, boolean bIncludeReferences);

	/**
	 * Mets � jour une tache
	 * 
	 * @param tacheDTO the tache dto
	 */
	void updateTache(TacheDTO tacheDTO);

	/**
	 * Mets � jour les champs <code>lieeATache</code> d'une tache
	 * 
	 * @param tacheDTO the tache dto
	 */
	void updateTacheLieeATache(TacheDTO tacheDTO);

	/**
	 * Mets � jour le champ <code>cleVariante</code> et
	 * le le champ <code>valeurVariante</code> d'une tache
	 * 
	 * @param tacheDTO the tache dto
	 */
	void updateTacheVariante(TacheDTO tacheDTO);

	/**
	 * Mets � jour le champ <code>faitParRole</code> d'une tache
	 *
	 * @param tacheDTO the tache dto
	 */
	void updateTacheFaitParRole(TacheDTO tacheDTO);

	/**
	 * Cr�e un evenement
	 * 
	 * @param evtDTO the evt dto
	 * 
	 * @return the evt dto
	 */
	EvtDTO createEvt(EvtDTO evtDTO);

	/**
	 * R�cup�re un evenement � partir de son id evtId
	 * 
	 * @param evtId
	 * @return un evenement
	 */
	EvtDTO getEvt(String evtId);

	/**
	 * Mets � jour la date de cr�ation d'un evenement
	 * 
	 * @param evtDTO the evt dto
	 */
	void updateEvtDateCreation(EvtDTO evtDTO);

	/**
	 * R�cup�re la liste des evenements pour un processus
	 * 
	 * @param processusId the process id
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByProcessus(String processusId);

	/**
	 * R�cup�re la liste des evenements pour un processus
	 * 
	 * @param processusId the process id
	 * 
	 * @return the list of EvtDTO
	 */
	Map<String, EvtDTO> findMapEvtByProcessus(String processusId);

	/**
	 * R�cup�re la liste des evenements pour une tache
	 * 
	 * @param tacheId the tache id
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByTache(String tacheId);

	/**
	 * R�cup�re la liste des evenements generes par une tache
	 * 
	 * @param tacheId the tache id
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findGeneratedEvtByTache(String tacheId);

	/**
	 * R�cup�re la liste des evenements pour un processus et un typeAbd donn�es
	 * 
	 * @param processusId the process id
	 * @param typeAbd the type abd
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByProcAndTypeAbd(String processusId, String typeAbd);

	/**
	 * R�cup�re la liste des evenements d'une certaine cause pour un processus donn�es
	 * 
	 * @param processusId the process id
	 * @param cause The cause
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtByProcAndCause(String processusId, String cause);

	/**
	 * R�cup�re l'evenement le plus r�cent pour un processus et dont le type de la cause �v�nement vaut typeEvt
	 * 
	 * @param processusId the process id
	 * @param typeEvt the type evt
	 * 
	 * @return the list of EvtDTO
	 */
	EvtDTO findEvtByProcAndTypeEvtAndPlusRecent(String processusId, String typeEvt);

	/**
	 * R�cup�re les �v�nements li�s � la commande et dont le typeEvenement est celui pass� en param�tre.
	 * Pour information, il s'agit de la recherche d�crite dans la RG3 de IHM_LIV_ECRAN_Notes.doc.
	 * Cela consiste, � descendre depuis la commande, vers les lignes de commandes, puis les processus, puis
	 * les tache (de lancement), puis d'une part, vers les �v�nements, ou d'autre part, vers les
	 * (sous-)processus, puis vers les taches (du sous-processus), vers enfin les �v�nemnts.
	 * 
	 * @param commandeId
	 * @param typeEvenementValConst Valeur constante du TypeEvenement
	 * @return
	 */
	List<EvtDTO> findEvtByCommandeAndTypeEvenement(String commandeId, String typeEvenementValConst);

	/**
	 * Permet la r�cup�ration des EVT pour une commande
	 * 
	 * @param commandeId L'identifiant de la commande
	 * @return La liste des ev�nements pour la commande
	 */
	List<EvtDTO> findEvtByCommande(String commandeId);

	/**
	 * R�cup�re la liste des evenements associ�s aux t�ches lanc�es par le processus pour un type evt donn�.
	 * 
	 * On passe par un finder pour r�cup�rer la liste de ces �v�nements.
	 * La raison : suite aux optimisations faites au niveau du chargement des donn�es de processus, dans l'espace de donn�es du processus courant
	 * il se peut qu'il n'y ait que la t�che courante d'accessible, et non pas toutes les t�ches lanc�es par le processus.
	 * Pour obtenir l'ensemble des �v�nements associ�s aux t�ches lanc�es par le processus, on passe donc par un finder sur la table Evt.
	 * A partir de ces �v�n�ments, on r�cup�re leur TypeEvenement via la CauseEvenement.
	 * On ne conserve que les �v�nement de type typeEvt.
	 * 
	 * @param processusId the process id
	 * @param typeEvt the type evt
	 * 
	 * @return the list of EvtDTO
	 */
	List<EvtDTO> findEvtParTacheLanceeParProcessusAndTypeEvt(String processusId, String typeEvt);

	/**
	 * R�cup�re une tache en cours.
	 * 
	 * @param tacheEnCoursId the tache tache en cours id
	 * 
	 * @return the tache en cours
	 */
	TacheEnCoursDTO getTacheEnCours(String tacheEnCoursId);

	/**
	 * R�cup�re une liste de tache en cours pour un processus donn�
	 *
	 * @param processusId Le processus id
	 *
	 * @return La liste de <code>TacheEnCoursDTO</code>
	 */
	List<TacheEnCoursDTO> findTacheEnCoursByProcessus(String processusId);

	/**
	 * R�cup�re une liste de tache en cours pour un processus donn� avec un identifiant externe pr�cis.
	 *
	 * @param processusId Le processus id
	 * @param tacheIdExterne L'identifiant externe de la t�che.
	 *
	 * @return La liste de <code>TacheEnCoursDTO</code>
	 */
	List<TacheEnCoursDTO> findTacheEnCoursByProcessusAndIdExterne(String processusId, String tacheIdExterne);

	/**
	 * R�cup�re une liste de tache en cours pour une commande donn�e
	 * 
	 * @param commandeId Le commande id
	 * 
	 * @return La liste de <code>TacheEnCoursDTO</code>
	 */
	List<TacheEnCoursDTO> findTacheEnCoursByCommande(String commandeId);

	/**
	 * Cr�e une tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 * 
	 * @return the tache en cours dto
	 */
	TacheEnCoursDTO createTacheEnCours(TacheEnCoursDTO tacheEnCoursDTO);

	/**
	 * Mets � jour la tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 */
	void updateTacheEnCours(TacheEnCoursDTO tacheEnCoursDTO);

	/**
	 * Mets � jour le champ ZoneGeo de la tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 */
	void updateTacheEnCoursZoneGeo(TacheEnCoursDTO tacheEnCoursDTO);

	/**
	 * Mets � jour le champ Role de la tache en cours.
	 * 
	 * @param tacheEnCoursDTO the tache en cours dto
	 */
	void updateTacheEnCoursRole(TacheEnCoursDTO tacheEnCoursDTO);

	/**
	 * Supprime la tache en cours.
	 * 
	 * @param tacheEnCoursId the tache en cours id
	 */
	void deleteTacheEnCours(String tacheEnCoursId);

	/**
	 * Supprimer les occurrences de TacheEnCours telles que
	 * TacheEnCours.IdCommande = Id_Commande dont on veut interrompre le
	 * traitement automatique (pour Regul Manuel).
	 * 
	 * @param processusId
	 */
	void deleteTacheEnCoursByProcessus(String processusId);

	/**
	 * Supprimer les occurrences de TacheEnCours telles que
	 * TacheEnCours.IdCommande = Id_Commande, TacheEnCours.IdProcessus = Id_Processus
	 * et TacheEnCours.LibelleCourt = LibelleCourt dont on veut interrompre le
	 * traitement automatique (pour Regul Manuel).
	 * 
	 * @param commandeId
	 * @param processusId
	 * @param libelleCourt
	 */
	void deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt(String commandeId, String processusId, String libelleCourt);

	/**
	 * R�cup�re la liste des processus fils du processus pass� par son id
	 * 
	 * @param idProcessusPere
	 * @return La liste des <code>ProcessusDTO</code> fils
	 */
	List<ProcessusDTO> findProcessusFils(String idProcessusPere);

	/**
	 * Cr�ation d'un enregistrement ProcessusLc
	 * 
	 * @param processusLC
	 */
	ProcessusLcDTO createProcessusLC(ProcessusLcDTO processusLC);

	/**
	 * R�cup�re le processus d'un type donn�e et d'une ligne de commande donn�e par sa r�f�rence externe
	 * 
	 * @param refExterneLigneCommande
	 * @param typeProcessusId
	 * @return le <code>ProcessusDTO</code> correspondant (si trouv�, null sinon)
	 */
	ProcessusDTO findProcessusParRefExterneLigneCommandeEtType(String refExterneLigneCommande, String typeProcessusId);

	/**
	 * Retourne le processus p�re correspondant � la tache.
	 * 
	 * @param tacheId
	 * @return
	 */
	ProcessusDTO findProcessusByTacheAndPere(String tacheId);

	/**
	 * Retourne le processus en fonction de l'id de la commande, dont l'�tat n'est ni "ANNUL", ni "TERM" et qui n'est pas g�n�r� par un processus
	 * 
	 * @param commandeId
	 * @return Processus
	 */
	ProcessusDTO findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(String commandeId);

	/**
	 * Cr�ation d'un enregistrement ProcessusSuspendus
	 * 
	 * @param processusSuspendusDTO
	 * @return
	 */
	ProcessusSuspendusDTO createProcessusSuspendus(ProcessusSuspendusDTO processusSuspendusDTO);

	/**
	 * Supprime les instances de ProcessusSuspendus dont ProcessusSuspendus.IDPere = identifiant du processus fourni en entr�e
	 * 
	 * @param processusId
	 */
	void deleteProcessusSuspendusByIdPere(String processusId);


	/**
	 * R�cup�re les �v�nement g�n�r�s par une commande
	 * M�thode Directe : ne bloque pas les tables interm�diaires
	 *
	 * @param commandeId identifiant de la commande
	 *
	 * @return les �v�nements
	 */
	List<EvtDTO> findEvtDirectByCommande(String commandeId);


	/**
	 * R�cup�re l'evenement le plus r�cent � partir d'une liste d'evenements
	 * 
	 * @param evtsList la liste d'evenements
	 * @return l'evenement le plus r�cent
	 */
	EvtDTO recupererEvtPlusRecente(final Collection<EvtDTO> evtsList);

	/**
	 * Filtre les evements en fonction du typeEvenement
	 * 
	 * @param evtsList la liste d'evenements
	 * @param typeEvenement la valeur constante du typeEvenement
	 * @return la liste d'evenements de type typeEvenement
	 */
	Collection<EvtDTO> filtrerEvtByTypeEvenement(Collection<EvtDTO> evtsList, String typeEvenement);

	/**
	 * Cr�e une ligne dans la table Attendu
	 *
	 * @param attenduDTO la ligne � cr�er
	 *
	 * @return attenduDTO
	 */
	AttenduDTO createAttendu(AttenduDTO attenduDTO);

	/**
	 * Supprime une ligne dans la table Attendu
	 *
	 * @param idAttendu l'id de la ligne � supprimer
	 *
	 */
	void deleteAttendu(String idAttendu);

	/**
	 * Recherche une ligne dans la table Attendu
	 *
	 * @param idAttendu de la ligne � rechercher
	 *
	 * @return attenduDTO
	 */
	AttenduDTO rechercheAttendu(String idAttendu);

	/**
	 * Cr�e une ligne dans la table Predossier
	 *
	 * @param predossierDTO la ligne � cr�er
	 *
	 * @return PredossierDTO
	 */
	PredossierDTO createPredossier(PredossierDTO predossierDTO);

	/**
	 * Modifie une ligne dans la table Predossier
	 *
	 * @param predossierDTO la ligne � modifier
	 *
	 * @return PredossierDTO
	 */
	void updatePredossier(PredossierDTO predossierDTO);

	/**
	 * Recherche une ligne dans la table Predossier
	 *
	 * @param idPredossier de la ligne � rechercher
	 *
	 * @return PredossierDTO
	 */
	PredossierDTO recherchePredossier(String idPredossier);

}
