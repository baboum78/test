/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesParametreArtemis;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfTache;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;
import com.soliste.bolbec.livraison.service.model.CasMetierDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CausesAbandonDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EpCommercialDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.FamilleOffreComDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LienListeCausesDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.stepauto.traitements.data.LCOrigineMixte;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.OffreManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.TraductionManager;
import com.soliste.bolbec.livraison.service.util.VersionArtemisUtil;

import aps.AnomalieConstantes;
import aps.CasMetierConstantes;
import aps.CategorieEvenementConstantes;
import aps.CauseEvenement;
import aps.CauseEvenementConstantes;
import aps.CausesAbandon;
import aps.EtatInterventionConstantes;
import aps.JalonConstantes;
import aps.LienListeCauses;
import aps.MessagesConstantes;
import aps.ParametreArtemis;
import aps.StatutCommandeConstantes;
import aps.SystemeExterneConstantes;
import aps.Traduction;
import aps.TypeEvenement;
import aps.TypeEvenementConstantes;

/**
 * Classe avec les m�thodes utilitaires concernant les causes �v�nement.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>09/12/2009</TD><TD>DBA</TD><TD>EV-000039: Retour sur la condition li� retourNet</TD></TR>
 * <TR><TD>03/06/2010</TD><TD>PHC</TD><TD>IRMA_69 : - comparer les valeurs constantes des familles d'offre commerciale <BR>
 * et non les id qui sont versionn�s<BR>
 * - mise en place ServiceManager en static</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>22/02/2011</TD><TD>CCL</TD><TD>EV-000089: Avenant 7 - Modification de la gestion de l'abandon provisoire</TD></TR>
 * <TR><TD>24/05/2011</TD><TD>BPE</TD><TD>Suppression import inutile</TD></TR>
 * <TR><TD>11/07/2011</TD><TD>BPE</TD><TD>EV-000136: OPIM OPOM - D�placement de la m�thode filtrerCauseEvenementsStatutCommandeMixtePMCHDMigVoix + suppression du mot-cl� "return"</TD></TR>
 * <TR><TD>12/10/2011</TD><TD>GPA</TD><TD>DE-000200: Modification de la cause �v�nement g�n�r�e � la 1�re tentative d�affectation XDSL</TD></TR>
 * <TR><TD>21/05/2012</TD><TD>FTE</TD><TD>EV-000181 : Porta L36.6 - toute commande pour laquelle un marquage de la portabilit� a �t� effectu� ne peut plus �tre abandonn�e</TD></TR>
 * <TR><TD>26/04/2013</TD><TD>AZA</TD><TD>EV-000234 - Interdire l'abandon apr�s la mise � jour du SPN pour les commandes de Porta Fibre</TD></TR>
 * <TR><TD>21/05/2013</TD><TD>EBA</TD><TD>G8R2C2 - DE-000822 (331 FT) - Bouton Stop inutilisable lorsque les commandes ont d�clench� un marquage anticip� de la Porta</TD></TR>
 * </TABLE>
 *
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQ.4916</TD><TD>Func � EP0125 � Interdire l�abandon apr�s la mise � jour du SPN</TD></TR>
 * <TR><TD>REQ.8359</TD><TD>Func - EP0212 - Interdire l'abandon apr�s la mise � jour du SPN pour les commandes de Porta Fibre</TD></TR>
 *
 * </TABLE>
 *
 */
public class CauseEvenementUtil {

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = CauseEvenementUtil.class.getName();

	/** The Constant STRING_OUI_MAJ. */
	private static final String STRING_OUI_MAJ = "OUI";

	/** The Constant STRING_NON_MAJ. */
	private static final String STRING_NON_MAJ = "NON";

	/**
	 * Service manager pour acceder aux differents managers
	 */
	protected static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	/**
	 * Retourne la liste des causes d'�v�nement autoris�es pour l'abandon d'un AVP.
	 *
	 * @param papaProcessusId le PapaProcessus de l'AVP
	 * @param systemeExterneId l'identifiant du syst�me externe d�sirant abandonner
	 * (null si bolbec)
	 * @param abandon null ou ABD_COMPLET ou ABD_PARTIEL
	 * @param jalon le jalon (cf. param�tre optionnel de la TG)
	 *
	 * @return une liste de CauseEvenement
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourAbandon(String papaProcessusId, String systemeExterneId, String abandon, String jalon) {
		Set<String> ids = null;
		// TODO LBA DEFECT 150 G�rer l'abandon provisoire ?
		if ((abandon == null) || (abandon.length() == 0) || ConstantesTraduction.ABD_PROVISOIRE.equals(abandon)) {
			ids = getCauseEvenementAutoriseesIdPourAbandon(papaProcessusId, systemeExterneId, jalon);
		} else if (ConstantesTraduction.ABD_COMPLET.equals(abandon) || ConstantesTraduction.ABD_PARTIEL.equals(abandon)) {
			ids = getCauseEvenementAutoriseesIdPourAbandonMixte(abandon, papaProcessusId, systemeExterneId, jalon);
		}

		// Filtrage des causes abandon possibles
		ids = filtrageCausesPossibles(abandon, ids);

		List<CauseEvenementDTO> result = null;
		if (ids != null) {
			result = new ArrayList<CauseEvenementDTO>(ids.size());
			for (String id : ids) {
				CauseEvenementDTO causeEvenement = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, id);
				result.add(causeEvenement);
			}
		}
		return result;
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>22/02/2011</TD><TD>CCL</TD><TD>EV-000089: Avenant 7 - Modification de la gestion de l'abandon provisoire</TD></TR>
	 * </TABLE><BR>
	 *
	 * TRT_GEN_FiltrageDesCausesAbandon
	 * RG1 : Filtrage des Causes possibles
	 *
	 * Dans le cas d�un abandon provisoire d�une commande agr�g�e, il ne faut garder
	 * que la ou les causes abandon � Abandon provisoire �. A l�inverse, une commande
	 * non agr�g�e ou une commande agr�g�e en abandon complet ne doit pas poss�der en cause
	 * d�abandon la ou les causes Abandon � Abandon provisoire �
	 *
	 * @param abandon Type d'abandon
	 * @param ids Ensemble de cause evenements pour abandon
	 * @return L'ensemble <code>ids</code> filtr� et un ensemble vide le cas �ch�ant
	 *
	 *
	 */
	protected static Set<String> filtrageCausesPossibles(String abandon, Set<String> ids) {
		Set<String> result = new HashSet<String>();

		String valeurArtemis = SERVICE_MANAGER.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_CAUSE_ABD_PROVISOIRE, STRING_OUI_MAJ);

		if (StringUtils.isNotEmpty(valeurArtemis)) {
			for (String id : ids) {
				if (id != null) {
					CauseEvenementDTO causeEvenement = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, id);

					if (ConstantesTraduction.ABD_PROVISOIRE.equals(abandon)) {
						// On est dans le cas d�un abandon provisoire pour commande agr�g�e
						if (valeurArtemis.equals(causeEvenement.getValeurConstante())) {
							result.add(id);
						}
					} else {
						// On est dans le cas d�une commande non agr�g�e, soit dans le cas d�un
						// commande agr�g�e en abandon complet
						if (!valeurArtemis.equals(causeEvenement.getValeurConstante())) {
							result.add(id);
						}
					}
				}
			}
		} else {
			result = ids;
		}

		return result;
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour abandonner
	 * un AVP ou une t�che manuelle.
	 *
	 * @param tacheId l'identifiant de l'AVP
	 * @param abandon null ou ABD_COMPLET ou ABD_PARTIEL
	 * @param jalon null ou le jalon (cf. param�tre optionnel de la TG)
	 *
	 * @return une liste d'instances de CauseEvenementDTO
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourAbandonnerByAvp(String tacheId, String abandon, String jalon) {
		ProcessusDTO papaProcessus = SERVICE_MANAGER.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(papaProcessus.getId());

		List<LigneCommandeDTO> listeLC = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(commande.getId());
		LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(listeLC);
		SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
		CasMetierDTO cas = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CasMetierDTO.class, commande.getCasMetier().getId());
		if ((premiereLC != null) && (premiereLC.getJalon() != null)) {
			if (JalonConstantes.J_MES.equals(premiereLC.getJalon().getId()) && se != null && SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(se.getValeurConstante()) && CasMetierConstantes.VENTE_FTTH.equals(cas.getId())) {
				return getCauseEvenementAutoriseesPourAbandon(papaProcessus.getId(), SystemeExterneConstantes.GRAFIC, abandon, JalonConstantes.J_MES);
			}
		}

		return getCauseEvenementAutoriseesPourAbandon(papaProcessus.getId(), null, abandon, jalon);
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour abandonner
	 * un processus.
	 *
	 * @param processusId l'identifiant du processus
	 * @param abandon null ou ABD_COMPLET ou ABD_PARTIEL
	 * @param jalon null ou le jalon (cf. param�tre optionnel de la TG)
	 *
	 * @return une liste d'instances de CauseEvenementDTO
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourAbandonnerByProcessus(String processusId, String abandon, String jalon) {
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(processusId);

		List<LigneCommandeDTO> listeLC = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(commande.getId());
		LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(listeLC);
		SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
		CasMetierDTO cas = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CasMetierDTO.class, commande.getCasMetier().getId());
		if ((premiereLC != null) && (premiereLC.getJalon() != null)) {
			if (JalonConstantes.J_MES.equals(premiereLC.getJalon().getId()) && se != null && SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(se.getValeurConstante()) && CasMetierConstantes.VENTE_FTTH.equals(cas.getId())) {
				return getCauseEvenementAutoriseesPourAbandon(processusId, SystemeExterneConstantes.GRAFIC, abandon, JalonConstantes.J_MES);
			}
		}

		return getCauseEvenementAutoriseesPourAbandon(processusId, null, abandon, jalon);
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour cloturer un AVP.
	 *
	 * @param itemData l'AVP
	 *
	 * @return une liste d'instances de CauseEvenementDTO
	 * @throws DataException
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourCloturer(WfItemData itemData) throws DataException {
		List<CauseEvenementDTO> result = new ArrayList<CauseEvenementDTO>();
		WfTache wfTache = (WfTache) itemData;
		List<String> typeEvenementIds = wfTache.getStaticAttributes().get(WorkflowConstantes.EVENEMENTS_POSSIBLES);
		if (typeEvenementIds != null) {
			// Filtrage par version
			List<CauseEvenementDTO> causeEvenements = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(CauseEvenementDTO.class,
					new Comparaison(TypeEvenement.FIELD_VERSION, Constantes.OPERATOR_EQUAL, VersionArtemisUtil.getVersion(itemData)));
			// Filtrage par typeEvenement (en dehors du premier filtrage car il s'agit de v�rifier la pr�sence dans une liste !)
			for (CauseEvenementDTO causeEvenement : causeEvenements) {
				TypeEvenementDTO typeEvenement = causeEvenement.getTypeEvenement();
				if (typeEvenementIds.contains(typeEvenement.getValeurConstante())) {
					result.add(causeEvenement);
				}
			}
		}
		return result;
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour diff�rer un
	 * AVP ou une t�che manuelle.
	 *
	 * @param itemData l'AVP
	 *
	 * @return une liste d'instance de CauseEvenementDTO
	 * @throws DataException
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourDifferer(ItemData itemData) throws DataException {
		return getCauseEvenementAutoriseesPourCategorie(CategorieEvenementConstantes.DIFFERE, VersionArtemisUtil.getVersion(itemData));
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour reassigner un
	 * AVP ou une t�che manuelle.
	 *
	 * @param itemData
	 *
	 * @return une liste d'instance de CauseEvenementDTO
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourReassigner(ItemData itemData) throws DataException {
		return getCauseEvenementAutoriseesPourCategorie(CategorieEvenementConstantes.REASSIGN, VersionArtemisUtil.getVersion(itemData));
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour rerouter un
	 * AVP ou une t�che manuelle.
	 *
	 * @param itemData
	 *
	 * @return une liste d'instance de CauseEvenementDTO
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourRerouter(ItemData itemData) throws DataException {
		return getCauseEvenementAutoriseesPourCategorie(CategorieEvenementConstantes.REROUT, VersionArtemisUtil.getVersion(itemData));
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour retablir un
	 * AVP ou une t�che manuelle.
	 *
	 * @param processusId ID du processus
	 *
	 * @return une liste d'instance de CauseEvenementDTO
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourRetablir(String processusId) {
		ProcessusDTO processus = SERVICE_MANAGER.getProcessusManager().getProcessus(processusId);
		return getCauseEvenementAutoriseesPourCategorie(CategorieEvenementConstantes.RETABLI, VersionArtemisUtil.getVersion(processus));
	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour suspendre un
	 * AVP ou une t�che manuelle.
	 *
	 * @param processusId ID du processus
	 *
	 * @return une liste d'instance de CauseEvenementDTO
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourSuspendre(String processusId) {
		ProcessusDTO processus = SERVICE_MANAGER.getProcessusManager().getProcessus(processusId);
		return getCauseEvenementAutoriseesPourCategorie(CategorieEvenementConstantes.SUSPEND, VersionArtemisUtil.getVersion(processus));
	}

	/**
	 * Retourne la liste des CauseEvenement autoris�es pour la suspension du papaProcessus.
	 *
	 * @param papaProcessusId the papa processus id
	 *
	 * @return Set d'identifiants de CausesEvenement
	 */
	public static Set<String> getCauseEvenementAutoriseesIdPourSuspension(String papaProcessusId) {
		return getCauseEvenementAutoriseesIdPourAbandon(papaProcessusId, null, null);
	}

	/**
	 * Gets the cause evenement autorisees pour categorie.
	 *
	 * @param categorie the categorie
	 * @param version the version
	 *
	 * @return the cause evenement autorisees pour categorie
	 */
	private static List<CauseEvenementDTO> getCauseEvenementAutoriseesPourCategorie(String categorie, String version) {
		List<CauseEvenementDTO> result = new ArrayList<CauseEvenementDTO>();
		List<CauseEvenementDTO> causesEvenement = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(CauseEvenementDTO.class, new Comparaison(CauseEvenement.FIELD_VERSION, Constantes.OPERATOR_EQUAL, version));
		// Filtrage par typeEvenement (en dehors du premier filtrage car il s'agit de v�rifier la pr�sence dans une liste !)
		for (CauseEvenementDTO causeEvenement : causesEvenement) {
			TypeEvenementDTO typeEvenement = causeEvenement.getTypeEvenement();
			if (typeEvenement.getCategorieEvenement() != null && categorie.equals(typeEvenement.getCategorieEvenement().getId())) {
				result.add(causeEvenement);
			}
		}
		return result;
	}

	/**
	 * Ce traitement a pour but de permettre � une IHM de filtrer les
	 * CauseEvenement autoris�es lors d�un abandon, en fonction du niveau
	 * d�avancement du processus. <br/> En effet, pour chaque type d�op�rations
	 * ponctuelles et chaque famille d�offres, certaines causes ne sont
	 * autoris�es qu�� certains stades du processus (offres revendues
	 * notamment).
	 *
	 * @param papaProcessusId the papa processus id
	 * @param systemeExterneId the systeme externe id
	 * @param jalon the jalon
	 *
	 * @return Set
	 */
	public static Set<String> getCauseEvenementAutoriseesIdPourAbandon(String papaProcessusId, String systemeExterneId, String jalon) {
		Set<String> intersection = new HashSet<String>();
		Set<String> causesEvtAutorisees = new HashSet<String>();
		boolean emptyCauseEvenementMapPourLigneCommande = false;
		List<LigneCommandeDTO> lignesCde = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByEstLivreParProcessus(papaProcessusId);

		// Contr�le du marquage de la portabilit�
		if (!controleMarquagePortabilite(papaProcessusId, jalon)) {
			// abandon impossible
			return new HashSet<String>();
		}

		for (LigneCommandeDTO lc : lignesCde) {
			if (lc.getInduiteParLigneCommande() == null) {

				// R�cup�ration des causes �venement pour la ligne de commande
				Map<String, String> causeEvenementMapPourLigneCommande = getCauseEvenementMapPourLigneCommande(lc, systemeExterneId, jalon);

				// Si la collection est vide, il ne faudra conserver que les causeEvenement dont ForcerAffichage vaut OUI
				if (causeEvenementMapPourLigneCommande.isEmpty()) {
					emptyCauseEvenementMapPourLigneCommande = true;
				}

				// 1) S�lection de celles dont la valeur est � OUI
				causesEvtAutorisees.addAll(getKeysPourValue(causeEvenementMapPourLigneCommande, STRING_OUI_MAJ));
				// et celles dont la valeur est � NON
				causesEvtAutorisees.addAll(getKeysPourValue(causeEvenementMapPourLigneCommande, STRING_NON_MAJ));

				// 2) Pour permettre la s�lection de celles qui sont en commun avec TOUTES les lignes de commande,
				// � chaque LC, on ne garde que l'intersection entre l'intersection des LC pr�c�dentes et celle
				// que l'on traite � cette iteration.
				if (intersection.isEmpty()) {
					intersection.addAll(causeEvenementMapPourLigneCommande.keySet());
				} else {
					intersection.retainAll(causeEvenementMapPourLigneCommande.keySet());
				}
			}
		}

		// 2.bis) S�lection de celles qui sont en commun avec toutes les lignes de commande
		if (!emptyCauseEvenementMapPourLigneCommande) {
			causesEvtAutorisees.addAll(intersection);
		}

		return causesEvtAutorisees;
	}

	/**
	 * A partir d'une liste de causes �v�nement, cette m�thode permet de retourner toutes celles
	 * dont le param�tre ForcerAffichage est diff�rent de "NON".
	 *
	 * @param causesEvenement the causes evenement
	 *
	 * @return the list< cause evenement dt o>
	 */
	public static List<CauseEvenementDTO> filtrerCausesEvenementAffichables(List<CauseEvenementDTO> causesEvenement) {
		List<CauseEvenementDTO> causesEvenementAffichables = new ArrayList<CauseEvenementDTO>();
		for (CauseEvenementDTO causeEvenement : causesEvenement) {
			// On consid�re que l'objet a �t� charg� dans les traitements pr�c�dents, on r�cup�re donc directement la version
			String version = causeEvenement.getVersion();
			String causeEvenementId = causeEvenement.getId();
			List<LienListeCausesDTO> lienListeCauses = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(LienListeCausesDTO.class, new Comparaison(LienListeCauses.SLINK_CONTIENT_CAUSE_EVENEMENT, Constantes.OPERATOR_EQUAL, causeEvenementId),
					new Comparaison(LienListeCauses.FIELD_VERSION, Constantes.OPERATOR_EQUAL, version));
			for (LienListeCausesDTO lienListeCause : lienListeCauses) {
				String forcerAffichage = lienListeCause.getForcerAffichage();
				if (!StringUtils.equals(forcerAffichage, STRING_NON_MAJ)) {
					causesEvenementAffichables.add(causeEvenement);
					break;
				}
			}
		}
		return causesEvenementAffichables;
	}

	/**
	 * Ce traitement a pour but de permettre � une IHM de filtrer les
	 * CauseEvenement autoris�es lors d�un abandon mixte, en fonction du niveau
	 * d�avancement du processus. <br/> En effet, pour chaque type d�op�rations
	 * ponctuelles et chaque famille d�offres, certaines causes ne sont
	 * autoris�es qu�� certains stades du processus (offres revendues
	 * notamment).
	 *
	 * @param abandon the abandon
	 * @param papaProcessusId the papa processus id
	 * @param systemeExterneId the systeme externe id
	 * @param jalon the jalon
	 *
	 * @return Set
	 */
	public static Set<String> getCauseEvenementAutoriseesIdPourAbandonMixte(String abandon, String papaProcessusId, String systemeExterneId, String jalon) {
		Set<String> resultBD = null;
		Set<String> resultHD = null;
		List<LigneCommandeDTO> toutesLignesCde = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByEstLivreParProcessus(papaProcessusId);

		// Contr�le du marquage de la portabilit�
		if (!controleMarquagePortabilite(papaProcessusId, jalon)) {
			// abandon impossible
			return new HashSet<String>();
		}

		// EV-000039: R�cup�ration du casMetier de la commande
		String casMetier = recupererCasMetier(toutesLignesCde);

		// Chargement des donn�es : on filtre les lignes induites
		List<LigneCommandeDTO> ligneCdeMixteList = new ArrayList<LigneCommandeDTO>();
		for (LigneCommandeDTO lc : toutesLignesCde) {
			if (lc.getInduiteParLigneCommande() == null) {
				ligneCdeMixteList.add(lc);
			}
		}

		Collection<LCOrigineMixte> lcOrigineMixteList = null;
		lcOrigineMixteList = recupereLCOrigineMisteList(ligneCdeMixteList, lcOrigineMixteList);

		Set<String> causeEvenementIdsPourLigneCommandeBD = null;
		for (LigneCommandeDTO ligneCdeMixte : ligneCdeMixteList) {
			// recup�ration de la ligne de commande courante
			String idLigneCdeMixte = ligneCdeMixte.getId();
			if (ConstantesTraduction.ABD_COMPLET.equals(abandon)) {
				if (lcOrigineMixteList != null) {
					LCOrigineMixte lcOrigineMixteTrouve = null;
					for (LCOrigineMixte lcOrigineMixte : lcOrigineMixteList) {
						if (idLigneCdeMixte != null && idLigneCdeMixte.equals(lcOrigineMixte.getIdLCMixte()) && "BD".equals(lcOrigineMixte.getTypeDebit())) {
							lcOrigineMixteTrouve = lcOrigineMixte;
							break;
						}
					}
					if (lcOrigineMixteTrouve != null) {
						OffreDTO offreDTO = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, lcOrigineMixteTrouve.getOffre());

						if (offreDTO != null) {
							String familleOffreComId = offreDTO.getFamilleOffreCom().getId();
							causeEvenementIdsPourLigneCommandeBD = getCauseEvenementIdPourLigneCommandeMixte(ligneCdeMixte, familleOffreComId, ligneCdeMixte.getTypeOpPonctuelles().getId(), systemeExterneId, jalon);
						}
						if (resultBD == null) { // premi�re ligne de commande
							resultBD = causeEvenementIdsPourLigneCommandeBD;
						} else {
							resultBD.retainAll(causeEvenementIdsPourLigneCommandeBD);
						}
					}
				}
			}

			// EV-000039: Changement de la condition de valorisation (Cas retourNetVersRTC)
			if (!CasMetierConstantes.RETOUR_RTC_AVEC_OU_SANS_HD.equals(casMetier) && (ConstantesTraduction.ABD_PARTIEL.equals(abandon) || ConstantesTraduction.ABD_COMPLET.equals(abandon))) {
				if (lcOrigineMixteList != null) {
					LCOrigineMixte lcOrigineMixteTrouve = null;
					for (LCOrigineMixte lcOrigineMixte : lcOrigineMixteList) {
						if (idLigneCdeMixte != null && idLigneCdeMixte.equals(lcOrigineMixte.getIdLCMixte()) && "HD".equals(lcOrigineMixte.getTypeDebit())) {
							lcOrigineMixteTrouve = lcOrigineMixte;
							break;
						}
					}
					if (lcOrigineMixteTrouve != null) {
						OffreDTO offre = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, lcOrigineMixteTrouve.getOffre());
						Set<String> causeEvenementIdsPourLigneCommandeHD = null;
						if (offre != null) {
							String familleOffreComId = offre.getFamilleOffreCom().getId();
							causeEvenementIdsPourLigneCommandeHD = getCauseEvenementIdPourLigneCommandeMixte(ligneCdeMixte, familleOffreComId, ligneCdeMixte.getTypeOpPonctuelles().getId(), systemeExterneId, jalon);
						}
						if (resultHD == null) {
							// premi�re ligne de commande
							resultHD = causeEvenementIdsPourLigneCommandeHD;
						} else {
							resultHD.retainAll(causeEvenementIdsPourLigneCommandeHD);
						}
					}
				}
			}
		}

		// Union des causeEvenement des liste BD et HD
		Set<String> result = new HashSet<String>();
		if (resultBD != null) {
			result.addAll(resultBD);
		}
		if (resultHD != null) {
			result.addAll(resultHD);
		}

		return result;
	}

	private static Collection<LCOrigineMixte> recupereLCOrigineMisteList(List<LigneCommandeDTO> ligneCdeMixteList, Collection<LCOrigineMixte> lcOrigineMixteList) {
		if (!ligneCdeMixteList.isEmpty()) {
			LigneCommandeDTO ligneMixte = CollectionUtils.getFirstOrNull(ligneCdeMixteList);
			CommandeDTO commande = SERVICE_MANAGER.getCommandeManager().getCommande(ligneMixte.getIdCommande());
			String statutCommande = commande.getStatutCommande() != null ? commande.getStatutCommande().getId() : null;
			if (StatutCommandeConstantes.MIXTE.equals(statutCommande)) {
				// la commande est une commande mixte
				lcOrigineMixteList = identificationOrigineMixte(commande.getId());
			}
		}
		return lcOrigineMixteList;
	}

	/**
	 * Recuperation du cas metier de la commande
	 *
	 * @param toutesLignesCde
	 * @return cas metier de la commande
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>21/05/2012</TD><TD>FTE</TD><TD>Cr�ation</TD></TR>
	 * </TABLE>
	 */
	private static String recupererCasMetier(List<LigneCommandeDTO> toutesLignesCde) {
		LigneCommandeDTO firstLC = CollectionUtils.getFirstOrNull(toutesLignesCde);
		CommandeDTO cmd = SERVICE_MANAGER.getCommandeManager().findCommandeByLigneCommande(firstLC.getId());
		String casMetier = null;
		if (cmd != null && cmd.getCasMetier() != null) {
			casMetier = cmd.getCasMetier().getId();
		}
		return casMetier;
	}

	/**
	 * Gets the cause evenement map pour cause abandon.
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>21/02/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-210 : am�lioration du m�canisme de r�cup�ration des listeCauses</TD></TR>
	 * </TABLE>
	 *
	 * @param causesAbandonAutorisees the causes abandon autorisees
	 *
	 * @return the cause evenement map pour cause abandon
	 */
	private static Map<String, String> getCausesEvenementMapPourCausesAbandon(List<CausesAbandonDTO> causesAbandonAutorisees) {
		Map<String, String> listeCausesAutorisees = new HashMap<String, String>();

		for (CausesAbandonDTO causeAbandonAutorisee : causesAbandonAutorisees) {
			String causeListeCause = causeAbandonAutorisee.getListeCauses().getId();
			String causeAbandonVersion = causeAbandonAutorisee.getVersion();
			List<LienListeCausesDTO> lienlisteCauseList = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(LienListeCausesDTO.class, new Comparaison(LienListeCauses.FIELD_VERSION, Constantes.OPERATOR_EQUAL, causeAbandonVersion),
					new Comparaison(LienListeCauses.SLINK_EST_DANS_LISTE_CAUSES, Constantes.OPERATOR_EQUAL, causeListeCause));

			for (LienListeCausesDTO lienListeCause : lienlisteCauseList) {
				String idCauseEvt = lienListeCause.getCauseEvenement().getId();
				String forcerAffichage = lienListeCause.getForcerAffichage();

				listeCausesAutorisees.put(idCauseEvt, forcerAffichage);
				SERVICE_MANAGER.getLoggerManager().finer(CLASSNAME, "getCauseEvenementIdsPourCauseAbandon", "id cause evt autorise = " + idCauseEvt + " - champ ForcerAffichage = " + forcerAffichage);
			}
		}

		return listeCausesAutorisees;
	}

	/**
	 * Gets the cause evenement id pour cause abandon mixte.
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>21/02/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-210 : am�lioration du m�canisme de r�cup�ration des listeCauses</TD></TR>
	 * </TABLE>
	 *
	 * @param causesAbandonAutorisees the causes abandon autorisees
	 *
	 * @return the cause evenement id pour cause abandon mixte
	 */
	private static Set<String> getCausesEvenementIdPourCausesAbandonMixte(List<CausesAbandonDTO> causesAbandonAutorisees) {
		Set<String> result = new HashSet<String>();

		for (CausesAbandonDTO causeAbandonAutorisee : causesAbandonAutorisees) {
			String causeListeCause = causeAbandonAutorisee.getListeCauses().getId();
			String causeAbandonVersion = causeAbandonAutorisee.getVersion();
			List<LienListeCausesDTO> lienlisteCauseList = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(LienListeCausesDTO.class, new Comparaison(LienListeCauses.FIELD_VERSION, Constantes.OPERATOR_EQUAL, causeAbandonVersion),
					new Comparaison(LienListeCauses.SLINK_EST_DANS_LISTE_CAUSES, Constantes.OPERATOR_EQUAL, causeListeCause));

			// on ne r�cup�re que les id des causesEvt retenues
			for (LienListeCausesDTO lienListeCause : lienlisteCauseList) {
				result.add(lienListeCause.getCauseEvenement().getId());
			}
		}

		return result;
	}

	/**
	 * Gets the cause evenement map pour ligne commande.
	 *
	 * @param lc the lc
	 * @param systemeExterneId the systeme externe id
	 * @param jalon the jalon
	 *
	 * @return the cause evenement map pour ligne commande
	 */
	private static Map<String, String> getCauseEvenementMapPourLigneCommande(LigneCommandeDTO lc, String systemeExterneId, String jalon) {
		String[] familleOffreComEtTypeOpPonctuelleIds = getFamilleOffreComEtTypeOpPonctuelleIds(lc);
		String familleOffreComId = familleOffreComEtTypeOpPonctuelleIds[0];
		String typeOpPonctuelleId = familleOffreComEtTypeOpPonctuelleIds[1];
		List<CausesAbandonDTO> causesAbandonAutorisees = getCausesAbandonAutorisees(lc, familleOffreComId, typeOpPonctuelleId, systemeExterneId, jalon);
		if (causesAbandonAutorisees.isEmpty()) {
			return new HashMap<String, String>();
		}
		return getCausesEvenementMapPourCausesAbandon(causesAbandonAutorisees);
	}

	/**
	 * Gets the cause evenement id pour ligne commande mixte.
	 *
	 * @param ligneCdeMixte the ligne cde mixte
	 * @param familleOffreComId the famille offre com id
	 * @param typeOpPonctuelleId the type op ponctuelle id
	 * @param systemeExterneId the systeme externe id
	 * @param jalon the jalon
	 *
	 * @return the cause evenement id pour ligne commande mixte
	 */
	private static Set<String> getCauseEvenementIdPourLigneCommandeMixte(LigneCommandeDTO ligneCdeMixte, String familleOffreComId, String typeOpPonctuelleId, String systemeExterneId, String jalon) {
		List<CausesAbandonDTO> causesAbandonAutorisees = getCausesAbandonAutorisees(ligneCdeMixte, familleOffreComId, typeOpPonctuelleId, systemeExterneId, jalon);
		if (causesAbandonAutorisees.isEmpty()) {
			return new HashSet<String>();
		}
		return getCausesEvenementIdPourCausesAbandonMixte(causesAbandonAutorisees);
	}

	/**
	 * Gets the cause abandon autorisee.
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>03/06/2010</TD><TD>PHC</TD><TD>IRMA_69 : comparer les valeurs constantes des familles d'offre commerciale <BR>et non les id qui sont versionnes</TD></TR>
	 * <TR><TD>21/02/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-210 : am�lioration du m�canisme de r�cup�ration de la causeAbandon </TD></TR>
	 * </TABLE>
	 *
	 * @param lc the lc
	 * @param familleOffreComId the famille offre com id
	 * @param typeOpPonctuelleId the type op ponctuelle id
	 * @param systemeExterneId the systeme externe id
	 * @param jalon the jalon
	 *
	 * @return the cause abandon autorisee
	 */
	private static List<CausesAbandonDTO> getCausesAbandonAutorisees(LigneCommandeDTO lc, String familleOffreComId, String typeOpPonctuelleId, String systemeExterneId, String jalon) {
		String version = VersionArtemisUtil.getVersion(lc);
		String jalonId = jalon;
		if (jalonId == null && lc.getJalon() != null) {
			jalonId = lc.getJalon().getId();
		}
		// IRMA_69 comparer les valeurs constantes des familles d'offre commerciale et non les id qui sont versionnes.
		// car cela pose probleme pour les commandes mixte bi-version (version de la ligne de commande differente
		// de la version de la famille d'offre commerciale)
		// Lecture de la famille d'offre commerciale a partir de son id
		FamilleOffreComDTO familleOffreCom = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(FamilleOffreComDTO.class, familleOffreComId);
		String familleOffreComValeurConstante = familleOffreCom.getValeurConstante();

		Comparaison compSysExterne;
		if (systemeExterneId != null) {
			compSysExterne = new Comparaison(CausesAbandon.SLINK_RECU_DE_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, systemeExterneId);
		} else {
			compSysExterne = new Comparaison(CausesAbandon.SLINK_RECU_DE_SYSTEME_EXTERNE, Constantes.OPERATOR_IS_NULL, null);
		}
		Comparaison compVersion;
		if (version != null) {
			compVersion = new Comparaison(CausesAbandon.FIELD_VERSION, Constantes.OPERATOR_EQUAL, version);
		} else {
			compVersion = new Comparaison(CausesAbandon.FIELD_VERSION, Constantes.OPERATOR_IS_NULL, null);
		}

		// refectoring : on r�duit la liste sur laquelle on recherche nos valeurs
		List<CausesAbandonDTO> causeAbandonList = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(CausesAbandonDTO.class, compSysExterne, compVersion);

		List<CausesAbandonDTO> causesAbandonAutorisees = new ArrayList<CausesAbandonDTO>();
		for (CausesAbandonDTO causeAbandon : causeAbandonList) {
			String causeTypeOpPonctuelleId = causeAbandon.getTypeOpPonctuelles() != null ? causeAbandon.getTypeOpPonctuelles().getId() : null;
			// IRMA_69 recuperation de la valeur constante au lieu de l'id
			String causeFamilleOffreComValeurConstante = causeAbandon.getFamilleOffreCom() != null ? causeAbandon.getFamilleOffreCom().getValeurConstante() : null;
			String causeJalonId = causeAbandon.getJalon() != null ? causeAbandon.getJalon().getId() : null;

			if (((causeTypeOpPonctuelleId == null) || causeTypeOpPonctuelleId.equals(typeOpPonctuelleId)) && ((causeFamilleOffreComValeurConstante == null) || causeFamilleOffreComValeurConstante.equals(familleOffreComValeurConstante))
					&& ((causeJalonId == null) || causeJalonId.equals(jalonId))) {
				causesAbandonAutorisees.add(causeAbandon);
			}
		}

		return causesAbandonAutorisees;
	}

	/**
	 * TODO SOPRA PHC : Voir si c'est rempla�able par un appel � la methode getCollectionLCOrigineMixte de la classe IdentificationOrigineMixteTraitement
	 * qui fait la meme recherche mais rend en plus les lignes de suppresion induite (� filtrer en sortie ?)
	 *
	 * Identification origine mixte.
	 *
	 * @param commandeId the commande id
	 *
	 * @return the collection< lc origine mixte>
	 */
	private static Collection<LCOrigineMixte> identificationOrigineMixte(String commandeId) {

		// Rechercher les lignes de commande de la commande mixte telles que :
		// - LigneCommande.LigneCmdCatalogue.Commande.id = IdCommandeMixte
		// - ou LigneCommande. LigneCmd%Parc.Commande.id = IdCommandeMixte
		// - LigneCommande.LigneCmdCatalogue.Commande.id = IdCommandeReinj
		// - ou LigneCommande. LigneCmd%Parc.Commande.id = IdCommandeReinj
		List<LigneCommandeDTO> ligneCdeList = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(commandeId);

		// Rechercher des lignes de commande de l'espace d'objets telles que
		// l1_LigneCommande.<<dynamic>>IdCmdOrigineBD existe
		Collection<LigneCommandeDTO> ligneCdeMixteList = new ArrayList<LigneCommandeDTO>();
		for (LigneCommandeDTO ligneCde : ligneCdeList) {
			// Recherche si il existe l_LigneCommande.<<dynamic>>IdCmdOrigineBD
			Map<String, String> dynamicsLigneCde = ligneCde.getDynamicLigneCommandes();
			boolean estMixte = false;
			for (String cle : dynamicsLigneCde.keySet()) {
				if (ConstantesDynamicLigneCommande.LIGNECOMMANDE_IDCMDORIGINEBD.equals(cle)) {
					estMixte = true;
					break;
				}
			}
			if (estMixte) {
				ligneCdeMixteList.add(ligneCde);
			}
		}

		// Si aucune ligne n'est trouv�e
		// Il ne s'agit pas d'un commande mixte
		// On ne retourne pas d'objet au traitement appelant.
		// G�n�rer une anomalie CMD_NON_MIXTE
		if (ligneCdeMixteList.isEmpty()) {
			// RG_ANO1
			throw new AnomalieException(SERVICE_MANAGER.getAnomalieManager().newAno(AnomalieConstantes.CMD_NON_MIXTE, SERVICE_MANAGER.getAnomalieManager().getMessage(MessagesConstantes.PUB_00010, commandeId)));
		}

		// Rechercher idCmdOrigineBD tel que idCmdOrigineBD = l1_LigneCommande.<<dynamic>>IdCmdOrigineBD
		// Rechercher idCmdOrigineHD tel que idCmdOrigineHD = l1_LigneCommande.<<dynamic>>IdCmdOrigineHD
		String idCmdOrigineBD = null;
		String idCmdOrigineHD = null;
		Iterator<LigneCommandeDTO> lCOrigineMixteListIt = ligneCdeMixteList.iterator();
		while ((idCmdOrigineBD == null || idCmdOrigineHD == null) && lCOrigineMixteListIt.hasNext()) {
			LigneCommandeDTO ligneCmdMixte = lCOrigineMixteListIt.next();
			Map<String, String> dynamicsLigneCde = ligneCmdMixte.getDynamicLigneCommandes();
			for (Map.Entry<String, String> entry : dynamicsLigneCde.entrySet()) {
				if (ConstantesDynamicLigneCommande.LIGNECOMMANDE_IDCMDORIGINEBD.equals(entry.getKey())) {
					idCmdOrigineBD = entry.getValue();
				} else if (ConstantesDynamicLigneCommande.LIGNECOMMANDE_IDCMDORIGINEHD.equals(entry.getKey())) {
					idCmdOrigineHD = entry.getValue();
				}
			}
		}

		// Charger l'espace de travail relatif � chacune des commandes d'origine
		Collection<LCOrigineMixte> lCOrigineList = new ArrayList<LCOrigineMixte>();
		CommandeDTO commandeOrigineBD = SERVICE_MANAGER.getCommandeManager().getCommande(idCmdOrigineBD);
		if (commandeOrigineBD != null) {
			List<LigneCommandeDTO> lignesCde = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(idCmdOrigineBD);
			lCOrigineList.addAll(toCollectionLCOrigine(lignesCde, commandeOrigineBD.getRefExterne()));
		}
		CommandeDTO commandeOrigineHD = SERVICE_MANAGER.getCommandeManager().getCommande(idCmdOrigineHD);
		if (commandeOrigineHD != null) {
			List<LigneCommandeDTO> lignesCde = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByCommande(idCmdOrigineHD);
			lCOrigineList.addAll(toCollectionLCOrigine(lignesCde, commandeOrigineHD.getRefExterne()));
		}

		Collection<LCOrigineMixte> lCOrigineMixteList = new ArrayList<LCOrigineMixte>();
		for (LigneCommandeDTO ligneCmdMixte : ligneCdeMixteList) {
			lCOrigineMixteList.addAll(getCollectionLCOrigine(ligneCmdMixte, lCOrigineList, idCmdOrigineBD));
		}

		return lCOrigineMixteList;
	}

	/**
	 * Permet de r�cup�rer la liste des lignes de commande correspondantes � la
	 * commande mixte d'origine (comprend les lignes de commandes pour la
	 * commande HD et pour la commande BD) et ayant m�me offre ou nu que la ligne
	 * de commande pass�e en param�tre.
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>03/06/2010</TD><TD>PHC</TD><TD>IRMA_69 : comparer les valeurs constantes des offres <BR>
	 * et non les id qui sont versionnes</TD></TR>
	 * </TABLE>
	 *
	 * @param ligneCdeRef the ligne cde ref
	 * @param collectionLCOrigine the collection lc origine
	 * @param idCdeOrigineBD the id cde origine bd
	 *
	 * @return la liste des lignes de commande correspondante
	 */
	private static Collection<LCOrigineMixte> getCollectionLCOrigine(LigneCommandeDTO ligneCdeRef, Collection<LCOrigineMixte> collectionLCOrigine, String idCdeOrigineBD) {
		// Initialisation de la liste des lignes de cmd r�sultat
		Collection<LCOrigineMixte> lCOrigineCollection = new ArrayList<LCOrigineMixte>();
		// R�cup�ration de l'offre corresondant � la ligne de commande d'origine
		OffreDTO offre = getOffre(ligneCdeRef.getId());
		String valeurConstanteOffreLigneCmdRef = offre.getValeurConstante();
		// Traduction (TraductionCatCom) / syst�me externe "49W"
		// avec la cle "SUPPR_DOUBLON_MIXTE_NU" de l'offre
		String nuCdeRef = null;
		if (valeurConstanteOffreLigneCmdRef != null) {
			nuCdeRef = TraductionManager.getInstance().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.SUPPR_DOUBLON_MIXTE_NU, valeurConstanteOffreLigneCmdRef);
		}
		String idLCMixte = ligneCdeRef.getId();
		if (nuCdeRef != null) {
			for (LCOrigineMixte lCOrigine : collectionLCOrigine) {
				if (nuCdeRef.equals(lCOrigine.getNu())) {
					LCOrigineMixte lCOrigineMixte = new LCOrigineMixte(lCOrigine.getId(), lCOrigine.getIdCommande(), lCOrigine.getRefExterne(), lCOrigine.getRefExterneCommande(), lCOrigine.getOffre(), lCOrigine.getRecuParSystemeExterne(),
							lCOrigine.getNu(), idLCMixte, idCdeOrigineBD.equals(lCOrigine.getIdCommande()) ? "BD" : "HD", lCOrigine.getJalonPostReinj(), lCOrigine.getVersionModeleLPA());
					lCOrigineCollection.add(lCOrigineMixte);
				}
			}
		} else {
			for (LCOrigineMixte lCOrigine : collectionLCOrigine) {
				// IRMA_69 comparer les valeurs constantes des offres et non les id qui sont versionnes.
				// car cela pose probleme pour les commandes mixte bi-version (version de la ligne de commande diff�rente
				// de la version de la famille d'offre commerciale)
				// Lecture de l'offre commerciale a partir de son id
				OffreDTO offreLcOrigine = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, lCOrigine.getOffre());
				if (offreLcOrigine.getValeurConstante().equals(valeurConstanteOffreLigneCmdRef)) {
					LCOrigineMixte lCOrigineMixte = new LCOrigineMixte(lCOrigine.getId(), lCOrigine.getIdCommande(), lCOrigine.getRefExterne(), lCOrigine.getRefExterneCommande(), lCOrigine.getOffre(), lCOrigine.getRecuParSystemeExterne(),
							lCOrigine.getNu(), idLCMixte, idCdeOrigineBD.equals(lCOrigine.getIdCommande()) ? "BD" : "HD", lCOrigine.getJalonPostReinj(), lCOrigine.getVersionModeleLPA());
					lCOrigineCollection.add(lCOrigineMixte);
				}
			}
		}
		return lCOrigineCollection;
	}

	/**
	 * Transfomer une liste de lignes de commande en LCOrigine.
	 *
	 * @param collectionLC : la collection de lignes de commandes
	 * @param refExterneCmd : la ref externe de commande
	 *
	 * @return : la collection des LCOrigine
	 */
	private static Collection<LCOrigineMixte> toCollectionLCOrigine(Collection<LigneCommandeDTO> collectionLC, String refExterneCmd) {
		Collection<LCOrigineMixte> collectionLCOrigine = new ArrayList<LCOrigineMixte>();
		for (LigneCommandeDTO ligneCommande : collectionLC) {
			OffreDTO offre = getOffre(ligneCommande.getId());
			String idOffre = offre.getId();
			String offreConstante = offre.getValeurConstante();
			String nu = null;
			if (offreConstante != null) {
				nu = TraductionManager.getInstance().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.SUPPR_DOUBLON_MIXTE_NU, offreConstante);
			}
			collectionLCOrigine.add(new LCOrigineMixte(ligneCommande.getId(), ligneCommande.getIdCommande(), ligneCommande.getRefExterne(), refExterneCmd, idOffre, ligneCommande.getSystemeExterne().getId(), nu, null, null,
					ligneCommande.getJalon().getId(), getVersionModeleLPA(ligneCommande)));
		}
		return collectionLCOrigine;
	}

	/**
	 * R�cup�re le param�tre versionModeleLPA � partir de l'entit� de ligne de commande.
	 *
	 * @param ligneCde the ligne cde
	 *
	 * @return versionModeleLPA
	 */
	private static String getVersionModeleLPA(LigneCommandeDTO ligneCde) {
		Map<String, String> dynamicsLigneCde = ligneCde.getDynamicLigneCommandes();
		for (Map.Entry<String, String> entry : dynamicsLigneCde.entrySet()) {
			if (ConstantesDynamicLigneCommande.LIGNECOMMANDE_VERSIONMODELELPA.equals(entry.getKey())) {
				return entry.getValue();
			}
		}
		return null;
	}

	/**
	 * Retrouve l'offre � partir de la ligne de commande en param�tre.
	 *
	 * @param ligneCdeId the ligne cde id
	 *
	 * @return le code offre
	 */
	private static OffreDTO getOffre(String ligneCdeId) {
		// EV-000039: Rechercher de l'offre sur les PSS puis sur les EPC si non trouv� sur les PSS
		return OffreManager.getInstance().getOffreByPSSAfterEPC(ligneCdeId, true);
	}

	/**
	 * Gets the famille offre com et type op ponctuelle ids.
	 *
	 * @param lc the lc
	 *
	 * @return the famille offre com et type op ponctuelle ids
	 */
	private static String[] getFamilleOffreComEtTypeOpPonctuelleIds(LigneCommandeDTO lc) {
		Map<String, String> dynamicsLigneCde = lc.getDynamicLigneCommandes();
		String offreId = dynamicsLigneCde.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_TRANSCO_ANCIENNE_OFFRE);
		String typeOpPonctuelleId = dynamicsLigneCde.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_TRANSCO_ANCIENNE_OP);
		if (offreId == null) {
			PsSouhaiteDTO psSouhaite = SERVICE_MANAGER.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
			if (psSouhaite != null) {
				offreId = psSouhaite.getPorteSurOffre().getId();
			} else {
				EpCommercialDTO epc = SERVICE_MANAGER.getCommandeManager().findEpCommercialByLigneCommande(lc.getId());
				if (epc != null) {
					offreId = epc.getOffre().getId();
				}
			}
			typeOpPonctuelleId = lc.getTypeOpPonctuelles().getId();
		}
		String[] result = new String[2];
		if (offreId != null) {
			OffreDTO offre = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, offreId);
			result[0] = offre.getFamilleOffreCom().getId();
		} else {
			result[0] = null;
		}
		result[1] = typeOpPonctuelleId;
		return result;
	}

	/**
	 * Retourne les Key de <code>map</code> dont la Value est <code>searchValue</code>.
	 *
	 * @param map the map
	 * @param searchValue the search value
	 *
	 * @return the keys pour value
	 */
	private static Set<String> getKeysPourValue(Map<String, String> map, Object searchValue) {
		Set<String> keys = new HashSet<String>();
		for (Map.Entry<String, String> entry : map.entrySet()) {
			if (searchValue.equals(entry.getValue())) {
				keys.add(entry.getKey());
			}
		}
		return keys;
	}

	/**
	 * Supprime de la liste la cause evenement diff�rent du type CLOTUREAVP lorsque le statut de la commande est "Mixte_PMC_HDMigVoix" et que l'evenement de la tache en cours a une cause evenement �gal � AFFECINCOBRHD
	 *
	 * @param causeEvenements la liste des causes Evenement
	 * @param commande la commande
	 *
	 * @return true si un filtrage a �t� appliqu� sur la liste des causesEvenement, false sinon
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border' bgcolor=green>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>16/06/2011</TD><TD>BPE</TD><TD>EV-000136: OPIM OPOM - D�clencher un AVP en Affectation HD pour les migrations OPIM-OPOM</TD></TR>
	 * <TR><TD>05/07/2011</TD><TD>GPA</TD><TD>EV-000136: OPIM OPOM - Modification du test sur la CauseEvenement AFFECINCOBRHD pour ne conserver uniquement le REJEU</TD></TR>
	 * <TR><TD>11/07/2011</TD><TD>BPE</TD><TD>EV-000136: OPIM OPOM - D�placement de la m�thode + suppression du mot-cl� "return"</TD></TR>
	 * <TR><TD>12/10/2011</TD><TD>GPA</TD><TD>DE-000200: Modification de la cause �v�nement g�n�r�e � la 1�re tentative d�affectation XDSL</TD></TR>
	 * </TABLE><BR>
	 */
	public static boolean filtrerCauseEvenementsStatutCommandeMixtePMCHDMigVoix(List<CauseEvenementDTO> causeEvenements, CommandeDTO commande) {
		String methode = "filtrerCauseEvenementsStatutCommandeMixtePMCHDMigVoix";

		if (causeEvenements.isEmpty()) {
			return false;
		}

		// R�cup�ration de la commande en utilisant l'identifant du processus (Donn�e du formulaire)
		if (commande == null || !StatutCommandeConstantes.MIXTE_PMC_HDMIGVOIX.equals(commande.getStatutCommande().getId())) {
			return false;
		}

		boolean causeEvenementsFiltrees = false;
		CauseEvenementDTO causeEvenementTacheEnCoursLazy;
		CauseEvenementDTO causeEvenementTacheEnCours;
		EvtDTO evt;
		List<TacheEnCoursDTO> tachesEnCours = SERVICE_MANAGER.getProcessusManager().findTacheEnCoursByCommande(commande.getId());
		for (TacheEnCoursDTO tacheEnCours : tachesEnCours) {
			evt = SERVICE_MANAGER.getProcessusManager().getEvt(tacheEnCours.getIdEvt());
			if (evt == null) {
				continue;
			}
			causeEvenementTacheEnCoursLazy = evt.getCauseEvenement();
			if (causeEvenementTacheEnCoursLazy == null) {
				continue;
			}
			causeEvenementTacheEnCours = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, causeEvenementTacheEnCoursLazy.getId());
			if (!CauseEvenementConstantes.FORCAGE_INCOBRHD_VALEUR_CONSTANTE.equals(causeEvenementTacheEnCours.getValeurConstante())) {
				continue;
			}
			// Suppression de la CauseEvenement dont la valeur constante du TypeEvenement est CLOTUREREJ
			TypeEvenementDTO typeEvt;
			for (CauseEvenementDTO causeEvenement : new ArrayList<CauseEvenementDTO>(causeEvenements)) {
				typeEvt = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(TypeEvenementDTO.class, causeEvenement.getTypeEvenement().getId());
				if (!TypeEvenementConstantes.CLOTUREREJ_VALEUR_CONSTANTE.equals(typeEvt.getValeurConstante())) {
					SERVICE_MANAGER.getLoggerManager().qualif(CLASSNAME, 0, methode, commande.getId(), "Suppression de la CauseEvenement dont le typeEvenement est diff�rent de CLOTUREREJ");
					causeEvenements.remove(causeEvenement);
					causeEvenementsFiltrees = true;
				}
			}
		}
		return causeEvenementsFiltrees;
	}

	/**
	 * M�thode pour supprimer les causes �v�nements requalif si la commande n'est pas �ligible
	 */
	public static boolean filtrerCauseEvenementRequalifPlp(List<CauseEvenementDTO> causeEvenements, TacheDTO tache, CommandeDTO commande) {
		if (tache == null || tache.getEvt() == null) {
			return false;
		}

		supprCauseEvenement(causeEvenements, CauseEvenementConstantes.REQUALIF_PLP);

		String versionCourante = SERVICE_MANAGER.getVersionManager().getCurrentApplicationVersion();
		if (commande.getVersionApplicative().compareTo(versionCourante) < 0) {
			supprCauseEvenement(causeEvenements, CauseEvenementConstantes.CLOTURE_REQ_PLP);
		} else {
			supprCauseEvenement(causeEvenements, CauseEvenementConstantes.REJEU_REQ_PLP);
		}

		if (!contientCauseEvenement(causeEvenements, CauseEvenementConstantes.CLOTURE_REQ_PLP) && !contientCauseEvenement(causeEvenements, CauseEvenementConstantes.REJEU_REQ_PLP)) {
			return true;
		}

		if (!SERVICE_MANAGER.getTraitementManager().determinerCasEligibleRequalif(commande)) {
			supprCauseEvenement(causeEvenements, CauseEvenementConstantes.REJEU_REQ_PLP);
			supprCauseEvenement(causeEvenements, CauseEvenementConstantes.CLOTURE_REQ_PLP);
			return true;
		}

		List<String> causeEvenementsRequalif = Arrays.asList(CauseEvenementConstantes.IPON_PB_EXT_NON_LIBRE, CauseEvenementConstantes.IPON_PB_INT_NON_LIBRE, CauseEvenementConstantes.IPON_PBCONNEX_PTPB_PRI, CauseEvenementConstantes.REQUALIF_KO,
				CauseEvenementConstantes.REQUALIF_KO_R04, CauseEvenementConstantes.IPON_PBCREATE_RESS_INT);
		if (!causeEvenementsRequalif.contains(tache.getEvt().getCauseEvenement().getId())) {
			supprCauseEvenement(causeEvenements, CauseEvenementConstantes.REJEU_REQ_PLP);
			supprCauseEvenement(causeEvenements, CauseEvenementConstantes.CLOTURE_REQ_PLP);
			return true;
		}

		return false;
	}

	/**
	 * M�thode pour v�rifier la pr�sence de la cause �venement pass�e en param�tre dans la liste donn�e
	 */
	private static boolean contientCauseEvenement(List<CauseEvenementDTO> causeEvenements, String causeEvenementTest) {
		for (CauseEvenementDTO causeEvenement : new ArrayList<CauseEvenementDTO>(causeEvenements)) {
			if (causeEvenementTest.equals(causeEvenement.getId())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * M�thode de suppression de la cause �venement pass�e en param�tre dans la liste donn�e
	 */
	private static boolean supprCauseEvenement(List<CauseEvenementDTO> causeEvenements, String causeEvenementSuppr) {
		boolean causeEvenementsFiltrees = false;
		for (CauseEvenementDTO causeEvenement : new ArrayList<CauseEvenementDTO>(causeEvenements)) {
			if (causeEvenementSuppr.equals(causeEvenement.getId())) {
				causeEvenements.remove(causeEvenement);
				causeEvenementsFiltrees = true;
			}
		}
		return causeEvenementsFiltrees;
	}

	/**
	 * Contr�le d�un marquage de la portabilit� interdisant l�abandon de la commande
	 *
	 * @param papaProcessusId
	 * @return true s'il n'y a pas un marquage de la portabilit� sur la commande (abandon possible), false sinon (abandon impossible)
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>21/05/2012</TD><TD>FTE</TD><TD>Contr�le de la pr�sence du param�tre AbandonInterdit valoris� � OUI dans les param�tres de la commande</TD></TR>
	 * </TABLE>
	 */
	public static boolean controleMarquagePortabilite(String papaProcessusId, String jalon) {
		CommandeDTO commandeEnCours = SERVICE_MANAGER.getCommandeManager().findCommandeByProcessus(papaProcessusId);

		boolean estAbandonnable = true;
		if (commandeEnCours != null) {
			Map<String, String> commandeDyn = commandeEnCours.getDynamicCommandes();

			if (StringUtils.equals(commandeDyn.get(ConstantesDynamicCommande.CLE_ABANDON_INTERDIT), ConstantesDynamicCommande.VALEUR_OUI) && !StringUtils.equals(jalon, JalonConstantes.J_ABANMAN)) {
				// Marquage de la portabilit� valoris�, abandon interdit
				estAbandonnable = false;

			}
		}
		return estAbandonnable;
	}

	/**
	 * Gets the cause evenement abandon generique.
	 *
	 * @param version
	 * @return the cause evenement abandon generique
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>11/12/2017</TD><TD>CDS</TD><TD>EV-469</TD></TR>
	 * </TABLE>
	 */
	public static List<CauseEvenementDTO> getCauseEvenementAbandonGeneriqueParVersion(String version) {
		List<TraductionDTO> tradList = SERVICE_MANAGER.getReferenceSpaceManager().listInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.CLE_CAUSE_ABD_GENERIQUE),
				new Comparaison(Traduction.FIELD_VERSION, Constantes.OPERATOR_EQUAL, version));
		List<CauseEvenementDTO> causeEvenements = new ArrayList<CauseEvenementDTO>();

		for (TraductionDTO traductionDTO : tradList) {
			CauseEvenementDTO causeEvenement = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, new Comparaison(CauseEvenement.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, traductionDTO.getValeurArtemis()),
					new Comparaison(CauseEvenement.FIELD_VERSION, Constantes.OPERATOR_EQUAL, traductionDTO.getVersion()));
			causeEvenements.add(causeEvenement);
		}

		return causeEvenements;
	}

	/**
	 * Gets the cause evenement abandon generique ids.
	 *
	 * @param papaProcessus the papa processus
	 * @return the cause evenement abandon generique ids
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>11/12/2017</TD><TD>CDS</TD><TD>EV-469</TD></TR>
	 * </TABLE>
	 */
	public static Set<String> getCauseEvenementAbandonGeneriqueId(ProcessusDTO papaProcessus) {
		String version = VersionArtemisUtil.getVersion(papaProcessus);
		List<CauseEvenementDTO> causeEventGenList = getCauseEvenementAbandonGeneriqueParVersion(version);

		Set<String> causeEventGenIds = new HashSet<String>();
		for (CauseEvenementDTO causeEventGen : causeEventGenList) {
			causeEventGenIds.add(causeEventGen.getId());
		}

		return causeEventGenIds;
	}

}
