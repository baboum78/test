/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;

/**
 * LigneCommandeAAnnuler
 * 
 * @author La�titia FABRE
 */
public class LigneCommandeAAnnuler implements Serializable {

	private String idUnique;
	private String idExterne;
	private String systemeExterne;
	private String idCommandeExterne;

	/**
	 * Constructeur
	 * 
	 * @param idExterne
	 * @param systemeExterne
	 * @param idCommandeExterne
	 */
	public LigneCommandeAAnnuler(String idExterne, String systemeExterne, String idCommandeExterne) {
		super();
		this.idExterne = idExterne;
		this.systemeExterne = systemeExterne;
		this.idCommandeExterne = idCommandeExterne;
		// idUnique est utilis� pour identifier les LigneCommandeAAnnuler identiques,
		// notament pour l'utilisation de Set<LigneCommandeAAnnuler>.
		idUnique = idExterne + systemeExterne + idCommandeExterne;
	}

	/**
	 * Retourne le <code>idCommandeExterne</code>
	 * 
	 * @return le <code>idCommandeExterne</code>
	 */
	public String getIdCommandeExterne() {
		return idCommandeExterne;
	}

	/**
	 * Retourne le <code>idExterne</code>
	 * 
	 * @return le <code>idExterne</code>
	 */
	public String getIdExterne() {
		return idExterne;
	}

	/**
	 * Retourne le <code>systemeExterne</code>
	 * 
	 * @return le <code>systemeExterne</code>
	 */
	public String getSystemeExterne() {
		return systemeExterne;
	}

	@Override
	public boolean equals(Object obj) {
		return obj != null && obj instanceof LigneCommandeAAnnuler && (((LigneCommandeAAnnuler) obj).idUnique.equals(idUnique));
	}

	@Override
	public int hashCode() {
		return idUnique.hashCode();
	}
}
