/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception;

/**
 * Exception pour l'acc�s aux donn�es m�tier
 * 
 * @author gdzd8490
 * 
 */
public class DataException extends Exception {

	/**
	 * Constructeur
	 * 
	 * @param arg0
	 */
	public DataException(Throwable arg0) {
		super(arg0);
	}

}
