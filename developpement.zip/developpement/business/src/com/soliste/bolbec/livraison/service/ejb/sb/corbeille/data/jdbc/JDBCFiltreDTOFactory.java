/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;

import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.CatClientUniteDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.commun.service.model.ZoneGeoUniteDTO;
import com.soliste.bolbec.commun.service.model.ZoneSiUniteDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleTranslator;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCCondition;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCFilter;
import com.soliste.bolbec.livraison.service.util.jdbc.TacheEnCoursJDBCFields;

import aps.CatClientUnite;
import aps.RoleClientConstantes;
import aps.ZoneGeoUnite;
import aps.ZoneSIUnite;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>14/01/2014</TD><TD>FTE</TD><TD>EV-000268 : Crit�re de Filtre Multizones</TD></TR>
 * </TABLE>
 * 
 * Factory pour les FiltreDTO contenant des filtres JDBC
 * 
 * @author gdzd8490
 * 
 */
public class JDBCFiltreDTOFactory implements FiltreDTOFactory {

	private static FiltreDTOFactory instance = null;

	private static CorbeilleTranslator translator = null;

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static FiltreDTOFactory getInstance() {
		if (instance == null) {
			instance = new JDBCFiltreDTOFactory();
			translator = JDBCCorbeilleTranslator.getInstance();
		}
		return instance;
	}

	private JDBCFiltreDTOFactory() {
		// pour �viter instanciation inutile
	}

	/**
	 * Utilisation de la facade JDBCFiltreDTO pour la liste des filtres JDBC
	 * 
	 * @param jdbcConditions
	 * liste de JDBCConditions
	 * @return un JDBCFiltreDTO
	 */
	private FiltreDTO buildFiltreDTO(List<JDBCCondition> jdbcConditions) {
		// C'est pour avoir une nouvelle instance de liste avec les m�mes �l�ments
		return new JDBCFiltreDTO(new ArrayList<JDBCCondition>(jdbcConditions));
	}

	/**
	 * Cr�e un filtre JDBCFilter pour r�cup�rer les commandes critiques. Elles
	 * sont critiques si leur date contractuelle est inf�rieure � la date du
	 * jour + 2 jours.
	 * 
	 * @return un JDBCFilter
	 */
	private JDBCFilter createCommandesCritiquesFilter() {
		Date now = new Date();
		Date dateCritique = DateUtils.createOffsetDay(now, 2);
		String limite = DateUtils.getDatabaseDate(dateCritique).toString();
		JDBCField dateContractuelleField = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.DATE_CONTRACTUELLE);
		return new JDBCFilter(dateContractuelleField, JDBCFilter.OPERATOR_LOWER_THAN, limite);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createDateCompareFiltreDataFilter(java.lang.String, java.util.Date, boolean)
	 */
	public FiltreDTO createDateCompareFiltreDataFilter(String infoId, Date date, boolean greaterThan) {
		List<JDBCCondition> conditions = new ArrayList<JDBCCondition>();
		JDBCField field = (JDBCField) translator.translate(infoId);
		String dateCompare = DateUtils.getDatabaseDate().toString();
		if (greaterThan) {
			List<JDBCFilter> dateFilters = new ArrayList<JDBCFilter>();
			// date > valeur
			dateFilters.add(new JDBCFilter(field, JDBCFilter.OPERATOR_GREATER_THAN, dateCompare));
			// OR date is null
			dateFilters.add(new JDBCFilter(field, JDBCFilter.OPERATOR_IS_NULL));
			conditions.add(new JDBCCondition(JDBCCondition.OPERATOR_OR, dateFilters));
		} else {
			List<JDBCFilter> dateFilters = new ArrayList<JDBCFilter>();
			// date < valeur
			dateFilters.add(new JDBCFilter(field, JDBCFilter.OPERATOR_LOWER_THAN, dateCompare));
			// OR date is null
			dateFilters.add(new JDBCFilter(field, JDBCFilter.OPERATOR_IS_NULL));
			conditions.add(new JDBCCondition(JDBCCondition.OPERATOR_OR, dateFilters));
		}
		return buildFiltreDTO(conditions);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createDateIntervalFiltreDataFilter(java.lang.String, java.util.Date, java.util.Date)
	 */
	public FiltreDTO createDateIntervalFiltreDataFilter(String infoId, Date beginDate, Date endDate) {

		// Le filtre final
		ArrayList<JDBCCondition> conditions = new ArrayList<JDBCCondition>();

		JDBCField field = (JDBCField) translator.translate(infoId);
		String dateDebut = converte2String(DateUtils.getDatabaseDate(beginDate));
		String dateFin = converte2String(DateUtils.getDatabaseDate(endDate));

		if (beginDate != null) {
			if (endDate != null) {
				// --------------------------------
				// Intervalle begin < ___ < end
				// --------------------------------
				//

				// (begin < ____)
				List<JDBCFilter> dateFiltersBegin = new ArrayList<JDBCFilter>();
				dateFiltersBegin.add(new JDBCFilter(field, JDBCFilter.OPERATOR_GREATER_THAN, dateDebut));

				// (____ > end)
				List<JDBCFilter> dateFiltersEnd = new ArrayList<JDBCFilter>();
				dateFiltersEnd.add(new JDBCFilter(field, JDBCFilter.OPERATOR_LOWER_THAN, dateFin));

				// (begin < ____) & (____ > end)
				conditions.add(new JDBCCondition(JDBCCondition.OPERATOR_AND, dateFiltersBegin));
				conditions.add(new JDBCCondition(JDBCCondition.OPERATOR_AND, dateFiltersEnd));
			} else {
				// --------------------------------
				// Intervalle begin < ___
				// --------------------------------

				// (begin < ____)
				List<JDBCFilter> dateFiltersBegin = new ArrayList<JDBCFilter>();
				dateFiltersBegin.add(new JDBCFilter(field, JDBCFilter.OPERATOR_GREATER_THAN, dateDebut));
				conditions.add(new JDBCCondition(JDBCCondition.OPERATOR_AND, dateFiltersBegin));
			}
		} else {
			if (endDate != null) {
				// --------------------------------
				// Intervalle ___ < end
				// --------------------------------

				// (____ > end)
				List<JDBCFilter> dateFiltersEnd = new ArrayList<JDBCFilter>();
				dateFiltersEnd.add(new JDBCFilter(field, JDBCFilter.OPERATOR_LOWER_THAN, dateFin));
				conditions.add(new JDBCCondition(JDBCCondition.OPERATOR_AND, dateFiltersEnd));
			}
		}

		return buildFiltreDTO(conditions);
	}

	private String converte2String(Long longValue) {
		if (longValue != null) {
			return longValue.toString();
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createDateFiltreDataFilter(java.lang.String, java.lang.String, java.util.Date)
	 */
	public FiltreDTO createDateFiltreDataFilter(String infoId, String comparatorType, Date date) {
		List<JDBCCondition> conditions = new ArrayList<JDBCCondition>();
		List<JDBCFilter> filters = new ArrayList<JDBCFilter>();
		JDBCField field = (JDBCField) translator.translate(infoId);
		String strDate = DateUtils.getDatabaseDate(date).toString();
		filters.add(new JDBCFilter(field, translateComparator(comparatorType), strDate));
		conditions.add(new JDBCCondition(filters));
		return buildFiltreDTO(conditions);
	}

	/**
	 * Cr�e le filtre (un JDBCFilter) pour les cat�gories des clients livr�s
	 * associ�s � l'unit� d'activit� d'un agent
	 * 
	 * @param agentId
	 * @param roleClientId
	 * @param attributeName
	 * nom de la colonne associ�e
	 * @return un JDBCFilter
	 */
	private JDBCFilter createFiltreCatClient(String agentId, String roleClientId, String attributeName) {
		// R�cup�re l'unit� d'activit� associ�e � l'agent courant
		AgentDTO agent = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AgentDTO.class, agentId);
		List<CatClientUniteDTO> catClientUnites = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(CatClientUniteDTO.class,
				new Comparaison(CatClientUnite.SLINK_GERE_PAR_UNITE_ACTIVITE, Constantes.OPERATOR_EQUAL, agent.getUniteActivite().getId()));
		List<CatClientUniteDTO> catClientLivreUnites = new ArrayList<CatClientUniteDTO>();
		for (CatClientUniteDTO catClientUnite : catClientUnites) {
			if (roleClientId.equals(catClientUnite.getRoleClient().getId())) {
				catClientLivreUnites.add(catClientUnite);
			}
		}
		// Cr�ation du filtre sur le champ CategorieClient
		JDBCField field = TacheEnCoursJDBCFields.get(attributeName);
		if (catClientLivreUnites.isEmpty()) {
			return new JDBCFilter(field, JDBCFilter.OPERATOR_EQUAL, VALEUR_INEXISTANTE);
		}
		String[] values = new String[catClientLivreUnites.size()];
		int i = 0;
		for (CatClientUniteDTO catClientLivreUnite : catClientLivreUnites) {
			values[i] = catClientLivreUnite.getCategorieClient().getId();
			i++;
		}
		return new JDBCFilter(field, JDBCFilter.OPERATOR_IN, values);
	}

	/**
	 * Cr�e le filtre pour les roles de l'agent log�e
	 * 
	 * @param agentId l'agent
	 * @return un JDBCFilter
	 */
	private JDBCFilter createFiltreRoles(String agentId) {
		AgentDTO agent = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AgentDTO.class, agentId);
		List<RoleDTO> listePrivileges = agent.getUniteActivite().getRoles();
		List<String> values = new ArrayList<String>();

		for (RoleDTO role : listePrivileges) {
			values.add(role.getId());
		}
		JDBCField field = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ROLE);
		return new JDBCFilter(field, JDBCFilter.OPERATOR_IN, values.toArray(new String[0]));
	}

	/**
	 * Cr�e le filtre (un JDBCFilter) pour les cat�gories des clients
	 * contractants associ�s � l'unit� d'activit� d'un agent
	 * 
	 * @param agentId l'agent
	 * @return un JDBCFilter
	 */
	private JDBCFilter createFiltreCatClientContractant(String agentId) {
		return createFiltreCatClient(agentId, RoleClientConstantes.CO, TacheEnCoursJDBCFields.CATEGORIE_CLIENT_CONTRACTANT);
	}

	/**
	 * Cr�e le filtre (un JDBCFilter) pour les cat�gories des clients livr�s
	 * associ�s � l'unit� d'activit� d'un agent
	 * 
	 * @param agentId l'agent
	 * @return un JDBCFilter
	 */
	private JDBCFilter createFiltreCatClientLivre(String agentId) {
		return createFiltreCatClient(agentId, RoleClientConstantes.LIV, TacheEnCoursJDBCFields.CATEGORIE_CLIENT_LIVRE);
	}

	/**
	 * Cr�e les filtres (liste de JDBCCondition) pour les zones SI et GEO
	 * associ�es � l'unit� d'activit� d'un agent
	 * 
	 * @param agentId l'agent
	 * @return une liste de JDBCCondition
	 */
	private Collection<JDBCCondition> createFiltresZone(String agentId) {
		Collection<JDBCCondition> filtresZone = new ArrayList<JDBCCondition>();
		JDBCField zoneSIField = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ZONE_SI);
		JDBCField zoneGeoField = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ZONE_GEOGRAPHIQUE);
		// R�cup�re l'unit� d'activit� associ�e � l'agent courant
		AgentDTO agent = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AgentDTO.class, agentId);
		List<ZoneSiUniteDTO> zonesSiUnite = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ZoneSiUniteDTO.class,
				new Comparaison(ZoneSIUnite.SLINK_GERE_UNITE_UNITE_ACTIVITE, Constantes.OPERATOR_EQUAL, agent.getUniteActivite().getId()));
		List<ZoneGeoUniteDTO> zonesGeoUnite = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ZoneGeoUniteDTO.class,
				new Comparaison(ZoneGeoUnite.SLINK_GERE_PAR_UNITE_ACTIVITE, Constantes.OPERATOR_EQUAL, agent.getUniteActivite().getId()));
		// ZONES NON RENSEIGNEES
		if ((zonesGeoUnite.isEmpty()) && (zonesSiUnite.isEmpty())) {
			List<JDBCFilter> filtresZoneVides = new ArrayList<JDBCFilter>();
			filtresZoneVides.add(new JDBCFilter(zoneSIField, JDBCFilter.OPERATOR_EQUAL, VALEUR_INEXISTANTE));
			filtresZoneVides.add(new JDBCFilter(zoneGeoField, JDBCFilter.OPERATOR_EQUAL, VALEUR_INEXISTANTE));
			filtresZone.add(new JDBCCondition(JDBCCondition.OPERATOR_AND, filtresZoneVides));
		} else {
			// Filtres sur ZONE GEO
			String[] zoneGeoValues = new String[zonesGeoUnite.size()];
			int i = 0;
			for (ZoneGeoUniteDTO zoneGeoUnite : zonesGeoUnite) {
				zoneGeoValues[i] = zoneGeoUnite.getZoneGeographique().getId();
				i++;
			}
			List<JDBCFilter> zoneGeoFilters = new ArrayList<JDBCFilter>();
			// zoneGeo in (valeur1, valeur2...)
			zoneGeoFilters.add(new JDBCFilter(zoneGeoField, JDBCFilter.OPERATOR_IN, zoneGeoValues));
			// OR zoneGeo is null
			zoneGeoFilters.add(new JDBCFilter(zoneGeoField, JDBCFilter.OPERATOR_IS_NULL));
			filtresZone.add(new JDBCCondition(JDBCCondition.OPERATOR_OR, zoneGeoFilters));
			// Filtres sur ZONE SI
			String[] zoneSIValues = new String[zonesSiUnite.size()];
			int j = 0;
			for (ZoneSiUniteDTO zoneSiUnite : zonesSiUnite) {
				zoneSIValues[j] = zoneSiUnite.getZoneSi().getId();
				j++;
			}
			List<JDBCFilter> zoneSIFilters = new ArrayList<JDBCFilter>();
			// zoneSI in (valeur1, valeur2...)
			zoneSIFilters.add(new JDBCFilter(zoneSIField, JDBCFilter.OPERATOR_IN, zoneSIValues));
			// OR zoneSI is null
			zoneSIFilters.add(new JDBCFilter(zoneSIField, JDBCFilter.OPERATOR_IS_NULL));
			filtresZone.add(new JDBCCondition(JDBCCondition.OPERATOR_OR, zoneSIFilters));
		}
		return filtresZone;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createProcessusSuspendusFilter(java.lang.String)
	 */
	public FiltreDTO createProcessusSuspendusFilter(String agentId) {
		return createUniteActiviteFiltre(agentId);
	}

	/**
	 * Cr�e un filtre JDBCFilter pour ne pas afficher les taches ad-hoc, mais
	 * seulement les AVP et les t�ches manuelles.
	 * 
	 * @return un JDBCFilter
	 */
	private JDBCFilter createSansTacheAdHocFilter() {
		JDBCField roleField = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ROLE);
		return new JDBCFilter(roleField, JDBCFilter.OPERATOR_NOT_EQUAL, STEP_AUTO_PRIVILEGE);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createTachesCritiquesFilter(java.lang.String)
	 */
	public FiltreDTO createTachesCritiquesFilter(String agentId) {
		List<JDBCCondition> jdbcFilters = new ArrayList<JDBCCondition>();
		List<JDBCFilter> filtresSimples = new ArrayList<JDBCFilter>();
		filtresSimples.add(createSansTacheAdHocFilter());
		filtresSimples.add(createCommandesCritiquesFilter());
		jdbcFilters.add(new JDBCCondition(JDBCCondition.OPERATOR_AND, filtresSimples));
		jdbcFilters.addAll(createUniteActiviteFilter(agentId));
		return buildFiltreDTO(jdbcFilters);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createTexteFiltreDataFilter(java.lang.String, java.lang.String, java.lang.String)
	 */
	public FiltreDTO createTexteFiltreDataFilter(String infoId, String comparatorType, String texte) {
		List<JDBCFilter> filters = new ArrayList<JDBCFilter>();
		List<JDBCCondition> conditions = new ArrayList<JDBCCondition>();
		JDBCField field = (JDBCField) translator.translate(infoId);
		if (comparatorType.equals(FILTER_COMPARATOR_IS_NULL)) {
			filters.add(new JDBCFilter(field, translateComparator(comparatorType)));
		} else {
			filters.add(new JDBCFilter(field, translateComparator(comparatorType), texte));
		}
		conditions.add(new JDBCCondition(filters));
		return buildFiltreDTO(conditions);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createToutesTachesFilter(java.lang.String)
	 */
	public FiltreDTO createToutesTachesFilter(String agentId) {
		return createUniteActiviteFiltre(agentId);
	}

	/**
	 * Refacto pour creation des filtres Unite Activit�
	 */
	private FiltreDTO createUniteActiviteFiltre(String agentId) {
		List<JDBCCondition> conditions = new ArrayList<JDBCCondition>(createUniteActiviteFilter(agentId));
		return buildFiltreDTO(conditions);
	}

	/**
	 * Cr�e un filtre (liste de JDBCCondition) pour l'unit� d'activit� de
	 * l'utilisateur courant
	 * 
	 * @param agentId utilisateur courant
	 * @return une liste de JDBCCondition
	 */
	private List<JDBCCondition> createUniteActiviteFilter(String agentId) {
		List<JDBCFilter> filters = new ArrayList<JDBCFilter>();
		filters.add(createFiltreCatClientLivre(agentId));
		filters.add(createFiltreCatClientContractant(agentId));
		filters.add(createFiltreRoles(agentId));
		List<JDBCCondition> conditions = new ArrayList<JDBCCondition>(createFiltresZone(agentId));
		conditions.add(new JDBCCondition(JDBCCondition.OPERATOR_AND, filters));
		return conditions;
	}

	/**
	 * Traduit un op�rateur g�n�rique en op�rateur workflow
	 * 
	 * @param genericComparator
	 * @return l'�quivalent workflow de l'op�rateur g�n�rique
	 */
	private String translateComparator(String genericComparator) {
		String comparator;
		if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_EQUAL)) {
			comparator = JDBCFilter.OPERATOR_EQUAL;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_LOWER)) {
			comparator = JDBCFilter.OPERATOR_LOWER_THAN;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_GREATER)) {
			comparator = JDBCFilter.OPERATOR_GREATER_THAN;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_LIKE)) {
			comparator = JDBCFilter.OPERATOR_LIKE;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_LIKE_UPPER)) {
			comparator = JDBCFilter.OPERATOR_LIKE_UPPER;
		} else if (genericComparator.equals(FiltreDTOFactory.FILTER_COMPARATOR_IS_NULL)) {
			comparator = JDBCFilter.OPERATOR_IS_NULL;
		} else {
			throw new IllegalArgumentException(genericComparator + " n'est pas un comparateur de filtre valide");
		}
		return comparator;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory#createMultiCriteresDataFilter(java.lang.String, java.lang.String[])
	 */
	public FiltreDTO createMultiCriteresDataFilter(String infoId, String[] valueArray) {
		JDBCField field = (JDBCField) translator.translate(infoId);
		List<JDBCFilter> filters = new ArrayList<JDBCFilter>();
		JDBCFilter filter = new JDBCFilter(field, JDBCFilter.OPERATOR_IN, valueArray);
		filters.add(filter);
		List<JDBCCondition> conditions = new ArrayList<JDBCCondition>();
		conditions.add(new JDBCCondition(filters));
		return buildFiltreDTO(conditions);
	}
}