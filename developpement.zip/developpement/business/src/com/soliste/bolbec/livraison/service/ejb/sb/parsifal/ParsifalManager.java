package com.soliste.bolbec.livraison.service.ejb.sb.parsifal;

import com.soliste.bolbec.livraison.service.model.TransitPcmsDTO;

/**
 * Interface metier de l'ejb <code>ParsifalManagerSB</code><br/>
 * Interface repr�sentant le Business Interface pattern.
 * 
 * @author kyrw0678
 */
public interface ParsifalManager {

	/**
	 * Creates the transit pcms.
	 * 
	 * @param transitPcmsDTO the transitPcms dto
	 */
	void createTransitPcms(TransitPcmsDTO transitPcmsDTO);

	/**
	 * renvoie true si la recherche ne retourne aucun enregistrment, false sinon
	 * 
	 * @param ligneCommandeId the ligne commande id
	 * @param systemeExterne the systeme externe
	 * 
	 * @return the boolean
	 */
	Boolean findTransitPcmsByIdLdcAndServiceExterneAndIdFichierNull(String ligneCommandeId, String systemeExterne);
}
