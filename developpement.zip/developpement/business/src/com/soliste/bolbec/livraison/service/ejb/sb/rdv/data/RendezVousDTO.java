/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import java.io.Serializable;
import java.util.List;

import com.soliste.bolbec.livraison.service.model.InterventionDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO contenant les informations n�cessaires � l'affichage des donn�es du noeud RDV.
 */
public class RendezVousDTO implements Serializable {

	private String ligneCommandeId;
	private List<InterventionDTO> interventions;

	/**
	 * 
	 * @param ligneCommandeId
	 * @param interventions
	 */
	public RendezVousDTO(String ligneCommandeId, List<InterventionDTO> interventions) {
		this.ligneCommandeId = ligneCommandeId;
		this.interventions = interventions;
	}

	public List<InterventionDTO> getInterventions() {
		return this.interventions;
	}

	/**
	 * @param interventions the interventions to set
	 */
	public void setInterventions(List<InterventionDTO> interventions) {
		this.interventions = interventions;
	}

	public String getLigneCommandeId() {
		return this.ligneCommandeId;
	}

	/**
	 * @param ligneCommandeId the ligneCommandeId to set
	 */
	public void setLigneCommandeId(String ligneCommandeId) {
		this.ligneCommandeId = ligneCommandeId;
	}
}
