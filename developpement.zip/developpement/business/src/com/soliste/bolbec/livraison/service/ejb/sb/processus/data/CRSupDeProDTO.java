/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;

/**
 * Le DTO pour l'entit� CR EFB
 * 
 * @author La�titia FABRE
 */
public class CRSupDeProDTO implements Serializable {

	private String id;

	private String referenceCde;
	private String referenceLC;
	private String codeAction;
	private String jalon;
	private String codeDR;
	private String date;
	private String info;

	private String dateEnvoi;

	/**
	 * 
	 * @param id
	 */
	public CRSupDeProDTO(String id) {
		super();
		this.id = id;
	}

	/**
	 * Retourne le <code>id</code>
	 * 
	 * @return le <code>id</code>
	 */
	public String getId() {
		return id;
	}

	/**
	 * Affecte le <code>id</code>
	 * 
	 * @param id le <code>id</code> � affecter
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * Retourne le <code>codeAction</code>
	 * 
	 * @return le <code>codeAction</code>
	 */
	public String getCodeAction() {
		return codeAction;
	}

	/**
	 * Affecte le <code>codeAction</code>
	 * 
	 * @param codeAction le <code>codeAction</code> � affecter
	 */
	public void setCodeAction(String codeAction) {
		this.codeAction = codeAction;
	}

	/**
	 * Retourne le <code>codeDR</code>
	 * 
	 * @return le <code>codeDR</code>
	 */
	public String getCodeDR() {
		return codeDR;
	}

	/**
	 * Affecte le <code>codeDR</code>
	 * 
	 * @param codeDR le <code>codeDR</code> � affecter
	 */
	public void setCodeDR(String codeDR) {
		this.codeDR = codeDR;
	}

	/**
	 * Retourne le <code>date</code>
	 * 
	 * @return le <code>date</code>
	 */
	public String getDate() {
		return date;
	}

	/**
	 * Affecte le <code>date</code>
	 * 
	 * @param date le <code>date</code> � affecter
	 */
	public void setDate(String date) {
		this.date = date;
	}

	/**
	 * Retourne le <code>dateEnvoi</code>
	 * 
	 * @return le <code>dateEnvoi</code>
	 */
	public String getDateEnvoi() {
		return dateEnvoi;
	}

	/**
	 * Affecte le <code>dateEnvoi</code>
	 * 
	 * @param dateEnvoi le <code>dateEnvoi</code> � affecter
	 */
	public void setDateEnvoi(String dateEnvoi) {
		this.dateEnvoi = dateEnvoi;
	}

	/**
	 * Retourne le <code>info</code>
	 * 
	 * @return le <code>info</code>
	 */
	public String getInfo() {
		return info;
	}

	/**
	 * Affecte le <code>info</code>
	 * 
	 * @param info le <code>info</code> � affecter
	 */
	public void setInfo(String info) {
		this.info = info;
	}

	/**
	 * Retourne le <code>jalon</code>
	 * 
	 * @return le <code>jalon</code>
	 */
	public String getJalon() {
		return jalon;
	}

	/**
	 * Affecte le <code>jalon</code>
	 * 
	 * @param jalon le <code>jalon</code> � affecter
	 */
	public void setJalon(String jalon) {
		this.jalon = jalon;
	}

	/**
	 * Retourne le <code>referenceCde</code>
	 * 
	 * @return le <code>referenceCde</code>
	 */
	public String getReferenceCde() {
		return referenceCde;
	}

	/**
	 * Affecte le <code>referenceCde</code>
	 * 
	 * @param referenceCde le <code>referenceCde</code> � affecter
	 */
	public void setReferenceCde(String referenceCde) {
		this.referenceCde = referenceCde;
	}

	/**
	 * Retourne le <code>referenceLC</code>
	 * 
	 * @return le <code>referenceLC</code>
	 */
	public String getReferenceLC() {
		return referenceLC;
	}

	/**
	 * Affecte le <code>referenceLC</code>
	 * 
	 * @param referenceLC le <code>referenceLC</code> � affecter
	 */
	public void setReferenceLC(String referenceLC) {
		this.referenceLC = referenceLC;
	}

}
