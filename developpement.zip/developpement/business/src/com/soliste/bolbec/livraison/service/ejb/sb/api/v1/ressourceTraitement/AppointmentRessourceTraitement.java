package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement;

import javax.ejb.RemoveException;
import javax.ws.rs.core.Response;

import com.soliste.aps.workflow.xpm.wfsessionin.ConstantesXPM;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.ReferenceSpaceNavigatorAdaptateur;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.api.utils.AppointmentUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Appointment;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.AppointmentStatus;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.exception.LibererPlageException;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

/**
 * Traitement des ressources Note
 * 
 * @author mfayd
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/12/2015</TD><TD>MFA</TD><TD>Initialisation AppointmentRessourceTraitement</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>API REST</TD></TR>
 * </TABLE>
 **/
public class AppointmentRessourceTraitement {
	/**
	 * Manager Utils
	 */
	private final CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
	private final RendezVousManager RENDEZVOUS_MANAGER = ServiceManager.getInstance().getRendezVousManager();
	private final ILoggerManager LOGGER_MANAGER = ServiceManager.getInstance().getLoggerManager();
	private final String CLASS_NAME = getClass().getSimpleName();

	/**
	 * NoteRessourceTraitement
	 */
	public AppointmentRessourceTraitement() {

	}

	/**
	 * M�thode qui permet de lib�rer un rendez-vous
	 * 
	 * @param idCommande
	 * @param idIntervention
	 * @param appointment
	 * @param context
	 * @return
	 */
	public Response libererRdv(String idCommande, String idIntervention, Appointment appointment, @SuppressWarnings("unused") MessageContext context) {
		String methode = "libererRdv";
		ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, methode, "libererRdv pour la commande (id = " + idCommande + ")");

		// Erreur 404 si idCo ou idInter nulle + idInter et idCom non li�e
		if (StringUtils.isBlank(idCommande)) {
			throw APIExceptionEnum.appointmentorderidnotfound.createAPIException(idCommande);
		}
		if (StringUtils.isBlank(idIntervention)) {
			throw APIExceptionEnum.appointmentidnotfound.createAPIException(idIntervention);
		}
		if (!AppointmentUtils.interventionLieeACommande(idIntervention, idCommande)) {
			throw APIExceptionEnum.appointmentorderandrdvnotlinked.createAPIException(idIntervention, idCommande);
		}

		// Erreur 404 si appointment nul
		if (appointment == null) {
			throw APIExceptionEnum.appointmentdoesnotexist.createAPIException();
		}

		AppointmentStatus etatIntervention = appointment.getState();
		if (AppointmentStatus.unknown.equals(etatIntervention)) {
			throw APIExceptionEnum.appointmentbadstatus.createAPIException();
		}

		// Erreur 404 si status=aborted
		if (!AppointmentStatus.aborted.equals(etatIntervention)) {
			throw APIExceptionEnum.appointmentbadstateintervention.createAPIException(idIntervention);
		}

		String closureEventCauseId = null;
		if (appointment.getClosureEventCause() != null) {
			closureEventCauseId = appointment.getClosureEventCause().getId();
		}

		InterventionDTO interventionDTO = COMMANDE_MANAGER.getIntervention(idIntervention);
		// On r�cup�re l'objet appointment
		appointment = AppointmentUtils.getAppointmentByInterventionDTO(interventionDTO);
		appointment.setState(AppointmentStatus.aborted);
		AgentDTO agentDTO = ReferenceSpaceNavigatorAdaptateur.findInReferenceSpace(AgentDTO.class, ConstantesXPM.DEFAULT_XPM_USER);
		try {
			RENDEZVOUS_MANAGER.libererPlage(idIntervention, agentDTO, closureEventCauseId);
		} catch (LibererPlageException e) {
			LOGGER_MANAGER.fine(CLASS_NAME, methode, e + "LibererPlageException : Probl�me lors de la lib�ration de l'intervention id " + idIntervention + " pour la commande id :" + idCommande);
			throw APIExceptionEnum.appointmenterrorcancelling.createAPIException(idIntervention);
		} catch (RemoveException e) {
			LOGGER_MANAGER.fine(CLASS_NAME, methode, e + "RemoveException : Probl�me lors de la lib�ration de l'intervention id " + idIntervention + " pour la commande id :" + idCommande);
			e.printStackTrace();
			throw APIExceptionEnum.appointmenterrorcancelling.createAPIException(idIntervention, e.getMessage());
		}
		return Response.ok(appointment).build();
	}

	/**
	 * getRdv
	 * 
	 * @param idCommande
	 * @param idIntervention
	 * @param context
	 * @return
	 */
	public Response getIntervention(String idCommande, String idIntervention, @SuppressWarnings("unused") MessageContext context) {
		String methode = "getRdv";
		ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, methode, "getRdv pour la commande (id = " + idCommande + ")");

		// On v�rifie si la commande contient l'intervention sinon On sort avec un notFoundException

		// Erreur 404 si idCo ou idInter nulle + idInter et idCom non li�e
		if (StringUtils.isBlank(idCommande)) {
			throw APIExceptionEnum.appointmentorderidnotfound.createAPIException(idCommande);
		}
		if (StringUtils.isBlank(idIntervention)) {
			throw APIExceptionEnum.appointmentidnotfound.createAPIException(idIntervention);
		}
		if (!AppointmentUtils.interventionLieeACommande(idIntervention, idCommande)) {
			throw APIExceptionEnum.appointmentorderandrdvnotlinked.createAPIException(idIntervention, idCommande);
		}

		// On r�cup�re interventionDTO par son Id
		InterventionDTO interventionDTO = COMMANDE_MANAGER.getIntervention(idIntervention);

		if (interventionDTO == null) {
			throw APIExceptionEnum.appointmentnotfound.createAPIException(idIntervention);
		}

		// On r�cup�re l'objet appointment
		Appointment appointment = AppointmentUtils.getAppointmentByInterventionDTO(interventionDTO);

		return Response.ok(appointment).build();
	}

	public void validate(@SuppressWarnings("unused") Appointment appointment) {

	}

}
