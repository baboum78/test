package com.soliste.bolbec.livraison.service.ejb.sb;

import javax.ejb.EJBObject;

/**
 * Interface Remote de l'EJB session CompteRenduManagerSB.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public interface CompteRenduManagerRemote extends ICompteRenduManagerRemote, EJBObject {

}
