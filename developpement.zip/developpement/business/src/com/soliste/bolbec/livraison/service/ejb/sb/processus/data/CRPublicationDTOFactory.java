/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.w3c.dom.DOMException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import aps.EtatPublicationConstantes;
import aps.LienComplementCR;
import aps.SystemeExterneConstantes;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.RegularisationManuelleTraitement;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.model.ComplementCrDTO;
import com.soliste.bolbec.livraison.service.model.EtatPublicationDTO;
import com.soliste.bolbec.livraison.service.model.LienComplementCrDTO;
import com.soliste.bolbec.livraison.service.model.LienPublicationDTO;
import com.soliste.bolbec.livraison.service.model.PubRegManDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatRegulDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * 
 * Construit les CR Sagic, EFB, SupDePro, Cristal et Osiris que l'on veut visualiser dans l'IHM
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>17/09/2010</TD><TD>YTR</TD><TD>IRMA_798 : ajout du champs NumFT pour la publication des CR Sagic</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>17/07/2012</TD><TD>BPE</TD><TD>EV-000188: Remonter les CR d�avancement attendus par GRAFIC</TD></TR>
 * <TR><TD>14/02/2013</TD><TD>FTE</TD><TD>G8R2C1 - EV-000210 : Offre BVPN&BI FTTH(TRA-12-12) - Affichage des CR Frontal</TD></TR>
 * <TR><TD>17/05/2013</TD><TD>EBA</TD><TD>G8R2C2 - DE-664 (231 FT) : En regularisation Manuel publication impossible sur cmd suppression offre</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'><TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.5060</TD><TD>EP0141 � Remonter les CR d�avancement attendus par GRAFIC</TD></TR>
 * </TABLE>
 */
public class CRPublicationDTOFactory {

	private static String CLASS_NAME = "CRPublicationDTOFactory";

	/**
	 * Nom (et cl�) du champ ND pour le CR Cristal
	 */
	public static final String CLE_CR_CRISTAL_ND = "ND";
	/**
	 * Nom (et cl�) du champ Operation pour le CR Cristal
	 */
	public static final String CLE_CR_CRISTAL_OPERATION = "Operation";

	/**
	 * Valeur indiquant que le Compl�mentCR est obligatoire (champ Compl�mentCR.Obligatoire).
	 */
	private static final String STRING_COMPLEMENT_CR_OBLIGATOIRE = "O";

	private static final String STRING_BLANK = "";

	private CRPublicationDTOFactory() {
		// Constructeur
	}

	/**
	 * Cr�e le CRGenNonInfocentreDTO correspondant � pubRegMan.
	 * 
	 * @param pubRegMan
	 * @param lienPublication
	 * @return CRGenNonInfocentreDTO
	 */
	public static CRGenNonInfocentreDTO createCRNonInfocentre(PubRegManDTO pubRegMan) {

		// R�cup�ration du syst�me externe
		SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, pubRegMan.getSystemeExterne().getId());

		// R�cup�ration de l'�tat de la publication
		EtatPublicationDTO etat = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(EtatPublicationDTO.class, pubRegMan.getEtatPublication().getId());

		// R�cup�ration du LienPublication
		LienPublicationDTO lienPublication = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(LienPublicationDTO.class, pubRegMan.getLienPublication().getId());

		// Construction du DTO retourn�
		CRGenNonInfocentreDTO crNonInfocentreDTO = new CRGenNonInfocentreDTO(pubRegMan.getId());
		crNonInfocentreDTO.setSysExterne(se.getValeurConstante());
		crNonInfocentreDTO.setJalon(pubRegMan.getJalon().getId());
		crNonInfocentreDTO.setFormatExterne(lienPublication.getFormatExterne());
		crNonInfocentreDTO.setLibelleEtatPublication(etat.getLibelle());
		crNonInfocentreDTO.setLibelleLienPublication(lienPublication.getLibelleExterne());
		crNonInfocentreDTO.setValidable(!EtatPublicationConstantes.ENVOYE.equals(etat.getId()));

		return crNonInfocentreDTO;
	}

	/**
	 * Cr�e le CRGenNonInfocentreDTO correspondant � pubRegMan avec les champs possibles.
	 * 
	 * @param pubRegMan
	 * @return CRGenNonInfocentreDTO
	 */
	public static CRGenNonInfocentreDTO createCRNonInfocentreAvecChamps(PubRegManDTO pubRegMan) {
		final String METHOD_NAME = "createCRNonInfocentre";

		// Construction du DTO retourn�
		CRGenNonInfocentreDTO crNonInfocentreDTO = createCRNonInfocentre(pubRegMan);

		// Construction des champs
		Map<String, ChampCRGenNonInfocentreDTO> champsCR = getChampsPossiblesPourCR(pubRegMan);

		// Appel de la m�thode de lecture du message en fonction du SE
		String contenu = pubRegMan.getContenu();
		List<ChampCRGenNonInfocentreDTO> champsCRlst = new ArrayList<ChampCRGenNonInfocentreDTO>();
		if (SystemeExterneConstantes.SAGIC_VALEUR_CONSTANTE.equals(crNonInfocentreDTO.getSysExterne())) {
			champsCRlst = valoriserChampsCRSagic(contenu, champsCR);
		} else if (SystemeExterneConstantes.EFB_VALEUR_CONSTANTE.equals(crNonInfocentreDTO.getSysExterne())) {
			champsCRlst = valoriserChampsCREFB(contenu, champsCR);
		} else if (SystemeExterneConstantes.NUM_45R_VALEUR_CONSTANTE.equals(crNonInfocentreDTO.getSysExterne())) {
			champsCRlst = valoriserChampsCRCristal(contenu);
		} else if (SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(crNonInfocentreDTO.getSysExterne())) {
			champsCRlst = valoriserChampsCRGraficEtFrontal(contenu);
		} else if (SystemeExterneConstantes.FRONTAL_VALEUR_CONSTANTE.equals(crNonInfocentreDTO.getSysExterne())) {
			champsCRlst = valoriserChampsCRGraficEtFrontal(contenu);
		} else {
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Le systeme externe \"" + crNonInfocentreDTO.getSysExterne() + "\" n'est pas g�r�. Seuls EFB, SAGIC et Cristal (45R) le sont.");
		}
		crNonInfocentreDTO.setChamps(champsCRlst);

		return crNonInfocentreDTO;
	}

	/**
	 * Retourne la liste des champs que comprend le CR.
	 * 
	 * @param pubRegMan
	 * @return Map
	 */
	private static Map<String, ChampCRGenNonInfocentreDTO> getChampsPossiblesPourCR(PubRegManDTO pubRegMan) {
		Map<String, ChampCRGenNonInfocentreDTO> champsCRmap = new HashMap<String, ChampCRGenNonInfocentreDTO>();
		String lienPublication = pubRegMan.getLienPublication().getId();
		List<LienComplementCrDTO> liensComplementCr = ServiceManager.getInstance().getReferenceSpaceManager()
				.listInReferenceSpace(LienComplementCrDTO.class, new Comparaison(LienComplementCR.SLINK_POUR_LIEN_PUBLICATION, Constantes.OPERATOR_EQUAL, lienPublication));
		for (LienComplementCrDTO lienComplementCR : liensComplementCr) {
			ComplementCrDTO complementCr = lienComplementCR.getComplementCr();
			ChampCRGenNonInfocentreDTO champ = new ChampCRGenNonInfocentreDTO(complementCr.getCleCr());
			String cleCR = complementCr.getCleCr();
			champ.setLibelle(cleCR);
			champ.setModifiable(true);
			champ.setObligatoire(STRING_COMPLEMENT_CR_OBLIGATOIRE.equals(lienComplementCR.getObligatoire()));
			champsCRmap.put(cleCR, champ);
		}
		return champsCRmap;
	}

	/**
	 * Lecture du XML (champ contenu de PubRegMan) pour r�cup�rer les valeurs
	 * des champs du CR.
	 * 
	 * @param contenu champ contenu de PubRegMan
	 * @param champsCR Map des champs modifiables pour le CR correspondant
	 * � pubRegMan avec cl�=cleCR et valeur=ChampCRGenNonInfocentreDTO
	 * @return liste de tous les champs tri�s par ordre dans le XML
	 */
	private static List<ChampCRGenNonInfocentreDTO> valoriserChampsCRSagic(String contenu, Map<String, ChampCRGenNonInfocentreDTO> champsCR) {
		final String METHOD_NAME = "valoriserChampsCRSagic";
		List<ChampCRGenNonInfocentreDTO> champs = new ArrayList<ChampCRGenNonInfocentreDTO>();

		// Cr�ation du document XML (field params)
		Document document;
		if ((contenu != null) && (contenu.length() > 0)) {
			try {
				document = XmlUtils.getDocument(contenu);
				Element racine = document.getDocumentElement();

				// R�cup�ration des valeurs des attributs dans le XML
				// - d'abord dans le bloc CR
				NodeList crNL = racine.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CR);
				Element cr = (Element) crNL.item(0);
				champs.add(valoriserChampCRSagic(champsCR, cr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CDE_ID));
				champs.add(valoriserChampCRSagic(champsCR, cr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CODE));
				champs.add(valoriserChampCRSagic(champsCR, cr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_COMMENTAIRE_FT));
				champs.add(valoriserChampCRSagic(champsCR, cr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_COMMENTAIRE_FAI));

				// - puis dans le bloc ComplementCr
				NodeList complementCrNL = cr.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_COMPLEMENT);
				Element complementCr = (Element) complementCrNL.item(0);
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_TYPE_MODEM));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_MES_PREVUE));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_LEVEE_SAT));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_EXEC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_EFFET));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_RECYCL));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_INSTANCE_BOLBEC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_LIB_ENTITE));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_TEL_ENTITE));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_VILLE_ENTITE));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_NUM_VC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CHGT_DSLAM));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CODE_DR));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_NRA));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CODE_INSEE));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CARAC_LIG));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_NUM_FT));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_STATUT_NUM_FT));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_RDV_OP));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CRENEAU_RDV_OP));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_RDV_INIT));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CRENEAU_RDV_INIT));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_RDV_KO));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CRENEAU_RDV_KO));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_LIB_COMM_PC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CODE_COMM_PC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_ESCALIER_PC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_NUM_VOIE_PC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_LIB_VOIE_PC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_BATIMENT_PC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_ETAGE_PC));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_TETE_AM_PAIRE));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_CODE_BASICAT));
				champs.add(valoriserChampCRSagic(champsCR, complementCr, com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML.TAG_CR_DATE_PORT));
			} catch (IOException ioe) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getDocument");
				throw new InvalidMessageException("Erreur dans getDocument", contenu, ioe);
			} catch (SAXException saxe) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getDocument");
				throw new InvalidMessageException("Erreur dans getDocument", contenu, saxe);
			} catch (DOMException de) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getNodeValue");
				throw new InvalidMessageException("Erreur dans getNodeValue", contenu, de);
			}
		}
		return champs;
	}

	/**
	 * Valorisation de la valeur du champ de nom cleCR parmi champsCR �
	 * partir de element qui est le bloc XML contenant l'attribut cleCR.
	 * 
	 * @param champsCR
	 * @param element
	 * @param cleCR
	 * @return le champ (modifi� � partir de champsCR pour les champs
	 * modifiables, cr�� sinon)
	 */
	private static ChampCRGenNonInfocentreDTO valoriserChampCRSagic(Map<String, ChampCRGenNonInfocentreDTO> champsCR, Element element, String cleCR) {
		String valeur = element.getAttribute(cleCR);
		ChampCRGenNonInfocentreDTO champ = champsCR.get(cleCR);
		if (champ == null) {
			champ = new ChampCRGenNonInfocentreDTO(cleCR);
			champ.setLibelle(cleCR);
			champ.setObligatoire(false);
			champ.setModifiable(false);
		}
		if (valeur != null) {
			champ.setValeur(valeur);
		} else {
			champ.setValeur(STRING_BLANK);
		}
		return champ;
	}

	/**
	 * Lecture du XML (champ contenu de PubRegMan) pour r�cup�rer les valeurs
	 * des champs du CR.
	 * 
	 * <BR><B>HISTORIQUE</B>
	 * <TABLE frame='border' >
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>22/07/2013</TD><TD>EBA</TD><TD>G9R0C1 DE-820 : Prise en compte revue de code</TD></TR>
	 * </TABLE><BR>
	 * 
	 * @param contenu champ contenu de PubRegMan
	 * @param champsCR Map des champs possibles pour le CR correspondant
	 * � pubRegMan avec cl�=cleCR et valeur=ChampCRGenNonInfocentreDTO
	 * En entr�e, seules les champs modifiable, en sortie, tous les champs
	 * @return liste de tous les champs tri�s par ordre dans le XML
	 */
	private static List<ChampCRGenNonInfocentreDTO> valoriserChampsCREFB(String contenu, Map<String, ChampCRGenNonInfocentreDTO> champsCR) {
		final String METHOD_NAME = "valoriserChampsCREFB";
		List<ChampCRGenNonInfocentreDTO> champs = new ArrayList<ChampCRGenNonInfocentreDTO>();

		// Cr�ation du document XML (field params)
		Document document;
		if ((contenu != null) && (contenu.length() > 0)) {
			try {
				document = XmlUtils.getDocument(contenu);

				// R�cup�ration des param�tres et construction du CRSagicDTO
				Element racine = document.getDocumentElement();
				NodeList structTechniqueNL = racine.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STRUCTURE_TECHNIQUE);
				Element structTechnique = (Element) structTechniqueNL.item(0);
				String prefix = com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STRUCTURE_TECHNIQUE + ".";
				String prefixLib = "";
				champs.add(valoriserChampCREFB(champsCR, structTechnique, prefixLib, prefix, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_REF_MESSAGE));
				champs.add(valoriserChampCREFB(champsCR, structTechnique, prefixLib, prefix, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_TYPE_MESSAGE));
				champs.add(valoriserChampCREFB(champsCR, structTechnique, prefixLib, prefix, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_TYPE_EVENEMENT));
				champs.add(valoriserChampCREFB(champsCR, structTechnique, prefixLib, prefix, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CODE_BASE_EMETTEUR));
				champs.add(valoriserChampCREFB(champsCR, structTechnique, prefixLib, prefix, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_MODELE_LPA));
				champs.add(valoriserChampCREFB(champsCR, structTechnique, prefixLib, prefix, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_VERSION_MODELE_LPA));
				champs.add(valoriserChampCREFB(champsCR, structTechnique, prefixLib, prefix, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_HORODATAGE_MESSAGE));

				NodeList structMetierNL = racine.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STRUCTURE_METIER);
				Element structMetier = (Element) structMetierNL.item(0);
				// Commande
				NodeList commandeNL = structMetier.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CDE);
				Element commande = (Element) commandeNL.item(0);
				String prefixCde = com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STRUCTURE_METIER + "." + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CDE + ".";
				champs.add(valoriserChampCREFB(champsCR, commande, prefixLib, prefixCde, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_REF_CDE));
				// StatutOPCommande
				NodeList statutOpCommandeNL = commande.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STATUT_OP_COMMANDE);
				Element statutOpCommande = (Element) statutOpCommandeNL.item(0);
				String prefixStatutOpCommande = prefixCde + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STATUT_OP_COMMANDE + ".";
				champs.add(valoriserChampCREFB(champsCR, statutOpCommande, prefixLib, prefixStatutOpCommande, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CODE_STATUT_OP_COMMANDE));
				// LigneCde
				NodeList ligneCommandeNL = commande.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_LIGNE_CDE);
				for (int i = 0; i < ligneCommandeNL.getLength(); i++) {
					Element ligneCommande = (Element) ligneCommandeNL.item(i);
					String prefixLC = prefixCde + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_LIGNE_CDE + "_" + i + ".";
					String prefixlibLC = com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_LIGNE_CDE + "_" + i + ".";
					champs.add(valoriserChampCREFB(champsCR, ligneCommande, prefixlibLC, prefixLC, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_REF_LIGNE_CDE));
					// ContrainteLC
					NodeList contrainteLC = ligneCommande.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CONTRAINTE_LC);
					if (contrainteLC != null) {
						for (int j = 0; j < contrainteLC.getLength(); j++) {
							Element contrainte = (Element) contrainteLC.item(j);
							if (contrainte != null) {
								String prefixContrainteLC = prefixLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CONTRAINTE_LC + "_" + j + ".";
								String prefixlibContrainteLC = prefixlibLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CONTRAINTE_LC + "_" + j + ".";
								champs.add(valoriserChampCREFB(champsCR, contrainte, prefixlibContrainteLC, prefixContrainteLC, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_TYPE_CONTRAINTE));
								champs.add(valoriserChampCREFB(champsCR, contrainte, prefixlibContrainteLC, prefixContrainteLC, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_VALEUR_CONTRAINTE));
							}
						}
					}
					// Rendez-Vous
					NodeList rendezVous = ligneCommande.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_RENDEZ_VOUS);
					if (rendezVous != null) {
						for (int j = 0; j < rendezVous.getLength(); j++) {
							Element rdv = (Element) rendezVous.item(j);
							if (rdv != null) {
								String prefixRendezVous = prefixLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_RENDEZ_VOUS + "_" + j + ".";
								String prefixLibRendezVous = prefixlibLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_RENDEZ_VOUS + "_" + j + ".";
								champs.add(valoriserChampCREFB(champsCR, rdv, prefixLibRendezVous, prefixRendezVous, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_REF_RENDEZ_VOUS));
								champs.add(valoriserChampCREFB(champsCR, rdv, prefixLibRendezVous, prefixRendezVous, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_DATE_RENDEZ_VOUS));
								champs.add(valoriserChampCREFB(champsCR, rdv, prefixLibRendezVous, prefixRendezVous, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_HEURE_DEBUT_RENDEZ_VOUS));
								champs.add(valoriserChampCREFB(champsCR, rdv, prefixLibRendezVous, prefixRendezVous, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_DUREE_RENDEZ_VOUS));
								champs.add(valoriserChampCREFB(champsCR, rdv, prefixLibRendezVous, prefixRendezVous, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STATUT_RENDEZ_VOUS));
								champs.add(valoriserChampCREFB(champsCR, rdv, prefixLibRendezVous, prefixRendezVous, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_MOTIF_STATUT_RENDEZ_VOUS));
							}
						}
					}
					// Dates
					NodeList datesNL = ligneCommande.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_DATES);
					if (datesNL != null) {
						for (int j = 0; j < datesNL.getLength(); j++) {
							Element dates = (Element) datesNL.item(j);
							if (dates != null) {
								String prefixDates = prefixLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_DATES + "_" + j + ".";
								String prefixLibDates = prefixlibLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_DATES + "_" + j + ".";
								champs.add(valoriserChampCREFB(champsCR, dates, prefixLibDates, prefixDates, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_TYPE_DATE));
								champs.add(valoriserChampCREFB(champsCR, dates, prefixLibDates, prefixDates, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_VALEUR_DATE));
								champs.add(valoriserChampCREFB(champsCR, dates, prefixLibDates, prefixDates, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_HEURE_REA));
							}
						}
					}
					// StatutOperationnel
					NodeList statutOperationnelNL = ligneCommande.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STATUT_OP);
					if (statutOperationnelNL != null) {
						Element statutOperationnel = (Element) statutOperationnelNL.item(0);
						String prefixStatutOperationnel = prefixLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_STATUT_OP + ".";
						champs.add(valoriserChampCREFB(champsCR, statutOperationnel, prefixlibLC, prefixStatutOperationnel, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CODE_STATUT_OP));
						champs.add(valoriserChampCREFB(champsCR, statutOperationnel, prefixlibLC, prefixStatutOperationnel, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_DATE_STATUT_OP));
						// ComplementStatutOP
						if (statutOperationnel != null) {// test de nullite tardif car avant, null g�r� par valoriserChampCREFB pour les champs obligatoires
							NodeList complementStatutOPNL = statutOperationnel.getElementsByTagName(com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CPLT_STATUT_OP);
							if (complementStatutOPNL != null) {
								for (int j = 0; j < complementStatutOPNL.getLength(); j++) {
									Element complementStatutOP = (Element) complementStatutOPNL.item(j);
									// CodeCptStatutOperation
									if (complementStatutOP != null) {
										String prefixCpltStatutOP = prefixStatutOperationnel + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CPLT_STATUT_OP + "_" + j + ".";
										String prefixLibCpltStatutOP = prefixlibLC + com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CPLT_STATUT_OP + "_" + j + ".";
										champs.add(valoriserChampCREFB(champsCR, complementStatutOP, prefixLibCpltStatutOP, prefixCpltStatutOP, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_CODE_CPLT_STATUT_OP));
										champs.add(valoriserChampCREFB(champsCR, complementStatutOP, prefixLibCpltStatutOP, prefixCpltStatutOP, com.soliste.bolbec.livraison.service.interfaces.commun.efb.TagsXML.TAG_CR_LIBELLE_CPLT_STATUT_OP));
									}
								}
							}
						}
					}
				}
			} catch (IOException ioe) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getDocument");
				throw new InvalidMessageException("Erreur dans getDocument", contenu, ioe);
			} catch (SAXException saxe) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getDocument");
				throw new InvalidMessageException("Erreur dans getDocument", contenu, saxe);
			} catch (DOMException de) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getNodeValue");
				throw new InvalidMessageException("Erreur dans getNodeValue", contenu, de);
			}
		}
		return champs;
	}

	/**
	 * Valorisation de la valeur du champ de nom cleCR parmi champsCR �
	 * partir de element qui est le bloc XML contenant l'attribut cleCR.
	 * 
	 * @param champsCR
	 * @param element
	 * @param prefixLibelle
	 * @param prefixCleCR
	 * @param cleCR
	 * @return le champ (modifi� � partir de champsCR pour les champs
	 * modifiables, cr�� sinon)
	 */
	private static ChampCRGenNonInfocentreDTO valoriserChampCREFB(Map<String, ChampCRGenNonInfocentreDTO> champsCR, Element element, String prefixLibelle, String prefixCleCR, String cleCR) {
		String valeur = null;

		if (element != null) {
			if (element.getElementsByTagName(cleCR) != null) {
				Element ssElement = (Element) element.getElementsByTagName(cleCR).item(0);
				if (ssElement != null) {
					Node node = ssElement.getFirstChild();
					if (node != null) {
						valeur = node.getNodeValue();
					}
				}
			}
		}

		ChampCRGenNonInfocentreDTO champ;
		ChampCRGenNonInfocentreDTO champModel = champsCR.get(cleCR);
		if (champModel == null) {
			champ = new ChampCRGenNonInfocentreDTO(prefixCleCR + cleCR);
			champ.setLibelle(prefixLibelle + cleCR);
			champ.setObligatoire(false);
			champ.setModifiable(false);
		} else {
			champ = new ChampCRGenNonInfocentreDTO(prefixCleCR + cleCR);
			champ.setLibelle(prefixLibelle + cleCR);
			champ.setObligatoire(champModel.isObligatoire());
			champ.setModifiable(champModel.isModifiable());
		}
		if (valeur != null) {
			champ.setValeur(valeur);
		} else {
			champ.setValeur(STRING_BLANK);
		}
		return champ;
	}

	/**
	 * Lecture du champ contenu de PubRegMan pour r�cup�rer les valeurs
	 * des champs du CR.
	 * 
	 * @param contenu champ contenu de PubRegMan
	 * @return Liste des champs
	 */
	private static List<ChampCRGenNonInfocentreDTO> valoriserChampsCRCristal(String contenu) {
		List<ChampCRGenNonInfocentreDTO> champs = new ArrayList<ChampCRGenNonInfocentreDTO>();

		// TODO OLD: que faire avec Cristal ?????

		// Cristal est particulier, les champs ne sont pas r�cup�rer par la requ�te en BD
		// On les cr�e donc maintenant
		// - ND
		String nd = contenu.substring(0, 10);
		if (nd != null) {
			ChampCRGenNonInfocentreDTO champND = new ChampCRGenNonInfocentreDTO(CLE_CR_CRISTAL_ND);
			champND.setLibelle(CLE_CR_CRISTAL_ND);
			champND.setObligatoire(true);
			champND.setValeur(nd);
			champs.add(champND);
		}
		// - Operation
		String operation = contenu.substring(contenu.length() - 1);
		if (operation != null) {
			ChampCRGenNonInfocentreDTO champOp = new ChampCRGenNonInfocentreDTO(CLE_CR_CRISTAL_OPERATION);
			champOp.setLibelle(CLE_CR_CRISTAL_OPERATION);
			champOp.setObligatoire(true);
			champOp.setValeur(operation);
			champs.add(champOp);
		}

		return champs;
	}

	/**
	 * Lecture du champ contenu de PubRegMan pour r�cup�rer les valeurs
	 * des champs du CR.
	 * 
	 * @param contenu champ contenu de PubRegMan
	 * @return Liste des champs
	 */
	private static List<ChampCRGenNonInfocentreDTO> valoriserChampsCRGraficEtFrontal(String contenu) {
		final String chaineContenu = "Contenu";
		List<ChampCRGenNonInfocentreDTO> champs = new ArrayList<ChampCRGenNonInfocentreDTO>();

		ChampCRGenNonInfocentreDTO champND = new ChampCRGenNonInfocentreDTO(chaineContenu);
		champND.setLibelle(chaineContenu);
		champND.setObligatoire(true);
		champND.setValeur(contenu);
		champs.add(champND);

		return champs;
	}

	/**
	 * @param pubRegManSupDePro
	 * 
	 * @return CRSupDeProDTO
	 */
	public static ListCRSupDeProDTO createSupDePro(PubRegManDTO pubRegManSupDePro) {

		String METHOD_NAME = "createSupDePro";

		String id = pubRegManSupDePro.getId();

		// R�cup�ration de l'�tat de la publication
		EtatPublicationDTO etat = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(EtatPublicationDTO.class, pubRegManSupDePro.getEtatPublication().getId());

		// R�cup�ration du LienPublication
		LienPublicationDTO lienPublication = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(LienPublicationDTO.class, pubRegManSupDePro.getLienPublication().getId());

		// Construction du DTO retourn�
		ListCRSupDeProDTO listSupDePro = new ListCRSupDeProDTO(id);
		listSupDePro.setJalon(pubRegManSupDePro.getJalon().getId());
		listSupDePro.setFormatExterne(lienPublication.getFormatExterne());
		listSupDePro.setLibelleEtatPublication(etat.getLibelle());
		listSupDePro.setLibelleLienPublication(lienPublication.getLibelleExterne());
		listSupDePro.setValidable(!EtatPublicationConstantes.ENVOYE.equals(etat.getId()));

		Document document;
		String contenuSupDePro = pubRegManSupDePro.getContenu();
		if ((contenuSupDePro != null) && (contenuSupDePro.length() > 0)) {
			try {
				document = XmlUtils.getDocument(contenuSupDePro);

				// R�cup�ration des param�tres et construction du CRSagicDTO
				Element racine = document.getDocumentElement();
				// Publication
				NodeList publicationNL = racine.getElementsByTagName("PUBLICATION");
				for (int i = 0; i < publicationNL.getLength(); i++) {

					CRSupDeProDTO crSupDeProDTO = new CRSupDeProDTO(id);

					Element publication = (Element) publicationNL.item(i);
					crSupDeProDTO.setReferenceCde(publication.getAttribute("ReferenceCde"));
					crSupDeProDTO.setReferenceLC(publication.getAttribute("ReferenceLC"));
					crSupDeProDTO.setCodeAction(publication.getAttribute("CodeAction"));
					crSupDeProDTO.setJalon(publication.getAttribute("Jalon"));
					crSupDeProDTO.setCodeDR(publication.getAttribute("CodeDR"));
					crSupDeProDTO.setDate(publication.getAttribute("Date"));
					crSupDeProDTO.setInfo(publication.getAttribute("Info"));
					crSupDeProDTO.setDateEnvoi(publication.getAttribute("DateEnvoi"));

					listSupDePro.add(crSupDeProDTO);
				}
			} catch (IOException ioe) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getDocument");
				throw new InvalidMessageException("Erreur dans getDocument", contenuSupDePro, ioe);
			} catch (SAXException saxe) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getDocument");
				throw new InvalidMessageException("Erreur dans getDocument", contenuSupDePro, saxe);
			} catch (DOMException de) {
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, METHOD_NAME, "Erreur dans getNodeValue");
				throw new InvalidMessageException("Erreur dans getNodeValue", contenuSupDePro, de);
			}
		}

		return listSupDePro;
	}

	/**
	 * 
	 * @param transitSystStatRegulId
	 * 
	 * @return CROsirisDTO
	 */
	public static CROsirisDTO createOsirisId(String transitSystStatRegulId) {
		return new CROsirisDTO(transitSystStatRegulId);
	}

	/**
	 * 
	 * @param transitSystStatRegul
	 * 
	 * @return CROsirisDTO
	 */
	public static CROsirisDTO createOsiris(TransitSystStatRegulDTO transitSystStatRegul) {
		CROsirisDTO crOsirisDTO = new CROsirisDTO(transitSystStatRegul.getId());
		crOsirisDTO.setIdEntite(transitSystStatRegul.getIdEntite());
		crOsirisDTO.setFormatExterne(transitSystStatRegul.getFormatExterne());
		crOsirisDTO.setInstanceLocalisation(transitSystStatRegul.getInstanceLocalisation().getId());
		crOsirisDTO.setIdFichier(transitSystStatRegul.getIdFichier());
		if (transitSystStatRegul.getDateTransfert() != null) {
			crOsirisDTO.setDateTransfert(String.valueOf(transitSystStatRegul.getDateTransfert().longValue()));
		} else {
			crOsirisDTO.setDateTransfert("");
		}

		crOsirisDTO.setCodeTransfert(transitSystStatRegul.getCodeTransfert());
		crOsirisDTO.setVersion(transitSystStatRegul.getVersion());
		crOsirisDTO.setValidable(!RegularisationManuelleTraitement.CODE_TRANSFERT_APURGER.equals(transitSystStatRegul.getCodeTransfert()));

		// D�finition du libell� de l'�tat de publication, on utilise les libell�s
		// de la table EtatPublication
		String libelleEtatPublication = STRING_BLANK;
		if (RegularisationManuelleTraitement.CODE_TRANSFERT_APURGER.equals(transitSystStatRegul.getCodeTransfert())) {
			EtatPublicationDTO etat = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(EtatPublicationDTO.class, EtatPublicationConstantes.ENVOYE);
			libelleEtatPublication = etat.getLibelle();
		} else if (RegularisationManuelleTraitement.CODE_TRANSFERT_ECRIT.equals(transitSystStatRegul.getCodeTransfert())) {
			EtatPublicationDTO etat = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(EtatPublicationDTO.class, EtatPublicationConstantes.AENV);
			libelleEtatPublication = etat.getLibelle();
		} else {
			EtatPublicationDTO etat = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(EtatPublicationDTO.class, EtatPublicationConstantes.ACOMP);
			libelleEtatPublication = etat.getLibelle();
		}
		crOsirisDTO.setLibelleEtatPublication(libelleEtatPublication);

		return crOsirisDTO;
	}
}