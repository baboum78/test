/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.commande.data;

import java.io.Serializable;

import com.soliste.bolbec.livraison.service.model.AdresseDTO;

/**
 * DTO contenant les donn�es d'un acc�s de livraison, en fonction de son type
 * 
 * @author rgvs7490
 */
public class AccesLivraisonDataDTO implements Serializable {

	private int type;
	private String nd;
	private String ndplp;
	private String referenceEtudeNA;
	private AdresseDTO adresse;

	/**
	 * Retourne l'adresse, dans le cas ou le type est CLIENT_TYPE
	 * 
	 * @return l'adresse, dans le cas ou le type est CLIENT_TYPE, ou null
	 */
	public AdresseDTO getAdresse() {
		return this.adresse;
	}

	void setAdresse(AdresseDTO adresse) {
		this.adresse = adresse;
	}

	/**
	 * Retourne le ND, dans le cas ou le type est ND_TYPE
	 * 
	 * @return le ND, dans le cas ou le type est ND_TYPE, ou null
	 */
	public String getNd() {
		return this.nd;
	}

	void setNd(String nd) {
		this.nd = nd;
	}

	/**
	 * Retourne le NDPLP, dans le cas ou le type est NDPLP_TYPE
	 * 
	 * @return le ND, dans le cas ou le type est NDPLP_TYPE, ou null
	 */
	public String getNdplp() {
		return this.ndplp;
	}

	void setNdplp(String ndplp) {
		this.ndplp = ndplp;
	}

	/**
	 * Retourne la r�f�rence d'�tude NA, dans le cas ou le type est ETUDE_NA_TYPE
	 * 
	 * @return la r�f�rence d'�tude NA, dans le cas ou le type est ETUDE_NA_TYPE, ou null
	 */
	public String getReferenceEtudeNA() {
		return this.referenceEtudeNA;
	}

	void setReferenceEtudeNA(String referenceEtudeNA) {
		this.referenceEtudeNA = referenceEtudeNA;
	}

	/**
	 * Retourne le type de l'acc�s de livraison
	 * 
	 * @return le type de l'acc�s de livraison
	 */
	public int getType() {
		return this.type;
	}

	void setType(int type) {
		this.type = type;
	}
}
