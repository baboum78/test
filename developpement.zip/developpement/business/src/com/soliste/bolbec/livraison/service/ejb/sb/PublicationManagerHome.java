package com.soliste.bolbec.livraison.service.ejb.sb;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

public interface PublicationManagerHome extends EJBLocalHome {
	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public PublicationManagerLocal create() throws CreateException;
}
