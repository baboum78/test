/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Les infos d'AVP pour les AVP de type "AVPActivCommut"
 * 
 * @author pqtv8886
 */
public class AvpActivCommutDTO extends AvpInfoDTO {

	private String z0bpq;

	/**
	 * 
	 */
	AvpActivCommutDTO() {
	}

	public String getType() {
		return AVP_EVT_ABSENT;
	}

	/**
	 * Retourne le <code>z0bpq</code>
	 * 
	 * @return le <code>z0bpq</code>
	 */
	public String getZ0bpq() {
		return z0bpq;
	}

	/**
	 * Affecte le <code>z0bpq</code>
	 * 
	 * @param z0bpq le <code>z0bpq</code> � affecter
	 */
	public void setZ0bpq(String z0bpq) {
		this.z0bpq = z0bpq;
	}

}
