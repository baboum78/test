/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * Enum�ration mod�lisant un moment de la journ�e.
 */
public enum MomentInDay {
	LIBRE("L", "MomentInDay.libre"), MATIN("M", "MomentInDay.matin"), APRES_MIDI("A", "MomentInDay.apresMidi");

	private String id;
	private String key;

	private MomentInDay(String id, String key) {
		this.id = id;
		this.key = key;
	}

	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param id
	 * @return moment in day
	 */
	public static MomentInDay getMomentInDay(String id) {
		for (MomentInDay momentInDay : MomentInDay.values()) {
			if (StringUtils.equals(momentInDay.id, id)) {
				return momentInDay;
			}
		}
		return null;
	}
}