/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader;

import java.util.List;

import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.CorbeilleLoadCommand;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.CorbeilleLoaderException;

/**
 * Interface pour l'abstraction du chargement des donn�es corbeille
 * 
 * @author gdzd8490
 * 
 */
public interface CorbeilleLoader {

	/**
	 * Charge l'arbre des crit�res de regroupement par une requ�te sur la base
	 * de donn�es XPM
	 * 
	 * @param selectionFilters
	 * infos � charger
	 * @param dataFilters
	 * filtres
	 * @param user
	 * utilisateur courant
	 * @return une liste de crit�res de regroupements
	 * @throws CorbeilleLoaderException
	 */
	// TODO OLD: virer le user qui ne sert pas au jdbc (adaptor?)
	public List<SynthesisData> loadSynthesisList(List<FieldDTO> selectionFilters, List<FiltreDTO> dataFilters, WfUser user) throws CorbeilleLoaderException;

	/**
	 * Charge l'ensemble de donn�es pour les �lements du groupe. Avec
	 * pagination.
	 * 
	 * @param corbeilleLoadCommand
	 * commande de chargement
	 * @param user
	 * utilisateur courant
	 * @throws CorbeilleLoaderException
	 */
	// TODO OLD: virer le user qui ne sert pas au jdbc (adaptor?)
	public void loadItemList(CorbeilleLoadCommand corbeilleLoadCommand, WfUser user) throws CorbeilleLoaderException;

	/**
	 * Permet d'obtenir une instance de FieldDTOFactory
	 * 
	 * @return une instance de FieldDTOFactory
	 */
	public FieldDTOFactory getFieldFactory();

	/**
	 * Permet d'obtenir une instance de FiltreDTOFactory
	 * 
	 * @return une instance de FiltreDTOFactory
	 */
	public FiltreDTOFactory getFiltreFactory();
}
