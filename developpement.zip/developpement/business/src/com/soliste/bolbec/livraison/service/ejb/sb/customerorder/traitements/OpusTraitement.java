package com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.sw.custorder.ConstantesDeliverCustomerOrder;
import com.soliste.bolbec.livraison.service.sw.custorder.helper.IDeliverCustomerOrderNullHelper;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CouldBeRelatedToTemporarySiteType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CustomerOrderItemType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.FunctionSpecificationType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.LocalSiteExternalIdentifierType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.InstalledProduct;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.ProductSpecification;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.LocalMarketSegment;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace.LocalInstalledResource;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace.LocalInstalledResource.ResourceSpecification;

import aps.CasMetierConstantes;
import aps.EtatInterventionConstantes;
import aps.ResponsabiliteConstantes;
import aps.SystemeExterneConstantes;
import aps.Traduction;
import aps.TypeOpProgrammeeConstantes;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.Intervention;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.OperationProgrammee;
import bolbec.injection.xml.generated.ParametreType;

/**
 * Classe sp�cifique Opus du traitement des IC deliverCustomerOrder
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>29/06/2020</TD><TD>LHZ</TD><TD>US-851 Commande AdslE/DegE provenant de OPUS</TD></TR>
 * <TR><TD>03/08/2021</TD><TD>GBI</TD><TD>US-2964 : Ajustements des filtres pour les cas SU et CR PEPS</TD></TR>
 * </TABLE>
 */
public class OpusTraitement extends CustomerOrderTraitement {

	private static final String VALEUR_PTO = "PTO";
	/**
	 * The Constant CLASS_NAME.
	 */
	private final static String CLASS_NAME = OpusTraitement.class.getName();
	private String prestaClip;

	/**
	 * Constructeur
	 */
	public OpusTraitement(String emetteur) {
		EMETTEUR = emetteur;
	}

	@Override
	protected void controleBooleans() throws DeliverCustomerOrderFault {
		String casMetier = getDeliverCustomerOrderData().getCasMetier();
		if (CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.MO_FTTH.equals(casMetier)) {
			String method = "controleBooleans";
			loggerManager.fine(CLASS_NAME, method, "Controle le Local_InstalledResource pour le cas m�tier " + getDeliverCustomerOrderData().getCasMetier());
			if (Constantes.CST_ACQUISITION.equals(customerOrder.getCustomerOrderType())) {
				CouldBeRelatedToTemporarySiteType couldBeRelated = customerOrder.getCouldBeRelatedToTemporarySite();
				if (couldBeRelated != null) {
					List<SiteType> siteList = couldBeRelated.getSite();
					for (SiteType site : siteList) {
						List<LocalPlace> localPlaceList = site.getLocalPlace();
						for (LocalPlace localPlace : localPlaceList) {
							LocalInstalledResource localInstalledResource = localPlace.getLocalInstalledResource().get(0);
							if (localInstalledResource != null && localInstalledResource.isLocalExistingInstalledResource()) {
								throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampMalFormate(
										"Le champ local_existingInstalledResource n'a pas une valeur permise pour le cas m�tier : " + getDeliverCustomerOrderData().getCasMetier(), customerOrder.getCustomerOrderID());
							}

						}
					}
				}
			}
		}
	}

	@Override
	protected void verifLigneCommande() {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	/**
	 * G�nere l'ano en cas de probl�me sur les lignes de commandes
	 *
	 * @return
	 */
	protected DeliverCustomerOrderFault anoCommandeMalStructuree() {
		loggerManager.finest(CLASS_NAME, "anoCommandeMalStructuree", "G�n�ration d'une anomalie Commande Mal Structur�e.");

		return deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieChampMalFormate("La commande est mal structur�e pour le cas m�tier " + deliverCustomerOrderData.getCasMetier(), customerOrder.getCustomerOrderID());
	}

	@Override
	protected Collection<TraductionDTO> recupereFonctionsOblig() {
		return serviceManager.getReferenceSpaceManager()
				.listInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.FUNCTION_IC_DEGE_OBLIG),
						new Comparaison(Traduction.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, Constantes.CST_OUI),
						new Comparaison(Traduction.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_75B));
	}

	@Override
	protected void controlesSpecifiques() throws DeliverCustomerOrderFault {
		String casMetier = getDeliverCustomerOrderData().getCasMetier();
		String method = "controlesSpecifiques";
		loggerManager.fine(CLASS_NAME, method, "Controles sp�cifiques au cas m�tier " + getDeliverCustomerOrderData().getCasMetier());
		// le test sur CR_FTTH et CR_FTTE est r�alis� dans le xsd
		if (CasMetierConstantes.SU_FTTH_VALEUR_CONSTANTE.equals(casMetier)) {
			for (CustomerOrderItemType custOrderType : customerOrder.getCustomerOrderItem()) {
				if (ConstantesDeliverCustomerOrder.OFFRE_FTH.equals(custOrderType.getOfferSpecification().getOfferSpecificationCode())) {
					if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
						throw anoCommandeMalStructuree();
					}
				}
			}
		}
	}

	@Override
	protected void verifPrestaClipEtDebit(List<Map<String, String>> fonctionsLcTraduites) throws DeliverCustomerOrderFault {
		String method = "verifPrestaClipEtDebit";
		loggerManager.finest(CLASS_NAME, method, "V�rification sur PrestaCLIP et Debit.");
		prestaClip = getKeyInAny(fonctionsLcTraduites, ConstantesDeliverCustomerOrder.PRESTA_CLIP);
		if (StringUtils.isBlank(prestaClip)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.PRESTA_CLIP, customerOrder.getCustomerOrderID());
		}

		loggerManager.finest(CLASS_NAME, method, "Fin de la v�rification sur PrestaCLIP et Debit.");
	}

	@Override
	protected String determineCategorieClientContractant() throws DeliverCustomerOrderFault {
		final String method = "determineCategorieClientContractant";
		final String label = recupererLabelLocalMarketSegmentClientContractant();
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			String casMetier = getDeliverCustomerOrderData().getCasMetier();
			if (CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.MO_FTTH.equals(casMetier)) {
				throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
			}
			return null;
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.SEGMENT_MARCHE, label);
		loggerManager.fine(CLASS_NAME, method, "LocalMarketSegmentLabels traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			return label;
		}
		return traduction;
	}

	@Override
	protected String determineCodeClient() {
		String casMetier = getDeliverCustomerOrderData().getCasMetier();
		if (CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.MO_FTTH.equals(casMetier)) {
			return customerOrder.getCustomerOrderItem().get(getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().getIndexOrganisationName()).getProductOrderItem().get(0).getUser().get(0)
					.getParty().getLocalOrganisationName().getTradingName();
		}
		return customerOrder.getBuyer().getPartyRoleID();
	}

	@Override
	protected Map<String, List<ValeurParametreDTO>> recupererListeOffresElementaires() throws DeliverCustomerOrderFault {
		String method = "recupererListeOffresElementaires";
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration de la liste d'offres elementaires");
		// LinkedHashMap pour conserver l'ordre des param�tres lors de la copie sur les lignes de commandes
		Map<String, List<ValeurParametreDTO>> listeOffresElementaires = new LinkedHashMap<String, List<ValeurParametreDTO>>();
		String offre = null;
		try {
			for (CustomerOrderItemType custOrderType : customerOrder.getCustomerOrderItem()) {
				offre = custOrderType.getOfferSpecification().getOfferSpecificationCode();
				listeOffresElementaires.putAll(serviceManager.getTraductionManager().getTraductionOffreConcatDiff(offre, SystemeExterneConstantes.NUM_75B));
			}
		} catch (AnomalieException ae) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(offre, customerOrder.getCustomerOrderID());
		}
		loggerManager.fine(CLASS_NAME, method, "Nombre d'offre elementaires trouv�es : " + listeOffresElementaires.size());
		return listeOffresElementaires;
	}

	@Override
	protected void valorisationChampDynamiqueOsirisOpPonctuelleOrigine(Collection<LigneCommandeType> lignesDeCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected void fournirIdentifiantLigneDeCommande(Collection<LigneCommandeType> lignesDeCommande, String casMetier) {
		String method = "fournirIdentifiantLigneDeCommande";
		String prefixe = StringUtils.EMPTY;
		if (CasMetierConstantes.DEG_E.equals(casMetier)) {
			prefixe = customerOrder.getCustomerOrderID();
		}
		int i = 0;
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			String suffixe = customerOrder.getCustomerOrderItem().get(i).getCustomerOrderItemID();
			loggerManager.fine(CLASS_NAME, method, "IdLigneCommande cr�e : " + prefixe + suffixe);
			ligneDeCommande.setIdLigneCommande(prefixe + suffixe);
		}
	}

	@Override
	protected void fournirAccesEtTypeLivraison(Collection<LigneCommandeType> lignesDeCommande) {
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return;
		}
		final InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
		String method = "fournirAccesEtTypeLivraison";
		String casMetier = getDeliverCustomerOrderData().getCasMetier();
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			// RG11
			// Cas metier DEG_E
			if (CasMetierConstantes.DEG_E.equals(casMetier)) {
				final ProductSpecification productSpec = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getProductSpecification();
				String functionValue = null;
				if (productSpec != null) {
					for (FunctionSpecificationType functionSpecificationType : productSpec.getFunctionSpecification()) {
						String functionValueSpec = functionSpecificationType.getFunctionSpecificationCode();
						if (ConstantesDeliverCustomerOrder.PRESTA_CLIP.equals(functionValueSpec)) {
							functionValue = functionSpecificationType.getFunctionValueSpecification() != null ? functionSpecificationType.getFunctionValueSpecification().getFunctionValue() : null;
						}
					}
				}
				ligneDeCommande.setAccesLivraisonOrigine(installedProduct != null ? installedProduct.getInstalledProductID() : null);
				if (installedProduct != null && StringUtils.isNotBlank(installedProduct.getInstalledProductID()) && installedProduct.getInstalledProductID().length() == 8) {
					ligneDeCommande.setTypeAccesLivraisonOrigine(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_PRESTACLIP);
				} else {
					ligneDeCommande.setTypeAccesLivraisonOrigine(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_ND);
				}
				ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_PRESTACLIP);
				ligneDeCommande.setAccesLivraison(functionValue);
			// Cas metier FTTH
			} else if (CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.MO_FTTH.equals(casMetier)) {
				loggerManager.fine(CLASS_NAME, method, "Cas metier FTTH, accesLivraison : " + installedProduct + ", typeAccesLivraison : " + ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_FTTH);
				ligneDeCommande.setAccesLivraison(installedProduct != null ? installedProduct.getInstalledProductID() : null);
				ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_FTTH);
			// Cas metier PEPS (Creation)
			} else if (CasMetierConstantes.CR_PEPS.equals(casMetier)) {
				loggerManager.fine(CLASS_NAME, method, "Cas metier PEPS - Creation, accesLivraison : " + prestaClip + ", typeAccesLivraison : " + ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_PRESTACLIP);
				ligneDeCommande.setAccesLivraison(prestaClip);
				ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_PRESTACLIP);
			// Cas metier PEPS (Suppresion)
			} else if (CasMetierConstantes.SU_PEPS.equals(casMetier)) {
				// Si presence du champ installedProduct dans l'IC, on valorise accesLivraison et typeAcces respectivement a l'ID et FTTH
				// Sinon c'est la prestation CLIP (ID et PRESTACLIP)
				String accesLivraison = installedProduct != null ? installedProduct.getInstalledProductID() : prestaClip;
				String typeAccesLivraison = installedProduct != null ? ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_FTTH : ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_PRESTACLIP;

				ligneDeCommande.setTypeAccesLivraison(typeAccesLivraison);
				ligneDeCommande.setAccesLivraison(accesLivraison);
				loggerManager.fine(CLASS_NAME, method, "Cas metier PEPS - Suppression, accesLivraison : " + accesLivraison + ", typeAccesLivraison : " + typeAccesLivraison);
			}
		}
	}

	@Override
	protected String getTraductionCategorieClientLivre() throws DeliverCustomerOrderFault {
		final String methode = "getTraductionCategorieClientLivre";
		final String label = getLocalMarketSegmentLabelClientLivre();
		loggerManager.fine(CLASS_NAME, methode, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
		}
		String traduction = serviceManager.getTraductionManager().getTraductionCatClientInterfVersCatClientLivre(EMETTEUR, label);
		loggerManager.fine(CLASS_NAME, methode, "LocalMarketSegmentLabel traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			traduction = label;
		}
		return traduction;
	}

	@Override
	protected String getLocalMarketSegmentLabelClientLivre() {
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return null;
		}
		final LocalMarketSegment localMarketSegment = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getUser().get(0).getLocalMarketSegment();
		if (localMarketSegment == null) {
			return null;
		}
		return localMarketSegment.getLabel();
	}

	@Override
	protected Collection<ParametreType> creerParametresProduitServiceFunctionLc(int i) {
		final String prefixeParamDet = "ParamDet";
		final String prefixeBVPN = "BVPN_";
		final Collection<ParametreType> resultat = new ArrayList<ParametreType>();

		final List<Map<String, String>> fonctionsOpusLcLst = getDeliverCustomerOrderData().getFonctionsLc();
		String casMetier = getDeliverCustomerOrderData().getCasMetier();
		ParametreType parametreType;
		String cle;
		boolean isPeps = CasMetierConstantes.CR_PEPS.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier());
		boolean isFtthOuPeps = CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.MO_FTTH.equals(casMetier)
				|| isPeps;
		if (fonctionsOpusLcLst.size() > i) {
			for (Entry<String, String> fonctionOpusLc : fonctionsOpusLcLst.get(i).entrySet()) {
				String key = fonctionOpusLc.getKey();
				cle = StringUtils.EMPTY;
				if (ConstantesDeliverCustomerOrder.DEBIT.equals(key)) {
					cle = prefixeParamDet + ConstantesDeliverCustomerOrder.DEBIT_MAJ;
				} else if (ConstantesDeliverCustomerOrder.COLLECTE.equals(key)) {
					if (isPeps) {
						cle = ConstantesDeliverCustomerOrder.COLLECTE_MAJ;
					} else {
						cle = prefixeParamDet + ConstantesDeliverCustomerOrder.COLLECTE_MAJ;
					}
				} else if (ConstantesDeliverCustomerOrder.CLE_REGLETTE.equals(key)) {
					cle = ConstantesDynamicPSSouhaite.PSSOUHAITE_REGLETTE;
				} else if (ConstantesDeliverCustomerOrder.CLE_BROCHE.equals(key)) {
					cle = ConstantesDynamicPSSouhaite.PSSOUHAITE_BROCHE;
				} else if (ConstantesDeliverCustomerOrder.CLE_CODE_REGIME.equals(key)) {
					cle = ConstantesDynamicPSSouhaite.PSSOUHAITE_CODE_REGIME;
				} else if (ConstantesDeliverCustomerOrder.SERVICE.equals(key)) {
					cle = prefixeParamDet + ConstantesDeliverCustomerOrder.SERVICE_MAJ;
				} else if (isFtthOuPeps) {
					cle = prefixeBVPN + key;
				}
				if (!cle.isEmpty()) {
					parametreType = new ParametreType();
					parametreType.setCle(cle);
					parametreType.setValeur(fonctionOpusLc.getValue());
					resultat.add(parametreType);
				}
			}
		}
		if (isFtthOuPeps) {
			CouldBeRelatedToTemporarySiteType couldBeRelatedToTemporarySite = customerOrder.getCouldBeRelatedToTemporarySite();
			if (couldBeRelatedToTemporarySite != null) {
				List<SiteType> listeSite = couldBeRelatedToTemporarySite.getSite();
				if (listeSite != null && !listeSite.isEmpty()) {
					List<LocalPlace> listeLocalPlace = listeSite.get(0).getLocalPlace();
					if (listeLocalPlace != null && !listeLocalPlace.isEmpty()) {
						List<LocalInstalledResource> listeLocalInstalledResource = listeLocalPlace.get(0).getLocalInstalledResource();
						if (listeLocalInstalledResource != null && !listeLocalInstalledResource.isEmpty()) {
							ResourceSpecification resourceSpecification = listeLocalInstalledResource.get(0).getResourceSpecification();
							if (resourceSpecification != null) {
								String specificationCode = resourceSpecification.getSpecificationCode();
								String ptoId = listeLocalInstalledResource.get(0).getInstalledResourceID();
								if (StringUtils.equals(specificationCode, VALEUR_PTO) && StringUtils.isNotBlank(ptoId)) {
									parametreType = new ParametreType();
									parametreType.setCle(ConstantesDynamicPSSouhaite.PTOID);
									parametreType.setValeur(ptoId);
									resultat.add(parametreType);
								}
							}
						}
					}
				}
			}
		}
		return resultat;
	}

	@Override
	protected Collection<ParametreType> creerParametresHorsFunctionSpecification() {
		return new ArrayList<ParametreType>();
	}

	@Override
	protected void fournirInterventionEtParametresAssocies(Commande commande, Collection<LigneCommandeType> lignesDeCommande) {
		// creation d'intervention fictif (avec �tat ARESERV et responsabilit� EXTERIEURE)
		// et opProgramm�, avec le type INTERV_GLOBAL (comme pour FTTH)
		String casMetier = getDeliverCustomerOrderData().getCasMetier();
		if (CasMetierConstantes.CR_PEPS.equals(casMetier) || CasMetierConstantes.SU_PEPS.equals(casMetier)) {
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				String idIntervention = "Fictif_" + prestaClip;
				Intervention intervention = new Intervention();
				intervention.setIdIntervention(idIntervention);
				intervention.setEtatIntervention(EtatInterventionConstantes.ARESERV);
				intervention.setResponsabilite(ResponsabiliteConstantes.INITIATIVE_EXTERIEURE);
				commande.addIntervention(intervention);
				OperationProgrammee operationProgrammee = new OperationProgrammee();
				operationProgrammee.setIdIntervention(idIntervention);
				operationProgrammee.setTypeOp(TypeOpProgrammeeConstantes.CLIENT);
				ligneDeCommande.addOperationProgrammee(operationProgrammee);
			}
		}
	}

	@Override
	protected void valorisationParametresLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		// cr�ation de constante au d�but du fichier afin de faciliter la compr�hension du code par la suite
		boolean  isDegE = CasMetierConstantes.DEG_E.equals(getDeliverCustomerOrderData().getCasMetier());
		boolean isCrPeps = CasMetierConstantes.CR_PEPS.equals(getDeliverCustomerOrderData().getCasMetier());
		boolean isSuPeps = CasMetierConstantes.SU_PEPS.equals(getDeliverCustomerOrderData().getCasMetier());
		// RV20
		// Si le cas m�tier (RG20) est valoris� � � DEG_E � ou � CR_PEPS � ou � SU_PEPS � alors
		if (isDegE || isCrPeps || isSuPeps) {
			String partyRoleId = customerOrder.getBuyer().getPartyRoleID();
			final InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
			boolean installedProductIdRenseigne = installedProduct != null && installedProduct.getInstalledProductID() != null;
			for (LigneCommandeType ligneCommande : lignesCommande) {
				if (partyRoleId != null) {
					ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicCommande.CLE_CODE_FOP, partyRoleId));
				}
				// Si le cas m�tier (RG20) est valoris� � � DEG_E � && Si dans l�IC il existe le param�tre installedProductId renseign�
				if (isDegE && installedProductIdRenseigne) {
					ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON, ConstantesDynamicCommande.PLPHD));
				}
			}
			if (partyRoleId != null) {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_CODE_FOP, partyRoleId);
			}
			if (installedProductIdRenseigne) {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON, ConstantesDynamicCommande.PLPHD);
			} else if (Constantes.CST_ACQUISITION.equals(customerOrder.getCustomerOrderType())) {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.DEG_E_CREATION_PURE, Constantes.CST_OUI_MAJ);
			}

		}
	}

	@Override
	@SuppressWarnings("unused")
	protected void valorisationContexteLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected void valorisationChampsDynamiquesLC(Collection<LigneCommandeType> lignesCommande) {
		if (CasMetierConstantes.DEG_E.equals(getDeliverCustomerOrderData().getCasMetier())) {
			String codeOffre = customerOrder.getCustomerOrderItem().get(0).getOfferSpecification().getOfferSpecificationCode();
			for (LigneCommandeType ligneCommande : lignesCommande) {
				ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OFFRECIBLE, codeOffre));
			}

		} else {
			for (LigneCommandeType ligneCommande : lignesCommande) {
				// Helper
				IDeliverCustomerOrderNullHelper helper = deliverCustomerOrderData.getDeliverCustomerOrderNullHelper();
				// Verification de pr�sence des champs n�cessaires aux traitements
				if (helper.hasCouldBeRelatedToTemporarySite() && helper.hasLocalplace()) {
					// R�cup�ration du site
					SiteType site = getSiteOptimum();
					if (site != null) {
						// R�cup�ration du LocalPlace + subAddress + localSiteExternalIdentifier
						LocalSiteExternalIdentifierType localSiteExternalIdentifier = site.getLocalSiteExternalIdentifier();
						if (localSiteExternalIdentifier != null) {
							// Valorisation des champs dynamiques
							ligneCommande.addParametreLivraison(createParametre(EFBConstantes.IMB, localSiteExternalIdentifier.getExternalID()));
						}
					}
				}
			}
		}

	}

	/**
	 * Permet de r�cup�rer le site qui contient la r�f�rence "Optimum"
	 *
	 * @return le site qui contient la r�f�rence "Optimum"
	 */
	private SiteType getSiteOptimum() {

		List<SiteType> sites = customerOrder.getCouldBeRelatedToTemporarySite().getSite();
		if (sites != null) {
			for (SiteType site : sites) {
				if (site.getLocalSiteExternalIdentifier() != null && OPTIMUM_NAME.equals(site.getLocalSiteExternalIdentifier().getExternalReferentiel().value())) {
					return site;
				}
			}
		}
		return null;
	}

	@Override
	protected String determineDenominationClient() {
		String denomination = StringUtils.EMPTY;
		if (Constantes.CST_ACQUISITION.equals(customerOrder.getCustomerOrderType())) {
			denomination = customerOrder.getCustomerOrderItem().get(getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().getIndexOrganisationName()).getProductOrderItem().get(0).getUser()
					.get(0).getParty().getLocalOrganisationName().getTradingName();
		}
		return denomination;
	}

}