/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.fin;

import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.Arrays;
import java.util.Date;

import javax.xml.bind.DatatypeConverter;

import org.apache.commons.lang3.StringUtils;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ContexteModification;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.InterventionModification;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.Plage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionintervention.data.FinDeclarations;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Injecteur permettant la gestion des messages IOIOE venant de FIN.
 * On met � jour l'intervention en fonction du message re�u.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377: Commandes FTTE - Gestion des IOIOE venant de FIN</TD></TR>
 * </TABLE>
 */
public class InjecteurIOIOEFinMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * Generated Serial Version UID
	 */
	private static final long serialVersionUID = 5851136474206426007L;

	private static final String CLASS_NAME = InjecteurIOIOEFinMessageHandlerBean.class.getName();

	/**
	 * Le XSD correspondant aux messages IOIOE
	 */
	private static final String IOIOE_XSD = "InformOnInterventionOrderEvent.xsd";

	private static final String UC = "UC";
	private static final String IA = "IA";
	private static final String IC = "IC";

	private static final String IT = "IT";

	private static final String BASICAT_FIN = "FIN";

	private static final IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * Gestion du message IOIOE
	 * 
	 * @param message
	 * @throws RemoteException
	 * @throws Exception
	 */
	@Override
	public void processRequest(Serializable message) throws RemoteException, Exception {
		final String method = "processRequest";

		Document doc = getDocument(message);
		Element root = doc.getDocumentElement();

		String localRefStatusCode = getLocalRefStatusCode(root);
		if (Arrays.asList(UC, IA, IC).contains(localRefStatusCode)) {
			String interventionOrderId = getInterventionOrderId(root);

			if (!StringUtils.isBlank(interventionOrderId)) {
				InterventionDTO intervention = serviceManager.getRendezVousManager().findInterventionByRefInterventionAndPlusRecentDatePrise(interventionOrderId);

				if (intervention != null) {
					String statusCode = getStatusCode(root);

					if (!StringUtils.isBlank(statusCode) && !statusCode.equals(intervention.getDynamicInterventions().get(ConstantesDynamicIntervention.INTERVENTION_STATUSCODE))) {
						intervention.getDynamicInterventions().put(ConstantesDynamicIntervention.INTERVENTION_STATUSCODE, statusCode);
						serviceManager.getCommandeManager().updateDynamicIntervention(intervention);
					}

					String interventionDate = getInterventionDate(root);
					String interventionEndDate = getInterventionEndDate(root);
					Date startDate = DatatypeConverter.parseDateTime(interventionDate).getTime();
					Date endDate = DatatypeConverter.parseDateTime(interventionEndDate).getTime();

					if (intervention.getDebutPlage() == null || startDate.compareTo(intervention.getDebutPlage()) != 0) {
						String codeUi = intervention.getDynamicInterventions().get(ConstantesDynamicIntervention.INTERVENTION_UI);
						InterventionModification im = new InterventionModification(intervention.getReference(), intervention.getRefErdv(), "");
						Plage plage = new Plage(codeUi, startDate, endDate);
						ContexteModification contexte = new ContexteModification(BASICAT_FIN, ContexteModification.APPEL_WEBSERVICE_STRING);

						serviceManager.getRendezVousManager().modifierRendezVous(im, plage, intervention.getResponsabilite().getId(), contexte, new AgentDTO("Artemis"));
					}
				} else {
					serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Intervention " + interventionOrderId + " non trouv�e");
				}
			}
		} else if (IT.equals(localRefStatusCode)) {
			// CRI : Appel du traitement g�n�rique pour mettre fin � l'attente de
			// la r�ponse et ainsi poursuivre la livraison
			super.processRequest(message);
		}
	}

	/**
	 * M�thode permettant de r�cup�rer la valeur du champ interventionOrderID
	 * 
	 * @param root
	 * @return la valeur du champ interventionOrderID
	 */
	private String getInterventionOrderId(Element root) {
		final String method = "getInterventionOrderId";

		NodeList nodeListIo = root.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ORDER);
		if (nodeListIo.getLength() >= 1) {
			Element nodeIo = (Element) nodeListIo.item(0);
			NodeList nodeListIoi = nodeIo.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ORDER_ID);
			if (nodeListIoi.getLength() == 1) {
				Element nodeIoi = (Element) nodeListIoi.item(0);
				if (nodeIoi.getFirstChild() != null) {
					return nodeIoi.getFirstChild().getNodeValue();
				}
			}
		}

		serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Message invalide : champ " + FinDeclarations.TAG_INTERVENTION_ORDER_ID + " non trouv�");
		return null;
	}

	/**
	 * M�thode permettant de r�cup�rer la valeur du champ interventionID
	 * 
	 * @param root
	 * @return la valeur du champ interventionID
	 */
	private String getInterventionId(Element root) {
		final String method = "getInterventionId";

		NodeList nodeListIo = root.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ORDER);
		if (nodeListIo.getLength() >= 1) {
			Element nodeIo = (Element) nodeListIo.item(0);
			NodeList nodeListI = nodeIo.getElementsByTagName(FinDeclarations.TAG_INTERVENTION);
			if (nodeListI.getLength() >= 1) {
				Element nodeI = (Element) nodeListI.item(0);
				NodeList nodeListIi = nodeI.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ID);
				if (nodeListIi.getLength() == 1) {
					Element nodeIi = (Element) nodeListIi.item(0);
					if (nodeIi.getFirstChild() != null) {
						return nodeIi.getFirstChild().getNodeValue();
					}
				}
			}
		}

		serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Message invalide : champ " + FinDeclarations.TAG_INTERVENTION_ID + " non trouv�");
		return null;
	}

	/**
	 * M�thode permettant de r�cup�rer la valeur du champ interventionDate
	 * 
	 * @param root
	 * @return la valeur du champ interventionDate
	 */
	private String getInterventionDate(Element root) {
		final String method = "getInterventionDate";

		NodeList nodeListIo = root.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ORDER);
		if (nodeListIo.getLength() >= 1) {
			Element nodeIo = (Element) nodeListIo.item(0);
			NodeList nodeListI = nodeIo.getElementsByTagName(FinDeclarations.TAG_INTERVENTION);
			if (nodeListI.getLength() >= 1) {
				Element nodeI = (Element) nodeListI.item(0);
				NodeList nodeListId = nodeI.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_DATE);
				if (nodeListId.getLength() == 1) {
					Element nodeId = (Element) nodeListId.item(0);
					if (nodeId.getFirstChild() != null) {
						return nodeId.getFirstChild().getNodeValue();
					}
				}
			}
		}

		serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Message invalide : champ " + FinDeclarations.TAG_INTERVENTION_DATE + " non trouv�");
		return null;
	}

	/**
	 * M�thode permettant de r�cup�rer la valeur du champ interventionEndDate
	 * 
	 * @param root
	 * @return la valeur du champ interventionEndDate
	 */
	private String getInterventionEndDate(Element root) {
		final String method = "getInterventionEndDate";

		NodeList nodeListIo = root.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ORDER);
		if (nodeListIo.getLength() >= 1) {
			Element nodeIo = (Element) nodeListIo.item(0);
			NodeList nodeListI = nodeIo.getElementsByTagName(FinDeclarations.TAG_INTERVENTION);
			if (nodeListI.getLength() >= 1) {
				Element nodeI = (Element) nodeListI.item(0);
				NodeList nodeListIed = nodeI.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_END_DATE);
				if (nodeListIed.getLength() == 1) {
					Element nodeIed = (Element) nodeListIed.item(0);
					if (nodeIed.getFirstChild() != null) {
						return nodeIed.getFirstChild().getNodeValue();
					}
				}
			}
		}

		serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Message invalide : champ " + FinDeclarations.TAG_INTERVENTION_END_DATE + " non trouv�");
		return null;
	}

	/**
	 * M�thode permettant de r�cup�rer la valeur du champ statusCode
	 * 
	 * @param root
	 * @return la valeur du champ statusCode
	 */
	private String getStatusCode(Element root) {
		final String method = "getStatusCode";

		NodeList nodeListIo = root.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ORDER);
		if (nodeListIo.getLength() >= 1) {
			Element nodeIo = (Element) nodeListIo.item(0);
			NodeList nodeListI = nodeIo.getElementsByTagName(FinDeclarations.TAG_INTERVENTION);
			if (nodeListI.getLength() >= 1) {
				Element nodeI = (Element) nodeListI.item(0);
				NodeList nodeListIs = nodeI.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_STATUS);
				if (nodeListIs.getLength() == 1) {
					Element nodeIs = (Element) nodeListIs.item(0);
					NodeList nodeListSc = nodeIs.getElementsByTagName(FinDeclarations.TAG_STATUS_CODE);
					if (nodeListSc.getLength() == 1) {
						Element nodeSc = (Element) nodeListSc.item(0);
						if (nodeSc.getFirstChild() != null) {
							return nodeSc.getFirstChild().getNodeValue();
						}
					}
				}
			}
		}

		serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Message invalide : champ " + FinDeclarations.TAG_STATUS_CODE + " non trouv�");
		return null;
	}

	/**
	 * M�thode permettant de r�cup�rer la valeur du champ local_RefStatusCode
	 * 
	 * @param root
	 * @return la valeur du champ local_RefStatusCode
	 */
	private String getLocalRefStatusCode(Element root) {
		final String method = "getLocalRefStatusCode";

		NodeList nodeListIo = root.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_ORDER);
		if (nodeListIo.getLength() >= 1) {
			Element nodeIo = (Element) nodeListIo.item(0);
			NodeList nodeListI = nodeIo.getElementsByTagName(FinDeclarations.TAG_INTERVENTION);
			if (nodeListI.getLength() >= 1) {
				Element nodeI = (Element) nodeListI.item(0);
				NodeList nodeListIs = nodeI.getElementsByTagName(FinDeclarations.TAG_INTERVENTION_STATUS);
				if (nodeListIs.getLength() == 1) {
					Element nodeIs = (Element) nodeListIs.item(0);
					NodeList nodeListLrsc = nodeIs.getElementsByTagName(FinDeclarations.TAG_LOCAL_REF_STATUS_CODE);
					if (nodeListLrsc.getLength() == 1) {
						Element nodeLrsc = (Element) nodeListLrsc.item(0);
						if (nodeLrsc.getFirstChild() != null) {
							return nodeLrsc.getFirstChild().getNodeValue();
						}
					}
				}
			}
		}

		serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Message invalide : champ " + FinDeclarations.TAG_LOCAL_REF_STATUS_CODE + " non trouv�");
		return null;
	}

	/**
	 * M�thode pour r�cup�rer un Document XML � partir du message XML
	 * 
	 * @param message
	 * @return Docuemnt
	 * @throws InvalidMessageException
	 */
	private Document getDocument(Serializable message) throws InvalidMessageException {
		Document doc;

		try {
			doc = XmlUtils.getDocument((String) message, InjecteurIOIOEFinMessageHandlerBean.class.getResource(IOIOE_XSD).getFile());
		} catch (IOException ioe) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + ioe.getMessage(), message, ioe);
		} catch (SAXException saxe) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + saxe.getMessage(), message, saxe);
		}

		return doc;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	@Override
	public ActivationParam getActivationParam(Serializable message) throws InvalidMessageException {
		final String method = "getActivationParam";

		// On r�cup�re la r�f�rence de l'intervention pour r�cup�rer la commande li�e pour g�rer le CR et poursuivre la livraison
		Document doc = getDocument(message);
		Element root = doc.getDocumentElement();

		String interventionOrderId = getInterventionOrderId(root);
		if (!StringUtils.isBlank(interventionOrderId)) {
			InterventionDTO intervention = serviceManager.getRendezVousManager().findInterventionByRefInterventionAndPlusRecentDatePrise(interventionOrderId);

			if (intervention != null) {
				LigneCommandeDTO ligneCommande = CollectionUtils.getFirstOrNull(serviceManager.getCommandeManager().findLigneCommandeByIntervention(intervention.getId()));

				if (ligneCommande != null) {
					CommandeDTO commande = serviceManager.getCommandeManager().getCommande(ligneCommande.getIdCommande());
					TacheEnCoursDTO tacheEnCours = CollectionUtils.getFirstOrNull(serviceManager.getProcessusManager().findTacheEnCoursByCommande(commande.getId()));
					if (tacheEnCours != null) {
						// L'id requ�te est de la forme LY_G9R2_ln1020162 (CritereLocalisation_VersionCmde_IdProcessus)
						String idRequete = ligneCommande.getInstanceLocalisation().getId() + "_" + commande.getVersionArtemis() + "_" + tacheEnCours.getIdProcess();
						return new ActivationParam("Intervention", idRequete);
					}

					serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Aucune t�che en cours trouv�e pour la commande " + commande.getId());
				} else {
					serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Aucune ligne de commande trouv�e pour l'intervention d'id " + intervention.getId());
				}
			} else {
				serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Intervention " + interventionOrderId + " non trouv�e");
			}
		} else {
			serviceManager.getLoggerManager().warning(CLASS_NAME, method, "Erreur lors de la r�cup�ration du champ interventionOrderId");
		}

		return null;
		// throw new InvalidMessageException("Message invalide");
	}
}