/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;
import java.util.List;

import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;

import com.google.common.base.Strings;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs Maj Parc Materiel
 * 
 * @author dxll7528
 */
public class CloturerAvpCorrectionAdresseCommande extends CloturerAvpCommande {

	private String libelleVoie;
	private String codeRivoli;
	private String numeroVoie;
	private String ensemble;
	private String batiment;
	private String escalier;
	private String etage;
	private String porte;
	private String logo;
	private String codeInsee;
	private String ndplp;
	private final int NB_PARAM = 11;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param libelleVoie
	 * @param codeRivoli
	 * @param numeroVoie
	 * @param ensemble
	 * @param batiment
	 * @param escalier
	 * @param etage
	 * @param porte
	 * @param logo
	 * @param codeInsee
	 */
	public CloturerAvpCorrectionAdresseCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String libelleVoie, String codeRivoli, String numeroVoie, String ensemble, String batiment, String escalier,
			String etage, String porte, String logo, String codeInsee) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.libelleVoie = libelleVoie;
		this.codeRivoli = codeRivoli;
		this.numeroVoie = numeroVoie;
		this.ensemble = ensemble;
		this.batiment = batiment;
		this.escalier = escalier;
		this.etage = etage;
		this.porte = porte;
		this.logo = logo;
		this.codeInsee = codeInsee;
	}

	public CloturerAvpCorrectionAdresseCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String libelleVoie, String codeRivoli, String numeroVoie, String ensemble, String batiment, String escalier,
			String etage, String porte, String logo, String codeInsee, String ndplp) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.libelleVoie = libelleVoie;
		this.codeRivoli = codeRivoli;
		this.numeroVoie = numeroVoie;
		this.ensemble = ensemble;
		this.batiment = batiment;
		this.escalier = escalier;
		this.etage = etage;
		this.porte = porte;
		this.logo = logo;
		this.codeInsee = codeInsee;
		this.ndplp = ndplp;
	}

	public CloturerAvpCorrectionAdresseCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData) {
		super(tacheId, info, causeEvenementId, date, itemData);
	}

	public String getBatiment() {
		return batiment;
	}

	public String getEnsemble() {
		return ensemble;
	}

	public String getEscalier() {
		return escalier;
	}

	public String getEtage() {
		return etage;
	}

	public String getLibelleVoie() {
		return libelleVoie;
	}

	public String getLogo() {
		return logo;
	}

	public String getPorte() {
		return porte;
	}

	public String getCodeInsee() {
		return codeInsee;
	}

	public String getCodeRivoli() {
		return codeRivoli;
	}

	public String getNumeroVoie() {
		return numeroVoie;
	}

	public String getNdplp() {
		return ndplp;
	}

	public void setLibelleVoie(String libelleVoie) {
		this.libelleVoie = libelleVoie;
	}

	public void setCodeRivoli(String codeRivoli) {
		this.codeRivoli = codeRivoli;
	}

	public void setNumeroVoie(String numeroVoie) {
		this.numeroVoie = numeroVoie;
	}

	public void setEnsemble(String ensemble) {
		this.ensemble = ensemble;
	}

	public void setBatiment(String batiment) {
		this.batiment = batiment;
	}

	public void setEscalier(String escalier) {
		this.escalier = escalier;
	}

	public void setEtage(String etage) {
		this.etage = etage;
	}

	public void setPorte(String porte) {
		this.porte = porte;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public void setCodeInsee(String codeInsee) {
		this.codeInsee = codeInsee;
	}

	public void setNdplp(String ndplp) {
		this.ndplp = ndplp;
	}

	public void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande){

		int cpt = 0;

		for (LigneCommandeDTO commandePrecedente : listeLigneCommande) {
			AdresseDTO adresseDTO = commandePrecedente.getClient().getAdresse();

			if(this.getCodeRivoli() == null && adresseDTO.getCodeRivoli() != null){
				this.setCodeRivoli(adresseDTO.getCodeRivoli());
				cpt++;
			}
			if(this.getNumeroVoie() == null && adresseDTO.getNumeroVoie() != null){
				this.setNumeroVoie(adresseDTO.getNumeroVoie());
				cpt++;
			}
			if(this.getEnsemble() == null && adresseDTO.getEnsemble() != null){
				this.setEnsemble(adresseDTO.getEnsemble());
				cpt++;
			}
			if(this.getBatiment() == null && adresseDTO.getBatiment() != null){
				this.setBatiment(adresseDTO.getBatiment());
				cpt++;
			}
			if(this.getEscalier() == null && adresseDTO.getEscalier() != null){
				this.setEscalier(adresseDTO.getEscalier());
				cpt++;
			}
			if(this.getEtage() == null && adresseDTO.getEtage() != null){
				this.setEtage(adresseDTO.getEtage());
				cpt++;
			}
			if(this.getPorte() == null && adresseDTO.getPorte() != null){
				this.setPorte(adresseDTO.getPorte());
				cpt++;
			}
			if(this.getLogo() == null && adresseDTO.getLogo() != null){
				this.setLogo(adresseDTO.getLogo());
				cpt++;
			}
			if(this.getCodeInsee() == null && adresseDTO.getCodeInsee() != null){
				this.setCodeInsee(adresseDTO.getCodeInsee());
				cpt++;
			}
			if(this.getNdplp() == null && commandePrecedente.getLigneCmdCatalogue().getInstanceOg().getEpCommercial().getNdplp() != null){
				this.setNdplp(commandePrecedente.getLigneCmdCatalogue().getInstanceOg().getEpCommercial().getNdplp());
				cpt++;
			}
			if(cpt >= NB_PARAM){
				break;
			}
		}

		if(dataToSet != null){
			if(dataToSet.getCodeRivoli() != null){
				setCodeRivoli(dataToSet.getCodeRivoli());
			}
			if(dataToSet.getNumVoie() != null){
				setNumeroVoie(dataToSet.getNumVoie());
			}
			if(dataToSet.getEns() != null){
				setEnsemble(dataToSet.getEns());
			}
			if(dataToSet.getBatiment() != null){
				setBatiment(dataToSet.getBatiment());
			}
			if(dataToSet.getEscalier() != null){
				setEscalier(dataToSet.getEscalier());
			}
			if(dataToSet.getEtage() != null){
				setEtage(dataToSet.getEtage());
			}
			if(dataToSet.getPorte() != null){
				setPorte(dataToSet.getPorte());
			}
			if(dataToSet.getLogo() != null){
				setLogo(dataToSet.getLogo());
			}
			if(dataToSet.getCodeInsee() != null){
				setCodeInsee(dataToSet.getCodeInsee());
			}
			if(dataToSet.getNdplp() != null){
				setNdplp(dataToSet.getNdplp());
			}
		}

	}
}
