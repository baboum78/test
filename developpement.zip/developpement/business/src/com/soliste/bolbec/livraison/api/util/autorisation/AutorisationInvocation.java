package com.soliste.bolbec.livraison.api.util.autorisation;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.cxf.jaxrs.ext.MessageContext;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;

import com.soliste.bolbec.commun.service.api.exception.APIException;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Classe permettant de g�rer l'autorisation de l'API Rest
 * chaque service est intercept� et la m�thode gererAutorisation
 * l'englobe.
 * 
 * @author bperrard
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>29/10/2015</TD><TD>BPE</TD><TD>EV-000353 : Mise en place archi Rest de Base</TD></TR>
 * <TR><TD>25/01/2016</TD><TD>KWE</TD><TD>EV-000353 : Modifications exceptions</TD></TR>
 * </TABLE>
 */
@Aspect
public class AutorisationInvocation {

	private final IServiceManager serviceManager = ServiceManager.getInstance();
	private final ILoggerManager loggerManager = serviceManager.getLoggerManager();
	private final String className = getClass().getSimpleName();

	private final AutorisationUtil autorisationUtil;

	public AutorisationInvocation(final AutorisationUtil autorisationUtil) {
		this.autorisationUtil = autorisationUtil;
	}

	/**
	 * Intercepteur g�rant l'API rest, en ce qui concerne l'authentification, l'autorisation
	 * et la gestion des exceptions
	 * 
	 * @param joinPoint
	 * @return
	 * @throws Throwable
	 */
	@Around("execution(* com.soliste.bolbec.livraison.api.v*.ressource.*RessourceImpl.*(..))")
	public Object gererAutorisation(ProceedingJoinPoint joinPoint) throws Throwable {
		final String nomMethode = "gererAutorisation";
		final MethodSignature methodeSignature = (MethodSignature) joinPoint.getSignature();
		final Method methode = methodeSignature.getMethod();
		final Habilitation habilitation = methode.getAnnotation(Habilitation.class);

		// 1) authentification : pas d'agent pas d'acc�s
		// =============================================

		// On r�cup�re le context de la m�thode
		MessageContext messageContext = null;

		for (Object arg : joinPoint.getArgs()) {
			if (arg instanceof MessageContext) {
				messageContext = (MessageContext) arg;
				break;
			}
		}

		// Le messageContext est null dans le cas o� il a �t� omis dans la liste des param�tres de la m�thode --> Forbidden
		if (messageContext == null) {
			loggerManager.warning(className, nomMethode, String.format("Ressource inaccessible : le messageContext est manquant dans la liste des param�tres pour la m�thode %s", methodeSignature.getName()));
			return APIExceptionEnum.unauthorized.createAPIException().getReponse();
		}

		// identification de l'agent
		final AgentDTO agent = autorisationUtil.getCurrentAgentFromMessageContext(messageContext);

		// Pas d'agent --> Forbidden
		if (agent == null) {
			return APIExceptionEnum.unauthorized.createAPIException().getReponse();
		}

		// 2) autorisation : on regarde si l'agent poss�de les habilitations n�cessaires
		// =============================================================================

		// Si aucune autorisation valable, la methode est accessible par tout le monde
		if (habilitation == null) {
			return appelerRessource(joinPoint);
		}

		// R�cup�ration des habilitations n�cessaires pour utiliser la ressource
		final Set<String> habilitationsNecessaires = new HashSet<String>(Arrays.asList(habilitation.value()));

		// Si la liste d'habilitations n�cessaires est vide --> Forbidden
		if (habilitationsNecessaires.isEmpty()) {
			return Response.status(Status.FORBIDDEN).build();
		}

		// Si l'agent n'est pas habilit� --> Forbidden
		if (!autorisationUtil.isHabilitated(habilitationsNecessaires, agent)) {
			return Response.status(Status.FORBIDDEN).build();
		}

		return appelerRessource(joinPoint);
	}

	/**
	 * Appelle la m�thode de la ressource.
	 * Les exceptions sont r�cup�r�s/trac�s, puis un code erreur est transmis
	 * 
	 * @param joinPoint
	 * @return
	 * @throws Throwable
	 */
	private Object appelerRessource(final ProceedingJoinPoint joinPoint) throws Throwable {
		try {
			return joinPoint.proceed();
		} catch (APIException apiException) {
			loggerManager.info(joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(), "apiException : ", apiException);
			return apiException.getReponse();
		} catch (Exception e) {
			loggerManager.warning(joinPoint.getSignature().getDeclaringTypeName(), joinPoint.getSignature().getName(), "Erreur interne.", e);
			return APIExceptionEnum.generic500.createAPIException().getReponse();
		}
	}

}
