/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.ArrayList;
import java.util.List;

import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * </TABLE><BR>
 */

/**
 * Factory pour SousProcessusDTO
 * 
 * @author rgvs7490
 */
public class SousProcessusDTOFactory {

	private SousProcessusDTOFactory() {
	}

	/**
	 * 
	 * @param sp
	 * @return
	 */
	public static SousProcessusDTO create(ProcessusDTO sp) {
		SousProcessusDTO dto = new SousProcessusDTO();

		ProcessusTypeDTO procTypeComplet = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, sp.getProcessusType().getId());
		sp.setProcessusType(procTypeComplet);
		dto.setSousProcessus(sp);
		TacheDTO phase = getPhaseFromTache(sp.getAppelleParTacheId());
		dto.setPhase(phase);
		dto.setPapaProcessus(phase.getLancerParProcessus());

		List<TacheDTO> taches = new ArrayList<TacheDTO>();
		List<TacheDTO> tachesDuProcessus = ServiceManager.getInstance().getProcessusManager().findTacheByLanceParProcessus(sp.getId());
		for (TacheDTO tache : tachesDuProcessus) {
			chargerRoleEtAgentComplets(tache);
			taches.add(tache);
		}
		dto.setTaches(taches);

		return dto;
	}

	/**
	 * 
	 * @param tacheId
	 * @return
	 */
	public static TacheDTO getPhaseFromTache(String tacheId) {
		TacheDTO tache = ServiceManager.getInstance().getProcessusManager().getTache(tacheId);
		ProcessusDTO papaProcessus = tache.getLancerParProcessus();
		List<TacheDTO> taches = ServiceManager.getInstance().getProcessusManager().findTacheByLanceParProcessus(papaProcessus.getId());
		for (TacheDTO phase : taches) {
			if (phase.getLibelle().equals(tache.getLibelle())) {
				return phase;
			}
		}
		return null;
	}

	private static void chargerRoleEtAgentComplets(TacheDTO tache) {
		RoleDTO roleComplet = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RoleDTO.class, tache.getFaitParRole().getId());
		tache.setFaitParRole(roleComplet);
		AgentDTO agentComplet = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AgentDTO.class, tache.getRealiseeParAgent().getId());
		tache.setRealiseeParAgent(agentComplet);
	}
}
