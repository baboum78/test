/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

/**
 *  $Workfile:   IC_42C.java  $
 *  $Revision:   1.0  $
 *  $Date:   Feb 20 2004 16:08:40  $
 *  $Log:   W:/00_PVCS_BOLBECG4/archives/developpement/uc_adaptateurs/src.ejb/bolbec/adaptateur/ic42c/IC_42C.java-arc  $
 * 
 *    Rev 1.0   Feb 20 2004 16:08:40   EROY
 * Initial revision.
 * 
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c;

/**
 * <BR><B>HISTORIQUE</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/06/2010</TD><TD>DBA</TD><TD>EV-000072: Nouveau constructeur par d�faut </TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE>
 * 
 * @author dBaret
 * 
 */
public class IC_42C {

	/**
	 * D�finition des donn�es de l'intention de commande 42C
	 */
	private String typeCommande;
	private String datePublication;
	private String dateEvt;
	private String ancienNd;
	private String nouveauNd;
	private String ancienNom;
	private String nouveauNom;
	private String offre;
	private String prestation;
	private String codeProvider;
	private String renvoiRepartiteur;
	private String motifResil;
	private String segmentMarche;
	private String edsInstallation;
	private String centreRattachement;
	private String operateur;

	/**
	 * <BR><B>HISTORIQUE</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/06/2010</TD><TD>DBA</TD><TD>EV-000072: Constructeur par d�faut</TD></TR>
	 * </TABLE>
	 */
	public IC_42C() {

	}

	/**
	 * 
	 * @param a_typeCommande
	 * @param a_datePublication
	 * @param a_dateEvt
	 * @param a_ancienNd
	 * @param a_nouveauNd
	 * @param a_ancienNom
	 * @param a_nouveauNom
	 * @param a_offre
	 * @param a_prestation
	 * @param a_codeProvider
	 * @param a_renvoiRepartiteur
	 * @param a_motifResil
	 * @param a_segmentMarche
	 * @param a_edsInstallation
	 * @param a_centreRattachement
	 * @param a_operateur
	 */
	public IC_42C(String a_typeCommande, String a_datePublication, String a_dateEvt, String a_ancienNd, String a_nouveauNd, String a_ancienNom, String a_nouveauNom, String a_offre, String a_prestation, String a_codeProvider, String a_renvoiRepartiteur,
			String a_motifResil, String a_segmentMarche, String a_edsInstallation, String a_centreRattachement, String a_operateur) {
		// initialisation des donn�es de l'intention de commande 42C
		typeCommande = a_typeCommande;
		datePublication = a_datePublication;
		dateEvt = a_dateEvt;
		ancienNd = a_ancienNd;
		nouveauNd = a_nouveauNd;
		ancienNom = a_ancienNom;
		nouveauNom = a_nouveauNom;
		offre = a_offre;
		prestation = a_prestation;
		codeProvider = a_codeProvider;
		renvoiRepartiteur = a_renvoiRepartiteur;
		motifResil = a_motifResil;
		segmentMarche = a_segmentMarche;
		edsInstallation = a_edsInstallation;
		centreRattachement = a_centreRattachement;
		operateur = a_operateur;
	}

	/************************************************************************
	 * getters et setters pour les donn�es de l'intention de commande 42C *
	 ************************************************************************/
	public String getTypeCommande() {
		return typeCommande;
	}

	public void setTypeCommande(String a_typeCommande) {
		typeCommande = a_typeCommande;
	}

	public String getDatePublication() {
		return datePublication;
	}

	public void setDatePublication(String a_datePublication) {
		datePublication = a_datePublication;
	}

	public String getDateEvt() {
		return dateEvt;
	}

	public void setDateEvt(String a_dateEvt) {
		dateEvt = a_dateEvt;
	}

	public String getAncienNd() {
		return ancienNd;
	}

	public void setAncienNd(String a_ancienNd) {
		ancienNd = a_ancienNd;
	}

	public String getNouveauNd() {
		return nouveauNd;
	}

	public void setNouveauNd(String a_nouveauNd) {
		nouveauNd = a_nouveauNd;
	}

	public String getAncienNom() {
		return ancienNom;
	}

	public void setAncienNom(String a_ancienNom) {
		ancienNom = a_ancienNom;
	}

	public String getNouveauNom() {
		return nouveauNom;
	}

	public void setNouveauNom(String a_nouveauNom) {
		nouveauNom = a_nouveauNom;
	}

	public String getOffre() {
		return offre;
	}

	public void setOffre(String a_offre) {
		offre = a_offre;
	}

	public String getPrestation() {
		return prestation;
	}

	public void setPrestation(String a_prestation) {
		prestation = a_prestation;
	}

	public String getCodeProvider() {
		return codeProvider;
	}

	public void setCodeProvider(String a_codeProvider) {
		codeProvider = a_codeProvider;
	}

	public String getRenvoiRepartiteur() {
		return renvoiRepartiteur;
	}

	public void setRenvoiRepartiteur(String a_renvoiRepartiteur) {
		renvoiRepartiteur = a_renvoiRepartiteur;
	}

	public String getMotifResil() {
		return motifResil;
	}

	public void setMotifResil(String a_motifResil) {
		motifResil = a_motifResil;
	}

	public String getSegmentMarche() {
		return segmentMarche;
	}

	public void setSegmentMarche(String a_segmentMarche) {
		segmentMarche = a_segmentMarche;
	}

	public String getEdsInstallation() {
		return edsInstallation;
	}

	public void setEdsInstallation(String a_edsInstallation) {
		edsInstallation = a_edsInstallation;
	}

	public String getCentreRattachement() {
		return centreRattachement;
	}

	public void setCentreRattachement(String a_centreRattachement) {
		centreRattachement = a_centreRattachement;
	}

	public String getOperateur() {
		return operateur;
	}

	public void setOperateur(String a_operateur) {
		operateur = a_operateur;
	}
}
