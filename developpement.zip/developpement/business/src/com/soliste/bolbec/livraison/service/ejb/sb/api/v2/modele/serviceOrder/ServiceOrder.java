package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * Modele Ressource ServiceOrder
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/10/2016</TD><TD>JDE</TD><TD>Cr�ation de la ressource CustomerRef et AddressRef</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "serviceOrder")
public class ServiceOrder extends com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.ServiceOrder {

	private CustomerRef contractorCustomer;
	private CustomerRef deliveredCustomer;

	public ServiceOrder() {

	}

	/**
	 * Construction de l'objet � partir de la V1
	 * 
	 * @param serviceOrderV1
	 */
	public ServiceOrder(com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.ServiceOrder serviceOrderV1) {
		this.setAbortEventCause(serviceOrderV1.getAbortEventCause());
		this.setAppointmentRef(serviceOrderV1.getAppointmentRef());
		this.setExternalId(serviceOrderV1.getExternalId());
		this.setId(serviceOrderV1.getId());
		this.setJobCase(serviceOrderV1.getJobCase());
		this.setNotesList(serviceOrderV1.getNotesList());
		this.setOrderItemsList(serviceOrderV1.getOrderItemsList());
		this.setState(serviceOrderV1.getState());
		if (serviceOrderV1.getTaskRef() != null) {
			this.setTaskRefId(serviceOrderV1.getTaskRef().getId());
		}
	}

	/**
	 * 
	 * @return the contractorCustomer
	 */
	public CustomerRef getContractorCustomer() {
		return contractorCustomer;
	}

	/**
	 * @param contractorCustomer the contractorCustomer to set
	 */
	public void setContractorCustomer(CustomerRef contractorCustomer) {
		this.contractorCustomer = contractorCustomer;
	}

	/**
	 * @return the deliveredCustomer
	 */
	public CustomerRef getDeliveredCustomer() {
		return deliveredCustomer;
	}

	/**
	 * @param deliveredCustomer the deliveredCustomer to set
	 */
	public void setDeliveredCustomer(CustomerRef deliveredCustomer) {
		this.deliveredCustomer = deliveredCustomer;
	}

}
