package com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Queue;

import org.apache.commons.lang3.StringUtils;
import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.model.DescGroupeOffresDTO;
import com.soliste.bolbec.livraison.service.model.DescOffreGroupeeDTO;
import com.soliste.bolbec.livraison.service.model.InputDynamicCommandeDTO;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicEPCommercial;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.sw.custorder.ConstantesDeliverCustomerOrder;
import com.soliste.bolbec.livraison.service.sw.custorder.DeliverCustomerOrderDataIOSW;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.AddressType.City;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.AddressType.Street;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.AddressType.Street.StreetCode;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.BuyerType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CouldUseTemporaryContactMethodType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.CustomerOrderItemType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.DeliverCustomerOrderRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.FunctionSpecificationType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.FunctionSpecificationType.FunctionValueSpecification;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.PartyRoleType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.Party;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.Party.LocalOrganisationName;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.User.Party.LocalPersonName;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType.LocalPlace.SubAddress;
import com.orange.bolbec.customerOrderIOSW.types.fault.CustomerOrderFault;

import aps.CasMetierConstantes;
import aps.DescGroupeOffres;
import aps.DescOffreGroupee;
import aps.SystemeExterneConstantes;
import aps.TypeOpPonctuellesConstantes;
import bolbec.injection.xml.generated.Adresse;
import bolbec.injection.xml.generated.ClientContractant;
import bolbec.injection.xml.generated.ClientLivre;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.Contact;
import bolbec.injection.xml.generated.ElementParcAffecte;
import bolbec.injection.xml.generated.InstanceOffreGroupee;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.Message;
import bolbec.injection.xml.generated.ParametreType;
import bolbec.injection.xml.generated.ProduitServiceSouhaite;

/**
 * Classe de base du traitement des IC deliverCustomerOrder
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>16/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Cr�ation de la classe</TD></TR>
 * <TR><TD>22/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Fin du Dev</TD></TR>
 * <TR><TD>24/01/2013</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210: Corrections suite � test d'int�gration</TD></TR>
 * <TR><TD>20/06/2013</TD><TD>EBA</TD><TD>G8R2C2 - Mise en place Sonar : suppression des accents dans noms de methodes</TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * <TR><TD>05/09/2013</TD><TD>BPE</TD><TD>DE-000936 "NullPointerException lors d'une injection d'une IC vers CustomerOrderServiceIOSW"</TD></TR>
 * <TR><TD>30/08/2013</TD><TD>VDE</TD><TD>EV-000250 "Process Vente-R�siliation automatis�e" </TD></TR>
 * <TR><TD>05/09/2013</TD><TD>BPE</TD><TD>G8R2C3 : DE-000950 "Resil Vente FTTH : ndfinder renseign� avec VIA tronqu�"</TD></TR>
 * <TR><TD>30/10/2013</TD><TD>VDE</TD><TD>EV-000227 "Mutation en masse DSLAM"</TD></TR>
 * <TR><TD>24/01/2014</TD><TD>VDE</TD><TD>DE-000990 "Mutation en masse DSLAM"</TD></TR>
 * <TR><TD>21/03/2014</TD><TD>BPE</TD><TD>G8R2C4 DE-001045 "FunctionValue obligatoire � tort sur Mutation DSLAM"</TD></TR>
 * <TR><TD>31/10/2014</TD><TD>KRA</TD><TD>EV-000302_03 : PLP Fibre</TD></TR>
 * <TR><TD>10/12/2014</TD><TD>KRA</TD><TD>EV-000320 : G8R2C6 - Effet de bord quarantaine</TD></TR>
 * <TR><TD>26/05/2015</TD><TD>JDE</TD><TD>EV-000315 : G8R2C7 - Commandes Bacara Salto (SCE)</TD></TR>
 * <TR><TD>26/05/2015</TD><TD>JDE</TD><TD>EV-000335 : G8R2C7 - Gestion des abandons des commandes Fibres. Determination d'un nouveau contexte ABANDON</TD></TR>
 * <TR><TD>30/07/2015</TD><TD>GCL</TD><TD>EV-000327 : G9R1C1 - RIP FTTH</TD></TR>
 * <TR><TD>10/12/2015</TD><TD>JDE</TD><TD>EV-000348 : G9R2C1 - Net commande unique</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377 : ROME OFfre - Commandes FTTE</TD></TR>
 * <TR><TD>11/10/2017</TD><TD>SMO</TD><TD>EV-431 : FTTE offre active sur RIP</TD></TR>
 * <TR><TD>15/03/2018</TD><TD>CDS</TD><TD>QC-948 Bitstream</TD></TR>
 * <TR><TD>16/05/2018</TD><TD>CDS</TD><TD>QC-1006 Bitstream - codeFOP</TD></TR>
 * <TR><TD>16/05/2019</TD><TD>YNOURI</TD><TD>QC-260 : Rendre l'acceptation des commandes g�n�rique</TD></TR>
 * <TR><TD>03/08/2021</TD><TD>GBI</TD><TD>US-2964 : Ajustements des filtres pour les cas SU et CR PEPS</TD></TR>
 * </TABLE>
 *
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.4956</TD><TD>EP135 � Prendre en compte les commandes FTTH Op�rateur �mises par GRAFIC</TD></TR>
 * <TR><TD>REQ.7299</TD><TD>EP0170 - Prendre en compte les commandes issues du Frontal de Livraison</TD></TR>
 * <TR><TD>REQ.9321</TD><TD>EP0239 - Accepter les commandes de R�siliation de Vente FTTH</TD></TR>
 * <TR><TD>REQ.9323</TD><TD>EP0228 - Accepter les commandes de mutation en masse</TD></TR>
 * <TR><TD>REQ.11787</TD><TD>EP0334 - Rep�rer et stocker les caract�ristiques des PLP Fibre dans le cadre de la vente FTTH (EV302)</TD></TR>
 * <TR><TD>EP0350</TD><TD>EP0350 - Identifier et livrer les commandes SCE (EV315)</TD></TR>
 * <TR><TD>EP0372</TD><TD>EP0372 - Gestion des abandons des commandes Fibres. Determination d'un nouveau contexte ABANDON</TD></TR>
 * <TR><TD>EP0375</TD><TD>Persister au niveau de la commande le contexte RIP FTTH sur le DeliverCustomerOrder et le ReportDeliverSupplierOrder</TD></TR>
 * </TABLE>
 *
 */
public abstract class CustomerOrderTraitement {

	/** The Constant CLASS_NAME. */
	private static final String CLASS_NAME = CustomerOrderTraitement.class.getName();

	/** Optimum */
	public static final String OPTIMUM_NAME = "Optimum";
	public static final String FUNCTION_CODE_FACT = "CodeFact";
	public static final String FUNCTION_QUANTITE = "Quantite";
	public static final String FUNCTION_MONTANT = "Montant";
	public static final String FUNCTION_TVA = "TVA";

	/** Le service manager */
	protected IServiceManager serviceManager = ServiceManager.getInstance();
	protected ILoggerManager loggerManager = serviceManager.getLoggerManager();

	protected DeliverCustomerOrderRequestMessage customerOrder;
	protected DeliverCustomerOrderDataIOSW deliverCustomerOrderData;

	// valoris� par la classe fille
	protected String EMETTEUR;
	protected HashMap<Entry<String, List<ValeurParametreDTO>>, CustomerOrderItemType> offreElementaireToCustomOrderItem;
	protected HashMap<LigneCommandeType, CustomerOrderItemType> ligneCommandeToCustomOrderItem;

	protected final String dateFormatee = DateUtils.format(DateUtils.getNowDate(), ConstantesDeliverCustomerOrder.FORMAT_DATE_HEURE);

	/**
	 * Getters
	 *
	 * @return deliverCustomerOrderData
	 */
	public DeliverCustomerOrderDataIOSW getDeliverCustomerOrderData() {
		return deliverCustomerOrderData;
	}

	/**
	 * Contr�les sur les valeurs de type boolean. <br />
	 * Les enumerations ne sont pas autoris�es dans le xsd pour le type boolean
	 *
	 * @throws DeliverCustomerOrderFault
	 */
	protected abstract void controleBooleans() throws DeliverCustomerOrderFault;

	/**
	 * Fait les v�rifications sur les lignes de commandes
	 *
	 * @throws DeliverCustomerOrderFault
	 */
	protected abstract void verifLigneCommande() throws DeliverCustomerOrderFault ;

	/**
	 * r�cup�re les fonctions obligatoires dans la table traduction
	 *
	 * @return
	 */
	protected abstract Collection<TraductionDTO> recupereFonctionsOblig();

	/**
	 * RG4: Contr�les specifiques
	 *
	 * @throws DeliverCustomerOrderFault
	 */
	protected abstract void controlesSpecifiques() throws DeliverCustomerOrderFault;

	/**
	 * Point d'entr�e du traitement de la commande<br />
	 * Les traitements sp�cifiques sont effectu�s dans les classes filles
	 *
	 * @param customerOrder
	 * @return
	 * @throws CustomerOrderFault
	 * @throws ValidationException
	 * @throws MarshalException
	 * @throws DeliverCustomerOrderFault
	 */
	public String traiter(DeliverCustomerOrderRequestMessage customerOrder, final DeliverCustomerOrderDataIOSW deliverCustomerOrderData) throws MarshalException, ValidationException, DeliverCustomerOrderFault {
		String methode = "traiter";
		this.customerOrder = customerOrder;
		this.deliverCustomerOrderData = deliverCustomerOrderData;

		// RG20 - on valorise le cas metier d�s le d�but
		loggerManager.fine(CLASS_NAME, methode, "Cas m�tier valoris� � : " + deliverCustomerOrderData.getCasMetier());

		deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().analyser();
		validate();
		final String messageAdapte;
		messageAdapte = serialiserMessage(adapter());
		loggerManager.info(CLASS_NAME, methode, "IC Art�mis \"" + customerOrder.getCustomerOrderID() + "\" adapt�e au format Art�mis : " + messageAdapte);

		return messageAdapte;

	}

	/**
	 * S�rialise l'IC Artemis en XML pour injection en livraison
	 *
	 * @param icArtemis l'IC Art�mis
	 * @return la repr�sentation XML
	 * @throws ValidationException
	 * @throws MarshalException
	 */
	protected String serialiserMessage(final Message icArtemis) throws MarshalException, ValidationException {
		final StringWriter writer = new StringWriter();
		icArtemis.marshal(writer);
		return writer.toString();
	}

	/**
	 * M�thode permettant de valider le contenu de la commande grafic
	 *
	 * @throws DeliverCustomerOrderFault
	 */
	protected void validate() throws DeliverCustomerOrderFault {
		final String methode = "validate";
		loggerManager.fine(CLASS_NAME, methode, "Validation de l'IC " + EMETTEUR);

		// RG2 : cf xsd sp�cifique
		controleBooleans();

		// 2.2.2.3 - Check LignesCommandes
		verifLigneCommande();
		verifierCoherenceChamps();
		controlesSpecifiques();

		loggerManager.info(CLASS_NAME, methode, "L'intention de commande " + EMETTEUR + " \"" + customerOrder.getCustomerOrderID() + "\" a �t� valid�e");
	}

	/**
	 * R�cup�re de l'IC les fonctions. Chaque element de la liste est li� � une Ldc
	 *
	 * @return une Map function/valeur
	 * @throws DeliverCustomerOrderFault
	 */
	public static List<Map<String, String>> recupererFonctionLc(DeliverCustomerOrderRequestMessage customerOrder, ILoggerManager loggerManager) throws DeliverCustomerOrderFault {
		String method = "recupererFonctionLc";
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration des fonctionLc pour le cas m�tier en �valuation.");

		final List<Map<String, String>> fonctionsLCLst = new ArrayList<Map<String, String>>();

		Map<String, String> fonctionsLC = null;
		List<FunctionSpecificationType> functionsSpecification;
		for (CustomerOrderItemType custOrderItem : customerOrder.getCustomerOrderItem()) {
			fonctionsLC = new HashMap<String, String>();
			if (custOrderItem.getProductOrderItem() != null) {
				for (ProductOrderItemType productOrderItem : custOrderItem.getProductOrderItem()) {
					functionsSpecification = productOrderItem.getProductSpecification().getFunctionSpecification();
					if (functionsSpecification != null) {
						String cle;
						String valeur;
						FunctionValueSpecification functionValueSpecification;
						for (FunctionSpecificationType functionSpecification : functionsSpecification) {
							cle = functionSpecification.getFunctionSpecificationCode();
							// Si la valeur n'est pas fournie, la fonction est ignor�e
							functionValueSpecification = functionSpecification.getFunctionValueSpecification();
							if (functionValueSpecification == null) {
								continue;
							}
							valeur = functionValueSpecification.getFunctionValue();
							if (valeur == null) {
								continue;
							}
							fonctionsLC.put(cle, valeur);
						}
					}
				}
			}
			fonctionsLCLst.add(fonctionsLC);
		}
		loggerManager.fine(CLASS_NAME, method, "FonctionLc trouv�es " + fonctionsLC);
		return fonctionsLCLst;

	}

	/**
	 * RG3 V�rifie la coh�rence des champs de l'IC
	 *
	 * @throws CustomerOrderFault
	 */
	private void verifierCoherenceChamps() throws DeliverCustomerOrderFault {
		final String methode = "verifierCoherenceChamps";
		loggerManager.finest(CLASS_NAME, methode, "Contr�le de la pr�sence des param�tres techniques");
		// r�cup�ration des traductions
		final Collection<TraductionDTO> traductions = recupereFonctionsOblig();
		loggerManager.fine(CLASS_NAME, methode, "Nombre de fonctions obligatoires " + traductions.size() + " pour le cas m�tier " + deliverCustomerOrderData.getCasMetier());
		// construction de la collection des functions obligatoires
		final Map<String, Collection<String>> fonctionsObligatoires = construireMapFonctionsEtValeursObligatoires(traductions);

		final List<Map<String, String>> fonctionsLc = deliverCustomerOrderData.getFonctionsLc();
		final List<Map<String, String>> fonctionsGraficLcTraduites = traduireFonctionsLc(fonctionsLc);
		deliverCustomerOrderData.setFonctionsLc(fonctionsGraficLcTraduites);
		verifierPresenceChampsObligatoires(fonctionsObligatoires);
	}

	/**
	 * Traduit la map fonctions "CustomerOrder" en map fonctions "Artemis"
	 *
	 * @param fonctionsLcLst
	 */
	protected List<Map<String, String>> traduireFonctionsLc(final List<Map<String, String>> fonctionsLcLst) {
		final String methode = "traduireFonctionsLc";
		loggerManager.finest(CLASS_NAME, methode, "Fonctions " + EMETTEUR + " NON traduites : " + fonctionsLcLst);
		final List<Map<String, String>> fonctionsLcTraduitesLst = new ArrayList<Map<String, String>>();
		String fonction;
		String fonctionTraduite;
		String valeurTraduite;
		Map<String, String> fonctionsLcTraduites = null;
		for (Map<String, String> fonctionsLc : fonctionsLcLst) {
			fonctionsLcTraduites = new HashMap<String, String>();
			for (Entry<String, String> functionATraduire : fonctionsLc.entrySet()) {
				fonction = functionATraduire.getKey();
				fonctionTraduite = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.FUNCTION, fonction);
				fonctionTraduite = fonctionTraduite != null ? fonctionTraduite : fonction;
				valeurTraduite = traduireValeur(fonctionTraduite, functionATraduire.getValue());
				fonctionsLcTraduites.put((fonctionTraduite != null ? fonctionTraduite : fonction), (valeurTraduite != null ? valeurTraduite : functionATraduire.getValue()));
			}
			fonctionsLcTraduitesLst.add(fonctionsLcTraduites);
		}
		loggerManager.finest(CLASS_NAME, methode, "Fonctions " + EMETTEUR + " traduites : " + fonctionsLcTraduites);
		return fonctionsLcTraduitesLst;
	}

	/**
	 * Permet de traduire les valeurs possibles d'une fonction
	 *
	 * @param fonctionTraduite la fonction pr�alablement traduite
	 * @param valeur la valeur de la fonction
	 * @return les valeurs traduites
	 */
	protected String traduireValeur(final String fonctionTraduite, final String valeur) {
		final StringBuilder constructionValeurExterne = new StringBuilder(100);
		constructionValeurExterne.append(fonctionTraduite);
		constructionValeurExterne.append('_');
		constructionValeurExterne.append(valeur);
		final String valeurExterne = constructionValeurExterne.toString();
		return serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.FUNCTION_VALUE, valeurExterne);
	}

	/**
	 * Construit la Map (function/ValeursPossibles) en fonction des �l�ments r�cup�r�s dans la table traduction
	 *
	 * @param traductions
	 * @return la map
	 */
	protected Map<String, Collection<String>> construireMapFonctionsEtValeursObligatoires(final Collection<TraductionDTO> traductions) {
		String method = "construreMapFonctionsEtValeursObligatoires";
		loggerManager.finest(CLASS_NAME, method, "Construction des fonctions " + EMETTEUR + " obligatoires.");
		final Map<String, Collection<String>> resultat = new HashMap<String, Collection<String>>();
		String valeurArtemis;
		String nomFonction;
		Queue<String> valeurArtemisSplitee;
		Collection<String> valeursAssociees;
		for (TraductionDTO traduction : traductions) {
			valeurArtemis = traduction.getValeurArtemis();
			valeurArtemisSplitee = new LinkedList<String>(Arrays.asList(valeurArtemis.split("_")));
			nomFonction = valeurArtemisSplitee.poll();
			valeursAssociees = new ArrayList<String>(valeurArtemisSplitee);
			resultat.put(nomFonction, valeursAssociees);
		}
		loggerManager.finest(CLASS_NAME, method, "Fonctions " + EMETTEUR + " obligatoires : " + resultat);
		return resultat;
	}

	/**
	 * ContainsKey mais chercher dans toutes les HashMap de la liste
	 *
	 * @param fonctionsLcTraduitesLst
	 * @param key
	 * @return
	 */
	public static boolean containsKeyInAny(List<Map<String, String>> fonctionsLcTraduitesLst, String key) {
		for (Map<String, String> fonctionsLcTraduites : fonctionsLcTraduitesLst) {
			if (fonctionsLcTraduites.containsKey(key)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Retourne la valeur associ�e � la cl� pass�e en param�tre.<br />
	 * La premi�re valeur non nulle trouv�e est retourn�e
	 *
	 * @param fonctionsLcTraduitesLst
	 * @param key
	 * @return
	 */
	public static String getKeyInAny(List<Map<String, String>> fonctionsLcTraduitesLst, String key) {

		for (Map<String, String> fonctionsLcTraduites : fonctionsLcTraduitesLst) {
			if (StringUtils.isNotEmpty(fonctionsLcTraduites.get(key))) {
				return fonctionsLcTraduites.get(key);
			}
		}
		return StringUtils.EMPTY;
	}

	/**
	 * V�rifie dans l'IC si les champs obligatoires sont bien pr�sents
	 *
	 * @param fonctionsObligatoires
	 * @throws CustomerOrderFault
	 */
	protected void verifierPresenceChampsObligatoires(final Map<String, Collection<String>> fonctionsObligatoires) throws DeliverCustomerOrderFault {
		String method = "verifierPresenceChampsObligatoires";
		loggerManager.finest(CLASS_NAME, method, "V�rification des champs obligatoires.");
		final List<Map<String, String>> fonctionsLcTraduitesLst = deliverCustomerOrderData.getFonctionsLc();
		// 2.2.3.5
		for (String functionObligatoire : fonctionsObligatoires.keySet()) {
			if (!containsKeyInAny(fonctionsLcTraduitesLst, functionObligatoire)) {
				throw deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(functionObligatoire, customerOrder.getCustomerOrderID());
			}
		}
		loggerManager.finest(CLASS_NAME, method, "Tous les champs function obligatoires sont pr�sents dans les functionLc.");

		for (Map<String, String> fonctionsLcTraduites : fonctionsLcTraduitesLst) {
			if (fonctionsLcTraduites.containsKey(ConstantesDeliverCustomerOrder.TYPEBRASSAGE) && ConstantesDeliverCustomerOrder.OI.equals(fonctionsLcTraduites.get(ConstantesDeliverCustomerOrder.TYPEBRASSAGE))) {
				if (!fonctionsLcTraduites.containsKey(ConstantesDeliverCustomerOrder.CONNECTEUR_PIGTAIL)) {
					throw deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent(ConstantesDeliverCustomerOrder.CONNECTEUR_PIGTAIL, customerOrder.getCustomerOrderID());
				}
				loggerManager.finest(CLASS_NAME, method, ConstantesDeliverCustomerOrder.TYPEBRASSAGE + " : " + ConstantesDeliverCustomerOrder.OI + ", et " + ConstantesDeliverCustomerOrder.CONNECTEUR_PIGTAIL + " pr�sent.");
			}
		}

		verifPrestaClipEtDebit(fonctionsLcTraduitesLst);

		String functionObligatoire;
		Collection<String> valeursObligatoire;
		String valeurTraduite = null;
		for (Entry<String, Collection<String>> functionValeursObligatoire : fonctionsObligatoires.entrySet()) {
			valeursObligatoire = functionValeursObligatoire.getValue();
			if (valeursObligatoire.isEmpty()) {
				continue;
			}
			functionObligatoire = functionValeursObligatoire.getKey();
			for (Map<String, String> fonctionsLcTraduites : fonctionsLcTraduitesLst) {
				valeurTraduite = fonctionsLcTraduites.get(functionObligatoire);
				if (StringUtils.isNotBlank(valeurTraduite)) {
					break;
				}
			}

			if (!valeursObligatoire.contains(valeurTraduite)) {
				throw deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(functionObligatoire, customerOrder.getCustomerOrderID());
			}
		}
		loggerManager.finest(CLASS_NAME, method, "Fin de la v�rification des champs obligatoires.");
	}

	/**
	 * v�rifie la pr�sence des valeurs PrestaClip et Debit selon certaines conditions
	 *
	 * @param fonctionsLcTraduites
	 * @throws CustomerOrderFault
	 */
	protected abstract void verifPrestaClipEtDebit(final List<Map<String, String>> fonctionsLcTraduites) throws DeliverCustomerOrderFault ;

	/**
	 * G�nere l'ano en cas de probl�me sur les lignes de commandes
	 *
	 * @return
	 */
	protected DeliverCustomerOrderFault anoCommandeMalStructuree() {
		loggerManager.finest(CLASS_NAME, "anoCommandeMalStructuree", "G�n�ration d'une anomalie Commande Mal Structur�e.");

		return deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieChampMalFormate("La commande est mal structur�e pour le cas m�tier " + deliverCustomerOrderData.getCasMetier(), customerOrder.getCustomerOrderID());
	}

	/**
	 * Point d'entr�e de l'adaptateur : adapte l'IC grafic en commande au format Artemis
	 *
	 * @return le message au format Artemis
	 * @throws CustomerOrderFault
	 */
	public Message adapter() throws DeliverCustomerOrderFault {
		String method = "adapter";
		final Message icArtemis = new Message();
		icArtemis.setIdEmetteur(EMETTEUR);
		icArtemis.setVersion("2.0");
		icArtemis.setDateEmission(dateFormatee);
		deliverCustomerOrderData.setListeOffresElementaires(recupererListeOffresElementaires());
		loggerManager.finest(CLASS_NAME, method, "Cr�ation de la commande.");
		final Commande commande = creerCommande();
		loggerManager.finest(CLASS_NAME, method, "Commande cr��e.");
		icArtemis.setCommande(commande);
		icArtemis.setStatutCommande(deliverCustomerOrderData.getStatutCommande());
		return icArtemis;
	}

	/**
	 * RG5 Construction du client contractant
	 *
	 * @return le client contractant
	 */
	protected ClientContractant creerClientContractant() throws DeliverCustomerOrderFault {
		String method = "creerClientContractant";

		// Cat�gorie client
		final ClientContractant clientContractant = new ClientContractant();
		clientContractant.setCategorie(determineCategorieClientContractant());

		// Code client
		final String codeClient = determineCodeClient();
		loggerManager.fine(CLASS_NAME, method, "D�termination CodeClient : " + codeClient);
		clientContractant.setNomOuRaisonSociale(codeClient);
		if (SystemeExterneConstantes.GRAFIC.equals(EMETTEUR)) {
			clientContractant.setIdClient(codeClient);
		}
		if (SystemeExterneConstantes.NUM_75B.equals(EMETTEUR) && CasMetierConstantes.DEG_E.equals(getDeliverCustomerOrderData().getCasMetier())) {
			clientContractant.setNomOuRaisonSociale(determineDenominationClient());
			clientContractant.setIdClient(codeClient);
		}
		BuyerType buyerType = customerOrder.getBuyer();
		if (buyerType != null) {
			clientContractant.setSiren(buyerType.getSiren());
			clientContractant.setNic(buyerType.getNic());
		}
		return clientContractant;
	}

	/**
	 * RG5
	 *
	 * @return la categorie du client contractant
	 */
	protected abstract String determineCategorieClientContractant() throws DeliverCustomerOrderFault;

	/**
	 * RG5
	 *
	 * @return le label du LocalMarketSegment (C9) s'il existe, sinon null
	 */
	protected String recupererLabelLocalMarketSegmentClientContractant() {
		String res = null;
		if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasBuyer() && null != customerOrder.getBuyer().getLocalMarketSegment()) {
			res = customerOrder.getBuyer().getLocalMarketSegment().getLabel();
		}
		return res;
	}

	/**
	 * D�termine le code client � partir de l'IC
	 *
	 * @return
	 * @throws CustomerOrderFault
	 */
	protected String determineCodeClient() {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		String codeClient = null;
		if (customerOrder.getBuyer() != null && StringUtils.isNotBlank(customerOrder.getBuyer().getPartyName())) {
			codeClient = customerOrder.getBuyer().getPartyName();
		} else {
			codeClient = customerOrder.getCustomerOrderItem().get(getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().getIndexOrganisationName()).getProductOrderItem().get(0).getUser().get(0).getParty().getLocalOrganisationName().getTradingName();
		}
		return codeClient;
	}

	/**
	 * D�termine la denomination client partir de l'IC
	 *
	 * @return
	 * @throws CustomerOrderFault
	 */
	protected String determineDenominationClient() {
		return StringUtils.EMPTY;
	}

	/**
	 * RG6 : R�cup�re la liste des offres �l�mentaires.
	 *
	 * @return la liste des offres �l�mentaires
	 * @throws CustomerOrderFault
	 */
	protected Map<String, List<ValeurParametreDTO>> recupererListeOffresElementaires() throws DeliverCustomerOrderFault {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		String method = "recupererListeOffresElementaires";
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration de la liste d'offres elementaires");
		// LinkedHashMap pour conserver l'ordre des param�tres lors de la copie sur les lignes de commandes
		Map<String, List<ValeurParametreDTO>> listeOffresElementaires = new LinkedHashMap<String, List<ValeurParametreDTO>>();
		String offre = null;
		try {
			for (CustomerOrderItemType custOrderType : customerOrder.getCustomerOrderItem()) {
				offre = custOrderType.getOfferSpecification().getOfferSpecificationCode();
				listeOffresElementaires = serviceManager.getTraductionManager().getTraductionOffreConcatDiff(offre, EMETTEUR);
			}
		} catch (AnomalieException ae) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(offre, customerOrder.getCustomerOrderID());
		}
		loggerManager.fine(CLASS_NAME, method, "Nombre d'offre elementaires trouv�es : " + listeOffresElementaires.size());
		return listeOffresElementaires;
	}

	/**
	 * Cr�e la commande
	 *
	 * @return la commande
	 * @throws CustomerOrderFault
	 */
	protected Commande creerCommande() throws DeliverCustomerOrderFault {
		String method = "creerCommande";
		List<InputDynamicCommandeDTO> inputDynamicCommandList = serviceManager.getTraductionManager().findInputDynamicCommandeByOrigine(SystemeExterneConstantes.DCO_VALEUR_CONSTANTE);
		final Commande commande = new Commande();

		// RG22
		commande.setIdCommande(customerOrder.getCustomerOrderID());
		commande.setCasMetier(deliverCustomerOrderData.getCasMetier());
		// RG28
		String vendeur = recupererIdVendeur();
		if (StringUtils.isNotBlank(vendeur)) {
			commande.setIdVendeur(vendeur);
		}

		// RG5
		final ClientContractant clientContractant = creerClientContractant();
		commande.setClientContractant(clientContractant);

		final Contact contact = creerContact();
		commande.setContact(contact);

		loggerManager.finest(CLASS_NAME, method, "Cr�ation et remplissage des lignes de commande.");

		// Cr�ation et remplissage des lignes de commande
		final Collection<LigneCommandeType> lignesDeCommande = creerLignesCommande();
		fournirIdentifiantLigneDeCommande(lignesDeCommande, deliverCustomerOrderData.getCasMetier());
		fournirDateContractuelleDateSouhaitee(lignesDeCommande);
		fournirOperationPonctuelle(lignesDeCommande);
		fournirAccesEtTypeLivraison(lignesDeCommande);
		fournirElementsFacturation(lignesDeCommande);
		fournirClientLivre(lignesDeCommande);
		fournirIdentifiantAccesClient(lignesDeCommande);
		fournirParametrePSouEPC(lignesDeCommande);
		// QC-948
		if ((CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_MODIFICATION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| CasMetierConstantes.CR_PEPS.equals(deliverCustomerOrderData.getCasMetier())
				|| SystemeExterneConstantes.NUM_48W.equals(EMETTEUR)) {
			fournirInterventionEtParametresAssocies(commande, lignesDeCommande);
		}

		// Cr�ation des instancesOG et r�partition des lignes de commande
		final Collection<InstanceOffreGroupee> instancesOffreGroupee = creerOffresGroupees(lignesDeCommande);
		if (instancesOffreGroupee != null) {
			commande.setInstanceOffreGroupee(instancesOffreGroupee.toArray(new InstanceOffreGroupee[0]));
		}

		// Suppression de lignes de commande
		if (CasMetierConstantes.SU_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.SU_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
				|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType())) || SystemeExterneConstantes.NUM_49W.equals(EMETTEUR)
				|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| (CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))) {
			commande.setLigneCommande(lignesDeCommande.toArray(new LigneCommandeType[0]));
		}

		// Cas de la modification VENTE_FTTH & MO_FTTH
		if ((CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.MO_FTTH.equals(deliverCustomerOrderData.getCasMetier()))
				&& Constantes.CST_MODIFICATION.equalsIgnoreCase(customerOrder.getCustomerOrderType())) {
			commande.setLigneCommande(lignesDeCommande.toArray(new LigneCommandeType[0]));
		}

		// RG21 : Valorisation date de d�pot et date validation FO
		commande.setDateDebutPriseCommandeFO(determineDateDebutPrise());
		commande.setDateValidationCommandeFO(determineDateValidation());
		// RG24 : D�tection d�une commande de FTTH entreprise.
		detectionCommandeFTTHEntreprise(inputDynamicCommandList);

		// US-864: Valorisation multiacces
		if (StringUtils.isNotEmpty(getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.TYPE_ACCES))) {
			deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.MULTI_ACCES, ConstantesDynamicCommande.VALEUR_1);
			String infoCmd = deliverCustomerOrderData.getDynamicCommandes().get(ConstantesDynamicCommande.CLE_INFO_CMD);
			if (StringUtils.isBlank(infoCmd)) {
				infoCmd = Constantes.TXT_INFO_CMD_MULTI_ACCES;
			} else if (!infoCmd.contains(Constantes.TXT_INFO_CMD_MULTI_ACCES)) {
				infoCmd = infoCmd + Constantes.SEPARATEUR_POINT_VIRGULE + Constantes.TXT_INFO_CMD_MULTI_ACCES;
			}
			deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_INFO_CMD, infoCmd);
		}

		// RG25 Valorisation des parametres LigneCommande
		if (CasMetierConstantes.MUT_DSLAM.equals(deliverCustomerOrderData.getCasMetier()) || SystemeExterneConstantes.NUM_49W.equals(EMETTEUR) || SystemeExterneConstantes.NUM_75B.equals(EMETTEUR)) {
			valorisationParametresLigneCommande(lignesDeCommande);
			valorisationContexteLigneCommande(lignesDeCommande);
		}

		// RG25 Valorisation des champs dynamique LC pour Vente FTTH, DEG_E, FTTH (provenants d'OPUS) et PEPS
		if (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) || SystemeExterneConstantes.NUM_49W.equals(EMETTEUR)
				|| CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) || (SystemeExterneConstantes.NUM_75B.equals(EMETTEUR) && (CasMetierConstantes.CR_FTTH.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.MO_FTTH.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.SU_FTTH.equals(deliverCustomerOrderData.getCasMetier())))
				|| CasMetierConstantes.CR_PEPS.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier())) {
			valorisationChampsDynamiquesLC(lignesDeCommande);
		}

		// RG25 : OsirisOpPonctuelleOrigine
		valorisationChampDynamiqueOsirisOpPonctuelleOrigine(lignesDeCommande);

		// RG25 : Fonction OI
		valorisationChampDynamiqueOI(lignesDeCommande);

		// RG25 Fonction DateAccept
		valorisationChampDynamiqueDateAccept(lignesDeCommande);

		// RG27 Valorisation du champ Process
		if (customerOrder.getProcess() != null) {
			if (Constantes.CST_OUI.equals(deliverCustomerOrderData.getDynamicCommandes().get(ConstantesDynamicCommande.CLE_FTTH_ENTREPRISE))) {
				// Contexte RIP pour FTTH Entreprise
				if (customerOrder.getProcess() != null) {
					if (lignesDeCommande.size() > 0) {
						LigneCommandeType lc = lignesDeCommande.iterator().next();
						ParametreType process = createParametre(ConstantesDynamicCommande.CLE_PROCESS, customerOrder.getProcess());
						lc.addParametreLivraison(process);
					}
				}
			} else {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_PROCESS, customerOrder.getProcess());
			}

		}

		gestionParametresOI();

		commande.setParametresCommande(createCdeDynParam());

		return commande;
	}

	/**
	 * RG25 Valorisation du champ dynamique LC pour la fonction OI, si pr�sent
	 * (poour tous les cas m�tiers)
	 *
	 * @param lignesDeCommande LC � valoriser
	 */
	private void valorisationChampDynamiqueOI(Collection<LigneCommandeType> lignesDeCommande) {
		String keyOI = getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.OI);
		if (StringUtils.isNotBlank(keyOI)) {
			for (LigneCommandeType ligneCommande : lignesDeCommande) {
				ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE, keyOI));
			}
		}
	}

	/**
	 * RG25 Valorisation du champ dynamique LC pour la fonction DateAccept, si pr�sent
	 * (poour tous les cas m�tiers)
	 *
	 * @param lignesDeCommande LC � valoriser
	 */
	private void valorisationChampDynamiqueDateAccept(Collection<LigneCommandeType> lignesDeCommande) {
		String dateAccept = getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.DATE_ACCEPT);
		dateAccept = DateUtils.changeFormatDate(dateAccept, EFBConstantes.FORMAT_DATE, EFBConstantes.FORMAT_DATE_HEURE);
		if (StringUtils.isNotBlank(dateAccept)) {
			for (LigneCommandeType ligneCommande : lignesDeCommande) {
				ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_DATE_DEBUT_ACCEPTATION_CMD_ACCES, dateAccept));
			}
		}
	}

	/**
	 * RG25 Valorisation du champ dynamique LC OsirisOpPonctuelleOrigine
	 * (poour tous les cas m�tiers)
	 *
	 * @param lignesDeCommande LC � valoriser
	 */
	protected abstract void valorisationChampDynamiqueOsirisOpPonctuelleOrigine(Collection<LigneCommandeType> lignesDeCommande);


	/**
	 * S occupe de la gestion des parametre OI (staircaseOI, floorOI, buildingOI)
	 * Fait appel aux methodes recuperationParametreOI et valorisationParametreOI
	 */
	private void gestionParametresOI() {

		String[] strArrayParametreOI = recuperationParametreOI();

		valorisationParametreOI(strArrayParametreOI);

	}

	/**
	 * Permet de recuperer les constantes staircaseOI, floorOI, buildingOI, interfLivr pour traitement ulterieur
	 *
	 * @return la liste des parametres OI : String[]
	 */
	private String[] recuperationParametreOI() {

		String staircaseOI = null;
		String floorOI = null;
		String buildingOI = null;
		String interfLivr = null;

		if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasCouldBeRelatedToTemporarySite()) {
			final SiteType site = customerOrder.getCouldBeRelatedToTemporarySite().getSite().get(0);
			if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasLocalplace()) {
				final LocalPlace temporaryLocalPlace = site.getLocalPlace().get(0);
				final LocalPlace.LocalInstalledResource localInstalledResource = CollectionUtils.getFirstOrNull(temporaryLocalPlace.getLocalInstalledResource());
				final SubAddress subAddress = temporaryLocalPlace.getSubAddress();
				if (localInstalledResource != null && localInstalledResource.getResourceSpecification() != null) {
					interfLivr = localInstalledResource.getResourceSpecification().getSpecificationCode();
				}
				if (subAddress != null) {
					staircaseOI = subAddress.getStaircaseOI();
					floorOI = subAddress.getFloorOI();
					buildingOI = subAddress.getBuildingOI();
				}
			}
		}

		return new String[] { staircaseOI, floorOI, buildingOI, interfLivr };
	}

	/**
	 * Valorise dans le deliverCustomerOrderData, les variables staircaseOI, floorOI, buildingOI, interfLivr si elles existent
	 *
	 * @param strArrayParametreOI
	 */
	private void valorisationParametreOI(String[] strArrayParametreOI) {

		if (StringUtils.isNotEmpty(strArrayParametreOI[0])) {
			deliverCustomerOrderData.getDynamicCommandes().put(EFBConstantes.ESCALIEROI, strArrayParametreOI[0]);
		}

		if (StringUtils.isNotEmpty(strArrayParametreOI[1])) {
			deliverCustomerOrderData.getDynamicCommandes().put(EFBConstantes.ETAGEOI, strArrayParametreOI[1]);
		}

		if (StringUtils.isNotEmpty(strArrayParametreOI[2])) {
			deliverCustomerOrderData.getDynamicCommandes().put(EFBConstantes.BATIMENTOI, strArrayParametreOI[2]);
		}
		if (StringUtils.isNotEmpty(strArrayParametreOI[3])) {
			deliverCustomerOrderData.getDynamicCommandes().put(EFBConstantes.INTERFLIVR, strArrayParametreOI[3]);
		}

	}

	/**
	 * RG24 : D�tection d�une commande de FTTH entreprise.
	 *
	 * @param inputDynamicCommandList la liste des param�tres dynamique de commande DCO
	 */
	private void detectionCommandeFTTHEntreprise(List<InputDynamicCommandeDTO> inputDynamicCommandList) {
		// CR_FTTH ou SU_FTTH
		if (CasMetierConstantes.CR_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.SU_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.MO_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.CR_PEPS.equals(deliverCustomerOrderData.getCasMetier())) {
			deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_FTTH_ENTREPRISE, Constantes.CST_OUI);
		}
		// VENTE_FTTH
		if (CasMetierConstantes.VENTE_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
			if (containsKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CODE_FOP)) {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_CODE_FOP, getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CODE_FOP));
			}
			if (containsKeyInAny(deliverCustomerOrderData.getFonctionsLc(), translateKeyParameter(inputDynamicCommandList, ConstantesDeliverCustomerOrder.NUM_SERIE_ONT))) {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDeliverCustomerOrder.NUM_SERIE_ONT,
						getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), translateKeyParameter(inputDynamicCommandList, ConstantesDeliverCustomerOrder.NUM_SERIE_ONT)));
			}
		}

		// Contexte
		if (containsKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CONTEXTE)) {
			// casMetier � DENUM_INDUITE
			if (CasMetierConstantes.DENUM_INDUITE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON, CasMetierConstantes.DENUM_INDUITE_VALEUR_CONSTANTE);
			} else {
				deliverCustomerOrderData.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON, getKeyInAny(deliverCustomerOrderData.getFonctionsLc(), ConstantesDeliverCustomerOrder.CONTEXTE_LIVRAISON));
			}
		}
	}

	/**
	 * cree le tableau des parametres de la commande (param�tres dynamiques plus tard)
	 *
	 * @return
	 */
	private ParametreType[] createCdeDynParam() {
		List<ParametreType> paramList = new ArrayList<ParametreType>();
		// Ajout des dynCmd cr��s pr�cedement
		for (Entry<String, String> dynCmd : deliverCustomerOrderData.getDynamicCommandes().entrySet()) {
			ParametreType param = new ParametreType();
			param.setCle(dynCmd.getKey());
			param.setValeur(dynCmd.getValue());
			paramList.add(param);
		}
		return paramList.toArray(new ParametreType[paramList.size()]);

	}

	/**
	 * d�termine la date de validation de l'IC
	 *
	 * @return
	 */
	private String determineDateValidation() {
		Date dateValidation = null;
		if (customerOrder.getCustomerOrderStatus() != null && customerOrder.getCustomerOrderStatus().getStartDate() != null) {
			dateValidation = customerOrder.getCustomerOrderStatus().getStartDate().getTime();
		}
		if (dateValidation == null) {
			return dateFormatee;
		}
		return DateUtils.format(dateValidation, ConstantesDeliverCustomerOrder.FORMAT_DATE_HEURE);
	}

	/**
	 * determine la date de d�butPrise de la commande
	 *
	 * @return
	 */
	private String determineDateDebutPrise() {
		Date dateDebutPrise = null;
		if (customerOrder.getDepositDate() != null) {
			dateDebutPrise = customerOrder.getDepositDate().getTime();
		} else {
			if (customerOrder.getCustomerOrderStatus() != null && customerOrder.getCustomerOrderStatus().getStartDate() != null) {
				dateDebutPrise = customerOrder.getCustomerOrderStatus().getStartDate().getTime();
			}
		}

		if (dateDebutPrise == null) {
			return dateFormatee;
		}

		return DateUtils.format(dateDebutPrise, ConstantesDeliverCustomerOrder.FORMAT_DATE_HEURE);
	}

	/**
	 * Cr�e l'objet contact commande
	 *
	 * @return l'objet contact
	 */
	protected Contact creerContact() {
		final Contact contact = new Contact();
		if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasPhoneNumber()) {
			contact.setTelephone(customerOrder.getCouldUseTemporaryContactMethod().get(0).getPhoneNumber().get(0).getNumber());
		}
		if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasPersonNameContactMethod()) {
			contact.setNom(customerOrder.getCouldUseTemporaryContactMethod().get(0).getContactMethod().getPartyRole().getParty().getPersonName().getLastName());
		}
		return contact;
	}

	/**
	 * RG7 D�termination des offres �l�mentaires et instanciation des lignes de commandes et entit�s PSS/EPC
	 *
	 * @return La liste des lignes de commande
	 */
	protected Collection<LigneCommandeType> creerLignesCommande() {
		ligneCommandeToCustomOrderItem = new HashMap<LigneCommandeType, CustomerOrderItemType>();
		final Collection<LigneCommandeType> lignesDeCommande = new ArrayList<LigneCommandeType>();
		final Map<String, List<ValeurParametreDTO>> listeOffresElementaires = deliverCustomerOrderData.getListeOffresElementaires();
		LigneCommandeType ligneCommandeType;
		if (CasMetierConstantes.SU_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.SU_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
				|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType())) || SystemeExterneConstantes.NUM_49W.equals(EMETTEUR)
				|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| (CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))) {
			ElementParcAffecte elementParcAff;
			for (Entry<String, List<ValeurParametreDTO>> offre : listeOffresElementaires.entrySet()) {
				ligneCommandeType = new LigneCommandeType();
				elementParcAff = new ElementParcAffecte();
				ligneCommandeType.setElementParcAffecte(elementParcAff);
				elementParcAff.setRefOffreExistante(offre.getKey());
				lignesDeCommande.add(ligneCommandeType);

				if (CasMetierConstantes.SU_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
					ligneCommandeToCustomOrderItem.put(ligneCommandeType, offreElementaireToCustomOrderItem.get(offre));
				}
			}
		} else if (CasMetierConstantes.CR_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.CR_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.MUT_DSLAM.equals(deliverCustomerOrderData.getCasMetier())
				|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| (CasMetierConstantes.CR_PEPS.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| (SystemeExterneConstantes.NUM_48W.equals(EMETTEUR) && Constantes.CST_PRESTATION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))) {
			ProduitServiceSouhaite produitServiceSouhaite;
			for (Entry<String, List<ValeurParametreDTO>> offre : listeOffresElementaires.entrySet()) {
				ligneCommandeType = new LigneCommandeType();
				produitServiceSouhaite = new ProduitServiceSouhaite();
				ligneCommandeType.setProduitServiceSouhaite(produitServiceSouhaite);
				produitServiceSouhaite.setRefOffreCible(offre.getKey());
				lignesDeCommande.add(ligneCommandeType);

				if (CasMetierConstantes.CR_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
					ligneCommandeToCustomOrderItem.put(ligneCommandeType, offreElementaireToCustomOrderItem.get(offre));
				}
			}
		} else if ((CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.MO_FTTH.equals(deliverCustomerOrderData.getCasMetier()))
				&& Constantes.CST_MODIFICATION.equalsIgnoreCase(customerOrder.getCustomerOrderType())) {
			ElementParcAffecte elementParcAff;
			ProduitServiceSouhaite produitServiceSouhaite;
			for (Entry<String, List<ValeurParametreDTO>> offre : listeOffresElementaires.entrySet()) {
				ligneCommandeType = new LigneCommandeType();
				// Gestion du ProduitService
				produitServiceSouhaite = new ProduitServiceSouhaite();
				ligneCommandeType.setProduitServiceSouhaite(produitServiceSouhaite);
				produitServiceSouhaite.setRefOffreCible(offre.getKey());
				// Gestion de l'EP
				elementParcAff = new ElementParcAffecte();
				ligneCommandeType.setElementParcAffecte(elementParcAff);
				elementParcAff.setRefOffreExistante(offre.getKey());
				lignesDeCommande.add(ligneCommandeType);
			}
		}
		return lignesDeCommande;
	}

	/**
	 * RG8 Cr�e un identifiant pour chaque ligne de commande
	 *
	 * @param lignesDeCommande les lignes de commande
	 */
	protected void fournirIdentifiantLigneDeCommande(final Collection<LigneCommandeType> lignesDeCommande, String casMetier) {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		String method = "fournirIdentifiantLigneDeCommande";
		ArrayList<LigneCommandeType> ligneCommandeTypesArray = (ArrayList<LigneCommandeType>) lignesDeCommande;
		for (LigneCommandeType ligneDeCommande : ligneCommandeTypesArray) {
			String idLdC = customerOrder.getCustomerOrderItem().get(ligneCommandeTypesArray.indexOf(ligneDeCommande)).getCustomerOrderItemID();
			loggerManager.fine(CLASS_NAME, method, "IdLigneCommande cr�e : " + idLdC);
			ligneDeCommande.setIdLigneCommande(idLdC);
		}
	}

	/**
	 * RG9 : Date Contractuelle et Date Souhait�e
	 */
	protected void fournirDateContractuelleDateSouhaitee(final Collection<LigneCommandeType> lignesDeCommande) {

		if (customerOrder.getDeliveryContractualDate() != null) {
			final Date dateGrafic = customerOrder.getDeliveryContractualDate().getTime();

			String date = DateUtils.format(dateGrafic, ConstantesDeliverCustomerOrder.FORMAT_DATE_HEURE);
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				ligneDeCommande.setDateContractuelle(date);
				ligneDeCommande.setDateSouhaitee(date);
			}
		}
		// / FIXME G8R2C6 - Temporaire - Pour forcer la commande
		else {
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				String date = DateUtils.format(DateUtils.getNowDate(), ConstantesDeliverCustomerOrder.FORMAT_DATE_HEURE);
				ligneDeCommande.setDateContractuelle(date);
				ligneDeCommande.setDateSouhaitee(date);
			}
		}
	}

	/**
	 * RG10 : fournit l'op�ration ponctuelle pour chaque ligne de commande
	 *
	 * @param lignesDeCommande
	 * @throws CustomerOrderFault
	 */
	protected void fournirOperationPonctuelle(final Collection<LigneCommandeType> lignesDeCommande) throws DeliverCustomerOrderFault {
		String method = "fournirOperationPonctuelle";
		if (!deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return;
		}
		final String valeurExterne = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getFunctionalOperation().getFunctionalOperationType();
		final String valeurArtemis = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.CODE_ACTION, StringUtils.upperCase(valeurExterne));
		if (valeurArtemis == null) {
			throw deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(valeurExterne, customerOrder.getCustomerOrderID());
		}
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			ligneDeCommande.setRefOperationPonctuelle(valeurArtemis);
		}
		loggerManager.fine(CLASS_NAME, method, "Op�ration ponctuelle valeurExterne/valeurArtemis : " + valeurExterne + "/" + valeurArtemis);
		deliverCustomerOrderData.setReferenceOpPonctuelle(valeurArtemis);
	}

	/**
	 * RG11 : Acc�s et Type Livraison
	 *
	 * @param lignesDeCommande
	 */
	protected void fournirAccesEtTypeLivraison(final Collection<LigneCommandeType> lignesDeCommande) {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		String method = "fournirAccesEtTypeLivraison";

		final ProductOrderItemType.InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
		loggerManager.fine(CLASS_NAME, method, "Cas metier MUT_DSLAM, accesLivraison : " + installedProduct + ", typeAccesLivraison : " + ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_ND);
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
			ligneDeCommande.setAccesLivraison(installedProduct != null ? installedProduct.getInstalledProductID() : null);
			ligneDeCommande.setTypeAccesLivraison(ConstantesDeliverCustomerOrder.TYPE_ACCES_LIVRAISON_ND);
		}
	}

	/**
	 * RG12
	 *
	 * @param lignesDeCommande
	 * @throws CustomerOrderFault
	 */
	protected void fournirClientLivre(final Collection<LigneCommandeType> lignesDeCommande) throws DeliverCustomerOrderFault {
		String method = "";
		loggerManager.finest(CLASS_NAME, method, "Cr�ation du client livr�.");
		final String traductionCatClient = getTraductionCategorieClientLivre();
		String nomOuRaisonSociale = null;
		String prenom = null;
		String codePostal = null;
		String ville = null;
		String libelleVoie = null;
		String codeRivoli = null;
		String numVoie = null;
		String cpltNumVoie = null;
		String batiment = null;
		String escalier = null;
		String etage = null;
		String codeInsee = null;
		if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasCouldBeRelatedToTemporarySite()) {
			final SiteType site = customerOrder.getCouldBeRelatedToTemporarySite().getSite().get(0);
			codePostal = site.getAddress().getPostalCode();
			final City city = site.getAddress().getCity();
			if (city != null) {
				ville = city.getCityName();
				codeInsee = city.getCityCode();
			}
			final Street street = site.getAddress().getStreet();
			if (street != null) {
				final List<StreetCode> streetCodeList = street.getStreetCode();
				if (streetCodeList != null && streetCodeList.size() > 0) {
					StreetCode streetCode = streetCodeList.get(0);
					if (streetCode != null) {
						codeRivoli = streetCode.getCode();
					}
				}
				libelleVoie = street.getStreetName();
				numVoie = street.getStreetNumber();
				cpltNumVoie = street.getStreetLetter();
			}
			if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasLocalplace()) {
				final LocalPlace temporaryLocalPlace = site.getLocalPlace().get(0);
				final SubAddress subAddress = temporaryLocalPlace.getSubAddress();
				if (subAddress != null) {
					batiment = site.getLocalPlace().get(0).getSubAddress().getBuildingName();
					escalier = site.getLocalPlace().get(0).getSubAddress().getStaircaseNumber();
					etage = site.getLocalPlace().get(0).getSubAddress().getFloorNumber();
				}
			}
		}
		if (deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			final Party productOrderParty = customerOrder.getCustomerOrderItem().get(deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().getIndexOrganisationName()).getProductOrderItem().get(0).getUser().get(0).getParty(); // getCustomerOrderItem(deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().getIndexOrganisationName()).getProductOrderItem().get(0).getUser().get(0).getParty();

			if (productOrderParty != null) {
				final LocalPersonName localPersonName = productOrderParty.getLocalPersonName();
				if (localPersonName != null && (!CasMetierConstantes.MUT_DSLAM.equals(deliverCustomerOrderData.getCasMetier()))) {
					nomOuRaisonSociale = localPersonName.getLastName();
					prenom = localPersonName.getFirstName();
				}
				if (StringUtils.isEmpty(nomOuRaisonSociale)) {
					LocalOrganisationName local_OrganisationName = productOrderParty.getLocalOrganisationName();
					if (local_OrganisationName != null) {
						nomOuRaisonSociale = local_OrganisationName.getTradingName();
					}
				}
			}

			// / FIXME G8R2C6 - Temporaire - Pour forcer la commande
			else {
				nomOuRaisonSociale = "";
			}
		}

		ClientLivre clientLivre;
		Adresse adresseClientLivre;
		ArrayList<LigneCommandeType> ligneCommandeTypesArray = (ArrayList<LigneCommandeType>) lignesDeCommande;
		for (LigneCommandeType ligneDeCommande : ligneCommandeTypesArray) {
			clientLivre = new ClientLivre();
			adresseClientLivre = new Adresse();
			clientLivre.setAdresse(adresseClientLivre);
			clientLivre.setNomOuRaisonSociale(nomOuRaisonSociale);
			clientLivre.setPrenom(prenom);
			clientLivre.setCategorie(traductionCatClient);
			adresseClientLivre.setCodePostal(codePostal);
			adresseClientLivre.setVille(ville);
			adresseClientLivre.setLibelleVoie(libelleVoie);
			adresseClientLivre.setCodeRivoli(codeRivoli);
			adresseClientLivre.setNumeroVoie(numVoie);
			adresseClientLivre.setCpltNumVoie(cpltNumVoie);
			adresseClientLivre.setBatiment(batiment);
			adresseClientLivre.setEscalier(escalier);
			adresseClientLivre.setEtage(etage);
			adresseClientLivre.setCodeInsee(codeInsee);
			CustomerOrderItemType customerOrderItemType = customerOrder.getCustomerOrderItem().get(ligneCommandeTypesArray.indexOf(ligneDeCommande));
			if (customerOrderItemType != null && customerOrderItemType.getProductOrderItem().size() > 0 &&
					customerOrderItemType.getProductOrderItem().get(0) != null &&
					customerOrderItemType.getProductOrderItem().get(0).getUser().size() > 0 &&
					customerOrderItemType.getProductOrderItem().get(0).getUser().get(0) != null &&
					customerOrderItemType.getProductOrderItem().get(0).getUser().get(0).getParty() != null &&
					customerOrderItemType.getProductOrderItem().get(0).getUser().get(0).getParty().getLocalOrganisationName() !=null) {
				clientLivre.setSiren(customerOrderItemType.getProductOrderItem().get(0).getUser().get(0).getParty().getLocalOrganisationName().getSiren());
				clientLivre.setNic(customerOrderItemType.getProductOrderItem().get(0).getUser().get(0).getParty().getLocalOrganisationName().getNic());
			}
			ligneDeCommande.setClientLivre(clientLivre);
		}
	}

	/**
	 * RG12 : r�cup�re la valeur du champ Label dans Local_MarketSegment
	 *
	 * @return le label du LocalMarketSegment s'il existe, sinon null
	 * @throws CustomerOrderFault
	 */
	protected String getTraductionCategorieClientLivre() throws DeliverCustomerOrderFault {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		final String methode = "getTraductionCategorieClientLivre";
		final String label = getLocalMarketSegmentLabelClientLivre();
		loggerManager.fine(CLASS_NAME, methode, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (org.apache.commons.lang.StringUtils.isBlank(label)) {
			throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
		}
		String traduction = serviceManager.getTraductionManager().getTraductionCatClientInterfVersCatClientLivre(EMETTEUR, label);
		loggerManager.fine(CLASS_NAME, methode, "LocalMarketSegmentLabel traduit : " + traduction);
		if (org.apache.commons.lang.StringUtils.isBlank(traduction)) {
			traduction = label;
		}
		return traduction;

	}

	/**
	 * RG12 : r�cup�re la valeur du champ Label dans Local_MarketSegment
	 *
	 * @return le label du LocalMarketSegment s'il existe, sinon null
	 */
	protected String getLocalMarketSegmentLabelClientLivre() {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		if (!getDeliverCustomerOrderData().getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return null;
		}
		final ProductOrderItemType.User.LocalMarketSegment localMarketSegment = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getUser().get(0).getLocalMarketSegment();
		if (localMarketSegment == null) {
			return null;
		}
		return localMarketSegment.getLabel();
	}

	/**
	 * RG13 : Identifiant de l�acces client
	 *
	 * @param lignesDeCommande
	 */
	protected void fournirIdentifiantAccesClient(final Collection<LigneCommandeType> lignesDeCommande) {
		String method = "fournirIdentifiantAccesClient";
		if (!deliverCustomerOrderData.getDeliverCustomerOrderNullHelper().hasProductOrderItem()) {
			return;
		}

		String installedProductId;
		if (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier())) {
			// Pour un cas m�tier DEG_E, on prend l'acc�s livraison de la ligne de commande comme ID d'acc�s client
			// Cette m�canique est egalement utilisee pour le cas metier SU_PEPS
			installedProductId = lignesDeCommande.iterator().next().getAccesLivraison();
		} else {
			final com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.ProductOrderItemType.InstalledProduct installedProduct = customerOrder.getCustomerOrderItem().get(0).getProductOrderItem().get(0).getInstalledProduct();
			if (installedProduct == null) {
				return;
			}
			installedProductId = installedProduct.getInstalledProductID();
		}

		loggerManager.fine(CLASS_NAME, method, "InstalledProductID : " + installedProductId);
		if (CasMetierConstantes.CR_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
				|| CasMetierConstantes.CR_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.MUT_DSLAM.equals(deliverCustomerOrderData.getCasMetier())
				|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && (Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType())))
				|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| SystemeExterneConstantes.NUM_48W.equals(EMETTEUR)) {
			ProduitServiceSouhaite produitServiceSouhaite;
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				produitServiceSouhaite = ligneDeCommande.getProduitServiceSouhaite();
				if (!CasMetierConstantes.VENTE_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
					produitServiceSouhaite.setIdAccesClient(installedProductId);
				}
				produitServiceSouhaite.setIdEPCFutur(installedProductId);
			}
		} else if ((CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_MODIFICATION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
				|| CasMetierConstantes.MO_FTTH.equals(deliverCustomerOrderData.getCasMetier())) {
			ProduitServiceSouhaite produitServiceSouhaite;
			ElementParcAffecte elementParcAffecte;
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				// Gestion ProduitService
				produitServiceSouhaite = ligneDeCommande.getProduitServiceSouhaite();
				produitServiceSouhaite.setIdEPCFutur(installedProductId);
				if (CasMetierConstantes.MO_FTTH.equals(deliverCustomerOrderData.getCasMetier())) {
					produitServiceSouhaite.setIdAccesClient(installedProductId);
				}
				// Gestion EPC
				elementParcAffecte = ligneDeCommande.getElementParcAffecte();
				elementParcAffecte.setIdEPC(installedProductId);
				elementParcAffecte.setIdAccesClient(installedProductId);
			}
		} else {
			ElementParcAffecte elementParcAffecte;
			for (LigneCommandeType ligneDeCommande : lignesDeCommande) {
				elementParcAffecte = ligneDeCommande.getElementParcAffecte();
				elementParcAffecte.setIdEPC(installedProductId);
				elementParcAffecte.setIdAccesClient(installedProductId);
			}
		}
	}

	/**
	 * RG14 : Valorisation de la Hashmap Param�tre Produit ou Service
	 * RG23 : Valorisation de la Hashmap Parametre Element Parc
	 *
	 * @param lignesDeCommande
	 */
	protected void fournirParametrePSouEPC(final Collection<LigneCommandeType> lignesDeCommande) {
		String method = "fournirParametrePSouEPC";
		final Map<String, List<ValeurParametreDTO>> listeOffresElementaires = deliverCustomerOrderData.getListeOffresElementaires();
		String refOffreCible = null;
		Collection<ParametreType> mapParametreProduitService;
		List<ValeurParametreDTO> parametresProduitService;
		final Collection<ParametreType> parametresHorsFunctionSpecification = creerParametresHorsFunctionSpecification();
		loggerManager.finest(CLASS_NAME, method, "Parametres hors function sp�cification : " + parametresHorsFunctionSpecification);
		int i = 0;
		for (LigneCommandeType ligneDeCommande : lignesDeCommande) {

			Collection<ParametreType> parametresProduitServiceFunctionLc = creerParametresProduitServiceFunctionLc(i);

			mapParametreProduitService = new ArrayList<ParametreType>(parametresProduitServiceFunctionLc);
			if (CasMetierConstantes.SU_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
					|| CasMetierConstantes.SU_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
					|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType())) || SystemeExterneConstantes.NUM_49W.equals(EMETTEUR)
					|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| (CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))) {
				refOffreCible = ligneDeCommande.getElementParcAffecte().getRefOffreExistante();
			} else if (CasMetierConstantes.CR_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
					|| CasMetierConstantes.CR_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.MUT_DSLAM.equals(deliverCustomerOrderData.getCasMetier())
					|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_MODIFICATION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| CasMetierConstantes.MO_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
					|| (CasMetierConstantes.CR_PEPS.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| SystemeExterneConstantes.NUM_48W.equals(EMETTEUR)) {
				refOffreCible = ligneDeCommande.getProduitServiceSouhaite().getRefOffreCible();
			}
			parametresProduitService = listeOffresElementaires.get(refOffreCible);
			mapParametreProduitService.addAll(creerMapParametreProduitService(parametresProduitService));
			mapParametreProduitService.addAll(parametresHorsFunctionSpecification);

			// RG14 et RG23 - EPC ou PSS parametre OsirisIdOffreOrigine pour SCE
			if (CasMetierConstantes.CR_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.SU_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
				ParametreType parametreType = new ParametreType();
				parametreType.setCle(ConstantesDynamicPSSouhaite.PSSOUHAITE_OSIRIS_IDOFFREORIG);
				parametreType.setValeur(ligneCommandeToCustomOrderItem.get(ligneDeCommande).getOfferSpecification().getOfferSpecificationCode());
				mapParametreProduitService.add(parametreType);
			}

			// Gestion des cas ADSLE, valorisation de l'OffreCible de l'EpCommercial en suppression
			if (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType())) {
				ParametreType parametreType = new ParametreType();
				parametreType.setCle(ConstantesDynamicEPCommercial.EPCOMMERCIAL_OFFRECIBLE);
				parametreType.setValeur(refOffreCible);
				mapParametreProduitService.add(parametreType);
			}

			if (CasMetierConstantes.CR_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
					|| CasMetierConstantes.CR_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier()) || CasMetierConstantes.MUT_DSLAM.equals(deliverCustomerOrderData.getCasMetier())
					|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_MODIFICATION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| (CasMetierConstantes.CR_PEPS.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_ACQUISITION.equalsIgnoreCase(customerOrder.getCustomerOrderType()))) {
				loggerManager.finest(CLASS_NAME, method, "Parametres produit service pour la ligne de commande " + ligneDeCommande.getIdLigneCommande() + " : " + mapParametreProduitService);
				ligneDeCommande.getProduitServiceSouhaite().setParametreProduitService(mapParametreProduitService.toArray(new ParametreType[0]));
			} else if (CasMetierConstantes.SU_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
					|| CasMetierConstantes.SU_SCE_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())
					|| (CasMetierConstantes.VENTE_FTTH.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType())) || SystemeExterneConstantes.NUM_49W.equals(EMETTEUR)
					|| (CasMetierConstantes.DEG_E.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))
					|| (CasMetierConstantes.SU_PEPS.equals(deliverCustomerOrderData.getCasMetier()) && Constantes.CST_REMOVAL.equalsIgnoreCase(customerOrder.getCustomerOrderType()))) {
				loggerManager.finest(CLASS_NAME, method, "Parametres Element Parc pour la ligne de commande " + ligneDeCommande.getIdLigneCommande() + " : " + mapParametreProduitService);
				ligneDeCommande.getElementParcAffecte().setParametreElementParc(mapParametreProduitService.toArray(new ParametreType[0]));
			} else if (CasMetierConstantes.MO_FTTH_VALEUR_CONSTANTE.equals(deliverCustomerOrderData.getCasMetier())) {
				loggerManager.finest(CLASS_NAME, method, "Parametres produit service pour la ligne de commande " + ligneDeCommande.getIdLigneCommande() + " : " + mapParametreProduitService);
				ligneDeCommande.getProduitServiceSouhaite().setParametreProduitService(mapParametreProduitService.toArray(new ParametreType[0]));
				loggerManager.finest(CLASS_NAME, method, "Parametres Element Parc pour la ligne de commande " + ligneDeCommande.getIdLigneCommande() + " : " + mapParametreProduitService);
				ligneDeCommande.getElementParcAffecte().setParametreElementParc(mapParametreProduitService.toArray(new ParametreType[0]));
			}

			i++;
		}

	}

	/**
	 * RG14 - Cr�e les Param�tres Produit ou service � partir des functions Lc
	 *
	 * @return la liste des ParametresProduitService
	 */
	protected Collection<ParametreType> creerParametresProduitServiceFunctionLc(int i) {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		return new ArrayList<ParametreType>();
	}

	/**
	 * RG14 - Cr�e les param�tre produit service � partir des functions Lc
	 *
	 * @return la liste des ParametresProduitService
	 */
	protected Collection<ParametreType> creerParametresHorsFunctionSpecification() {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		return new ArrayList<ParametreType>();
	}

	/**
	 * RG14 - Cr�e la HashMap ParametreProduitService
	 *
	 * @param parametresProduitService
	 * @return
	 */
	protected Collection<ParametreType> creerMapParametreProduitService(final List<ValeurParametreDTO> parametresProduitService) {
		final Collection<ParametreType> resultat = new ArrayList<ParametreType>();
		ParametreType parametreType;
		StringBuilder cle;
		for (ValeurParametreDTO parametreProduitService : parametresProduitService) {
			parametreType = new ParametreType();
			cle = new StringBuilder(30);
			cle.append(ConstantesDeliverCustomerOrder.PREFIX_PARAM_DET);
			cle.append(parametreProduitService.getParametres().getCode());
			parametreType.setCle(cle.toString());
			parametreType.setValeur(parametreProduitService.getValeur());
			resultat.add(parametreType);
		}
		return resultat;
	}

	/**
	 * RG15 : Intervention et param�tres associ�s
	 *
	 * @param lignesDeCommande la ligne de commande
	 * @param commande la commande
	 * @throws CustomerOrderFault
	 */
	protected abstract void fournirInterventionEtParametresAssocies(final Commande commande, final Collection<LigneCommandeType> lignesDeCommande) throws DeliverCustomerOrderFault;

	/**
	 * RG16 : R�f�rence Offre group�e
	 *
	 * @param lignesCommande
	 * @throws CustomerOrderFault
	 */
	protected Collection<InstanceOffreGroupee> creerOffresGroupees(final Collection<LigneCommandeType> lignesCommande) throws DeliverCustomerOrderFault {
		String method = "creerOffresGroupees";
		if (!TypeOpPonctuellesConstantes.CR.equals(deliverCustomerOrderData.getReferenceOpPonctuelle())) {
			return null;
		}

		loggerManager.finest(CLASS_NAME, method, "Cr�ation des offres groupe�s");
		final Map<String, InstanceOffreGroupee> mapOffresGroupees = new HashMap<String, InstanceOffreGroupee>();
		InstanceOffreGroupee instanceOffreGroupeeActuelle;
		String idOffreGroupe;
		DescOffreGroupeeDTO offreGroupee;
		for (LigneCommandeType ligneCommande : lignesCommande) {
			offreGroupee = determinerOffreGroupee(ligneCommande);
			idOffreGroupe = offreGroupee.getId();
			loggerManager.finest(CLASS_NAME, method, "Id de l'offre groupe� : " + idOffreGroupe);
			if (!mapOffresGroupees.containsKey(idOffreGroupe)) {
				instanceOffreGroupeeActuelle = new InstanceOffreGroupee();
				instanceOffreGroupeeActuelle.setRefOffreGroupee(offreGroupee.getOffreGroupee().getId());
				instanceOffreGroupeeActuelle.addLigneCommande(ligneCommande);
				mapOffresGroupees.put(idOffreGroupe, instanceOffreGroupeeActuelle);
			} else {
				idOffreGroupe = offreGroupee.getId();
				instanceOffreGroupeeActuelle = mapOffresGroupees.get(idOffreGroupe);
				instanceOffreGroupeeActuelle.addLigneCommande(ligneCommande);
			}
		}
		return mapOffresGroupees.values();
	}

	/**
	 * RG16 : Extrait l'offre groupee de la ligne de commande
	 *
	 * @param ligneCommande
	 * @return l'offre groupee
	 * @throws CustomerOrderFault
	 */
	protected DescOffreGroupeeDTO determinerOffreGroupee(final LigneCommandeType ligneCommande) throws DeliverCustomerOrderFault {
		final String refOffreCible;
		final DescGroupeOffresDTO groupeOffre;
		final DescOffreGroupeeDTO offreGroupee;
		refOffreCible = ligneCommande.getProduitServiceSouhaite().getRefOffreCible();
		groupeOffre = CollectionUtils.getFirstOrNull(serviceManager.getReferenceSpaceManager().listInReferenceSpace(DescGroupeOffresDTO.class, new Comparaison(DescGroupeOffres.SLINK_CONTIENT_OFFRE, Constantes.OPERATOR_EQUAL, refOffreCible)));
		if (groupeOffre == null) {
			throw deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(DescGroupeOffres.class.getName(), customerOrder.getCustomerOrderID());
		}
		offreGroupee = CollectionUtils
				.getFirstOrNull(serviceManager.getReferenceSpaceManager().listInReferenceSpace(DescOffreGroupeeDTO.class, new Comparaison(DescOffreGroupee.SLINK_CONTIENT_GROUPE_OFFRES, Constantes.OPERATOR_EQUAL, groupeOffre.getGroupeOffres().getId())));
		if (offreGroupee == null) {
			throw deliverCustomerOrderData.getDeliverCustomerOrderHelper().genererAnomalieErreurTraduction(DescOffreGroupee.class.getName(), customerOrder.getCustomerOrderID());
		}
		return offreGroupee;
	}

	/**
	 * RG25 : Valorise les parametres ligneCommande (cas Mutation DSLAM)
	 *
	 * @throws CustomerOrderFault
	 */
	protected abstract void valorisationParametresLigneCommande(Collection<LigneCommandeType> lignesCommande);

	/**
	 * RG26 : Valorise les contextes ligneCommande (cas Mutation DSLAM)
	 *
	 * @throws CustomerOrderFault
	 */
	protected abstract void valorisationContexteLigneCommande(Collection<LigneCommandeType> lignesCommande);

	/**
	 * RG27 Valorisation des champs dynamique LC pour Vente FTTH
	 *
	 * @param lignesCommande LC � valoriser
	 */
	protected abstract void valorisationChampsDynamiquesLC(Collection<LigneCommandeType> lignesCommande);

	/**
	 * Creer un parametre pour ajouter au parametreDynamic ligneDeCommande
	 *
	 * @param a_key
	 * @param a_value
	 * @return
	 */
	protected ParametreType createParametre(String a_key, String a_value) {
		ParametreType l_param = new ParametreType();
		l_param.setCle(a_key);
		l_param.setValeur(a_value);
		return l_param;
	}

	/**
	 * Permet de traduire une clef de requ�te du nom connu par BOLBEC vers le nom utilis� dans le WS deliverCustomerOrder
	 *
	 * @param parameters la liste des param�tres DCO r�cup�r�s en base
	 * @param bolbecKey la clef telle qu'elle est connue dans BOLBEC
	 * @return la clef telle qu'elle est attendue dans le WS deliverCustomerOrder, null si pas d'occurence trouv�e
	 */
	private String translateKeyParameter(List<InputDynamicCommandeDTO> parameters, String bolbecKey) {
		if (StringUtils.isEmpty(bolbecKey)) {
			return null;
		}
		for (InputDynamicCommandeDTO parameter : parameters) {
			if (parameter != null && bolbecKey.equals(parameter.getCle())) {
				return parameter.getFonction();
			}
		}
		return null;
	}

	/**
	 * RG28 : Valorisation du champ Vendeur
	 *
	 * Rechercher dans l�IC la pr�sence d�un bloc :
	 * IC_CustomerOrder.CouldUseTemporaryContactMethod.ContactMethod.PartyRole avec :
	 * �	partyRoleType = �Vendor�
	 *
	 * Si le bloc est trouv�, r�cup�rer la valeur, si elle existe, depuis ce bloc PartyRole dans le champ :
	 * 	PartyRole.Party.PersonName.lastName
	 */
	protected String recupererIdVendeur () {
		//� ne pas remplir ici que si c'est un cas g�n�rique. Les sp�cifit�s seront d�finis dans les class qui h�ritent
		//� prendre en compte que cette m�thode peut-�tre surcharg� dans les class qui h�ritent
		for (CouldUseTemporaryContactMethodType contact : customerOrder.getCouldUseTemporaryContactMethod()) {
			if (contact.getContactMethod() != null && contact.getContactMethod().getPartyRole() != null
					&& PartyRoleType.VENDOR.equals(contact.getContactMethod().getPartyRole().getPartyRoleType())) {
				return contact.getContactMethod().getPartyRole().getParty().getPersonName().getLastName();
			}
		}
		return null;
	}

	/**
	 * 	RG29 : Valorisation des �l�ments de facturation
	 *
	 *  Si l�IC CustomerOrder poss�de pour la ligne de commande concern�e un bloc FunctionSpecification avec d�termin�s SpecificationCodes (CodeFact, Quantite, Montant, TVA)
	 * 	Alors valoriser, dans la ligne de commande, la donn�e li� � chaque code
	 *
	 * @param lignesDeCommande
	 */
	protected void fournirElementsFacturation (final Collection<LigneCommandeType> lignesDeCommande) {
		ArrayList<LigneCommandeType> ligneCommandeTypesArray = (ArrayList<LigneCommandeType>) lignesDeCommande;
		for (LigneCommandeType ligneDeCommande : ligneCommandeTypesArray) {
			CustomerOrderItemType customerOrderItemType =  customerOrder.getCustomerOrderItem().get(ligneCommandeTypesArray.indexOf(ligneDeCommande));
			for (ProductOrderItemType productOrderItemType : customerOrderItemType.getProductOrderItem()) {
				for (FunctionSpecificationType functionSpecificationType : productOrderItemType.getProductSpecification().getFunctionSpecification()) {
					remplirElementsFacturation(ligneDeCommande, functionSpecificationType);
				}
			}
		}
	}

	/**
	 * remplir les �l�ments de facturation pour chaque lignecommande
	 *
	 * @param ligneDeCommande
	 * @param functionSpecificationType
	 */
	private void remplirElementsFacturation(LigneCommandeType ligneDeCommande, FunctionSpecificationType functionSpecificationType) {
		if (FUNCTION_CODE_FACT.equals(functionSpecificationType.getFunctionSpecificationCode())) {
			ligneDeCommande.setCodeFacturationOffre(functionSpecificationType.getFunctionValueSpecification().getFunctionValue());
		}
		if (FUNCTION_QUANTITE.equals(functionSpecificationType.getFunctionSpecificationCode())) {
			ligneDeCommande.setQuantite(Float.parseFloat(functionSpecificationType.getFunctionValueSpecification().getFunctionValue()));
		}
		if (FUNCTION_MONTANT.equals(functionSpecificationType.getFunctionSpecificationCode())) {
			ligneDeCommande.setMontantLigne(Float.parseFloat(functionSpecificationType.getFunctionValueSpecification().getFunctionValue()));
		}
		if (FUNCTION_TVA.equals(functionSpecificationType.getFunctionSpecificationCode())) {
			ligneDeCommande.setTypeTVA(Float.parseFloat(functionSpecificationType.getFunctionValueSpecification().getFunctionValue()));
		}
	}
}
