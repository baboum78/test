package com.soliste.bolbec.livraison.service.ejb.sb.customerorder;

import javax.ejb.CreateException;
import javax.ejb.EJBLocalHome;

/**
 * Interface Local de l'EJB session CustomerOrderManagerSB.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>31/12/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210 - Offre BVPN&BI FTTH(TRA-12-12) � Cr�ation de la classe </TD></TR>
 * </TABLE>
 * 
 * @author ebaali
 * 
 */
public interface CustomerOrderManagerHome extends EJBLocalHome {

	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public CustomerOrderManagerLocal create() throws CreateException;
}
