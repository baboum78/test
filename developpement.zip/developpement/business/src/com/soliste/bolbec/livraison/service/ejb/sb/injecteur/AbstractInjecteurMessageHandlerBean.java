/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur;

import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.logging.Level;

import javax.ejb.SessionContext;
import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.naming.NamingException;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfPrivilege;
import com.soliste.aps.workflow.WfUser;
import com.soliste.aps.workflow.xpm.wfsessionin.ConstantesXPM;
import com.soliste.bolbec.commun.service.ejb.sb.jms.RollbackHandler;
import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.commun.service.util.jms.QueueHelper;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.WorkflowManager;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.exception.UnavailableTaskException;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.model.CatalogueTachePropertiesDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.CompteRenduDTO;
import com.soliste.bolbec.livraison.service.model.LienCRActiviteDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.TacheManager;

import aps.CatalogueTacheProperties;
import aps.LienCRActivite;

/**
 * Superclasse des injecteurs de messages jms. Cette classe g�re la connexion �
 * la file, les classes qui en h�ritent doivent impl�menter la m�thode
 * <code>getActivationParam</code> qui analyse les messages lus.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>13/12/2010</TD><TD>LBA</TD><TD>Refactoring CAST : utilisation StringUtils pour v�rifier les String vides</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>05/01/2012</TD><TD>GPA</TD><TD>Correction suite � l'audit CAST G7R6C4</TD></TR>
 * <TR><TD>23/10/2013</TD><TD>EBA</TD><TD>G9R0C1 : Corrections sonar</TD></TR>
 * <TR><TD>24/06/2020</TD><TD>ECR</TD><TD>G09R07C14 US-804 : RouteHotline - Contournement PM</TD></TR>
 * </TABLE>
 */
public abstract class AbstractInjecteurMessageHandlerBean extends AbstractMessageHandlerBean {

	private static final String ERROR_QUEUE_CONNECTION_FACTORY_NAME = "jms/errorQueueConnectionFactory";
	private static final String ERROR_QUEUE_NAME = "jms/errorQueue";
	private QueueHelper errorQueueHelper;
	private transient WfUser wfUser = null;

	protected final IServiceManager serviceManager = ServiceManager.getInstance();
	protected final ILoggerManager loggerManager = serviceManager.getLoggerManager();

	/**
	 * createCompteRendu
	 * 
	 * @param idCR identifiant du CR / Requete
	 * @param message le message � stocker
	 * @throws RemoteException
	 */
	public void createCompteRendu(String idCR, Serializable message) {
		CompteRenduDTO compteRendu = new CompteRenduDTO(idCR);
		compteRendu.setMessage(message.toString());
		compteRendu.setDateReception(DateUtils.getDatabaseDate());
		ServiceManager.getInstance().getCompteRenduManager().createCompteRendu(compteRendu);
	}

	/**
	 * getActivationParam
	 * 
	 * @param a_message
	 * @return ActivationParam
	 * @throws InvalidMessageException
	 */
	public abstract ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException;

	/**
	 * @return errorQueueHelper
	 */
	public QueueHelper getErrorQueueHelper() {
		return errorQueueHelper;
	}

	/**
	 * Ecoute la file en attente de nouveaux messages
	 * 
	 * @param a_message
	 * @throws InvalidJmsMessageException
	 */
	public void injecte(Serializable a_message) throws InvalidJmsMessageException {
		QueueConnection queueConnection = null;
		try {
			// Affichage du message dans le fichier de log
			ServiceManager.getInstance().getLoggerManager().info(getClass().getName(), "injecte", "Message re�u : " + a_message.toString());
			processRequest(a_message);
		} catch (RemoteException e) {
			// on veut faire un rollback, donc on lance une ProcessException
			rollback(e);
		} catch (InvalidMessageException ime) {
			// on veut rejeter le message, donc on lance une InvalidJmsMessageException
			// qui n'est pas une ProcessException
			throw new InvalidJmsMessageException(ime.getMessage(), null, ime.getCause());
		} catch (TechnicalBusinessException ime) {
			// on veut rejouer le message, donc on lance une TechnicalBusinessException
			throw ime;
		} catch (Exception t) {
			rollback(t);
		} finally {
			QueueHelper.closeConnection(queueConnection);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractMessageHandlerBean#processMessage(java.io.Serializable)
	 */
	public void processMessage(Serializable a_message) throws InvalidJmsMessageException, TechnicalBusinessException {
		injecte(a_message);
	}

	/**
	 * traitement du message lu dans la file
	 * 
	 * @param a_message message � traiter
	 * @throws RemoteException
	 * @throws Exception
	 */
	public void processRequest(Serializable a_message) throws RemoteException, Exception {
		final String className = getClass().getName();
		final String methodName = "processRequest";
		StringBuilder sbMessage;

		loggerManager.fine(className, methodName, "Traitement du message " + a_message);

		// r�cup�rer l'id de la requ�te � partir du message, ainsi que ActivatedBy
		ActivationParam l_param = getActivationParam(a_message);
		sbMessage = new StringBuilder().append("Message CR pour l'identifiant de requ�te ").append(l_param.getIdRequete());
		sbMessage.append(" et le service d'activation ").append(l_param.getActivatedBy()).append(".");
		loggerManager.fine(className, methodName, sbMessage.toString());

		// stocke le message dans CompteRendu
		createCompteRendu(l_param.getIdRequete(), a_message);

		// poste un message au WF pour notifier de la disponibilit� du compte rendu
		if (StringUtils.isNotEmpty(l_param.getActivatedBy())) {
			activateTasks(l_param);
		}
	}

	/**
	 * initialisation. Positionne les UserId des Logs pour chaque injecteur.
	 * 
	 * @param sessionContext
	 */
	public void setSessionContext(SessionContext sessionContext) {
		super.setSessionContext(sessionContext);
		// Positionnement des UserId des logs � partir du descripteur de d�ploiement
		errorQueueHelper = new QueueHelper(ERROR_QUEUE_CONNECTION_FACTORY_NAME, ERROR_QUEUE_NAME);
	}

	/**
	 * @param a_param param�tres d'activation du CR
	 * @throws InvalidJmsMessageException le message ne peut pas �tre consomm�, ni pourra l'�tre
	 * @throws TechnicalBusinessException une erreur est survenu dans le traitement, le message est � r�-traiter
	 */
	protected void activateTasks(ActivationParam a_param) throws InvalidMessageException, TechnicalBusinessException {
		final String className = getClass().getName();
		final String methodName = "activateTasks";
		StringBuilder sbMessage;

		// Obtenir les identifiants du CR
		String typeCR = a_param.getActivatedBy();
		String idRequete = a_param.getIdRequete();
		String typeRequete = a_param.getTypeRequete();
		if (loggerManager.isLoggable(Level.FINER)) {
			sbMessage = new StringBuilder("Workflow � notifier pour l'identifiant de requ�te ").append(idRequete).append(" et le type CR ").append(typeCR);
			loggerManager.finer(className, methodName, sbMessage.toString());
		}

		// Obtenir la commande et le processus de la commande
		CommandeDTO commande = null;
		ProcessusDTO processus = null;
		if (StringUtils.equals(ActivationParam.TYPE_REQUETE_PROCESSUS, typeRequete)) {
			if ((idRequete != null) && (idRequete.length() > 0)) {
				// Le lastIndexOf "_" permet de r�cup�rer l'idProcessus quelque soit l'idRequete (ex: LY_G6_ln1020162 ou ln1020162)
				String idProcessus = idRequete.substring(idRequete.lastIndexOf("_") + 1);
				if (StringUtils.isNotBlank(idProcessus)) {
					commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessusId(idProcessus);
					processus = ServiceManager.getInstance().getProcessusManager().getProcessus(idProcessus);
				}
			}
		} else if (StringUtils.equals(ActivationParam.TYPE_REQUETE_COMMANDE, typeRequete)) {
			if ((idRequete != null) && (idRequete.length() > 0)) {
				// R�cup�ration de l'identifiant de la commande � partir de l'idRequete
				String idCommande = idRequete.substring(idRequete.lastIndexOf("_") + 1);
				if (StringUtils.isNotBlank(idCommande)) {
					commande = ServiceManager.getInstance().getCommandeManager().getCommande(idCommande);
				}
			}
		}

		// Valider que les objets existent en base, si non, retraiter le message (possible deadlock)
		if (commande == null || (processus == null && StringUtils.equals(ActivationParam.TYPE_REQUETE_PROCESSUS, typeRequete))) {
			sbMessage = new StringBuilder("L'identifiant de requ�te ").append(idRequete).append(" fait r�f�rence � un processus ou commande qui n'a pas �t� trouv� en base. CR � rejouer.");
			loggerManager.warning(getClass().getName(), methodName, sbMessage.toString());
			throw new TechnicalBusinessException(sbMessage.toString());
		}
		if (loggerManager.isLoggable(Level.FINER)) {
			// log des �l�ments r�cup�r�s
			sbMessage = new StringBuilder("L'identifiant de requ�te ").append(idRequete).append(" a permis obtenir");
			sbMessage.append(" la commande : ").append(commande.getId());
			if (processus != null)
				sbMessage.append(" et le processus : ").append(processus.getId());
			loggerManager.finer(className, methodName, sbMessage.toString());
		}

		// R�cup�rer les Processus/Activit� candidates � traiter le CR
		List<LienCRActiviteDTO> lstLienCRActiviteDTO = findCRActivitesByTypeCR(typeCR);
		if (lstLienCRActiviteDTO.isEmpty()) {
			sbMessage = new StringBuilder("Le type de CR ").append(typeCR).append(" n'est pas pr�vu. CR ignor�.");
			loggerManager.warning(className, methodName, sbMessage.toString());
			throw new InvalidMessageException(sbMessage.toString());
		}
		filtrerCRActivitesByProcessus(lstLienCRActiviteDTO, commande, processus);
		if (lstLienCRActiviteDTO.isEmpty()) {
			sbMessage = new StringBuilder("Le type de CR ").append(typeCR).append(" n'est pas pr�vu pour la commande/processus. CR ignor�.");
			loggerManager.warning(className, methodName, sbMessage.toString());
			throw new InvalidMessageException(sbMessage.toString());
		}
		if (loggerManager.isLoggable(Level.FINER)) {
			// log des �l�ments r�cup�r�s
			sbMessage = new StringBuilder("Le type de CR ").append(typeCR).append(" a permis obtenir ").append(lstLienCRActiviteDTO.size()).append(" proc/activit� candidats pour son traitement.");
			loggerManager.finer(className, methodName, sbMessage.toString());
		}

		// Parcours des possibles combinaisons pour activation de la t�che
		boolean bTaskActivated = false;
		String sActivityName = null;
		for (LienCRActiviteDTO lienCRActiviteDTO : lstLienCRActiviteDTO) {
			// Tentative d'activation avec la combinaison Processus / Activit�
			if (activateTasks(idRequete, commande, processus, lienCRActiviteDTO)) {
				sActivityName = lienCRActiviteDTO.getDemandeActivite();
				bTaskActivated = true;
				break;
			}
		}

		// Traitement en fonction de l'activit� r�alis�e
		if (bTaskActivated) {
			// log des op�rations r�alis�es
			if (loggerManager.isLoggable(Level.FINER)) {
				// log des op�rations r�alis�es
				sbMessage = new StringBuilder("Le CR avec identifiant ").append(idRequete).append(" a permis l'activation de l'activit� ").append(sActivityName).append(". CR consomm�.");
				loggerManager.finer(className, methodName, sbMessage.toString());
			}
		} else {
			// Si aucune tache n'a �t� identifi�, des nouvelles tentatives sont pr�vues (TechnicalBusinessException)
			sbMessage = new StringBuilder("Le CR avec identifiant ").append(idRequete).append(" n'est pour le moment consommable. CR � rejouer.");
			loggerManager.warning(getClass().getName(), methodName, sbMessage.toString());
			throw new TechnicalBusinessException(sbMessage.toString());
		}
	}

	/**
	 * @param idRequete l'identifiant du CR
	 * @param commande la commande, identifi�e � partir de l'idRequete
	 * @param processus le processus, si c'est le cas, identifi� � partir de l'idRequete
	 * @param lienCRActiviteDTO la combinaison de processus / activit� candidate pour le traitement du CR
	 * @return true si une activit� a �t� r�veill�
	 * @throws InvalidJmsMessageException le message ne peut pas �tre consomm�, ni pourra l'�tre
	 * @throws TechnicalBusinessException une erreur est survenu dans le traitement, le message est � r�-traiter
	 */
	protected boolean activateTasks(String idRequete, CommandeDTO commande, ProcessusDTO processus, LienCRActiviteDTO lienCRActiviteDTO) throws InvalidMessageException, TechnicalBusinessException {
		final String className = getClass().getName();
		final String methodName = "activateTasks";
		StringBuilder sbMessage;

		// Pr�-contr�le
		if (StringUtils.isBlank(idRequete) || commande == null || lienCRActiviteDTO == null) {
			return false;
		}

		// Obtenir les processus et activit� du lien
		String processusType = lienCRActiviteDTO.getProcessus();
		String activityName = lienCRActiviteDTO.getDemandeActivite();
		loggerManager.finer(className, methodName, "Tentative de traitement avec le processus " + processusType + " et l'activit� " + activityName + ".");

		// Contr�le du type de processus, si un processus est d�j� identifi� (un filtre aura �t� d�j� fait en avance, mais au cas o�)
		if (processus != null && !StringUtils.equals(processusType, processus.getProcessusType().getId())) {
			loggerManager.finer(className, methodName, "Le processus " + processus.getId() + " n'est pas du type " + processusType + ".");
			return false;
		}

		// La t�che qui sera � r�veiller
		TacheDTO tacheDTO = null;

		// R�cup�re la/les t�ches , � partir des t�ches en cours pour la commande et processus type
		List<TacheDTO> lstTachesDTOEnCours = findTachesByTacheEnCours(commande, processus, processusType, activityName);
		if (!lstTachesDTOEnCours.isEmpty()) {
			loggerManager.finer(className, methodName, "La recherche par t�che en cours � trouv� " + lstTachesDTOEnCours.size() + " t�ches compatibles.");

			// Si des t�ches en cours existent pour les crit�res, les parcourir pour chercher les d'AVP � fermer.
			tacheDTO = choisirTacheEtCloturerAVPs(commande, processus, processusType, activityName, lstTachesDTOEnCours);
		}
		if (tacheDTO != null) {
			loggerManager.fine(className, methodName, "La t�che en cours " + tacheDTO.getId() + " de type " + tacheDTO.getLibelleCourt() + " sera utilis�e.");
		} else {
			loggerManager.finer(className, methodName, "La recherche par t�che en cours n'a trouv�e aucune t�che compatible.");
		}

		// R�cup�re la/les t�ches, � partir de la derni�re date d'instanciation.
		if (tacheDTO == null) {
			List<TacheDTO> lstTachesDTO = findTachesByDate(commande, processus, processusType, activityName);
			if (!lstTachesDTO.isEmpty()) {
				loggerManager.finer(className, methodName, "La recherche par date � trouv� " + lstTachesDTO.size() + " t�ches compatibles.");

				tacheDTO = lstTachesDTO.get(0);
				loggerManager.fine(className, methodName, "La t�che " + tacheDTO.getId() + " de type " + tacheDTO.getLibelleCourt() + " sera utilis�e.");
			} else {
				loggerManager.finer(className, methodName, "La recherche par date n'a trouv�e aucune t�che compatible.");
			}
		}

		// Si une t�che a �t� trouv�e, on l'utilise pour la notification
		if (tacheDTO == null) {
			loggerManager.finer(className, methodName, "Aucune t�che n'a �t� trouv� pour cette combinaison de processus/activit�.");
			return false;
		} else {
			// Notification au workflow pour demande d'ex�cution de la t�che de r�ponse sur l'activity
			serviceManager.getWorkflowManager().envoyerCR(getEmptyWfUser(), commande.getId(), tacheDTO.getLancerParProcessus().getId(), tacheDTO.getId(), idRequete, activityName);

			// return true;
			loggerManager.fine(className, methodName, "Activation envoy� pour l'activit� " + activityName + " de la commande " + commande.getId());
			return true;
		}
	}

	/**
	 * M�thode permettant de r�cup�rer l'activit� associ�e � un type de CR
	 */
	private List<LienCRActiviteDTO> findCRActivitesByTypeCR(String typeCR) {
		List<LienCRActiviteDTO> lienCRActiviteDTOList = Collections.EMPTY_LIST;
		if (StringUtils.isBlank(typeCR)) {
			return lienCRActiviteDTOList;
		}

		Comparaison cmpCr = new Comparaison(LienCRActivite.FIELD_TYPE_CR, Constantes.OPERATOR_EQUAL, typeCR);
		return serviceManager.getReferenceSpaceManager().listInReferenceSpace(LienCRActiviteDTO.class, cmpCr);
	}

	/**
	 * M�thode permettant le filtrage des CRActivites par la commande et processus identifi�s
	 * 
	 * @param lienCRActiviteDTOList la liste de CRActivites � parcourir
	 * @param commande la commande
	 * @param processus le processus
	 */
	private void filtrerCRActivitesByProcessus(List<LienCRActiviteDTO> lienCRActiviteDTOList, CommandeDTO commande, ProcessusDTO processus) {
		// Si la liste est d�j� vide, pas de filtrage, on retourne la liste.
		if (lienCRActiviteDTOList == null || lienCRActiviteDTOList.isEmpty()) {
			return;
		}

		// Si la commande ou le processus sont vides, pas de filtrage, on retourne la liste
		if (commande == null || processus == null) {
			return;
		}

		// Enleve de la liste les �l�ments qui ne correspond pas avec le processus connu
		for (Iterator<LienCRActiviteDTO> itrLienCRActiviteDTO = lienCRActiviteDTOList.iterator(); itrLienCRActiviteDTO.hasNext();) {
			LienCRActiviteDTO lienCRActiviteDTO = itrLienCRActiviteDTO.next();
			if (!StringUtils.equals(processus.getProcessusType().getId(), lienCRActiviteDTO.getProcessus())) {
				itrLienCRActiviteDTO.remove();
			}
		}
	}

	/**
	 * R�cup�re les t�ches en cours de la commande, puis les filtre avec le processus, processusType et activityName re�us
	 * 
	 * @param commande la commande de l'idRequete
	 * @param processus le processus de l'idRequete
	 * @param processusType le type de processus du CR
	 * @param activityName le nom de l'activit� du CR
	 * @return la liste de taches identifi�es
	 */
	List<TacheDTO> findTachesByTacheEnCours(CommandeDTO commande, ProcessusDTO processus, String processusType, String activityName) {
		final String className = getClass().getName();
		final String methodName = "findTachesByTacheEnCours";

		// Pr�-contr�le
		if (commande == null || StringUtils.isBlank(processusType) || StringUtils.isBlank(activityName)) {
			return Collections.EMPTY_LIST;
		}

		// Obtenir les t�ches en cours
		List<TacheEnCoursDTO> lstTacheEnCoursDTO = serviceManager.getProcessusManager().findTacheEnCoursByCommande(commande.getId());
		if (lstTacheEnCoursDTO == null || lstTacheEnCoursDTO.isEmpty()) {
			return Collections.EMPTY_LIST;
		}
		loggerManager.finer(className, methodName, "R�cup�ration de " + lstTacheEnCoursDTO.size() + " t�ches en cours.");

		// Parcourir la liste pour utiliser la t�che si correspond avec le processus et l'activit�
		List<TacheDTO> lstTacheDTO = new ArrayList<TacheDTO>();

		for (TacheEnCoursDTO tacheEnCoursDTO : lstTacheEnCoursDTO) {
			// Valider le processus de la tache en cours
			if (processus != null) {
				// Valider que la t�che en cours appartient � notre processus.
				if (!StringUtils.equals(processus.getId(), tacheEnCoursDTO.getIdProcess())) {
					loggerManager.finer(className, methodName, "T�che en cours " + tacheEnCoursDTO.getId() + " ignor�e car le processus n'est pas l'attendu.");
					continue;
				}
			} else {
				// Obtenir le processus de la TC, et valider qu'il est du bon type
				ProcessusDTO processusDTOByTC = serviceManager.getProcessusManager().getProcessus(tacheEnCoursDTO.getIdProcess());
				if (processusDTOByTC == null || StringUtils.equals(processusType, processusDTOByTC.getProcessusType().getId())) {
					loggerManager.finer(className, methodName, "T�che en cours " + tacheEnCoursDTO.getId() + " ignor�e car le type processus n'est pas l'attendu.");
					continue;
				}
			}

			// Valider la Tache et l'activit�
			TacheDTO tacheDTO = serviceManager.getProcessusManager().getTache(tacheEnCoursDTO.getId());
			if (tacheDTO == null) {
				// La t�che n'existe plus ??
				loggerManager.finer(className, methodName, "T�che en cours " + tacheEnCoursDTO.getId() + " ignor�e car la t�che n'existe plus en base.");
				continue;
			} else if ((tacheDTO.getCatalogueActivite() != null) && !StringUtils.equals(activityName, tacheDTO.getCatalogueActivite().getId())) {
				// La t�che est d'une activit� diff�rente.
				loggerManager.finer(className, methodName, "T�che en cours " + tacheEnCoursDTO.getId() + " ignor�e car l'activit� n'est pas l'attendue.");
				continue;
			}

			// Toutes les validations effectu�es, la t�che est candidate, on l'ajoute � la liste
			loggerManager.finer(className, methodName, "T�che en cours " + tacheEnCoursDTO.getId() + " r�cup�r�e.");
			lstTacheDTO.add(tacheDTO);
		}

		return lstTacheDTO;
	};

	/**
	 * � partir d'une liste de t�ches en cours de la commande, choisit la plus ad�quate, et ferme les AVPs.
	 * 
	 * @param commande la commande de l'idRequete
	 * @param processus le processus de l'idRequete
	 * @param processusType le type de processus du CR
	 * @param activityName le nom de l'activit� du CR
	 * @param lstTachesDTO la liste de t�ches en cours identifi�e en pr�alable.
	 * @return la liste de taches identifi�es
	 */
	TacheDTO choisirTacheEtCloturerAVPs(CommandeDTO commande, ProcessusDTO processus, String processusType, String activityName, List<TacheDTO> lstTachesDTO) {
		final String className = getClass().getName();
		final String methodName = "choisirTacheEtCloturerAVPs";

		TacheDTO retNotFound = null;

		// Pr�-contr�le
		if (commande == null || StringUtils.isBlank(processusType) || StringUtils.isBlank(activityName) || lstTachesDTO == null || lstTachesDTO.isEmpty()) {
			return retNotFound;
		}

		TacheDTO retTacheDTO = retNotFound;
		for (TacheDTO tacheDTOCandidate : lstTachesDTO) {
			// Valider la candidature de la t�che - typologie du traitement
			CatalogueTachePropertiesDTO catalogueTachePropertiesDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTachePropertiesDTO.class,
					new Comparaison(CatalogueTacheProperties.FIELD_POUR_TACHE, Constantes.OPERATOR_EQUAL, tacheDTOCandidate.getCatalogueTache().getId()));
			if (catalogueTachePropertiesDTO == null) {
				// La validation n'est pas possible.
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " de type " + tacheDTOCandidate.getLibelleCourt() + " ne permet pas la r�cup�ration des propri�t�s.");
				continue;
			}

			// Valider la candidature de la t�che - la t�che doit appartenir � notre activit�
			if (tacheDTOCandidate.getCatalogueActivite() != null && !StringUtils.equals(activityName, tacheDTOCandidate.getCatalogueActivite().getId())) {
				// La t�che ne correspond pas avec l'activit�
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " est ignor�e car l'activit� n'est pas l'attendue.");
				continue;
			}

			// D�terminer quoi faire avec la t�che candidate
			if (StringUtils.equals(Constantes.CST_CATALOGUETACHE_TYPETRAITEMENT_REPONSE, catalogueTachePropertiesDTO.getTypeTraitement())) {
				// Si la t�che est une t�che de r�ponse, pr�conisation pour l'utiliser pour le traitement.
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " de type " + tacheDTOCandidate.getLibelleCourt() + " est propos�e car elle est une t�che de r�ponse.");
				retTacheDTO = tacheDTOCandidate;
			} else if (StringUtils.equals(Constantes.CST_CATALOGUETACHE_TYPE_AVP, catalogueTachePropertiesDTO.getTypeTraitement())) {
				// Si la t�che est une t�che AVP
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " de type " + tacheDTOCandidate.getLibelleCourt() + " est une AVP � fermer.");
				cloturerAVP(commande, tacheDTOCandidate);
				retTacheDTO = tacheDTOCandidate;
			} else if (StringUtils.equals(Constantes.CST_CATALOGUETACHE_TYPETRAITEMENT_DEMANDE, catalogueTachePropertiesDTO.getTypeTraitement())) {
				// Si la t�che en cours est une t�che de demande, c'est normal de recevoir une CR. On la traite, mais avec moins priorit�.
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " de type " + tacheDTOCandidate.getLibelleCourt() + " est consid�r�e moins prioritaire.");
				if (retTacheDTO == null) {
					retTacheDTO = tacheDTOCandidate;
				}
			} else {
				// Si la t�che n'est pas une t�che pr�vue, on passe � la suivante.
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " de type " + tacheDTOCandidate.getLibelleCourt() + " est consid�r�e moins prioritaire.");
				continue;
			}
		}

		return retTacheDTO;
	}

	/**
	 * Cl�ture une tache AVP. Si un probl�me apparait, on consid�re que la priorit� est traiter le message.
	 * 
	 * @param commandeDTO la commande
	 * @param tacheDTO la tache AVP � cl�turer
	 * @return la liste de taches identifi�es
	 */
	private void cloturerAVP(CommandeDTO commandeDTO, TacheDTO tacheDTO) {
		final String className = getClass().getName();
		final String methodName = "cloturerAVP";

		try {
			WfUser wfUser = getEmptyWfUser();
			WorkflowManager workflowManager = serviceManager.getWorkflowManager();
			WfActivity wfActivity = workflowManager.getWfActivity(wfUser, commandeDTO.getId(), tacheDTO.getId());
			serviceManager.getTacheManager().cloturerTache(tacheDTO, wfActivity.getValues(), false, false, false, wfUser);
			workflowManager.forcerReservation(wfActivity, wfUser.getFullName());
			workflowManager.liberer(wfActivity);
		} catch (UnavailableTaskException e) {
			loggerManager.warning(className, methodName, "La t�che " + tacheDTO.getId() + " de type " + tacheDTO.getLibelleCourt() + " a une un probl�me pendant la lib�ration.", e);
		}
	}

	/**
	 * R�cup�re les t�ches de la commande par type de processus
	 * , puis les tri et les filtre avec le processus, processusType et activityName re�us
	 * 
	 * @param commande la commande de l'idRequete
	 * @param processus le processus de l'idRequete
	 * @param processusType le type de processus du CR
	 * @param activityName le nom de l'activit� du CR
	 * @return la liste de taches identifi�es
	 */
	List<TacheDTO> findTachesByDate(CommandeDTO commande, ProcessusDTO processus, String processusType, String activityName) {
		final String className = getClass().getName();
		final String methodName = "findTachesByDate";

		List<TacheDTO> retNotFound = Collections.EMPTY_LIST;
		// Pr�-contr�le
		if (commande == null || StringUtils.isBlank(processusType) || StringUtils.isBlank(activityName)) {
			return retNotFound;
		}

		// Obtenir le processus par type, si il n'a pas encore �t� trouv�
		if (processus == null) {
			List<ProcessusDTO> lstProcessus = serviceManager.getProcessusManager().findProcessusByCommande(commande.getId());
			for (ProcessusDTO processusCommande : lstProcessus) {
				if (StringUtils.equals(processusType, processusCommande.getProcessusType().getId())) {
					processus = processusCommande;
					break;
				}
			}
		}
		// Valider qu'un processus a �t� trouv� / re�u
		if (processus == null) {
			// Si Aucune processus re�u ni r�cup�r�, pas de t�che possible
			loggerManager.finer(className, methodName, "Processus inconnu, impossible faire une recherche de t�ches.");
			return retNotFound;
		} else {
			loggerManager.finer(className, methodName, "Processus " + processus.getId() + " utilis� pour la recherche de t�ches.");
		}

		// Obtenir la derni�re t�che instanci�e par le processus
		List<TacheDTO> lstTaches = serviceManager.getProcessusManager().findTacheByLanceParProcessusRangeParDate(processus.getId());
		if ((lstTaches == null) || lstTaches.isEmpty()) {
			// Si Aucune t�che candidate, pas de t�che possible
			loggerManager.finer(className, methodName, "La recherche par processus n'a trouv� aucune t�che candidate.");
			return retNotFound;
		} else {
			loggerManager.finer(className, methodName, "La recherche par processus a trouv� " + lstTaches.size() + " t�ches.");
		}
		TacheDTO tacheDTOCandidate = lstTaches.get(lstTaches.size() - 1);
		loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " de type " + tacheDTOCandidate.getLibelleCourt() + " est consid�r�e la t�che candidate.");

		// Valider la candidature de la t�che - la t�che doit appartenir � notre activit�
		if (tacheDTOCandidate.getCatalogueActivite() != null && !StringUtils.equals(activityName, tacheDTOCandidate.getCatalogueActivite().getId())) {
			// La t�che ne correspond pas avec l'activit�
			loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " est ignor�e car l'activit� n'est pas l'attendue.");
			return retNotFound;
		}

		// Valider la candidature de la t�che - typologie du traitement
		CatalogueTachePropertiesDTO catalogueTachePropertiesDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTachePropertiesDTO.class,
				new Comparaison(CatalogueTacheProperties.FIELD_POUR_TACHE, Constantes.OPERATOR_EQUAL, tacheDTOCandidate.getCatalogueTache().getId()));
		if (catalogueTachePropertiesDTO == null) {
			// La validation n'est pas possible.
			loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " est ignor�e car les propri�t�s n'ont pas �t� trouv�es.");
			return retNotFound;
		}
		if (StringUtils.equals(Constantes.CST_CATALOGUETACHE_TYPETRAITEMENT_DEMANDE, catalogueTachePropertiesDTO.getTypeTraitement())) {
			// Si la derni�re t�che est une t�che de demande, c'est normal de recevoir une CR
			loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " utilis�e car elle est une t�che de demande.");
		} else if (StringUtils.equals(Constantes.CST_CATALOGUETACHE_TYPETRAITEMENT_REPONSE, catalogueTachePropertiesDTO.getTypeTraitement())) {
			// Si la derni�re t�che est une t�che de r�ponse, c'est normal si elle n'est pas ferm�e, mais pas si elle l'est.
			if (StringUtils.equals(TacheManager.INDICATEUR_DONE, tacheDTOCandidate.getIndicateurFin())) {
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " est ignor�e car elle est une t�che de r�ponse termin�e.");
				return retNotFound;
			} else {
				loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " est utilis�e car elle est une t�che de r�ponse non termin�e.");
			}
		} else {
			// Si la derni�re t�che est une t�che diff�rente (avp, manuel, etc...), mais pas de t�che en cours... pas trait�e.
			loggerManager.finer(className, methodName, "La t�che " + tacheDTOCandidate.getId() + " est ignor�e car elle est n'est pas une t�che de demande/r�ponse.");
			return retNotFound;
		}

		// Toutes les validations ont �t� pass�es
		return Collections.singletonList(tacheDTOCandidate);

	};

	/**
	 * M�thode qui cr�� un WFUser bidon, ce qui suffi pour l'activation d'une
	 * tache sur reception de CR
	 *
	 * @return WFUser vide (valeurs bidons)
	 */
	protected WfUser getEmptyWfUser() {
		if (wfUser == null) {
			WfPrivilege l_priv = new WfPrivilege(ConstantesXPM.WF_STEP_AUTO_PRIVILEGE);
			wfUser = new WfUser(ConstantesXPM.WF_STEP_AUTO_PRIVILEGE, new WfPrivilege[] { l_priv });
		}
		return wfUser;
	}

	/**
	 *
	 * @inherit com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractMessageHandlerBean#rejectMessage(javax.jms.Message, java.lang.String, java.lang.String)
	 */
	protected void rejectMessage(Message a_message, String a_causeId, String a_diagnostic) {
		String methode = "rejectMessage";

		QueueConnection queueConnection = null;
		try {
			queueConnection = errorQueueHelper.createConnection();
			QueueSession queueSession = queueConnection.createQueueSession(true, 0);
			QueueSender queueSender = queueSession.createSender(errorQueueHelper.getQueue());
			Serializable l_msg = getMessageContent(a_message);
			ObjectMessage msg = queueSession.createObjectMessage(l_msg);
			ServiceManager.getInstance().getLoggerManager().severe(getClass().getName(), methode, "Message rejet� : " + l_msg + " - cause : " + a_causeId + " - diagnostic : " + a_diagnostic);
			queueSender.send(msg);
		} catch (InvalidJmsMessageException e) {
			// on ne fait rien: on ne peut pas rejeter le message proprement,
			// et �a ne sert � rien de faire un rollback sinon on va devoir retraiter le message
			ServiceManager.getInstance().getLoggerManager().fine(getClass().getName(), methode, "InvalidJmsMessageException => on ne fait rien");
		} catch (JMSException e) {
			errorQueueHelper.invalidate();
			rollback(e);
		} catch (NamingException e) {
			ServiceManager.getInstance().getLoggerManager().severe(getClass().getName(), methode, "Impossible d'utiliser le QueueHelper", e);
			rollback(e);
		} finally {
			QueueHelper.closeConnection(queueConnection);
		}
	}

	/**
	 * La m�me mais avec une HashMap en entr�e
	 *
	 * @param a_message
	 * @param a_causeId
	 * @param a_diagnostic
	 */
	protected void rejectMessage(Serializable a_message, String a_causeId, String a_diagnostic) {
		QueueConnection queueConnection = null;
		try {
			queueConnection = errorQueueHelper.createConnection();
			QueueSession queueSession = queueConnection.createQueueSession(true, 0);
			QueueSender queueSender = queueSession.createSender(errorQueueHelper.getQueue());
			// Serializable l_msg = getMessageContent(a_message);
			ObjectMessage msg = queueSession.createObjectMessage(a_message);
			ServiceManager.getInstance().getLoggerManager().severe(getClass().getName(), "rejectMessage", "Message rejet� : " + a_message + " - cause : " + a_causeId + " - diagnostic : " + a_diagnostic);
			queueSender.send(msg);
			// } catch (bolbec.interfaces.commun.protocol.jms.InvalidJmsMessageException e) {
			// on ne fait rien: on ne peut pas rejeter le message proprement,
			// et �a ne sert � rien de faire un rollback sinon on va devoir
			// retraiter
			// le message
		} catch (JMSException e) {
			errorQueueHelper.invalidate();
			rollback(e);
		} catch (NamingException e) {
			ServiceManager.getInstance().getLoggerManager().severe(getClass().getName(), "rejectMessage", "Impossible d'utiliser le QueueHelper", e);
			rollback(e);
		} finally {
			QueueHelper.closeConnection(queueConnection);
		}
	}

	@Override
	public void ejbCreate() {
		this.rollbackHandler = new RollbackHandler(true);
	}
}
