/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import java.io.Serializable;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import aps.ParametreArtemis;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.ResponsabiliteDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * </TABLE><BR>
 */

/**
 * Donn�es de r�f�rence pour la recherche de plages
 */
public class RechercherPlageReferenceDataDTO implements Serializable {

	private InterventionDTO intervention;
	private List<ResponsabiliteDTO> responsabilites;
	private Date defaultStartDate;
	private Date defaultEndDate;

	/**
	 * 
	 * @param intervention
	 * @param responsabilites
	 */
	public RechercherPlageReferenceDataDTO(InterventionDTO intervention, List<ResponsabiliteDTO> responsabilites) {
		this.intervention = intervention;
		this.responsabilites = responsabilites;
		Calendar start = Calendar.getInstance();
		Calendar end = Calendar.getInstance();
		int startOffset = findParametreArtemis("DEBUT_RECH_PLAGE", 3);
		int endOffset = findParametreArtemis("FIN_RECH_PLAGE", 33);
		start.add(Calendar.DATE, startOffset);
		end.add(Calendar.DATE, endOffset);
		this.defaultStartDate = start.getTime();
		this.defaultEndDate = end.getTime();
	}

	private static int findParametreArtemis(String cle, int defaultValue) {
		List<ParametreArtemisDTO> parametres = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ParametreArtemisDTO.class, new Comparaison(ParametreArtemis.FIELD_CLE_PARAMETRE, Constantes.OPERATOR_EQUAL, cle));
		for (ParametreArtemisDTO parametre : parametres) {
			String val = parametre.getValeurParametre();
			if (val != null) {
				try {
					return Integer.parseInt(val);
				} catch (NumberFormatException e) {
					return defaultValue;
				}
			}
			return defaultValue;
		}
		return defaultValue;
	}

	public Date getDefaultStartDate() {
		return this.defaultStartDate;
	}

	void setDefaultStartDate(Date defaultBeginDate) {
		this.defaultStartDate = defaultBeginDate;
	}

	public Date getDefaultEndDate() {
		return this.defaultEndDate;
	}

	void setDefaultEndDate(Date defaultEndDate) {
		this.defaultEndDate = defaultEndDate;
	}

	public List<ResponsabiliteDTO> getResponsabilites() {
		return this.responsabilites;
	}

	void setResponsabilites(List<ResponsabiliteDTO> responsabilites) {
		this.responsabilites = responsabilites;
	}

	public InterventionDTO getIntervention() {
		return this.intervention;
	}

	void setIntervention(InterventionDTO intervention) {
		this.intervention = intervention;
	}
}
