/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.io.Serializable;

/**
 * Pr�f�rences pour un filtre de type date
 * 
 * @author rgvs7490
 */
public class DateFiltrePreference implements Serializable {

	private String id;
	private String dateId;

	/**
	 * @param id
	 * @param dateId
	 */
	public DateFiltrePreference(String id, String dateId) {
		this.id = id;
		this.dateId = dateId;
	}

	/**
	 * @return id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * @return date
	 */
	public String getDateId() {
		return this.dateId;
	}
}
