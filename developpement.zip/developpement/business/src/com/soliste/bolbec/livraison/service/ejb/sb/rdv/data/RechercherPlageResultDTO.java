/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import java.io.Serializable;
import java.util.List;

import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.Plage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.CritereIntervention;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe contenant les r�sultats d'une recherche de plage
 */
public class RechercherPlageResultDTO implements Serializable {

	private List<Plage> plages;
	private CritereIntervention critereIntervention;
	private String warning;

	/**
	 * 
	 * @param plages
	 * @param critereIntervention
	 * @param warning
	 */
	public RechercherPlageResultDTO(List<Plage> plages, CritereIntervention critereIntervention, String warning) {
		this.plages = plages;
		this.critereIntervention = critereIntervention;
		this.warning = warning;
	}

	public List<Plage> getPlages() {
		return this.plages;
	}

	public CritereIntervention getCritereIntervention() {
		return this.critereIntervention;
	}

	/**
	 * Retourne l'avertissament g�n�r� par la recherche de plages,
	 * ou null s'il n'ya a pas eu d'avertissement
	 */
	public String getWarning() {
		return this.warning;
	}
}
