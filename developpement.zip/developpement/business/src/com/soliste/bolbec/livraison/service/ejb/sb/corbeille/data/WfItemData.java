/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.util.List;
import java.util.Map;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfException;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;

/**
 * Interface pour les donn�es d'un item corbeille (avec information du workflow)
 * 
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/11/2019</TD><TD>SOP</TD><TD>US-674: Corbeille WF</TD></TR>
 * 
 */
public interface WfItemData extends ItemData {
	WfActivity getWfObject();

	Map<String, List<String>> getStaticAttributes() throws DataException;

	Object getStaticAttribute(String key) throws WfException;
}
