/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.rdv;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import com.soliste.aps.workflow.WfException;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.constante.FiltreSappuieSur;
import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.commun.service.interfaces.util.cxf.io.InfoMessageWebSrv;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesParametreArtemis;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.anomalies.Evenement;
import com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager;
import com.soliste.bolbec.livraison.service.anomalies.SFAno;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.WfServices;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.data.AccesLivraisonKey;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ContexteModification;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.DayOfWeek;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.Duration;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ExtendedInterventionDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.InterventionModification;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.LibererPlageResultDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.MomentInDay;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.NatureIntervention;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.RechercherPlageReferenceDataDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.RechercherPlageResultDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.RendezVousDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ReserverPlageResultDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.exception.LibererPlageException;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.exception.RechercherPlageException;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.exception.ReserverPlageException;
import com.soliste.bolbec.livraison.service.enumeration.TypeAccesLivraisonEnum;
import com.soliste.bolbec.livraison.service.interfaces.commun.CommandeTraitee;
import com.soliste.bolbec.livraison.service.interfaces.commun.RTechnique;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.InterventionReservee;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.Plage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionintervention.LancerIntervention;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionintervention.data.CritereAppel;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionintervention.data.IOLancerIntervention;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionintervention.data.InterventionALancer;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.commun.gestionintervention.data.GpcDeclarations;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.CritereAdresseEtPlages;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.CritereIntervention;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.IOLibererPlage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.IOModifierPlage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.IORechercherPlages;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.IOReserverPlage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionressourcestechniquesbl.RechCentreZoneTransport;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionressourcestechniquesbl.data.IORechCentreZoneTransport;
import com.soliste.bolbec.livraison.service.interfaces.util.InterventionUtil;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.AnomalieDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatInterventionDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.InstanceSeDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RepartiteurDTO;
import com.soliste.bolbec.livraison.service.model.ResponsabiliteDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TypeOpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.stepauto.traitements.InterventionTraitement;
import com.soliste.bolbec.livraison.service.util.DateAndTimerUtil;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.TraductionManager;

import aps.AnomalieConstantes;
import aps.CasMetierConstantes;
import aps.CategorieEvenementConstantes;
import aps.EtatCommandeConstantes;
import aps.EtatInterventionConstantes;
import aps.EtatProcessusConstantes;
import aps.Evt;
import aps.EvtHome;
import aps.Intervention;
import aps.InterventionHome;
import aps.MessagesConstantes;
import aps.ParametreArtemis;
import aps.ProcessusTypeConstantes;
import aps.Repartiteur;
import aps.ResponsabiliteConstantes;
import aps.RessourceTechConstantes;
import aps.ServiceExterneConstantes;
import aps.StatutCommandeConstantes;
import aps.SystemeExterne;
import aps.SystemeExterneConstantes;
import aps.TraitementConstantes;
import aps.TypeOpPonctuellesConstantes;
import aps.TypeOpProgrammeeConstantes;

import static org.apache.commons.lang3.StringUtils.join;

/**
 * Impl�mentation de l'EJB session RendezVousManager.
 * 
 * @see RendezVousManager
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/02/2010</TD><TD>DBA</TD><TD>EV-000029[3]: Sauvegarde de la valeur MESCONTR dans XPM ExtraInfo</TD></TR>
 * <TR><TD>25/02/2010</TD><TD>DBA</TD><TD>IRMA_151: Factorisation code</TD></TR>
 * <TR><TD>20/05/2010</TD><TD>YTR</TD><TD>IRMA_174: Appel � tort du SF_ERDV_NotifierNouvelleIntervention</TD></TR>
 * <TR><TD>09/08/2010</TD><TD>YTR</TD><TD>Refactor generation manager</TD></TR>
 * <TR><TD>27/09/2010</TD><TD>YTR</TD><TD>Suppression ServiceUtil</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>GPA</TD><TD>Suppression des appels aux classes LocalisationTraitement et IdGenerator</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Refactor CAST : suppression classe deprecated GestionAnomalie</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>07/02/2011</TD><TD>GPE</TD><TD>IRMA_946: Retour Null sur Web Service NotificationModificationErdv</TD></TR>
 * <TR><TD>13/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1236 Correction d'anomalies trouv�es par FindBugs</TD></TR>
 * <TR><TD>18/05/2011</TD><TD>CCL</TD><TD>IRMA 980 : Perte des donn�es Observation sur les interventions</TD></TR>
 * <TR><TD>22/06/2011</TD><TD>CCL</TD><TD>IRMA 971 : Erreur parfois lors modification ou r�servation de RDV</TD></TR>
 * <TR><TD>14/09/2011</TD><TD>GPA</TD><TD>EV-000167: Modif de rendez-vous non report�e dans BOLBEC</TD></TR>
 * <TR><TD>25/06/2012</TD><TD>GPA</TD><TD>EV-000188: Vente FTTH - Ajout de finders</TD></TR>
 * <TR><TD>10/09/2012</TD><TD>EBA</TD><TD>Defect MCO 126 - Valorisation du MESContr de la nouvelle intervention avec celui de l'ancienne</TD></TR>
 * <TR><TD>17/10/2012</TD><TD>FTE</TD><TD>EV-000083: Si la modification du RDV intervient sur une commande en cours de requalification dans le sous-processus Bilan Affectation Configuration, le d�lai de temporisation doit �tre de nouveau calcul�
 * <TR><TD>23/09/2013</TD><TD>BPE</TD><TD>G8R2C3 � EV-000264 : Ajout de la m�thode getRendezVousParCommandeRef</TD></TR>
 * <TR><TD>16/10/2013</TD><TD>BPE</TD><TD>G8R2C3 - EV-000250 "Correction mineure"</TD></TR>
 * <TR><TD>11/02/2014</TD><TD>VDE</TD><TD>G8R2C4 - QC-001005 "GPC Champ Observation : limitation � 40 caract�res."</TD></TR>
 * <TR><TD>14/05/2014</TD><TD>VDE</TD><TD>EV-000278 : Mise en quarantaine des ND</TD></TR>
 * <TR><TD>01/08/2014</TD><TD>VDE</TD><TD>EV-000299 : Renseigner le ND � destination de GPC</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377 : ROME OFfre - Commandes FTTE</TD></TR>
 * </TD></TR>
 * </TABLE>
 * 
 * <B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.1685</TD><TD>EP 0070 - Modifier l'Intervention du rendez-vous port�e par une commande mixte</TD></TR>
 * <TR><TD>REQ.5812</TD><TD>EP 0130 � Mettre � jour le d�lai de temporisation en cas de modification de RDV</TD></TR>
 * </TABLE>
 */
public class RendezVousManagerBean extends FwkSessionBean implements RendezVousManager {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1689803753285707092L;

	/**
	 * The Class CentreZoneCatPCResult.
	 */
	private static class CentreZoneCatPCResult {

		/** The categorie pc. */
		private String categoriePC;

		/** The centre. */
		private String centre;

		/** The warning. */
		private String warning;

		/** The zone. */
		private String zone;

		/** The cmpact. */
		private String cmpact;

		/**
		 * The Constructor.
		 * 
		 * @param centre the centre
		 * @param zone the zone
		 * @param warning the warning
		 * @param categoriePC the categorie pc
		 * @param cmpact the cmpact
		 */
		public CentreZoneCatPCResult(String centre, String zone, String warning, String categoriePC, String cmpact) {
			this.centre = centre;
			this.zone = zone;
			this.warning = warning;
			this.categoriePC = categoriePC;
			this.cmpact = cmpact;
		}

		/**
		 * Gets the categorie pc.
		 * 
		 * @return Returns the categoriePC.
		 */
		public String getCategoriePC() {
			return categoriePC;
		}

		/**
		 * Gets the centre.
		 * 
		 * @return centre.
		 */
		public String getCentre() {
			return centre;
		}

		/**
		 * Gets the warning.
		 * 
		 * @return warning.
		 */
		public String getWarning() {
			return warning;
		}

		/**
		 * Gets the zone.
		 * 
		 * @return zone.
		 */
		public String getZone() {
			return zone;
		}

		/**
		 * Gets the cmpact.
		 * 
		 * @return cmpact.
		 */
		@SuppressWarnings("unused")
		public String getCmpact() {
			return cmpact;
		}

	}

	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	protected static IAnomalieManager ANOMALIE_MANAGER = serviceManager.getAnomalieManager();

	/** The Constant DYNAMIC_INTERVENTION_CODE_MODIF_RESERVATION_AUTRE_DATE. */
	public static final String DYNAMIC_INTERVENTION_CODE_MODIF_RESERVATION_AUTRE_DATE = "RESERVATION AUTRE DATE";

	/** The Constant DYNAMIC_INTERVENTION_CODE_MODIF_RESERVATION_IMPOSSIBLE. */
	public static final String DYNAMIC_INTERVENTION_CODE_MODIF_RESERVATION_IMPOSSIBLE = "RESERVATION_IMPOSSIBLE";

	/** The Constant DYNAMIC_INTERVENTION_CODE_MODIF_DEPLACE. */
	public static final String DYNAMIC_INTERVENTION_CODE_MODIF_DEPLACE = "DEPLACE";

	/** The Constant DYNAMIC_INTERVENTION_LIB_MODIF_REPORTEE_VIA. */
	public static final String DYNAMIC_INTERVENTION_LIB_MODIF_REPORTEE_VIA = "Report�e via ";

	/** The Constant DYNAMIC_INTERVENTION_LIBELLE_MODIF_HISTORISATION_RESERVATION_MANUELLE. */
	public static final String DYNAMIC_INTERVENTION_LIBELLE_MODIF_HISTORISATION_RESERVATION_MANUELLE = "Historisation de l'ancien RDV lors d'une r�servation manuelle";

	/** The Constant DYNAMIC_INTERVENTION_LIBELLE_MODIF_RESERVATION_IMPOSSIBLE. */
	public static final String DYNAMIC_INTERVENTION_LIBELLE_MODIF_RESERVATION_IMPOSSIBLE = "R�servation impossible dans GPC";

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = RendezVousManagerBean.class.getName();

	/** The Constant AVPCONTRINTERVGLOB_NOM_TRAITEMENT. */
	private static final String AVPCONTRINTERVGLOB_NOM_TRAITEMENT = "AVPContrIntervGlob";

	/** The Constant AVPCONTROLERDV_NOM_TRAITEMENT. */
	private static final String AVPCONTROLERDV_NOM_TRAITEMENT = "AVPControleRDV";

	/** The Constant AVPCRINTERVCLI_NOM_TRAITEMENT. */
	private static final String AVPCRINTERVCLI_NOM_TRAITEMENT = "AVPCRIntervCli";

	/** The Constant AVPCRINTERVGLOB_NOM_TRAITEMENT. */
	private static final String AVPCRINTERVGLOB_NOM_TRAITEMENT = "AVPCRIntervGlob";

	/** The Constant NATURE_INTERV_CLIENT. */
	private static final String NATURE_INTERV_CLIENT = "CLIENT";

	/** The Constant NATURE_INTERV_GLOBALE. */
	private static final String NATURE_INTERV_GLOBALE = "CLIENTREPARTITEUR";

	/** The Constant BASICAT_BOLBEC. */
	private static final String BASICAT_BOLBEC = "49W";

	/** The Constant COMPLETUDECRI_NOM_TRAITEMENT. */
	private static final String COMPLETUDECRI_NOM_TRAITEMENT = "CompletudeCRI";

	/** The Constant DEPLACE_STRING. */
	private static final String DEPLACE_STRING = "DEPLACE";

	/** The Constant CMPACT_DEFAUT. */
	private static final String CMPACT_DEFAUT = "PO";

	/** The Constant KO_GPC_OK_STRING. */
	private static final String KO_GPC_OK_STRING = "KO_GPC_OK";

	/** The Constant KO_STRING. */
	private static final String KO_STRING = "KO";

	/** The Constant MODIF_RDV__ID_ACTIVATION. */
	private static final String MODIF_RDV_ID_ACTIVATION = "MODIFRDV";

	/** The Constant OUI_STRING. */
	private static final String OUI_STRING = "OUI";

	/** The Constant NON_STRING. */
	private static final String NON_STRING = "NON";

	/** The Constant OK_STRING. */
	private static final String OK_STRING = "OK";

	/** The Constant PARAM_DETENTION_PREFIX. */
	private static final String PARAM_DETENTION_PREFIX = "ParamDet";

	/** The Constant REPORT_VIA_PREFIX. */
	private static final String REPORT_VIA_PREFIX = "Report�e via ";

	/** The Constant TCHMANRESINTERVGLOB_NOM_TRAITEMENT. */
	private static final String TCHMANRESINTERVGLOB_NOM_TRAITEMENT = "TchManResIntervGlob";

	/** The Constant NOTIF_MODIF_RDV_ERREUR_TECHNIQUE. */
	private static final String NOTIF_MODIF_RDV_ERREUR_TECHNIQUE = "001";

	/** The Constant NOTIF_MODIF_RDV_ERREUR_ETAT_INTERVENTION. */
	private static final String NOTIF_MODIF_RDV_ERREUR_ETAT_INTERVENTION = "007";

	/** The Constant NOTIF_MODIF_RDV_ERREUR_INTERVENTION_INCONNUE. */
	private static final String NOTIF_MODIF_RDV_ERREUR_INTERVENTION_INCONNUE = "009";

	/** The Constant BARRE_VERTICALE_STRING. */
	private static final String BARRE_VERTICALE_STRING = "|";

	/** The Constant EMPTY_STRING. */
	private static final String EMPTY_STRING = "";

	/** Longuer max du champ Observation en BD */
	private static final int OBSERVATION_MAX_SIZE = 1000;

	/** The etats. */
	private Set<String> etats;

	/** The tous etats. */
	private Set<String> tousEtats;

	/** The intervention home. */
	private InterventionHome interventionHome;

	/** The session context. */
	private SessionContext sessionContext;

	/** The evt home. */
	private EvtHome evtHome;

	/**
	 * Construteur.
	 */
	public RendezVousManagerBean() {

		etats = new HashSet<String>();
		etats.add(EtatInterventionConstantes.RESERV);
		etats.add(EtatInterventionConstantes.ARESERV);
		etats.add(EtatInterventionConstantes.TERM);
		etats.add(EtatInterventionConstantes.PLANIF);
		etats.add(EtatInterventionConstantes.ENVOI);
		etats.add(EtatInterventionConstantes.AMODIF);
		etats.add(EtatInterventionConstantes.ANN);
		etats.add(EtatInterventionConstantes.KO);
		etats.add(EtatInterventionConstantes.REPORT);

		tousEtats = new HashSet<String>();
		tousEtats.add(EtatInterventionConstantes.RESERV);
		tousEtats.add(EtatInterventionConstantes.ARESERV);
		tousEtats.add(EtatInterventionConstantes.TERM);
		tousEtats.add(EtatInterventionConstantes.PLANIF);
		tousEtats.add(EtatInterventionConstantes.ENVOI);
		tousEtats.add(EtatInterventionConstantes.AMODIF);
		tousEtats.add(EtatInterventionConstantes.ANN);
		tousEtats.add(EtatInterventionConstantes.KO);
		tousEtats.add(EtatInterventionConstantes.REPORT);
	}

	/**
	 * Sets the session context.
	 * 
	 * @param sessionContext the session context
	 * 
	 * @see javax.ejb.SessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext sessionContext) {
		this.sessionContext = sessionContext;
		try {
			interventionHome = getEntityHome(InterventionHome.class);
			evtHome = getEntityHome(EvtHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getIntervention(java.lang.String)
	 */
	public InterventionDTO getIntervention(String interventionId) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "getIntervention", "Recherche de l'intervention  " + interventionId);
		try {
			Intervention intervention = getInterventionEntity(interventionId);
			return new InterventionDTO(intervention);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getIntervention", "Probleme de recuperation de l'intervention " + interventionId, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#updateInterventionObservation(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public void updateInterventionObservation(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getLigneCommande", "Mise � jour de l'intervention  " + interventionDTO.getId());
		try {
			Intervention intervention = getInterventionEntity(interventionDTO.getId());
			intervention.setObservation(interventionDTO.getObservation());
			long timestamp = intervention.getTimestamp() + 1;
			intervention.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getIntervention", "Probleme de recuperation de l'intervention " + interventionDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getNatureIntervention(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public NatureIntervention getNatureIntervention(InterventionDTO intervention) {
		if (NATURE_INTERV_CLIENT.equals(getNatureFromIntervention(intervention))) {
			return NatureIntervention.INTERVENTION_CLIENT;
		} else if (NATURE_INTERV_GLOBALE.equals(getNatureFromIntervention(intervention))) {
			return NatureIntervention.INTERVENTION_GLOBALE;
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getNatureOpProgrammes(List)
	 */
	public String getNatureOpProgrammes(List<OpProgrammeeDTO> opProgrammeeList) {
		return getNatureFromOpProgrammees(opProgrammeeList);
	}

	@Override
	public TypeOpProgrammeeDTO getTypeOpProgrammeeAvecNaturePrioritaire(List<TypeOpProgrammeeDTO> lstTypeOpProgrammee) {
		return getTypeOpProgrammeePrioritaire(lstTypeOpProgrammee);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getRechercherPlageReferenceData(java.lang.String, java.lang.String)
	 */
	public RechercherPlageReferenceDataDTO getRechercherPlageReferenceData(String ligneCommandeId, String interventionId) {
		List<ResponsabiliteDTO> responsabilites;
		LigneCommandeDTO lc = serviceManager.getCommandeManager().getLigneCommande(ligneCommandeId);
		InterventionDTO intervention = serviceManager.getCommandeManager().getIntervention(interventionId);
		CommandeDTO commande = serviceManager.getCommandeManager().getCommande(lc.getIdCommande());
		String etatCommande = commande.getEtatCommande().getId();
		if (EtatCommandeConstantes.FO_CREEE.equals(etatCommande) || EtatCommandeConstantes.FO_ACOMP.equals(etatCommande)) {
			ResponsabiliteDTO responsabilite = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ResponsabiliteDTO.class, ResponsabiliteConstantes.INITIATIVE_CLIENT);
			responsabilites = Collections.singletonList(responsabilite);
		} else if (EtatInterventionConstantes.RESERV.equals(intervention.getEtatIntervention().getId())) {
			responsabilites = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ResponsabiliteDTO.class);
		} else if (intervention.getResponsabilite() == null || StringUtils.isEmpty(intervention.getResponsabilite().getId())) {
			responsabilites = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ResponsabiliteDTO.class);
		} else {
			ResponsabiliteDTO responsabilite = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ResponsabiliteDTO.class, intervention.getResponsabilite().getId());
			responsabilites = Collections.singletonList(responsabilite);
		}

		List<ResponsabiliteDTO> responsabilitesNonExt = new ArrayList<ResponsabiliteDTO>();
		for (ResponsabiliteDTO responsabiliteDTO : responsabilites) {
			if (!ResponsabiliteConstantes.INITIATIVE_EXTERIEURE.equals(responsabiliteDTO.getId()) && !isResponsabiliteOperateurEtDateDepasse(responsabiliteDTO, commande.getDatabaseDateDateCreationArtemis())) {
				responsabilitesNonExt.add(responsabiliteDTO);
			}
		}
		return new RechercherPlageReferenceDataDTO(intervention, responsabilitesNonExt);
	}

	/**
	 * Pour initiative OPERATEUR, return true si la valeur du param�tre "MODIF_RDV_OPER" n'existe pas ou est inf�rieure � la date de cr�ation de la commande dans l�application
	 * Sinon return false (param�tre "MODIF_RDV_OPER" sup�rieur ou �gal � la date de la commande, responsabilit� diff�rent d'OPERATEUR)
	 *
	 * @param responsabiliteDTO
	 * @return isOperateurEtDateDepasse
	 */
	public boolean isResponsabiliteOperateurEtDateDepasse(ResponsabiliteDTO responsabiliteDTO, Long dateCreationCommande) {
		boolean isOperateurEtDateDepasse = false;
		if (responsabiliteDTO != null) {
			String responsabilite = responsabiliteDTO.getId();
			if (ResponsabiliteConstantes.INITIATIVE_OPERATEUR.equals(responsabilite)) {
				isOperateurEtDateDepasse = true;
				ParametreArtemisDTO paramArtemis = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ParametreArtemisDTO.class,
						new Comparaison(ParametreArtemis.FIELD_CLE_PARAMETRE, com.soliste.bolbec.commun.service.Constantes.OPERATOR_EQUAL, ConstantesParametreArtemis.MODIF_RDV_OPER),
						new Comparaison(ParametreArtemis.FIELD_VERSION, com.soliste.bolbec.commun.service.Constantes.OPERATOR_EQUAL, com.soliste.bolbec.commun.service.Constantes.VERSION));
				if (paramArtemis != null) {
					long dateModifRdvOper = Long.parseLong(paramArtemis.getValeurParametre());
					if (dateCreationCommande <= dateModifRdvOper) {
						isOperateurEtDateDepasse = false;
					}
				}
			}
		}
		return isOperateurEtDateDepasse;
	}


	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getRendezVous(java.lang.String)
	 */
	public RendezVousDTO getRendezVous(String ligneCommandeId) {
		return getRendezVous(ligneCommandeId, etats);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getRendezVousParNd(java.lang.String)
	 */
	public List<ExtendedInterventionDTO> getRendezVousParNd(String nd) {
		return getRendezVousParCommandesList(serviceManager.getCommandeManager().findCommandeByND(nd));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getRendezVousParNd(java.lang.String)
	 */
	public List<ExtendedInterventionDTO> getRendezVousParRefIntervention(String refIntervention) {
		return getRendezVousParCommandesList(serviceManager.getCommandeManager().findCommandeByRefIntervention(refIntervention));

	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#getRendezVousParCommandeRef(String)
	 */
	public List<ExtendedInterventionDTO> getRendezVousParCommandeRef(String commandeRef) {
		return getRendezVousParCommandesList(serviceManager.getCommandeManager().findCommandeByRefeRDV(commandeRef));
	}

	/**
	 * Retourne la liste des interventions (ExtendedInterventionDTO) pour
	 * une liste de commandes donn�e ordonn�es par Intervention.datePriseRDV
	 * d�croissante (les plus r�centes en pemier), avec les DynamicIntervention
	 * correspondants, la Commande li�e, les PsSouhaitee, et les Offre, et
	 * pouvant stocker une String InterventionEtatReport initialis�e � vide.
	 * 
	 * @param commandesListe de lignes de commande
	 * @return la liste des interventions (ExtendedInterventionDTO)pour une liste de commandes
	 * donn� ordonn�es par Intervention.datePriseRDV d�croissante (les
	 * plus r�centes en pemier), avec les DynamicIntervention
	 * correspondants, la Commande li�e, les PsSouhaitee, et les Offre,
	 * et pouvant stocker une String InterventionEtatReport initialis�e
	 * � vide.
	 */
	private List<ExtendedInterventionDTO> getRendezVousParCommandesList(final List<CommandeDTO> commandesListe) {
		final List<ExtendedInterventionDTO> rendezVousTriesListeRes = new ArrayList<ExtendedInterventionDTO>();
		List<LigneCommandeDTO> lignesCommande;
		List<InterventionDTO> interventions;
		ExtendedInterventionDTO dto;
		InterventionDTO interventionIterator;
		ExtendedInterventionDTO dtoPrecedent;
		for (CommandeDTO commande : commandesListe) {
			lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
			for (LigneCommandeDTO lc : lignesCommande) {
				interventions = getRendezVous(lc.getId(), tousEtats).getInterventions();
				for (InterventionDTO intervention : interventions) {
					dto = new ExtendedInterventionDTO(intervention, commande);
					rendezVousTriesListeRes.add(dto);
					interventionIterator = intervention;
					while (interventionIterator.getSuitIntervention() != null) {
						interventionIterator = interventionIterator.getSuitIntervention();
						dtoPrecedent = new ExtendedInterventionDTO(interventionIterator, commande);
						rendezVousTriesListeRes.add(dtoPrecedent);
					}
				}
			}
		}

		Collections.sort(rendezVousTriesListeRes, new Comparator<ExtendedInterventionDTO>() {
			public int compare(final ExtendedInterventionDTO o1, final ExtendedInterventionDTO o2) {
				final Date datePriseRdv1 = o1.getIntervention().getDatePrise(), datePriseRdv2 = o2.getIntervention().getDatePrise();
				if ((datePriseRdv1 != null) && (datePriseRdv2 != null)) {
					return datePriseRdv2.compareTo(datePriseRdv1);
				} else if (datePriseRdv1 != null) {
					return -1;
				} else if (datePriseRdv2 != null) {
					return 1;
				} else {
					return 0;
				}
			}
		});
		return rendezVousTriesListeRes;
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>25/02/2010</TD><TD>DBA</TD><TD>IRMA_151: Factorisation code</TD></TR>
	 * </TABLE>
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#rechercherPlage(java.lang.String, java.util.Date, java.util.Date, com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.DayOfWeek,
	 * com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.MomentInDay, com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.Duration)
	 */
	public RechercherPlageResultDTO rechercherPlage(String interventionId, Date startDate, Date endDate, DayOfWeek dayOfWeek, MomentInDay momentInDay, Duration duration) throws RechercherPlageException {
		try {
			InterventionDTO intervention = getIntervention(interventionId);
			List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeeByIntervention(interventionId);
			OpProgrammeeDTO firstOpProgrammee = CollectionUtils.getFirstOrNull(opProgrammees);
			List<LigneCommandeDTO> ligneCommandes = serviceManager.getCommandeManager().findLigneCommandeByOpProgrammee(firstOpProgrammee.getId());
			if (ligneCommandes.size() == 0) {
				throw new RuntimeException("Aucune ligne de commande attach�e � l'OpProgrammee " + firstOpProgrammee.getId());
			}
			LigneCommandeDTO firstLigneCommande = CollectionUtils.getFirstOrNull(ligneCommandes);
			CommandeDTO commande = serviceManager.getCommandeManager().getCommande(firstLigneCommande.getIdCommande());
			String versionArtemis = commande.getVersionArtemis();
			CentreZoneCatPCResult centreZoneCatPCResult = rechercherCentreZoneCategoriePC(intervention, opProgrammees, ligneCommandes, commande);
			CritereAdresseEtPlages critereAEP = new CritereAdresseEtPlages();
			critereAEP.setId(serviceManager.getGeneratorManager().generateKey());
			String categorieClientContractant = (commande.getClient().getCategorieClient() != null) ? commande.getClient().getCategorieClient().getId() : null;
			String categorieClientLivre = (firstLigneCommande.getClient().getCategorieClient() != null) ? firstLigneCommande.getClient().getCategorieClient().getId() : null;
			Long dateContractuelle = firstLigneCommande.getDatabaseDateDateContractuelle();
			String cleRecherche = null;

			// r�cup�ration de l'objet commandeTraitee pour mode bouchon
			CommandeTraitee commandeTraitee = new CommandeTraitee(commande.getId(), commande.getDatabaseDateDateValidationFo().toString(), versionArtemis, commande.getRefExterne());

			// cr�ation objet IO_RechercherPlage
			IORechercherPlages ioRechercherPlages = new IORechercherPlages(null, null, commandeTraitee);
			String critereLocalisation = null;
			String ndLocalisation = null;
			for (OpProgrammeeDTO opProgrammee : opProgrammees) {

				// G�n�ration de MesContr
				String mesContr = null;
				if (TypeOpProgrammeeConstantes.INTERV_GLOBALE.equals(opProgrammee.getTypeOpProgrammee().getId())) {
					String intervMesContr = opProgrammee.getIntervention().getMescontr();
					if (!(NON_STRING.equals(intervMesContr)) && !(StringUtils.isEmpty(intervMesContr))) {
						mesContr = intervMesContr;
					}
				}
				// IRMA_151: Factorisation de la m�thode
				ioRechercherPlages.addOpeProgIntervention(opProgrammee.getId(), opProgrammee.getTypeOpProgrammee().getId(), null, mesContr, null);
				List<LigneCommandeDTO> lignesCdePourOpProg = serviceManager.getCommandeManager().findLigneCommandeByOpProgrammee(opProgrammee.getId());
				for (LigneCommandeDTO lc : lignesCdePourOpProg) {
					// Valorisation de l'IAR
					if (cleRecherche == null) {
						if (!TypeAccesLivraisonEnum.IDCLI.name().equals(lc.getTypeAccesLivraison())) {
							cleRecherche = lc.getAccesLivraison();
						} else {
							cleRecherche = lc.getNdFinder();
						}
					}
					PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
					if (critereLocalisation == null) {
						critereLocalisation = firstLigneCommande.getInstanceLocalisation().getId();
					}
					if (ndLocalisation == null) {
						ndLocalisation = (psSouhaite != null) ? psSouhaite.getNd() : null;
					}
					if (psSouhaite != null) {
						ioRechercherPlages.addPSIntervention(psSouhaite.getId(), psSouhaite.getPorteSurOffre().getId(), new HashMap<String, String>(getRechercherPlagePsSouhaiteDynamicFields(psSouhaite)), getRechercherPlageOffreCible(lc),
								getRechercherPlageOffreExistante(lc));
					}
				}
			}
			ioRechercherPlages.setVersionArtemis(versionArtemis);
			critereAEP.setCentre(centreZoneCatPCResult.getCentre());
			critereAEP.setZone(centreZoneCatPCResult.getZone());
			critereAEP.setCategoriePC(centreZoneCatPCResult.getCategoriePC());
			critereAEP.setDateDebut(DateUtils.getDatabaseDate(startDate.getTime()));
			Date endDate2359 = (Date) endDate.clone();
			endDate2359.setHours(23);
			endDate2359.setMinutes(59);
			critereAEP.setDateFin(DateUtils.getDatabaseDate(endDate2359.getTime()));
			critereAEP.setJour(dayOfWeek.getId());
			critereAEP.setMoment(momentInDay.getId());
			critereAEP.setDureePrevue(duration.getIdDb());
			critereAEP.setDateContractuelle(dateContractuelle);
			critereAEP.setCatClientContractant(categorieClientContractant);
			critereAEP.setCatClientLivre(categorieClientLivre);
			AdresseDTO adresseClient = firstLigneCommande.getClient().getAdresse();
			if (adresseClient != null) {
				critereAEP.setCodeINSEE(adresseClient.getCodeInsee());
				critereAEP.setCodeRivoli(adresseClient.getCodeRivoli());

				String numVoieNumber = adresseClient.getNumeroVoie();
				critereAEP.setNumVoieNumberAndLetter (numVoieNumber);
			}
			ioRechercherPlages.setCritereAdresseEtPlages(critereAEP);

			// valorisation CritereLocalisation
			ioRechercherPlages.setCritereLocalisation(critereLocalisation);
			ioRechercherPlages.setNdLocalisation(ndLocalisation);

			// valorisation CritereIntervention
			Map<String, String> dynamicsIntervention = intervention.getDynamicInterventions();
			CritereIntervention critereInterventionInput = new CritereIntervention(dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_ACTIV), dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_PROD),
					dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_CENTRE), dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_ZONE), dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_SEGMA),
					dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_CMPACT));
			critereInterventionInput.setCleRecherche(cleRecherche);
			ioRechercherPlages.setCritereIntervention(critereInterventionInput);

			// Valorisation des booleans isModif, isReserv, isRefKyakuPresent poru voir sur quel cas on est.
			String etatIntervention = intervention.getEtatIntervention().getId();
			ioRechercherPlages.setModif(EtatInterventionConstantes.RESERV.equals(etatIntervention) || EtatInterventionConstantes.ENVOI.equals(etatIntervention) || EtatInterventionConstantes.AMODIF.equals(etatIntervention));
			ioRechercherPlages.setReserv(EtatInterventionConstantes.ARESERV.equals(etatIntervention) || EtatInterventionConstantes.PLANIF.equals(etatIntervention));
			ioRechercherPlages.setPerimKyakuPresent(StringUtils.isNotBlank(dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU)));

			// Appel du SF
			SFAno ano = InterventionUtil.rechercherPlages(ioRechercherPlages);
			Evenement evenement = null;
			if (ano != null) {
				evenement = ANOMALIE_MANAGER.traiter(TraitementConstantes.RECHERCHEPLAGES, ano);
				boolean erreurBloquante = CategorieEvenementConstantes.POPBQ.equals(evenement.getIdCategorieEvenement());
				if (erreurBloquante) {
					throw new RechercherPlageException(evenement.getLibelle());
				}
			}

			// r�cup�ration objet Crit�reIntervention
			CritereIntervention critereIntervention = ioRechercherPlages.getCritereIntervention();

			// traitement plages retourn�es
			List<Plage> plages = ioRechercherPlages.getListePlages();

			// Mise � jour des champs dynamiques de l'intervention
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ACTIV, critereIntervention.getActiv());
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_PROD, critereIntervention.getProd());
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CENTRE, critereIntervention.getCentre());
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ZONE, critereIntervention.getZone());
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_SEGMA, critereIntervention.getSegma());
			if (critereIntervention.isPerimKyaku()) {
				dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU, ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU_OUI);
			} else {
				dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU, null);
			}
			serviceManager.getCommandeManager().updateDynamicIntervention(intervention);

			String warning = (evenement != null) ? evenement.getLibelle() : centreZoneCatPCResult.getWarning();
			return new RechercherPlageResultDTO(plages, critereIntervention, warning);
		} catch (CreateException e) {
			throw new EJBException(e);
		} catch (RechercherPlageException e) {
			sessionContext.setRollbackOnly();
			throw e;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#filtrerPlage(java.lang.String, java.util.List)
	 */
	public List<Plage> filtrerPlage(String interventionId, List<Plage> plages) {

		// toutes les lignes de commande de Cr�ation rattach�es � la commande en cours
		List<LigneCommandeDTO> lignesCommandeCreation = new ArrayList<LigneCommandeDTO>();
		boolean filtragePlage = false;
		List<LigneCommandeDTO> ligneCommandes = serviceManager.getCommandeManager().findLigneCommandeByIntervention(interventionId);
		for (LigneCommandeDTO ligneCde : ligneCommandes) {
			if (ligneCde.getTypeOpPonctuelles() != null && TypeOpPonctuellesConstantes.CR.equals(ligneCde.getTypeOpPonctuelles().getId())) {
				lignesCommandeCreation.add(ligneCde);
			}
		}

		// Pour toutes les lignes de commande de Cr�ation rattach�es � la commande en cours
		for (LigneCommandeDTO ligneCde : lignesCommandeCreation) {
			Map<String, String> dynamicsLigneCde = ligneCde.getDynamicLigneCommandes();
			String valOffreCible = dynamicsLigneCde.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OFFRECIBLE);
			if (!StringUtils.isBlank(valOffreCible)) {
				String valeurExterne = valOffreCible.substring(valOffreCible.indexOf("_") + 1);
				String entree = TraductionManager.getInstance().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.FILTRAGE_PLAGE, valeurExterne);
				if (entree != null) {
					if (OUI_STRING.equals(entree)) {
						filtragePlage = true;
					}
				}
			}
			if (filtragePlage) {
				List<Plage> listePlageFiltree = new ArrayList<Plage>();

				// supprimer de la collection plages toues les objets pour lesquels HeureDebut ou HeureFin n'est pas une heure pleine
				for (Plage plage : plages) {
					int heure = DateUtils.getDatabaseDate(plage.getDebut()).intValue();
					if ((heure % 100) == 0) {
						listePlageFiltree.add(plage);
					}
				}
				return listePlageFiltree;
			}
		}
		return plages;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#libererPlage(java.lang.String, com.soliste.bolbec.commun.service.model.AgentDTO, java.lang.String)
	 */
	public LibererPlageResultDTO libererPlage(String interventionId, AgentDTO agentDTO, String responsabiliteId) throws LibererPlageException, RemoveException {
		try {
			InterventionDTO intervention = getIntervention(interventionId);
			String reference = intervention.getReference();
			String refExterne = intervention.getRefExterne();
			Map<String, String> dynamicsIntervention = intervention.getDynamicInterventions();
			String activ = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
			String prod = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_PROD);
			String baseGpc = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_BASEGPC);
			String refKyaku = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU);
			boolean isPerimKyaku = ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU_OUI.equals(dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU));

			String critereLocalisation = null;
			String ndLocalisation = null;
			String versionArtemis = null;
			String casMetier = null;
			CommandeTraitee commandeTraitee = null;

			// r�cup�ration de la liste des Op�rations Programm�es associ�es
			List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeeByIntervention(interventionId);
			for (OpProgrammeeDTO opProgrammee : opProgrammees) {
				List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByOpProgrammee(opProgrammee.getId());
				LigneCommandeDTO firstLigneCommande = CollectionUtils.getFirstOrNull(lignesCde);
				// construction de l'objet commandeTraitee pour l'appel au SF
				CommandeDTO commande = serviceManager.getCommandeManager().getCommande(firstLigneCommande.getIdCommande());
				if (casMetier == null && commande.getCasMetier() != null) {
					casMetier = commande.getCasMetier().getId();
				}
				if (versionArtemis == null) {
					versionArtemis = commande.getVersionArtemis();
				}
				commandeTraitee = new CommandeTraitee(commande.getId(), commande.getDatabaseDateDateValidationFo().toString(), versionArtemis, commande.getRefExterne());
				if (ndLocalisation == null) {
					if (TypeAccesLivraisonEnum.ND.name().equals(firstLigneCommande.getTypeAccesLivraison())) {
						ndLocalisation = firstLigneCommande.getAccesLivraison();
					}
				}
				if (critereLocalisation == null && firstLigneCommande.getInstanceLocalisation() != null) {
					critereLocalisation = firstLigneCommande.getInstanceLocalisation().getId();
				}
			}
			CritereIntervention critInterv = new CritereIntervention(activ, prod);
			critInterv.setBaseGpc(baseGpc);
			IOLibererPlage ioLibererPlage = new IOLibererPlage(critereLocalisation, ndLocalisation, critInterv, reference, refExterne, commandeTraitee, responsabiliteId, refKyaku, isPerimKyaku);
			ioLibererPlage.setVersionArtemis(versionArtemis);

			// Appel du SF
			Evenement evenement = null;
			SFAno ano = InterventionUtil.libererPlage(ioLibererPlage);
			if (ano != null) {
				evenement = ANOMALIE_MANAGER.traiter(TraitementConstantes.LIBERATIONPLAGE, ano);
				boolean erreurBloquante = CategorieEvenementConstantes.POPBQ.equals(evenement.getIdCategorieEvenement());
				if (erreurBloquante) {
					throw new LibererPlageException(evenement.getLibelle());
				}
			}
			intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.ANN));
			serviceManager.getCommandeManager().updateInterventionEtat(intervention);

			// RG3 : Valorisation du responsable modification
			String prenom = (agentDTO != null && agentDTO.getPrenom() != null) ? agentDTO.getPrenom() : "";
			String nom = (agentDTO != null && agentDTO.getNom() != null) ? agentDTO.getNom() : "";
			String resp_modif = prenom + " " + nom;
			if (!StringUtils.isBlank(resp_modif.trim())) {
				Map<String, String> dynamics = intervention.getDynamicInterventions();
				dynamics.put(ConstantesDynamicIntervention.INTERVENTION_RESP_MODIF, resp_modif);
				serviceManager.getCommandeManager().updateDynamicIntervention(intervention);
			}

			// cr�ation d'une nouvelle intervention
			InterventionDTO newIntervention = createInterventionFille(intervention);
			Map<String, String> dynamics = newIntervention.getDynamicInterventions();
			dynamics.put(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU, null);
			dynamics.put(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU, null);
			serviceManager.getCommandeManager().updateDynamicIntervention(newIntervention);
			newIntervention.setObservation(intervention.getObservation());
			newIntervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.ARESERV));
			newIntervention.setResponsabilite(intervention.getResponsabilite());
			newIntervention.setMescontr(intervention.getMescontr());
			serviceManager.getCommandeManager().updateIntervention(newIntervention);

			NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_I, NotificationGeneriqueConstantes.LIBERERINTERV, intervention.getId(), commandeTraitee.getId());
			serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

			String warning = (evenement != null) ? evenement.getLibelle() : null;
			return new LibererPlageResultDTO(warning, newIntervention.getId());
		} catch (CreateException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#reserverPlage(java.lang.String, com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.Plage, com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.CritereIntervention, java.lang.String,
	 * com.soliste.bolbec.commun.service.model.AgentDTO)
	 */
	public ReserverPlageResultDTO reserverPlage(String interventionId, Plage plage, CritereIntervention critereIntervention, String responsabiliteId, AgentDTO agentDTO) throws ReserverPlageException {
		try {
			InterventionDTO intervention = getIntervention(interventionId);
			if (EtatInterventionConstantes.ARESERV.equals(intervention.getEtatIntervention().getId()) || EtatInterventionConstantes.PLANIF.equals(intervention.getEtatIntervention().getId())) {
				return reserverPlage(intervention, plage, critereIntervention, responsabiliteId, agentDTO);
			}
			ContexteModification contexte = new ContexteModification(BASICAT_BOLBEC, ContexteModification.APPEL_IHM_STRING);
			return modificationIntervention(intervention, critereIntervention, plage, responsabiliteId, contexte, null, agentDTO);
		} catch (CreateException e) {
			throw new EJBException(e);
		} catch (RemoveException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>07/02/2011</TD><TD>GPE</TD><TD>IRMA_946: Retour Null sur Web Service NotificationModificationErdv</TD></TR>
	 * </TABLE>
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#modifierRendezVous(com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.InterventionModification, com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.Plage, java.lang.String,
	 * com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ContexteModification, com.soliste.bolbec.commun.service.model.AgentDTO)
	 */
	public String modifierRendezVous(InterventionModification intervention, Plage plage, String responsabiliteId, ContexteModification contexte, AgentDTO agentDTO) throws ReserverPlageException {
		String res = null;
		try {
			// IRMA_846 : ne plus faire de getIntervention, mais un findInterventionByRefInterventionAndPlusRecentDatePrise car interventionid
			// pass� par erdv est en fait la referenceIntervention
			InterventionDTO interventionExistante = findInterventionByRefInterventionAndPlusRecentDatePrise(intervention.getInterventionId());
			if (interventionExistante == null) {
				res = KO_STRING;
			} else {
				Map<String, String> dynamicsIntervention = interventionExistante.getDynamicInterventions();
				String activVal = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
				String prodVal = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_PROD);
				String centreVal = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_CENTRE);
				String zoneVal = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_ZONE);
				String segmaVal = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_SEGMA);
				String cmpactVal = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_CMPACT);

				CritereIntervention crit = new CritereIntervention(activVal, prodVal, centreVal, zoneVal, segmaVal, cmpactVal);
				ReserverPlageResultDTO resultDTO = modificationIntervention(interventionExistante, crit, plage, responsabiliteId, contexte, intervention.getObservation(), agentDTO);
				if (resultDTO == null) {
					res = KO_STRING;
				} else {
					res = resultDTO.getCode();
				}
			}
			return res;
		} catch (CreateException ce) {
			return KO_STRING;
		} catch (RemoveException re) {
			return KO_STRING;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#modificationIntervention(java.lang.String, java.lang.String, java.lang.String, java.util.Date, java.util.Date, java.lang.String, java.lang.String)
	 */
	public String modificationIntervention(String referenceIntervention, String basicat, String referenceERdv, Date dateDebut, Date dateFin, String agent, String responsabilite) {
		String methodName = "modificationIntervention";
		String retour = null;
		try {
			ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "Recherche de l'intervention : " + referenceIntervention);
			InterventionDTO interventionCourante = findInterventionByRefInterventionAndPlusRecentDatePrise(referenceIntervention);
			if (interventionCourante == null) {
				retour = NOTIF_MODIF_RDV_ERREUR_INTERVENTION_INCONNUE;
			} else {

				// 2 - Contr�le de la coh�rence des donn�es internes
				String etatIntervention = interventionCourante.getEtatIntervention().getId();
				if (!EtatInterventionConstantes.ENVOI.equals(etatIntervention) && !EtatInterventionConstantes.RESERV.equals(etatIntervention) && !EtatInterventionConstantes.PLANIF.equals(etatIntervention)
						&& !EtatInterventionConstantes.REPORT.equals(etatIntervention)) {
					retour = NOTIF_MODIF_RDV_ERREUR_ETAT_INTERVENTION;
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "Etat de l'intervention incorrect : " + etatIntervention);
				} else {

					// 3 - Modification de l�intervention dans Art�mis

					// Cr�ation d�une nouvelle intervention
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "Cr�ation d'une nouvelle intervention");
					InterventionDTO nouvelleIntervention = createInterventionFille(interventionCourante);
					nouvelleIntervention.setDebutPlage(dateDebut);
					nouvelleIntervention.setFinPlage(dateFin);
					nouvelleIntervention.setRefErdv(referenceERdv);
					nouvelleIntervention.setResponsabilite(new ResponsabiliteDTO(responsabilite));
					nouvelleIntervention.setRefExterne(interventionCourante.getRefExterne());
					nouvelleIntervention.setDatabaseDateDateEnvoiOt(interventionCourante.getDatabaseDateDateEnvoiOt());
					nouvelleIntervention.setDatabaseDateDatePrise(DateUtils.getDatabaseDate());
					nouvelleIntervention.setEtatIntervention(interventionCourante.getEtatIntervention());
					serviceManager.getCommandeManager().updateIntervention(nouvelleIntervention);

					// Modification de l�intervention courante
					interventionCourante.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.REPORT));
					serviceManager.getCommandeManager().updateInterventionEtat(interventionCourante);

					// R�cup�ration du syst�me externe pour r�cup�rer le libelle du basicat
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "R�cup�ration du libell� du basicat " + basicat);
					LigneCommandeDTO firstLigneCommande = findFirstLigneCommandeFromFirstOpByIntervention(nouvelleIntervention.getId());
					CommandeDTO commande = serviceManager.getCommandeManager().getCommande(firstLigneCommande.getIdCommande());
					String versionArtemis = commande.getVersionArtemis();
					SystemeExterneDTO systExt = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, new Comparaison(SystemeExterne.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, basicat),
							new Comparaison(SystemeExterne.FIELD_VERSION, Constantes.OPERATOR_EQUAL, versionArtemis));
					String libBasicat = "";
					if (systExt != null) {
						libBasicat = systExt.getNom();
					}
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "Libell� du basicat trouv� : " + libBasicat);

					// Cr�ation des informations compl�mentaire de la notification de report
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "Cr�ation des champs DynamicIntervention compl�mentaires");
					Map<String, String> dynamicsIntervention = interventionCourante.getDynamicInterventions();
					dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CODEMODIF, DYNAMIC_INTERVENTION_CODE_MODIF_DEPLACE);
					dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ORIGINEDEMANDE, basicat);
					dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_LIBELLEMODIF, DYNAMIC_INTERVENTION_LIB_MODIF_REPORTEE_VIA + libBasicat);
					dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_RESP_MODIF, agent);
					serviceManager.getCommandeManager().updateDynamicIntervention(interventionCourante);
				}
			}

		} catch (CreateException ce) {
			retour = NOTIF_MODIF_RDV_ERREUR_TECHNIQUE;
		}
		ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "Traitement de modification d'intervention termin�");
		return retour;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#createEvtPourNotificationModificationRDV(java.lang.String)
	 */
	public void createEvtPourNotificationModificationRDV(String codeErreur) throws CreateException {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(Evt.FIELD_DATE_CREATION, DateUtils.getDatabaseDate());
		values.put(Evt.FIELD_INFO, codeErreur);
		Evt result = evtHome.create(serviceManager.getGeneratorManager().generateKey(), values);
		result.setLinks(values);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.rdv.RendezVousManager#gererErreurNotifNouvelleInterv(java.lang.String, java.lang.String)
	 */
	public void gererErreurNotifNouvelleInterv(String codeErreur, String libelleErreur) {
		SFAno l_anomalie = null;
		if (codeErreur == null) {
			l_anomalie = ANOMALIE_MANAGER.newSFAno("NotifierNouvelleIntervention", AnomalieConstantes.ERREUR_TECH_AV, ANOMALIE_MANAGER.getMessage(MessagesConstantes.GENE_000020));
		} else {
			String idAnomalie = TraductionManager.getInstance().getTraductionErreurInterfVersArtemis("NotifierNouvelleIntervention", ServiceExterneConstantes.ERDV_NOTIFNOUVINTERV, codeErreur);
			AnomalieDTO anomalie = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AnomalieDTO.class, idAnomalie);
			if (anomalie == null) {
				l_anomalie = ANOMALIE_MANAGER.newSFAno("NotifierNouvelleIntervention", AnomalieConstantes.ERREUR_TRADUCTION_AV,
						ANOMALIE_MANAGER.getMessage(MessagesConstantes.GENE_000050, new Object[] { codeErreur, libelleErreur, ServiceExterneConstantes.ERDV_NOTIFNOUVINTERV }));
			} else {
				l_anomalie = ANOMALIE_MANAGER.newSFAno("NotifierNouvelleIntervention", anomalie.getId(), codeErreur + " - " + libelleErreur);
			}
		}

		// Traitement des anomalies retourn�es par la notif. de nouvelle intervention
		if (l_anomalie != null) {
			ANOMALIE_MANAGER.traiter(TraitementConstantes.RESERVATIONPLAGE, l_anomalie);
			// Pas de traitement d'erreur bloquante : le non fonctionnement de l'appel � la notification
			// ne doit pas perturber la r�servation de plage
		}
	}

	/**
	 * Gets the Intervention entity.
	 * 
	 * @param id the id
	 * 
	 * @return the Intervention entity
	 * 
	 * @throws FinderException the finder exception
	 */
	@SuppressWarnings("unchecked")
	private Intervention getInterventionEntity(String id) throws FinderException {
		Intervention intervention = null;
		try {
			intervention = interventionHome.findByPrimaryKey(new EntityBeanPK(id));
		} catch (FinderException fe) {
			Collection<Intervention> interventions = interventionHome.findParRefIntervention(id);
			if (interventions.size() > 0) {
				return interventions.iterator().next();
			}
			throw new FinderException("Impossible de trouver une intervention pour l'identifiant [" + id + "]");
		}
		return intervention;
	}

	/**
	 * {@inheritDoc}
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>07/02/2011</TD><TD>GPE</TD><TD>IRMA_946: Retour Null sur Web Service NotificationModificationErdv</TD></TR>
	 * <TR><TD>13/09/2011</TD><TD>GPA</TD><TD>EV-000167: Filtrage des interventions associ�es � des commandes �l�mentaires regroup�es</TD></TR>
	 * </TABLE>
	 */
	public InterventionDTO findInterventionByRefInterventionAndPlusRecentDatePrise(String interventionReference) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterventionByRefInterventionAndPlusRecentDatePrise", "Recherche de l'intervention de r�f�rence " + interventionReference + " et de DatePrise la plus r�cente");
		try {
			@SuppressWarnings("unchecked")
			Collection<Intervention> interventions = interventionHome.findParRefIntervention(interventionReference);
			// Filtrer la collection d'intervention en supprimant les interventions associ�es aux commandes �l�mentaires regroup�es
			filterIntervCmdesElemRegroup(interventions);
			Intervention interventionPlusRecente = getInterventionPlusRecente(interventions);
			return (interventionPlusRecente == null) ? null : new InterventionDTO(interventionPlusRecente);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterventionByRefInterventionAndPlusRecentDatePrise", "Probleme de recuperation de l'intervention de r�f�rence " + interventionReference, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * Filtrer la collection d'intervention en supprimant les interventions associ�es � des commandes �l�mentaires regroup�es
	 * 
	 * @param listeInterventions la liste d'intervention � filter
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>13/09/2011</TD><TD>GPA</TD><TD>EV-000167: Cr�ation de la m�thode</TD></TR>
	 * <TR><TD>08/10/2013</TD><TD>BPE</TD><TD>G8R2C3 : DE-000949 "RDV des commandes mixtes non modifiables par eRDV"</TD></TR>
	 * </TABLE>
	 */
	protected void filterIntervCmdesElemRegroup(final Collection<Intervention> listeInterventions) {
		final CommandeManager commandeManager = serviceManager.getCommandeManager();
		final Collection<Intervention> listeInterventionsCopie = new ArrayList<Intervention>(listeInterventions);
		List<LigneCommandeDTO> lignesCommandeListe;
		CommandeDTO commande;
		for (Intervention intervention : listeInterventionsCopie) {
			lignesCommandeListe = commandeManager.findLigneCommandeByIntervention(intervention.getId());
			if (lignesCommandeListe.size() == 0) {
				continue;
			}
			commande = commandeManager.getCommande(lignesCommandeListe.get(0).getIdCommande());
			if (EtatCommandeConstantes.TERM.equals(commande.getEtatCommande().getId()) && commande.getStatutCommande().getId().endsWith("_Regroupee")) {
				listeInterventions.remove(intervention);
			}
		}
	}

	/**
	 * M�thode retournant parmis la collection pass�e en entr�e l'intervention dont la date prise est la plus r�cente.
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>07/02/2011</TD><TD>GPE</TD><TD>IRMA_946: Retour Null sur Web Service NotificationModificationErdv</TD></TR>
	 * </TABLE>
	 * 
	 * @param interventions
	 * la collection dans laquelle on cherche l'intervention dont la date prise est la plus r�cente
	 * @return
	 * l'intervention dont la date prise est la plus r�cente
	 */
	protected static Intervention getInterventionPlusRecente(Collection<Intervention> interventions) {
		Intervention interventionCourante = null;
		Long datePriseInterventionCourante = null;
		for (Intervention intervention : interventions) {
			// Cas ou il n'y a qu'une intervention
			if (interventions.size() == 1) {
				return intervention;
			}

			if (interventionCourante == null) {
				if (intervention.getDatePrise() != null) {
					interventionCourante = intervention;
					datePriseInterventionCourante = intervention.getDatePrise();
				}
			} else {
				Long datePriseATester = intervention.getDatePrise();
				if ((datePriseATester != null) && (datePriseATester.compareTo(datePriseInterventionCourante) > 0)) {
					interventionCourante = intervention;
					datePriseInterventionCourante = intervention.getDatePrise();
				}
			}
		}
		return interventionCourante;
	}

	/**
	 * Find first ligne commande from first op by intervention.
	 * 
	 * @param interventionId the intervention id
	 * 
	 * @return the ligne commande dto
	 */
	private LigneCommandeDTO findFirstLigneCommandeFromFirstOpByIntervention(String interventionId) {
		List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeeByIntervention(interventionId);
		OpProgrammeeDTO firstOpProgrammee = CollectionUtils.getFirstOrNull(opProgrammees);
		List<LigneCommandeDTO> ligneCommandes = serviceManager.getCommandeManager().findLigneCommandeByOpProgrammee(firstOpProgrammee.getId());
		if (ligneCommandes.size() == 0) {
			throw new RuntimeException("Aucune ligne de commande attach�e � l'OpProgrammee " + firstOpProgrammee.getId());
		}
		return CollectionUtils.getFirstOrNull(ligneCommandes);
	}

	/**
	 * Gets the rendez vous.
	 * 
	 * @param ligneCommandeId the ligne commande id
	 * @param etatInterventions the etat interventions
	 * 
	 * @return the rendez vous
	 */
	private RendezVousDTO getRendezVous(String ligneCommandeId, Set<String> etatInterventions) {
		LigneCommandeDTO ligneCommande = serviceManager.getCommandeManager().getLigneCommande(ligneCommandeId);
		AccesLivraisonKey accesLivraisonKey = new AccesLivraisonKey(ligneCommande);
		CommandeDTO commande = serviceManager.getCommandeManager().getCommande(ligneCommande.getIdCommande());
		List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
		Set<InterventionDTO> interventions = new HashSet<InterventionDTO>();
		for (LigneCommandeDTO ligneCde : lignesCommande) {
			AccesLivraisonKey key = new AccesLivraisonKey(ligneCde);
			if (key.equals(accesLivraisonKey)) {
				// Utilisation d'un Set pour �viter d'avoir plusieurs fois la m�me intervention dans la liste
				interventions.addAll(getInterventions(ligneCde.getId(), etatInterventions));
			}
		}
		return new RendezVousDTO(ligneCommandeId, new ArrayList<InterventionDTO>(interventions));
	}

	/**
	 * Gets the interventions.
	 * 
	 * @param ligneCdeId the ligne cde id
	 * @param etatInterventions the etat interventions
	 * 
	 * @return the interventions
	 */
	private Set<InterventionDTO> getInterventions(String ligneCdeId, Set<String> etatInterventions) {
		Set<InterventionDTO> result = new HashSet<InterventionDTO>();
		List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeByLigneCommande(ligneCdeId);
		for (OpProgrammeeDTO opProgrammee : opProgrammees) {
			InterventionDTO intervention = opProgrammee.getIntervention();
			if (intervention != null && etatInterventions.contains(intervention.getEtatIntervention().getId())) {
				result.add(intervention);
			}
		}
		List<LigneCommandeDTO> lignesCdeInduites = serviceManager.getCommandeManager().findLigneCommandeInduiteByLigneCommande(ligneCdeId);
		for (LigneCommandeDTO ligneCdeInduite : lignesCdeInduites) {
			result.addAll(getInterventions(ligneCdeInduite.getId(), etatInterventions));
		}
		return result;
	}

	/**
	 * Update lignes commande date souhaitee and date contractuelle.
	 * 
	 * @param interventionId the intervention id
	 * @param debutPlage the debut plage
	 * @param dateContractuelleModifiee the date contractuelle modifiee
	 */
	private void updateLignesCommandeDateSouhaiteeAndDateContractuelle(String interventionId, Long debutPlage, boolean dateContractuelleModifiee) {
		// R�cup�ration de toutes les lignes de commande de la commande correspondant � l'intervention
		// (attention, c'est explicitement diff�rent que de r�cup�rer les lignes de commande d'une intervention
		// en passant par les OpProgramm�e, cf. TRT_ReservationPlage RG4)
		List<LigneCommandeDTO> ligneCommandes = serviceManager.getCommandeManager().findLigneCommandeByInterventionViaCommande(interventionId);

		// Parmi ces lignes de commande, seules certaines doivent �tre mise � jour
		if (!ligneCommandes.isEmpty()) {
			AccesLivraisonKey referenceAccesLivraisonKey = new AccesLivraisonKey(CollectionUtils.getFirstOrNull(ligneCommandes));
			for (LigneCommandeDTO lc : ligneCommandes) {
				AccesLivraisonKey key = new AccesLivraisonKey(lc);
				if (key.equals(referenceAccesLivraisonKey)) {

					// Cette ligne de commande doit �tre mise � jour
					lc.setDatabaseDateDateSouhaitee(debutPlage);
					if (dateContractuelleModifiee) {
						lc.setDatabaseDateDateContractuelle(debutPlage);
					}
					serviceManager.getCommandeManager().updateLigneCommandeDateSouhaiteAndDateContractuelle(lc);
				}
			}
		}
	}

	/**
	 * Gets the nature from intervention.
	 * 
	 * @param intervention the intervention
	 * 
	 * @return the nature from intervention
	 */
	private static String getNatureFromIntervention(InterventionDTO intervention) {
		List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeeByIntervention(intervention.getId());
		// seul le 1er �l�ment de la liste nous int�resse ( il ne peut pas y avoir de m�lange CLIENT/REPARTITEUR )
		if (opProgrammees.size() == 0) {
			// ne devrait jamais arriver
			return null;
		}

		return getNatureFromOpProgrammees(opProgrammees);
	}

	/**
	 * Gets the nature from les opProgrammees.
	 *
	 * @param opProgrammees la liste d'OpProgrammees
	 *
	 * @return the nature from intervention
	 */
	private static String getNatureFromOpProgrammees(List<OpProgrammeeDTO> opProgrammees) {
		String nature = StringUtils.EMPTY;
		if (!org.springframework.util.CollectionUtils.isEmpty(opProgrammees)) {
			List<TypeOpProgrammeeDTO> lstTypeOpProgrammee = new ArrayList<TypeOpProgrammeeDTO>();
			for (OpProgrammeeDTO opProgrammeeDTO: opProgrammees) {
				lstTypeOpProgrammee.add(opProgrammeeDTO.getTypeOpProgrammee());
			}
			setPrioEtNatureTypeOpProgrammees(lstTypeOpProgrammee);
			nature = getTypeOpProgrammeePrioritaire(lstTypeOpProgrammee).getNature();
		}
		return nature;
	}

	/**
	 * Mis � jour de la nature et prio de la liste types opProgrammees.
	 *
	 * @param lstTypeOpProgrammee la liste d'OpProgrammees
	 *
	 * @return the nature from intervention
	 */
	private static void setPrioEtNatureTypeOpProgrammees(List<TypeOpProgrammeeDTO> lstTypeOpProgrammee) {
		if (!org.springframework.util.CollectionUtils.isEmpty(lstTypeOpProgrammee)) {
			for (TypeOpProgrammeeDTO typeOpProgrammeeDTO : lstTypeOpProgrammee) {
				TypeOpProgrammeeDTO typeOpProgrammeeAvecNatureEtPrio = serviceManager.getReferenceSpaceManager().findInReferenceSpace(TypeOpProgrammeeDTO.class, typeOpProgrammeeDTO.getId());
				typeOpProgrammeeDTO.setNature(typeOpProgrammeeAvecNatureEtPrio.getNature());
				typeOpProgrammeeDTO.setPrio(typeOpProgrammeeAvecNatureEtPrio.getPrio());
			}
		}
	}

	/**
	 * Retourne le typeOpProgrammee avec nature prioritaire
	 *
	 * @param lstTypeOpProgrammee la liste d'OpProgrammees
	 *
	 * @return le type opProgrammee
	 */
	private static TypeOpProgrammeeDTO getTypeOpProgrammeePrioritaire(List<TypeOpProgrammeeDTO> lstTypeOpProgrammee) {
		TypeOpProgrammeeDTO typeOpProgrammeeDTO = null;
		if (!org.springframework.util.CollectionUtils.isEmpty(lstTypeOpProgrammee)) {
			Collections.sort(lstTypeOpProgrammee, new TypeOpProgrammeeDTO.SortByPrioComparator());
			typeOpProgrammeeDTO = lstTypeOpProgrammee.get(0);
		}
		return typeOpProgrammeeDTO;
	}

	/**
	 * Rechercher centre zone categorie pc.
	 * 
	 * @param intervention the intervention
	 * @param opProgrammees the op programmees
	 * @param ligneCommandes the ligne commandes
	 * @param commande the commande
	 * 
	 * @return the centre zone cat pc result
	 * 
	 * @throws RechercherPlageException the rechercher plage exception
	 * @throws CreateException the create exception
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>22/06/2011</TD><TD>CCL</TD><TD>IRMA 971 : Erreur parfois lors modification ou r�servation de RDV</TD></TR>
	 * </TABLE>
	 */
	private CentreZoneCatPCResult rechercherCentreZoneCategoriePC(InterventionDTO intervention, List<OpProgrammeeDTO> opProgrammees, List<LigneCommandeDTO> ligneCommandes, CommandeDTO commande) throws RechercherPlageException, CreateException {
		String methodName = "rechercherCentreZoneCategoriePC";
		String centre = null;
		String zone = null;
		String cmpact = null;
		String activ = null;
		String categoriePC = null;
		String warning = null;
		String nature = null;

		// A partir de l'objet intervention, rechercher s'il existe des champs dynamiques qui sont associ�s � centre, zone, cmpact, activ
		Map<String, String> dynamicInterventions = intervention.getDynamicInterventions();
		centre = dynamicInterventions.get(ConstantesDynamicIntervention.INTERVENTION_CENTRE);
		zone = dynamicInterventions.get(ConstantesDynamicIntervention.INTERVENTION_ZONE);
		cmpact = dynamicInterventions.get(ConstantesDynamicIntervention.INTERVENTION_CMPACT);
		activ = dynamicInterventions.get(ConstantesDynamicIntervention.INTERVENTION_ACTIV);

		LigneCommandeDTO ligneCommande = CollectionUtils.getFirstOrNull(ligneCommandes);
		Map<String, String> dynamicLdc = ligneCommande.getDynamicLigneCommandes();

		// Si zone et centre ne sont pas valoris�s ==> on va rechercher ces infos � partir de la ligne de commande
		if (StringUtils.isBlank(zone)) {
			zone = valoriserZoneAvecLigneCommande(dynamicInterventions, dynamicLdc);
		}
		if (StringUtils.isBlank(centre)) {
			centre = valoriserCentreAvecLigneCommande(dynamicInterventions, ligneCommande);
		}

		// Recherche de la nature de l'intervention
		boolean natureClientRepartiteur = false;
		for (OpProgrammeeDTO opProg : opProgrammees) {
			TypeOpProgrammeeDTO typeOpProg = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(TypeOpProgrammeeDTO.class, opProg.getTypeOpProgrammee().getId());
			nature = typeOpProg.getNature();
			if ((nature != null) && GpcDeclarations.NATURE_INTERV_CLIENTREPARTITEUR.equals(nature)) {
				ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "L'intervention est de nature CLIENTREPARTITEUR");
				natureClientRepartiteur = true;
				break;
			}
		}
		if (natureClientRepartiteur && StringUtils.isBlank(cmpact)) {
			if (!StringUtils.isBlank(activ)) {
				ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "activ est non vide ou non null");
				cmpact = TraductionManager.getInstance().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_20Z, ConstantesTraduction.CMPACT, activ);
				if (!StringUtils.isBlank(cmpact)) {
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "cmpact = " + cmpact);
				}
			} else {
				// R�cup�rer la cat�gorie PC
				cmpact = dynamicLdc.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_CATEGORIEPC);
				if (!StringUtils.isBlank(cmpact)) {
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "On r�cup�re la CategoriePC ==> cmpact = " + cmpact);
				} else {
					cmpact = CMPACT_DEFAUT;
					ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "cmpact = " + cmpact);
				}
			}
			dynamicInterventions.put(ConstantesDynamicIntervention.INTERVENTION_CMPACT, cmpact);
		} else {
			// jamais obligatoire mais si on l'a, on l'utilise
			cmpact = dynamicLdc.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_CATEGORIEPC);
			if (!StringUtils.isBlank(cmpact)) {
				ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "jamais obligatoire mais si on l'a, on l'utilise ==> cmpact = " + cmpact);
			}
		}

		// si le centre ou la zone ne sont toujours pas valoris�s
		if (StringUtils.isBlank(centre) || StringUtils.isBlank(zone)) {
			ServiceManager.getInstance().getLoggerManager().finest(RendezVousManagerBean.class.getName(), methodName, "Centre ou Zone ne sont toujours pas valoris�s");
			String typeAccesLivraisonOrigine = ligneCommande.getTypeAccesLivraisonOrigine();
			if (TypeAccesLivraisonEnum.ND.name().equals(typeAccesLivraisonOrigine)) {
				// RGANO01
				String message = ANOMALIE_MANAGER.getMessage(MessagesConstantes.NUM_42C_000080);
				SFAno ano = ANOMALIE_MANAGER.newSFAno(TraitementConstantes.RECHERCHEPLAGES, commande.getVersionArtemis() + "_" + AnomalieConstantes.ABS_CENTRE_ZONE_VALEUR_CONSTANTE, SFAno.TYPE_DNR, message);
				Evenement e = ANOMALIE_MANAGER.traiter(TraitementConstantes.RECHERCHEPLAGES, ano);
				throw new RechercherPlageException(e.getLibelle());
			}

			// Si le typeAccesLivraisonOrigine est diff�rent de "ND", il est n�cessaire d'appeler
			// le SF RechCentreZoneTransport pour r�cup�rer le centre et la zone transport et
			// dans certains cas la cat�gorie PC

			// i. G�n�ration des donn�es n�cessaires au SF RechCentreZoneTransport
			ProcessusDTO processus = serviceManager.getProcessusManager().findProcessusByLigneCommandeAndPereAndPlusRecent(ligneCommande.getId());
			List<RTechnique> rTechniqueList = new ArrayList<RTechnique>();
			if (processus != null) {
				rTechniqueList = serviceManager.getRessourcesTechManager().getRTechniques(processus.getId(), FiltreSappuieSur.TOUS_SAUF_SENSEVOL_CS);
			}
			PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(ligneCommande.getId());
			CommandeTraitee commandeTraitee = new CommandeTraitee(commande.getId(), commande.getDatabaseDateDateValidationFo().toString(), commande.getVersionArtemis(), commande.getRefExterne());
			String ndLocalisation = (psSouhaite != null) ? psSouhaite.getNd() : null;
			String critereLocalisation = (ligneCommande.getInstanceLocalisation() != null) ? ligneCommande.getInstanceLocalisation().getId() : null;
			IORechCentreZoneTransport ioRechCentreZoneTransport = new IORechCentreZoneTransport(rTechniqueList, critereLocalisation, ndLocalisation, commandeTraitee);

			// ii. Appeler le SF RechCentreZoneTransport avec en entr�e les RTechnique pr�c�demment charg�es
			SFAno ano = rechercherCentreZoneTransport(ioRechCentreZoneTransport);

			// iii. G�rer les anomalies retourn�es par le SF
			if (ano != null) {
				Evenement e = ANOMALIE_MANAGER.traiter(TraitementConstantes.RECHERCHEPLAGES, ano);
				boolean warn = SFAno.TYPE_AV.equals(ano.getType());
				if (!warn) {
					throw new RechercherPlageException(e.getLibelle());
				}
				warning = e.getLibelle();
			}

			// iv. Traiter les donn�es remont�es par le SF
			String zoneClient = null;
			String centreClient = null;
			String categoriePCClient = null;
			if (ioRechCentreZoneTransport.getCritereAdresseIntervention() != null) {
				zoneClient = ioRechCentreZoneTransport.getCritereAdresseIntervention().getZoneClient();
				centreClient = ioRechCentreZoneTransport.getCritereAdresseIntervention().getCentreClient();
				categoriePCClient = ioRechCentreZoneTransport.getCritereAdresseIntervention().getCategoriePC();
			}

			// Si Crit�reAdresseIntervention.CentreClient ou Crit�reAdresseIntervention.ZoneClient n'est pas valoris�
			if (StringUtils.isBlank(centreClient) || StringUtils.isBlank(zoneClient)) {
				// RGANO02
				String obj = "";
				if (StringUtils.isBlank(centreClient)) {
					obj = ConstantesDynamicIntervention.INTERVENTION_CENTRE;
				} else if (StringUtils.isBlank(zoneClient)) {
					obj = ConstantesDynamicIntervention.INTERVENTION_ZONE;
				}
				String message = ANOMALIE_MANAGER.getMessage(MessagesConstantes.RCHEPLAGES_000060, new Object[] { obj });
				SFAno anomalieAbs = ANOMALIE_MANAGER.newSFAno(TraitementConstantes.RECHERCHEPLAGES, commande.getVersionArtemis() + "_" + AnomalieConstantes.ABS_DONNEES_PROPOSER_VALEUR_CONSTANTE, SFAno.TYPE_DNR, message);
				Evenement e = ANOMALIE_MANAGER.traiter(TraitementConstantes.RECHERCHEPLAGES, anomalieAbs);
				throw new RechercherPlageException(e.getLibelle());
			}

			// Sauver ces donn�es dans les lignes de commande concern�es et en param�tres de l'intervention
			for (LigneCommandeDTO lcToUpdate : ligneCommandes) {
				Map<String, String> dynamicLcToUpdate = lcToUpdate.getDynamicLigneCommandes();
				String critereLocalisationToUpdate = (lcToUpdate.getInstanceLocalisation() != null) ? lcToUpdate.getInstanceLocalisation().getId() : null;
				InstanceSeDTO instSE = serviceManager.getLocalisationManager().getInstanceSEDTO(commande.getVersionArtemis() + "_" + ServiceExterneConstantes.S42C_CONSREP_A_VALEUR_CONSTANTE, critereLocalisationToUpdate);
				// CentreClient
				RepartiteurDTO repartiteur = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RepartiteurDTO.class, new Comparaison(Repartiteur.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, centre),
						new Comparaison(Repartiteur.SLINK_GEREE_PAR_INSTANCE_S_E, Constantes.OPERATOR_EQUAL, instSE.getId()));
				lcToUpdate.setRepartiteur(repartiteur);
				// ZoneClient
				dynamicLcToUpdate.put(ConstantesDynamicLigneCommande.LIGNECOMMANDE_ZONE, zoneClient);
				// CategoriePC
				dynamicLcToUpdate.put(ConstantesDynamicLigneCommande.LIGNECOMMANDE_CATEGORIEPC, categoriePCClient);

				// Sauvegarde des champs modifi�s
				serviceManager.getCommandeManager().updateLigneCommandeRepartiteur(lcToUpdate);
				serviceManager.getCommandeManager().updateDynamicLigneCommande(lcToUpdate);
			}
			dynamicInterventions.put(ConstantesDynamicIntervention.INTERVENTION_CENTRE, centreClient);
			dynamicInterventions.put(ConstantesDynamicIntervention.INTERVENTION_ZONE, zoneClient);
			dynamicInterventions.put(ConstantesDynamicIntervention.INTERVENTION_CMPACT, categoriePCClient);
		}

		// Sauvegarde des dynamics modifi�s
		serviceManager.getCommandeManager().updateDynamicIntervention(intervention);

		return new CentreZoneCatPCResult(centre, zone, warning, categoriePC, cmpact);
	}

	/**
	 * Recherche la zone sur la ligne de commande
	 * 
	 * @param dynamicInterventions les infos dynamiques de l'intervention
	 * @param dynamicLdc les infos dynamiques de la ligne de commande
	 * @return la zone
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>14/09/2011</TD><TD>GPA</TD><TD>Cr�ation de la m�thode pour r�duire la complexit� cyclomatique de la m�thode appelante</TD></TR>
	 * </TABLE>
	 */
	private String valoriserZoneAvecLigneCommande(Map<String, String> dynamicInterventions, Map<String, String> dynamicLdc) {
		String methode = "valoriserZoneAvecLigneCommande";
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methode, "zone n'a pas �t� valoris�e ==> Contr�ler la pr�sence de la cl� Zone parmi les param�tres dynmiques de la ligne de commande");

		// Contr�ler la pr�sence de la cl� Zone parmi les param�tres dynmiques de la ligne de commande
		String zone = dynamicLdc.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_ZONE);
		if (!StringUtils.isBlank(zone)) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methode, "zone = " + zone);
			dynamicInterventions.put(ConstantesDynamicIntervention.INTERVENTION_ZONE, zone);
		}

		return zone;
	}

	/**
	 * Recherche du centre sur la ligne de commande
	 * 
	 * @param dynamicInterventions les infos dynamiques de l'intervention
	 * @return le centre
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>14/09/2011</TD><TD>GPA</TD><TD>Cr�ation de la m�thode pour r�duire la complexit� cyclomatique de la m�thode appelante</TD></TR>
	 * </TABLE>
	 */
	private String valoriserCentreAvecLigneCommande(Map<String, String> dynamicInterventions, LigneCommandeDTO ligneCommande) {
		String methode = "valoriserCentreAvecLigneCommande";
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methode, "centre n'a pas �t� valoris�e ==> Contr�ler la pr�sence de la cl� Centre parmi les param�tres dynmiques de la ligne de commande");

		// Contr�ler la pr�sence de la cl� Centre parmi les param�tres dynmiques de la ligne de commande
		String centre = "";
		if (ligneCommande.getRepartiteur() != null) {
			RepartiteurDTO repartiteur = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RepartiteurDTO.class, ligneCommande.getRepartiteur().getId());
			if (repartiteur != null) {
				centre = repartiteur.getValeurExterne();
				if (!StringUtils.isBlank(centre)) {
					ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methode, "centre = " + centre);
					dynamicInterventions.put(ConstantesDynamicIntervention.INTERVENTION_CENTRE, centre);
				}
			}
		}

		return centre;
	}

	/**
	 * Gets the rechercher plage offre cible.
	 * 
	 * @param lc the lc
	 * 
	 * @return the rechercher plage offre cible
	 */
	private String getRechercherPlageOffreCible(LigneCommandeDTO lc) {
		Map<String, String> dynamicsLigneCommande = lc.getDynamicLigneCommandes();
		String result = dynamicsLigneCommande.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OFFRECIBLE);
		if (result == null) {
			result = EMPTY_STRING;
		}
		return result;
	}

	/**
	 * Gets the rechercher plage offre existante.
	 * 
	 * @param lc the lc
	 * 
	 * @return the rechercher plage offre existante
	 */
	private String getRechercherPlageOffreExistante(LigneCommandeDTO lc) {
		Map<String, String> dynamicsLigneCommande = lc.getDynamicLigneCommandes();
		String result = dynamicsLigneCommande.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OFFREEXISTANTE);
		if (result == null) {
			result = EMPTY_STRING;
		}
		return result;
	}

	/**
	 * Gets the rechercher plage ps souhaite dynamic fields.
	 * 
	 * @param psSouhaite the ps souhaite
	 * 
	 * @return the rechercher plage ps souhaite dynamic fields
	 */
	private Map<String, String> getRechercherPlagePsSouhaiteDynamicFields(PsSouhaiteDTO psSouhaite) {
		Map<String, String> result = new HashMap<String, String>();
		for (Map.Entry<String, String> entry : psSouhaite.getDynamicPsSouhaites().entrySet()) {
			if (entry.getKey().startsWith(PARAM_DETENTION_PREFIX)) {
				result.put(entry.getKey(), entry.getValue());
			}
		}
		return result;
	}

	/**
	 * {@inheritDoc}
	 */
	public InterventionDTO createInterventionFille(InterventionDTO interventionPrecedente) throws CreateException {
		InterventionDTO intervention = new InterventionDTO(serviceManager.getGeneratorManager().generateKey());
		intervention.setSuitIntervention(interventionPrecedente);
		intervention.setInstanceOg(interventionPrecedente.getInstanceOg());
		intervention.setReference(interventionPrecedente.getReference());
		intervention.setRefErdv(interventionPrecedente.getRefErdv());
		// IRMA_846: R�cup�ration de la refExterne de l'intervention pr�c�dente
		intervention.setRefExterne(interventionPrecedente.getRefExterne());
		intervention.setMescontr(interventionPrecedente.getMescontr());
		intervention.setDynamicInterventions(interventionPrecedente.getDynamicInterventions());
		serviceManager.getCommandeManager().createIntervention(intervention);

		List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeeByIntervention(interventionPrecedente.getId());
		for (OpProgrammeeDTO opProgrammee : opProgrammees) {
			opProgrammee.setIntervention(intervention);
			serviceManager.getCommandeManager().updateOpProgrammeeIntervention(opProgrammee);
		}

		return intervention;
	}

	/**
	 * Modification intervention.
	 * 
	 * @param interventionExistante the intervention existante
	 * @param crit the crit
	 * @param plage the plage
	 * @param responsabiliteId the responsabilite id
	 * @param contexte the contexte
	 * @param obs the obs
	 * @param agentDTO the agent dto
	 * 
	 * @return the reserver plage result dto
	 * 
	 * @throws ReserverPlageException the reserver plage exception
	 * @throws CreateException the create exception
	 * @throws RemoveException the remove exception
	 */
	private ReserverPlageResultDTO modificationIntervention(InterventionDTO interventionExistante, CritereIntervention crit, Plage plage, String responsabiliteId, ContexteModification contexte, String obs, AgentDTO agentDTO)
			throws ReserverPlageException, CreateException, RemoveException {
		LigneCommandeDTO firstLigneCde = findFirstLigneCommandeFromFirstOpByIntervention(interventionExistante.getId());
		CommandeDTO commande = serviceManager.getCommandeManager().getCommande(firstLigneCde.getIdCommande());
		ReserverPlageResultDTO res = new ReserverPlageResultDTO();
		String etatIntervention = interventionExistante.getEtatIntervention().getId();
		if (EtatInterventionConstantes.PLANIF.equals(etatIntervention)) {

			// /R�cup�ration de la version de la commande
			String version = commande.getVersionArtemis();

			// Mettre � jour les objets bolbec sans appel au SF ni au wkf
			res = majIntervention(interventionExistante, responsabiliteId, contexte, plage, crit, version, interventionExistante.getRefExterne(), agentDTO);
			res.setCode(OK_STRING);
		} else if (EtatInterventionConstantes.RESERV.equals(etatIntervention) || EtatInterventionConstantes.ENVOI.equals(etatIntervention) || EtatInterventionConstantes.AMODIF.equals(etatIntervention)) {
			res = modifierPlage(interventionExistante, plage, crit, responsabiliteId, contexte, obs, agentDTO);
			res.setCode(OK_STRING);
			try {
				// IRMA_846 : utilisation de l'id de la nouvelle intervention au lieu de celui de l'intervention existante
				impactWorkflow(plage, res.getNouvelleIntervention().getId(), crit, agentDTO, commande);
			} catch (WfException we) {
				res.setCode(KO_GPC_OK_STRING);
			} catch (RuntimeException re) {
				// On catch ici toutes les exceptions de type Runtime
				// afin que le service retourne un objet non null et
				// ne bloque pas l'application appelante
				res.setCode(KO_GPC_OK_STRING);
			}
		} else if (EtatInterventionConstantes.REPORT.equals(etatIntervention)) {
			InterventionDTO interventionHistorisees = interventionExistante.getSuitIntervention();
			boolean hasInterventionHistorisee = false;
			if (interventionHistorisees != null) {
				hasInterventionHistorisee = true;
				while (hasInterventionHistorisee) {
					if (EtatInterventionConstantes.ENVOI.equals(interventionHistorisees.getEtatIntervention().getId()) || EtatInterventionConstantes.RESERV.equals(interventionHistorisees.getEtatIntervention().getId())) {
						res = modifierPlage(interventionExistante, plage, crit, responsabiliteId, contexte, obs, agentDTO);
						res.setCode(OK_STRING);
						try {
							impactWorkflow(plage, res.getInterventionId(), crit, agentDTO, commande);
						} catch (WfException we) {
							res.setCode(KO_GPC_OK_STRING);
						} catch (RuntimeException re) {
							// On catch ici toutes les exceptions de type Runtime
							// afin que le service retourne un objet non null et
							// ne bloque pas l'application appelante
							res.setCode(KO_GPC_OK_STRING);
						}
						break;
					}
					hasInterventionHistorisee = false;
					interventionHistorisees = interventionHistorisees.getSuitIntervention();
				}
			}
		} else {
			res.setCode(KO_STRING);
		}
		return res;
	}

	/**
	 * Maj intervention.
	 * 
	 * @param intervention the intervention
	 * @param responsabiliteId the responsabilite id
	 * @param contexte the contexte
	 * @param plageRetenue the plage retenue
	 * @param critereIntervention the critere intervention
	 * @param versionArtemis the version bolbec
	 * @param refExterne the ref externe
	 * @param agentDTO the agent dto
	 * 
	 * @return the reserver plage result dto
	 * 
	 * @throws CreateException the create exception
	 * @throws RemoveException the remove exception
	 * 
	 * <B>HISTORIQUE DES MODIFICATIONS:</B>
	 * <TABLE frame='border' ><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/05/2011</TD><TD>CCL</TD><TD>IRMA 980 : Perte des donn�es Observation sur les interventions</TD></TR>
	 * </TABLE>
	 */
	private ReserverPlageResultDTO majIntervention(InterventionDTO intervention, String responsabiliteId, ContexteModification contexte, Plage plageRetenue, CritereIntervention critereIntervention, String versionArtemis, String refExterne,
			AgentDTO agentDTO) throws CreateException, RemoveException {

		// Cr�ation de l'intervention fille et duplication des champs dynamiques
		InterventionDTO nouvelleIntervention = createInterventionFille(intervention);

		// Mise � jour de l'intervention report�e
		String etatIntervention = intervention.getEtatIntervention().getId();
		intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.REPORT));
		serviceManager.getCommandeManager().updateInterventionEtat(intervention);
		Map<String, String> dynamicsIntervention = intervention.getDynamicInterventions();
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CODEMODIF, DEPLACE_STRING);
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ORIGINEDEMANDE, contexte.getBasicat());
		SystemeExterneDTO systExt = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, new Comparaison(SystemeExterne.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, contexte.getBasicat()),
				new Comparaison(SystemeExterne.FIELD_VERSION, Constantes.OPERATOR_EQUAL, versionArtemis));
		String libelleModif = REPORT_VIA_PREFIX + systExt.getNom();
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_LIBELLEMODIF, libelleModif);

		// RG8 : Valorisation du responsable modification
		String prenom = agentDTO.getPrenom() != null ? agentDTO.getPrenom() : "";
		String nom = agentDTO.getNom() != null ? agentDTO.getNom() : "";
		String resp_modif = prenom + " " + nom;
		if (!StringUtils.isBlank(resp_modif.trim())) {
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_RESP_MODIF, resp_modif);
		}
		serviceManager.getCommandeManager().updateDynamicIntervention(intervention);

		// Fin mise � jour de l'intervention report�e
		// MAJ de la nouvelle intervention
		nouvelleIntervention.setReference(intervention.getReference());
		nouvelleIntervention.setRefExterne(refExterne);
		// EV000037 - Formatage r�aliser dans l'objet Plage
		Long debutPlage = DateUtils.getDatabaseDate(plageRetenue.getDebut());
		Long finPlage = null;

		if (plageRetenue.getDuree() == null) {
			Calendar cal = Calendar.getInstance();
			cal.setTime(plageRetenue.getDebut());
			cal.add(Calendar.HOUR, 1);
			finPlage = DateUtils.getDatabaseDate(cal.getTime());
		} else {
			nouvelleIntervention.setDuree(plageRetenue.getDuree());
			finPlage = DateUtils.getDatabaseDate(plageRetenue.getFin());
		}

		nouvelleIntervention.setDatabaseDateDebutPlage(debutPlage);
		nouvelleIntervention.setDatabaseDateFinPlage(finPlage);
		nouvelleIntervention.setDatabaseDateDatePrise(DateUtils.getDatabaseDate());

		// RG7
		nouvelleIntervention.setObservation(plageRetenue.getObservation());
		updateInterventionObservation(nouvelleIntervention);
		if (EtatInterventionConstantes.AMODIF.equals(etatIntervention)) {
			nouvelleIntervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.RESERV));
		} else {
			nouvelleIntervention.setEtatIntervention(new EtatInterventionDTO(etatIntervention));
			if (EtatInterventionConstantes.ENVOI.equals(etatIntervention)) {
				nouvelleIntervention.setDatabaseDateDateEnvoiOt(DateUtils.getDatabaseDate());
			}
		}

		String responsabilite;
		boolean responsabiliteForceeInitiativeFT = false;
		if (intervention.getResponsabilite() != null && ResponsabiliteConstantes.INITIATIVE_FT.equals(intervention.getResponsabilite().getId())) {
			responsabiliteForceeInitiativeFT = true;
			responsabilite = ResponsabiliteConstantes.INITIATIVE_FT;
		} else {
			responsabilite = responsabiliteId;
		}
		nouvelleIntervention.setResponsabilite(new ResponsabiliteDTO(responsabilite));
		nouvelleIntervention.setMescontr(intervention.getMescontr());

		// champs dynamiques Intervention
		Map<String, String> dynamicsNouvelleIntervention = nouvelleIntervention.getDynamicInterventions();
		dynamicsNouvelleIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ACTIV, critereIntervention.getActiv());
		dynamicsNouvelleIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CENTRE, critereIntervention.getCentre());
		dynamicsNouvelleIntervention.put(ConstantesDynamicIntervention.INTERVENTION_PROD, critereIntervention.getProd());
		dynamicsNouvelleIntervention.put(ConstantesDynamicIntervention.INTERVENTION_SEGMA, critereIntervention.getSegma());
		dynamicsNouvelleIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ZONE, critereIntervention.getZone());
		dynamicsNouvelleIntervention.put(ConstantesDynamicIntervention.INTERVENTION_UI, plageRetenue.getCodeUi());

		serviceManager.getCommandeManager().updateDynamicIntervention(nouvelleIntervention);
		serviceManager.getCommandeManager().updateIntervention(nouvelleIntervention);

		String responsabilitenouvelleIntervention = nouvelleIntervention.getResponsabilite().getId();
		boolean dateContractuelleModifiee = ResponsabiliteConstantes.INITIATIVE_CLIENT.equals(responsabilitenouvelleIntervention) || ResponsabiliteConstantes.INITIATIVE_OPERATEUR.equals(responsabilitenouvelleIntervention);
		if (debutPlage != null) {
			updateLignesCommandeDateSouhaiteeAndDateContractuelle(nouvelleIntervention.getId(), debutPlage, dateContractuelleModifiee);
		}
		// IRM_846: Remonter de l'intervention cr��e
		ReserverPlageResultDTO ress = new ReserverPlageResultDTO(dateContractuelleModifiee, responsabiliteForceeInitiativeFT, nouvelleIntervention.getId(), OK_STRING);
		ress.setNouvelleIntervention(nouvelleIntervention);
		return ress;
	}

	/**
	 * Modifier plage.
	 * 
	 * @param interventionExistante the intervention existante
	 * @param plage the plage
	 * @param critereIntervention the critere intervention
	 * @param responsabiliteId the responsabilite id
	 * @param contexte the contexte
	 * @param obsSupplementaires the obs supplementaires
	 * @param agentDTO the agent dto
	 * 
	 * @return the reserver plage result dto
	 * 
	 * @throws RemoveException the remove exception
	 * @throws CreateException the create exception
	 * @throws ReserverPlageException the reserver plage exception
	 * 
	 * <B>HISTORIQUE DES MODIFICATIONS:</B>
	 * <TABLE frame='border' ><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/05/2011</TD><TD>CCL</TD><TD>IRMA 980 : Perte des donn�es Observation sur les interventions</TD></TR>
	 * </TABLE>
	 */
	private ReserverPlageResultDTO modifierPlage(InterventionDTO interventionExistante, Plage plage, CritereIntervention critereIntervention, String responsabiliteId, ContexteModification contexte, String obsSupplementaires, AgentDTO agentDTO)
			throws RemoveException, CreateException, ReserverPlageException {

		Long dateContractuelle = null;
		String critereLocalisation = null;
		String ndLocalisation = null;
		String versionArtemis = null;
		CommandeTraitee commandeTraitee = null;

		// r�cup�ration de la liste des Op�rations Programm�es associ�es
		List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeeByIntervention(interventionExistante.getId());
		for (OpProgrammeeDTO opProgrammee : opProgrammees) {

			// r�cup�ration LigneCommande associ�e � l'op�ration programm�e
			List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByOpProgrammee(opProgrammee.getId());
			LigneCommandeDTO firstLigneCommande = CollectionUtils.getFirstOrNull(lignesCommande);

			// Construction de l'objet commandeTraitee
			CommandeDTO commande = serviceManager.getCommandeManager().getCommande(firstLigneCommande.getIdCommande());
			commandeTraitee = new CommandeTraitee(commande.getId(), commande.getDatabaseDateDateValidationFo().toString(), commande.getVersionArtemis(), commande.getRefExterne());

			// valorisation date souhait�e (on valorise une seule fois)
			if (dateContractuelle == null) {
				dateContractuelle = firstLigneCommande.getDatabaseDateDateContractuelle();
			}
			if (versionArtemis == null) {
				versionArtemis = commande.getVersionArtemis();
			}
			if (ndLocalisation == null) {
				if (TypeAccesLivraisonEnum.ND.name().equals(firstLigneCommande.getTypeAccesLivraison())) {
					ndLocalisation = firstLigneCommande.getAccesLivraison();
				} else if (TypeAccesLivraisonEnum.IDCLI.name().equals(firstLigneCommande.getTypeAccesLivraison())) {
					ndLocalisation = firstLigneCommande.getNdFinder();
				}
			}

			// valorisation critereLocalisation (on valorise une seule fois)
			if (critereLocalisation == null) {
				critereLocalisation = firstLigneCommande.getInstanceLocalisation().getId();
			}
		}
		String cleRecherche = ndLocalisation;

		// RG6 - Plage.Observations pour appel au SF_ModifierPlage
		Map<String, String> dynamicsIntervention = interventionExistante.getDynamicInterventions();
		String mesContr = interventionExistante.getMescontr();
		String obsOut = "";
		String obsExistantes = interventionExistante.getObservation();
		if (obsExistantes == null) {
			obsExistantes = "";
		}

		if (mesContr != null) {
			if (!(NON_STRING.equals(mesContr)) && (mesContr.length() > 0)) {

				// Indique le besoin du libell� de mise en service contradictoire
				// sp�cifique (li� au type de Techno DSL ou au num�ro d'appel)
				// Si il est � False, il faut ajouter le libell� g�n�rique de MESCONTR
				boolean isMesContrSpecific = false;
				// Intervention.<<dynamic>>typeTechnoDSL
				String typeTechnoDSLValeur = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_TYPE_TECHNO_DSL);
				if (!StringUtils.isBlank(typeTechnoDSLValeur)) {
					String tmp = ANOMALIE_MANAGER.getMessage(MessagesConstantes.MESCONTR_000020, typeTechnoDSLValeur);
					isMesContrSpecific = true;
					if (obsExistantes.indexOf(tmp) == -1) {
						obsOut += tmp;
					}
				}

				// Intervention.<<dynamic>>numAppelMes
				String numAppelMesValeur = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_NUM_APPEL_MES);
				if (!StringUtils.isBlank(numAppelMesValeur)) {
					String tmp = ANOMALIE_MANAGER.getMessage(MessagesConstantes.MESCONTR_000030, numAppelMesValeur);
					isMesContrSpecific = true;
					if (obsExistantes.indexOf(tmp) == -1) {
						obsOut += tmp;
					}
				}
				if (!isMesContrSpecific) {
					String tmp = ANOMALIE_MANAGER.getMessage(MessagesConstantes.MESCONTR_000010);
					if (obsExistantes.indexOf(tmp) == -1) {
						obsOut += tmp;
					}
				}
			}
		}

		// On a g�n�r� dans observations les observations fonctionnelles li�es �
		// la mise en service contradictoire
		// On doit ajouter dans observations, avant d'impacter l'intervention
		// modifi�e, les �ventuelles observations existantes sur l'intervention.
		if (obsOut.length() > 0) {
			if (obsExistantes.length() > 0) {
				obsOut = obsExistantes + "; " + obsOut;
			}
		} else {
			obsOut = obsExistantes;
		}
		if ((obsSupplementaires != null) && (obsSupplementaires.length() > 0)) {

			// Si le param�tre d'entr�e Intervention.Observations est valoris�
			if (StringUtils.isEmpty(obsOut)) {
				obsOut = obsSupplementaires;
			} else {
				obsOut += "; " + obsSupplementaires;
			}
		}
		critereIntervention.setCleRecherche(cleRecherche);

		// Troncature � 1000 caracteres du champ Observations (longuer max sur BD)
		if (obsOut.length() > OBSERVATION_MAX_SIZE) {
			plage.setObservation(obsOut.substring(0, OBSERVATION_MAX_SIZE));
		} else {
			plage.setObservation(obsOut);
		}

		String refKyaku = interventionExistante.getDynamicInterventions().get(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU);
		boolean isPerimKyaku = ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU_OUI.equals(interventionExistante.getDynamicInterventions().get(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU));
		IOModifierPlage ioModifierPlage = new IOModifierPlage(critereLocalisation, ndLocalisation, interventionExistante.getReference(), interventionExistante.getRefExterne(), critereIntervention, plage, commandeTraitee,
				DateUtils.getDatabaseDate(dateContractuelle), refKyaku, responsabiliteId, isPerimKyaku);
		ioModifierPlage.setVersionArtemis(versionArtemis);
		return modifierPlage(interventionExistante, ioModifierPlage, responsabiliteId, contexte, agentDTO);
	}

	/**
	 * Modifier plage.
	 * 
	 * @param intervention the intervention
	 * @param ioModifierPlage the io modifier plage
	 * @param responsabiliteId the responsabilite id
	 * @param contexte the contexte
	 * @param agentDTO the agent dto
	 * 
	 * @return the reserver plage result dto
	 * 
	 * @throws ReserverPlageException the reserver plage exception
	 * @throws CreateException the create exception
	 * @throws RemoveException the remove exception
	 */
	private ReserverPlageResultDTO modifierPlage(InterventionDTO intervention, IOModifierPlage ioModifierPlage, String responsabiliteId, ContexteModification contexte, AgentDTO agentDTO) throws ReserverPlageException, CreateException, RemoveException {

		// Initialisation d'un objet par d�faut (Retourn� dans le cas d'un appel WebService)
		final ReserverPlageResultDTO res;

		LigneCommandeDTO firstLigneCde = findFirstLigneCommandeFromFirstOpByIntervention(intervention.getId());
		String idCommande = firstLigneCde.getIdCommande();
		// Si ce n'est pas un appel WebService (Cas nominal appel � GPC)
		if (!ContexteModification.APPEL_WEBSERVICE_STRING.equals(contexte.getAppel())) {
			SFAno ano = InterventionUtil.modifierPlage(ioModifierPlage);
			Evenement evenement = null;
			if (ano != null) {
				if (!ContexteModification.APPEL_WEBSERVICE_STRING.equals(contexte.getAppel())) {
					evenement = ANOMALIE_MANAGER.traiter(TraitementConstantes.MODIFICATIONPLAGE, ano);
					boolean erreurBloquante = CategorieEvenementConstantes.POPBQ.equals(evenement.getIdCategorieEvenement());
					if (erreurBloquante) {
						throw new ReserverPlageException(evenement.getLibelle());
					}
				} else {
					evenement = ANOMALIE_MANAGER.traiter(TraitementConstantes.MODIFICATIONPLAGE, ano);
					throw new ReserverPlageException(evenement.getLibelle());
				}
			}

			// Traitement des objets renvoy�s par le SF
			// r�cup�ration de l'interv r�serv�e
			InterventionReservee interventionReservee = ioModifierPlage.getInterventionReservee();
			Plage plageRetenue = ioModifierPlage.getPlage();
			CritereIntervention critereIntervention = ioModifierPlage.getCritereIntervention();
			res = majIntervention(intervention, responsabiliteId, contexte, plageRetenue, critereIntervention, ioModifierPlage.getVersionArtemis(), interventionReservee.getReference(), agentDTO);
			String warning = (evenement != null) ? evenement.getLibelle() : null;
			res.setReservationWarning(warning);
		} else {
			// EV-377 ROME Offre
			CommandeDTO commande = serviceManager.getCommandeManager().getCommande(idCommande);
			String casMetier = null;
			if (commande != null && commande.getCasMetier() != null) {
				casMetier = commande.getCasMetier().getId();
			}

			// IRMA_846 : mise � jour de la refexterne avec la valeur de la refexterne de l'intervention et non pas la reference de l'intervention
			res = majIntervention(intervention, responsabiliteId, contexte, ioModifierPlage.getPlage(), ioModifierPlage.getCritereIntervention(), ioModifierPlage.getVersionArtemis(), intervention.getRefExterne(), agentDTO);

			// EV-377 ROME Offre
			if (CasMetierConstantes.CR_FTTE.equals(casMetier) || CasMetierConstantes.SU_FTTE.equals(casMetier)) {
				res.setCode(KO_STRING);
			}
		}

		NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_I, NotificationGeneriqueConstantes.MODIFIERINTERV, intervention.getId(), idCommande);
		serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

		return res;
	}

	/**
	 * Reserver plage.
	 * 
	 * @param interventionExistante the intervention existante
	 * @param plage the plage
	 * @param critereIntervention the critere intervention
	 * @param responsabiliteId the responsabilite id
	 * @param agentDTO the agent dto
	 * 
	 * @return the reserver plage result dto
	 * 
	 * @throws RemoveException the remove exception
	 * @throws ReserverPlageException the reserver plage exception
	 * @throws CreateException the create exception
	 * 
	 * <B>HISTORIQUE DES MODIFICATIONS:</B>
	 * <TABLE frame='border' ><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/05/2011</TD><TD>CCL</TD><TD>IRMA 980 : Perte des donn�es Observation sur les interventions</TD></TR>
	 * </TABLE>
	 */
	private ReserverPlageResultDTO reserverPlage(InterventionDTO interventionExistante, Plage plage, CritereIntervention critereIntervention, String responsabiliteId, AgentDTO agentDTO) throws RemoveException, ReserverPlageException, CreateException {

		Long dateContractuelle = null;
		String critereLocalisation = null;
		String ndLocalisation = null;
		String versionArtemis = null;
		CommandeTraitee commandeTraitee = null;

		// r�cup�ration de la liste des Op�rations Programm�es associ�es
		List<OpProgrammeeDTO> opProgrammees = serviceManager.getCommandeManager().findOpProgrammeeByIntervention(interventionExistante.getId());
		for (OpProgrammeeDTO opProgrammee : opProgrammees) {

			// r�cup�ration LigneCommande associ�e � l'op�ration programm�e
			List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByOpProgrammee(opProgrammee.getId());
			LigneCommandeDTO firstLigneCommande = CollectionUtils.getFirstOrNull(lignesCommande);

			// Construction de l'objet commandeTraitee
			CommandeDTO commande = serviceManager.getCommandeManager().getCommande(firstLigneCommande.getIdCommande());
			commandeTraitee = new CommandeTraitee(commande.getId(), commande.getDatabaseDateDateValidationFo().toString(), commande.getVersionArtemis(), commande.getRefExterne());

			// valorisation date souhait�e (on valorise une seule fois)
			if (dateContractuelle == null) {
				dateContractuelle = firstLigneCommande.getDatabaseDateDateContractuelle();
			}
			if (versionArtemis == null) {
				versionArtemis = commande.getVersionArtemis();
			}

			if (ndLocalisation == null) {
				if (TypeAccesLivraisonEnum.ND.name().equals(firstLigneCommande.getTypeAccesLivraison())) {
					ndLocalisation = firstLigneCommande.getAccesLivraison();
				} else if (TypeAccesLivraisonEnum.IDCLI.name().equals(firstLigneCommande.getTypeAccesLivraison()) && commande.getStatutCommande() != null && StatutCommandeConstantes.AGREGEE.equals(commande.getStatutCommande().getId())
						&& commande.getCasMetier() != null && CasMetierConstantes.CR_FTTH.equals(commande.getCasMetier().getId())) {
					ndLocalisation = firstLigneCommande.getNdFinder();
				}
			}

			// valorisation critereLocalisation (on valorise une seule fois)
			if (critereLocalisation == null) {
				critereLocalisation = firstLigneCommande.getInstanceLocalisation().getId();
			}
		}
		String cleRecherche = ndLocalisation;
		String obsOut = "";
		Map<String, String> dynamicsIntervention = interventionExistante.getDynamicInterventions();
		String mesContr = interventionExistante.getMescontr();
		if (mesContr != null) {
			if (!(NON_STRING.equals(mesContr)) && (mesContr.length() > 0)) {

				// Intervention.<<dynamic>>typeTechnoDSL
				String typeTechnoDSLValeur = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_TYPE_TECHNO_DSL);
				if ((typeTechnoDSLValeur != null) && (typeTechnoDSLValeur.length() > 0)) {
					obsOut += ANOMALIE_MANAGER.getMessage(MessagesConstantes.MESCONTR_000020, typeTechnoDSLValeur);
				}

				// Intervention.<<dynamic>>numAppelMes
				String numAppelMesValeur = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_NUM_APPEL_MES);
				if ((numAppelMesValeur != null) && (numAppelMesValeur.length() > 0)) {
					obsOut += ANOMALIE_MANAGER.getMessage(MessagesConstantes.MESCONTR_000030, numAppelMesValeur);
				}
				if (StringUtils.isEmpty(obsOut)) {
					obsOut += ANOMALIE_MANAGER.getMessage(MessagesConstantes.MESCONTR_000010);
				}
			}
		}
		critereIntervention.setCleRecherche(cleRecherche);
		if (StringUtils.isNotEmpty(obsOut)) {
			plage.setObservation(obsOut);
		}
		String perimKyaku = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU);
		critereIntervention.setPerimKyaku(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU_OUI.equals(perimKyaku));
		IOReserverPlage ioReserverPlage = new IOReserverPlage(critereLocalisation, ndLocalisation, critereIntervention, plage, commandeTraitee, DateUtils.getDatabaseDate(dateContractuelle));
		ioReserverPlage.setVersionArtemis(versionArtemis);
		ioReserverPlage.setRefInt(interventionExistante.getReference());
		return reserverPlage(interventionExistante, ioReserverPlage, responsabiliteId, agentDTO, commandeTraitee.getId());
	}

	/**
	 * Reserver plage.
	 * 
	 * @param intervention the intervention
	 * @param ioReserverPlage the io reserver plage
	 * @param responsabiliteId the responsabilite id
	 * @param agentDTO the agent dto
	 * 
	 * @return the reserver plage result dto
	 * 
	 * @throws ReserverPlageException the reserver plage exception
	 * @throws CreateException the create exception
	 * @throws RemoveException the remove exception
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>13/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1236 Correction d'anomalies trouv�es par FindBugs</TD></TR>
	 * </TABLE>
	 */
	private ReserverPlageResultDTO reserverPlage(InterventionDTO intervention, IOReserverPlage ioReserverPlage, String responsabiliteId, AgentDTO agentDTO, String idCommande) throws ReserverPlageException, CreateException, RemoveException {

		// Appel du SF
		SFAno ano = InterventionUtil.reserverPlage(ioReserverPlage);
		Evenement evenement = null;
		if (ano != null) {
			evenement = ANOMALIE_MANAGER.traiter(TraitementConstantes.RESERVATIONPLAGE, ano);
			boolean erreurBloquante = CategorieEvenementConstantes.POPBQ.equals(evenement.getIdCategorieEvenement());
			if (erreurBloquante) {
				historiserInterventionNonReservee(intervention);
				throw new ReserverPlageException(evenement.getLibelle());
			}
		}

		boolean isDateOTRenseigne = false;
		if (intervention.getSuitIntervention() != null) {
			isDateOTRenseigne = intervention.getSuitIntervention().getDatabaseDateDateEnvoiOt() != null;
		}

		// Traitement des objets renvoy�s par le SF
		// r�cup�ration de l'interv r�serv�e
		InterventionReservee interventionReservee = ioReserverPlage.getInterventionReservee();
		// ici
		Long debutPlageAncienneIntervention = intervention.getDatabaseDateDebutPlage();
		Long debutPlage = DateUtils.getDatabaseDate(ioReserverPlage.getPlageRetenue().getDebut());
		if ((debutPlageAncienneIntervention != null) && (!debutPlageAncienneIntervention.equals(debutPlage))) {

			// Dupliquer Intervention en AncienneIntervention, avec tous les attributs et DynamicIntervention
			// Intervention ancienneIntervention = createInterventionFille(intervention);
			InterventionDTO ancienneIntervention = new InterventionDTO(serviceManager.getGeneratorManager().generateKey());

			// Duplication de tous les champs de la table Intervention
			// InstanceOG
			ancienneIntervention.setInstanceOg(intervention.getInstanceOg());

			// Pas l'�tat puisque MAJ ensuite
			// Responsabilite
			ancienneIntervention.setResponsabilite(intervention.getResponsabilite());

			// Pas rapportIntervention
			// Pas suit
			// Pas dateEnvoieOT
			// Date prise
			ancienneIntervention.setDatabaseDateDatePrise(intervention.getDatabaseDateDatePrise());

			// D�but plage
			ancienneIntervention.setDatabaseDateDebutPlage(intervention.getDatabaseDateDebutPlage());

			// Fin plage
			ancienneIntervention.setDatabaseDateFinPlage(intervention.getDatabaseDateFinPlage());

			// Dur�e
			ancienneIntervention.setDuree(intervention.getDuree());

			// MESCONTR
			ancienneIntervention.setMescontr(intervention.getMescontr());

			// Observations
			ancienneIntervention.setObservation(intervention.getObservation());

			// REF
			ancienneIntervention.setReference(intervention.getReference());

			// REF EXTERNE
			ancienneIntervention.setRefExterne(intervention.getRefExterne());

			// Duplication de tous les champs de la table DynamicIntervention
			ancienneIntervention.setDynamicInterventions(intervention.getDynamicInterventions());

			// MAJ de l'�tat
			ancienneIntervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.REPORT));

			// MAJ de ces champs dynamic
			Map<String, String> dynamicsIntervention = ancienneIntervention.getDynamicInterventions();
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CODEMODIF, DYNAMIC_INTERVENTION_CODE_MODIF_RESERVATION_AUTRE_DATE);
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ORIGINEDEMANDE, BASICAT_BOLBEC);
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_LIBELLEMODIF, DYNAMIC_INTERVENTION_LIBELLE_MODIF_HISTORISATION_RESERVATION_MANUELLE);
			if (ioReserverPlage.getCritereIntervention().isPerimKyaku()) {
				dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU, interventionReservee.getRefKyaku());
				dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU, ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU_OUI);
			}

			// Sauvegarde du DTO
			serviceManager.getCommandeManager().createIntervention(ancienneIntervention);

			// Maj
			intervention.setSuitIntervention(ancienneIntervention);
		}

		// champ Responsabilite
		if (intervention.getResponsabilite() == null) {
			ResponsabiliteDTO responsabiliteDTO = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ResponsabiliteDTO.class, responsabiliteId);
			intervention.setResponsabilite(responsabiliteDTO);
		}

		// valorisation champs dynamiques, duree, refExterne, etatIntervention,
		// datePrise, debutPlage et finPlage de l'intervention
		modifierIntervention(intervention, ioReserverPlage.getCritereIntervention(), interventionReservee, ioReserverPlage.getPlageRetenue(), agentDTO);

		boolean dateContractuelleModifiee = !ResponsabiliteConstantes.INITIATIVE_FT.equals(intervention.getResponsabilite().getId());
		if (debutPlage != null) {
			updateLignesCommandeDateSouhaiteeAndDateContractuelle(intervention.getId(), debutPlage, dateContractuelleModifiee);

			// Mise � jour des donn�es intervention du workflow
			CommandeDTO commande = serviceManager.getCommandeManager().getCommande(idCommande);
			try {
				impactWorkflow(ioReserverPlage.getPlageRetenue(), intervention.getId(), ioReserverPlage.getCritereIntervention(), agentDTO, commande);
			} catch (WfException e) {
				// On ne bloque pas le traitement, on notifie dans les logs que la maj workflow n'a pas pu �tre effectu�e
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "reserverPlage", "Erreur lors de la mise � jour des donn�es intervention dans le workflow");
			}
		}
		String warning = (evenement != null) ? evenement.getLibelle() : null;

		// -- AJOUT G6R20 : Notifier eRDV d�une nouvelle intervention
		// EV-000066 : Notifier � eRDV uniquement si AncienneIntervention.RefERDV n�est pas vide & AncienneIntervention.Etat <> � REPORT �
		String referenceERDV = intervention.getRefErdv();
		if (referenceERDV != null && !EtatInterventionConstantes.REPORT.equals(intervention.getEtatIntervention().getId())) {
			String numint = intervention.getRefExterne();
			String refint = ioReserverPlage.getRefInt();
			Map<String, String> dynamicsIntervention = intervention.getDynamicInterventions();
			String codeUI = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_UI);
			String activite = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
			String produit = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_PROD);
			String refKyaku = dynamicsIntervention.get(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU);

			// Appel au SF notifier ERDV nouvelle intervention
			SFAno l_anomalieRetournee = InterventionUtil.notifierNouvelleIntervention(ioReserverPlage.getPlageRetenue(), numint, refint, referenceERDV, codeUI, activite, produit, refKyaku, new InfoMessageWebSrv(ioReserverPlage.getIdCommandeTraitee()));

			// Traitement des anomalies retourn�es par le SF
			if (l_anomalieRetournee != null) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "reserverPlage",
						"Traitement de l'anomalie retourn�e par le SF NotifierNouvelleIntervention (" + l_anomalieRetournee.getErreur() + ") : se reporter � l'�v�nement trac� en base.");
				ANOMALIE_MANAGER.traiter(TraitementConstantes.RESERVATIONPLAGE, l_anomalieRetournee);
				// Pas de traitement d'erreur bloquante : le non fonctionnement de l'appel � la notification
				// ne doit pas perturber la r�servation de plage
			}
		}

		warning = appelLancerIntervention(isDateOTRenseigne, intervention, idCommande, warning);

		NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_I, NotificationGeneriqueConstantes.RESERVERINTERV, intervention.getId(), idCommande);
		serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

		return new ReserverPlageResultDTO(warning, dateContractuelleModifiee, intervention.getId(), OK_STRING);
	}

	/**
	 * 		Si l�intervention pr�c�dente a une date d�envoi d�OT renseign�e, on fait appel � la RG1.
	 * 		Dans le cas d�une r�servation faite suite � une lib�ration de rendez-vous, alors que l�OT a d�j� �t� envoy� � GPC,
	 * 		il est n�cessaire de renvoyer un nouvel OT, en appelant le service fonctionnel LancerIntervention.
	 * 		Un bimode sera appliqu� pour distinguer les cas fibre des cas cuivre, � partir de la RT trouv�e sur la commande.
	 *
	 * @param isDateOtRenseigne
	 * @param intervention
	 * @param idCommande
	 * @param warning
	 * @return
	 */
	private String appelLancerIntervention(boolean isDateOtRenseigne, InterventionDTO intervention, String idCommande, String warning) {
		if (isDateOtRenseigne) {
			// Recup�re l'instance RT de type CBL ou CBL_THD de la commande
			InstanceRtDTO instanceRtTrouve = recupererInstanceRTCBLouCBLTHD(idCommande);
			if (instanceRtTrouve != null) {
				CommandeDTO commande = serviceManager.getCommandeManager().getCommande(idCommande);
				Map<String, String> proprietes = new HashMap<String, String>();
				proprietes.put(Constantes.RS_IDCOMMANDE, idCommande);
				proprietes.put(Constantes.RS_DATEVALIDATIONFO, commande.getDatabaseDateDateValidationFo().toString());
				proprietes.put(Constantes.RS_VERSION_BOLBEC, commande.getVersionArtemis());
				proprietes.put(Constantes.RS_REFEXTERNE_COMMANDE, commande.getRefExterne());
				CommandeTraitee commandeTraitee = serviceManager.getCommandeTraiteeManager().traiter(proprietes);
				List<LigneCommandeDTO> ligneCommandeList = serviceManager.getCommandeManager().findLigneCommandeByCommande(idCommande);
				List<TacheEnCoursDTO> tacheList = serviceManager.getProcessusManager().findTacheEnCoursByCommande(idCommande);
				String idTache = CollectionUtils.getFirstOrNull(tacheList).getId();
				TacheDTO tacheDTO = serviceManager.getProcessusManager().getTache(idTache);
				String idProcessus = tacheDTO.getLancerParProcessus().getId();
				InterventionALancer intervALancer = new InterventionALancer(intervention.getId(), intervention.getReference(), intervention.getDynamicInterventions());
				CritereAppel critere = null;
				// Instance RT trouv�: CBL --> cas Cuivre
				if (RessourceTechConstantes.CBL.equals(instanceRtTrouve.getRessourceTech().getId())) {
					String nd = InterventionTraitement.getNdPSouEPC(CollectionUtils.getFirstOrNull(ligneCommandeList));
					List<String> eltsMessage = InterventionTraitement.getElementsMessageCuivre(commande, intervention, ligneCommandeList);
					String blocXML = InterventionTraitement.getBlocXMLCuivre(commande, intervention, ligneCommandeList, join(eltsMessage, ' '), idProcessus);
					critere = new CritereAppel(null, nd, instanceRtTrouve.getIdExterne(), blocXML);
					// Instance RT trouv�: CBL_THD --> cas Fibre
				} else {
					String blocXML = InterventionTraitement.getBlocXMLFibre(commande, intervention, ligneCommandeList, null, idProcessus);
					critere = new CritereAppel(null, instanceRtTrouve.getIdRt(), "", blocXML);
				}

				IOLancerIntervention io = new IOLancerIntervention(intervALancer, critere, serviceManager.getLocalisationManager().getLocalisation(idProcessus),
						serviceManager.getLocalisationManager().getND(idProcessus), commandeTraitee, tacheDTO);
				try {
					//Appeler le service fonctionnel � Lancer Intervention � en lui passant en entr�e les objets pr�c�demment g�n�r�s.
					LancerIntervention.executer(io);
				} catch (Exception e) {
					if (org.apache.commons.lang.StringUtils.isBlank(warning)) {
						warning = "OT non g�n�r�. Veuillez contacter le soutien.";
					} else {
						warning = warning + "\nOT non g�n�r�. Veuillez contacter le soutien.";
					}
					ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "appelLancerIntervention", "Erreur retourn� par le SF LancerIntervention" + e.getMessage());
					return warning;
				}
				// Mettre � jour l��tat d�avancement de l�intervention : Intervention.EtatIntervention = � ENVOI �
				// ainsi que la date d�envoi de l�OT : Intervention.DateEnvoiOT = date courante
				intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.ENVOI));
				intervention.setDatabaseDateDateEnvoiOt(DateUtils.getDatabaseDate());
				serviceManager.getCommandeManager().updateIntervention(intervention);
			}
		}
		return warning;
	}

	/**
	 * Recup�re l'instance RT de type CBL ou CBL_THD de la commande
	 * @param idCommande
	 * @return
	 */
	private InstanceRtDTO recupererInstanceRTCBLouCBLTHD(String idCommande) {
		InstanceRtDTO instanceRtTrouve = null;
		List<ProcessusDTO> processusList = serviceManager.getProcessusManager().findProcessusByCommande(idCommande);
		for (ProcessusDTO processus : processusList) {
			List<InstanceRtDTO> instanceRtDTOList = serviceManager.getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processus.getId());
			for (InstanceRtDTO instanceRtDTO : instanceRtDTOList) {
				if (RessourceTechConstantes.CBL_THD.equals(instanceRtDTO.getRessourceTech().getId()) || RessourceTechConstantes.CBL.equals(instanceRtDTO.getRessourceTech().getId())) {
					return instanceRtDTO;
				}
			}
		}
		return instanceRtTrouve;
	}

	/**
	 * Historiser intervention non reservee.
	 * 
	 * @param intervention the intervention
	 * 
	 * @throws CreateException the create exception
	 * @throws RemoveException the remove exception
	 * 
	 * <B>HISTORIQUE DES MODIFICATIONS:</B>
	 * <TABLE frame='border' ><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/05/2011</TD><TD>CCL</TD><TD>IRMA 980 : Perte des donn�es Observation sur les interventions</TD></TR>
	 * </TABLE>
	 */
	private void historiserInterventionNonReservee(InterventionDTO intervention) throws CreateException, RemoveException {

		// Cette m�thode set les champs suivants:
		// nouvelleIntervention.id
		// nouvelleIntervention.instanceOG
		// nouvelleIntervention.opProgramme
		// DynamicIntervention(nouvelleIntervention) = DynamicIntervention(intervention)
		InterventionDTO nouvelleIntervention = createInterventionFille(intervention);

		// nouvelleIntervention.observations
		if (intervention.getObservation() != null) {
			nouvelleIntervention.setObservation(intervention.getObservation());
			updateInterventionObservation(nouvelleIntervention);
		}
		nouvelleIntervention.setMescontr(intervention.getMescontr());
		nouvelleIntervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.ARESERV));
		nouvelleIntervention.setResponsabilite(new ResponsabiliteDTO(ResponsabiliteConstantes.INITIATIVE_FT));
		serviceManager.getCommandeManager().updateIntervention(nouvelleIntervention);

		// MAJ pr�c�dente intervention
		intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.REPORT));

		// MAJ de ces champs dynamic
		Map<String, String> dynamicsIntervention = intervention.getDynamicInterventions();
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CODEMODIF, DYNAMIC_INTERVENTION_CODE_MODIF_RESERVATION_IMPOSSIBLE);
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ORIGINEDEMANDE, BASICAT_BOLBEC);
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_LIBELLEMODIF, DYNAMIC_INTERVENTION_LIBELLE_MODIF_RESERVATION_IMPOSSIBLE);
		serviceManager.getCommandeManager().updateIntervention(intervention);
		Long debutPlage = intervention.getDatabaseDateDebutPlage();
		if (debutPlage != null) {
			String responsabilitenouvelleIntervention = nouvelleIntervention.getResponsabilite() != null ? nouvelleIntervention.getResponsabilite().getId() : null;
			boolean dateContractuelleModifiee = ResponsabiliteConstantes.INITIATIVE_CLIENT.equals(responsabilitenouvelleIntervention) || ResponsabiliteConstantes.INITIATIVE_OPERATEUR.equals(responsabilitenouvelleIntervention);
			updateLignesCommandeDateSouhaiteeAndDateContractuelle(intervention.getId(), debutPlage, dateContractuelleModifiee);
		}
	}

	/**
	 * Modifier intervention.
	 * 
	 * @param intervention the intervention
	 * @param critereIntervention the critere intervention
	 * @param interventionReservee the intervention reservee
	 * @param plageRetenue the plage retenue
	 * @param agentDTO the agent dto
	 * 
	 * @throws CreateException the create exception
	 * @throws RemoveException the remove exception
	 */
	private void modifierIntervention(InterventionDTO intervention, CritereIntervention critereIntervention, InterventionReservee interventionReservee, Plage plageRetenue, AgentDTO agentDTO) throws CreateException, RemoveException {

		// champs dynamiques Intervention
		Map<String, String> dynamicsIntervention = intervention.getDynamicInterventions();
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ACTIV, critereIntervention.getActiv());
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_CENTRE, critereIntervention.getCentre());
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_PROD, critereIntervention.getProd());
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_SEGMA, critereIntervention.getSegma());
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_ZONE, critereIntervention.getZone());
		dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_UI, plageRetenue.getCodeUi());
		if (critereIntervention.isPerimKyaku()) {
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU, interventionReservee.getRefKyaku());
		} else {
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU, null);
		}

		// RG5 : Valorisation du responsable modification
		String prenom = agentDTO.getPrenom() != null ? agentDTO.getPrenom() : "";
		String nom = agentDTO.getNom() != null ? agentDTO.getNom() : "";
		String resp_modif = prenom + " " + nom;
		if (!StringUtils.isBlank(resp_modif.trim())) {
			dynamicsIntervention.put(ConstantesDynamicIntervention.INTERVENTION_RESP_MODIF, resp_modif);
		}
		intervention.setRefExterne(interventionReservee.getReference());
		// EV000037 - Formatage r�aliser dans l'objet Plage
		intervention.setDuree(plageRetenue.getDuree());
		intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.RESERV));
		intervention.setDatabaseDateDatePrise(DateUtils.getDatabaseDate());
		intervention.setDatabaseDateDebutPlage(DateUtils.getDatabaseDate(plageRetenue.getDebut()));
		intervention.setDatabaseDateFinPlage(DateUtils.getDatabaseDate(plageRetenue.getFin()));
		serviceManager.getCommandeManager().updateIntervention(intervention);
	}

	/**
	 * Impact workflow.
	 * 
	 * @param plage the plage
	 * @param nouvelleInterventionId the nouvelle intervention id
	 * @param critereIntervention the critere intervention
	 * @param agentDTO the agent dto
	 * 
	 * @throws CreateException the create exception
	 * @throws WfException the wf exception
	 * @throws RuntimeException the runtime exception
	 */
	private void impactWorkflow(Plage plage, String nouvelleInterventionId, CritereIntervention critereIntervention, AgentDTO agentDTO, CommandeDTO commande) throws CreateException, WfException, RuntimeException {
		final String method = "impactWorkflow";

		WfServices wfServices = serviceManager.getWfServices();
		WfUser wfUser = wfServices.getWfUser(agentDTO);
		InterventionDTO nouvelleIntervention = getIntervention(nouvelleInterventionId);
		Long debutPlage = DateUtils.getDatabaseDate(plage.getDebut());
		Map<String, String> wfProperties = new HashMap<String, String>();
		// TODO G10: r�viser m�thode pour voir si c'est n�cessaire de l'adapter � Camunda ou on peut le supprimer
		// Apparemment on peut supprimer tous les donn�es de wfProperties (date contractuelle, date rdv, intervention infos)
		wfProperties.put(Constantes.RS_DATE_CONTRACTUELLE, debutPlage.toString());
		// EV-000014: Sauvegarde de la date de RDV dans un champ du BDoc
		wfProperties.put(Constantes.RS_DATE_RDV, "");
		if (nouvelleIntervention.getDebutPlage() != null) {
			wfProperties.put(Constantes.RS_DATE_RDV, "" + (nouvelleIntervention.getDebutPlage().getTime() / 1000L));
		}
		// EV-000029[3]: Sauvegarde d'un nouveau champ dans XPM (MESCONTR)
		wfProperties.put(Constantes.RS_INTERVENTIONS_INFOS,
				nouvelleIntervention.getDebutPlage() + BARRE_VERTICALE_STRING + nouvelleIntervention.getRefExterne() + BARRE_VERTICALE_STRING + critereIntervention.getActiv() + BARRE_VERTICALE_STRING + nouvelleIntervention.getMescontr());

		ProcessusDTO processusEnCours = getProcessusEnCours(nouvelleIntervention);
		ProcessusTypeDTO processusTypeEnCours = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, processusEnCours.getProcessusType().getId());
		String processusTypeEnCoursValCst = processusTypeEnCours.getValeurConstante();
		if (debutPlage != null) {
			String atteint = commande.getDynamicCommandes().get(ConstantesDynamicCommande.CLE_TACHE_RDV_ATTEINTE);
			if (Constantes.CST_OUI_MAJ.equals(atteint)) {
				Map<String, String> proprietesNotificationWorkflow = new HashMap<String, String>();
				proprietesNotificationWorkflow.put(Constantes.RS_DATE_PROGRAMMATION, Long.toString(debutPlage));
				wfProperties.put(Constantes.RS_DATE_PROGRAMMATION, Long.toString(debutPlage));

				// duration du timer d'attente (en fonction de la date de fin de la temporisation)
				String durationAttente = DateAndTimerUtil.calculerTemporisationAvecDelaiFormatISO(debutPlage);

				serviceManager.getLoggerManager().finer(CLASSNAME, method, "Duration avant programmation calcul�e: " + durationAttente);
				proprietesNotificationWorkflow.put(Constantes.RS_TIMER_DURATION, durationAttente);
				wfProperties.put(Constantes.RS_TIMER_DURATION, durationAttente);
				wfUser.doProcessNotificationModifTimer(commande.getId(), proprietesNotificationWorkflow);
			}
		}

		// TODO G10: r�viser m�thode pour voir si c'est n�cessaire de l'adapter � Camunda ou on peut le supprimer (APPAREMMENT ON PEUT LE SUPPRIMER, car on a adapt� l'envoie du timer)
		String traitementCourantName = getTacheEnCoursLibelleCourt(nouvelleIntervention);
		ProcessusDTO papaProcessus = getPapaProcessusEnCours(nouvelleIntervention);
		ProcessusTypeDTO papaProcessusType = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, papaProcessus.getProcessusType().getId());
		if (ProcessusTypeConstantes.LIVRAISONPMC_VALEUR_CONSTANTE.equals(papaProcessusType.getValeurConstante())) {
			if (!ProcessusTypeConstantes.SPGESTRESSCLI_VALEUR_CONSTANTE.equals(processusTypeEnCoursValCst)) {

				// envoyer le message MSG_MC_LIVRAISONPMC
				wfUser.doSetBusinessDataValues(papaProcessus.getBpiid(), null, null, papaProcessus.getBpName(), wfProperties);
			} else if (AVPCONTROLERDV_NOM_TRAITEMENT.equals(traitementCourantName) || AVPCRINTERVCLI_NOM_TRAITEMENT.equals(traitementCourantName) || COMPLETUDECRI_NOM_TRAITEMENT.equals(traitementCourantName)) {

				// envoyer le message MSG_MC_SPGESTRESSCLI
				wfUser.doSetBusinessDataValues(processusEnCours.getBpiid(), null, papaProcessus.getBpName(), processusEnCours.getBpName(), wfProperties);
			} else {
				wfUser.doSetBusinessDataValues(processusEnCours.getBpiid(), MODIF_RDV_ID_ACTIVATION, papaProcessus.getBpName(), processusEnCours.getBpName(), wfProperties);
			}
		} else if (ProcessusTypeConstantes.LIVRAISON_VALEUR_CONSTANTE.equals(papaProcessusType.getValeurConstante())) {
			if (!ProcessusTypeConstantes.SPCONSTRCBL_VALEUR_CONSTANTE.equals(processusTypeEnCoursValCst) && !ProcessusTypeConstantes.SPBILANAFFCFG_VALEUR_CONSTANTE.equals(processusTypeEnCoursValCst)) {
				wfUser.doSetBusinessDataValues(papaProcessus.getBpiid(), null, null, papaProcessus.getBpName(), wfProperties);
			} else if (TCHMANRESINTERVGLOB_NOM_TRAITEMENT.equals(traitementCourantName) || AVPCRINTERVGLOB_NOM_TRAITEMENT.equals(traitementCourantName) || AVPCONTRINTERVGLOB_NOM_TRAITEMENT.equals(traitementCourantName)) {
				wfUser.doSetBusinessDataValues(processusEnCours.getBpiid(), null, papaProcessus.getBpName(), processusEnCours.getBpName(), wfProperties);
			} else if (ProcessusTypeConstantes.SPCONSTRCBL_VALEUR_CONSTANTE.equals(processusTypeEnCoursValCst) || debutPlage != null) {
				wfUser.doSetBusinessDataValues(processusEnCours.getBpiid(), MODIF_RDV_ID_ACTIVATION, papaProcessus.getBpName(), processusEnCours.getBpName(), wfProperties);
			}
		} else if (ProcessusTypeConstantes.COMPLETUDE_VALEUR_CONSTANTE.equals(papaProcessusType.getValeurConstante())) {
			wfUser.doSetBusinessDataValues(papaProcessus.getBpiid(), null, null, papaProcessus.getBpName(), wfProperties);
		}
	}

	/**
	 * Gets the papa processus en cours.
	 * 
	 * @param intervention the intervention
	 * 
	 * @return the papa processus en cours
	 */
	private ProcessusDTO getPapaProcessusEnCours(InterventionDTO intervention) {
		ProcessusDTO papaProcessus = null;
		LigneCommandeDTO firstLigneCde = findFirstLigneCommandeFromFirstOpByIntervention(intervention.getId());
		List<ProcessusDTO> processusLst = serviceManager.getProcessusManager().findProcessusByLigneCommande(firstLigneCde.getId());
		for (ProcessusDTO processus : processusLst) {
			if (EtatProcessusConstantes.EN_COURS.equals(processus.getEtatProcessus().getId())) {
				papaProcessus = processus;
				while (papaProcessus.getGenereParProcessus() != null) {
					papaProcessus = papaProcessus.getGenereParProcessus();
				}
				break;
			}
		}
		if (papaProcessus == null) {
			throw new RuntimeException("Aucun processus en cours!");
		}
		return papaProcessus;
	}

	/**
	 * Gets the processus en cours.
	 * 
	 * @param intervention the intervention
	 * 
	 * @return the processus en cours
	 */
	private ProcessusDTO getProcessusEnCours(InterventionDTO intervention) {
		ProcessusDTO processusEnCours = null;
		LigneCommandeDTO firstLigneCde = findFirstLigneCommandeFromFirstOpByIntervention(intervention.getId());
		List<ProcessusDTO> processusLst = serviceManager.getProcessusManager().findProcessusByLigneCommande(firstLigneCde.getId());
		for (ProcessusDTO processus : processusLst) {
			if (EtatProcessusConstantes.EN_COURS.equals(processus.getEtatProcessus().getId())) {
				if (processusEnCours == null) {
					processusEnCours = processus;
				} else {
					if (processus.getDatabaseDateDateCreation().compareTo(processusEnCours.getDatabaseDateDateCreation()) > 0) {
						processusEnCours = processus;
					}
				}
			}
		}
		return processusEnCours;
	}

	/**
	 * Renvoie le champ LibelleCourt de la tache en cours pour cette intervention
	 * 
	 * @param intervention the intervention
	 * 
	 * @return the tache en cours libelle court
	 */
	private String getTacheEnCoursLibelleCourt(InterventionDTO intervention) {
		LigneCommandeDTO firstLigneCde = findFirstLigneCommandeFromFirstOpByIntervention(intervention.getId());
		List<ProcessusDTO> processusLst = serviceManager.getProcessusManager().findProcessusByLigneCommande(firstLigneCde.getId());
		for (ProcessusDTO processus : processusLst) {
			if (EtatProcessusConstantes.EN_COURS.equals(processus.getEtatProcessus().getId())) {
				List<TacheDTO> taches = serviceManager.getProcessusManager().findTacheByLanceParProcessus(processus.getId());
				for (TacheDTO tache : taches) {
					if (tache.getDatabaseDateDateFinReelle() == null) {
						return tache.getLibelleCourt();
					}
				}
			}
		}
		return null;
	}

	/**
	 * Rechercher centre zone transport.
	 * 
	 * @param ioRechCentreZoneTransport the io rech centre zone transport
	 * 
	 * @return the sF ano
	 */
	private SFAno rechercherCentreZoneTransport(IORechCentreZoneTransport ioRechCentreZoneTransport) {
		try {
			RechCentreZoneTransport.executer(ioRechCentreZoneTransport);
			// S'il existe au moins un avertissement, on retourne le premier de la liste
			return ioRechCentreZoneTransport.getSfAno();
		} catch (AnomalieException l_exc) {
			return l_exc.getSfAno();
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public List<InterventionDTO> findInterventionsByRefErdv(final String referenceErdv) {
		final List<InterventionDTO> listeInterventions = new ArrayList<InterventionDTO>();
		try {
			@SuppressWarnings("unchecked")
			final Collection<Intervention> interventions = interventionHome.findParRefErdv(referenceErdv);
			for (Intervention interv : interventions) {
				listeInterventions.add(new InterventionDTO(interv));
			}
		} catch (FinderException fe) {
			throw new EJBException(fe);
		}
		return listeInterventions;
	}

	/**
	 * {@inheritDoc}
	 */
	public InterventionDTO findInterventionByRefErdvAndDatePrisePlusRecente(final String referenceErdv) {
		final List<InterventionDTO> listeInterventions = findInterventionsByRefErdv(referenceErdv);
		final InterventionDTO interventionPlusRecente = serviceManager.getInterventionManager().recupererInterventionPlusRecente(listeInterventions);
		return interventionPlusRecente;
	}
}
