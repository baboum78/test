package com.soliste.bolbec.livraison.service.ejb.sb.customerorder;

import com.orange.bolbec.customerOrderIOSW.services.CancelDeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.services.InformOnCustomerOrderEventFault;
import com.orange.bolbec.customerOrderIOSW.types.cancelCustomerOrder.CancelDeliverCustomerOrderRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.cancelCustomerOrder.CancelDeliverCustomerOrderResponseMessage;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.DeliverCustomerOrderResponseMessage;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.DeliverCustomerOrderWithLocalisationRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.informCustomerOrder.InformOnCustomerOrderEventRequestMessage;
import com.orange.bolbec.customerOrderIOSW.types.informCustomerOrder.InformOnCustomerOrderEventResponseMessage;

/**
 * Interface metier de l'ejb <code>CustomerOrderManagerSB</code><br/>
 * Permet d'encapsuler le traitement WS dans un EJB et donc d'effecuter un rollback en cas de besoin
 * 
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>31/12/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV-000210 - Offre BVPN&BI FTTH(TRA-12-12) � Cr�ation de la classe </TD></TR>
 * <TR><TD>12/08/2013</TD><TD>AZA</TD><TD>G9R0C1 - Migration CXF</TD></TR>
 * </TABLE>
 * 
 * @author ebaali
 * 
 */
public interface CustomerOrderManager {

	/**
	 * 
	 * traitement cot� livraison d'un appel � deliverCustomerOrder encapsul� dans un EJB
	 * 
	 * @param customerOrderWithLocalisation
	 * @return
	 * @throws RemoteException
	 * @throws DeliverCustomerOrderFaultMessage
	 */
	public DeliverCustomerOrderResponseMessage deliverCustomerOrderWithLocalisation(final DeliverCustomerOrderWithLocalisationRequestMessage customerOrderWithLocalisation) throws DeliverCustomerOrderFault;

	/**
	 * 
	 * traitement cot� livraison d'un appel � informOnCustomerOrderEvent encapsul� dans un EJB
	 * 
	 * @param customerOrder
	 * @return
	 * @throws InformOnCustomerOrderEventFault
	 * @throws RemoteException
	 * @throws InformOnCustomerOrderEventFaultMessage
	 */
	public InformOnCustomerOrderEventResponseMessage informOnCustomerOrderEvent(final InformOnCustomerOrderEventRequestMessage customerOrder) throws InformOnCustomerOrderEventFault;

	/**
	 * 
	 * traitement cot� livraison d'un appel � cancelDeliverCustomerOrder encapsul� dans un EJB
	 * 
	 * @param customerOrder
	 * @return
	 * @throws CancelDeliverCustomerOrderFault
	 * @throws RemoteException
	 * @throws CancelDeliverCustomerOrderFaultMessage
	 */
	public CancelDeliverCustomerOrderResponseMessage cancelDeliverCustomerOrder(final CancelDeliverCustomerOrderRequestMessage customerOrder) throws CancelDeliverCustomerOrderFault;
}
