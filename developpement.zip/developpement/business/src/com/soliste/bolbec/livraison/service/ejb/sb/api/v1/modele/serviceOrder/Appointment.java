package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.soliste.bolbec.livraison.service.ejb.sb.api.adapter.CalendarAdapter;

import java.util.Calendar;

/**
 * Modele Ressource Appointment
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/11/2015</TD><TD>MFA</TD><TD>Initialisation du Appointment</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "appointment")
public class Appointment {

	private String id;
	private String appointmentRef;
	private String erdvId;
	private String externalId;
	private AppointmentStatus state;
	@XmlJavaTypeAdapter(CalendarAdapter.class)
	private Calendar startDate;
	@XmlJavaTypeAdapter(CalendarAdapter.class)
	private Calendar endDate;
	@XmlJavaTypeAdapter(CalendarAdapter.class)
	private Calendar reservationDate;
	@XmlJavaTypeAdapter(CalendarAdapter.class)
	private Calendar sentOTDate;
	private String appointmentObservation;
	private ClosureEventCause closureEventCause;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the appointmentRef
	 */
	public String getAppointmentRef() {
		return appointmentRef;
	}

	/**
	 * @param appointmentRef the appointmentRef to set
	 */
	public void setAppointmentRef(String appointmentRef) {
		this.appointmentRef = appointmentRef;
	}

	/**
	 * @return the erdvId
	 */
	public String getErdvId() {
		return erdvId;
	}

	/**
	 * @param erdvId the erdvId to set
	 */
	public void setErdvId(String erdvId) {
		this.erdvId = erdvId;
	}

	/**
	 * @return the externalId
	 */
	public String getExternalId() {
		return externalId;
	}

	/**
	 * @param externalId the externalId to set
	 */
	public void setExternalId(String externalId) {
		this.externalId = externalId;
	}

	/**
	 * @return the state
	 */
	public AppointmentStatus getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(AppointmentStatus state) {
		this.state = state;
	}

	/**
	 * @return the startDate
	 */
	public Calendar getStartDate() {
		return startDate;
	}

	/**
	 * @param startDate the startDate to set
	 */
	public void setStartDate(Calendar startDate) {
		this.startDate = startDate;
	}

	/**
	 * @return the endDate
	 */
	public Calendar getEndDate() {
		return endDate;
	}

	/**
	 * @param endDate the endDate to set
	 */
	public void setEndDate(Calendar endDate) {
		this.endDate = endDate;
	}

	/**
	 * @return the reservationDate
	 */
	public Calendar getReservationDate() {
		return reservationDate;
	}

	/**
	 * @param reservationDate the reservationDate to set
	 */
	public void setReservationDate(Calendar reservationDate) {
		this.reservationDate = reservationDate;
	}

	/**
	 * @return the sentOTDate
	 */
	public Calendar getSentOTDate() {
		return sentOTDate;
	}

	/**
	 * @param sentOTDate the sentOTDate to set
	 */
	public void setSentOTDate(Calendar sentOTDate) {
		this.sentOTDate = sentOTDate;
	}

	/**
	 * @return the appointmentObservation
	 */
	public String getAppointmentObservation() {
		return appointmentObservation;
	}

	/**
	 * @param appointmentObservation the appointmentObservation to set
	 */
	public void setAppointmentObservation(String appointmentObservation) {
		this.appointmentObservation = appointmentObservation;
	}

	public ClosureEventCause getClosureEventCause() {
		return closureEventCause;
	}

	public void setClosureEventCause(ClosureEventCause closureEventCause) {
		this.closureEventCause = closureEventCause;
	}
}
