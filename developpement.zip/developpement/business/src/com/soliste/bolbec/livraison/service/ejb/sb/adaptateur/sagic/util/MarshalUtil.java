/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.util;

import java.io.StringReader;
import java.io.StringWriter;

import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;

import aps.AnomalieConstantes;
import bolbec.adaptateur.sagic.xml.generated.CommandeSagic;
import bolbec.injection.xml.generated.Message;

import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;

/**
 * The Class MarshalUtil.
 * 
 * /**
 * The Class MarshalUtil.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/02/2012</TD><TD>BPE</TD><TD>DE-000228 : pas de recyclage des IC SAGIC pour erreur catalogue ou structure XML</TD></TR>
 * </TABLE>
 * 
 * @author Phil Bretherton
 */
public class MarshalUtil {

	/**
	 * Instantiates a new marshal util.
	 */
	private MarshalUtil() {
	}

	/**
	 * Marshal.
	 * 
	 * @param message the a_message
	 * 
	 * @return the string
	 */
	public static String marshal(Message message) {
		StringWriter writer = new StringWriter();
		try {
			message.marshal(writer);
		} catch (MarshalException a_ex) {
			throw new ReceptionCdeException("marshal", "Erreur lors du marshal", a_ex);
		} catch (ValidationException a_ex) {
			throw new ReceptionCdeException("marshal", "Erreur lors de la validation", a_ex);
		}
		return writer.toString();
	}

	/**
	 * Unmarshal message body.
	 * 
	 * @param a_message the a_message
	 * 
	 * @return the serializable
	 * 
	 * @throws ReceptionCdeException the reception cde exception
	 */
	public static CommandeSagic unmarshalMessageBody(String a_message) throws ReceptionCdeException {
		try {
			return (CommandeSagic) CommandeSagic.unmarshalCommandeSagic(new StringReader(a_message));
		} catch (ValidationException a_ex) {
			throw getValidationException(a_ex);
		} catch (MarshalException a_ex) {
			if (a_ex.getException() instanceof ValidationException) {
				throw getValidationException((ValidationException) a_ex.getException());
			}
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Une exception s'est produite lors de la de-s�rialisation " + "de l'XML d'une intention de commande sagic.\n" + "L'exception Castor est la suivante : \n"
					+ a_ex.getLocalizedMessage(), a_ex);
		}
	}

	/**
	 * Gets the validation exception.
	 * 
	 * @param a_ex the a_ex
	 * 
	 * @return the validation exception
	 */
	private static ReceptionCdeException getValidationException(ValidationException a_ex) {
		return new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, "Une exception s'est produite lors de la validation " + "de l'XML d'une intention de commande sagic.\n" + "L'exception Castor est la suivante pour le champ "
				+ a_ex.getLocation() + ": \n" + a_ex.getLocalizedMessage(), a_ex);
	}

}
