package com.soliste.bolbec.livraison.service.ejb.sb.api;

/**
 * Classe servant � int�grer tous les param�tres � initialiser � l'aide de leur cl� Artemis notamment
 * voir US-2867
 */
public class DataToSet {

	//US-2867 - Int�gration des cl�s Artemis pour le param�tre data ajout� � Task
	public static final String CODE_IMMEUBLE = "Imb";
	public static final String CODE_BATIMENT = "Bat";
	public static final String CODE_ESCALIER = "Esc";
	public static final String CODE_ETAGE = "Etag";
	public static final String CODE_CPL_VOIE = "CplVoie";
	public static final String CODE_NUM_VOIE = "NumVoie";
	public static final String CODE_RIVOLI = "CodeVoie";
	public static final String CODE_CODE_INSEE = "CodeInsee";
	public static final String CODE_PTO = "IdPTO";
	public static final String CODE_PRISE_EXISTANTE = "PriseExist";
	public static final String CODE_OPE_IMMEUBLE = "OpImb";
	public static final String CODE_CENTRE = "Centre";
	public static final String CODE_REGLETTE ="Reglette";
	public static final String CODE_BROCHE ="Broche";
	public static final String CODE_VC_OPER ="VcOper";
	public static final String CODE_VC_CIBLE ="VcCible";
	public static final String CODE_VOIE ="Voie";
	public static final String CODE_ENSEMBLE ="Ens";
	public static final String CODE_PORTE ="Porte";
	public static final String CODE_LOGO ="Logo";
	public static final String CODE_NDPLP ="NDPLP";
	public static final String CODE_NOM_OLT ="NomOlt";
	public static final String CODE_CHASS_OLT ="ChassOlt";
	public static final String CODE_CARTE_OLT ="CarteOlt";
	public static final String CODE_PORT_OLT ="PortOlt";
	public static final String CODE_VILLE ="Ville";
	public static final String CODE_TYPE_VOIE ="TypVoie";
	public static final String CODE_ACTIVE ="Activ";
	public static final String CODE_PROD ="Prod";

	private String immeuble, batiment, escalier, etage, cplVoie, numVoie, codeRivoli, codeInsee, idPTO, priseExist, opImb, centre, reglette, broche, vcOper, vcCible, voie, ens, porte, logo, ndplp, nomOlt, chassOlt, carteOlt, portOlt, ville, typeVoie, activ, prod;

	public String getImmeuble() {
		return immeuble;
	}

	public void setImmeuble(String immeuble) {
		this.immeuble = immeuble;
	}

	public String getBatiment() {
		return batiment;
	}

	public void setBatiment(String batiment) {
		this.batiment = batiment;
	}

	public String getEscalier() {
		return escalier;
	}

	public void setEscalier(String escalier) {
		this.escalier = escalier;
	}

	public String getEtage() {
		return etage;
	}

	public void setEtage(String etage) {
		this.etage = etage;
	}

	public String getCplVoie() {
		return cplVoie;
	}

	public void setCplVoie(String cplVoie) {
		this.cplVoie = cplVoie;
	}

	public String getNumVoie() {
		return numVoie;
	}

	public void setNumVoie(String numVoie) {
		this.numVoie = numVoie;
	}

	public String getCodeRivoli() {
		return codeRivoli;
	}

	public void setCodeRivoli(String codeRivoli) {
		this.codeRivoli = codeRivoli;
	}

	public String getCodeInsee() {
		return codeInsee;
	}

	public void setCodeInsee(String codeInsee) {
		this.codeInsee = codeInsee;
	}

	public String getIdPTO() {
		return idPTO;
	}

	public void setIdPTO(String idPTO) {
		this.idPTO = idPTO;
	}

	public String getPriseExist() {
		return priseExist;
	}

	public void setPriseExist(String priseExist) {
		this.priseExist = priseExist;
	}

	public String getOpImb() {
		return opImb;
	}

	public void setOpImb(String opImb) {
		this.opImb = opImb;
	}

	public String getCentre() {
		return centre;
	}

	public void setCentre(String centre) {
		this.centre = centre;
	}

	public String getReglette() {
		return reglette;
	}

	public void setReglette(String reglette) {
		this.reglette = reglette;
	}

	public String getBroche() {
		return broche;
	}

	public void setBroche(String broche) {
		this.broche = broche;
	}

	public String getVcOper() {
		return vcOper;
	}

	public void setVcOper(String vcOper) {
		this.vcOper = vcOper;
	}

	public String getVcCible() {
		return vcCible;
	}

	public void setVcCible(String vcCible) {
		this.vcCible = vcCible;
	}

	public String getVoie() {
		return voie;
	}

	public void setVoie(String voie) {
		this.voie = voie;
	}

	public String getEns() {
		return ens;
	}

	public void setEns(String ens) {
		this.ens = ens;
	}

	public String getPorte() {
		return porte;
	}

	public void setPorte(String porte) {
		this.porte = porte;
	}

	public String getLogo() {
		return logo;
	}

	public void setLogo(String logo) {
		this.logo = logo;
	}

	public String getNdplp() {
		return ndplp;
	}

	public void setNdplp(String ndplp) {
		this.ndplp = ndplp;
	}

	public String getNomOlt() {
		return nomOlt;
	}

	public void setNomOlt(String nomOlt) {
		this.nomOlt = nomOlt;
	}

	public String getChassOlt() {
		return chassOlt;
	}

	public void setChassOlt(String chassOlt) {
		this.chassOlt = chassOlt;
	}

	public String getCarteOlt() {
		return carteOlt;
	}

	public void setCarteOlt(String carteOlt) {
		this.carteOlt = carteOlt;
	}

	public String getPortOlt() {
		return portOlt;
	}

	public void setPortOlt(String portOlt) {
		this.portOlt = portOlt;
	}

	public String getVille() {
		return ville;
	}

	public void setVille(String ville) {
		this.ville = ville;
	}

	public String getTypeVoie() {
		return typeVoie;
	}

	public void setTypeVoie(String typeVoie) {
		this.typeVoie = typeVoie;
	}

	public String getActiv() {
		return activ;
	}

	public void setActiv(String activ) {
		this.activ = activ;
	}

	public String getProd() {
		return prod;
	}

	public void setProd(String prod) {
		this.prod = prod;
	}
}
