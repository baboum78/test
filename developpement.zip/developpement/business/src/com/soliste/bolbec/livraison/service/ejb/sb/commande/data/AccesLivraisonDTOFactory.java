/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.commande.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import aps.CauseEvenementConstantes;
import aps.EtatRTConstantes;
import aps.ProcessusTypeConstantes;
import aps.RessourceTechConstantes;
import aps.StatutCommandeConstantes;

import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.data.AccesLivraisonKey;
import com.soliste.bolbec.livraison.service.enumeration.TypeAccesLivraisonEnum;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RessourceTechDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.util.DynamicFieldUtil;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/12/2010</TD><TD>DBA</TD><TD>CAST: Correction switch sans defaut</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>22/07/2011</TD><TD>GPA</TD><TD>IRMA_876: Ajout de date contractuelle sur la page AccessLivraison</TD></TR>
 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000163 BOLBEC-2028 : Modification de l'affichage de l'acc�s de livraison � l'IHM d'bolbec pour les commandes agr�g�es NSD+</TD></TR>
 * <TR><TD>16/10/2013</TD><TD>BPE</TD><TD>G8R2C3 - EV-000250 "Correction mineure"</TD></TR>
 * </TABLE><BR>
 * 
 * Factory pour les AccesLivraisonDTO
 * 
 * @author rgvs7490
 */
public class AccesLivraisonDTOFactory {

	protected IServiceManager serviceManager = ServiceManager.getInstance();
	private static AccesLivraisonDTOFactory instance = new AccesLivraisonDTOFactory();

	/**
	 * Constructeur priv�
	 */
	protected AccesLivraisonDTOFactory() {
		// Nothing to do
	}

	/**
	 * @param lc
	 * @return AccesLivraisonDTO
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border' bgcolor=green>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000163 BOLBEC-2028 : Modification de l'affichage de l'acc�s de livraison � l'IHM d'bolbec pour les commandes agr�g�es NSD+</TD></TR>
	 * </TABLE><BR>
	 */
	public AccesLivraisonDTO create(LigneCommandeDTO lc) {
		AccesLivraisonKey theKey = new AccesLivraisonKey(lc);
		List<LigneCommandeDTO> lignesCommandesAccesLivraison = getLignesCommandesAccesLivraison(lc.getIdCommande(), theKey);
		AccesLivraisonDTO dto = createSansInfos(lc, lignesCommandesAccesLivraison);
		AccesLivraisonDataDTO data = new AccesLivraisonDataDTO();
		int type = theKey.getType().getValue();
		data.setType(type);

		if (type == TypeAccesLivraisonEnum.ND.getValue()) {
			data.setNd(theKey.getReference());
		} else if (type == TypeAccesLivraisonEnum.NDPLP.getValue()) {
			data.setNdplp(theKey.getReference());
		} else if (type == TypeAccesLivraisonEnum.RefNA.getValue()) {
			data.setReferenceEtudeNA(theKey.getReference());
		} else if (type == TypeAccesLivraisonEnum.IDCLI.getValue()) {
			if (lc.getClient().getAdresse() != null) {
				data.setAdresse(lc.getClient().getAdresse());
				String nd = lc.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_SUPPORT);
				if (nd != null) {
					data.setNd(nd);
				}
			}
		}
		// Pas de gestion pour les autres cas
		dto.setAccesLivraisonCourant(data);

		data = construireAccesLivraisonOrigine(lc);
		dto.setAccesLivraisonOrigine(data);
		dto.setReferenceEtudeNA(getReferenceEtudeNA(lc.getId()));

		// RG 7 Valorisation de Broche et R�glette forc�e
		// Rechercher les champs de la table DynamicPSSouhaite (pour tous les PSSouhaite de la
		// commande) dont la cl� est : 'BROCHE_ADSL' ou 'REGLETTE_ADSL'. On affiche la premi�re
		// valeur trouv�e pour chacun de ces deux champs.
		boolean isBrocheAdslTrouvee = false;
		boolean isRegletteAdslTrouvee = false;
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByCommande(lc.getIdCommande());
		for (LigneCommandeDTO ligneCde : lignesCde) {
			PsSouhaiteDTO pss = ServiceManager.getInstance().getCommandeManager().findPsSouhaiteByLigneCommande(ligneCde.getId());
			if (pss != null) {
				Map<String, String> dynamics = pss.getDynamicPsSouhaites();
				String brocheAdsl = dynamics.get(ConstantesDynamicPSSouhaite.PSSOUHAITE_BROCHE_ADSL);
				String regletteAdsl = dynamics.get(ConstantesDynamicPSSouhaite.PSSOUHAITE_REGLETTE_ADSL);
				if (!isBrocheAdslTrouvee && StringUtils.isNotEmpty(brocheAdsl)) {
					dto.setBrocheAdsl(brocheAdsl);
					isBrocheAdslTrouvee = true;
				}
				if (!isRegletteAdslTrouvee && StringUtils.isNotEmpty(regletteAdsl)) {
					dto.setRegletteAdsl(regletteAdsl);
					isRegletteAdslTrouvee = true;
				}
				if (isBrocheAdslTrouvee && isRegletteAdslTrouvee) {
					break;
				}
			}
		}

		return dto;
	}

	/**
	 * Construit l'�l�ment Acc�s Livraison Origine
	 * 
	 * @param lc la ligne de commande
	 * @return L'acc�s livraison origine
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border' bgcolor=green>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000163 BOLBEC-2028 : Modification de l'affichage de l'acc�s de livraison � l'IHM d'bolbec pour les commandes agr�g�es NSD+</TD></TR>
	 * </TABLE><BR>
	 */
	protected AccesLivraisonDataDTO construireAccesLivraisonOrigine(LigneCommandeDTO lc) {
		CommandeManager commandeManager = serviceManager.getCommandeManager();
		AccesLivraisonDataDTO data = new AccesLivraisonDataDTO();
		String commandeId = lc.getIdCommande();
		CommandeDTO commande = commandeManager.getCommande(commandeId);
		boolean livraisonOrigineAffectee = false;
		if (commande != null && StatutCommandeConstantes.AGREGEE.equals(commande.getStatutCommande().getId())) {
			List<LigneCommandeDTO> lignesCommande = commandeManager.findLigneCommandeByCommande(commandeId);
			for (LigneCommandeDTO ligneCommande : lignesCommande) {
				int typeLc = TypeAccesLivraisonEnum.valueOf(ligneCommande.getTypeAccesLivraisonOrigine()).getValue();
				if (TypeAccesLivraisonEnum.NDPLP.getValue() == typeLc) {
					data.setType(TypeAccesLivraisonEnum.NDPLP.getValue());
					data.setNdplp(ligneCommande.getAccesLivraisonOrigine());
					livraisonOrigineAffectee = true;
					break;
				}
			}
		}
		if (!livraisonOrigineAffectee) {
			int type = TypeAccesLivraisonEnum.valueOf(lc.getTypeAccesLivraisonOrigine()).getValue();
			data.setType(type);

			if (type == TypeAccesLivraisonEnum.ND.getValue()) {
				data.setNd(lc.getAccesLivraisonOrigine());
			} else if (type == TypeAccesLivraisonEnum.NDPLP.getValue()) {
				data.setNdplp(lc.getAccesLivraisonOrigine());
			} else if (type == TypeAccesLivraisonEnum.RefNA.getValue()) {
				data.setReferenceEtudeNA(lc.getAccesLivraisonOrigine());
			} else if (type == TypeAccesLivraisonEnum.IDCLI.getValue()) {
				if (lc.getClient().getAdresse() != null) {
					data.setAdresse(lc.getClient().getAdresse());
				}
			}
			// Pas de gestion pour les autres cas
		}
		return data;
	}

	/**
	 * Cette m�thode est publique uniquement pour �tre testable
	 * 
	 * @param lc
	 * @param lignesCommandesAccesLivraison
	 * @return AccesLivraisonDTO
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>22/07/2011</TD><TD>GPA</TD><TD>IRMA_876: Ajout de date contractuelle sur la page AccessLivraison</TD></TR>
	 * </TABLE>
	 */
	private AccesLivraisonDTO createSansInfos(LigneCommandeDTO lc, List<LigneCommandeDTO> lignesCommandesAccesLivraison) {
		AccesLivraisonDTO dto = new AccesLivraisonDTO();
		dto.setId(lc.getId());
		dto.setClientLivre(lc.getClient());
		Map<String, String> dynamicsLigneCommandeAcceptes = DynamicFieldUtil.findAcceptedDynamicFields(lc.getDynamicLigneCommandes(), "ZoneAccesLivraisonContactPrefixe", "ZoneAccesLivraisonContactCle");
		dto.setContacts(dynamicsLigneCommandeAcceptes);

		// --------------------------------------------
		// R�cup�ration des dates en utilisant lc
		// --------------------------------------------

		// Fiche IHM � Ecran � Acc�s Livraison (RG 1)
		Long dateContractuelle = lc.getDatabaseDateDateContractuelle();
		// Fiche IHM � Ecran � Acc�s Livraison (RG 3)
		Long dateSouhaitee = lc.getDatabaseDateDateSouhaitee();
		// Fiche IHM � Ecran � Acc�s Livraison (RG 7)
		Long datePrevisionnelleDesaturation = calculerDatePrevisionnelleDesaturation(lc.getId());

		// --------------------------------------------
		// Mise � jour des dates en utilisant les
		// lignes de commande access livraison
		// --------------------------------------------

		// Mise � jour des dates en utilisant les ligne de commande access livraison
		for (LigneCommandeDTO lcAccesLivraison : lignesCommandesAccesLivraison) {
			// Fiche IHM � Ecran � Acc�s Livraison (RG 1)
			dateContractuelle = choisirPlusPetit(dateContractuelle, lcAccesLivraison.getDatabaseDateDateContractuelle());
			// Fiche IHM � Ecran � Acc�s Livraison (RG 3)
			dateSouhaitee = choisirPlusPetit(dateSouhaitee, lcAccesLivraison.getDatabaseDateDateSouhaitee());
			// Fiche IHM � Ecran � Acc�s Livraison (RG 7)
			datePrevisionnelleDesaturation = choisirPlusGrand(datePrevisionnelleDesaturation, calculerDatePrevisionnelleDesaturation(lcAccesLivraison.getId()));
		}

		// --------------------------------------------
		// Mise � jour du DTO
		// --------------------------------------------

		// Fiche IHM � Ecran � Acc�s Livraison (RG 1)
		dto.setDateContractuelle(DateUtils.getDatabaseDate(dateContractuelle));
		// Fiche IHM � Ecran � Acc�s Livraison (RG 3)
		dto.setDateSouhaitee(DateUtils.getDatabaseDate(dateSouhaitee));
		// Fiche IHM � Ecran � Acc�s Livraison (RG 7)
		dto.setDatePrevisionnelleDesaturation(DateUtils.getDatabaseDate(datePrevisionnelleDesaturation));

		// Retour du DTO
		return dto;
	}

	/**
	 * Fonction permettant de mettre � jour un Long si la nouvelle valeur est plus grande.
	 * 
	 * TODO OLD: D�placer dans le projet outil
	 * 
	 * @param oldValue La valeur � mettre � jour
	 * @param newValue La nouvelle valeur
	 */
	private Long choisirPlusGrand(Long oldValue, Long newValue) {

		// V�rification de l'ancienne valeur
		if (oldValue == null) {

			// ---------------------------------------------
			// L'ancienne valeur n'a jamais �t� initialis�e
			// ---------------------------------------------

			// V�rification de la nouvelle valeur
			if (newValue != null) {

				// ---------------------------------------------
				// La nouvelle valeur est valide (Non null)
				// ---------------------------------------------

				// Initialisation de l'ancienne valeur � partir de la nouvelle
				return newValue;
			}

		} else {

			// ------------------------------------
			// La valeur est d�ja initialis�e
			// ------------------------------------

			// Si la valeur est plus grande
			if (newValue != null && newValue > oldValue) {

				// -----------------------------------------------------
				// La nouvelle valeur est plus grande que l'ancienne
				// --------------------------------------------------

				// Mise � jour de la valeur
				return newValue;
			}
		}

		return oldValue;
	}

	/**
	 * Fonction permettant de mettre � jour un Long si la nouvelle valeur est plus petite.
	 * 
	 * TODO OLD: D�placer dans le projet outil
	 * 
	 * @param oldValue La valeur � mettre � jour
	 * @param newValue La nouvelle valeur
	 */
	private Long choisirPlusPetit(Long oldValue, Long newValue) {

		// V�rification de l'ancienne valeur
		if (oldValue == null) {

			// ---------------------------------------------
			// L'ancienne valeur n'a jamais �t� initialis�e
			// ---------------------------------------------

			// V�rification de la nouvelle valeur
			if (newValue != null) {

				// ---------------------------------------------
				// La nouvelle valeur est valide (Non null)
				// ---------------------------------------------

				// Initialisation de l'ancienne valeur � partir de la nouvelle
				return newValue;
			}

		} else {

			// ------------------------------------
			// La valeur est d�ja initialis�e
			// ------------------------------------

			// Si la valeur est plus grande
			if (newValue != null && newValue < oldValue) {

				// -----------------------------------------------------
				// La nouvelle valeur est plus grande que l'ancienne
				// --------------------------------------------------

				// Mise � jour de la valeur
				return newValue;
			}
		}

		return oldValue;
	}

	/**
	 * Fonction permettant de calculer pour une commande donn�e, la date pr�visionnelle de d�saturation
	 * 
	 * @param ligneCommandeId La ligne de commande de r�f�rence
	 * @return La date pr�visionnelle de d�saturation. Peut �tre null si aucun �v�nement GxRy_AFFECSATURATION n'est<BR>
	 * trouv� pour cette ligne de commande
	 */
	private Long calculerDatePrevisionnelleDesaturation(String ligneCommandeId) {
		// La valeur � calculer
		Long datePrevisionnelleDesaturation = null;
		// R�cup�ration du processusManager
		ProcessusManager processusManager = ServiceManager.getInstance().getProcessusManager();
		// R�cup�ration de la liste des processus pour la ligne de commande
		List<ProcessusDTO> processusList = processusManager.findProcessusByLigneCommande(ligneCommandeId);
		// Recherche des �v�nements GxRy_AFFECSATURATION
		for (ProcessusDTO processus : processusList) {
			List<EvtDTO> evts = processusManager.findEvtByProcAndCause(processus.getId(), CauseEvenementConstantes.AFFECSATURATION);
			// Pour chaque �v�nements trouv�s
			for (EvtDTO evt : evts) {
				// Mise � jour de la date pr�visionnelle de d�saturation si elle est plus grande
				datePrevisionnelleDesaturation = choisirPlusGrand(datePrevisionnelleDesaturation, evt.getDatabaseDateDateFinPrevue());
			}
		}
		// Retour de la plus grande date pr�visionnelle de d�saturation
		return datePrevisionnelleDesaturation;
	}

	private static List<LigneCommandeDTO> getLignesCommandesAccesLivraison(String commandeId, AccesLivraisonKey theKey) {
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByCommande(commandeId);
		List<LigneCommandeDTO> result = new ArrayList<LigneCommandeDTO>();
		for (LigneCommandeDTO lc : lignesCde) {
			AccesLivraisonKey k = new AccesLivraisonKey(lc);
			if (k.equals(theKey)) {
				result.add(lc);
			}
		}
		return result;
	}

	private String getReferenceEtudeNA(String ligneCommandeId) {
		String result = null;
		ProcessusDTO livraisonProcessus = null;
		List<ProcessusDTO> processusLst = ServiceManager.getInstance().getProcessusManager().findProcessusByLigneCommande(ligneCommandeId);
		for (ProcessusDTO processus : processusLst) {
			ProcessusTypeDTO processusType = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, processus.getProcessusType().getId());
			if (ProcessusTypeConstantes.LIVRAISON_VALEUR_CONSTANTE.equals(processusType.getValeurConstante())) {
				livraisonProcessus = processus;
				break;
			}
		}
		if (livraisonProcessus != null) {
			InstanceRtDTO searchedInstanceRT = null;
			List<InstanceRtDTO> instanceRtLst = ServiceManager.getInstance().getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(livraisonProcessus.getId());
			for (InstanceRtDTO irt : instanceRtLst) {
				RessourceTechDTO ressourceTech = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, irt.getRessourceTech().getId());
				if (RessourceTechConstantes.CBL_VALEUR_CONSTANTE.equals(ressourceTech.getValeurConstante()) && irt.getEtatRt() != null && EtatRTConstantes.CS_CF.equals(irt.getEtatRt().getId())) {
					searchedInstanceRT = irt;
					break;
				}
			}
			if (searchedInstanceRT != null) {
				result = searchedInstanceRT.getIdExterne();
			}
		}
		return result;
	}

	public static AccesLivraisonDTOFactory getInstance() {
		return instance;
	}

}