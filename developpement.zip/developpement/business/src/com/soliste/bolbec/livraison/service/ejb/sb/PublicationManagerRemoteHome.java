package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * Interface home de l'EJB session <code>PublicationManager</code>.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/05/2018</TD><TD>AJO</TD><TD>QC974 : VADOR</TD></TR>
 * </TABLE>
 */

public interface PublicationManagerRemoteHome extends EJBHome {

	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public PublicationManagerRemote create() throws CreateException, RemoteException;

}
