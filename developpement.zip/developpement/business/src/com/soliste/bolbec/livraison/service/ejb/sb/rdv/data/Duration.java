/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * Enum�ration mod�lisant une dur�e.
 */
public enum Duration {
	D_0H30("0030", "0030", "Duration.0h30"), D_1H00("0100", "0100", "Duration.1h00"), D_1H30("0130", "0130", "Duration.1h30"), D_2H00("0200", "0200", "Duration.2h00"), D_2H30("0230", "0230", "Duration.2h30"), D_3H00("0300", "0300", "Duration.3h00"), D_3H30(
			"0330", "0330", "Duration.3h30"), D_4H00("0400", "0400", "Duration.4h00"), STANDARD("STANDARD", "", "Duration.standard");

	private String idIhm;
	private String idDb;
	private String key;

	private Duration(String idIhm, String idDb, String key) {
		this.idIhm = idIhm;
		this.idDb = idDb;
		this.key = key;
	}

	/**
	 * Retourne l'identifiant utilis� dans les �l�ments IHM.
	 * 
	 * @return idIhm
	 */
	public String getIdIhm() {
		return idIhm;
	}

	/**
	 * Retourne l'identifiant utilis� dans la base de donn�es.
	 * 
	 * @return idDb
	 */
	public String getIdDb() {
		return idDb;
	}

	/**
	 * Retourne la cl� (dans ApplicationRessource.properties) du libell� pour l'affichage.
	 * 
	 * @return key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param idIhm
	 * @return duration
	 */
	public static Duration getDurationByIdIhm(String idIhm) {
		for (Duration duration : Duration.values()) {
			if (StringUtils.equals(duration.idIhm, idIhm)) {
				return duration;
			}
		}
		// Ne devrait jamais arriver ici !
		return STANDARD;
	}

	/**
	 * @param idDb
	 * @return duration
	 */
	public static Duration getDurationByIdDb(String idDb) {
		for (Duration duration : Duration.values()) {
			if (StringUtils.equals(duration.idDb, idDb)) {
				return duration;
			}
		}
		return STANDARD;
	}
}