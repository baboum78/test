package com.soliste.bolbec.livraison.service;

public class ConstantesEPT {

	public static final int SRV_AFF = 1;
	public static final int SRV_CF = 2;
	public static final int SRV_DCF = 3;
	public static final int SRV_LIB = 4;
	public static final int SRV_MES = 5;
	public static final int SRV_MOD = 6;
	public static final int SRV_MOE = 7;
	public static final int SRV_OBT = 8;
	public static final int SRV_ISR = 9;
}
