package com.soliste.bolbec.livraison.service.ejb.sb.ic;

import com.soliste.bolbec.livraison.service.model.CommandeDTO;

import aps.Processus;
import bolbec.injection.xml.generated.Message;

/**
 * Interface metier de l'ejb <code>CommandeManagerSB</code><br/>
 * Permet de cr�er une commande ou un processus<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * <BR/><TABLE>
 * <TR><TH>DATE</TH><TH>USER</TH><TH>DETAIL</TH></TR>
 * <TR><TD>20/04/2010</TD><TD>ALE</TD><TD>EV-000060 - Construction automatique des dynamicCommande</TD></TR>
 * <TR><TD>26/04/2010</TD><TD>ALE</TD><TD>EV-000060 - Correction du defect_50</TD></TR>
 * <TR><TD>08/10/2013</TD><TD>GPA</TD><TD>G9R0C1 : Test des couches techniques</TD></TR>
 * </TABLE>
 * 
 * @author kyrw0678
 */
public interface InjectionCommandeManager {

	/**
	 * Retourne la commande avec id idCommande
	 *
	 * @param idCommande the message xml
	 *
	 * @return the commande dto
	 */
	CommandeDTO getCommandeById(String idCommande);

	/**
	 * Cr�e une commande en base ainsi que tous ses liens.<br/>
	 * Cette m�thode est excut�e dans une nouvelle transaction :
	 * on doit obligatoirement avoir une trace en base de la commande
	 *
	 * @param messageXml the message xml
	 * @param instanceLocalisation the instance localisation
	 *
	 * @return the commande dto
	 */
	CommandeDTO createCommande(Message messageXml, String instanceLocalisation);

	/**
	 * Cr�e une commande en base avec l'idCommande, refExterne, l'�tat et la date de cr�ation<br/>
	 * Cette m�thode est excut�e dans une nouvelle transaction :
	 * on doit obligatoirement avoir une trace en base de la commande
	 *
	 * @param refExterne la r�f�rence externe
	 *
	 * @return the commande dto
	 */
	CommandeDTO createCommande(String refExterne);

	/**
	 * Mis � jour d'une commande en base. La commande a �t� cr�e seulement aves les donn�es:
	 * 		idCommande, refExterne, �tat et date de cr�ation
	 * Cette m�thode met � jour les autres donn�es de la commande
	 *
	 * @param idCommande l'id de la commande � mettre � jour
	 * @param messageXml le message avec les donn�es
	 * @param instanceLocalisation
	 *
	 * @return the commande dto
	 */
	CommandeDTO updateCommande(String idCommande, Message messageXml, String instanceLocalisation);

	/**
	 * Mis � jour l'�tat d'une commande en base
	 *
	 * @param commandeDTO la commande � mettre � jour
	 *
	 * @return the commande dto
	 */
	void updateCommandeEtat(CommandeDTO commandeDTO);

	/**
	 * Mis � jour l'�tat d'une commande en base avec une nouvelle transaction
	 *
	 * @param commandeDTO la commande � mettre � jour
	 *
	 * @return the commande dto
	 */
	void updateCommandeEtatWithNewTransaction(CommandeDTO commandeDTO);

	/**
	 * Cr�e un processus en base.
	 * 
	 * @param processusType le type de processus � instancier
	 * @return l'instance de processus cr��e
	 * 
	 * <TABLE>
	 * <TR><TH>DATE</TH><TH>USER</TH><TH>DETAIL</TH></TR>
	 * <TR><TD>08/07/2013</TD><TD>GPA</TD><TD>Cr�ation de la m�thode</TD></TR>
	 * </TABLE>
	 */
	public Processus createProcessus(String processusType);

}
