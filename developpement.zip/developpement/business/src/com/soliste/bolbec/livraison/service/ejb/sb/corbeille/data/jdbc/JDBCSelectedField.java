/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField;

/**
 * Impl�mentation pour les infos que doit ramener une requ�te JDBC
 * 
 * @author gdzd8490
 * 
 */
public class JDBCSelectedField implements SelectedField {

	private String selectedField;

	/**
	 * Constructeur
	 * 
	 * @param selectedField
	 */
	public JDBCSelectedField(String selectedField) {
		this.selectedField = selectedField;
	}

	/**
	 * Renvoie le filtre JDBC
	 * 
	 * @return le filtre JDBC
	 */
	public String getSelectedField() {
		return selectedField;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField#getAttributeType()
	 */
	public String getAttributeType() {
		// TODO OLD: ces m�thodes sont utilis�es uniquement par le workflow :
		// supprimer ces m�thodes dans les classes les plus hautes
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField#getAttributeName()
	 */
	public String getAttributeName() {
		// TODO OLD: ces m�thodes sont utilis�es uniquement par le workflow :
		// supprimer ces m�thodes dans les classes les plus hautes
		return null;
	}

}
