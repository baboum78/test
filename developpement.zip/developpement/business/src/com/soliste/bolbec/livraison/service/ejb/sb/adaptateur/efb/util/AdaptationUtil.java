/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.util;

import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.commun.service.constante.SensEvolution;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesParametreDynamique;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.AnomalieDTO;
import com.soliste.bolbec.livraison.service.model.DescGroupeOffresDTO;
import com.soliste.bolbec.livraison.service.model.DescOffreGroupeeDTO;
import com.soliste.bolbec.livraison.service.model.FamilleOffreComDTO;
import com.soliste.bolbec.livraison.service.model.FonctionEfbDTO;
import com.soliste.bolbec.livraison.service.model.GroupeOffresDTO;
import com.soliste.bolbec.livraison.service.model.InputDynamicCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.OffreSeDTO;
import com.soliste.bolbec.livraison.service.model.ParametreDynamiqueDTO;
import com.soliste.bolbec.livraison.service.model.ParametresDTO;
import com.soliste.bolbec.livraison.service.model.TraductionCatComDTO;
import com.soliste.bolbec.livraison.service.model.ValeurParametreDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamic;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationEfb;
import com.soliste.bolbec.livraison.service.stepauto.traitements.metier.eua.GestionMetierKOLIV;
import com.soliste.bolbec.livraison.service.util.IReferenceSpaceManager;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ITraductionManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.AnomalieConstantes;
import aps.CasMetierConstantes;
import aps.DescGroupeOffres;
import aps.DescOffreGroupee;
import aps.EtatInterventionConstantes;
import aps.FonctionEFB;
import aps.MessagesConstantes;
import aps.Offre;
import aps.OffreSE;
import aps.StatutCommandeConstantes;
import aps.SystemeExterneConstantes;
import aps.TypeOpPonctuellesConstantes;
import aps.TypeOpProgrammeeConstantes;
import bolbec.adaptateur.efb.xml.generated.AdresseInstallPSS;
import bolbec.adaptateur.efb.xml.generated.AdressePrincipale;
import bolbec.adaptateur.efb.xml.generated.AliasInstanceOffreGroupee;
import bolbec.adaptateur.efb.xml.generated.ClientDeposantCde;
import bolbec.adaptateur.efb.xml.generated.ClientDetenteur;
import bolbec.adaptateur.efb.xml.generated.Commande;
import bolbec.adaptateur.efb.xml.generated.CommandeEfb;
import bolbec.adaptateur.efb.xml.generated.ContrainteLC;
import bolbec.adaptateur.efb.xml.generated.CritereIdentificationRDV;
import bolbec.adaptateur.efb.xml.generated.CritereIdentificationTiersDeposantCde;
import bolbec.adaptateur.efb.xml.generated.Dates;
import bolbec.adaptateur.efb.xml.generated.EltOrgLivLC;
import bolbec.adaptateur.efb.xml.generated.EltParcCreeLC;
import bolbec.adaptateur.efb.xml.generated.EltParcImpacteLC;
import bolbec.adaptateur.efb.xml.generated.LigneCde;
import bolbec.adaptateur.efb.xml.generated.PartageRessTechniques;
import bolbec.adaptateur.efb.xml.generated.RendezVous;
import bolbec.adaptateur.efb.xml.generated.SpecificiteCommande;
import bolbec.adaptateur.efb.xml.generated.StatutOperationnel;
import bolbec.adaptateur.efb.xml.generated.StructureMetier;
import bolbec.adaptateur.efb.xml.generated.StructureTechnique;
import bolbec.adaptateur.efb.xml.generated.ValeurFonctionEdP;
import bolbec.adaptateur.efb.xml.generated.ValeurFonctionPSS;
import bolbec.injection.xml.generated.Adresse;
import bolbec.injection.xml.generated.ClientContractant;
import bolbec.injection.xml.generated.ClientLivre;
import bolbec.injection.xml.generated.ElementParcAffecte;
import bolbec.injection.xml.generated.InstanceOffreGroupee;
import bolbec.injection.xml.generated.Intervention;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.Message;
import bolbec.injection.xml.generated.OperationProgrammee;
import bolbec.injection.xml.generated.ParametreType;
import bolbec.injection.xml.generated.ProduitServiceSouhaite;

/**
 * Classe permettant de convertir une commande (Message) en provenance d'EFB en commande interne BOLBEC<BR>
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>????????</TD><TD>SICOR LYON</TD><TD>Premi�re version de la classe</TD></TR>
 * <TR><TD>26/11/2009</TD><TD>DBA</TD><TD>EV-000039: Impl�mentation de l'�volution</TD></TR>
 * <TR><TD>08/12/2009</TD><TD>DBA</TD><TD>EV-000039: Retour sur le casMetier (Cas retourNetVersRTC)</TD></TR>
 * <TR><TD>15/12/2009</TD><TD>DBA</TD><TD>EV-000039: R�cup�ration de l'identifiant de la commande et de la LC si erreur offre compatible</TD></TR>
 * <TR><TD>19/04/2010</TD><TD>ALE</TD><TD>EV-000060: Migration H323 Fibre SIP</TD></TR>
 * <TR><TD>24/04/2010</TD><TD>DBA</TD><TD>EV-000060: Correction defect_49</TD></TR>
 * <TR><TD>27/04/2010</TD><TD>DBA</TD><TD>EV-000060: Correction defect_51, probl�me de filtrage de ligne de commande</TD></TR>
 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>Retour arri�re partielle sur le RETOUR_FT</TD></TR>
 * <TR><TD>23/07/2010</TD><TD>YTR</TD><TD>IRMA_905 : Ajout du filtrage des ligne de suppresion porta sip dans la RG20</TD></TR>
 * <TR><TD>06/08/2010</TD><TD>DBA</TD><TD>EV-000053: Nouvelle m�thode valoriserAID</TD></TR>
 * <TR><TD>16/09/2010</TD><TD>GPA</TD><TD>EV-000053: Ajout du champs commandeId dans les logs qualif</TD></TR>
 * <TR><TD>08/12/2010</TD><TD>LBA</TD><TD>Refactoring CAST : passage constante en premier dans assertion equals</TD></TR>
 * <TR><TD>13/12/2010</TD><TD>LBA</TD><TD>Refactoring CAST : r�duction complexit� cyclomatique</TD></TR>
 * <TR><TD>06/01/2011</TD><TD>BPE</TD><TD>EV-000089: Impl�mentation de l'�volution</TD></TR>
 * <TR><TD>26/01/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant sur l'adaptateur EFB</TD></TR>
 * <TR><TD>08/02/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant sur la FQR 154</TD></TR>
 * <TR><TD>18/02/2011</TD><TD>GPE</TD><TD>Correction de l'adaptateur EFB</TD></TR>
 * <TR><TD>10/03/2011</TD><TD>BPE</TD><TD>R�cup�ration de la r�f�rence RDV via la valeurFonctionSimplePSS + Correction defect 171</TD></TR>
 * <TR><TD>21/03/2011</TD><TD>JCH</TD><TD>EV-000077: EDSI et segment de marche KO pour retourFT</TD></TR>
 * <TR><TD>29/03/2011</TD><TD>GPA</TD><TD>Qualif MOE G7R6C1 (Defect 10): Probl�me lors de l'injection d'une commande FTTH agr�g�e si la premi�re ligne de commande est celle contenant l'offre de prestation</TD></TR>
 * <TR><TD>14/04/2011</TD><TD>CCL</TD><TD>BOLBEC-1236 Optimisation de l'utilisation des HashMap</TD></TR>
 * <TR><TD>29/04/2011</TD><TD>BPE</TD><TD>EV-000151: Echec notifierModificationRDV erreur 006</TD></TR>
 * <TR><TD>06/06/2011</TD><TD>GPA</TD><TD>EV-000136: d�tection de la commande Soft/parsifal de migration d�offre OPIM vers OPOM</TD></TR>
 * <TR><TD>09/06/2011</TD><TD>GPA</TD><TD>Correction de l'algorithme de valorisation commande (RG19)</TD></TR>
 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160 - BOLBEC-2009 : KO �ligibilit� Parsifal 42C</TD></TR>
 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 - BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160: Correction Defect 249</TD></TR>
 * <TR><TD>29/09/2011</TD><TD>GPA</TD><TD>Defect_198: Envoi d'un OT 400 au lieu de 4C4 en activation sur la porta FTTH</TD></TR>
 * <TR><TD>28/02/2012</TD><TD>BPE</TD><TD>DE-000187: pas de code compl�ment et libell� sur CR EFB de type NENHD + type NENMIX non g�r�</TD></TR>
 * <TR><TD>08/03/2012</TD><TD>GPA</TD><TD>DE-000155: TypeAccesLivraison renseign� � IDCLI sur commande de suppression ou modification FTTH</TD></TR>
 * <TR><TD>08/03/2012</TD><TD>GPA</TD><TD>EV-000169: Reprise des commandes FTTH en KOLIV</TD></TR>
 * <TR><TD>23/04/2012</TD><TD>BPE</TD><TD>EV-000198: Rejet des commandes EFB dont la dur�e d'intervention est non enti�re (Defect 25)</TD></TR>
 * <TR><TD>10/08/2012</TD><TD>GPA</TD><TD>EV-000204: Commandes EFB ODEBI rejet�es (Defect 183)</TD></TR>
 * <TR><TD>23/08/2012</TD><TD>EBA</TD><TD>EV-000209: Blocage cmde dans Artemis (Affectation Nouvelle BL)</TD></TR>
 * <TR><TD>03/10/2012</TD><TD>GPA</TD><TD>EV-000190: Offre VDSL2</TD></TR>
 * <TR><TD>08/04/2013</TD><TD>GPA</TD><TD>G8R2C2 - EV-000238 : Rejet automatique des commandes EFB non conformes</TD></TR>
 * <TR><TD>21/05/2013</TD><TD>GPA</TD><TD>G8R2C2 - DE-000344 : CR NENHD mal format� sur rejet commande KoLiv FTTH</TD></TR>
 * <TR><TD>23/05/2013</TD><TD>AZA</TD><TD>G8R2C2 - EV-00236-Liberation ND Support pour R�siliations FTTH</TD></TR>
 * <TR><TD>10/07/2013</TD><TD>FTE</TD><TD>G8R2C2 - EV-00236_01-R�siliation FTTH / Lib�ration du ND Support</TD></TR>
 * <TR><TD>16/09/2013</TD><TD>EBA</TD><TD>G8R2C3 - Corrections mineures</TD></TR>
 * <TR><TD>08/11/2013</TD><TD>EBA</TD><TD>G8R2C4 - EV-000269 : Prendre en compte les motifs de commande "Cession" et "Changement de titulaire" </TD></TR>
 * <TR><TD>14/05/2014</TD><TD>VDE</TD><TD>EV-000278 : Mise en quarantaine des ND</TD></TR>
 * <TR><TD>05/06/2014</TD><TD>ASE</TD><TD>EV-000300 : Suite Co Fibre Pro</TD></TR>
 * <TR><TD>19/06/2014</TD><TD>GCL</TD><TD>G8R2C5 - EV-000302 : PLP Fibre </TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000304 : Fluidification ADSL vers Fibre </TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000298 - R�siliation acc�s FTTH en cas de porta sortante </TD></TR>
 * <TR><TD>23/09/2014</TD><TD>ASE</TD><TD>DE - 001126 + EV-000304_01</TD></TR>
 * <TR><TD>30/10/2014</TD><TD>KRA</TD><TD>Correction mineure</TD></TR>
 * <TR><TD>02/01/2015</TD><TD>GCL</TD><TD>EV-000302_04 : PLP Fibre</TD></TR>
 * <TR><TD>06/01/2015</TD><TD>KRA</TD><TD>Mise en en quarantaine</TD></TR>
 * <TR><TD>19/03/2015</TD><TD>GCL</TD><TD>EV-000302_06 : PLP Fibre - Evolution de la d�termination du contexte PLP</TD></TR>
 * <TR><TD>05/05/2015</TD><TD>GCL</TD><TD>DE-600 : Valeur par d�faut du motif de suppression</TD></TR>
 * <TR><TD>06/07/2015</TD><TD>JDE</TD><TD>EV-000328 : Alimentation robot 177 : RTC avec portabilit� r�entrante</TD></TR>
 * <TR><TD>04/08/2015</TD><TD>JDE</TD><TD>EV-000278_12 : Mise en quarantaine</TD></TR>
 * <TR><TD>29/10/2015</TD><TD>MFA</TD><TD>Correction de defect QC-678 [40aine ND appel] Commande Portabilit� non inject�e dans la livraison</TD></TR>
 * <TR><TD>08/12/2015</TD><TD>JDE</TD><TD>EV-000348 : Net commande unique</TD></TR>
 * <TR><TD>11/05/2016</TD><TD>JDE</TD><TD>EV-000348_03 : Net commande unique : Ecrasement cas m�tier</TD></TR>
 * <TR><TD>15/07/2016</TD><TD>JDE</TD><TD>EV-000362 : PLP Fibre sans RDV</TD></TR>
 * <TR><TD>23/08/2016</TD><TD>JDE</TD><TD>QC-000775 : Ajout contr�le fonction NDEDP obligatoire</TD></TR>
 * <TR><TD>20/08/2017</TD><TD>AJO</TD><TD>EV-442 : D�num�rotation</TD></TR>
 * <TR><TD>15/12/2017</TD><TD>SMO</TD><TD>EV-467 : PLP HD</TD></TR>
 * <TR><TD>09/02/2018</TD><TD>SMO</TD><TD>QC-943 : Avancement MESC FT</TD></TR>
 * <TR><TD>24/05/2018</TD><TD>AJO</TD><TD>QC-1010 Avancement MESC FT : commandes regroup�es</TD></TR>
 * <TR><TD>22/02/2019</TD><TD>RMA</TD><TD>US-102 : Gestion de la Porta sortante fibre avec ND IP diff�rent du ND Support _OBL)</TD></TR>
 * <TR><TD>27/03/2019</TD><TD>RRU</TD><TD>US-028 : Sc�nario pr�-config - Param�trage en inputdynamiccommande</TD></TR>
 * <TR><TD>10/05/2019</TD><TD>RRU</TD><TD>US-028 : Sc�nario pr�-config - G�n�ralisation traitement inputdynamiccommande</TD></TR>
 * <TR><TD>30/07/2019</TD><TD>YNO</TD><TD>EV-313 : CLAF - Transmission des donn�es OI et PM dans la commande EFB<TD></TR>
 * 
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.255</TD><TD>EP0024 - Valoriser les champs EDSI et segment de march� dans le cas des commandes de retour FT</TD></TR>
 * <TR><TD>REQ.370</TD><TD>EP0030 - D�tecter le motif de commande Parsifal</TD></TR>
 * <TR><TD>REQ.619</TD><TD>EP0039 - D�tecter la commande Soft/Parsifal de migration OPIM-OPOM</TD></TR>
 * <TR><TD>REQ.1325</TD><TD>EP0065 - Fournir le compl�ment num�ro de voie � 42C</TD></TR>
 * <TR><TD>REQ.4304</TD><TD>EP0108 � Identifier le contexte KO LIV FTTH par un cas m�tier sp�cifique</TD></TR>
 * <TR><TD>REQ.4305</TD><TD>EP0109 - Transformer les lignes de commande de cr�ation en lignes de commande de modification</TD></TR>
 * <TR><TD>REQ.4306</TD><TD>EP0110 - Ne pas effectuer de regroupement de commandes dans le contexte KO LIV FTTH</TD></TR>
 * <TR><TD>REQ.5796</TD><TD>EP0165 � Accepter une commande VDSL avec une r�f�rence externe existante</TD></TR>
 * <TR><TD>REQ.7425</TD><TD>EP0201 - Rep�rer et rejeter les commandes correspondant � des cas non pr�vus dans le SI</TD></TR>
 * <TR><TD>REQ.8364</TD><TD>EP0217 - D�poser des motifs de suppression d�pendants des cas de gestion pour la demande de R�siliation d'acc�s Client</TD></TR>
 * <TR><TD>REQ.10312</TD><TD>Func - EP0250 - Prendre en compte les motifs de commande "Cession" et "Changement de titulaire"</TD></TR>
 * <TR><TD>EP0282</TD><TD>Permettre d'activer ou de d�sactiver le m�canisme de d�num�rotation de l'adaptateur EFB</TD></TR>
 * <TR><TD>EP0272</TD><TD>Identifier le type de ND re�u (g�ographique ou non) dans les LC de maintien du num�ro issues de EFB</TD></TR>
 * <TR><TD>EP0273</TD><TD>D�terminer quel ND devra �tre trait� et dans quel sens dans les LC de maintien du num�ro issues de EFB</TD></TR>
 * <TR><TD>EP0302</TD><TD>Rep�rer et stocker les caract�ristiques des PLP Fibre</TD></TR>
 * <TR><TD>EP315</TD><TD>D�tecter et marquer les commandes r�siliation ADSL avec contexte de migration ADSL vers Fibre</TD></TR>
 * <TR><TD>EP313</TD><TD>Pr�voir des motifs de r�siliations particuliers dans le cadre des commandes de R�siliation FTTH sans motif de D�m�nagement</TD></TR>
 * <TR><TD>EP0333</TD><TD>D�tecter et traiter les commandes avec Ligne Incluse seule</TD></TR>
 * </TABLE>
 * 
 */
public class AdaptationUtil {

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = AdaptationUtil.class.getName();

	/** The Constant CONTACT_COMMANDE_TITRE. */
	private static final String CONTACT_COMMANDE_TITRE = "TitCivilInterloc";

	/** The Constant CONTACT_COMMANDE_NOM. */
	private static final String CONTACT_COMMANDE_NOM = "NomInterlocuteur";

	/** The Constant CONTACT_COMMANDE_PRENOM. */
	private static final String CONTACT_COMMANDE_PRENOM = "PrenomInterlocuteur";

	/** The Constant CONTACT_COMMANDE_EMAIL. */
	private static final String CONTACT_COMMANDE_EMAIL = "Email";

	/** The Constant CONTACT_COMMANDE_PROFESSION. */
	private static final String CONTACT_COMMANDE_PROFESSION = "FonctionInterlocuteur";

	/** The Constant CONTACT_COMMANDE_TELEPHONE. */
	private static final String CONTACT_COMMANDE_TELEPHONE = "Telephone";

	/** The Constant CONTACT_COMMANDE_FAX. */
	private static final String CONTACT_COMMANDE_FAX = "Telecopie";

	/** The Constant NON_MESC. */
	private static final String NON_MESC = "NON";

	/** The Constant OUI. */
	private static final String OUI = "OUI";

	private static final String PI = "PI";
	private static final String RD = "RD";
	private static final String PO = "PO";

	/** The Constant ND_TYPE_ACCES_LIV. */
	private static final String ND_TYPE_ACCES_LIV = "ND";

	private static final String FTTH_TYPE_ACCES_LIV = "FTTH";

	/** The Constant NDPLP_TYPE_ACCES_LIV. */
	private static final String NDPLP_TYPE_ACCES_LIV = "NDPLP";

	/** The Constant IDCLI_TYPE_ACCES_LIV. */
	private static final String IDCLI_TYPE_ACCES_LIV = "IDCLI";

	/** The Constant MIT_TYPE_CRITERE. */
	private static final String MIT_TYPE_CRITERE = "MIT";

	/** The Constant ACTIVITE_GPC_TYPE_CRITERE. */
	protected static final String ACTIVITE_GPC_TYPE_CRITERE = "ActiviteGPC";

	/** The Constant PRODUIT_GPC_TYPE_CRITERE. */
	protected static final String PRODUIT_GPC_TYPE_CRITERE = "ProduitGPC";

	/** The Constant ORIGINE_RDV_VAL_PARAM_INTERV. */
	protected static final String ORIGINE_RDV_VAL_PARAM_INTERV = "45R";

	/** The Constant HD_TYPE_DEBIT_CMD. */
	private static final String HD_TYPE_DEBIT_CMD = "HD";

	/** The Constant BD_TYPE_DEBIT_CMD. */
	private static final String BD_TYPE_DEBIT_CMD = "BD";

	/** The Constant THD_TYPE_DEBIT_CMD. */
	private static final String THD_TYPE_DEBIT_CMD = "THD";

	private static final String PORTA_TYPE_DEBIT_CMD = "PORTA";

	/** The Constant EN_SERVICE_ETAT_LIGNE. */
	private static final String EN_SERVICE_ETAT_LIGNE = "en service";

	/** The Constant PLPA_ETAT_LIGNE. */
	private static final String PLPA_ETAT_LIGNE = "PLPA";

	/** The Constant SYNCHRONISATION_TYPE_CONTRAINTE. */
	private static final String SYNCHRONISATION_TYPE_CONTRAINTE = "Synchronisation";

	/** The Constant HD_VALEUR_CONTRAINTE. */
	private static final String HD_VALEUR_CONTRAINTE = "HD";

	/** The Constant BLANK_STRING. */
	private static final String BLANK_STRING = "";

	/** The Constant SPACE_STRING. */
	private static final String SPACE_STRING = " ";

	private static final String PIPE_SEPARATEUR = "|";

	/** The Constant MIDNIGHT_STRING. */
	private static final String MIDNIGHT_STRING = " 00:00:00";

	/** The Constant SHORT_DATE_FORMAT. */
	private static final String SHORT_DATE_FORMAT = "yyMM";

	/** The Constant STATUT_OP_COMMANDE_REAAC. */
	private static final String STATUT_OP_COMMANDE_REAAC = "REAAC";

	/** The Constant ERDV_VALUE */
	private static final String ERDV_VALUE = "ERDV";

	/**
	 * The Constant ORIGINE_TYPE_CRITERE.
	 * ajout EV-000007 pour la reconaissance des RDV pris par Erdv
	 */
	protected static final String ORIGINE_TYPE_CRITERE = "Origine";

	/** The Constant AUTRE_CDE_BL */
	private static final String AUTRE_CDE_BL = "AutreCdeBL";

	/** The constant any string */
	private static final String STRING_RULE_ANY = "*";

	/** The constant does not start with */
	private static final String STRING_RULE_NOT_START_WITH = "!";

	/**
	 * The Constant ERDV_VAL_CRITERE.
	 * ajout EV-000007 pour la reconaissance des RDV pris par Erdv
	 */
	protected static final String ERDV_VAL_CRITERE = "e-RDV";

	/**
	 * The Constant TIRET_SEPARATEUR.
	 * ajout EV-000007 pour la decomposition de l'identifiant des RDV pris par Erdv
	 */
	private static final String TIRET_SEPARATEUR = "-";

	/** Le service manager permettant d'acc�der � tous les services utils d'bolbec (Traduction, Logger, ReferenceSpace, etc ...) */
	private IServiceManager serviceManager = ServiceManager.getInstance();

	/** The date livre plus tot. */
	private Date dateLivrePlusTot = null;

	/** The date livre plus tot prevue. */
	private Date dateLivrePlusTotPrevue = null;

	/** The date resil plus tot. */
	private Date dateResilPlusTot = null;

	/** Le nd conserve */
	private String ndConserve = null;

	/** Boolean permettant de contr�ler l'ex�cution du calcul du cas m�tier */
	private boolean casMetierOK = false;

	/** Le type de portabilit� trouv� (Uniquement dans le cas PORTA SIP FTTH) */
	private String typePorta = null;

	/** Boolean permettant de d�tecter si le type de portabilit� a d�ja �t� recherch� */
	private boolean typePortaOK = false;

	/** Boolean permettant de d�tecter si l'offreArtemis pour le cas m�tier a d�ja �t� recherch� */
	private boolean typeValoriserOffre = false;

	/** L'offre bolbec (Dans le cas d'une PORTA SIP FTTH) */
	private String offreArtemis = null;

	/** EV-000060: Lors de la lecture des lignes de commande, permet de r�cup�rer les ref lc et de les ranger par statut */
	private Map<String, ArrayList<String>> codeStatutOperation2RefLc = new HashMap<String, ArrayList<String>>();

	/** EV-000089: la r�f�rence de RDV trouv�e (utilis�e pour les commande agr�g�es) */
	private String refRDV = null;

	/** EV-000089: la r�f�rence ligne de commande prest RDV trouv�e (utilis�e pour les commande agr�g�es) */
	private String refLigneCmdPrestRDV = null;

	/** EV-000089: Boolean permettant de d�tecter si la r�f�rence de RDV a d�ja �t� recherch� */
	private boolean refRDVOK = false;

	/** EV-000089: Boolean permettant de d�terminer si la commande trait�e est une commande agr�gr�e ou non */
	private boolean cmdAgregee = false;

	/**
	 * label Fin pour log de fin de methode
	 */
	private String LABEL_FIN_METHODE = "Fin";

	/** EV-000136: */
	protected static final String CODE_ACTION_FORCEE = "CODE_ACTION_FORCEE";
	protected static final String CONVERSION_CODE_ACTION = "CONVERSION_CODE_ACTION";

	/** EV-000160 */
	protected static final String LIGNE_COMMANDE_A_IGNORER = "LC_A_IGNORER";

	/** EV-000278 */
	protected static final String SEPARATEUR = " | ";
	protected static final String FAMILLE_OFFRE_PORTA = "FAMILLE_OFFRE_PORTA";

	/** EV-000277 */
	protected static final String NO_CONTACT_RDV = "NoContactRDV";
	protected static final String VALEUR_QT = "valeurQT";
	protected static final String SECOND_ND = "secondNd";

	/**
	 * Adapt.
	 * 
	 * @param a_paramFonctNotification the a_param fonct notification
	 * @param l_IcEFB the l_ ic efb
	 * 
	 * @return un message
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/06/2011</TD><TD>GPA</TD><TD>EV-000059: Ajout de l'argument a_ICEFB � la m�thode getCommnde()</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * </TABLE>
	 */
	public Message adapt(CommandeEfb l_IcEFB, Map<String, Object> a_paramFonctNotification) throws ReceptionCdeException {
		final String l_method = "adapt";
		serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "D�but" + " de l'adaptateur EFB");

		StructureTechnique l_structureTechnique = l_IcEFB.getStructureTechnique();
		Message l_message = new Message();

		l_message.setIdMessage(l_structureTechnique.getRefMessage());
		l_message.setIdEmetteur(SystemeExterneConstantes.EFB);

		String l_versionModeleLPA = l_structureTechnique.getVersionModeleLPA();
		l_message.setVersion(l_versionModeleLPA);

		String l_dateEmission = l_structureTechnique.getHorodatageMessage();
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "dateEmission  : " + l_dateEmission);
		String l_dateEmissionConvertie = DateUtils.changeFormatDate(l_dateEmission, EFBConstantes.FORMAT_DATE_HEURE_EFB, EFBConstantes.FORMAT_DATE_HEURE);
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "dateConvertie  : " + l_dateEmissionConvertie);
		l_message.setDateEmission(l_dateEmissionConvertie);

		StructureMetier l_structureMetier = l_IcEFB.getStructureMetier();
		Commande l_commandeEFB = l_structureMetier.getCommande();

		// 2.2.4.3	V�rifications sp�cifiques
		verifOffreFonction(l_commandeEFB);

		// EV-000039: Validation de l'IC avec les offres incompatible
		if (!ValidationUtil.validateOffreCompatible(l_IcEFB)) {
			// EV-000039: Lev� d'une anomalie si les offres ne sont pas compatible
			genererAnomalieContenuInjection(a_paramFonctNotification, l_commandeEFB, AnomalieConstantes.CONTENU_ICEFB);
		}

		// 2.2.4.5 Rejet des commandes de modification de portabilit� FTTH sans ND en service
		if ((!ValidationUtil.validateCommandeModifPortaFTTHAvecNDEnService(l_IcEFB))) {
			genererAnomalieContenuInjection(a_paramFonctNotification, l_commandeEFB, AnomalieConstantes.CONTENU_ICEFB);
		}

		try {
			// EV-000089: Valorise le boolean cmdAgregee
			cmdAgregee = isCommandeAgregee(l_commandeEFB);
			bolbec.injection.xml.generated.Commande commandeArtemis = getCommande(l_IcEFB, a_paramFonctNotification);
			l_message.setCommande(commandeArtemis);

			// 2.2.4.3 Rejet des commandes non-NSD+ avec prestations
			// 2.2.4.4 Rejet des commandes NSD+ sans prestations
			if ((!ValidationUtil.validateCommandeNonNsdSansPrestation(l_IcEFB, cmdAgregee)) || (!ValidationUtil.validateCommandeNsdAvecPrestation(l_IcEFB, cmdAgregee, commandeArtemis.getCasMetier()))) {
				genererAnomalieContenuInjection(a_paramFonctNotification, l_commandeEFB, AnomalieConstantes.REJET_AGREGEE);
			}

			// 2.2.4.5 Rejet des commandes PLPA sans date de livraison
			// 2.2.4.6 Rejet des commandes de d�m�nagement sans date de livraison
			// 2.2.4.7 Rejet des commandes de d�m�nagement sans date de livraison ancienne adresse
			if (!ValidationUtil.validateCommandePlpaSansDateLivraison(l_IcEFB) || !ValidationUtil.validateCommandeDemenagementSansDateLivraison(l_IcEFB, cmdAgregee)
					|| !ValidationUtil.validateCommandeDemenagementSansDateLivraisonAncienneAdresse(l_IcEFB, cmdAgregee)) {
				genererAnomalieContenuInjection(a_paramFonctNotification, l_commandeEFB, AnomalieConstantes.CONTENU_ICEFB);
			}

			// On set le statut commande
			String statutCommande = getStatutCommande(l_commandeEFB, l_message.getCommande(), a_paramFonctNotification);
			if (statutCommande != null) {
				l_message.setStatutCommande(statutCommande);
			}
			// Mise a jour des dates de livraison pour toutes les lignes de commande
			if (dateLivrePlusTot == null) {
				dateLivrePlusTot = dateLivrePlusTotPrevue;
			}
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "MAJ dateSouhait�e �  : " + dateLivrePlusTot);
			mettreAJourDateSouhaitee(l_message);
		} catch (ReceptionCdeException a_ex) {
			serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "Traitement de l'exception remont�e");
			traiterException(l_commandeEFB, l_versionModeleLPA, a_paramFonctNotification, a_ex);
		}

		serviceManager.getLoggerManager().finer(CLASSNAME, l_method, LABEL_FIN_METHODE + " de l'adaptateur EFB");
		return l_message;
	}

	/**
	 * Offre de migration XGSPON, et fonction de dur�e d�attente obligatoire
	 *
	 * Si la commande comporte une ligne avec une offre de migration XGSPON,
	 * la ligne de commande doit obligatoirement avoir une fonction sp�cifique.
	 * Si la ligne avec l�offre ne comporte pas cette fonction obligatoire ou si la valeur n�est pas valide,
	 * d�clencher une anomalie � SYNTAXE_ICEFB � et une notification � anomalie format d�injection �
	 *
	 * @param l_commandeEFB
	 */
	private void verifOffreFonction(Commande l_commandeEFB) {
		boolean offrePresent = false;
		boolean foncPresent = false;
		for (LigneCde ligneCde : l_commandeEFB.getLigneCde()) {
			// V�rifier via la table TRADUCTIONCATCOM si la commande comporte une ligne avec une offre de migration XGSPON avec :
			//	Cle = � Offre_MIGXGS �
			//	Valeur = <Code_Offre>
			TraductionCatComDTO traduction = serviceManager.getTraductionManager().getEntityTraductionCatComInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_OFFRE_MIGXGS, ligneCde.getCodeOffrePSS());
			if (traduction != null){
				offrePresent = true;
				// Si une occurrence est trouv�e, la ligne portant l�offre doit obligatoirement avoir une fonction sp�cifique associ�e.
				foncPresent = isFoncPresentEtValeurOK(foncPresent, ligneCde);
			}
		}
		if (offrePresent && !foncPresent) {
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, EFBConstantes.MESSAGE_ANOMALIE_FORMAT_INJECTION);
		}
	}

	/**
	 * 	La valeur associ�e � cette fonction doit-�tre un nombre entier positif (>= 0).
	 * 	Pour cela, v�rifier qu�une occurrence est trouv�e dans la table TRADUCTIONCATCOM, avec :
	 * 	Cle = � DureeAttBranchSN �
	 * 	Valeur = <RefFonctionPSS>
	 *
	 * @param foncPresent
	 * @param ligneCde
	 * @return
	 */
	private boolean isFoncPresentEtValeurOK(boolean foncPresent, LigneCde ligneCde) {
		for (ValeurFonctionPSS valeurFonctionPSS: ligneCde.getValeurFonctionPSS()) {
			TraductionCatComDTO traduction = serviceManager.getTraductionManager().getEntityTraductionCatComInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesDynamicCommande.CLE_NUMERO_DUREE_ATT_BRANCHE_SN, valeurFonctionPSS.getRefFonctionPSS());
			if (traduction != null) {
				foncPresent = true;
				String valeur = valeurFonctionPSS.getValeurFonctionSimplePSS();
				try {
					int valeurInt = Integer.parseInt(valeur);
					if (valeurInt < 0) {
						foncPresent = false;
					}
				} catch (NumberFormatException e) {
					foncPresent = false;
				}
			}
		}
		return foncPresent;
	}

	/**
	 * Appel de la RG_ANO1 pour une anomalie � CONTENU_ICEFB � et une notification � anomalie contenu d�injection �
	 * 
	 * @param a_paramFonctNotification
	 * @param l_commandeEFB
	 * @throws ReceptionCdeException
	 */
	private void genererAnomalieContenuInjection(Map<String, Object> a_paramFonctNotification, Commande l_commandeEFB, String codeAnomalie) throws ReceptionCdeException {
		// R�cup�ration de la liste des lignes de commande
		List<String> refLcList = new ArrayList<String>();
		for (LigneCde lc : l_commandeEFB.getLigneCde()) {
			refLcList.add(lc.getRefLigneCde());
		}
		a_paramFonctNotification.put(DeleguePublicationEfb.CLE_LISTE_REF_LIGNE_CDE, refLcList);
		a_paramFonctNotification.put(DeleguePublicationEfb.CLE_REF_COMMANDE, l_commandeEFB.getRefCommande());
		a_paramFonctNotification.put(DeleguePublicationEfb.CLE_LIGNE_CDE_ERREUR, l_commandeEFB.getLigneCde()[0].getRefLigneCde());

		throw new ReceptionCdeException(codeAnomalie, "anomalie contenu d'injection");
	}

	/**
	 * Valorisation du statutCommande (RG15)
	 * 
	 * @param l_commandeEFB the l_commande efb
	 * @param a_paramFonctNotification the a_param fonct notification
	 * @param commandeArtemis the commande bolbec
	 * @return statutCommande
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/01/2011</TD><TD>BPE</TD><TD>EV-000089: Prise en compte du statut "AGREGEE"</TD></TR>
	 * <TR><TD>06/06/2011</TD><TD>GPA</TD><TD>EV-000136: Prise en compte du statut Mixte_HDMigVoix</TD></TR>
	 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160: KO �ligibilit� Parsifal 42C</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162: NSD Gestion adresses parsifal</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169: Gestion du cas metier "RECR_FTTH"</TD></TR>
	 * </TABLE>
	 */
	protected String getStatutCommande(Commande l_commandeEFB, bolbec.injection.xml.generated.Commande commandeArtemis, Map<String, Object> a_paramFonctNotification) {
		String method = "getStatutCommande";
		String statutCommande = null;
		if (cmdAgregee) {
			return StatutCommandeConstantes.AGREGEE_VALEUR_CONSTANTE;
		}

		int nbligne = l_commandeEFB.getLigneCdeCount();
		boolean contrainteTypeSynchronisation = false;
		String codeStatutOpCommande = null;
		if (l_commandeEFB.getStatutOpCommande() != null) {
			codeStatutOpCommande = l_commandeEFB.getStatutOpCommande().getCodeStatutOpCommande();
		}
		for (int h = 0; h < nbligne; h++) {
			LigneCde ligneCdeEFB = l_commandeEFB.getLigneCde(h);
			ContrainteLC[] contrainteLC = ligneCdeEFB.getContrainteLC();
			boolean statutComandeMixte = false;
			if (contrainteLC != null) {
				for (int i = 0; i < contrainteLC.length; i++) {
					if (SYNCHRONISATION_TYPE_CONTRAINTE.equalsIgnoreCase(contrainteLC[i].getTypeContrainte())) {
						serviceManager.getLoggerManager().finest(CLASSNAME, method, "On a trouv� une contrainte de type " + SYNCHRONISATION_TYPE_CONTRAINTE);
						contrainteTypeSynchronisation = true;
						if (HD_VALEUR_CONTRAINTE.equalsIgnoreCase(contrainteLC[i].getValeurContrainte())) {
							serviceManager.getLoggerManager().finest(CLASSNAME, method, "La commande est une commande Mixte_Maitre");
							a_paramFonctNotification.put(EFBConstantes.SYNCHRO_MIXTE, HD_VALEUR_CONTRAINTE);
							statutCommande = StatutCommandeConstantes.MIXTE_MAITRE;
							statutComandeMixte = true;
							break;
						}
					}
				}
				if (statutComandeMixte) {
					break;
				}
			}
		}

		// On recherche si la commande est de statut Bas_Debit_Solo uniquement si l'on n'a pas trouv� de contrainte de type "Synchronisation"
		if (!contrainteTypeSynchronisation) {
			serviceManager.getLoggerManager().finest(CLASSNAME, method, "Pas de contrainte de type " + SYNCHRONISATION_TYPE_CONTRAINTE + ", on recherche si la commande est de type " + StatutCommandeConstantes.BAS_DEBIT_SOLO);
			for (int h = 0; h < nbligne; h++) {
				LigneCde ligneCdeEFB = l_commandeEFB.getLigneCde(h);

				PartageRessTechniques partageRessTechniques = ligneCdeEFB.getPartageRessTechniques();
				if (partageRessTechniques != null) {
					serviceManager.getLoggerManager().finest(CLASSNAME, method,
							"StatutOpCommande : " + codeStatutOpCommande + ", Etat Ligne : " + partageRessTechniques.getEtatLigne() + ", EtatResReutilisablesId : " + partageRessTechniques.getEtatResReutilisablesId());
				} else {
					serviceManager.getLoggerManager().finest(CLASSNAME, method, "StatutOpCommande : " + codeStatutOpCommande);
				}
				if (STATUT_OP_COMMANDE_REAAC.equals(codeStatutOpCommande) && partageRessTechniques != null && EN_SERVICE_ETAT_LIGNE.equals(partageRessTechniques.getEtatLigne())
						&& StringUtils.isNotEmpty(partageRessTechniques.getEtatResReutilisablesId())) {
					serviceManager.getLoggerManager().finest(CLASSNAME, method, "La commande est une commande Bas_Debit_Solo");
					statutCommande = StatutCommandeConstantes.BAS_DEBIT_SOLO;
					break;
				}
			}
		}
		// Mixte_THD ?
		String casMetier = commandeArtemis.getCasMetier();
		if (statutCommande == null && CasMetierConstantes.CR_FTTH.equals(casMetier)) {
			statutCommande = StatutCommandeConstantes.MIXTE_THD;
		} else {
			if (CasMetierConstantes.MO_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.RECR_FTTH.equals(casMetier)) {
				// FTTH_Lot2
				statutCommande = StatutCommandeConstantes.NON_MIXTE_THD;
				// EV-000136: Migration Voix Entreprise
			} else {
				if (CasMetierConstantes.MIG_VOIXENTR.equals(casMetier)) {
					statutCommande = StatutCommandeConstantes.MIXTE_HDMIGVOIX;
				}
			}
		}
		return statutCommande;
	}

	/**
	 * D�termine si la commande EFB est agr�g�e ou non
	 * 
	 * @param l_commandeEFB la commande efb
	 * @return true si agregee, false sinon
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * </TABLE>
	 */
	protected boolean isCommandeAgregee(Commande l_commandeEFB) {
		for (int i = 0; i < l_commandeEFB.getSpecificiteCommandeCount(); i++) {
			SpecificiteCommande specificiteCommande = l_commandeEFB.getSpecificiteCommande(i);
			if (specificiteCommande != null && AUTRE_CDE_BL.equalsIgnoreCase(specificiteCommande.getTypeCritere())) {
				if (Constantes.CST_N.equals(specificiteCommande.getValCritereEnum())) {
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * Gets the commande.
	 * 
	 * @param a_ICEFB commande re�ue d'EFB
	 * @param paramFonctNotification the a_param fonct notification
	 * 
	 * @return Commande commande g�n�r�e
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/06/2011</TD><TD>GPA</TD><TD>EV-000059: Ajout de l'argument a_ICEFB</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160: Correction Defect 249</TD></TR>
	 * </TABLE>
	 */
	private bolbec.injection.xml.generated.Commande getCommande(CommandeEfb a_ICEFB, Map<String, Object> paramFonctNotification) throws ReceptionCdeException {
		final String l_method = "getCommande";

		// Instance d'une commande au format bolbec
		Commande commandeEFB = a_ICEFB.getStructureMetier().getCommande();
		bolbec.injection.xml.generated.Commande commande = new bolbec.injection.xml.generated.Commande();
		commande.setIdCommande(commandeEFB.getRefCommande());

		// Date d�pot de la commande
		String l_dateDepot = commandeEFB.getDateDepot();
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "l_dateDepot  : " + l_dateDepot);
		commande.setDateDebutPriseCommandeFO(fromDateToDateHeure(l_dateDepot));

		// Date de validation de la commande
		String l_dateValidation = commandeEFB.getDateValidation();
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "l_dateValidation  : " + l_dateValidation);
		commande.setDateValidationCommandeFO(fromDateToDateHeure(l_dateValidation));

		// Identifiant vendeur
		if (commandeEFB.getEltOrgPriseCde() != null) {
			commande.setIdVendeur(commandeEFB.getEltOrgPriseCde().getAgentPriseCde());
		}

		// Contact Commande
		valoriseContactCommande(commandeEFB, commande);

		ClientDetenteur l_clientContractant = null;
		// Boucle sur les lignes de commandes
		Map<String, InstanceOffreGroupee> l_listeOG = new HashMap<String, InstanceOffreGroupee>();

		// Bool�en pour la d�termination du code Z0BPQ et du code OI
		boolean isCodeZ0BPQInit = false;
		boolean isCodeOiInit = false;
		String codeOi = null;
		int nbligne = commandeEFB.getLigneCdeCount();
		for (int i = 0; i < nbligne; i++) {
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "R�cup�ration de la ligne  : " + i);
			LigneCde ligneCdeEFB = commandeEFB.getLigneCde(i);
			String l_idLC = ligneCdeEFB.getRefLigneCde();
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement de la Ligne de Commande EFB " + l_idLC);
			// Controle du code statut LC
			StatutOperationnel l_statutOperationnel = ligneCdeEFB.getStatutOperationnel();
			if (!ValidationUtil.validateStatutOpLC(l_statutOperationnel.getCodeStatutOperation())) {
				paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, l_idLC);
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur EFB - CodeStatutOperation " + l_statutOperationnel.getCodeStatutOperation() + " inconnu");
			}

			// On met ds clientContractant, le client d�tenteur de la premi�re LC
			if (i == 0) {
				l_clientContractant = ligneCdeEFB.getClientDetenteur();
				commande.setClientContractant(getClientContractant(ligneCdeEFB, l_clientContractant));
			}

			String l_codeActionEFB = ligneCdeEFB.getRefOpCommercialeLPA();
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Code action : " + l_codeActionEFB);
			if (!ValidationUtil.validateRefOpCommerciale(l_codeActionEFB)) {
				paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, l_idLC);
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur EFB - Op�ration Commerciale " + l_codeActionEFB + " inconnue");
			}

			String l_codeActionArtemis = recupererRefOpPonctuelle(ligneCdeEFB, a_ICEFB, null, paramFonctNotification);

			String l_offreEFB = ligneCdeEFB.getCodeOffrePSS();
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Code offre : " + l_offreEFB);
			Map<String, List<ValeurParametreDTO>> l_listeOffreArtemis = null;
			try {
				l_listeOffreArtemis = serviceManager.getTraductionManager().getTraductionOffreConcatDiff(l_offreEFB, SystemeExterneConstantes.EFB);
			} catch (AnomalieException a_ex) {
				serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "Traitement de l'exception remont�e : " + a_ex.getMessage());
				// Traiter l'erreur
				paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, l_idLC);
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "ligne de commande en erreur " + l_idLC);
				throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Erreur de traduction pour la cl� " + l_offreEFB + " et le systeme externe EFB");
			}

			if (l_listeOffreArtemis != null) {
				String keyOffre = null;
				List<ValeurParametreDTO> listeValeurParametre = null;
				for (Entry<String, List<ValeurParametreDTO>> entry : l_listeOffreArtemis.entrySet()) {
					keyOffre = entry.getKey();
					serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "R�cup�ration offre avec la cl� : " + keyOffre);
					listeValeurParametre = entry.getValue();

					// Modification de l'offre dans le cas particulier de la PORTA SIP
					traduireOffrePortaSIP(ligneCdeEFB);

					// Valorisation de la r�f�rence de RDV
					getReferenceRDV(ligneCdeEFB);

					valoriserOffreArtemisPourCasMetier(commandeEFB);
					// Appel de la RG14 - Valorisation du cas m�tier en fonction du cas STANDARD ou PORTA SIP (FTTH)
					if (offreArtemis != null) {
						valoriserCasMetierLivraison(commande, offreArtemis, commandeEFB, paramFonctNotification);
					} else {
						valoriserCasMetierLivraison(commande, keyOffre, commandeEFB, paramFonctNotification);
					}

					// ALE - 20100420 - EV-000061 - Migration Fibre H323 vers SIP
					valoriserParametreCommande(commande, commandeEFB);

					// R�cup�ration du code Z0BPQ en �vitant le m�canisme de filtrage (il peut-�tre port� par une ligne potentiellement filtr�e)
					if (!isCodeZ0BPQInit) {
						String valeurCodeZ0BPQ = determinerValeurCodeZ0BPQ(commande.getCasMetier(), commandeEFB);
						isCodeZ0BPQInit = true;
						if (valeurCodeZ0BPQ != null) {
							commande.addParametresCommande(createParametre(ConstantesDynamicCommande.CODE_Z0BPQ, valeurCodeZ0BPQ));
							serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout du param�tre commande : " + ConstantesDynamicCommande.CODE_Z0BPQ + ", valeur : " + valeurCodeZ0BPQ);
						}
					}

					// ALE - 20100430 - EV-000060: filtrage des lignes de commande
					// Test n�cessairement effectu� apr�s la valorisation du cas m�tier
					if (filtrerLigne(commande, ligneCdeEFB)) {
						// Si la ligne est effectivement � filtrer conform�ment � la RG20, on arr�te la boucle de traitement des offres de cette ligne l�,
						// ce qui a pour effet de ne pas la transmettre � Art�mis, comme demand�
						serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "RG20 - ligne filtr�e, refLigneCde=" + ligneCdeEFB.getRefLigneCde());
						break;
					}

					LigneCommandeType ligneCommandeType = getLigneCommande(ligneCdeEFB, a_ICEFB, commande, keyOffre, listeValeurParametre, l_clientContractant, paramFonctNotification);

					// Valorisation de la date d'acceptation de la commande par l'OI
					valorisationDateAcceptationCommandeOI(ligneCdeEFB, ligneCommandeType);

					// R�cup�ration et valorisation du code OI
					if (!isCodeOiInit && isCommandeAgregee(commandeEFB)) {
						codeOi = recuperationCodeOI(commandeEFB, commande.getCasMetier());
						isCodeOiInit = true;
					}
					if (StringUtils.isNotBlank(codeOi)) {
						ligneCommandeType.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE, codeOi));
					}

					if (aps.TypeOpPonctuellesConstantes.CR.equals(l_codeActionArtemis) && (!CasMetierConstantes.RECR_FTTH.equals(commande.getCasMetier()))) {
						// -------------------------
						// Cas CR
						// -------------------------
						String l_refOffreGroupee = getRefOffreGroupe(keyOffre, l_idLC, paramFonctNotification);
						serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ref offre group�e : " + l_refOffreGroupee);

						InstanceOffreGroupee l_instanceOffreGroupee = getInstanceOffreGroupee(l_listeOG, l_refOffreGroupee);

						if (l_instanceOffreGroupee != null) {
							serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout ligne de cde ds offre group�e " + l_instanceOffreGroupee.getRefOffreGroupee() + " pour offre art�mis " + keyOffre);
							l_instanceOffreGroupee.addLigneCommande(ligneCommandeType);
						} else {
							// On n'a pas trouv�e l'instanceOG
							InstanceOffreGroupee l_instanceOG = new InstanceOffreGroupee();
							l_instanceOG.setRefOffreGroupee(l_refOffreGroupee);
							serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Cr�ation offre group�e " + l_refOffreGroupee);
							serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout d'une ligne de commande pour l'offre art�mis " + keyOffre);
							l_instanceOG.addLigneCommande(ligneCommandeType);

							l_listeOG.put(l_refOffreGroupee, l_instanceOG);
							serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "M�morisation offre group�e " + l_refOffreGroupee);

							commande.addInstanceOffreGroupee(l_instanceOG);
							serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Instance Offre group�e rattach�e � la ligne de commande");
						}
						// -------------------------
						// Cas EQUALS
						// -------------------------
					} else if (aps.TypeOpPonctuellesConstantes.EQUALS.equals(l_codeActionArtemis)) {
						// EV-000160 On regarde si on doit ignorer ou non la ligne de commande
						if (!isLigneCommandeEqualsAIgnorer(commande, ligneCdeEFB)) {
							serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout d'une ligne de commande pour l'offre art�mis " + keyOffre);
							commande.addLigneCommande(ligneCommandeType);
						}
					} else {
						// -------------------------
						// Cas MO, SU ou cas metier RECR_FTTH
						// -------------------------
						serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout d'une ligne de commande pour l'offre art�mis " + keyOffre);
						commande.addLigneCommande(ligneCommandeType);
					}
				} // End while offre
			} else {
				// Traiter l'erreur
				paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, l_idLC);
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "ligne de commande en erreur " + l_idLC);
				throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Erreur de traduction pour la cl� " + l_offreEFB + " et le systeme externe EFB");
			}
		} // End for LigneDeCommande

		// EV-000162 - Valorisation du num�ro de Voie
		// Appel de la RG21
		alimenterNumeroVoie(commande);

		// La commande a �t� entierement constitu�e, c'est le moment d'appliquer la RG13
		modifOffrePourCommandeMixte(commandeEFB, commande, paramFonctNotification);

		return commande;
	}

	/**
	 * Valorise contact commande.
	 * 
	 * @param commandeEFB the commande efb
	 * @param commande the commande
	 */
	private void valoriseContactCommande(Commande commandeEFB, bolbec.injection.xml.generated.Commande commande) {
		// Contact commande
		ClientDeposantCde clientDeposantCde = commandeEFB.getClientDeposantCde();
		if (clientDeposantCde != null) {
			CritereIdentificationTiersDeposantCde[] critereIdentificationTiersDeposantCdeTab = clientDeposantCde.getCritereIdentificationTiersDeposantCde();
			Map<String, String> contactCommandeMap = null;
			if (critereIdentificationTiersDeposantCdeTab.length > 0) {
				contactCommandeMap = new HashMap<String, String>();

				for (int i = 0; i < critereIdentificationTiersDeposantCdeTab.length; i++) {
					CritereIdentificationTiersDeposantCde ci = critereIdentificationTiersDeposantCdeTab[i];
					contactCommandeMap.put(ci.getTypeCritere(), ci.getValCritereSimple());
				}

				bolbec.injection.xml.generated.Contact contactCommande = new bolbec.injection.xml.generated.Contact();
				// Titre contact commande
				if (contactCommandeMap.get(CONTACT_COMMANDE_TITRE) != null) {
					contactCommande.setTitre(contactCommandeMap.get(CONTACT_COMMANDE_TITRE));
				}
				// Nom contact commande
				if (contactCommandeMap.get(CONTACT_COMMANDE_NOM) != null) {
					contactCommande.setNom(contactCommandeMap.get(CONTACT_COMMANDE_NOM));
				}
				// Prenom contact commande
				if (contactCommandeMap.get(CONTACT_COMMANDE_PRENOM) != null) {
					contactCommande.setPrenom(contactCommandeMap.get(CONTACT_COMMANDE_PRENOM));
				}
				// Email contact commande
				if (contactCommandeMap.get(CONTACT_COMMANDE_EMAIL) != null) {
					contactCommande.setEmail(contactCommandeMap.get(CONTACT_COMMANDE_EMAIL));
				}
				// Profession contact commande
				if (contactCommandeMap.get(CONTACT_COMMANDE_PROFESSION) != null) {
					contactCommande.setProfession(contactCommandeMap.get(CONTACT_COMMANDE_PROFESSION));
				}
				// Telephone contact commande
				if (contactCommandeMap.get(CONTACT_COMMANDE_TELEPHONE) != null) {
					contactCommande.setTelephone(contactCommandeMap.get(CONTACT_COMMANDE_TELEPHONE));
				}
				// Fax contact commande
				if (contactCommandeMap.get(CONTACT_COMMANDE_FAX) != null) {
					contactCommande.setFax(contactCommandeMap.get(CONTACT_COMMANDE_FAX));
				}

				commande.setContact(contactCommande);
			}
		}
	}

	/**
	 * Gets the ligne commande.
	 * 
	 * @param ligneCdeEFB ligne de commande EFB
	 * @param icEFB commande EFB
	 * @param commande commande bolbec (necessaire pour l'ajout d'intervention)
	 * @param keyOffre Offre
	 * @param listeValeurParametre Liste de ValeurParametre
	 * @param a_clientContractant client contractant
	 * @param a_paramFonctNotification param�tres Fonctionnels pour notification
	 * 
	 * @return LigneCommandeType
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>06/08/2010</TD><TD>DBA</TD><TD>EV-000053: Appel de la m�thode valoriserAID</TD></TR>
	 * <TR><TD>16/09/2010</TD><TD>GPA</TD><TD>EV-000053: Modification de la signature de la m�thode valoriserAID</TD></TR>
	 * <TR><TD>17/01/2011</TD><TD>BPE</TD><TD>EV-000089: Prise en compte du statut "AGREGEE"</TD></TR>
	 * <TR><TD>26/01/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant sur l'adaptateur EFB</TD></TR>
	 * <TR><TD>17/06/2011</TD><TD>GPA</TD><TD>EV-000059: Appel de la m�thode recupererRefOpPonctuelle() + ajout de l'argument a_ICEFB</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * <TR><TD>29/09/2011</TD><TD>GPA</TD><TD>Defect_198: Ajout d'un argument � l'appel de la m�thode setParametresProduitServiceEtEPC()</TD></TR>
	 * </TABLE>
	 */
	protected LigneCommandeType getLigneCommande(LigneCde ligneCdeEFB, CommandeEfb icEFB, bolbec.injection.xml.generated.Commande commande, String keyOffre, List<ValeurParametreDTO> listeValeurParametre, ClientDetenteur a_clientContractant,
			Map<String, Object> a_paramFonctNotification) throws ReceptionCdeException {
		final String l_method = "getLigneCommande";

		Commande a_commandeEFB = icEFB.getStructureMetier().getCommande();
		String l_idLCommande = ligneCdeEFB.getRefLigneCde();
		LigneCommandeType l_ligneCde = new LigneCommandeType();
		l_ligneCde.setIdLigneCommande(l_idLCommande);

		// RG1 : Valorisation des dates
		// Pour la date souhait�, il y a �galement des traitements dans la
		// m�thode mettreAJourDateSouhaitee appel�e dans la m�thode adapt.
		// Pour la date contractuelle, le format de date du champ EFB
		// IC_EFB.DateContractuelleLC est le m�me que le format du champ
		// DateContractuelle, il suffit donc de recopier tel quel.
		l_ligneCde.setDateContractuelle(ligneCdeEFB.getDateContractuelleLC());

		boolean dateSouhaiteeClient = true;
		String l_dateLivraison = getDate(ligneCdeEFB, EFBConstantes.SOUHAITEE_CLIENT);
		if (StringUtils.isBlank(l_dateLivraison)) {
			dateSouhaiteeClient = false;
			l_dateLivraison = getDate(ligneCdeEFB, EFBConstantes.LIVRAISON_PREVUE);
		}

		try {
			Date l_dateLiv = DateUtils.parseDate(l_dateLivraison, EFBConstantes.FORMAT_DATE_HEURE);

			if (dateSouhaiteeClient) {
				if (dateLivrePlusTot == null || l_dateLiv.before(dateLivrePlusTot)) {
					dateLivrePlusTot = l_dateLiv;
					serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "dateLivrePlusTot mis � : " + dateLivrePlusTot);
				}
			} else {
				if (dateLivrePlusTotPrevue == null || l_dateLiv.before(dateLivrePlusTotPrevue)) {
					dateLivrePlusTotPrevue = l_dateLiv;
					serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "dateLivrePlusTot mis � : " + dateLivrePlusTotPrevue);
				}
			}
		} catch (ParseException l_exc) {
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur de format de date : " + l_dateLivraison);
		}

		String l_dateResiliation = getDate(ligneCdeEFB, EFBConstantes.DATE_DESIRE_RESIL_ANCIENNE_BL);
		if (l_dateResiliation != null) {
			try {
				Date l_dateResil = DateUtils.parseDate(l_dateResiliation, EFBConstantes.FORMAT_DATE_HEURE);

				// Si l_dateResil est apr�s la date de resiliation la plus proche, on
				// garde la
				// date de resiliation la plus proche
				if (dateResilPlusTot != null) {
					if (l_dateResil.before(dateResilPlusTot)) {
						dateResilPlusTot = l_dateResil;
					}
				} else {
					dateResilPlusTot = l_dateResil;
				}
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "dateResilPlusTot mis � : " + dateResilPlusTot);
			} catch (ParseException l_exc) {
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur de format de date : " + l_dateResiliation);
			}
		}

		String l_codeActionEFB = ligneCdeEFB.getRefOpCommercialeLPA();
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Code action EFB : " + l_codeActionEFB);
		String codeActionArtemis = recupererRefOpPonctuelle(ligneCdeEFB, icEFB, l_ligneCde, a_paramFonctNotification);
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Type traduit de la Ligne de Commande : " + codeActionArtemis);
		l_ligneCde.setRefOperationPonctuelle(codeActionArtemis);
		l_ligneCde.setClientLivre(getClientLivre(ligneCdeEFB));
		// Appel � la RG25
		keyOffre = traduireOffreElementaires(keyOffre, icEFB, ligneCdeEFB, l_ligneCde);

		// RG 4 : Parametre Livraison Ligne de commande
		String typeDebitCommande = valoriserParametresLivraisonLigneDeCommande(a_commandeEFB, ligneCdeEFB, commande, l_ligneCde, a_paramFonctNotification, keyOffre);

		// Cas d'une commande de cr�ation ou suppression de PORTASIP
		if (PORTA_TYPE_DEBIT_CMD.equals(typeDebitCommande)) {
			// EV-000006 : PortaSip
			// Valorisation du nd conserv�
			valoriserNdConcerve(ligneCdeEFB);
		}

		ElementParcAffecte l_elementParcAffecte = null;
		if (!TypeOpPonctuellesConstantes.CR.equals(l_ligneCde.getRefOperationPonctuelle())) {
			l_elementParcAffecte = getElementParcAffecte(ligneCdeEFB, keyOffre, a_clientContractant, commande, typeDebitCommande, codeActionArtemis);
			l_ligneCde.setElementParcAffecte(l_elementParcAffecte);
		}

		// FTTH_S1D1_Lot2, chef ! - R�cup�ration des PS souhait� dans le cas CR, MO ou DENUM (Mais pas dans le cas EQUALS et SU)
		ProduitServiceSouhaite l_psSouhaite = null;
		if (aps.TypeOpPonctuellesConstantes.CR.equals(codeActionArtemis) || aps.TypeOpPonctuellesConstantes.MO.equals(codeActionArtemis) || aps.TypeOpPonctuellesConstantes.DENUM.equals(codeActionArtemis)) {
			// Appel a la RG5
			l_psSouhaite = getProduitServiceSouhaite(l_ligneCde, ligneCdeEFB, keyOffre, codeActionArtemis, typeDebitCommande);
			l_ligneCde.setProduitServiceSouhaite(l_psSouhaite);
		}

		// AccesLivraison et TypeAccesLivraison (R�gle RG10 dans la sp�cification)
		valorisationAccesLivraison(l_ligneCde, codeActionArtemis, l_codeActionEFB, a_commandeEFB, commande, ligneCdeEFB, a_paramFonctNotification);

		// Valorisation de l'offre par rapport au type de portabilit� SIP FTTH
		traductionOffre(l_ligneCde);

		// Valorisation du contexte PLP
		valorisationContextePLP(ligneCdeEFB, commande);

		// R�cup�ration RIO
		recuperationRIO(ligneCdeEFB, l_ligneCde);

		// Mise � jour des param�tres de PSSouhait� et d'EPCommercial
		setParametresProduitServiceEtEPC(l_ligneCde.getRefOperationPonctuelle(), commande, ligneCdeEFB, l_psSouhaite, l_elementParcAffecte, listeValeurParametre, a_paramFonctNotification, l_ligneCde);

		// EV-302
		valoriserInfoComplementaireSurPSS(l_psSouhaite, ligneCdeEFB, commande);

		// EV-277
		String valeurQT = null;
		String secondNdContact = null;
		// EV-000089 : valorisation du questionnaire technique
		Map<String, String> mapQTetNd = valoriserQuestionnaireTechniqueEtSecondNd(commande, ligneCdeEFB, a_commandeEFB, l_psSouhaite);
		if (mapQTetNd == null) {
			valeurQT = BLANK_STRING;
		} else {
			valeurQT = mapQTetNd.get(VALEUR_QT);
			secondNdContact = mapQTetNd.get(SECOND_ND);
		}
		// Valorise les champs Intervention (dans la commande), Op�ration
		// programm�e et param�tres d'intervention (dans une ligne de
		// commande). (R�gle RG9 dans la sp�cification)
		valoriserOpProgEtIntervention(commande, l_ligneCde, ligneCdeEFB, valeurQT, secondNdContact);

		return l_ligneCde;
	}

	/**
	 * RG4 : valorisation des param�tres livraison ligne de commande
	 * (La r�gle de gestion de d�termination du cas m�tier (RG14) a �t� pr�alablement ex�cut�e)
	 * 
	 * @param commandeEFB
	 * @param ligneCdeEFB
	 * @param commande
	 * @param ligneCde
	 * @param paramFonctNotification
	 * @return le type d�bit commande
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169: Extraction de la RG</TD></TR>
	 * <TR><TD>03/10/2012</TD><TD>GPA</TD><TD>EV-000190: Valorisation du codeStatutOpCommande</TD></TR>
	 * <TR><TD>17/09/2013</TD><TD>BPE</TD><TD>EV-000245: Absence de retour sur Activit� AccesHD_Deco_Nu de EFB (Art�mis, EFB)</TD></TR>
	 * </TABLE>
	 */
	protected String valoriserParametresLivraisonLigneDeCommande(Commande commandeEFB, LigneCde ligneCdeEFB, bolbec.injection.xml.generated.Commande commande, LigneCommandeType ligneCde, Map<String, Object> paramFonctNotification, String keyOffre) {
		String methode = "valoriserParametresLivraisonLigneDeCommande";
		String refOffreGroupeeEFB = ligneCdeEFB.getRefOffreGroupPSS();
		if (refOffreGroupeeEFB != null) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.REF_OFFRE_GROUPEE_EFB, refOffreGroupeeEFB));
		}

		String idLCommande = ligneCdeEFB.getRefLigneCde();
		if (idLCommande != null) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.OSIRIS_ID_LCDE_ORIGINE, idLCommande));
		}

		String refOpCommercialeLPA = ligneCdeEFB.getRefOpCommercialeLPA();
		if (refOpCommercialeLPA != null) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.OSIRIS_OP_PONCT_ORIGINE, refOpCommercialeLPA));
		}

		if (commandeEFB.getEquipeSAVCde() != null && commandeEFB.getEquipeSAVCde().getEntite() != null && commandeEFB.getEquipeSAVCde().getAgence() != null) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.EDSI, commandeEFB.getEquipeSAVCde().getAgence() + commandeEFB.getEquipeSAVCde().getEntite()));
		}

		String typeDebitCommande = getTypeDebitCommande(commandeEFB, commande);
		if (StringUtils.isNotEmpty(typeDebitCommande)) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.TYPE_DEBIT_CMD, typeDebitCommande));
		}

		// EV-000008 - YTR - recuperation du champ motif commande
		String motifCommande = commandeEFB.getMotifCommande();
		if (StringUtils.isNotEmpty(motifCommande)) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.MOTIF_COMMANDE, motifCommande));
		}
		// EV-000008

		// EV-000077
		ParametreType parametreTypeSegma = construireParametreTypeSegma(ligneCdeEFB, false);
		if (parametreTypeSegma != null) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.SEGMA, parametreTypeSegma.getValeur()));
		}

		if (commandeEFB.getStatutOpCommande() != null) {
			String codeStatutOpCommande = commandeEFB.getStatutOpCommande().getCodeStatutOpCommande();
			if (codeStatutOpCommande != null) {
				ligneCde.addParametreLivraison(createParametre(EFBConstantes.CODE_STATUT_OP_COMMANDE, codeStatutOpCommande));
			}
		}

		// EV-000302
		if (ligneCdeEFB.getPartageRessTechniques() != null) {
			String idSISSI = ligneCdeEFB.getPartageRessTechniques().getIdSISSI();
			if (idSISSI != null) {
				if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.ID_SISSI)) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.ID_SISSI, idSISSI));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.ID_SISSI);
				}
			}

			String idSISSIBat = ligneCdeEFB.getPartageRessTechniques().getIdSISSIBat();
			if (idSISSIBat != null) {
				if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.ID_SISSI_BAT)) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.ID_SISSI_BAT, idSISSIBat));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.ID_SISSI_BAT);
				}
			}

			String idSISSIEsc = ligneCdeEFB.getPartageRessTechniques().getIdSISSIEsc();
			if (idSISSIEsc != null) {
				if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.ID_SISSI_ESC)) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.ID_SISSI_ESC, idSISSIEsc));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.ID_SISSI_ESC);
				}
			}

			String batimentOI = ligneCdeEFB.getPartageRessTechniques().getBatimentOI();
			if (StringUtils.isNotBlank(batimentOI)) {
				if (!isClefPresenteDansParamLivraisonCommande(commande, EFBConstantes.BATIMENTOI)) {
					commande.addParametresCommande(createParametre(EFBConstantes.BATIMENTOI, batimentOI));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.BATIMENTOI);
				}
			}

			String escalierOI = ligneCdeEFB.getPartageRessTechniques().getEscalierOI();
			if (StringUtils.isNotBlank(escalierOI)) {
				if (!isClefPresenteDansParamLivraisonCommande(commande, EFBConstantes.ESCALIEROI)) {
					commande.addParametresCommande(createParametre(EFBConstantes.ESCALIEROI, escalierOI));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.ESCALIEROI);
				}
			}

			String etageOI = ligneCdeEFB.getPartageRessTechniques().getEtageOI();
			if (StringUtils.isNotBlank(etageOI)) {
				if (!isClefPresenteDansParamLivraisonCommande(commande, EFBConstantes.ETAGEOI)) {
					commande.addParametresCommande(createParametre(EFBConstantes.ETAGEOI, etageOI));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.ETAGEOI);
				}
			}

			String referencePM = ligneCdeEFB.getPartageRessTechniques().getReferencePM();
			if (StringUtils.isNotBlank(referencePM)) {
				if (!isClefPresenteDansParamLivraisonCommande(commande, EFBConstantes.REFERENCEPM)) {
					commande.addParametresCommande(createParametre(EFBConstantes.REFERENCEPM, referencePM));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.REFERENCEPM);
				}
			}

			String IMB = ligneCdeEFB.getPartageRessTechniques().getIMB();
			if (IMB != null) {
				if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.IMB)) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.IMB, IMB));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.IMB);
				}
			}

			String PLPSansPTOId = ligneCdeEFB.getPartageRessTechniques().getPLPSansPTOId();
			if (PLPSansPTOId != null) {
				if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.PLP_SANS_PT_OID)) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.PLP_SANS_PT_OID, PLPSansPTOId));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.PLP_SANS_PT_OID);
				}
			}

			if (ligneCdeEFB.getPartageRessTechniques() != null) {
				String EtatLigne = ligneCdeEFB.getPartageRessTechniques().getEtatLigne();
				if (EtatLigne != null) {
					if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.ETAT_LIGNE)) {
						ligneCde.addParametreLivraison(createParametre(EFBConstantes.ETAT_LIGNE, EtatLigne));
						serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.ETAT_LIGNE);
					}
				}
			}

			String ResReutilisablesId = ligneCdeEFB.getPartageRessTechniques().getResReutilisablesId();
			if (ResReutilisablesId != null) {
				if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.RES_REUTILISABLES_ID)) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.RES_REUTILISABLES_ID, ResReutilisablesId));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.RES_REUTILISABLES_ID);
				}
			}

			String EtatResReutilisablesId = ligneCdeEFB.getPartageRessTechniques().getEtatResReutilisablesId();
			if (EtatResReutilisablesId != null) {
				if (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.ETAT_RES_REUTILISABLES_ID)) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.ETAT_RES_REUTILISABLES_ID, EtatResReutilisablesId));
					serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.ETAT_RES_REUTILISABLES_ID);
				}
			}
		}

		// 2.34	RG31 : R�cup�ration Valeur du d�bit de repli
		recuperationValeurDebitRepli(ligneCdeEFB, ligneCde);

		// Marquage des contraintes
		ContrainteLC[] contrainteLC = ligneCdeEFB.getContrainteLC();
		if (contrainteLC != null) {
			for (int i = 0; i < contrainteLC.length; i++) {
				if (SYNCHRONISATION_TYPE_CONTRAINTE.equalsIgnoreCase(contrainteLC[i].getTypeContrainte()) && HD_VALEUR_CONTRAINTE.equalsIgnoreCase(contrainteLC[i].getValeurContrainte())) {
					ligneCde.addParametreLivraison(createParametre(EFBConstantes.SYNCHRO_MIXTE, HD_VALEUR_CONTRAINTE));
					break;
				}
			}
		}

		// EV-000053: Valorisation du parametre de livraison AID (R�f�rence Alias Offre Groupee)
		boolean valorisationAID = valoriserAID(ligneCdeEFB, ligneCde, commandeEFB.getRefCommande());

		// Dans le cas d�une commande � Reprise de cr�ation d�acc�s FTTH � (cas m�tier � RECR_FTTH �), le champ AID est obligatoire pour traiter la commande dans
		// la suite du processus de livraison, sinon celle-ci doit �tre rejet�e.
		if (CasMetierConstantes.RECR_FTTH.equals(commande.getCasMetier()) && (!valorisationAID)) {
			// La commande doit �tre rejet�e de mani�re d�finitive
			// Appel RG_ANO1
			paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, idLCommande);
			throw new ReceptionCdeException(AnomalieConstantes.CONTENU_ICEFB, "Dans le cas d�une commande � Reprise de cr�ation d�acc�s FTTH �, le champ AID est obligatoire");
		}

		if (CasMetierConstantes.RECR_FTTH.equals(commande.getCasMetier())) {
			// Dans le cas particulier des commande KOLIV (IC_EFB.MotifCommande= � KOLIV �) et que le cas m�tier identifi� est � RECR_FTTH �, il sera n�cessaire de forcer des type OP ponctuelles de chaque ligne de commande de � CR � � � MO �
			ligneCde.setRefOperationPonctuelle(TypeOpPonctuellesConstantes.MO);
		}

		final OffreDTO offre = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, keyOffre);
		String valArtemis = offre.getValeurConstante() + PIPE_SEPARATEUR + commandeEFB.getStatutOpCommande().getCodeStatutOpCommande();
		final String traduction = serviceManager.getTraductionManager().getTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.STATUT_RSEACTNU, valArtemis);
		if (ConstantesTraduction.OUI.equals(traduction)) {
			ligneCde.addParametreLivraison(createParametre(ConstantesTraduction.STATUT_RSEACTNU, ConstantesTraduction.OUI));
		}

		return typeDebitCommande;
	}

	/**
	 * Si, sur une LC de la commande EFB, celle-ci porte l�offre correspondant au param�tre � Offre_MIGXGS �,
	 * alors on ajoute la valeur du d�bit de repli.
	 *
	 * @param ligneCdeEFB
	 * @param ligneCde
	 */
	private void recuperationValeurDebitRepli(LigneCde ligneCdeEFB, LigneCommandeType ligneCde) {
		String methode = "recuperationValeurDebitRepli";
		TraductionCatComDTO traductionOffre = serviceManager.getTraductionManager().getEntityTraductionCatComInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_OFFRE_MIGXGS, ligneCdeEFB.getCodeOffrePSS());
		String debitRepli = null;
		if (traductionOffre != null) {
			for (ValeurFonctionPSS valeurFonctionPSS: ligneCdeEFB.getValeurFonctionPSS()) {
				TraductionCatComDTO traductionFonction = serviceManager.getTraductionManager().getEntityTraductionCatCom(ConstantesDynamicCommande.CLE_DEBIT, ConstantesTraduction.TRADUCTION_VAL_ARTE_REF_FONCTION_PSS, valeurFonctionPSS.getRefFonctionPSS());
				if (traductionFonction != null) {
					debitRepli = valeurFonctionPSS.getValeurFonctionPSS();
				}
			}
		}
		if (StringUtils.isNotBlank(debitRepli) && (!isClePresenteDansParamLivraison(ligneCde, EFBConstantes.VF_DEBIT_REPLI))) {
			ligneCde.addParametreLivraison(createParametre(EFBConstantes.VF_DEBIT_REPLI, debitRepli));
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre livraison " + EFBConstantes.VF_DEBIT_REPLI);
		}
	}

	/**
	 * RG2 : r�cup�ration de la r�f�rence Op�ration Ponctuelle
	 * 
	 * @param ligneCdeEFB la ligne de commande EFB courante
	 * @param icEFB l'IC EFB
	 * @param ligneCommande la ligne de commande Artemis courante (si null => pas de marquage de la ligne)
	 * @param paramFonctNotification les param�tres de notification
	 * @return la valeur de la r�f�rence Op�ration Ponctuelle
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/06/2011</TD><TD>GPA</TD><TD>EV-000059: Cr�ation de la m�thode</TD></TR>
	 * </TABLE>
	 */
	protected String recupererRefOpPonctuelle(LigneCde ligneCdeEFB, CommandeEfb icEFB, LigneCommandeType ligneCommande, Map<String, Object> paramFonctNotification) throws ReceptionCdeException {
		String methode = "recupererRefOpPonctuelle";

		StringBuilder valeurExterne = new StringBuilder(icEFB.getStructureTechnique().getTypeEvenement());
		valeurExterne.append(PIPE_SEPARATEUR);
		valeurExterne.append(ligneCdeEFB.getCodeOffrePSS());
		valeurExterne.append(PIPE_SEPARATEUR);
		valeurExterne.append(ligneCdeEFB.getRefOpCommercialeLPA());

		String refOpPonctuelle = "";
		for (ValeurFonctionPSS valFctPss : ligneCdeEFB.getValeurFonctionPSS()) {
			StringBuilder valeurIdValeurFonction = new StringBuilder(valeurExterne);
			valeurIdValeurFonction.append(PIPE_SEPARATEUR);
			valeurIdValeurFonction.append(valFctPss.getRefFonctionPSS());
			valeurIdValeurFonction.append(PIPE_SEPARATEUR);
			valeurIdValeurFonction.append(valFctPss.getValeurFonctionPSS());

			String valeurArtemis = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, CODE_ACTION_FORCEE, valeurIdValeurFonction.toString());
			if (StringUtils.isNotBlank(valeurArtemis)) {
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "ReferenceOperationPonctuelle r�cup�rer via la table TraductionCatCom : '" + refOpPonctuelle + "' et la valeurIdValeurFonction");
				refOpPonctuelle = valeurArtemis;

				// Marquer la ligne de commande pour la phase d'activation
				if (ligneCommande != null) {
					ligneCommande.addParametreLivraison(createParametre(CONVERSION_CODE_ACTION, Constantes.CST_OUI));
					ligneCommande.addParametreLivraison(createParametre(EFBConstantes.CODE_ACTION_ORIGINE, ligneCdeEFB.getRefOpCommercialeLPA()));
				}

				break;
			}
		}

		if (StringUtils.isBlank(refOpPonctuelle)) {
			String valeurArtemis = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, CODE_ACTION_FORCEE, valeurExterne.toString());

			if (StringUtils.isNotBlank(valeurArtemis)) {
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "ReferenceOperationPonctuelle r�cup�rer via la table TraductionCatCom : '" + refOpPonctuelle + "'");
				refOpPonctuelle = valeurArtemis;

				// Marquer la ligne de commande pour la phase d�activation
				if (ligneCommande != null) {
					ligneCommande.addParametreLivraison(createParametre(CONVERSION_CODE_ACTION, Constantes.CST_OUI));
					ligneCommande.addParametreLivraison(createParametre(EFBConstantes.CODE_ACTION_ORIGINE, ligneCdeEFB.getRefOpCommercialeLPA()));
				}
			} else {
				// Si le forcage n�a pas donn� de r�sultat
				refOpPonctuelle = translate(EFBConstantes.KEY_CODE_ACTION, ligneCdeEFB.getRefOpCommercialeLPA(), ligneCdeEFB.getRefLigneCde(), paramFonctNotification);
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "ReferenceOperationPonctuelle r�cup�rer via la table Traduction : '" + refOpPonctuelle + "'");
			}
		}
		return refOpPonctuelle;
	}

	/**
	 * V�rifie si la ligne de commande est � ignorer, � savoir, si l'offre est TV_ADSL et le typeOPPonctuelle est EQUALS.
	 * 
	 * @param commande la commande au format Artemis
	 * @param lcEFB la ligne de commande courante au format EFB
	 * @return <code>true</code> si la ligne de commande est � ignorer, <code>false</code> sinon.
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160: Cr�ation de la m�thode</TD></TR>
	 */
	protected boolean isLigneCommandeEqualsAIgnorer(bolbec.injection.xml.generated.Commande commande, LigneCde lcEFB) {
		String cle = "LCTVEQUALS_A_IGNORER";
		String valeurArtemis = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, cle, lcEFB.getCodeOffrePSS());
		if (valeurArtemis != null) {
			commande.addParametresCommande(createParametre(valeurArtemis, Constantes.CST_OUI));
			return true;
		}
		return false;
	}

	/**
	 * Gets the date.
	 * 
	 * @param a_ligneCdeEFB ligne de Cde EFB,
	 * @param a_typeDate Type de date
	 * 
	 * @return String Valeur de la date
	 */
	public static String getDate(LigneCde a_ligneCdeEFB, String a_typeDate) {
		String l_valeur = null;
		int l_nbDate = a_ligneCdeEFB.getDatesCount();
		for (int i = 0; i < l_nbDate; i++) {
			Dates l_date = a_ligneCdeEFB.getDates(i);
			String l_typeDateTrouve = l_date.getTypeDate();
			if (a_typeDate.equals(l_typeDateTrouve)) {
				String l_valeurDate = l_date.getValeurDate();
				String l_valeurHeure = l_date.getHeureRea();
				if (l_valeurHeure == null) {
					l_valeur = fromDateToDateHeure(l_valeurDate);
				} else {
					l_valeur = l_valeurDate + SPACE_STRING + l_valeurHeure;

				}
				return l_valeur;
			}
		}
		return l_valeur;
	}

	/**
	 * From date to date heure.
	 * 
	 * @param date the date
	 * 
	 * @return date + " 00:00:00"
	 */
	private static String fromDateToDateHeure(String date) {
		return date + MIDNIGHT_STRING;
	}

	/**
	 * Retourne le ProduitServiceSouhaite valoris� avec les donn�es.
	 * (RG5 dans la sp�cification)
	 * 
	 * @param ligneCdeArtemis ligne de commande au format Artemis
	 * @param a_ligneCdeEFB ligne de commande de l'IC EFB
	 * @param a_keyOffre code offre
	 * @param a_codeActionArtemis code action art�mis
	 * @param typeDebitCmd le type d�bit commande
	 * @return le produit service souhait�
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>10/08/2012</TD><TD>GPA</TD><TD>EV-000204: Gestion des cas de conversion code action</TD></TR>
	 * </TABLE>
	 */
	protected ProduitServiceSouhaite getProduitServiceSouhaite(LigneCommandeType ligneCdeArtemis, LigneCde a_ligneCdeEFB, String a_keyOffre, String a_codeActionArtemis, String typeDebitCmd) {
		final String l_method = "getProduitServiceSouhaite";
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement du ProduitServiceSouhaite");

		ProduitServiceSouhaite l_psSouhaite = new ProduitServiceSouhaite();
		if (!PORTA_TYPE_DEBIT_CMD.equals(typeDebitCmd)) {
			if (aps.TypeOpPonctuellesConstantes.CR.equals(a_codeActionArtemis)) {
				String l_codeActionEFB = a_ligneCdeEFB.getRefOpCommercialeLPA();
				if ((!EFBConstantes.DEM.equals(l_codeActionEFB)) && (!isCasConversionCodeAction(ligneCdeArtemis))) {
					l_psSouhaite.setIdEPCFutur(a_ligneCdeEFB.getEltParcCreeLC().getRefEltParc());
					l_psSouhaite.setIdAccesClient(a_ligneCdeEFB.getEltParcCreeLC().getNDARPorteur());
					l_psSouhaite.setIdElementParcSupport(a_ligneCdeEFB.getEltParcCreeLC().getNDARPorteur());

				} else {
					l_psSouhaite.setIdEPCFutur(a_ligneCdeEFB.getEltParcImpacteLC().getRefEltParc());
					l_psSouhaite.setIdAccesClient(a_ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur());
					l_psSouhaite.setIdElementParcSupport(a_ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur());
				}
			}
			if (aps.TypeOpPonctuellesConstantes.MO.equals(a_codeActionArtemis)) {
				l_psSouhaite.setIdEPCFutur(a_ligneCdeEFB.getEltParcImpacteLC().getRefEltParc());
				l_psSouhaite.setIdAccesClient(a_ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur());
				l_psSouhaite.setIdElementParcSupport(a_ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur());
			}
			if (aps.TypeOpPonctuellesConstantes.DENUM.equals(a_codeActionArtemis)) {
				l_psSouhaite.setIdEPCFutur(a_ligneCdeEFB.getEltParcImpacteLC().getRefEltParc());
				l_psSouhaite.setIdAccesClient(a_ligneCdeEFB.getEltParcImpacteLC().getNDARPorteurAncien());
				l_psSouhaite.setIdElementParcSupport(a_ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur());
			}
		} else {
			// EV-000006 : PortaSIP
			if (aps.TypeOpPonctuellesConstantes.CR.equals(a_codeActionArtemis) || aps.TypeOpPonctuellesConstantes.MO.equals(a_codeActionArtemis)) {
				l_psSouhaite.setIdEPCFutur(ndConserve);
				l_psSouhaite.setIdAccesClient(ndConserve);
				l_psSouhaite.setIdElementParcSupport(ndConserve);
			}
		}
		l_psSouhaite.setRefOffreCible(a_keyOffre);

		return l_psSouhaite;
	}

	/**
	 * Sets the parametres produit service et epc.
	 * 
	 * @param a_ligneCdeEFB ligne de commande de l'IC EFB
	 * @param a_psSouhaite psSouhaite
	 * @param a_eltParc Element de Parc affect�
	 * @param a_listeValeurParametre liste des valeurs des param�tres de l'offre
	 * @param a_paramFonctNotification param�tres Fonctionnels pour notification
	 * @param a_ligneCde la ligne de commadne en construction
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/06/2011</TD><TD>GPA</TD><TD>EV-000059: appel � la m�thode isCasConversionCodeAction()</TD></TR>
	 * <TR><TD>29/09/2011</TD><TD>GPA</TD><TD>Defect_198: Ajout d'un argument � l'appel de la m�thode setParametresProduitServiceEtEPC()</TD></TR>
	 * </TABLE>
	 */
	private void setParametresProduitServiceEtEPC(String codeActionArtemis, bolbec.injection.xml.generated.Commande commandeArtemis, LigneCde a_ligneCdeEFB, ProduitServiceSouhaite a_psSouhaite, ElementParcAffecte a_eltParc,
			List<ValeurParametreDTO> a_listeValeurParametre, Map<String, Object> a_paramFonctNotification, LigneCommandeType a_ligneCde) {
		final String l_method = "setParametresProduitServiceEtEPC";
		boolean trouveTechno = false;
		boolean trouveInterface = false;
		String l_valeurDebit = BLANK_STRING;
		// Fonctions issues de l'IC EFB
		int l_nbValeurFonctionPSS = a_ligneCdeEFB.getValeurFonctionPSSCount();
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement des " + l_nbValeurFonctionPSS + " fonctions issues de l'IC EFB");

		for (int i = 0; i < l_nbValeurFonctionPSS; i++) {
			ValeurFonctionPSS lvaleurFonctionPSS = a_ligneCdeEFB.getValeurFonctionPSS(i);
			FonctionEfbDTO fonctionEfbDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(FonctionEfbDTO.class, new Comparaison(FonctionEFB.FIELD_REFERENCE, Constantes.OPERATOR_LIKE, lvaleurFonctionPSS.getRefFonctionPSS()),
					new Comparaison(FonctionEFB.FIELD_VALEUR, Constantes.OPERATOR_LIKE, lvaleurFonctionPSS.getValeurFonctionPSS()));
			if (fonctionEfbDTO != null) {
				ValeurParametreDTO valeurParametreDTO = fonctionEfbDTO.getValeurParametre();
				String l_valeurParametre = valeurParametreDTO.getValeur();
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "R�cup�ration valeur parametre : " + l_valeurParametre);
				ParametresDTO parametresDTO = valeurParametreDTO.getParametres();
				String l_codeParametre = parametresDTO.getCode();
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "R�cup�ration code parametre : " + l_codeParametre);
				if (l_codeParametre != null) {
					if (EFBConstantes.TECHNOLOGIE.equals(l_codeParametre)) {
						trouveTechno = true;
					}
					if (EFBConstantes.DEBIT.equals(l_codeParametre)) {
						l_valeurDebit = l_valeurParametre;
					}
					if (EFBConstantes.INTERFACE.equals(l_codeParametre)) {
						trouveInterface = true;
					}
					majParam(codeActionArtemis, commandeArtemis, l_codeParametre, l_valeurParametre, a_psSouhaite, a_eltParc, a_ligneCdeEFB);
				}
			} else {
				if (!isCasConversionCodeAction(a_ligneCde)) {
					// ALE - IRMA_55 - si la fonction EFB n'est pas dans le catalogue, cela peut �tre le Z0BPQ
					String valeurExterne = serviceManager.getTraductionManager().getTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_Z0BPQ_PORTA, ConstantesTraduction.TRADUCTION_CLE_Z0BPQ_PORTA);
					if (valeurExterne != null && valeurExterne.equals(lvaleurFonctionPSS.getRefFonctionPSS())) {
						majParam(codeActionArtemis, commandeArtemis, ConstantesDynamicPSSouhaite.PSSOUHAITE_Z0BPQ, lvaleurFonctionPSS.getValeurFonctionSimplePSS(), a_psSouhaite, a_eltParc, a_ligneCdeEFB);
						serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "R�cup�ration code parametre : " + lvaleurFonctionPSS.getRefFonctionPSS() + "=" + lvaleurFonctionPSS.getValeurFonctionSimplePSS());
					}
				}
			}
		}

		// Fonctions issues de la liste des param�tres techniques
		if (a_listeValeurParametre != null && !a_listeValeurParametre.isEmpty()) {
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement des " + a_listeValeurParametre.size() + " parametres techniques");
			for (ValeurParametreDTO valeurParametreDTO : a_listeValeurParametre) {
				String l_valeurParametre = valeurParametreDTO.getValeur();
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "R�cup�ration valeur parametre : " + l_valeurParametre);
				ParametresDTO parametresDTO = valeurParametreDTO.getParametres();
				String l_codeParametre = parametresDTO.getCode();
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "R�cup�ration code parametre : " + l_codeParametre);
				if (l_codeParametre != null) {
					if (EFBConstantes.TECHNOLOGIE.equals(l_codeParametre)) {
						trouveTechno = true;
					}
					if (EFBConstantes.DEBIT.equals(l_codeParametre)) {
						l_valeurDebit = l_valeurParametre;
					}
					if (EFBConstantes.INTERFACE.equals(l_codeParametre)) {
						trouveInterface = true;
					}
					majParam(codeActionArtemis, commandeArtemis, l_codeParametre, l_valeurParametre, a_psSouhaite, a_eltParc, a_ligneCdeEFB);
				}
			}
		}

		// Cas particulier pour la technologie
		if (!trouveTechno) {
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Cas Techno non trouv�e");
			String l_valeurTechno = BLANK_STRING;
			String l_idTechno = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.MODIF_TECHNO, l_valeurDebit);
			if (l_idTechno != null) {
				ValeurParametreDTO valeurParametreDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ValeurParametreDTO.class, serviceManager.getVersionManager().prefixerWithCurrentGoRoCo(l_idTechno));
				l_valeurTechno = valeurParametreDTO.getValeur();
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "ValeurTechno : " + l_valeurTechno);
			} else {
				l_idTechno = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.TECHNO_PARDEFAUT, EFBConstantes.TECHNOLOGIE);
				if (StringUtils.isEmpty(l_idTechno)) {
					a_paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, a_ligneCdeEFB.getRefLigneCde());
					throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Pas de technologie par d�faut");
				}
				ValeurParametreDTO valeurParametreDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ValeurParametreDTO.class, serviceManager.getVersionManager().prefixerWithCurrentGoRoCo(l_idTechno));
				l_valeurTechno = valeurParametreDTO.getValeur();
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "valeurTechno par d�faut : " + l_valeurTechno);
			}
			majParam(codeActionArtemis, commandeArtemis, EFBConstantes.TECHNOLOGIE, l_valeurTechno, a_psSouhaite, a_eltParc, a_ligneCdeEFB);
		}

		if (!trouveInterface) {
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Cas Interface non trouv�e");
			String l_idInterface = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.INTERFACE_PARDEFAUT, EFBConstantes.INTERFACE);
			if (StringUtils.isEmpty(l_idInterface)) {
				a_paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, a_ligneCdeEFB.getRefLigneCde());
				throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Pas d'interface par d�faut");
			}
			ValeurParametreDTO valeurParametreDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ValeurParametreDTO.class, serviceManager.getVersionManager().prefixerWithCurrentGoRoCo(l_idInterface));
			String l_valeurInterface = valeurParametreDTO.getValeur();
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "valeurInterface par d�faut : " + l_valeurInterface);
			majParam(codeActionArtemis, commandeArtemis, EFBConstantes.INTERFACE, l_valeurInterface, a_psSouhaite, a_eltParc, a_ligneCdeEFB);
		}
	}

	/**
	 * 
	 * @param ligneCdeEFB
	 * @param commande : la commande Artemis
	 * 
	 * RG27 : Si une balise PLPSansPTOId contenant une valeur existe ou s'il existe une offre ACCES_FIBRE avec le PTOId valoris�, on est dans un contexte PLP
	 */
	protected void valorisationContextePLP(LigneCde ligneCdeEFB, bolbec.injection.xml.generated.Commande commande) {
		final String methode = "valorisationContextePLP";
		boolean isContextePLP = false;

		String valExterne = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.CLE_CAS_METIER_PLP, commande.getCasMetier());
		if (Constantes.CST_OUI.equals(valExterne)) {
			if (ligneCdeEFB.getPartageRessTechniques() != null && ligneCdeEFB.getPartageRessTechniques().getPLPSansPTOId() != null) {
				// S'il existe une balise <PLPSansPTOId>
				isContextePLP = true;
			} else {
				for (ValeurFonctionPSS valPSS : ligneCdeEFB.getValeurFonctionPSS()) {
					String valeurExterne = ligneCdeEFB.getCodeOffrePSS() + PIPE_SEPARATEUR + valPSS.getRefFonctionPSS();
					String valArtemis = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_ACCES_FIBRE_PLP, valeurExterne);
					if (Constantes.CST_OUI.equals(valArtemis) && !StringUtils.isEmpty(valPSS.getRefFonctionPSS())) {
						// Si on trouve un couple RefFonctionPSS / ValeurFonctionPSS correspondante
						isContextePLP = true;
					}
				}
			}
			// Si on est dans un contexte PLP, le param�tre ContextePLP est valoris�
			if (isContextePLP) {
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Valorisation du contexte PLP : true");
				commande.addParametresCommande(createParametre(EFBConstantes.CONTEXTE_PLP, Constantes.CST_TRUE));
			}
		}
	}

	/**
	 * RG28 : R�cup�ration RIO
	 * 
	 * @param ligneCdeEFB
	 * @param l_ligneCde
	 */
	private void recuperationRIO(LigneCde ligneCdeEFB, LigneCommandeType l_ligneCde) {
		String valeurArtemis = ligneCdeEFB.getCodeOffrePSS();
		List<String> valeursExternes = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_RIO, valeurArtemis);
		for (ValeurFonctionPSS valPSS : ligneCdeEFB.getValeurFonctionPSS()) {
			if (valeursExternes.contains(valPSS.getRefFonctionPSS())) {
				l_ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.RIO, valPSS.getValeurFonctionSimplePSS()));
				break;
			}
		}
	}

	/**
	 * RG29 : Valorisation de la date d'acceptation de la commande par l'OI
	 *
	 * @param ligneCdeEFB
	 * @param ligneCommandeType
	 */
	private void valorisationDateAcceptationCommandeOI(LigneCde ligneCdeEFB, bolbec.injection.xml.generated.LigneCommandeType ligneCommandeType) {
		List<TraductionCatComDTO> traductions = serviceManager.getTraductionManager().findTraductionCatComByCleAndSystemeExterne(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_DATE_AC_OI);
		for (TraductionCatComDTO trad : traductions) {
			for (ValeurFonctionPSS valFctPss : ligneCdeEFB.getValeurFonctionPSS()) {
				if (trad.getValeurExterne().equals(valFctPss.getRefFonctionPSS())) {
					String date = DateUtils.changeFormatDate(valFctPss.getValeurFonctionSimplePSS(), EFBConstantes.FORMAT_DATE_AC, EFBConstantes.FORMAT_DATE_HEURE);
					ligneCommandeType.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_DATE_DEBUT_ACCEPTATION_CMD_ACCES, date));
					return;
				}
			}
		}
	}

	/**
	 * RG30 : R�cup�ration du code OI
	 *
	 * @param commandeEFB
	 * @param casMetier
	 * @return
	 */
	private String recuperationCodeOI(Commande commandeEFB, String casMetier) {
		List<TraductionCatComDTO> traductions = serviceManager.getTraductionManager().findTraductionCatComByCleAndSystemeExterne(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_OPERATEUR_IMMEUBLE);
		for (LigneCde ligneCdeEfb : commandeEFB.getLigneCde()) {
			for (TraductionCatComDTO trad : traductions) {
				for (ValeurFonctionPSS valFctPss : ligneCdeEfb.getValeurFonctionPSS()) {
					if (trad.getValeurExterne().equals(valFctPss.getRefFonctionPSS())) {
						String codeOI = valFctPss.getValeurFonctionSimplePSS();
						if (StringUtils.isNotBlank(codeOI)) {
							return codeOI;
						}
					}
				}
			}
		}

		if (CasMetierConstantes.CR_FTTH.equals(casMetier)) {
			return ConstantesDynamicLigneCommande.NON_RENSEIGNE;
		}

		return null;
	}

	/**
	 * Recherche la pr�sence d'infos compl�mentaires � recopier sur le pss, puis les recopie dans les param�tres Produit ou Service
	 * 
	 * @param psSouhaite le PSS
	 * @param ligneCdeEFB la ligne de commande EFB
	 */
	protected void valoriserInfoComplementaireSurPSS(ProduitServiceSouhaite psSouhaite, LigneCde ligneCdeEFB, bolbec.injection.xml.generated.Commande commande) {
		final String methode = "valoriserInfoComplementaireSurPSS";

		// Les infos ne sont recopi�s que dans un contexte PLP
		boolean isContextePLP = false;
		for (ParametreType parametreCommande : commande.getParametresCommande()) {
			if (EFBConstantes.CONTEXTE_PLP.equals(parametreCommande.getCle()) && Constantes.CST_TRUE.equals(parametreCommande.getValeur())) {
				isContextePLP = true;
			}
		}
		if (isContextePLP) {
			for (ValeurFonctionPSS valPSS : ligneCdeEFB.getValeurFonctionPSS()) {
				String refFonctionPSS = valPSS.getRefFonctionPSS();
				if (refFonctionPSS != null) {
					String valeurArtemis = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.FONCTION_RECOPIE_PSS, refFonctionPSS);
					if (valeurArtemis != null) {
						// On r�cup�re la valeur ValeurFonctionPSS si elle est renseign�e, sinon la ValeurFonctionSimplePSS
						final String valeurParamPS;
						if (valPSS.getValeurFonctionPSS() != null) {
							valeurParamPS = valPSS.getValeurFonctionPSS();
						} else if (valPSS.getValeurFonctionSimplePSS() != null) {
							valeurParamPS = valPSS.getValeurFonctionSimplePSS();
						} else {
							throw new ReceptionCdeException(AnomalieConstantes.CONTENU_ICEFB, "Les valeurs FonctionPSS et FonctionSimplePSS sont nulles lors de la recherche d'infos compl�mentaires");
						}
						serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Ajout parametre " + valeurArtemis + " pour DynamicPS");
						psSouhaite.addParametreProduitService(createParametre(valeurArtemis, valeurParamPS));
					}
				}
			}
		} else {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Contexte non PLP : pas de valorisation d'infos compl�mentaires sur le PSS.");
		}
	}

	/**
	 * Determination de la n�cessit� de convertir le code action
	 * 
	 * @param ligneCommandeType
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/06/2011</TD><TD>GPA</TD><TD>EV-000059: Cr�ation de la m�thode</TD></TR>
	 * <TR><TD>29/09/2011</TD><TD>GPA</TD><TD>Defect_198: R�cup�ration de la ligne de commande en param�tre de la m�thode</TD></TR>
	 * </TABLE>
	 */
	protected boolean isCasConversionCodeAction(LigneCommandeType ligneCommandeType) {
		List<ParametreType> paramLC = Arrays.asList(ligneCommandeType.getParametreLivraison());
		for (ParametreType param : paramLC) {
			if (CONVERSION_CODE_ACTION.equals(param.getCle()) && Constantes.CST_OUI.equals(param.getValeur())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Maj param.
	 * 
	 * @param codeActionArtemis le code action actemis (CR, MO, SU, ...)
	 * @param commandeArtemis La commande en cours de cr�ation
	 * @param l_codeParametre Code parametre
	 * @param l_valeurParametre Valeur parametre
	 * @param a_psSouhaite the a_ps souhaite
	 * @param a_eltParc the a_elt parc
	 * @param a_ligneCdeEFB the a_ligne cde efb
	 */
	protected void majParam(String codeActionArtemis, bolbec.injection.xml.generated.Commande commandeArtemis, String l_codeParametre, String l_valeurParametre, ProduitServiceSouhaite a_psSouhaite, ElementParcAffecte a_eltParc, LigneCde a_ligneCdeEFB) {
		final String l_method = "majParam";
		String l_param = l_codeParametre;
		// ALE - IRMA_55 - le Z0BPQ n'est pas un "paramDet"
		if (!ConstantesDynamicPSSouhaite.PSSOUHAITE_Z0BPQ.equals(l_codeParametre)) {
			l_param = ConstantesDynamic.PREFIX_PARAM_DETENTION + l_codeParametre;
		}
		if (a_psSouhaite != null) {
			a_psSouhaite.addParametreProduitService(createParametre(l_param, l_valeurParametre));
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout parametre " + l_param + " pour DynamicPS");
			// Traitement de l'offre d'origine
			a_psSouhaite.addParametreProduitService(createParametre(EFBConstantes.OSIRIS_ID_OFFRE_ORIGINE, a_ligneCdeEFB.getCodeOffrePSS()));

			// FTTH_Lot2: Gestion des lignes de modification
			if (a_eltParc != null && aps.TypeOpPonctuellesConstantes.MO.equals(codeActionArtemis) && (CasMetierConstantes.MO_FTTH.equals(commandeArtemis.getCasMetier()) || CasMetierConstantes.RECR_FTTH.equals(commandeArtemis.getCasMetier()))) {
				a_eltParc.addParametreElementParc(createParametre(l_param, l_valeurParametre));
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout parametre " + l_param + " pour DynamicEPC");
				// Traitement de l'offre d'origine
				a_eltParc.addParametreElementParc(createParametre(EFBConstantes.OSIRIS_ID_OFFRE_ORIGINE, a_ligneCdeEFB.getCodeOffrePSS()));
			}

			// EV-442 : Denum SCA -> Gestion des commandes de DENUM
			if (a_eltParc != null && aps.TypeOpPonctuellesConstantes.DENUM.equals(codeActionArtemis)) {
				a_eltParc.addParametreElementParc(createParametre(l_param, l_valeurParametre));
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout parametre " + l_param + " pour DynamicEPC");
				// Traitement de l'offre d'origine
				a_eltParc.addParametreElementParc(createParametre(EFBConstantes.OSIRIS_ID_OFFRE_ORIGINE, a_ligneCdeEFB.getCodeOffrePSS()));
				// Sauvegarde du nouveau ND sur le PSSouhaite
				a_psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.PSSOUHAITE_NOUVEAU_ND, a_ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur()));
			}

		} else {
			if (a_eltParc != null) {
				a_eltParc.addParametreElementParc(createParametre(l_param, l_valeurParametre));
				serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Ajout parametre " + l_param + " pour DynamicEPC");
				// Traitement de l'offre d'origine
				a_eltParc.addParametreElementParc(createParametre(EFBConstantes.OSIRIS_ID_OFFRE_ORIGINE, a_ligneCdeEFB.getCodeOffrePSS()));
			}
		}
	}

	/**
	 * Creates the parametre.
	 * 
	 * @param a_key Cl�
	 * @param a_value Valeur
	 * 
	 * @return ParametreType
	 */
	protected ParametreType createParametre(String a_key, String a_value) {
		ParametreType l_param = new ParametreType();
		l_param.setCle(a_key);
		l_param.setValeur(a_value);
		return l_param;
	}

	/**
	 * Gets the client livre.
	 * 
	 * @param a_ligneCdeEFB Ligne de commande EFB
	 * 
	 * @return ClientLivre
	 */
	private ClientLivre getClientLivre(LigneCde a_ligneCdeEFB) {
		final String l_method = "getClientLivre";
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement du client livr�");
		ClientDetenteur l_clientLivre = a_ligneCdeEFB.getClientDetenteur();

		ClientLivre l_client = new ClientLivre();

		l_client.setIdClient(l_clientLivre.getRefClientDetenteur());
		l_client.setCategorie(l_clientLivre.getSegmentationMarcheCltDetenteur());
		l_client.setCivilite(l_clientLivre.getCiviliteClientDetenteur());
		String l_nomClient = l_clientLivre.getNomClientDetenteur();
		String l_identiteClient = BLANK_STRING;
		if (l_nomClient != null) {
			l_identiteClient = l_nomClient;
		} else {
			String l_raisonSocialeClient = l_clientLivre.getRaisonSocialeClientDetenteur();
			if (l_raisonSocialeClient != null) {
				l_identiteClient = l_raisonSocialeClient;
			}
		}
		l_client.setNomOuRaisonSociale(l_identiteClient);
		l_client.setPrenom(l_clientLivre.getPrenomClientDetenteur());
		String l_siret = l_clientLivre.getCodeSiretClientDetenteur();
		if (l_siret != null) {
			l_client.setSiren(l_siret.substring(0, 9));
			l_client.setNic(l_siret.substring(9));
		}
		setAdresseInstall(a_ligneCdeEFB, l_client);
		return l_client;
	}

	/**
	 * Sets the adresse install.
	 * 
	 * @param a_ligneCdeEFB ligne de commande EFB
	 * @param l_client client livr�
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * </TABLE>
	 */
	private void setAdresseInstall(LigneCde a_ligneCdeEFB, ClientLivre l_client) {
		final String l_method = "setAdresseInstall";
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement de l'adresse d'installation");
		// ADRESSE d'installation
		AdresseInstallPSS l_adresseInstallPSS = a_ligneCdeEFB.getAdresseInstallPSS();
		if (l_adresseInstallPSS != null) {
			Adresse l_ladresseInstall = new Adresse();
			l_ladresseInstall.setLigne1(concatenerLigneAdresse(l_adresseInstallPSS.getLigne1AdrInstallPSS(), l_adresseInstallPSS.getLigne2AdrInstallPSS()));
			l_ladresseInstall.setLigne2(concatenerLigneAdresse(l_adresseInstallPSS.getLigne3AdrInstallPSS(), l_adresseInstallPSS.getLigne4AdrInstallPSS()));
			l_ladresseInstall.setTypeVoie(l_adresseInstallPSS.getTypeDeVoieAdrInstallPSS());
			l_ladresseInstall.setNumeroVoie(l_adresseInstallPSS.getNumeroDansVoieInstallPSS());
			l_ladresseInstall.setCpltNumVoie(l_adresseInstallPSS.getCpltNumeroDansVoieAdrInstallPSS());
			l_ladresseInstall.setLibelleVoie(l_adresseInstallPSS.getNomVoieInstallPSS());
			l_ladresseInstall.setCodePostal(l_adresseInstallPSS.getCPAdrInstallPSS());
			l_ladresseInstall.setVille(l_adresseInstallPSS.getCommuneAdrInstallPSS());
			l_ladresseInstall.setPays(l_adresseInstallPSS.getPaysAdrInstallPSS());
			l_ladresseInstall.setEnsemble(l_adresseInstallPSS.getEnsemblePSS());
			l_ladresseInstall.setBatiment(l_adresseInstallPSS.getBatimentPSS());
			l_ladresseInstall.setEscalier(l_adresseInstallPSS.getEscalierPSS());
			l_ladresseInstall.setEtage(l_adresseInstallPSS.getEtagePSS());
			l_ladresseInstall.setPorte(l_adresseInstallPSS.getPortePSS());
			l_ladresseInstall.setLogo(l_adresseInstallPSS.getLogoPSS());
			l_ladresseInstall.setCodeRivoli(l_adresseInstallPSS.getNumeroRivoliInstallPSS());
			l_ladresseInstall.setCodeInsee(l_adresseInstallPSS.getCINSEECommuneAdrInstallPSS());
			l_client.setAdresse(l_ladresseInstall);
			serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "adresse d'installation rattach� au client livr�");
		}
	}

	/**
	 * Gets the element parc affecte.
	 * 
	 * @param a_ligneCdeEFB ligne de commande EFB
	 * @param a_offreArtemis the a_offre bolbec
	 * @param a_clientContractant the a_client contractant
	 * @param commande
	 * @param typeDebitCommande
	 * 
	 * @return ElementParcAffecte
	 */
	private ElementParcAffecte getElementParcAffecte(LigneCde a_ligneCdeEFB, String a_offreArtemis, ClientDetenteur a_clientContractant, bolbec.injection.xml.generated.Commande commande, String typeDebitCommande, String codeActionArtemis) {
		final String l_method = "getElementParcAffecte";
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement de l'�l�ment de Parc affect�");
		ElementParcAffecte l_eltParc = new ElementParcAffecte();
		l_eltParc.setRefOffreExistante(a_offreArtemis);
		l_eltParc.setIdClientContractant(a_clientContractant.getRefClientDetenteur());
		// Appel de la RG16
		majIdAccesClientEtIdEPCommercial(l_eltParc, commande, a_ligneCdeEFB, typeDebitCommande, codeActionArtemis);
		return l_eltParc;
	}

	/**
	 * M�thode l'instance OffreGroup�e.
	 * 
	 * @param listeOG the a_liste og
	 * @param refOffreGroupee the a_ref offre groupee
	 * 
	 * @return InstanceOffreGroupee
	 */
	private InstanceOffreGroupee getInstanceOffreGroupee(Map<String, InstanceOffreGroupee> listeOG, String refOffreGroupee) {
		final String method = "getInstanceOffreGroupee";
		serviceManager.getLoggerManager().finest(CLASSNAME, method, "Traitement de l'instanceOffreGroupee");
		// Recherche si cette instance a d�j� �t� trouv�e
		Iterator<Entry<String, InstanceOffreGroupee>> iterator = listeOG.entrySet().iterator();
		while (iterator.hasNext()) {
			Entry<String, InstanceOffreGroupee> entry = iterator.next();
			String keyOffreGroupee = entry.getKey();
			serviceManager.getLoggerManager().finest(CLASSNAME, method, "comparaison offre group�e avec :" + keyOffreGroupee);
			if (StringUtils.equals(refOffreGroupee, keyOffreGroupee)) {
				serviceManager.getLoggerManager().finest(CLASSNAME, method, "R�cup�ration offre group�e avec la cl� : " + keyOffreGroupee);
				return entry.getValue();
			}
		}
		return null;
	}

	/**
	 * Gets the ref offre groupe.
	 * 
	 * @param a_codeOffreArtemis code offre Artemis
	 * @param a_idLC the a_id lc
	 * @param a_paramFonctNotification the a_param fonct notification
	 * 
	 * @return String r�f�rence de l'offre group�e
	 */
	private String getRefOffreGroupe(String a_codeOffreArtemis, String a_idLC, Map<String, Object> a_paramFonctNotification) {
		OffreDTO offreDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, a_codeOffreArtemis);
		DescGroupeOffresDTO descGroupeOffresDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(DescGroupeOffresDTO.class, new Comparaison(DescGroupeOffres.SLINK_CONTIENT_OFFRE, Constantes.OPERATOR_EQUAL, offreDTO.getId()));
		if (descGroupeOffresDTO == null) {
			a_paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, a_idLC);
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Aucune groupe d'offres pour l'offre " + offreDTO.getId());
		}
		GroupeOffresDTO groupeOffresDTO = descGroupeOffresDTO.getGroupeOffres();
		if (groupeOffresDTO == null) {
			a_paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, a_idLC);
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Aucune groupe d'offres pour l'offre " + offreDTO.getId());
		}
		List<DescOffreGroupeeDTO> descOffreGroupeeDTOs = serviceManager.getReferenceSpaceManager().listInReferenceSpace(DescOffreGroupeeDTO.class,
				new Comparaison(DescOffreGroupee.SLINK_CONTIENT_GROUPE_OFFRES, Constantes.OPERATOR_EQUAL, groupeOffresDTO.getId()));
		if (descOffreGroupeeDTOs.size() == 0) {
			a_paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, a_idLC);
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Aucun offre group�e pour le groupe d'offres " + offreDTO.getId());
		}
		return CollectionUtils.getFirstOrNull(descOffreGroupeeDTOs).getOffreGroupee().getId();
	}

	/**
	 * Gets the client contractant.
	 * 
	 * @param a_ligneCdeEFB ligne de commande EFB
	 * @param a_clientDetenteur client contractant EFB
	 * 
	 * @return ClientContractant client contractant pour Art�mis
	 */
	private ClientContractant getClientContractant(LigneCde a_ligneCdeEFB, ClientDetenteur a_clientDetenteur) {
		final String l_method = "getClientContractant";
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement du client contractant");
		ClientContractant l_client = new ClientContractant();
		l_client.setIdClient(a_clientDetenteur.getRefClientDetenteur());
		l_client.setCategorie(a_clientDetenteur.getSegmentationMarcheCltDetenteur());
		l_client.setCivilite(a_clientDetenteur.getCiviliteClientDetenteur());
		String l_nomClient = a_clientDetenteur.getNomClientDetenteur();
		String l_identiteClient = BLANK_STRING;
		if (l_nomClient != null) {
			l_identiteClient = l_nomClient;
		} else {
			String l_raisonSocialeClient = a_clientDetenteur.getRaisonSocialeClientDetenteur();
			if (l_raisonSocialeClient != null) {
				l_identiteClient = l_raisonSocialeClient;
			}
		}
		l_client.setNomOuRaisonSociale(l_identiteClient);
		l_client.setPrenom(a_clientDetenteur.getPrenomClientDetenteur());
		String l_siret = a_clientDetenteur.getCodeSiretClientDetenteur();
		if (l_siret != null) {
			l_client.setSiren(l_siret.substring(0, 9));
			l_client.setNic(l_siret.substring(9));
		}

		setAdresseClientContractant(a_ligneCdeEFB, l_client);
		return l_client;
	}

	/**
	 * Sets the adresse client contractant.
	 * 
	 * @param a_ligneCdeEFB ligne de commande EFB
	 * @param a_client client contractant
	 */
	private void setAdresseClientContractant(LigneCde a_ligneCdeEFB, ClientContractant a_client) {
		final String l_method = "setAdresseClientContractant";
		serviceManager.getLoggerManager().finest(CLASSNAME, l_method, "Traitement de l'adresseClientContractant");
		// ADRESSE
		Adresse l_ladresse = new Adresse();
		AdressePrincipale l_adressePrincipale = a_ligneCdeEFB.getAdressePrincipale();
		if (l_adressePrincipale != null) {
			l_ladresse.setLigne1(concatenerLigneAdresse(l_adressePrincipale.getLigne1AdrPrincipale(), l_adressePrincipale.getLigne2AdrPrincipale()));
			l_ladresse.setLigne2(concatenerLigneAdresse(l_adressePrincipale.getLigne3AdrPrincipale(), l_adressePrincipale.getLigne4AdrPrincipale()));
			l_ladresse.setCodePostal(l_adressePrincipale.getCPAdrPrincipale());
			l_ladresse.setVille(l_adressePrincipale.getCommuneAdrPrincipale());
			l_ladresse.setPays(l_adressePrincipale.getPaysAdrPrincipale());
			a_client.setAdresse(l_ladresse);
		}
	}

	/**
	 * Concatener ligne adresse.
	 * 
	 * @param ligne1 the ligne1
	 * @param ligne2 the ligne2
	 * 
	 * @return the string
	 */
	private String concatenerLigneAdresse(String ligne1, String ligne2) {
		StringBuffer sb = new StringBuffer(BLANK_STRING);
		if (ligne1 != null) {
			sb.append(ligne1);
		}
		if (ligne2 != null) {
			if (ligne1 != null) {
				sb.append(SPACE_STRING);
			}
			sb.append(ligne2);
		}
		return sb.toString();
	}

	/**
	 * Translate.
	 * 
	 * @param a_key the a_key
	 * @param a_externalValue the a_external value
	 * @param a_idLC the a_id lc
	 * @param a_paramFonctNotification the a_param fonct notification
	 * 
	 * @return the string
	 */
	private String translate(String a_key, String a_externalValue, String a_idLC, Map<String, Object> a_paramFonctNotification) throws ReceptionCdeException {
		return translate(a_key, a_externalValue, SystemeExterneConstantes.EFB, a_idLC, a_paramFonctNotification);
	}

	/**
	 * Translate.
	 * 
	 * @param a_key the a_key
	 * @param a_externalValue the a_external value
	 * @param a_systemeExterne the a_systeme externe
	 * @param a_idLC the a_id lc
	 * @param a_paramFonctNotification the a_param fonct notification
	 * 
	 * @return the string
	 */
	private String translate(String a_key, String a_externalValue, String a_systemeExterne, String a_idLC, Map<String, Object> a_paramFonctNotification) throws ReceptionCdeException {
		String l_return = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(a_systemeExterne, a_key, a_externalValue);
		if (l_return == null) {
			a_paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, a_idLC);
			throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Erreur de traduction pour la cl� " + a_key + ", la valeur externe " + a_externalValue + " et le systeme externe " + a_systemeExterne);
		}
		return l_return;
	}

	/**
	 * Mise � jour sur toutes les lignes de commande de la date souhait�e qui
	 * doit �tre la m�me partout.
	 * 
	 * @param a_message message g�n�r�
	 */
	private void mettreAJourDateSouhaitee(Message a_message) {
		final String l_method = "mettreAJourDateSouhaitee";
		bolbec.injection.xml.generated.Commande l_commande = a_message.getCommande();

		String dateResilAncienneBL = null;
		if (dateResilPlusTot != null) {
			dateResilAncienneBL = DateUtils.format(dateResilPlusTot, DateUtils.ISO_DATETIME_FORMAT_PATTERN);
			serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "MAJ date desire resil ancienne BL � " + dateResilAncienneBL);
		}

		final String l_dateSouhaitee = DateUtils.format(dateLivrePlusTot, EFBConstantes.FORMAT_DATE_HEURE);
		serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "MAJ date souhait�e � " + l_dateSouhaitee);

		// Parcours des lignes de commande de suppression
		int nbLdCs = l_commande.getLigneCommandeCount();
		serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "Parcours des " + nbLdCs + " lignes de commandes de suppressions g�n�r�es");
		for (int i = 0; i < nbLdCs; i++) {
			LigneCommandeType l_ligneCdeArtemis = l_commande.getLigneCommande(i);
			l_ligneCdeArtemis.setDateSouhaitee(l_dateSouhaitee);
			if (dateResilAncienneBL != null) {
				l_ligneCdeArtemis.addParametreLivraison(createParametre(EFBConstantes.DATE_DESIRE_RESIL_ANCIENNE_BL, dateResilAncienneBL));
			}
		}

		// Parcours des lignes de commande de cr�ation
		int l_nbIOG = l_commande.getInstanceOffreGroupeeCount();
		for (int j = 0; j < l_nbIOG; j++) {
			InstanceOffreGroupee l_instanceOffreGroupee = l_commande.getInstanceOffreGroupee(j);
			int nbLdCc = l_instanceOffreGroupee.getLigneCommandeCount();
			serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "Parcours des " + nbLdCc + " lignes de commandes de cr�ation g�n�r�es");
			for (int k = 0; k < nbLdCc; k++) {
				LigneCommandeType l_ligneCdeArtemis = l_instanceOffreGroupee.getLigneCommande(k);
				l_ligneCdeArtemis.setDateSouhaitee(l_dateSouhaitee);
				if (dateResilAncienneBL != null) {
					l_ligneCdeArtemis.addParametreLivraison(createParametre(EFBConstantes.DATE_DESIRE_RESIL_ANCIENNE_BL, dateResilAncienneBL));
				}
			}
		}
	}

	/**
	 * Traiter exception.
	 * 
	 * @param a_commandeEFB the a_commande efb
	 * @param a_versionModeleLPA versionModeleLPA
	 * @param a_paramFonctNotification param�tres fonctionnels � remonter
	 * @param a_ex exception � traiter
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>03/10/2012</TD><TD>GPA</TD><TD>EV-000190: Valorisation du code statut op commande</TD></TR>
	 * </TABLE>
	 */
	protected void traiterException(Commande a_commandeEFB, String a_versionModeleLPA, Map<String, Object> a_paramFonctNotification, ReceptionCdeException a_ex) {
		final String l_method = "traiterException";
		a_paramFonctNotification.put(EFBConstantes.CLE_VERSION_MODELE_LPA, a_versionModeleLPA);
		a_paramFonctNotification.put(EFBConstantes.CLE_REF_COMMANDE, a_commandeEFB.getRefCommande());
		if (a_commandeEFB.getStatutOpCommande() != null) {
			a_paramFonctNotification.put(EFBConstantes.CODE_STATUT_OP_COMMANDE, a_commandeEFB.getStatutOpCommande().getCodeStatutOpCommande());
		}

		// R�cup�ration de la ligne de commande en cours de traitement
		Object idLigneCdeEnCours = a_paramFonctNotification.get(EFBConstantes.CLE_LIGNE_CDE_ERREUR);

		// Boucle sur les lignes de commandes
		// (au passage, r�cup�ration de la contrainte LC de type de contrainte
		// Synchronisation pour la ligne de commande en cours de traitement)
		int nbligne = a_commandeEFB.getLigneCdeCount();
		List<String> l_listeLC = new ArrayList<String>();
		serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "R�cup�ration de l'ensemble des lignes de commandes");
		for (int i = 0; i < nbligne; i++) {
			LigneCde l_ligneCdeEFB = a_commandeEFB.getLigneCde(i);
			String l_idLC = l_ligneCdeEFB.getRefLigneCde();
			l_listeLC.add(l_idLC);
			// Du temps qu'on y est, est-ce qu'il s'agit de la ligne de commande
			// en cours ?
			if (l_idLC.equals(idLigneCdeEnCours)) {
				// On en profite pour r�cup�rer la contrainte LC
				ContrainteLC[] contrainteLC = l_ligneCdeEFB.getContrainteLC();
				if (contrainteLC != null) {
					for (int j = 0; j < contrainteLC.length; j++) {
						if (SYNCHRONISATION_TYPE_CONTRAINTE.equalsIgnoreCase(contrainteLC[j].getTypeContrainte())) {
							// Si c'est une contrainte LC de type de contrainte
							// Synchronisation, il faut l'ajouter dans la hashmap
							a_paramFonctNotification.put(EFBConstantes.CLE_SYNCHRO_MIXTE, contrainteLC[j].getValeurContrainte());
							break;
						}
					}
				}
			}
		}
		a_paramFonctNotification.put(EFBConstantes.CLE_LISTE_REF_LIGNE_CDE, l_listeLC);

		// EV-238 : recherche traduction �FORMAT_NON_PEC_EFB� pour l'anomalie � cr�er
		a_paramFonctNotification.put(EFBConstantes.CLE_CODE_CPLT_STATUT_OP, recupValeurConstanteAnomalie(a_ex.getId()));

		serviceManager.getLoggerManager().finer(CLASSNAME, l_method, "Sortie de l'adaptateur EFB par la remont�e d'une exception " + a_ex.getId());
		throw new ReceptionCdeException(a_ex.getId(), a_ex.getMessage());
	}

	/**
	 * r�cup�re la valeur constante l'anomalie
	 */
	private String recupValeurConstanteAnomalie(String anoId) {
		AnomalieDTO ano = serviceManager.getReferenceSpaceManager().findInReferenceSpace(AnomalieDTO.class, anoId);
		if (ano != null) {
			return serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, EFBConstantes.FORMAT_NON_PEC_EFB, ano.getValeurConstante());
		}
		return StringUtils.EMPTY;
	}

	/**
	 * Valorise les champs Acc�sLivraison et TypeAcc�sLivraison dans une ligne de commande. (R�gle RG10 dans la sp�cification)
	 * 
	 * @param ligneCde La ligne de commande � valoriser
	 * @param codeActionArtemis the code action bolbec
	 * @param codeActionEFB the code action efb
	 * @param commandeEFB the commande efb
	 * @param commandeArtemis the commande bolbec
	 * @param ligneCdeEFB the ligne cde efb
	 * @param paramFonctNotification the param fonct notification
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>26/01/2011</TD><TD>GPE</TD><TD>EV-000089 : Avenant sur l'adaptateur EFB</TD></TR>
	 * <TR><TD>08/02/2011</TD><TD>GPE</TD><TD>EV-000089 : Avenant sur la FQR 154</TD></TR>
	 * <TR><TD>10/03/2011</TD><TD>BPE</TD><TD>EV-000089 : Correction Defect 171</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 : NSD Gestion adresses parsifal</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>DE-000155 : Impl�mentation de la r�gle du cas metier THD manquante</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169 : Gestion du cas metier "RECR_FTTH"</TD></TR>
	 * <TR><TD>10/08/2012</TD><TD>GPA</TD><TD>EV-000204 : Gestion du cas de conversion code action lors de la r�cup�ration de l'acc�s livraison</TD></TR>
	 * <TR><TD>05/06/2014</TD><TD>GCL</TD><TD>EV-000278 : Maj pour porta FTTH </TD></TR>
	 * </TABLE>
	 */
	protected void valorisationAccesLivraison(LigneCommandeType ligneCde, String codeActionArtemis, String codeActionEFB, Commande commandeEFB, bolbec.injection.xml.generated.Commande commandeArtemis, LigneCde ligneCdeEFB,
			Map<String, Object> paramFonctNotification) {
		final String method = "valorisationAccesLivraison";

		// Initialisation des variables � calculer
		String accesLivraison = BLANK_STRING;
		String typeAccesLivraison = ND_TYPE_ACCES_LIV;

		// R�cup�ration du type de d�bit de la commande
		String typeDebitCmd = getTypeDebitCommande(commandeEFB, commandeArtemis);

		/**
		 * Sp�cificit� pour le typeDebitCmd = � HD � :
		 * Il faut faire la distinction entre une commande PARSIFAL non agr�g�e et une commande PARSIFAL agr�g�e.
		 * De plus il faut rechercher si la ligne de commande de la commande agr�g�e n�est pas l�acc�s porteur, identifi� par l�offre de famille d�offre commerciale NU_Retail_32R.
		 */
		final boolean isTypeDebitCmdHD = HD_TYPE_DEBIT_CMD.equals(typeDebitCmd);
		String trNURetail32R = null;
		if (isTypeDebitCmdHD && cmdAgregee) {
			// R�cup�ration de l'idOffre
			String idOffre = ligneCde.getProduitServiceSouhaite().getRefOffreCible();
			trNURetail32R = getAppartenanceOffreAFamilleOffre(idOffre, ConstantesTraduction.NU_Retail_32R);
		}
		String codeAction = null;
		for (ParametreType param : ligneCde.getParametreLivraison()) {
			if (EFBConstantes.CODE_ACTION_ORIGINE.equals(param.getCle())) {
				codeAction = param.getValeur();
				break;
			}
		}
		serviceManager.getLoggerManager().qualif("Yes", 0, "we", "are", codeAction);
		if (codeAction == null) {
			codeAction = ligneCde.getRefOperationPonctuelle();
		}
		serviceManager.getLoggerManager().qualif("Yes", 0, "we", "are", codeAction);
		boolean isOffreQuarantaine = isOffreTypeQuarantaine(ligneCde, ligneCdeEFB);
		if (isTypeDebitCmdHD && TypeOpPonctuellesConstantes.MO.equals(codeAction) && isOffreQuarantaine) {
			typeAccesLivraison = ND_TYPE_ACCES_LIV;
			valoriserAccesLivraisonFamilleOffreQuarantaine(ligneCdeEFB, ligneCde, commandeArtemis, paramFonctNotification, accesLivraison);
			ligneCde.setTypeAccesLivraison(typeAccesLivraison);
			return;
		}
		// EV-442 D�num�rotation
		if (isTypeDebitCmdHD && TypeOpPonctuellesConstantes.DENUM.equals(codeAction)) {
			typeAccesLivraison = ND_TYPE_ACCES_LIV;
			accesLivraison = ligneCdeEFB.getEltParcImpacteLC().getNDARPorteurAncien();
			ligneCde.setAccesLivraison(accesLivraison);
			ligneCde.setTypeAccesLivraison(typeAccesLivraison);
			return;
		}

		// si c�est une commande haut d�bit donc en provenance de PARSIFAL et non de CRISTAL on fait comme avant les commandes mixtes
		// ou
		// si c�est une commande haut d�bit Agr�g�e mais dont la ligne de commande n�est pas l�acc�s porteur
		if ((isTypeDebitCmdHD && !cmdAgregee) || (isTypeDebitCmdHD && cmdAgregee && !OUI.equals(trNURetail32R))) {
			accesLivraison = getAccesLivraisonAvecConversionCodeAction(codeActionArtemis, codeActionEFB, ligneCdeEFB, isCasConversionCodeAction(ligneCde));
		}
		// Cas d'une commande de cr�ation/modification/suppression d�acc�s FTTH ou reprise de cr�ation d�acc�s FTTH)
		else if (THD_TYPE_DEBIT_CMD.equals(typeDebitCmd)) {
			String casMetier = commandeArtemis.getCasMetier();
			if (CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.RECR_FTTH.equals(casMetier)) {
				typeAccesLivraison = IDCLI_TYPE_ACCES_LIV;
			} else {
				if (TypeOpPonctuellesConstantes.CR.equals(ligneCdeEFB.getRefOpCommercialeLPA())) {
					accesLivraison = ligneCdeEFB.getEltParcCreeLC().getNDARPorteur();
				} else {
					accesLivraison = ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur();
				}
				typeAccesLivraison = FTTH_TYPE_ACCES_LIV;
			}
		}
		// Cas d'une commande de portabilit�
		else if (PORTA_TYPE_DEBIT_CMD.equals(typeDebitCmd)) {
			// EV-000278 : Maj pour porta FTTH
			if (TypeOpPonctuellesConstantes.MO.equals(codeAction) && isOffreQuarantaine) {
				valoriserAccesLivraisonFamilleOffreQuarantaine(ligneCdeEFB, ligneCde, commandeArtemis, paramFonctNotification, accesLivraison);
				accesLivraison = ligneCde.getAccesLivraison();
			} else {
				// EV-000006 : PortaSip
				accesLivraison = getAccesLivraison(codeActionArtemis, codeActionEFB, ligneCdeEFB);
			}
			// Type d'acc�s FTTH dans les deux cas
			typeAccesLivraison = FTTH_TYPE_ACCES_LIV;
		}
		// Dans les autres cas
		else {
			/*
			 * Soit on est dans le cas d�un type de d�bit de � BD �, soit on est dans le cas d�un type de d�bit � HD � pour une commande agr�g�e
			 * et sur une ligne de commande d�offre de la famille d�offre commerciale � NU_Retail_32R �.
			 * Cette derni�re doit se comporter comme l�acc�s r�seau porteur d�une commande Agr�g�e Net+, et donc � l�identique d�une commande d�acc�s R�seau BD Cristal.
			 */

			final boolean isTypeDebitCmdBD = BD_TYPE_DEBIT_CMD.equals(typeDebitCmd);
			String trAccesReseauBD = null;
			if (isTypeDebitCmdBD) {
				// R�cup�ration de l'idOffre
				String idOffre = ligneCde.getProduitServiceSouhaite().getRefOffreCible();
				// V�rification de l'appartenance d'une offre pass�e en param�tre � une
				// familleoffrecom pass�e en param�tre (RG12)
				trAccesReseauBD = getAppartenanceOffreAFamilleOffre(idOffre, ConstantesTraduction.TRADUCTION_CLE_ACCES_RESEAU_BD);
			}

			// SI TrAccesReseauBD existe et TrAccesReseauBD.ValeurArtemis = 'OUI'
			// Alors on est dans le cas de l�acc�s r�seau porteur. Donc il faut savoir
			// sur quoi on construit. Donc il faut que l�on ait l��tat de la ligne.
			if (OUI.equals(trAccesReseauBD) || isTypeDebitCmdHD) {
				// R�cup�ration d'IC_EFB.EtatLigne et d'IC_EFB.ResReutilisablesId
				String etatLigne = null;
				String idResReutilisable = null;
				String etatResReutilisable = null;
				PartageRessTechniques partageRessTechniques = ligneCdeEFB.getPartageRessTechniques();
				if (partageRessTechniques != null) {
					etatLigne = partageRessTechniques.getEtatLigne();
					String idResReutilisableTmp = partageRessTechniques.getResReutilisablesId();
					if (StringUtils.isNotEmpty(idResReutilisableTmp)) {
						idResReutilisable = idResReutilisableTmp;
					}
					etatResReutilisable = partageRessTechniques.getEtatResReutilisablesId();
				}
				// uniquement pour une commande BD : pr�sence obligatoire pour le regroupement
				if (isTypeDebitCmdBD) {
					// Il faut �galement v�rifier que la cat�gorie de raccordement est bien
					// pr�sente dans la commande. Car elle sert dans la suite de la livraison
					if (StringUtils.isNotEmpty(etatResReutilisable)) {
						ligneCde.addParametreLivraison(createParametre(EFBConstantes.CATRAC_CRISTAL_EFB, etatResReutilisable));
					} else {
						// Lev� d'anomalie si IC_EFB.EtatResReutilisablesId est null ou vide
						// RG ANO1
						paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, ligneCde.getIdLigneCommande());
						throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur EFB - EtatResReutilisablesId est inexistat ou vide");
					}
				}
				// Lev� d'anomalie si IC_EFB.EtatLigne est null ou vide
				if (StringUtils.isEmpty(etatLigne)) {
					// RG ANO1
					paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, ligneCde.getIdLigneCommande());
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur EFB - EtatLigne est inexistat ou vide");
				}
				// Si etatLigne <> 'en service' (la ligne est � cr�er)
				if (!EN_SERVICE_ETAT_LIGNE.equalsIgnoreCase(etatLigne)) {
					if (idResReutilisable != null) {
						accesLivraison = idResReutilisable;
						typeAccesLivraison = NDPLP_TYPE_ACCES_LIV;
					} else {
						typeAccesLivraison = IDCLI_TYPE_ACCES_LIV;
					}
					// Ajout dans la HashMap des cl�s et des valeurs si elles ne sont pas nulles :
					// - idResReutilisable
					ajouterParamLiv(method, ligneCde, EFBConstantes.ID_RES_REUTILISABLE, idResReutilisable);
					// - EltParcImpacteLC.NDARPorteur
					String ndFinalChoisi = getAccesLivraison(codeActionArtemis, codeActionEFB, ligneCdeEFB);
					ajouterParamLiv(method, ligneCde, EFBConstantes.ND_FINAL_CHOISI, ndFinalChoisi);
					// Cas d'un d�m�nagement avec changement de ND
					if (EFBConstantes.DEM.equals(codeActionEFB)) {
						// Ajout dans la HashMap des cl�s et des valeurs si elles ne sont pas nulles :
						// - EltParcImpacteLC.NDARPorteurAncien
						String ndAncienneAdresse = ligneCdeEFB.getEltParcImpacteLC().getNDARPorteurAncien();
						ajouterParamLiv(method, ligneCde, EFBConstantes.ND_ANCIENNE_ADRESSE, ndAncienneAdresse);
					}
				}
				// Sinon (la ligne n'est pas � cr�er)
				else {
					if (idResReutilisable != null) {
						// Ajout dans la HashMap des cl�s et des valeurs si elles ne sont pas nulles :
						// - idResReutilisable
						ajouterParamLiv(method, ligneCde, EFBConstantes.ID_RES_REUTILISABLE, idResReutilisable);
						// - NDARPorteur
						String ndFinalChoisi = getAccesLivraison(codeActionArtemis, codeActionEFB, ligneCdeEFB);
						ajouterParamLiv(method, ligneCde, EFBConstantes.ND_FINAL_CHOISI, ndFinalChoisi);
						// Si la valeur de IdRessReutilisable <> la valeur de NDFinalChoisi alors

						// Retour arri�re partiel sur RETOUR_FT avec CHGT_ND
						if (!idResReutilisable.equals(ndFinalChoisi)) {
							accesLivraison = idResReutilisable;
							typeAccesLivraison = NDPLP_TYPE_ACCES_LIV;
						} else {
							accesLivraison = idResReutilisable;
							typeAccesLivraison = ND_TYPE_ACCES_LIV;
						}

					} else {
						// R�cup�ration du NDARPorteur
						accesLivraison = getAccesLivraison(codeActionArtemis, codeActionEFB, ligneCdeEFB);
						typeAccesLivraison = ND_TYPE_ACCES_LIV;
						// Ajout dans la HashMap des cl�s et des valeurs si elles ne sont pas nulles :
						ajouterParamLiv(method, ligneCde, EFBConstantes.ND_FINAL_CHOISI, accesLivraison);
					}
				}
			}
			// Alors on est pas dans le cas de l�acc�s r�seau porteur. Donc il est inutile de g�rer le type
			// de ligne (PLP, Retour FT, Adresse)
			else {
				// R�cup�ration du NDARPorteur
				accesLivraison = getAccesLivraison(codeActionArtemis, codeActionEFB, ligneCdeEFB);
				typeAccesLivraison = ND_TYPE_ACCES_LIV;
				// Ajout dans la HashMap des cl�s et des valeurs si elles ne sont pas nulles :
				ajouterParamLiv(method, ligneCde, EFBConstantes.ND_FINAL_CHOISI, accesLivraison);
			}
		}
		// Valorisation des champs Acc�sLivraison et TypeAcc�sLivraison
		ligneCde.setAccesLivraison(accesLivraison);
		ligneCde.setTypeAccesLivraison(typeAccesLivraison);

		// Pour un typeAccesLivraison NDPLP : on marque si n�cessaire le CONTEXTE_LIVRAISON � PLPHD
		if (NDPLP_TYPE_ACCES_LIV.equals(typeAccesLivraison)) {
			valoriserContexteLivraisonPLPHD(commandeArtemis);
		}

		serviceManager.getLoggerManager().qualif(CLASSNAME, 0, method, commandeArtemis.getIdCommande(), "MaJJ accesLivraison : " + accesLivraison + " / typeAccesLivraison : " + typeAccesLivraison);
	}

	/**
	 * RG 18 : M�thode permettant de valoriser le ndConcerve
	 * 
	 * @param ligneCdeEFB La ligne EFB � utiliser pour calculer l'information
	 */
	protected void valoriserNdConcerve(LigneCde ligneCdeEFB) {
		// Initialisation de la valeur � null
		ndConserve = null;

		// Recherche du ndConcerve
		ValeurFonctionPSS[] fonctionsPSS = ligneCdeEFB.getValeurFonctionPSS();
		for (ValeurFonctionPSS fonctionPSS : fonctionsPSS) {

			String valTraduite = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_ND_A_CONSERVER, fonctionPSS.getRefFonctionPSS());

			if (!StringUtils.isEmpty(valTraduite)) {
				ndConserve = fonctionPSS.getValeurFonctionSimplePSS();
				break;
			}
		}

		// Si le ndConcerve est null, il faut arr�ter le traitement
		// On remonte une exception
		if (ndConserve == null) {
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur EFB - L'offre de portabilite Fibre SIP doit poss�der la r�f�rence du ND Port� dans son intention de commande");
		}
	}

	/**
	 * Retourne la valeur d'acc�s livraison en fonction du type de commande.
	 * Pour info, il s'agit de l'algo utilis� avant les commandes mixtes.
	 * 
	 * @param codeActionArtemis the code action bolbec
	 * @param codeActionEFB the code action efb
	 * @param ligneCdeEFB the ligne cde efb
	 * 
	 * @return String
	 */
	private String getAccesLivraison(String codeActionArtemis, String codeActionEFB, LigneCde ligneCdeEFB) {
		// "false" pour ignorer ce param�tre
		return getAccesLivraisonAvecConversionCodeAction(codeActionArtemis, codeActionEFB, ligneCdeEFB, false);
	}

	/**
	 * Retourne la valeur d'acc�s livraison en fonction du type de commande.
	 * Pour info, il s'agit de l'algo utilis� avant les commandes mixtes.
	 * 
	 * @param codeActionArtemis the code action bolbec
	 * @param codeActionEFB the code action efb
	 * @param ligneCdeEFB the ligne cde efb
	 * @param conversionCodeAction booleen d�terminant si une conversion du code action sera n�cessaire
	 * 
	 * @return String
	 */
	private String getAccesLivraisonAvecConversionCodeAction(String codeActionArtemis, String codeActionEFB, LigneCde ligneCdeEFB, boolean conversionCodeAction) {
		String accesLivraisonLocal;
		if (aps.TypeOpPonctuellesConstantes.CR.equals(codeActionArtemis) && (!EFBConstantes.DEM.equals(codeActionEFB)) && (!conversionCodeAction)) {
			// R�cup�ration du NDARPorteur de EltParcCreeLC
			EltParcCreeLC eltParcCreeLC = ligneCdeEFB.getEltParcCreeLC();
			accesLivraisonLocal = eltParcCreeLC.getNDARPorteur();
		} else {
			// R�cup�ration du NDARPorteur de EltParcImpactLC
			EltParcImpacteLC eltParcImpacteLC = ligneCdeEFB.getEltParcImpacteLC();
			accesLivraisonLocal = eltParcImpacteLC.getNDARPorteur();
		}
		return accesLivraisonLocal;
	}

	/**
	 * Ajoute un param�tre de livraison � la ligne si la valeur n'est pas nulle.
	 * 
	 * @param method Nom de la m�thode appelante
	 * @param ligneCde the ligne cde
	 * @param cle the cle
	 * @param valeur the valeur
	 */
	private void ajouterParamLiv(String method, LigneCommandeType ligneCde, String cle, String valeur) {
		if (StringUtils.isNotEmpty(valeur)) {
			serviceManager.getLoggerManager().finest(CLASSNAME, method, "Ajout parametre " + cle);
			ligneCde.addParametreLivraison(createParametre(cle, valeur));
		}
	}

	/**
	 * M�thode permettant de construire le champs observation � partir des donn�ees pass�es en entr�e
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>26/01/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant sur l'adaptateur EFB</TD></TR>
	 * <TR><TD>18/02/2011</TD><TD>GPE</TD><TD>Correction de l'adaptateur EFB</TD></TR>
	 * </TABLE>
	 * 
	 * @param typeCritere
	 * @param motifStatutRDV
	 * @param valCritereSimple
	 * @return le champs observation construit � partir des donn�ees pass�es en entr�e
	 */
	protected String construireObservation(final String typeCritere, final String motifStatutRDV, final String valCritereSimple) {
		String observations = null;

		if (MIT_TYPE_CRITERE.equals(typeCritere)) {
			observations = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.PREST_MIT_000000, new Object[] { valCritereSimple });
		} else {
			observations = motifStatutRDV;
			if (observations != null) {
				observations = observations.replaceAll("[<>,\"']", " ");

				char c = (char) 11;
				observations = observations.replace(c, ' ');

				c = (char) 14;
				observations = observations.replace(c, ' ');

				c = (char) 124;
				observations = observations.replace(c, ' ');
			}
		}

		return observations;
	}

	/**
	 * M�thode permettant de retournant la reference rdv de l'intervention � cr�er
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>26/01/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant sur l'adaptateur EFB</TD></TR>
	 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160 - BOLBEC-2009 : KO �ligibilit� Parsifal 42C</TD></TR>
	 * </TABLE>
	 * 
	 * @param presenceERDV
	 * @param EFBRefRDV
	 * @return la reference rdv de l'intervention � cr�er
	 */
	protected String getReferenceRDVIntervention(boolean presenceERDV, final String EFBRefRDV) {
		String referenceRDV = null;

		if (presenceERDV) {
			referenceRDV = cmdAgregee ? refRDV : EFBRefRDV;
		}

		return referenceRDV;
	}

	/**
	 * Class utilitaire permettant de retourner les donn�es valoris�es par la m�thode <code>protected static RDVUtil valoriserRDV(RendezVous[] rendezVous) throws ReceptionCdeException</code>
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/02/2011</TD><TD>GPE</TD><TD>Correction de l'adaptateur EFB</TD></TR>
	 * <TR><TD>23/04/2012</TD><TD>BPE</TD><TD>EV-000198: Rejet des commandes EFB dont la dur�e d'intervention est non enti�re (Defect 25)</TD></TR>
	 * </TABLE>
	 */
	protected static class RDVUtil {
		protected Date debut = null;
		protected Date fin = null;
		protected String duree = null;
	}

	/**
	 * M�thode permettant de valoriser les dates de d�but et de fin du rdv en provenance de la commande EFB
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/02/2011</TD><TD>GPE</TD><TD>Correction de l'adaptateur EFB</TD></TR>
	 * <TR><TD>23/04/2012</TD><TD>BPE</TD><TD>EV-000198: Rejet des commandes EFB dont la dur�e d'intervention est non enti�re (Defect 25)</TD></TR>
	 * </TABLE>
	 * 
	 * @param rendezVous
	 * @return
	 * @throws ReceptionCdeException
	 */
	protected RDVUtil valoriserRDV(RendezVous[] rendezVous) throws ReceptionCdeException {
		RDVUtil retValue = new RDVUtil();
		if ((rendezVous[0].getDateRendezVous() != null) && (rendezVous[0].getHeureDebutRendezVous() != null)) {
			try {
				String debutStr = rendezVous[0].getDateRendezVous() + SPACE_STRING + rendezVous[0].getHeureDebutRendezVous();
				retValue.debut = DateUtils.parseDate(debutStr, EFBConstantes.FORMAT_DATE_HEURE);
				Calendar cal = new GregorianCalendar();
				cal.setTime(retValue.debut);
				retValue.duree = valoriserDureeIntervention(rendezVous[0].getDuree());
				cal.add(Calendar.HOUR_OF_DAY, Integer.parseInt(retValue.duree.substring(0, 2)));
				cal.add(Calendar.MINUTE, Integer.parseInt(retValue.duree.substring(2, 4)));
				retValue.fin = cal.getTime();
			} catch (ParseException e) {
				// Ne doit pas arriver ici car validation d�j� faite avec le XSD !
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur de format de date");
			} catch (NumberFormatException e) {
				// Ne doit pas arriver ici car validation d�j� faite avec le XSD !
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Erreur de format de date");
			}
		}
		return retValue;
	}

	/**
	 * Class utilitaire permettant de retourner les donn�es valoris�es par la m�thode <code>protected ParametreTypeUtil valoriserParametreTypes(RendezVous[] rendezVous, String idIntervention)</code>
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/02/2011</TD><TD>GPE</TD><TD>Correction de l'adaptateur EFB</TD></TR>
	 * </TABLE>
	 */
	protected static class ParametreTypeUtil {
		String observations = null;
		ParametreType parametreTypePresenceMIT = null;
		ParametreType parametreTypeActiv = null;
		ParametreType parametreTypeProd = null;
		boolean presenceERDV = false;
		String idIntervention = null;
	}

	/**
	 * M�thode permettant de valoriser les 'param�tres type' du rdv
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/02/2011</TD><TD>GPE</TD><TD>Correction de l'adaptateur EFB</TD></TR>
	 * </TABLE>
	 * 
	 * @param rendezVous
	 * le rendez-vous en provenance de la commande EFB
	 * @param idIntervention
	 * @return
	 */
	protected ParametreTypeUtil valoriserParametreTypes(RendezVous[] rendezVous, String idIntervention) {
		ParametreTypeUtil retValue = new ParametreTypeUtil();

		// Construction du champ observations (et de deux param�tres)
		// En effet, du temps que l'on est dans les crit�res, on en
		// profite pour construire deux param�tres d'intervention.
		CritereIdentificationRDV[] criteres = rendezVous[0].getCritereIdentificationRDV();
		String typeCritere;
		for (int i = 0; i < criteres.length; i++) {
			typeCritere = criteres[i].getTypeCritere();

			// Construction du champ observations
			retValue.observations = construireObservation(typeCritere, rendezVous[0].getMotifStatutRDV(), criteres[i].getValCritereSimple());

			if (StringUtils.isNotEmpty(criteres[i].getValCritereSimple())) {
				if (MIT_TYPE_CRITERE.equals(typeCritere)) {
					retValue.parametreTypePresenceMIT = new ParametreType();
					retValue.parametreTypePresenceMIT.setCle(ConstantesDynamicIntervention.INTERVENTION_PRESENCE_MIT);
					retValue.parametreTypePresenceMIT.setValeur(criteres[i].getValCritereSimple());
				} else if (ACTIVITE_GPC_TYPE_CRITERE.equals(typeCritere)) {
					retValue.parametreTypeActiv = new ParametreType();
					retValue.parametreTypeActiv.setCle(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
					retValue.parametreTypeActiv.setValeur(criteres[i].getValCritereSimple());
				} else if (PRODUIT_GPC_TYPE_CRITERE.equals(typeCritere)) {
					retValue.parametreTypeProd = new ParametreType();
					retValue.parametreTypeProd.setCle(ConstantesDynamicIntervention.INTERVENTION_PROD);
					retValue.parametreTypeProd.setValeur(criteres[i].getValCritereSimple());
				}
				// EV-000007 : si le RDV vient de ERDV, (CritereIdentificationRDV.TypeCritere= �Origine� Et
				// CritereIdentificationRDV.ValCritereSimple=�e-RDV�)
				// il faut decouper l'identifiant pour recuperer l'IdIntervention et les param�tres ACTIV et PROD
				// si ces donn�es sont renseign�es
				else if (ORIGINE_TYPE_CRITERE.equals(typeCritere)) {
					String ValCrit = criteres[i].getValCritereSimple();

					if (ERDV_VAL_CRITERE.equals(ValCrit)) {
						retValue.presenceERDV = true;
						retValue.idIntervention = ERDV_VALUE;
						retValue.parametreTypeActiv = new ParametreType();
						retValue.parametreTypeActiv.setCle(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
						retValue.parametreTypeActiv.setValeur(null);
						retValue.parametreTypeProd = new ParametreType();
						retValue.parametreTypeProd.setCle(ConstantesDynamicIntervention.INTERVENTION_PROD);
						retValue.parametreTypeProd.setValeur(null);
					} else {
						// decoupage de l'identifiant
						String[] tabIdIntervention = decouperIdentifiant(idIntervention);
						// le param�tre ACTIV correspond au premier champ s'il est renseign�
						retValue.parametreTypeActiv = valoriserParametreActifDuRdv(tabIdIntervention);
						// le param�tre PROD correspond au deuxi�me champ s'il est renseign�
						retValue.parametreTypeProd = valoriserParametreProdDuRdv(tabIdIntervention);
						// l'identifiant du RDV correspond au quatri�me champ s'il est renseign�
						retValue.idIntervention = valoriserIdentifiantDuRdv(tabIdIntervention);
					}
				}
			}
		}

		return retValue;
	}

	/**
	 * Valorise les champs Intervention (dans la commande),
	 * Op�ration programm�e et param�tres d'intervention (dans
	 * une ligne de commande). (R�gle RG9 dans la sp�cification)
	 * 
	 * @param commande La commande � valoriser
	 * @param ligneCde La ligne de commande � valoriser
	 * @param ligneCdeEFB La ligne de commande EFB � adapter
	 * @param valeurQT la valeur du questionnaire technique
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/01/2011</TD><TD>BPE</TD><TD>EV-000089: Prise en compte du statut "AGREGEE"</TD></TR>
	 * <TR><TD>26/01/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant sur l'adaptateur EFB</TD></TR>
	 * <TR><TD>18/02/2011</TD><TD>GPE</TD><TD>Correction de l'adaptateur EFB</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * </TABLE>
	 */
	@SuppressWarnings("null")
	protected void valoriserOpProgEtIntervention(bolbec.injection.xml.generated.Commande commande, LigneCommandeType ligneCde, LigneCde ligneCdeEFB, String valeurQT, String secondNdContact) throws ReceptionCdeException {
		String trAccesReseauBD = null;
		ProduitServiceSouhaite psSouhaite = ligneCde.getProduitServiceSouhaite();
		// si commande NSD+
		if (cmdAgregee) {
			// Valorisation des param�tres dynamiques PSS pour le cas des commandes PLP Fibre sans RDV
			if (psSouhaite != null) {
				for (ParametreType parametreCommande : commande.getParametresCommande()) {
					if (ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON.equals(parametreCommande.getCle()) && ConstantesDynamicCommande.PLP_SANS_RDV.equals(parametreCommande.getValeur())) {
						psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.OBSERVATIONS_EVENTUELLES, valeurQT));

						String centre = ligneCdeEFB.getPartageRessTechniques().getCentreRattachement();
						if (!StringUtils.isBlank(centre)) {
							psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.CENTRE_RATTACHEMENT, centre));
						}

						String zone = ligneCdeEFB.getPartageRessTechniques().getZoneRattachement();
						if (!StringUtils.isBlank(zone)) {
							psSouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.ZONE_RATTACHEMENT, zone));
						}

						return;
					}
				}
			}

			String refLigneCdeEFB = ligneCdeEFB.getRefLigneCde();
			// s'ils sont diff�rents, on sort
			if ((refLigneCdeEFB == null) || !refLigneCdeEFB.equals(refLigneCmdPrestRDV)) {
				return;
			}
		} else {
			// R�cup�ration de l'idOffre
			if (psSouhaite != null) {
				String idOffre = psSouhaite.getRefOffreCible();
				// V�rification de l'appartenance d'une offre pass�e en param�tre � une
				// familleoffrecom pass�e en param�tre (RG12)
				trAccesReseauBD = getAppartenanceOffreAFamilleOffre(idOffre, ConstantesTraduction.TRADUCTION_CLE_ACCES_RESEAU_BD);
			}
		}

		// SI TrAccesReseauBD existe et TrAccesReseauBD.ValeurArtemis = 'OUI'
		// Alors on est dans le cas de l�acc�s r�seau porteur.
		// Si on est bien sur l'acc�s r�seau BD
		// ou bien si l'on est dans le cas d'une commande agreg�e
		if (cmdAgregee || OUI.equals(trAccesReseauBD)) {
			// On v�rifie si il y a un rendez vous
			RendezVous[] rendezVous = ligneCdeEFB.getRendezVous();
			boolean isEfbRDV = (rendezVous != null) && (rendezVous.length > 0);
			if (isEfbRDV || (refRDV != null)) {
				// D�clarations des param�tres d'intervention qui seront
				// ajout�s dans la ligne de commande
				ParametreType parametreTypeActiv = null;
				ParametreType parametreTypeProd = null;
				ParametreType parametreTypeCentre = null;
				ParametreType parametreTypeZone = null;
				ParametreType parametreTypeCodeUI = null;
				ParametreType parametreTypeOrigineRdv = null;
				ParametreType parametreTypePresenceMIT = null;
				ParametreType parametreTypeSegma = null;
				ParametreType parametreTypeSecondNd = null;
				// R�cup�ration du champ IdIntervention
				String idIntervention = isEfbRDV ? rendezVous[0].getRefRDV() : "";
				// Calcul des dates de d�but et de fin
				RDVUtil rdvFormatter = null;
				String observations = null;
				boolean presenceERDV = false;
				if (isEfbRDV) {
					rdvFormatter = valoriserRDV(rendezVous);
					ParametreTypeUtil paramTypeValorise = valoriserParametreTypes(rendezVous, idIntervention);
					observations = paramTypeValorise.observations;
					parametreTypePresenceMIT = paramTypeValorise.parametreTypePresenceMIT;
					parametreTypeActiv = paramTypeValorise.parametreTypeActiv;
					parametreTypeProd = paramTypeValorise.parametreTypeProd;
					presenceERDV = paramTypeValorise.presenceERDV;
					if (paramTypeValorise.idIntervention != null) {
						idIntervention = paramTypeValorise.idIntervention;
					}
				} else {
					// Dans le cas d�une commande NSD+, les informations concernant le questionnaire technique vont �tre ajout�es dans ce champ :
					if (cmdAgregee && StringUtils.isNotEmpty(valeurQT)) {
						observations = valeurQT;
					}
				}

				if (cmdAgregee) {
					idIntervention = ERDV_VALUE;
					presenceERDV = true;
				}

				// Construction de deux param�tres d'intervention et
				PartageRessTechniques partageRessTechniques = ligneCdeEFB.getPartageRessTechniques();
				if (partageRessTechniques != null) {
					// Construction du param�tre parametreTypeCentre
					parametreTypeCentre = construireParametreTypeCentre(parametreTypeCentre, partageRessTechniques);
					// Construction du param�tre parametreTypeZone
					parametreTypeZone = construireParametreTypeZone(parametreTypeZone, partageRessTechniques);
				}
				// Construction du param�tre d'intervention parametreTypeCodeUI
				parametreTypeCodeUI = construireParametreIntervention(ligneCdeEFB, parametreTypeCodeUI);
				// Construction du param�tre d'intervention parametreTypeOrigineRdv
				parametreTypeOrigineRdv = construireParametreTypeOrigineRdv();
				// Construction du param�tre d'intervention parametreTypeSegma
				parametreTypeSegma = construireParametreTypeSegma(ligneCdeEFB, true);
				// Valoriser une intervention avec les donn�es suivantes
				Intervention intervention = valoriserDonneesIntervention(commande, rendezVous, idIntervention, rdvFormatter, observations, getReferenceRDVIntervention(presenceERDV, isEfbRDV ? rendezVous[0].getRefRDV() : ""));
				// Valorisation d'une op�ration programm�e
				valoriserOpProgrammee(ligneCde, idIntervention);
				// Valorisation du secondNd
				if (secondNdContact != null) {
					parametreTypeSecondNd = createParametre(ConstantesDynamicIntervention.NO_CONTACT_RDV, secondNdContact);
				}
				// Ajouts des param�tres d'intervention qui ont �t� d�finis
				// dans la ligne de commande
				if (parametreTypeActiv != null) {
					intervention.addParametre(parametreTypeActiv);
				}
				if (parametreTypeProd != null) {
					intervention.addParametre(parametreTypeProd);
				}
				if (parametreTypeCentre != null) {
					intervention.addParametre(parametreTypeCentre);
				}
				if (parametreTypeZone != null) {
					intervention.addParametre(parametreTypeZone);
				}
				if (parametreTypeCodeUI != null) {
					intervention.addParametre(parametreTypeCodeUI);
				}
				if (parametreTypePresenceMIT != null) {
					intervention.addParametre(parametreTypePresenceMIT);
				}
				intervention.addParametre(parametreTypeOrigineRdv);
				if (parametreTypeSegma != null) {
					intervention.addParametre(parametreTypeSegma);
				}
				if (parametreTypeSecondNd != null) {
					intervention.addParametre(parametreTypeSecondNd);
				}
			}
			// Aucun rendez-vous n'existe
			else {
				creerNouvelleIntervention(commande, ligneCde, ligneCdeEFB);
			}
		}
	}

	/**
	 * @param tabIdIntervention
	 * @return
	 */
	protected String valoriserIdentifiantDuRdv(String[] tabIdIntervention) {
		String idIntervention;
		if (tabIdIntervention.length > 3 && StringUtils.isNotEmpty(tabIdIntervention[3])) {
			idIntervention = tabIdIntervention[3];
		} else {
			// dans le cas d'un RDV venant de eRDV, remise � null de l'identifiant s'il n'est pas renseign�
			// sinon il garde la valeur lue par defaut dans l'IC EFB (rendezVous[0].getRefRDV())
			idIntervention = null;
		}
		return idIntervention;
	}

	/**
	 * @param tabIdIntervention
	 * @return
	 */
	private ParametreType valoriserParametreProdDuRdv(String[] tabIdIntervention) {
		ParametreType retValue = null;
		if (tabIdIntervention.length > 1 && StringUtils.isNotEmpty(tabIdIntervention[1])) {
			retValue = new ParametreType();
			retValue.setCle(ConstantesDynamicIntervention.INTERVENTION_PROD);
			retValue.setValeur(tabIdIntervention[1]);
		}
		return retValue;
	}

	/**
	 * @param tabIdIntervention
	 * @return
	 */
	protected ParametreType valoriserParametreActifDuRdv(String[] tabIdIntervention) {
		ParametreType retValue = null;
		if (tabIdIntervention.length > 0 && StringUtils.isNotEmpty(tabIdIntervention[0])) {
			retValue = new ParametreType();
			retValue.setCle(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
			retValue.setValeur(tabIdIntervention[0]);
		}
		return retValue;
	}

	/**
	 * @param idIntervention
	 * @return
	 */
	private String[] decouperIdentifiant(String idIntervention) {
		String tabIdIntervention[] = new String[5];
		if (idIntervention != null) {
			tabIdIntervention = idIntervention.split(TIRET_SEPARATEUR);
		}
		return tabIdIntervention;
	}

	/**
	 * @param commande
	 * @param ligneCde
	 * @param ligneCdeEFB
	 */
	protected void creerNouvelleIntervention(bolbec.injection.xml.generated.Commande commande, LigneCommandeType ligneCde, LigneCde ligneCdeEFB) {
		String etatResReutilisablesId = null;
		PartageRessTechniques partageRessTechniques = ligneCdeEFB.getPartageRessTechniques();
		if (partageRessTechniques != null) {
			etatResReutilisablesId = partageRessTechniques.getEtatResReutilisablesId();
		}
		// Si IC_EFB.EtatResReutilisablesId existe et est non vide (Cat�gorie de raccordement)
		if (StringUtils.isNotEmpty(etatResReutilisablesId)) {
			// Recherche de la valeurbolbec d'un enregistrement Tr de la
			// table TRADUCTION tel que :
			// - Tr.valeurexterne = IC_EFB.EtatResReutilisablesId
			// - Tr.cle = NATURE
			// - Tr.SystemeExterne = <<version>>_EFB
			String valeurbolbec = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.TRADUCTION_CLE_NATURE, etatResReutilisablesId);
			// Si Tr existe et Tr.ValeurArtemis=CLIENT
			if (ConstantesTraduction.CLIENT.equals(valeurbolbec)) {
				// Construction de l'idIntervention
				String idInstanceArtemisEtCounter = serviceManager.getGeneratorManager().generateKey();
				String idIntervention = "A" + DateUtils.format(DateUtils.getDate(), SHORT_DATE_FORMAT) + idInstanceArtemisEtCounter;
				// Valoriser une intervention avec les donn�es suivantes
				Intervention intervention = new Intervention();
				commande.addIntervention(intervention);
				intervention.setIdIntervention(idIntervention);
				intervention.setEtatIntervention(EtatInterventionConstantes.ARESERV);
				intervention.setMesc(NON_MESC);
				valoriserOpProgrammee(ligneCde, idIntervention);
			}
		}
	}

	/**
	 * M�thode permettant de valoriser les donn�es d'intervention
	 * 
	 * @param commande
	 * @param rendezVous
	 * @param idIntervention
	 * @param rdvFormatter
	 * @param observations
	 * @param RefeRDV
	 * @return
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>17/01/2011</TD><TD>BPE</TD><TD>EV-000089: Prise en compte du statut "AGREGEE"</TD></TR>
	 * <TR><TD>26/01/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant sur l'adaptateur EFB</TD></TR>
	 * <TR><TD>10/05/2011</TD><TD>BPE</TD><TD>EV-000151: Echec notifierModificationRDV erreur 006</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * <TR><TD>23/04/2012</TD><TD>BPE</TD><TD>EV-000198: Rejet des commandes EFB dont la dur�e d'intervention est non enti�re (Defect 25)</TD></TR>
	 * </TABLE>
	 */
	protected Intervention valoriserDonneesIntervention(bolbec.injection.xml.generated.Commande commande, RendezVous[] rendezVous, String idIntervention, RDVUtil rdvFormatter, String observations, String RefeRDV) {
		Intervention intervention = new Intervention();
		commande.addIntervention(intervention);
		intervention.setIdIntervention(idIntervention);
		intervention.setIdPlanCharge(idIntervention);
		intervention.setRefRDV(RefeRDV);
		// EV-000151: Echec notifierModificationRDV erreur 006
		Date dateActuelle = DateUtils.getNowDate();
		intervention.setDateReservation(DateUtils.format(dateActuelle, EFBConstantes.FORMAT_DATE_HEURE));
		if (rdvFormatter == null || rdvFormatter.debut == null) {
			if ((refRDV != null) && cmdAgregee) {
				intervention.setEtatIntervention(EtatInterventionConstantes.RESERV);
			}
		} else {
			// EV-000007 : Si la reference de RDV est valide (non null et renseign�e), positionner l'�tat � RESERV,
			// sinon, positionner l'�tat � PLANIF
			if (StringUtils.isNotEmpty(rendezVous[0].getRefRDV())) {
				intervention.setEtatIntervention(EtatInterventionConstantes.RESERV);
			} else {
				intervention.setEtatIntervention(EtatInterventionConstantes.PLANIF);
			}
			intervention.setDebutPlage(DateUtils.format(rdvFormatter.debut, EFBConstantes.FORMAT_DATE_HEURE));
			intervention.setFinPlage(DateUtils.format(rdvFormatter.fin, EFBConstantes.FORMAT_DATE_HEURE));
			intervention.setDuree(rdvFormatter.duree);
		}
		intervention.setObservations(observations);
		intervention.setMesc(NON_MESC);
		return intervention;
	}

	/**
	 * Convertit la dur�e du RDV au format HHMM (Cf RG9)
	 * 
	 * @param dureeRDV la dur�e du RDV au format (X.Y)
	 * @return la dur�e du RDV au format HHMM
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>23/04/2012</TD><TD>BPE</TD><TD>EV-000198: Rejet des commandes EFB dont la dur�e d'intervention est non enti�re (Defect 25)</TD></TR>
	 * </TABLE>
	 */
	protected String valoriserDureeIntervention(String dureeRDV) {

		// Valeur par d�faut retourn�e dans le cas d'une dureeRDV inexistante ou syntaxiquement incorrecte
		final String valeurDefaut = "0000";

		// Si la dur�e de RDV est inexistante, la valeur par d�faut est retourn�e
		if (dureeRDV == null) {
			return valeurDefaut;
		}

		// Pattern de correspondance avec la duree de RDV
		final Pattern pattern = Pattern.compile("^(\\d{1,2})(?:\\.(\\d{0,2})\\d*)?$");
		final Matcher matcher = pattern.matcher(dureeRDV);

		// Dans le cas d'une dur�e de RDV syntaxiquement incorrecte, la valeur par d�faut est retourn�e
		if (!matcher.matches()) {
			return valeurDefaut;
		}

		// Extraction des groupes � partir du pattern
		final String partieEntiereDureeRDV = matcher.group(1);
		final String partieDecimaleDureeRDV = matcher.group(2);

		// Initialisation de la dur�e de RDV convertie (valeur retourn�e)
		final StringBuilder dureeConvertie = new StringBuilder(4);

		// Ajout de l'heure dans la dur�e de RDV convertie
		final String heuresConverties = StringUtils.leftPad(partieEntiereDureeRDV, 2, "0");
		dureeConvertie.append(heuresConverties);

		final String minutesConverties;
		if (partieDecimaleDureeRDV != null) {
			// Dans le cas d'une dur�e de RDV non enti�re, on effectue la calcule des minutes
			final int minutes = Integer.parseInt(StringUtils.rightPad(partieDecimaleDureeRDV, 2, "0"));
			final String tmpMinutes = String.valueOf(minutes * 6 / 10);
			minutesConverties = StringUtils.leftPad(tmpMinutes, 2, "0");
		} else {
			// Dans le cas d'une dur�e de RDV enti�re, les minutes valent donc "00"
			minutesConverties = "00";
		}

		// Ajout des minutes dans la dur�e de RDV convertie
		dureeConvertie.append(minutesConverties);

		// Retourne la duree au format HHMM
		return dureeConvertie.toString();
	}

	/**
	 * @param ligneCde
	 * @param idIntervention
	 */
	protected void valoriserOpProgrammee(LigneCommandeType ligneCde, String idIntervention) {
		OperationProgrammee operationProgrammee = new OperationProgrammee();
		operationProgrammee.setIdIntervention(idIntervention);
		operationProgrammee.setTypeOp(TypeOpProgrammeeConstantes.INTERV_GLOBALE);
		ligneCde.addOperationProgrammee(operationProgrammee);
	}

	/**
	 * @return
	 */
	private ParametreType construireParametreTypeOrigineRdv() {
		ParametreType parametreTypeOrigineRdv;
		parametreTypeOrigineRdv = new ParametreType();
		parametreTypeOrigineRdv.setCle(ConstantesDynamicIntervention.INTERVENTION_ORIGINERDV);
		parametreTypeOrigineRdv.setValeur(ORIGINE_RDV_VAL_PARAM_INTERV);
		return parametreTypeOrigineRdv;
	}

	/**
	 * @param ligneCdeEFB
	 * @param tradSegma
	 * @return
	 */
	protected ParametreType construireParametreTypeSegma(LigneCde ligneCdeEFB, boolean tradSegma) {
		ClientDetenteur clientDetenteur = ligneCdeEFB.getClientDetenteur();
		ParametreType parametreTypeSegma = null;
		if (clientDetenteur != null) {
			String segmentation = clientDetenteur.getSegmentationMarcheCltDetenteur();
			if (segmentation != null) {
				parametreTypeSegma = new ParametreType();
				parametreTypeSegma.setCle(ConstantesDynamicIntervention.INTERVENTION_SEGMA);
				// Si la destination est externe, on ne traduit pas la segmentation
				if (tradSegma) {
					parametreTypeSegma.setValeur(serviceManager.getTraductionManager().getTraductionCatClientCatClientVersInterf(SystemeExterneConstantes.NUM_20Z, segmentation, segmentation));
				} else {
					parametreTypeSegma.setValeur(segmentation);
				}
			}
		}
		return parametreTypeSegma;
	}

	/**
	 * @param parametreTypeZone
	 * @param partageRessTechniques
	 * @return
	 */
	protected ParametreType construireParametreTypeZone(ParametreType parametreTypeZone, PartageRessTechniques partageRessTechniques) {
		String zoneRattachement = partageRessTechniques.getZoneRattachement();
		if (StringUtils.isNotEmpty(zoneRattachement)) {
			parametreTypeZone = new ParametreType();
			parametreTypeZone.setCle(ConstantesDynamicIntervention.INTERVENTION_ZONE);
			parametreTypeZone.setValeur(zoneRattachement);
		}
		return parametreTypeZone;
	}

	/**
	 * @param parametreTypeCentre
	 * @param partageRessTechniques
	 * @return
	 */
	protected ParametreType construireParametreTypeCentre(ParametreType parametreTypeCentre, PartageRessTechniques partageRessTechniques) {
		String centreRattachement = partageRessTechniques.getCentreRattachement();
		if (StringUtils.isNotEmpty(centreRattachement)) {
			parametreTypeCentre = new ParametreType();
			parametreTypeCentre.setCle(ConstantesDynamicIntervention.INTERVENTION_CENTRE);
			parametreTypeCentre.setValeur(centreRattachement);
		}
		return parametreTypeCentre;
	}

	/**
	 * @param ligneCdeEFB
	 * @param parametreTypeCodeUI
	 * @return
	 */
	protected ParametreType construireParametreIntervention(LigneCde ligneCdeEFB, ParametreType parametreTypeCodeUI) {
		EltOrgLivLC[] eltOrgLivLC = ligneCdeEFB.getEltOrgLivLC();
		for (int i = 0; i < eltOrgLivLC.length; i++) {
			if (StringUtils.isNotEmpty(eltOrgLivLC[i].getEquipeLivrLC())) {
				parametreTypeCodeUI = new ParametreType();
				parametreTypeCodeUI.setCle(ConstantesDynamicIntervention.INTERVENTION_UI);
				parametreTypeCodeUI.setValeur(eltOrgLivLC[i].getEquipeLivrLC());
			}
		}
		return parametreTypeCodeUI;
	}

	/**
	 * R�cup�re le type de d�bit de la commande (Haut Debit ou Bas D�bit)
	 * au format bolbec � partir de la commande EFB et de la commande
	 * Artemis en cours de construction (la RG14 doit �tre d�j� pass�e)
	 * (RG11 dans les sp�cifications).
	 * 
	 * @param commandeEFB the commande efb
	 * @param commandeArtemis the commande bolbec
	 * 
	 * @return Le type d�bit commande traduit en code bolbec
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169: Gestion du cas metier "RECR_Porta_SIP_Fibre"</TD></TR>
	 * </TABLE>
	 */
	protected String getTypeDebitCommande(Commande commandeEFB, bolbec.injection.xml.generated.Commande commandeArtemis) {
		String valeurbolbec = null;

		// R�cup�ration de IC_BOLBEC.commande.CasMetier
		String casMetier = commandeArtemis.getCasMetier();
		// Si THD
		if (CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.MO_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.RECR_FTTH.equals(casMetier)) {
			valeurbolbec = THD_TYPE_DEBIT_CMD;
		}
		// Sinon (BD ou HD ou PORTA)
		else if (CasMetierConstantes.RECR_PORTA_SIP_FIBRE.equals(casMetier)) {
			valeurbolbec = PORTA_TYPE_DEBIT_CMD;
		} else if (commandeEFB.getStatutOpCommande() != null) {
			String codeStatutOpCommande = commandeEFB.getStatutOpCommande().getCodeStatutOpCommande();
			valeurbolbec = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.TRADUCTION_CLE_TYPE_DEBIT_CMD, codeStatutOpCommande);
			// RG ANO 1
			if (StringUtils.isEmpty(valeurbolbec)) {
				throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION,
						"Erreur de traduction pour la cl� " + ConstantesTraduction.TRADUCTION_CLE_TYPE_DEBIT_CMD + ", la valeur externe " + codeStatutOpCommande + " et le systeme externe " + SystemeExterneConstantes.EFB);
			}
		}
		return valeurbolbec;
	}

	/**
	 * V�rification de l'appartenance d'une offre pass�e en param�tre �
	 * une familleoffrecom pass�e en param�tre (RG12).
	 * 
	 * @param paramIdOffre the param id offre
	 * @param paramFamille the param famille
	 * 
	 * @return String appartenance
	 */
	private String getAppartenanceOffreAFamilleOffre(String paramIdOffre, String paramFamille) {
		// R�cup�ration de l'offre et de la familleOffreCom de cette offre
		OffreDTO offreDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, paramIdOffre);
		FamilleOffreComDTO familleOffreComDTO = offreDTO.getFamilleOffreCom();
		// Nous allons maintenant v�rifier si la familleOffreCom est une familleOffreCom d�acc�s r�seau BD
		String externalValue = familleOffreComDTO.getValeurConstante();
		return serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_49W, paramFamille, externalValue);
	}

	/**
	 * Modification de l'offre pour l'acc�s r�seau bas d�bit CRISTAL si c'est une
	 * commande mixte. (RG13)
	 * 
	 * @param cdeEFB the cde efb
	 * @param cdeArtemis the cde bolbec
	 * @param paramFonctNotification the param fonct notification
	 * 
	 * @throws ReceptionCdeException the reception cde exception
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>28/02/2012</TD><TD>BPE</TD><TD>DE-000187: pas de code compl�ment et libell� sur CR EFB de type NENHD + type NENMIX non g�r�</TD></TR>
	 * </TABLE>
	 */
	private void modifOffrePourCommandeMixte(Commande cdeEFB, bolbec.injection.xml.generated.Commande cdeArtemis, Map<String, Object> paramFonctNotification) {
		// R�cup�rer le typeDebitCmd avec la RG11
		String typeDebitCmd = getTypeDebitCommande(cdeEFB, cdeArtemis);
		// Si typeDebitCmd <> (HD OU THD)
		if (!HD_TYPE_DEBIT_CMD.equals(typeDebitCmd) && !THD_TYPE_DEBIT_CMD.equals(typeDebitCmd) && !PORTA_TYPE_DEBIT_CMD.equals(typeDebitCmd)) {
			String idpremiereLC = null;
			// On va rechercher l'offre offreAboBD de la ligne de commande ayant
			// une familleoffrecom ABO_BD
			String idOffreAccesReseau = null;
			for (int j = 0; j < cdeArtemis.getInstanceOffreGroupeeCount(); j++) {
				InstanceOffreGroupee instanceOffreGroupee = cdeArtemis.getInstanceOffreGroupee(j);
				for (int i = 0; i < instanceOffreGroupee.getLigneCommandeCount(); i++) {
					LigneCommandeType ligneCde = instanceOffreGroupee.getLigneCommande(i);
					if (i == 0) {
						idpremiereLC = ligneCde.getIdLigneCommande();
					}
					// R�cup�rer lc_offre
					String lcOffre = ligneCde.getProduitServiceSouhaite().getRefOffreCible();
					// Appliquer la RG12 avec
					// - paramIdOffre = lc_Offre
					// - paramFamille = ABO_BD
					String trAboBD = getAppartenanceOffreAFamilleOffre(lcOffre, ConstantesTraduction.TRADUCTION_CLE_ABO_BD);
					// SI trAboBD renvoy� par la RG12 non nul est trAboBD.ValeurArtemis = OUI
					if (OUI.equals(trAboBD)) {
						OffreDTO offreAbonnementDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, lcOffre);
						// On va traduire l'abonnement en acc�s que l'on connait
						// (RTC_45R ou du NU_Retail_45R)
						String trOffreValArtemis = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_OFFRE_ACCES_BD_MIXTE,
								offreAbonnementDTO.getValeurConstante());
						if (StringUtils.isNotEmpty(trOffreValArtemis)) {
							// Rechercher OffreTraduite dans la table OFFRE tel que OffreTraduite.ValeurConstante = TrOffre.ValeurArtemis
							OffreDTO offreTraduiteDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, new Comparaison(Offre.FIELD_VALEUR_CONSTANTE, Constantes.OPERATOR_EQUAL, trOffreValArtemis),
									new Comparaison(Offre.FIELD_VERSION, Constantes.OPERATOR_EQUAL, Constantes.VERSION));
							// SI OffreTraduite non nulle
							if (offreTraduiteDTO != null) {
								idOffreAccesReseau = offreTraduiteDTO.getId();
								serviceManager.getLoggerManager().finest(CLASSNAME, "modifOffrePourCommandeMixte", "idOffreAccesReseau=" + idOffreAccesReseau);
							}
							// RG ANO 1
							else {
								paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, ligneCde.getIdLigneCommande());
								throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Anomalie traduction aucune offre acc�s r�seau \"" + trOffreValArtemis + "\" pour l'abonnement");
							}
						}
						// RG ANO 1
						else {
							paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, ligneCde.getIdLigneCommande());
							throw new ReceptionCdeException(AnomalieConstantes.ERREUR_TRADUCTION, "Anomalie traduction abonnement vers acc�s r�seau");
						}
						// Sortir de la boucle
						break;
					}
				}
			}
			// SI offreAccesReseau <> null
			if (StringUtils.isNotEmpty(idOffreAccesReseau)) {
				// On recherche la commande correspondant � l'acc�s r�seau ie faisant
				// partie de la familleoffrecom ACCES_RESEAU_BD
				boolean accesReseauBDTrouve = false;
				for (int j = 0; j < cdeArtemis.getInstanceOffreGroupeeCount(); j++) {
					InstanceOffreGroupee instanceOffreGroupee = cdeArtemis.getInstanceOffreGroupee(j);
					for (int i = 0; i < instanceOffreGroupee.getLigneCommandeCount(); i++) {
						// R�cup�rer lc_offre = Ligne de Commande.Produit ou Service souhait�.
						// R�f�rence Offre cible
						LigneCommandeType ligneCdeTmp = instanceOffreGroupee.getLigneCommande(i);
						String lc_offre = ligneCdeTmp.getProduitServiceSouhaite().getRefOffreCible();
						// Appliquer la RG12 avec
						// - paramIdOffre = lc_Offre
						// - paramFamille = ACCES_RESEAU_BD
						String trAccesReseauBD = getAppartenanceOffreAFamilleOffre(lc_offre, ConstantesTraduction.TRADUCTION_CLE_ACCES_RESEAU_BD);
						// SI trAccesReseauBD renvoy� par la RG12 non nul est
						// trAccesReseauBD.ValeurArtemis = OUI
						if (OUI.equals(trAccesReseauBD)) {
							// Alors la ligne porte bien l'acc�s r�seau, il faut remplacer son
							// offre par l'offre r�elle d�termin�e � partir de l'abonnement
							accesReseauBDTrouve = true;
							ligneCdeTmp.getProduitServiceSouhaite().setRefOffreCible(idOffreAccesReseau);
							break;
						}
					}
				}
				// RG ANO 1
				if (!accesReseauBDTrouve) {
					paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, idpremiereLC);
					throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Toute commande bas d�bit CRISTAL doit avoir une offre de type acc�s r�seau BD");
				}
			}
			// RG ANO 1
			else {
				paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, idpremiereLC);
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Toute commande bas d�bit CRISTAL doit avoir une et une seule offre de type abonnement");
			}
		}
		// Verrue pour propagation du champ dynamic lignecommande CHGT_ND sur
		// toute les lignes de commandes de cr�ation ainsi que l'IdRessourceReutilisable
		propagationParametreLivraisonCHGTND(cdeArtemis);
	}

	/**
	 * Verrue pour propagation du champ dynamic lignecommande CHGT_ND sur
	 * toute les lignes de commandes de cr�ation.
	 * 
	 * @param cdeArtemis the cde bolbec
	 */
	private void propagationParametreLivraisonCHGTND(bolbec.injection.xml.generated.Commande cdeArtemis) {
		final String method = "propagationParametreLivraisonCHGTND";
		String idResReutilisableValue = null;
		// POUR chaque IC_Art�mis.Commande.Instance_Offre_Group�e.
		for (int j = 0; j < cdeArtemis.getInstanceOffreGroupeeCount(); j++) {
			InstanceOffreGroupee instanceOffreGroupee = cdeArtemis.getInstanceOffreGroupee(j);
			// POUR chaque Instance_Offre_Group�e.Ligne_de_Commande
			for (int i = 0; i < instanceOffreGroupee.getLigneCommandeCount(); i++) {
				LigneCommandeType ligneCde = instanceOffreGroupee.getLigneCommande(i);
				// POUR chaque Ligne_de_Commande.Param�tre livraison Ligne de commande
				for (int k = 0; k < ligneCde.getParametreLivraisonCount(); k++) {
					ParametreType param = ligneCde.getParametreLivraison(k);
					// Si on trouve la cl� = "IdRessourceReutilisable", r�cup�rer sa valeur
					if (EFBConstantes.ID_RES_REUTILISABLE.equals(param.getCle())) {
						idResReutilisableValue = param.getValeur();
					}
				}
			}
		}

		// EV-000039: Retour arri�re sur le marquage des lignes de commandes avec la suppression de la donn�e CHGT_ND

		// POUR chaque IC_Art�mis.Commande.Instance_Offre_Group�e.
		for (int j = 0; j < cdeArtemis.getInstanceOffreGroupeeCount(); j++) {
			InstanceOffreGroupee instanceOffreGroupee = cdeArtemis.getInstanceOffreGroupee(j);
			// POUR chaque Instance_Offre_Group�e.Ligne_de_Commande
			for (int i = 0; i < instanceOffreGroupee.getLigneCommandeCount(); i++) {
				LigneCommandeType ligneCde = instanceOffreGroupee.getLigneCommande(i);

				// Ajouter un Parametrelivraison Ligne de commande avec la cl� IdRessourceReutilisable
				// Et la valeur de idResReutilisable (bien tester qu'on a une valeur non null avant de stocker)
				ajouterParamLiv(method, ligneCde, EFBConstantes.ID_RES_REUTILISABLE, idResReutilisableValue);

			}
		}
	}

	/**
	 * Nouvel algo qui valorise le cas m�tier (pour du FTTH) lorsqu'une occurence correspondante existe dans la table "TRADUCTION".
	 * Sinon utilise l'ancienne m�thode.
	 * 
	 * @param commandeArtemis
	 * @param a_commandeEFB
	 * @return True, si le cas m�tier a �t� valoris� ou si aucune correspondance n'a �t� trouv�.
	 * False, si l'ancien algo de valorisation doit �tre appel�.
	 */
	protected boolean valoriserCasMetierFTTH(bolbec.injection.xml.generated.Commande commandeArtemis, Commande a_commandeEFB) {
		String methode = "valoriserCasMetierFTTH";
		for (LigneCde ligneCde : a_commandeEFB.getLigneCde()) {
			String codeOffrePSS = ligneCde.getCodeOffrePSS();
			if (!StringUtils.isEmpty(codeOffrePSS)) {
				// R�cup�re la liste des offres du cas m�tier en base
				List<String> listeOffres = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, EFBConstantes.DET_CAS_METIER_EFB, Constantes.CST_OUI);
				if (!listeOffres.isEmpty()) {
					// Recherche d'une correspondance
					for (String offreBase : listeOffres) {
						if (codeOffrePSS.equals(offreBase)) {
							// Correspondance trouv�e : on valorise le cas m�tier avec le nouvel algo
							String motifCommande = a_commandeEFB.getMotifCommande();
							String valeurExterne = motifCommande + "|" + ligneCde.getRefOpCommercialeLPA();
							String casMetier = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, EFBConstantes.CASMETIER_EFB, valeurExterne);
							if (!StringUtils.isEmpty(casMetier)) {
								// Ligne correspondante trouv�e, valorisation du cas m�tier
								commandeArtemis.setCasMetier(casMetier);
								serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Cas m�tier prioritaire : " + casMetier + "valoris� sur la commande Artemis.");
								return true;
							}
							valeurExterne = "*|" + ligneCde.getRefOpCommercialeLPA();
							casMetier = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, EFBConstantes.CASMETIER_EFB, valeurExterne);
							if (!StringUtils.isEmpty(casMetier)) {
								// Ligne correspondante non-prioritaire trouv�e, valorisation du cas m�tier
								commandeArtemis.setCasMetier(casMetier);
								serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Cas m�tier non-prioritaire : " + casMetier + "valoris� sur la commande Artemis.");
								return true;
							}
							// Si pas de correspondance, on quitte le RG sans valoris� le cas m�tier
							return true;
						}
					}
				}
			}
		}
		// Cas o� l'ancien algo va �tre utilis�
		return false;
	}

	/**
	 * RG14
	 * M�thode permettant de calculer le cas m�tier en fonction des lignes de commande EFB
	 * Ce traitement met � jour le boolean casMetierValoriser � TRUE pour ne pas
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>29/03/2011</TD><TD>GPA</TD><TD>Qualif MOE G7R6C1 (Defect 10): casMetierOK=true uniquement si le cas m�tier est positionn�</TD></TR>
	 * <TR><TD>06/06/2011</TD><TD>GPA</TD><TD>EV-000136: gestion des cas m�tiers de Migration Voix Entreprise</TD></TR>
	 * </TABLE>
	 * 
	 * @param commandeArtemis La commande bolbec � m�ttre � jour (Cas m�tier)
	 * @param idOffreArtemis L'identifiant de l'offre
	 * @param a_commandeEFB La commande au sens EFB
	 * @param paramFonctNotification Les param�tres fonctionnels de la notification
	 */
	protected void valoriserCasMetierLivraison(bolbec.injection.xml.generated.Commande commandeArtemis, String idOffreArtemis, Commande a_commandeEFB, Map<String, Object> paramFonctNotification) {

		if (!casMetierOK) {

			String motifCommande = a_commandeEFB.getMotifCommande();

			// Le nom de la m�thode � utiliser dans les logs
			final String nomMethode = "valoriserCasMetierLivraison";

			// Log de d�but
			serviceManager.getLoggerManager().finest(CLASSNAME, nomMethode, "D�but, commande bolbec=" + commandeArtemis.getIdCommande() + ", idOffreArtemis=" + idOffreArtemis);

			// Nouvel algo valorisant le cas m�tier
			casMetierOK = valoriserCasMetierFTTH(commandeArtemis, a_commandeEFB);

			// D�termination du cas m�tier en fonction du contexte
			// ------------------------------------------------------
			if (estContexte(idOffreArtemis, ConstantesTraduction.CONTEXTE_FTTH, ConstantesTraduction.FTTH) && (!casMetierOK)) {
				// Si contexte FTTH
				// Appel de l'algo "historique"
				determinerCasMetierForContexteFTTH(commandeArtemis, a_commandeEFB, paramFonctNotification);
				// Mise � jour du boolean pour indiquer que le traitement est effectu�
				casMetierOK = true;
			} else if (estContexte(idOffreArtemis, ConstantesTraduction.CONTEXTE_FSIP, ConstantesTraduction.FSIP) && (!casMetierOK)) {
				// Si contexte FSIP
				determinerCasmetierForContextePortaSIPFibre(commandeArtemis, a_commandeEFB);
				// Mise � jour du boolean pour indiquer que le traitement est effectu�
				casMetierOK = true;
			}

			// EV-000039: Cas retour net vers RTC
			if (!casMetierOK) {
				determinerCasMetierRetourNetVersRTC(commandeArtemis, motifCommande);
			}

			// EV-000348 : Net commande unique
			determinerCasMetierDemenagementAvecChangementND(a_commandeEFB, commandeArtemis);
		}

		// Log de fin
		serviceManager.getLoggerManager().finest(CLASSNAME, "valoriserCasMetierLivraison", LABEL_FIN_METHODE);

	}

	/**
	 * M�thode permettant de v�rifier le contexte d'une commande
	 * 
	 * @param idOffreArtemis L'identifiant de l'offre bolbec
	 * @param contexte Le contexte
	 * @param contexteTrad La valeur traduite du contexte (Utilis� pour la comparaison)
	 * @return true si la commande est dans le contexte, false sinon
	 */
	protected boolean estContexte(String idOffreArtemis, String contexte, String contexteTrad) {

		OffreDTO offreDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, idOffreArtemis);
		if (offreDTO != null && offreDTO.getFamilleOffreCom() != null) {

			// Traduction de l'offre
			String familleOffreCom = offreDTO.getFamilleOffreCom().getId();
			String traduction = serviceManager.getTraductionManager().getTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, contexte, familleOffreCom);

			return contexteTrad.equals(traduction);
		}

		return false;

	}

	/**
	 * Permet de rechercher le cas m�tier si le contexte est FTTH
	 * 
	 * @param commandeArtemis la commande bolbec
	 * @param a_commandeEFB La commande EFB
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160 - BOLBEC-2009 : KO �ligibilit� Parsifal 42C</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169: Gestion du cas metier "RECR_FTTH"</TD></TR>
	 * </TABLE>
	 */
	protected void determinerCasMetierForContexteFTTH(bolbec.injection.xml.generated.Commande commandeArtemis, Commande a_commandeEFB, Map<String, Object> paramFonctNotification) {
		String methode = "determinerCasMetierForContexteFTTH";
		List<String> lCodeOffreLcAIGNORER = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.LC_A_IGNORER, ConstantesTraduction.OUI);
		LigneCde[] tabLcEfb = a_commandeEFB.getLigneCde();
		LigneCde premiereLigneCdeSu = null;
		// Initialisation des compteurs
		int nbCR = 0;
		int nbSU = 0;

		// Parcours des lignes de commande EFB
		for (LigneCde lcEfb : tabLcEfb) {
			if (!(StringUtils.equals(lcEfb.getStatutOperationnel().getCodeStatutOperation(), EFBConstantes.STATUT_OP_LC_INCONNU) && (lCodeOffreLcAIGNORER.contains(lcEfb.getCodeOffrePSS())))) {
				// R�cup�ration de la valeur EFB (CR, SU, MO, IN1, IN2)
				String valEfb = lcEfb.getRefOpCommercialeLPA();
				if (valEfb != null) {

					// Traduction en valeur bolbec (CR, SU, MO, EQUALS) - IRMA_27
					String valArtemis = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, EFBConstantes.KEY_CODE_ACTION, valEfb);
					if (valArtemis != null) {

						// Incr�ment des compteurs en fonction des cas
						if (Arrays.asList("CR", "MO", "EQUALS").contains(valArtemis)) {
							nbCR++;
						}
						if (Arrays.asList("SU", "MO", "EQUALS").contains(valArtemis)) {
							nbSU++;

							if (premiereLigneCdeSu == null) {
								premiereLigneCdeSu = lcEfb;
							}
						}
					}
				}
			}
		}

		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Nbre de ligne de cr�ation : " + nbCR);
		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Nbre de ligne de suppression : " + nbSU);

		// Analyse des compteurs pour d�terminer le cas m�tier de la commande
		if (nbSU == 0) {
			if (isMotifPotentielRecreation(a_commandeEFB)) {
				commandeArtemis.setCasMetier(CasMetierConstantes.RECR_FTTH);
			} else {
				commandeArtemis.setCasMetier(CasMetierConstantes.CR_FTTH);
			}
		} else {
			if (isMotifPotentielRecreation(a_commandeEFB)) {
				// Dans le cas d�une commande KOLIV, toutes les lignes de commande doivent �tre de cr�ation
				// Appel RG_ANO1
				if (premiereLigneCdeSu != null) {
					paramFonctNotification.put(DeleguePublicationEfb.CLE_LIGNE_CDE_ERREUR, premiereLigneCdeSu.getRefLigneCde());
				}
				throw new ReceptionCdeException(AnomalieConstantes.CONTENU_ICEFB, "Dans le cas d�une commande � KOLIV �, toutes les lignes de commande doivent �tre de cr�ation.");
			}
			if (nbCR == 0) {
				commandeArtemis.setCasMetier(CasMetierConstantes.SU_FTTH);
			} else {
				commandeArtemis.setCasMetier(CasMetierConstantes.MO_FTTH);
			}
		}
	}

	/**
	 * Permet de rechercher le cas m�tier si le contexte est FSIP
	 * 
	 * @param commandeArtemis la commande bolbec
	 * @param a_commandeEFB La commande EFB
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>27/07/2011</TD><TD>BPE</TD><TD>EV-000160 - BOLBEC-2009 : KO �ligibilit� Parsifal 42C</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169: Gestion du cas metier "RECR_Porta_SIP_Fibre"</TD></TR>
	 * </TABLE>
	 */
	protected void determinerCasmetierForContextePortaSIPFibre(bolbec.injection.xml.generated.Commande commandeArtemis, Commande a_commandeEFB) {
		String methode = "determinerCasmetierForContextePortaSIPFibre";

		LigneCde[] tabLcEfb = a_commandeEFB.getLigneCde();

		// Initialisation des compteurs
		int nbCR = 0;
		int nbSU = 0;

		// Parcours des lignes de commande EFB
		for (LigneCde lcEfb : tabLcEfb) {

			// R�cup�ration de la valeur EFB
			String valEfb = lcEfb.getRefOpCommercialeLPA();
			if (valEfb != null) {

				// Traduction en valeur bolbec (CR, SU, MO, EQUALS)
				String valArtemis = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, EFBConstantes.KEY_CODE_ACTION, valEfb);
				if (valArtemis != null) {

					// Incr�ment des compteurs en fonction des cas
					if ("CR".equals(valArtemis)) {
						nbCR++;
					} else if ("SU".equals(valArtemis)) {
						nbSU++;
					}

				}
			}
		}

		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Nbre de ligne de cr�ation : " + nbCR);
		serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Nbre de ligne de suppression : " + nbSU);

		if (nbCR > 0) {
			if (GestionMetierKOLIV.CLE_KOLIV.equals(a_commandeEFB.getMotifCommande())) {
				commandeArtemis.setCasMetier(CasMetierConstantes.RECR_PORTA_SIP_FIBRE);
			} else {
				commandeArtemis.setCasMetier(CasMetierConstantes.CR_PORTA_SIP_FIBRE);
			}
		} else {
			commandeArtemis.setCasMetier(CasMetierConstantes.SU_PORTA_SIP_FIBRE);
		}

	}

	/**
	 * Permet de rechercher si le cas m�tier est Retour Net vers RTC et le positionner sur la commande
	 * 
	 * @param commandeArtemis la commande adapt�e au format Artemis
	 * @param motifCommande le motif de la commande dans l'IC EFB
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>06/06/2011</TD><TD>GPA</TD><TD>EV-000136: extraction de la m�thode</TD></TR>
	 * </TABLE>
	 */
	protected void determinerCasMetierRetourNetVersRTC(bolbec.injection.xml.generated.Commande commandeArtemis, String motifCommande) {
		String valTraduite = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.TRADUCTION_CLE_MOTIFCDECASMETIER, motifCommande);
		if (valTraduite != null) {
			commandeArtemis.setCasMetier(CasMetierConstantes.RETOUR_RTC_AVEC_OU_SANS_HD);
			// Mise � jour du boolean pour indiquer que le traitement est effectu�
			casMetierOK = true;
		}
	}

	/**
	 * Permet de rechercher si le cas m�tier un d�m�nagement avec changement de ND
	 * 
	 * @param commandeArtemis la commande adapt�e au format Artemis
	 */
	protected void determinerCasMetierDemenagementAvecChangementND(Commande commandeEfb, bolbec.injection.xml.generated.Commande commandeArtemis) {
		final String method = "determinerCasMetierDemenagementAvecChangementND";

		// Le contexte livraison n'�tant pas encore fix� (RG19), on anticipe ce traitement
		// Le code ne colle donc pas du tout avec la spec...
		List<String> traductions = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_PARAM_DYN_CDE_RESIL_ANC_ADR,
				ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON + "|" + ConstantesDynamicCommande.RESIL_ANC_ADR);

		// On v�rifie que la liste n'est pas vide
		if (traductions.isEmpty()) {
			serviceManager.getLoggerManager().info(CLASSNAME, method, "Aucune ligne trouv�e dans la table TraductionCatCom avec pour cl� " + ConstantesTraduction.CLE_PARAM_DYN_CDE_RESIL_ANC_ADR + " et valeur art�mis "
					+ ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON + "|" + ConstantesDynamicCommande.RESIL_ANC_ADR);
			return;
		}

		// On v�rifique que chaque traduction correspond � la commande, si c'est pas le cas, on sort de la m�thode !
		for (String traduction : traductions) {
			if (getValeurFonctionPSSCorrespondantATraduction(commandeEfb, traduction) == null) {
				serviceManager.getLoggerManager().fine(CLASSNAME, method, "La traduction " + traduction + " ne correspond pas avec la commande. On ne force PAS le cas m�tier � " + CasMetierConstantes.DEMGT_AVEC_CHGT_ND);
				return;
			}
		}

		// On v�rifie que la commande n'a pas d'offre internet fibre, si c'est le cas, on sort de la m�thode !
		List<String> offresInternetFibre = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, EFBConstantes.DET_CAS_METIER_EFB_INTERNET_FIBRE, Constantes.CST_OUI);
		for (LigneCde ligneCdeEfb : commandeEfb.getLigneCde()) {
			String codeOffrePSS = ligneCdeEfb.getCodeOffrePSS();
			if (!StringUtils.isBlank(codeOffrePSS) && offresInternetFibre.contains(codeOffrePSS)) {
				serviceManager.getLoggerManager().fine(CLASSNAME, method, "La commande poss�de l'offre internet fibre " + codeOffrePSS + ". On ne force PAS le cas m�tier � " + CasMetierConstantes.DEMGT_AVEC_CHGT_ND);
				return;
			}
		}

		// For�age du cas m�tier et mise � jour du boolean pour indiquer que le traitement est effectu�
		serviceManager.getLoggerManager().fine(CLASSNAME, method, "For�age du cas m�tier � " + CasMetierConstantes.DEMGT_AVEC_CHGT_ND);
		commandeArtemis.setCasMetier(CasMetierConstantes.DEMGT_AVEC_CHGT_ND);
		casMetierOK = true;
	}

	/**
	 * RG16 : Mise a jour des identifiant d'acces client et identifiant EPCommercial
	 * (Les RG10 et RG14 doivent �tre appel�es avant la RG16)
	 * 
	 * @param eltParcAffecte
	 * @param commande
	 * @param ligneCdeEFB
	 * @param typeDebitCommande
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169: Gestion du cas metier "RECR_FTTH"</TD></TR>
	 * <TR><TD>12/02/2013</TD><TD>EBA</TD><TD>G8R2C1 : Correction NPE trouv� par hasard</TD></TR>
	 * </TABLE>
	 */
	protected void majIdAccesClientEtIdEPCommercial(ElementParcAffecte eltParcAffecte, bolbec.injection.xml.generated.Commande commande, LigneCde ligneCdeEFB, String typeDebitCommande, String codeActionArtemis) {

		// Dans le cas d�une commande de cas m�tier � RECR_FTTH �, l�IC EFB ne portera pas d�informations sur le parc existant et donc pas d�EltParcImpactLC.
		// Dans ce cas, les identifiants d�EPC et d�acc�s client sont valoris�es depuis l�EltParcCreeLC

		if (!PORTA_TYPE_DEBIT_CMD.equals(typeDebitCommande)) {
			if (CasMetierConstantes.RECR_FTTH.equals(commande.getCasMetier())) {
				EltParcCreeLC eltParcCreeEFB = ligneCdeEFB.getEltParcCreeLC();
				if (eltParcCreeEFB != null) {
					eltParcAffecte.setIdAccesClient(eltParcCreeEFB.getNDARPorteur());
					eltParcAffecte.setIdEPC(eltParcCreeEFB.getRefEltParc());
				}
			} else if (TypeOpPonctuellesConstantes.DENUM.equals(codeActionArtemis)) {
				// EV-442 D�num�rotation
				EltParcImpacteLC eltParcImpacteEFB = ligneCdeEFB.getEltParcImpacteLC();
				if (eltParcImpacteEFB != null) {
					eltParcAffecte.setIdAccesClient(eltParcImpacteEFB.getNDARPorteurAncien());
					eltParcAffecte.setIdEPC(eltParcImpacteEFB.getRefEltParc());
				}
			} else {
				EltParcImpacteLC eltParcImpacteEFB = ligneCdeEFB.getEltParcImpacteLC();
				if (eltParcImpacteEFB != null) {
					eltParcAffecte.setIdAccesClient(eltParcImpacteEFB.getNDARPorteur());
					eltParcAffecte.setIdEPC(eltParcImpacteEFB.getRefEltParc());
				}
			}
		} else {
			// PortaSIP
			eltParcAffecte.setIdAccesClient(ndConserve);
			eltParcAffecte.setIdEPC(ndConserve);
		}
	}

	/**
	 * RG17 : Recupere la traduction de l'offre pour l'IC Artemis et met � jour l'offre de la ligne de commande pass� en param�tre
	 * 
	 * @param lcArtemis La ligne de commande qu'il faut utiliser pour traduire l'offre
	 * @return La r�f�rence de l'offre traduite
	 */
	protected String traductionOffre(LigneCommandeType lcArtemis) {

		// Log de d�but
		serviceManager.getLoggerManager().fine(CLASSNAME, "traductionOffre", "Debut: idLigneCommande=" + lcArtemis.getIdLigneCommande() + " | typePorta=" + typePorta);

		String traduction = null;

		// Si c'est un cas de PORTA_SIP (La m�thode valoriserTypePorta(...) valorise cette valeur)
		if (StringUtils.isNotEmpty(typePorta)) {

			// Traduction de l'offre
			traduction = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_TRAD_OFFRE_FSIP, typePorta);
			if (StringUtils.isNotEmpty(traduction)) {

				// Mise � jour de l'offre de la ligne de commande en fonction du type d'op�ration ponctuelle
				if (SensEvolution.SU.toString().equals(lcArtemis.getRefOperationPonctuelle())) {
					lcArtemis.getElementParcAffecte().setRefOffreExistante(traduction);
					serviceManager.getLoggerManager().finest(CLASSNAME, "traductionOffre", "L'offre de l'element parc affecte est valoris�e � : " + traduction);
				} else {
					if (SensEvolution.CR.toString().equals(lcArtemis.getRefOperationPonctuelle())) {
						lcArtemis.getProduitServiceSouhaite().setRefOffreCible(traduction);
						serviceManager.getLoggerManager().finest(CLASSNAME, "traductionOffre", "L'offre cible du produit service souhaite est valoris�e � : " + traduction);
					}
				}
			}
		}

		// Log de fin
		serviceManager.getLoggerManager().fine(CLASSNAME, "traductionOffre", LABEL_FIN_METHODE);

		// La tradcution de l'offre pour la ligne de commande
		return traduction;
	}

	/**
	 * M�thode permettant de valoriser offreArtemis principalement dans le cas Porta
	 * On v�rifie alors toutes les lignes de commandes
	 * 
	 * @param commandeEFB
	 */
	protected void valoriserOffreArtemisPourCasMetier(Commande commandeEFB) {
		final String methodName = "valoriserOffreArtemisPourCasMetier";

		String traduction = "";

		int nbligne = commandeEFB.getLigneCdeCount();
		for (int i = 0; i < nbligne; i++) {
			LigneCde ligneCdeEFB = commandeEFB.getLigneCde(i);
			// V�rification du calcul du type de portabilit� (Ne pas le refaire si c'est d�ja fait)
			if (!typeValoriserOffre) {

				// valorisation du Type de Portabilite
				ValeurFonctionPSS[] fonctionsPSS = ligneCdeEFB.getValeurFonctionPSS();
				for (ValeurFonctionPSS fonctionPSS : fonctionsPSS) {
					String valExterne = ligneCdeEFB.getCodeOffrePSS() + PIPE_SEPARATEUR + fonctionPSS.getRefFonctionPSS() + PIPE_SEPARATEUR + fonctionPSS.getValeurFonctionPSS();

					traduction = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_TYPE_PORT_FSIP, valExterne);

					if (StringUtils.isNotEmpty(traduction)) {
						break;
					}
				}

				// Log de d�but

				// Si c'est un cas de PORTA_SIP (La m�thode valoriserTypePorta(...) valorise cette valeur)
				if (StringUtils.isNotEmpty(traduction)) {

					// Traduction de l'offre
					offreArtemis = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_TRAD_OFFRE_FSIP, traduction);
					typeValoriserOffre = true;
				}

				// Log de fin
				serviceManager.getLoggerManager().fine(CLASSNAME, methodName, LABEL_FIN_METHODE);
			}
		}

	}

	/**
	 * 
	 * @param ligneCdeEFB
	 */
	protected void traduireOffrePortaSIP(LigneCde ligneCdeEFB) {

		final String methodName = "traduireOffrePortaSIP";

		// V�rification du calcul du type de portabilit� (Ne pas le refaire si c'est d�ja fait)
		if (!typePortaOK) {

			// Log de debut
			serviceManager.getLoggerManager().fine(CLASSNAME, "valoriserTypePorta", "Debut");

			// valorisation du Type de Portabilite
			ValeurFonctionPSS[] fonctionsPSS = ligneCdeEFB.getValeurFonctionPSS();
			for (ValeurFonctionPSS fonctionPSS : fonctionsPSS) {
				String valExterne = ligneCdeEFB.getCodeOffrePSS() + PIPE_SEPARATEUR + fonctionPSS.getRefFonctionPSS() + PIPE_SEPARATEUR + fonctionPSS.getValeurFonctionPSS();

				String valTraduite = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_TYPE_PORT_FSIP, valExterne);

				if (StringUtils.isNotEmpty(valTraduite)) {
					typePorta = valTraduite;
					break;
				}
			}

			if (StringUtils.isNotEmpty(typePorta)) {
				typePortaOK = true;
			}

			// Log de fin
			serviceManager.getLoggerManager().fine(CLASSNAME, methodName, LABEL_FIN_METHODE);
		}
	}

	/**
	 * Fonction permettant de retrouver la reference RDV de la commande EFB (si elle existe)
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>10/03/2011</TD><TD>BPE</TD><TD>R�cup�ration de la r�f�rence RDV via la valeurFonctionSimplePSS</TD></TR>
	 * </TABLE>
	 * 
	 * @param ligneCdeEFB
	 */
	protected void getReferenceRDV(LigneCde ligneCdeEFB) {
		final String methodName = "getReferenceRDV";
		// Log de debut
		serviceManager.getLoggerManager().fine(CLASSNAME, methodName, "Debut");

		// V�rification du calcul du type de portabilit� (Ne pas le refaire si c'est d�ja fait)
		if (!refRDVOK) {
			// valorisation du ref RDV
			ValeurFonctionPSS[] fonctionsPSS = ligneCdeEFB.getValeurFonctionPSS();
			for (ValeurFonctionPSS fonctionPSS : fonctionsPSS) {
				String valTraduite = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.TRADUCTION_CLE_REF_RDV, fonctionPSS.getRefFonctionPSS());

				if (StringUtils.isNotEmpty(valTraduite)) {
					refRDV = fonctionPSS.getValeurFonctionSimplePSS();
					if (refRDV != null) {
						refRDV = refRDV.toUpperCase();
					}
					refLigneCmdPrestRDV = ligneCdeEFB.getRefLigneCde();
					refRDVOK = true;
					break;
				}
			}
		}

		// Log de fin
		serviceManager.getLoggerManager().fine(CLASSNAME, methodName, LABEL_FIN_METHODE);
	}

	/**
	 * RG19 - Valorisation du param�tre Commande
	 * EV-000060 - Migration Fibre H323 vers Fibre SIP
	 * 
	 * @param commandeArtemis la commande au sens Art�mis
	 * @param commandeEfb la commande au sens EFB
	 * @author alegros
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>09/06/2011</TD><TD>GPA</TD><TD>Correction de l'algorithme de valorisation commande</TD></TR>
	 * <TR><TD>09/03/2012</TD><TD>GPA</TD><TD>EV-000169: Gestion du cas metier "RECR_Porta_SIP_Fibre"</TD></TR>
	 * </TABLE>
	 */
	protected void valoriserParametreCommande(bolbec.injection.xml.generated.Commande commandeArtemis, Commande commandeEfb) {
		// 2.22.1 Indicateur de portabilit� Fibre ver Fibre
		if (CasMetierConstantes.CR_PORTA_SIP_FIBRE.equals(commandeArtemis.getCasMetier()) || CasMetierConstantes.RECR_PORTA_SIP_FIBRE.equals(commandeArtemis.getCasMetier())) {

			List<String> listLCCommande = new ArrayList<String>();

			String compatibiliteFibreFibre = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.COMPATIBILITE_FIBRE_FIBRE, typePorta);
			if (StringUtils.isNotEmpty(compatibiliteFibreFibre)) {

				for (LigneCde ligneCde : commandeEfb.getLigneCde()) {
					listLCCommande.add(ligneCde.getRefOpCommercialeLPA() + ligneCde.getCodeOffrePSS());
				}

				List<String> listMigrationFibreHFibreS = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.MIGRATION_FIBRE_H_FIBRE_S, ConstantesTraduction.OUI);

				if (!listMigrationFibreHFibreS.isEmpty()) {
					String portafibre = NON_MESC;

					List<String> listePortabilite = new ArrayList<String>();
					for (String migrationFibreHFibreS : listMigrationFibreHFibreS) {
						listePortabilite.addAll(Arrays.asList(migrationFibreHFibreS.split("/")));
					}

					if (listLCCommande.containsAll(listePortabilite)) {
						portafibre = OUI;
					}

					serviceManager.getLoggerManager().finest(CLASSNAME, "valoriserParametreCommande", "RG19 - portaFibreFibre=" + portafibre);
					commandeArtemis.addParametresCommande(createParametre(EFBConstantes.PORTA_FIBRE_FIBRE, portafibre));
				}
			}
		}

		// 2.22.2 Motif de suppression OU SU_PORTA_SIP_FIBRE (US-102)
		String sCasMetier = commandeArtemis.getCasMetier();
		if (CasMetierConstantes.SU_FTTH.equals(sCasMetier) || CasMetierConstantes.SU_PORTA_SIP_FIBRE.equals(sCasMetier)) {
			if (isMotifDemenagement(commandeEfb.getMotifCommande())) {
				commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.MOTIF_SUPP, determinerMotifSuppression(commandeEfb)));
			} else if (isMotifORDST(commandeEfb.getMotifCommande())) {
				commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.MOTIF_SUPP, determinerMotifORDST(commandeEfb)));
			} else {
				// Si aucun motif n'est trouv�, on prend la valeur par d�faut "RD"
				commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.MOTIF_SUPP, RD));
			}

			// 2.22.3 Param�tre code OBL
			determinerParamCodeOBL(commandeArtemis, commandeEfb);
		}

		// 2.22.4 Param�tres dynamiques "offre" - "FonctionPSS"
		// 2.22.5 Param�tres dynamiques "offre" / "statut op�rationnel"
		determinerParametresDynamiquesConfig(commandeArtemis, commandeEfb);

		determinerParametresDynamiquesCasSpecifiques(commandeArtemis, commandeEfb);

		// 2.22.7 Param�tres dynamiques sans transcodage
		determinerParametresDynamiquesSansTranscodage(commandeArtemis, commandeEfb);

		// 2.22.8	Contexte Multi-Acc�s
		determinerParametreDynamiqueInfoCmdSiMultiAcces(commandeArtemis);

	}

	/**
	 * Contexte Multi-Acc�s
	 *
	 * @param commandeArtemis
	 */
	private void determinerParametreDynamiqueInfoCmdSiMultiAcces(bolbec.injection.xml.generated.Commande commandeArtemis) {
		ParametreType parametreInfoCmd = null;
		ParametreType parametreMultiAcces = null;
		for (ParametreType parametre : commandeArtemis.getParametresCommande()) {
			if (ConstantesDynamicCommande.MULTI_ACCES.equals(parametre.getCle())) {
				parametreMultiAcces = parametre;
			}
			if (ConstantesDynamicCommande.CLE_INFO_CMD.equals(parametre.getCle())) {
				parametreInfoCmd = parametre;
			}
		}
		if (parametreMultiAcces != null) {
			if (parametreInfoCmd == null) {
				parametreInfoCmd = new ParametreType();
				parametreInfoCmd.setCle(ConstantesDynamicCommande.CLE_INFO_CMD);
				parametreInfoCmd.setValeur(Constantes.TXT_INFO_CMD_MULTI_ACCES);
				commandeArtemis.addParametresCommande(parametreInfoCmd);
			} else if (!parametreInfoCmd.getValeur().contains(Constantes.TXT_INFO_CMD_MULTI_ACCES)) {
				String infoCmd = parametreInfoCmd.getValeur() + Constantes.SEPARATEUR_POINT_VIRGULE + Constantes.TXT_INFO_CMD_MULTI_ACCES;
				parametreInfoCmd.setValeur(infoCmd);
			}
		}
	}

	/**
	 * RG22 : D�termination du contexte de d�m�nagement ou assimil�
	 * 
	 * @return
	 */
	protected boolean isMotifDemenagement(String motifDemenagement) {

		String traductionDmgt = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.CLE_CONTEXTE_DEMENAGEMENT, motifDemenagement);
		if (Constantes.CST_OUI.equals(traductionDmgt)) {
			return true;
		}

		return false;
	}

	/**
	 * EV-000298 : Motif de commande assimil� � ORDST
	 * 
	 * @return
	 */
	protected boolean isMotifORDST(String motifDemenagement) {
		if (ConstantesTraduction.ORDST.equals(motifDemenagement)) {
			return true;
		}
		return false;
	}

	/**
	 * methode pour recuperer les motifsuppression
	 * 
	 * @param commandeEfb
	 * @return motifsuppression
	 */
	protected String determinerMotifSuppression(Commande commandeEfb) {
		String ndip = null;
		String ndip2 = null;
		String maintienND = null;
		String NDARPorteur = null;
		List<String> listeRefFonctionPSSND = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.FONCTION_MAINTIEN_ND, ConstantesTraduction.OUI);
		List<String> listeOffreRefFonctionPSSNDIP = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.FONCTION_NDIP, ConstantesTraduction.OUI);
		List<String> listeOffreRefFonctionPSSNDIP2 = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.FONCTION_NDIP2, ConstantesTraduction.OUI);

		for (LigneCde ligneCde : commandeEfb.getLigneCde()) {

			if (StringUtils.isBlank(maintienND)) {
				maintienND = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.VALEUR_MAINTIEN_ND, getmaintientNDIP(listeRefFonctionPSSND, ligneCde));
			}

			if (StringUtils.isBlank(ndip)) {
				ndip = getNDIP(listeOffreRefFonctionPSSNDIP, ligneCde);
			}

			if (StringUtils.isBlank(ndip2)) {
				ndip2 = getNDIP(listeOffreRefFonctionPSSNDIP2, ligneCde);
			}

			if (StringUtils.isBlank(NDARPorteur)) {
				if (ligneCde.getEltParcCreeLC() != null && StringUtils.isNotBlank(ligneCde.getEltParcCreeLC().getNDARPorteur())) {
					NDARPorteur = ligneCde.getEltParcCreeLC().getNDARPorteur();
				} else if (ligneCde.getEltParcImpacteLC() != null && StringUtils.isNotBlank(ligneCde.getEltParcImpacteLC().getNDARPorteur())) {
					NDARPorteur = ligneCde.getEltParcImpacteLC().getNDARPorteur();
				} else if (ligneCde.getPartageRessTechniques() != null && StringUtils.isNotBlank(ligneCde.getPartageRessTechniques().getNDARPorteur())) {
					NDARPorteur = ligneCde.getPartageRessTechniques().getNDARPorteur();
				}
			}

			if (StringUtils.isNotBlank(maintienND) && StringUtils.isNotBlank(ndip) && StringUtils.isNotBlank(ndip2) && StringUtils.isNotBlank(NDARPorteur)) {
				break;
			}
		}

		// Algorithme de d�termination du motif de suppression
		if (StringUtils.equals(maintienND, OUI)) {
			if (StringUtils.isBlank(ndip) || StringUtils.equals(ndip, NDARPorteur) || StringUtils.equals(ndip2, NDARPorteur)) {
				return PI;
			}
			return RD;
		} else if (StringUtils.isNotBlank(maintienND)) {
			return RD;
		}
		if (StringUtils.equals(ndip, NDARPorteur) || StringUtils.equals(ndip2, NDARPorteur)) {
			return PI;
		}
		return RD;
	}

	/**
	 * methode pour recuperer les motifsuppression
	 * 
	 * @param commandeEfb
	 * @return motifsuppression
	 */
	protected String determinerMotifORDST(Commande commandeEfb) {
		String ndipOrdst = null;
		String portaSortante = null;
		String NDARPorteur = null;
		List<String> listeRefFonctionPSSSortante = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.FONCTION_SORTANTE_DEJA_PORTE, ConstantesTraduction.OUI);

		List<String> listeRefFonctionPSSNDIPORDST = serviceManager.getTraductionManager().getListTraductionCatComArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.FONCTION_NDIP_ORDST, ConstantesTraduction.OUI);

		serviceManager.getLoggerManager().finest(CLASSNAME, "determinerMotifORDST", "Analyse des " + ConstantesTraduction.FONCTION_SORTANTE_DEJA_PORTE + " et des " + ConstantesTraduction.FONCTION_NDIP_ORDST);
		for (LigneCde ligneCde : commandeEfb.getLigneCde()) {

			if (StringUtils.isBlank(portaSortante)) {
				String rechPortaSortante = getmaintientNDIP(listeRefFonctionPSSSortante, ligneCde);
				if (rechPortaSortante != null) {
					portaSortante = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.VALEUR_SORTANTE_DEJA_PORTE, rechPortaSortante);
				}
			}

			if (StringUtils.isBlank(ndipOrdst)) {
				ndipOrdst = getmaintientNDIP(listeRefFonctionPSSNDIPORDST, ligneCde);
			}

			if (StringUtils.isBlank(NDARPorteur)) {
				if (ligneCde.getEltParcCreeLC() != null && StringUtils.isNotBlank(ligneCde.getEltParcCreeLC().getNDARPorteur())) {
					NDARPorteur = ligneCde.getEltParcCreeLC().getNDARPorteur();
				} else if (ligneCde.getEltParcImpacteLC() != null && StringUtils.isNotBlank(ligneCde.getEltParcImpacteLC().getNDARPorteur())) {
					NDARPorteur = ligneCde.getEltParcImpacteLC().getNDARPorteur();
				} else if (ligneCde.getPartageRessTechniques() != null && StringUtils.isNotBlank(ligneCde.getPartageRessTechniques().getNDARPorteur())) {
					NDARPorteur = ligneCde.getPartageRessTechniques().getNDARPorteur();
				}
			}

			if (StringUtils.isNotBlank(portaSortante) && StringUtils.isNotBlank(ndipOrdst) && StringUtils.isNotBlank(NDARPorteur)) {
				break;
			}
		}

		// Algorithme de d�termination du motif de suppression
		if (Constantes.CST_OUI.equals(portaSortante) && ((ndipOrdst != null && (ndipOrdst.equals(NDARPorteur))) || StringUtils.isBlank(ndipOrdst))) {
			serviceManager.getLoggerManager().finest(CLASSNAME, "determinerMotifORDST", "Valorisation du motif de suppression = PO");
			return PO;
		}
		serviceManager.getLoggerManager().finest(CLASSNAME, "determinerMotifORDST", "Valorisation du motif de suppression = RD");
		return RD;
	}

	/**
	 * r�cup�re maintienND et NDIP
	 * 
	 * @param listeRef
	 * @param ligneCde
	 * @return
	 */
	public String getmaintientNDIP(List<String> listeRef, LigneCde ligneCde) {
		if (ligneCde.getValeurFonctionPSS() != null) {
			for (ValeurFonctionPSS val : ligneCde.getValeurFonctionPSS()) {
				if (val != null && listeRef.contains(val.getRefFonctionPSS())) {
					if (val.getValeurFonctionPSS() == null) {
						return val.getValeurFonctionSimplePSS();
					}
					return val.getValeurFonctionPSS();
				}
			}
		}
		return null;
	}

	/**
	 * R�cup�re NDIP
	 * 
	 * @param listeOffreRef
	 * @param ligneCde
	 * @return
	 */
	public String getNDIP(List<String> listeOffreRef, LigneCde ligneCde) {
		final String method = "getNDIP";

		for (String offreRef : listeOffreRef) {
			// Split "codeOffrePSS|refFonctionPSS"
			String[] vals = offreRef.split("\\|");
			if (vals.length != 2) {
				serviceManager.getLoggerManager().warning(CLASSNAME, method, "La traduction " + offreRef + " n'est pas compos�e de 2 valeurs s�par�es par des '|'");
				continue;
			}

			String codeOffrePSS = vals[0];
			String refFonctionPSS = vals[1];

			if (ligneCde.getValeurFonctionPSS() != null) {
				if (codeOffrePSS.equals(ligneCde.getCodeOffrePSS())) {
					for (ValeurFonctionPSS valeurFonctionPss : ligneCde.getValeurFonctionPSS()) {
						if (valeurFonctionPss != null && refFonctionPSS.equals(valeurFonctionPss.getRefFonctionPSS())) {
							if (valeurFonctionPss.getValeurFonctionPSS() == null) {
								return valeurFonctionPss.getValeurFonctionSimplePSS();
							}
							return valeurFonctionPss.getValeurFonctionPSS();
						}
					}
				}
			}
		}

		return null;
	}

	/**
	 * m�thode pour tester si IC_BOLBEC poss�de un param�tre commande, quelque soit le cas m�tier
	 * 
	 * @param commandeArtemis
	 * @return true si la commande poss�de un param�tre commande
	 */
	public boolean possedeParam(bolbec.injection.xml.generated.Commande commandeArtemis) {
		if ((commandeArtemis.getParametresCommande().length != 0)) {
			for (ParametreType param : commandeArtemis.getParametresCommande()) {
				if (param != null && StringUtils.equals(CasMetierConstantes.CR_PORTA_SIP_FIBRE, param.getCle()) && StringUtils.equalsIgnoreCase(OUI, param.getValeur())) {
					return true;
				} else if (param != null && StringUtils.equals(ConstantesDynamicCommande.MOTIF_SUPP, param.getCle()) && StringUtils.isNotBlank(param.getValeur())) {

					return true;
				}
			}
		}

		return false;
	}

	/**
	 * RG20 - Selection des entit�s � transmettre � l�injecteur
	 * 
	 * @param commandeArtemis la commande � injecter dans Art�mis
	 * @param ligneCdeEFB la ligne de commande � tester
	 * @return true si la ligne doit �tre filtr�e
	 * @author alegros
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>23/07/2010</TD><TD>YTR</TD><TD>IRMA_905 : Ajout du filtrage des ligne de suppresion porta sip ayant le statut inconnu</TD></TR>
	 * <TR><TD>12/03/2012</TD><TD>GPA</TD><TD>EV-000169: Gestion du cas metier "RECR_Porta_SIP_Fibre"</TD></TR>
	 * </TABLE>
	 */
	protected boolean filtrerLigne(bolbec.injection.xml.generated.Commande commandeArtemis, LigneCde ligneCdeEFB) {
		String casMetier = commandeArtemis.getCasMetier();
		if ((ligneCdeEFB.getStatutOperationnel() != null)) {
			String codeStatutOperation = ligneCdeEFB.getStatutOperationnel().getCodeStatutOperation();
			if (EFBConstantes.STATUT_OP_LC_INCONNU.equals(codeStatutOperation)) {
				if (((CasMetierConstantes.CR_PORTA_SIP_FIBRE.equals(casMetier) || CasMetierConstantes.SU_PORTA_SIP_FIBRE.equals(casMetier) || CasMetierConstantes.RECR_PORTA_SIP_FIBRE.equals(casMetier))) || (possedeParam(commandeArtemis))) {
					return true;
				}
			}
			if (serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.LC_NON_LIVREE, codeStatutOperation + "|" + ligneCdeEFB.getCodeOffrePSS()) != null) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Cette m�thode recherche sur la ligne de commande EFB, un AliasOffreGroupee.<BR>
	 * Si on en trouve un de type BBS avec une r�f�rence valide (non NULL et non VIDE)<BR>
	 * La r�f�rence de cet alias est m�moris� dans les ParametreLivraison de la ligne de commande bolbec
	 * 
	 * @param lcEfb La ligne de commande EFB
	 * @param lcArtemis La ligne de commande Artemis (En cours de construction)
	 * @return <code>true</code> si l'AID a �t� valoris�, <code>false</code> sinon
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>06/08/2010</TD><TD>DBA</TD><TD>EV-000053: Initialisation de la m�thode</TD></TR>
	 * <TR><TD>08/03/2012</TD><TD>GPA</TD><TD>EV-000169: Ajout du booleen en retour de la m�thode</TD></TR>
	 * </TABLE>
	 */
	protected boolean valoriserAID(LigneCde lcEfb, LigneCommandeType lcArtemis, String refCommande) {
		boolean valorisation = false;

		// Si on en trouve une de type BBS
		AliasInstanceOffreGroupee aliasInstanceOG = lcEfb.getAliasInstanceOffreGroupee();
		if (aliasInstanceOG != null && aliasInstanceOG.getTypeAlias() != null && "BSS".equals(aliasInstanceOG.getTypeAlias().toUpperCase())) {

			// Et que la r�f�rence de l'alias existe (non NULL et non VIDE)
			String refAlias = aliasInstanceOG.getRefAliasInstanceOffreGroupee();
			if (refAlias != null && refAlias.trim().length() > 0) {

				// Ajout d'un parametre sur la commande
				lcArtemis.addParametreLivraison(createParametre(EFBConstantes.AID, refAlias));
				serviceManager.getLoggerManager().qualif(CLASSNAME, 0, "ajouterAliasInstanceOG", refCommande, "Valorisation AID=%s", refAlias);
				valorisation = true;
			}
		}

		return valorisation;
	}

	/**
	 * Lorsque le statut de la commande est de type "AGREGEE", cette m�thode cr�e un questionnaire technique pour une ligne de commande.
	 * Exemple de valeur retourn�e : "Question1=R�ponse1;Question2=R�ponse2;Question3=R�ponse3;"
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>07/01/2011</TD><TD>BPE</TD><TD>EV-000089: Initialisation de la m�thode</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * </TABLE>
	 * 
	 * @param commande
	 * 
	 * @param ligneCdeEFB La ligne de commande EFB
	 * @param commandeEFB La commande EFB
	 * @return le questionnaire technique
	 */
	protected Map<String, String> valoriserQuestionnaireTechniqueEtSecondNd(bolbec.injection.xml.generated.Commande commande, LigneCde ligneCdeEFB, Commande commandeEFB, ProduitServiceSouhaite l_pssouhaite) {
		final String methode = "valoriserQuestionnaireTechnique";
		final StringBuilder valeurQTBuffer = new StringBuilder(100);
		String secondNd = null;

		boolean cmdePlpSansRdv = false;
		for (ParametreType parametreCommande : commande.getParametresCommande()) {
			if (ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON.equals(parametreCommande.getCle()) && ConstantesDynamicCommande.PLP_SANS_RDV.equals(parametreCommande.getValeur())) {
				cmdePlpSansRdv = true;
				break;
			}
		}

		if ((!cmdAgregee && !cmdePlpSansRdv) || (ligneCdeEFB == null)) {
			return null;
		}
		IReferenceSpaceManager referenceSpaceManager = serviceManager.getReferenceSpaceManager();
		OffreSeDTO offreSE = referenceSpaceManager.findInReferenceSpace(OffreSeDTO.class, new Comparaison(OffreSE.FIELD_CODE, Constantes.OPERATOR_EQUAL, ligneCdeEFB.getCodeOffrePSS()));
		if (offreSE == null || offreSE.getOffreArtemis() == null) {
			return null;
		}
		OffreDTO offre = referenceSpaceManager.findInReferenceSpace(OffreDTO.class, offreSE.getOffreArtemis().getId());
		if (offre != null && Constantes.NATURE_OFFRE_PREST.equals(offre.getNatureOffre())) {
			// Soit c_valeurFonctionPSS, la liste des fonctions issue de l�IC_EFB contenant
			// les couples IC_EFB.RefFonctionPSS / IC_EFB.ValeurFonctionPSS / IC_EBF.ValeurFonctionSimplePSS.
			ITraductionManager traductionManager = serviceManager.getTraductionManager();
			for (ValeurFonctionPSS valeurFonctionPSS : ligneCdeEFB.getValeurFonctionPSS()) {
				// Traduction de la question associ�e au questionnaire technique
				String valeurArtemisRef = traductionManager.getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.QT_QUESTION, valeurFonctionPSS.getRefFonctionPSS());
				if (!StringUtils.isEmpty(valeurArtemisRef)) {
					String isSecondNd = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.ND_CONTACT_RDV, valeurFonctionPSS.getRefFonctionPSS());
					if (StringUtils.isNotBlank(isSecondNd) && Constantes.CST_OUI.equals(isSecondNd)) {
						if (StringUtils.isNotBlank(valeurFonctionPSS.getValeurFonctionSimplePSS())) {

							secondNd = valeurFonctionPSS.getValeurFonctionSimplePSS();

							// Enregistrement du second nd sur le pssouhaite
							l_pssouhaite.addParametreProduitService(createParametre(ConstantesDynamicPSSouhaite.NOCONTACTRDV_EVENTUEL, secondNd));
						}
					} else {
						String valeurQTReponse = valeurFonctionPSS.getValeurFonctionSimplePSS();
						String valeurQTQuestion = valeurArtemisRef;
						// Traduction de la r�ponse associ�e au questionnaire technique
						String valeurArtemisVal = traductionManager.getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.QT_REPONSE, valeurFonctionPSS.getValeurFonctionPSS());
						if (!StringUtils.isEmpty(valeurArtemisVal)) {
							valeurQTReponse = valeurArtemisVal;
						} else if (StringUtils.isEmpty(valeurQTReponse)) {
							continue;
						}
						valeurQTBuffer.append(valeurQTQuestion);
						valeurQTBuffer.append("=");
						valeurQTBuffer.append(valeurQTReponse);
						valeurQTBuffer.append(";");
					}
				}
			}
		}
		String valeurQT = valeurQTBuffer.toString();
		serviceManager.getLoggerManager().qualif(CLASSNAME, 0, methode, commandeEFB.getRefCommande(), "Valorisation ValeurQT=" + valeurQT);
		Map<String, String> mapReturn = new HashMap<String, String>();
		mapReturn.put("valeurQT", valeurQT);
		mapReturn.put("secondNd", secondNd);
		return mapReturn;
	}

	/**
	 * RG21 concat�ne le "compl�ment numero Voie" au "num�ro voie" de toutes les lignes de commande dans le cas o� la commande est agr�g�e et non FTTH
	 * 
	 * @param commandeArtemis la commande Artemis
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * </TABLE>
	 */
	protected void alimenterNumeroVoie(bolbec.injection.xml.generated.Commande commandeArtemis) {

		// Nous concat�nons � le compl�ment Numero Voie au num�ro Voie dans le cas o� la commande
		// est agr�g�e et non FTTH
		if (!cmdAgregee) {
			return;
		}
		String casMetier = commandeArtemis.getCasMetier();
		if (casMetier != null && casMetier.endsWith(ConstantesTraduction.FTTH)) {
			return;
		}

		// Nous concat�nons pour toutes les lignes de commande
		for (LigneCommandeType ligneCommande : commandeArtemis.getLigneCommande()) {
			alimenterNumeroVoieParLigneDeCommande(ligneCommande);
		}
		for (InstanceOffreGroupee instanceOffreGroupee : commandeArtemis.getInstanceOffreGroupee()) {
			for (LigneCommandeType ligneCommande : instanceOffreGroupee.getLigneCommande()) {
				alimenterNumeroVoieParLigneDeCommande(ligneCommande);
			}
		}
	}

	/**
	 * concat�ne le "compl�ment numero Voie" au "num�ro voie" de la ligne de commande
	 * 
	 * @param ligneCommande La ligne de commande
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>28/07/2011</TD><TD>BPE</TD><TD>EV-000162 BOLBEC-2077: NSD Gestion adresses parsifal</TD></TR>
	 * </TABLE>
	 */
	protected void alimenterNumeroVoieParLigneDeCommande(LigneCommandeType ligneCommande) {
		Adresse adresse = ligneCommande.getClientLivre().getAdresse();
		if (adresse == null) {
			return;
		}
		String cpltNumVoie = adresse.getCpltNumVoie();
		String numeroVoie = adresse.getNumeroVoie();
		if (StringUtils.isEmpty(cpltNumVoie)) {
			return;
		}

		if (StringUtils.isEmpty(numeroVoie)) {
			adresse.setNumeroVoie(cpltNumVoie);
		} else {
			adresse.setNumeroVoie(numeroVoie + cpltNumVoie);
		}
	}

	/**
	 * RG23 : D�termination des offres consid�r�es comme appartenant � des familles de Quarantaine
	 * 
	 * @param ligneCde
	 * @return
	 */
	protected boolean isOffreTypeQuarantaine(LigneCommandeType ligneCde, LigneCde ligneCdeEFB) {
		if (ligneCdeEFB.getEltParcImpacteLC() != null) {
			String NDARPorteur = ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur();

			String valeurFonctionNDEdP = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_NDEDP, ConstantesTraduction.REF_FONCTION_ND_EDP);
			String nDEdP = null;
			if (valeurFonctionNDEdP != null) {
				int nbValeurFonctionEdp = ligneCdeEFB.getEltParcImpacteLC().getValeurFonctionEdPCount();
				for (int i = 0; i < nbValeurFonctionEdp; i++) {
					ValeurFonctionEdP valeurFonctionEdp = ligneCdeEFB.getEltParcImpacteLC().getValeurFonctionEdP(i);
					if (valeurFonctionEdp != null) {
						if (valeurFonctionEdp.getRefFonctionEdP() != null && valeurFonctionNDEdP.equals(valeurFonctionEdp.getRefFonctionEdP())) {
							nDEdP = valeurFonctionEdp.getValeurFonctionSimpleEdP();
						}
					}
				}
			}

			if (NDARPorteur != null) {
				ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.NDAR_PORTEUR, NDARPorteur));
				if (nDEdP != null) {
					ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.ND_EDP, nDEdP));
					ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.COMMANDE_QUARANTAINE, Constantes.CST_OUI));
					return true;
				}
			}
		}
		return false;
	}

	/**
	 * RG24 : Valorisation de l'acc�s de livraison pour les lignes de commandes de modification li�es � une famille d�offre de Porta
	 * 
	 * @param ligneCdeEFB
	 * @param ligneCde
	 * @param commandeArtemis
	 * @param paramFonctNotification
	 */
	protected void valoriserAccesLivraisonFamilleOffreQuarantaine(LigneCde ligneCdeEFB, LigneCommandeType ligneCde, bolbec.injection.xml.generated.Commande commandeArtemis, Map<String, Object> paramFonctNotification, String accesLivraison) {
		List<ParametreDynamiqueDTO> parametres = ServiceManager.getInstance().getParametreDynamiqueManager().findParametreDynamiqueParCleEtVersion(ConstantesParametreDynamique.ANALYSE_ND_GEO_EFB, Constantes.VERSION_COURANTE);
		boolean analyseGeoNDEFB = false;
		for (ParametreDynamiqueDTO parametre : parametres) {
			if (Constantes.CST_OUI.equals(parametre.getValeur())) {
				analyseGeoNDEFB = true;
				break;
			}
		}

		if (analyseGeoNDEFB) {
			String NDARPorteur = "";
			String nDEdP = "";
			for (ParametreType parametreLivraison : ligneCde.getParametreLivraison()) {
				if (ConstantesDynamicLigneCommande.NDAR_PORTEUR.equals(parametreLivraison.getCle())) {
					NDARPorteur = parametreLivraison.getValeur();
				} else if (ConstantesDynamicLigneCommande.ND_EDP.equals(parametreLivraison.getCle())) {
					nDEdP = parametreLivraison.getValeur();
				}
			}

			String refFonctionPSS = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_TYPEND, ConstantesTraduction.REF_FONCTION_PSS);
			String refFonctionEdp = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_FONCTION_TYPEND, ConstantesTraduction.REF_FONCTION_EDP);

			String valFonctionPss = null;
			String valFonctionEdp = null;

			int nbValeurFonctionPSS = ligneCdeEFB.getValeurFonctionPSSCount();
			for (int i = 0; i < nbValeurFonctionPSS; i++) {
				ValeurFonctionPSS valeurFonctionPSS = ligneCdeEFB.getValeurFonctionPSS(i);
				if (valeurFonctionPSS.getRefFonctionPSS() != null && valeurFonctionPSS.getRefFonctionPSS().equals(refFonctionPSS)) {
					valFonctionPss = valeurFonctionPSS.getValeurFonctionPSS();
				}
			}

			int nbValeurFonctionEdp = ligneCdeEFB.getEltParcImpacteLC().getValeurFonctionEdPCount();
			for (int i = 0; i < nbValeurFonctionEdp; i++) {
				ValeurFonctionEdP valeurFonctionEdp = ligneCdeEFB.getEltParcImpacteLC().getValeurFonctionEdP(i);
				if (valeurFonctionEdp.getRefFonctionEdP() != null && valeurFonctionEdp.getRefFonctionEdP().equals(refFonctionEdp)) {
					valFonctionEdp = valeurFonctionEdp.getValeurFonctionEdP();
				}
			}

			// Valeur "NON_GEO" par d�faut, si un enregistrement est trouv�, on remplace par la valeur correspondante
			String valeurArtePss = ConstantesTraduction.NON_GEO;
			String valeurArteEdp = ConstantesTraduction.NON_GEO;
			if (valFonctionPss != null) {
				valeurArtePss = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, EFBConstantes.VALEUR_FONCTION_TYPEND, valFonctionPss);
			}
			if (valFonctionEdp != null) {
				valeurArteEdp = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, EFBConstantes.VALEUR_FONCTION_TYPEND, valFonctionEdp);
			}

			if (ConstantesTraduction.GEO.equals(valeurArtePss)) {
				accesLivraison = NDARPorteur;
				if (ConstantesTraduction.GEO.equals(valeurArteEdp)) {
					commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.CLE_TYPESDACCES, ConstantesDynamicCommande.ECR_GEO_PAR_GEO));
					// Ajout sur les dynamicLdc du contexte (On ne peut determiner le contexte "LigneCommande.FK_DEPENDCONTEXTE" � ce niverau de l'adaptateur, ce sera determin� plus tard dans CompletudeCommande)
					ligneCde.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.CLE_CONTEXTE_LDC, ConstantesDynamicLigneCommande.MAJ_PARCS_GEO));
				} else {
					commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.CLE_TYPESDACCES, ConstantesDynamicCommande.ECR_NON_GEO_PAR_GEO));
				}
			} else {
				if (ConstantesTraduction.GEO.equals(valeurArteEdp)) {
					accesLivraison = nDEdP;
					commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.CLE_TYPESDACCES, ConstantesDynamicCommande.ECR_GEO_PAR_NON_GEO));

				} else {
					paramFonctNotification.put(EFBConstantes.CLE_LIGNE_CDE_ERREUR, ligneCde.getIdLigneCommande());
					serviceManager.getLoggerManager().finest(CLASSNAME, "valoriserAccesLivraisonFamilleOffreQuarantaine", "Lev�e anomalie : " + AnomalieConstantes.CONTENU_ICEFB + " ,  NDARPorteur et NDEdP sont tout les deux non geographiques ");
					throw new ReceptionCdeException(AnomalieConstantes.CONTENU_ICEFB, "NDARPorteur et NDEdP sont tout les deux non geographiques");
				}
			}

		} else {
			accesLivraison = ligneCdeEFB.getEltParcImpacteLC().getNDARPorteur();
		}
		ligneCde.setAccesLivraison(accesLivraison);

	}

	/**
	 * Recherche dans les param�tres livraison la pr�sence d'une cl� sp�cifique.
	 * 
	 * @return true, si la cl� est pr�sente dans les param�tres. False sinon.
	 */
	protected boolean isClePresenteDansParamLivraison(LigneCommandeType ligneCde, String key) {

		for (int i = 0; i < ligneCde.getParametreLivraisonCount(); i++) {
			String cleActuelle = ligneCde.getParametreLivraison(i).getCle();
			if (key.equals(cleActuelle)) {
				return true;
			}
		}
		return false;
	}

	protected boolean isClefPresenteDansParamLivraisonCommande(bolbec.injection.xml.generated.Commande commande, String key) {
		for (int i = 0; i < commande.getParametresCommandeCount(); i++) {
			String cleActuelle = commande.getParametresCommande(i).getCle();
			if (key.equals(cleActuelle)) {
				return true;
			}
		}
		return false;
	}

	/**
	 * RG25 : Re-Traduction des offres �l�mentaires
	 * 
	 * @param keyOffre
	 * @param icEFB
	 * @param ligneCdeEFB
	 * @param ldc
	 */
	protected String traduireOffreElementaires(String keyOffre, CommandeEfb icEFB, LigneCde ligneCdeEFB, LigneCommandeType ldc) {
		String keyRetour = keyOffre;

		int nbLigne = 0;
		for (LigneCde ligne : icEFB.getStructureMetier().getCommande().getLigneCde()) {
			if (!StringUtils.equals(ligne.getStatutOperationnel().getCodeStatutOperation(), EFBConstantes.STATUT_OP_LC_INCONNU)) {
				nbLigne++;
			}
		}

		OffreDTO offre = serviceManager.getOffreManager().getOffreById(keyOffre);
		String valeurConstante = null;
		if (offre != null) {
			valeurConstante = offre.getValeurConstante();
		}

		String valeurExterne = nbLigne + PIPE_SEPARATEUR + ligneCdeEFB.getRefOpCommercialeLPA() + PIPE_SEPARATEUR + valeurConstante + PIPE_SEPARATEUR + ldc.getRefOperationPonctuelle();

		String valeurArte = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.EFB, EFBConstantes.RETRADUCTION_OFFRE, valeurExterne);
		if (valeurArte != null) {
			keyRetour = Constantes.VERSION + Constantes.SEP_VERSION_VALEURCST + valeurArte;

		}
		return keyRetour;
	}

	/**
	 * D�termine si le motif de la commande la rend �ligible � une offre de recr�ation
	 * 
	 * @param a_commandeEFB
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>02/06/14</TD><TD>ASE</TD><TD>EV-000300 D�termination des motifs potentiels de recr�ation</TD></TR>
	 * </TABLE>
	 */
	protected boolean isMotifPotentielRecreation(Commande a_commandeEFB) {
		String valeurArtemis = (serviceManager.getTraductionManager().getTraductionInterfVersArtemis(SystemeExterneConstantes.EFB, ConstantesTraduction.MOTIF_RECR, a_commandeEFB.getMotifCommande()));
		return Constantes.CST_OUI.equals(valeurArtemis);
	}

	/**
	 * EV-000298 : D�termine le param�tre codeOBL
	 * 
	 * @param commandeArtemis
	 * @param commandeEfb
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>07/07/14</TD><TD>ASE</TD><TD>EV-000298 </TD></TR>
	 * </TABLE>
	 */
	protected void determinerParamCodeOBL(bolbec.injection.xml.generated.Commande commandeArtemis, Commande commandeEfb) {
		for (LigneCde ligne : commandeEfb.getLigneCde()) {
			if (serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.OFFRE_CODE_OBL, ligne.getCodeOffrePSS()) != null) {
				for (ValeurFonctionPSS valeurFonctionPss : ligne.getValeurFonctionPSS()) {
					String codeObl = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.CODE_OBL, valeurFonctionPss.getRefFonctionPSS());
					if (codeObl != null) {
						final String valeurParamPS;
						if (valeurFonctionPss.getValeurFonctionPSS() != null) {
							valeurParamPS = valeurFonctionPss.getValeurFonctionPSS();
						} else if (valeurFonctionPss.getValeurFonctionSimplePSS() != null) {
							valeurParamPS = valeurFonctionPss.getValeurFonctionSimplePSS();
						} else {
							throw new ReceptionCdeException(AnomalieConstantes.CONTENU_ICEFB, "Les valeurs FonctionPSS et FonctionSimplePSS sont nulles lors de d�termination du codeOBL");
						}
						commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.CODE_OBL, valeurParamPS));
						return;
					}
				}
			}
		}
		return;
	}

	/**
	 * EV-298 : D�termine la valeur du code Z0BPQ.
	 * 
	 * @param casMetier
	 * @param commandeEFB
	 * @return
	 */
	protected String determinerValeurCodeZ0BPQ(String casMetier, Commande commandeEFB) {
		if (CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.SU_PORTA_SIP_FIBRE.equals(casMetier)) {
			for (LigneCde ligneCde : commandeEFB.getLigneCde()) {
				for (ValeurFonctionPSS valeurFonctionPSS : ligneCde.getValeurFonctionPSS()) {
					if (serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.OFFRE_CODE_Z0BPQ, ligneCde.getCodeOffrePSS()) != null
							&& serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.Z0BPQ_SU_FTTH, valeurFonctionPSS.getRefFonctionPSS()) != null) {
						return valeurFonctionPSS.getValeurFonctionSimplePSS();
					}
				}
			}
		}
		return null;
	}

	/**
	 * M�thode permettant de valoriser si n�cessaire le contexte livraison de la commande � "PLPHD"
	 * 
	 * @param commandeArtemis
	 */
	protected void valoriserContexteLivraisonPLPHD(bolbec.injection.xml.generated.Commande commandeArtemis) {
		// On ne valorise pas le contexte livraison s'il a d�j� �t� valoris� avant
		if (commandeArtemis.getParametresCommande() != null) {
			for (ParametreType dynamic : commandeArtemis.getParametresCommande()) {
				if (ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON.equals(dynamic.getCle())) {
					return;
				}
			}
		}

		commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON, ConstantesDynamicCommande.PLPHD));
	}

	/**
	 * M�thode permettant d�terminer des param�tres dynamiques lors de cas sp�cifiques
	 * 
	 * @param commandeArtemis
	 * @param commandeEfb
	 */
	protected void determinerParametresDynamiquesCasSpecifiques(bolbec.injection.xml.generated.Commande commandeArtemis, Commande commandeEfb) {
		// 2.22.6.1 Contexte PLPA
		if (commandeEfb.getStatutOpCommande() != null && !EFBConstantes.REAACTNU.equals(commandeEfb.getStatutOpCommande().getCodeStatutOpCommande())) {
			for (LigneCde ligneCommande : commandeEfb.getLigneCde()) {
				if (ligneCommande.getPartageRessTechniques() != null) {
					if (PLPA_ETAT_LIGNE.equals(ligneCommande.getPartageRessTechniques().getEtatLigne())) {
						commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON, ConstantesDynamicCommande.PLPA));
						break;
					}
				}
			}
		}

		// 2.22.6.2 Contexte R�siliation Ancienne Adresse
		if (EFBConstantes.DEMGT.equals(commandeEfb.getMotifCommande())) {
			for (LigneCde ligneCommande : commandeEfb.getLigneCde()) {
				if (TypeOpPonctuellesConstantes.CR.equals(ligneCommande.getRefOpCommercialeLPA())) {
					if (ligneCommande.getStatutOperationnel() != null && EFBConstantes.STATUT_OP_LC_INCONNU.equals(ligneCommande.getStatutOperationnel().getCodeStatutOperation())) {
						List<TraductionCatComDTO> traductions = serviceManager.getTraductionManager().findTraductionCatComByCleAndSystemeExterne(SystemeExterneConstantes.EFB, ConstantesTraduction.CLE_PARAM_DYN_CDE_RESIL_ANC_ADR);

						int nombreMatch = 0;
						TraductionCatComDTO traductionSauvegarde = null;
						for (TraductionCatComDTO trad : traductions) {
							if (getValeurFonctionPSSCorrespondantATraduction(commandeEfb, trad.getValeurExterne()) != null) {
								nombreMatch++;
								// Stockage de la 1ere traduction trouv�e
								if (traductionSauvegarde == null) {
									traductionSauvegarde = trad;
								}
							}
						}
						// Si 2 ou plus triptyques correspondants sont trouv�s
						if (nombreMatch > 1 && traductionSauvegarde != null) {
							String valeurArtemis[] = traductionSauvegarde.getValeurArtemis().split("\\|");
							if (valeurArtemis.length == 2) {
								commandeArtemis.addParametresCommande(createParametre(valeurArtemis[0], valeurArtemis[1]));
							}
						}

						break;
					}
				}
			}
		}

		// 2.22.6.3 Contexte DENUM (EV-442)
		if (EFBConstantes.DENUM.equals(commandeEfb.getMotifCommande())) {
			commandeArtemis.addParametresCommande(createParametre(ConstantesDynamicCommande.CLE_CONTEXTE_LIVRAISON, ConstantesDynamicCommande.DENUM));
		}
	}

	/**
	 * M�thode permettant de recopier des param�tres dynamiques sans transcodage
	 * 
	 * @param commandeArtemis
	 * @param commandeEfb
	 */
	private void determinerParametresDynamiquesSansTranscodage(bolbec.injection.xml.generated.Commande commandeArtemis, Commande commandeEfb) {
		String typoDemenagement = "";

		for (int i = 0; i < commandeEfb.getSpecificiteCommandeCount(); i++) {
			SpecificiteCommande specificiteCommande = commandeEfb.getSpecificiteCommande(i);
			if (specificiteCommande != null && EFBConstantes.TYPE_DEMGT.equalsIgnoreCase(specificiteCommande.getTypeCritere())) {
				typoDemenagement = specificiteCommande.getValCritereEnum();
			}
		}

		if (!StringUtils.isBlank(typoDemenagement)) {
			commandeArtemis.addParametresCommande(createParametre(EFBConstantes.TYPE_DEMGT, typoDemenagement));
		}
	}

	/**
	 * M�thode permettant de savoir si une commande et ses lignes correspondent � une traduction EFB
	 * Si c'est le cas, on r�cup�re la valeur fonction PSS qui correspond
	 * 
	 * @param commandeEfb la commande au format EFB
	 * @param traduction la traduction EFB
	 * @return la ValeurFonctionPSS correspondant � la traduction, null sinon
	 */
	private ValeurFonctionPSS getValeurFonctionPSSCorrespondantATraduction(Commande commandeEfb, String traduction) {
		final String method = "getValeurFonctionPSSCorrespondantATraduction";

		String[] vals = traduction.split("\\|");
		if (vals.length != 3) {
			serviceManager.getLoggerManager().warning(CLASSNAME, method, "La traduction " + traduction + " n'est pas compos� de 3 valeurs s�par�s par des '|'");
			return null;
		}

		String tradConfOffre = vals[0];
		String tradConfFonction = vals[1];
		String tradConfValeurFonction = vals[2];

		return getValeurFonctionPSSCorrespondantAOffreFonction(commandeEfb, tradConfOffre, tradConfFonction, tradConfValeurFonction);
	}

	/**
	 * M�thode permettant de savoir si une commande et ses lignes correspondent � une traduction EFB
	 * Si c'est le cas, on r�cup�re la valeur fonction PSS qui correspond
	 * 
	 * @param commandeEfb la commande au format EFB
	 * @param tradConfOffre l'offre
	 * @param tradConfFonction la fonction
	 * @param tradConfValeurFonction la valeur de la fonction
	 * @return la ValeurFonctionPSS correspondant � la traduction, null sinon
	 */
	private ValeurFonctionPSS getValeurFonctionPSSCorrespondantAOffreFonction(Commande commandeEfb, String tradConfOffre, String tradConfFonction, String tradConfValeurFonction) {
		for (LigneCde ligneCommande : commandeEfb.getLigneCde()) {
			ValeurFonctionPSS valeurFonctionPSS = getValeurFonctionPSSCorrespondantAOffreFonction(ligneCommande, tradConfOffre, tradConfFonction, tradConfValeurFonction);
			if (valeurFonctionPSS != null) {
				return valeurFonctionPSS;
			}
		}

		return null;
	}

	/**
	 * M�thode permettant de savoir si une ligne de commande correspondent � une traduction EFB (offre, fonction, valeur fonction)
	 * Si c'est le cas, on r�cup�re la valeur fonction PSS qui correspond
	 * 
	 * @param ligneCommande la ligne de commande au format EFB
	 * @param tradConfOffre l'offre
	 * @param tradConfFonction la fonction
	 * @param tradConfValeurFonction la valeur de la fonction
	 * @return la ValeurFonctionPSS correspondant � la traduction, null sinon
	 */
	private ValeurFonctionPSS getValeurFonctionPSSCorrespondantAOffreFonction(LigneCde ligneCommande, String tradConfOffre, String tradConfFonction, String tradConfValeurFonction) {
		// Pour l'EV 362 PLP Fibre sans RDV, refFonctionPSS et valeurFonctionPSS peuvent �tre �gales � *
		if (StringUtils.equals(tradConfOffre, ligneCommande.getCodeOffrePSS())) {
			for (int j = 0; j < ligneCommande.getValeurFonctionPSS().length; j++) {
				ValeurFonctionPSS valeurFonctionPSS = ligneCommande.getValeurFonctionPSS(j);
				if (StringUtils.equals(tradConfFonction, "*") || StringUtils.equals(tradConfFonction, valeurFonctionPSS.getRefFonctionPSS())) {
					if (StringUtils.equals(tradConfValeurFonction, "*") || StringUtils.equals(tradConfValeurFonction, valeurFonctionPSS.getValeurFonctionPSS())) {
						return valeurFonctionPSS;
					}
				}
			}
		}

		return null;
	}

	/**
	 * Permet de d�terminer les param�tres dynamiques de commande � partir de la table de conf.
	 * 
	 * @param commandeArtemis la commande bolbec
	 * @param commandeEfb la commande efb
	 */
	protected void determinerParametresDynamiquesConfig(bolbec.injection.xml.generated.Commande commandeArtemis, Commande commandeEfb) {
		String method = "determinerParametresDynamiquesConfig";
		List<InputDynamicCommandeDTO> lstInputDynamicCommandeDTO = serviceManager.getTraductionManager().findInputDynamicCommandeByOrigine(SystemeExterneConstantes.EFB_VALEUR_CONSTANTE);
		serviceManager.getLoggerManager().finer(CLASSNAME, method, "D�termination de param�tres dynamiques selon une liste de " + lstInputDynamicCommandeDTO.size() + " correspondances.");
		List<ParametreType> lstNouveauxParametres = new ArrayList<ParametreType>();
		for (InputDynamicCommandeDTO inputDynamicCommandeDTO : lstInputDynamicCommandeDTO) {
			for (LigneCde ligneCommande : commandeEfb.getLigneCde()) {
				ParametreType nouveauParam = getParametreDynamiqueConfig_X_Ligne(inputDynamicCommandeDTO, commandeArtemis, commandeEfb, ligneCommande);
				if (nouveauParam != null) {
					boolean existeDeja = false;
					for (ParametreType param : commandeArtemis.getParametresCommande()) {
						if (StringUtils.equals(nouveauParam.getCle(), param.getCle())) {
							if (!StringUtils.equals(nouveauParam.getValeur(), param.getValeur())) {
								serviceManager.getLoggerManager().warning(CLASSNAME, method, "Rejet du param�tre " + nouveauParam.getCle() + " par raison de incoh�rence.");
								throw new ReceptionCdeException(AnomalieConstantes.CONTENU_ICEFB,
										"Le param�tre avec pour cl� " + nouveauParam.getCle() + " est d�j� pr�sent sur la commande avec la valeur " + param.getValeur() + " et non pas la valeur " + nouveauParam.getValeur());
							}
							existeDeja = true;
						}
					}

					if (existeDeja) {
						serviceManager.getLoggerManager().finer(CLASSNAME, method, "Rejet du param�tre " + nouveauParam.getCle() + " par raison de doublon.");
					} else {
						lstNouveauxParametres.add(nouveauParam);
						commandeArtemis.addParametresCommande(nouveauParam);
						serviceManager.getLoggerManager().finer(CLASSNAME, method, "Int�gration du param�tre " + nouveauParam.getCle());
					}
				}
			}
		}
		serviceManager.getLoggerManager().finer(CLASSNAME, method, "R�cup�ration totale de " + lstNouveauxParametres.size() + " param�tres dynamiques.");
	}

	/**
	 * Permet de d�terminer le param�tre dynamique d'une ligne de commande � partir d'une ligne de la table de conf.
	 * 
	 * @param inputDynamicCommandeDTO la ligne de config input dynamique commande
	 * @param commande la commande bolbec
	 * @param commandeEfb la commande efb
	 * @param ligneCmdEfb la ligne de commande efb
	 */
	protected ParametreType getParametreDynamiqueConfig_X_Ligne(InputDynamicCommandeDTO inputDynamicCommandeDTO, bolbec.injection.xml.generated.Commande commande, Commande commandeEfb, LigneCde ligneCmdEfb) {
		String method = "getParametreDynamiqueConfig_X_Ligne";

		String tradConfStatut = inputDynamicCommandeDTO.getStatut();
		String tradConfOffre = inputDynamicCommandeDTO.getOffre();
		String tradConfFonction = inputDynamicCommandeDTO.getFonction();
		String tradConfValeurFonction = inputDynamicCommandeDTO.getValeurFonction();

		boolean bCorrespondanceOk = true;

		// Comparer le statut (et variations d'expr. reg.)
		if (StringUtils.isBlank(tradConfStatut) || StringUtils.equals(tradConfStatut, STRING_RULE_ANY)) {
		} else if (commandeEfb.getStatutOpCommande() != null) {
			bCorrespondanceOk = StringUtils.equals(tradConfStatut, commandeEfb.getStatutOpCommande().getCodeStatutOpCommande());
		}
		if (!bCorrespondanceOk) {
			return null;
		}

		// Comparer l'offre (et variations d'expr. reg.)
		if (StringUtils.isBlank(tradConfOffre) || StringUtils.equals(tradConfOffre, STRING_RULE_ANY)) {
		} else {
			bCorrespondanceOk = StringUtils.equals(tradConfOffre, ligneCmdEfb.getCodeOffrePSS());
		}
		if (!bCorrespondanceOk) {
			return null;
		}

		// Comparer la fonction'offre (et variations d'expr. reg.)
		List<ValeurFonctionPSS> lstValeurFonctionPSS = new LinkedList<ValeurFonctionPSS>();
		if (StringUtils.isBlank(tradConfFonction) || StringUtils.equals(tradConfFonction, STRING_RULE_ANY)) {
		} else {
			lstValeurFonctionPSS.addAll(Arrays.asList(ligneCmdEfb.getValeurFonctionPSS()));
			for (Iterator<ValeurFonctionPSS> itValeurFonctionPSS = lstValeurFonctionPSS.iterator(); itValeurFonctionPSS.hasNext();) {
				ValeurFonctionPSS valeurFonctionPSS = itValeurFonctionPSS.next();
				if (!StringUtils.equalsIgnoreCase(tradConfFonction, valeurFonctionPSS.getRefFonctionPSS())) {
					itValeurFonctionPSS.remove();
				}
			}
			bCorrespondanceOk = !lstValeurFonctionPSS.isEmpty();
		}
		if (!bCorrespondanceOk) {
			return null;
		}

		// Comparer la valeur fonction'offre (et variations d'expr. reg.)
		if (StringUtils.isBlank(tradConfValeurFonction) || StringUtils.equals(tradConfValeurFonction, STRING_RULE_ANY)) {
		} else {
			for (Iterator<ValeurFonctionPSS> itValeurFonctionPSS = lstValeurFonctionPSS.iterator(); itValeurFonctionPSS.hasNext();) {
				ValeurFonctionPSS valeurFonctionPSS = itValeurFonctionPSS.next();
				if (!StringUtils.equalsIgnoreCase(tradConfValeurFonction, valeurFonctionPSS.getValeurFonctionPSS())) {
					itValeurFonctionPSS.remove();
				}
			}
			bCorrespondanceOk = !lstValeurFonctionPSS.isEmpty();
		}
		if (!bCorrespondanceOk) {
			return null;
		}

		// Construire le parametre, et valider la composition
		ParametreType valeurParametre = null;
		if (bCorrespondanceOk) {
			String tradConfValeur = inputDynamicCommandeDTO.getValeurArtemis();
			if (StringUtils.isBlank(tradConfValeur) || StringUtils.equals(ConstantesTraduction.VALEUR_FONCTION_PSS, tradConfValeur) || StringUtils.equals(ConstantesTraduction.VALEUR_FONCTION_SIMPLE_PSS, tradConfValeur)) {
				if (lstValeurFonctionPSS.size() != 1) {
					serviceManager.getLoggerManager().warning(CLASSNAME, method,
							"La traduction " + inputDynamicCommandeDTO.getId() + " semble incorrect. On n'est pas capable d'identifier la valeur fonction dans une liste de longueur " + lstValeurFonctionPSS.size());
				} else {
					String strValeur = null;
					ValeurFonctionPSS valeurFonctionPSS = lstValeurFonctionPSS.get(0);
					if (StringUtils.equals(ConstantesTraduction.VALEUR_FONCTION_PSS, tradConfValeur)) {
						strValeur = valeurFonctionPSS.getValeurFonctionPSS();
					} else if (StringUtils.equals(ConstantesTraduction.VALEUR_FONCTION_SIMPLE_PSS, tradConfValeur)) {
						strValeur = valeurFonctionPSS.getValeurFonctionSimplePSS();
					} else {
						strValeur = valeurFonctionPSS.getValeurFonctionPSS();
						if (StringUtils.isBlank(strValeur)) {
							strValeur = valeurFonctionPSS.getValeurFonctionSimplePSS();
						}
					}
					valeurParametre = createParametre(inputDynamicCommandeDTO.getCle(), strValeur);
					serviceManager.getLoggerManager().finer(CLASSNAME, method, "La traduction " + inputDynamicCommandeDTO.getId() + " g�n�re le param�tre : " + valeurParametre.getCle() + " pour la ligne " + ligneCmdEfb.getRefLigneCde());
				}
			} else {
				valeurParametre = createParametre(inputDynamicCommandeDTO.getCle(), tradConfValeur);
				serviceManager.getLoggerManager().finer(CLASSNAME, method, "La traduction " + inputDynamicCommandeDTO.getId() + " g�n�re le param�tre : " + valeurParametre.getCle() + " pour la ligne " + ligneCmdEfb.getRefLigneCde());
			}
		}

		return valeurParametre;
	}

	public IServiceManager getServiceManager() {
		return serviceManager;
	}

	public void setServiceManager(IServiceManager serviceManager) {
		this.serviceManager = serviceManager;
	}

	public String getNdConserve() {
		return ndConserve;
	}

	public void setNdConserve(String ndConserve) {
		this.ndConserve = ndConserve;
	}

	public boolean isCasMetierOK() {
		return casMetierOK;
	}

	public void setCasMetierOK(boolean casMetierOK) {
		this.casMetierOK = casMetierOK;
	}

	public String getTypePorta() {
		return typePorta;
	}

	public void setTypePorta(String typePorta) {
		this.typePorta = typePorta;
	}

	public boolean isTypePortaOK() {
		return typePortaOK;
	}

	public void setTypePortaOK(boolean typePortaOK) {
		this.typePortaOK = typePortaOK;
	}

	public String getOffreArtemis() {
		return offreArtemis;
	}

	public void setOffreArtemis(String offreArtemis) {
		this.offreArtemis = offreArtemis;
	}

	public Map<String, ArrayList<String>> getCodeStatutOperation2RefLc() {
		return codeStatutOperation2RefLc;
	}

	public void setCodeStatutOperation2RefLc(Map<String, ArrayList<String>> codeStatutOperation2RefLc) {
		this.codeStatutOperation2RefLc = codeStatutOperation2RefLc;
	}

	public String getRefRDV() {
		return refRDV;
	}

	public void setRefRDV(String refRDV) {
		this.refRDV = refRDV;
	}

	public String getRefLigneCmdPrestRDV() {
		return refLigneCmdPrestRDV;
	}

	public void setRefLigneCmdPrestRDV(String refLigneCmdPrestRDV) {
		this.refLigneCmdPrestRDV = refLigneCmdPrestRDV;
	}

	public boolean isRefRDVOK() {
		return refRDVOK;
	}

	public void setRefRDVOK(boolean refRDVOK) {
		this.refRDVOK = refRDVOK;
	}

	public boolean isCmdAgregee() {
		return cmdAgregee;
	}

	public void setCmdAgregee(boolean cmdAgregee) {
		this.cmdAgregee = cmdAgregee;
	}
}