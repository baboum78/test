/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.commun.data;

import java.io.Serializable;

/**
 * Classe contenant une paire cl�-valeur. La cl� et la valeur doivent �tre
 * Serializable
 * 
 * @author rgvs7490
 */
public class KeyPair implements Serializable {

	private Object key;
	private Object value;

	/**
	 * Constructeur
	 * 
	 * @param key la cl�
	 * @param value la valeur
	 */
	public KeyPair(Object key, Object value) {
		this.key = key;
		this.value = value;
	}

	/**
	 * Retourne la cl�
	 * 
	 * @return la cl�
	 */
	public Object getKey() {
		return this.key;
	}

	/**
	 * Retourne la valeur
	 * 
	 * @return la valeur
	 */
	public Object getValue() {
		return this.value;
	}
}
