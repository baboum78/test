/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille;

import java.util.List;

import com.soliste.bolbec.commun.service.util.pagination.PaginationCommand;
import com.soliste.bolbec.commun.service.util.sort.SortCommand;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;

/**
 * Classe encapsulant une commande de chargement de corbeille
 * 
 * @author gdzd8490
 */
public class CorbeilleLoadCommand {

	/**
	 * Liste des identifiants correspondant aux crit�res de recherche
	 */
	private List<String> elementsIds = null;

	/**
	 * Liste des objets workflow charg�s en m�moire correspondant aux crit�res
	 * de recherche et � la commande de pagination
	 */
	private List<ItemData> loadedElements = null;

	/**
	 * Liste des informations � charger pour chaque loadedElement
	 */
	private List<String> infosToLoad = null;

	/**
	 * Commande de tri
	 */
	private SortCommand sortCommand = null;

	/**
	 * Commande de pagination
	 */
	private PaginationCommand paginationCommand = null;

	/**
	 * Liste des filtres d�terminant les elementsIds
	 */
	private List<FiltreDTO> dataFilters = null;

	/**
	 * Constructeur
	 * 
	 * @param infosToLoad
	 * les donn�es � collecter pour chaque �l�ment charg�
	 * @param dataFilters
	 * les filtres � appliquer pour r�cup�rer les �l�ments
	 * @param sortCommand
	 * la commande de tri
	 * @param paginationCommand
	 * la commande de pagination
	 */
	public CorbeilleLoadCommand(List<String> infosToLoad, List<FiltreDTO> dataFilters, SortCommand sortCommand, PaginationCommand paginationCommand) {
		this.infosToLoad = infosToLoad;
		this.dataFilters = dataFilters;
		this.sortCommand = sortCommand;
		this.paginationCommand = paginationCommand;
	}

	/**
	 * Retourne les filtres � appliquer pour r�cup�rer les �l�ments
	 * 
	 * @return les filtres � appliquer pour r�cup�rer les �l�ments
	 */
	public List<FiltreDTO> getDataFilters() {
		return dataFilters;
	}

	/**
	 * D�termine les filtres � appliquer pour r�cup�rer les �l�ments
	 * 
	 * @param dataFilters
	 * les filtres � appliquer pour r�cup�rer les �l�ments
	 */
	public void setDataFilter(List<FiltreDTO> dataFilters) {
		this.dataFilters = dataFilters;
	}

	/**
	 * Retourne la liste des identifiants correspondant aux crit�res de
	 * recherche
	 * 
	 * @return la liste des identifiants correspondant aux crit�res de recherche
	 */
	public List<String> getElementsIds() {
		return elementsIds;
	}

	/**
	 * D�termine la liste des identifiants correspondant aux crit�res de
	 * recherche
	 * 
	 * @param elementsIds
	 * la liste des identifiants correspondant aux crit�res de
	 * recherche
	 */
	public void setElementsIds(List<String> elementsIds) {
		this.elementsIds = elementsIds;
	}

	/**
	 * Retourne les donn�es � collecter pour chaque �l�ment charg�
	 * 
	 * @return les donn�es � collecter pour chaque �l�ment charg�
	 */
	public List<String> getInfosToLoad() {
		return infosToLoad;
	}

	/**
	 * D�termine les donn�es � collecter pour chaque �l�ment charg�
	 * 
	 * @param infosToLoad
	 * les donn�es � collecter pour chaque �l�ment charg�
	 */
	public void setInfosToLoad(List<String> infosToLoad) {
		this.infosToLoad = infosToLoad;
	}

	/**
	 * Retourne la liste des objets workflow charg�s en m�moire correspondant
	 * aux crit�res de recherche et � la commande de pagination
	 * 
	 * @return la liste des objets workflow charg�s en m�moire correspondant aux
	 * crit�res de recherche et � la commande de pagination
	 */
	public List<ItemData> getLoadedElements() {
		return loadedElements;
	}

	/**
	 * D�termine la liste des objets workflow charg�s en m�moire correspondant
	 * aux crit�res de recherche et � la commande de pagination
	 * 
	 * @param loadedElements
	 * la liste des objets workflow charg�s en m�moire correspondant
	 * aux crit�res de recherche et � la commande de pagination
	 */
	public void setLoadedElements(List<ItemData> loadedElements) {
		this.loadedElements = loadedElements;
	}

	/**
	 * Retourne la commande de pagination
	 * 
	 * @return la commande de pagination
	 */
	public PaginationCommand getPaginationCommand() {
		return paginationCommand;
	}

	/**
	 * D�termine la commande de pagination
	 * 
	 * @param paginationCommand
	 * la commande de pagination
	 */
	public void setPaginationCommand(PaginationCommand paginationCommand) {
		this.paginationCommand = paginationCommand;
	}

	/**
	 * Renvoie la commande de tri
	 * 
	 * @return la commande de tri
	 */
	public SortCommand getSortCommand() {
		return sortCommand;
	}

	/**
	 * D�termine la commande de tri
	 * 
	 * @param sortCommand
	 * la commande de tri
	 */
	public void setSortCommand(SortCommand sortCommand) {
		this.sortCommand = sortCommand;
	}
}
