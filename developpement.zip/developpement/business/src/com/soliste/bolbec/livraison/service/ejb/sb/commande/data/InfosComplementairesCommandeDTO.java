/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.commande.data;

import java.io.Serializable;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO contenant les infos compl�mentaires d'une commande (SAGIC)
 * 
 * @author rgvs7490
 */
public class InfosComplementairesCommandeDTO implements Serializable {

	private String id;
	private String xmlText;

	/**
	 * 
	 */
	InfosComplementairesCommandeDTO() {
	}

	public String getId() {
		return this.id;
	}

	void setId(String id) {
		this.id = id;
	}

	public String getXmlText() {
		return this.xmlText;
	}

	void setXmlText(String xmlText) {
		this.xmlText = xmlText;
	}
}
