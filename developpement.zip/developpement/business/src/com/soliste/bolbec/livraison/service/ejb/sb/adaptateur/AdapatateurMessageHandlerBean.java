package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur;

import java.io.Serializable;
import java.util.Map;

import javax.jms.JMSException;
import javax.jms.Message;
import javax.jms.ObjectMessage;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.jms.TextMessage;
import javax.naming.NamingException;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.commun.service.util.jms.QueueHelper;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.ic.InitialisationCommande;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * The Class AdapatateurMessageHandlerBean.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 */
public abstract class AdapatateurMessageHandlerBean extends AbstractMessageHandlerBean {

	/** The CLAS s_ name. */
	protected final static String CLASS_NAME = AdapatateurMessageHandlerBean.class.getName();

	/** The Constant TYPE_MESSAGE_INTRAITABLE. */
	private final static String TYPE_MESSAGE_INTRAITABLE = "Type de message intraitable";

	/** The Constant REJET_MESSAGE. */
	private final static String REJET_MESSAGE = "Rejet du message : \n";

	/** The Constant REJECT_QUEUE_NAME. */
	private static final String REJECT_QUEUE_NAME = "jms/rejectionQueue";

	/** The Constant QUEUE_FACTORY_NAME. */
	private static final String QUEUE_FACTORY_NAME = "jms/rejectionQueueConnectionFactory";

	/** The Constant JMS_PROP_DATE_REJET. */
	private static final String JMS_PROP_DATE_REJET = "DateRejet";

	/** The Constant JMS_PROP_CAUSE_REJET. */
	private static final String JMS_PROP_CAUSE_REJET = "CauseRejet";

	/** The Constant JMS_PROP_DIAGNOSTIC_REJET. */
	private static final String JMS_PROP_DIAGNOSTIC_REJET = "DiagnosticRejet";

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#rejectMessage(javax.jms.Message, java.lang.String, java.lang.String)
	 */
	@Override
	protected void rejectMessage(Message message, String cause, String diagnostic) {
		ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "rejectMessage", REJET_MESSAGE + message);
		QueueHelper queueHelper = new QueueHelper(QUEUE_FACTORY_NAME, REJECT_QUEUE_NAME);
		QueueConnection queueConnection = null;
		try {
			Serializable l_content;
			if (message instanceof TextMessage) {
				l_content = ((TextMessage) message).getText();
			} else {
				l_content = ((ObjectMessage) message).getObject();
			}
			queueConnection = queueHelper.createConnection();
			QueueSession queueSession = queueConnection.createQueueSession(true, 0);
			QueueSender queueSender = queueSession.createSender(queueHelper.getQueue());
			ObjectMessage msg = queueSession.createObjectMessage(l_content);
			msg.setLongProperty(JMS_PROP_DATE_REJET, System.currentTimeMillis());
			msg.setStringProperty(JMS_PROP_CAUSE_REJET, cause);
			msg.setStringProperty(JMS_PROP_DIAGNOSTIC_REJET, diagnostic);
			queueSender.send(msg);
			ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, "rejectMessage", "Message envoy� dans le fil de rejet : \n" + message);
		} catch (JMSException a_ex) {
			queueHelper.invalidate();
			throw new TechnicalBusinessException("RejectionException - Erreur JMS lors de l'envoi du message", a_ex);
		} catch (NamingException a_ex) {
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "rejectMessage", "Impossible d'utiliser le QueueHelper", a_ex);
			throw new TechnicalBusinessException("RejectionException - Impossible d'utiliser le QueueHelper", a_ex);
		} finally {
			QueueHelper.closeConnection(queueConnection);
		}

	}

	/**
	 * R�cup�re le message XML de l'Intention de Commande.
	 * 
	 * @param message the message
	 * 
	 * @return String
	 * 
	 * @throws InvalidJmsMessageException the invalid jms message exception
	 */
	@SuppressWarnings("unchecked")
	protected String getXmlMessage(Serializable message) throws InvalidJmsMessageException {
		if (!(message instanceof Map)) {
			throw new InvalidJmsMessageException(TYPE_MESSAGE_INTRAITABLE, message);
		}
		String result = ((Map<String, String>) message).get(Constantes.FIELD_MESSAGE);
		if (result == null) {
			throw new InvalidJmsMessageException(TYPE_MESSAGE_INTRAITABLE, message);
		}
		return result;
	}

	/**
	 * R�cup�re l'instance de localisation de l'Intention de Commande.
	 * 
	 * @param message the message
	 * 
	 * @return String
	 * 
	 * @throws InvalidJmsMessageException the invalid jms message exception
	 */
	@SuppressWarnings("unchecked")
	protected String getInstanceLocalisation(Serializable message) throws InvalidJmsMessageException {
		if (!(message instanceof Map)) {
			throw new InvalidJmsMessageException(TYPE_MESSAGE_INTRAITABLE, message);
		}
		String result = ((Map<String, String>) message).get(Constantes.FIELD_INSTANCE_LOCALISATION);
		if (result == null) {
			throw new InvalidJmsMessageException(TYPE_MESSAGE_INTRAITABLE, message);
		}
		return result;
	}

	/**
	 * Appel au m�canisme g�n�rique MG_InitialisationCommandeArtemis � fin de cr�er ou r�cuperer la commande en base d�s qu�elle est re�ue sur l�adaptateur
	 *
	 * @param a_message
	 * message � traiter
	 * @throws InvalidJmsMessageException
	 * dans le cas o� le message n'est pas valide
	 */
	public CommandeDTO getOrCreateCommande(Serializable a_message) throws InvalidJmsMessageException{
		CommandeDTO commandeDTO = null;
		String refExterne = "";
		try {
			refExterne = getRefExterne(a_message);
			//Faire appel au m�canisme g�n�rique MG_InitialisationCommandeArtemis avec la r�f�rence externe
			if (StringUtils.isNotBlank(refExterne)) {
				commandeDTO = InitialisationCommande.getOrCreateCommande(refExterne);
			}
		} catch (InvalidJmsMessageException ex) {
			ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, "processMessage", "Envoi d'une notification pour publication NON_PEC");
			throw ex;
		} catch (Exception e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "processMessage", "Erreur cr�ation de la commande " + refExterne, e);
			throw new InvalidJmsMessageException("ERREUR INTERNE", a_message);
		}
		return commandeDTO;
	}

	/**
	 * R�cup�re la r�ference externe de l'Intention de Commande. On ne veut pas faire une validation xml (ce sera fait apr�s) et
	 * on veut la recuperer m�me si le format du message est incorrecte --> pas de validations
	 *
	 * @param message message � traiter, avec diff�rents formats selon l'emetteur
	 *
	 * @return String
	 *
	 * @throws InvalidJmsMessageException dans le cas o� le message n'est pas valide
	 */
	public String getRefExterne (Serializable message) throws InvalidJmsMessageException {
		if (!(message instanceof Map)) {
			throw new InvalidJmsMessageException(TYPE_MESSAGE_INTRAITABLE, message);
		}

		Map<String, String> map = (Map<String, String>) message;
		String xmlMessage = map.get(Constantes.FIELD_MESSAGE);
		String balise = getBaliseRefExterne();
		String refExterne;

		try {
 			int positionMessage = xmlMessage.indexOf(balise) + balise.length();
			String baliseFin = getBaliseFin();
			refExterne = xmlMessage.substring(positionMessage, xmlMessage.indexOf(baliseFin, positionMessage));
			refExterne = creerRefExterne(message, refExterne);

			if (StringUtils.isBlank(refExterne)) {
				throw new InvalidJmsMessageException(TYPE_MESSAGE_INTRAITABLE + ": Impossible de r�cup�rer la reference externe", message);
			}
		} catch (Exception e) {
			throw new InvalidJmsMessageException(TYPE_MESSAGE_INTRAITABLE, message);
		}
		return refExterne;
	}

	/**
	 * Fait les modifications n�cessaires pour obtenir la refExterne � partir de la reference pass� en param�tre
	 *
	 * @param message message � traiter, avec diff�rents formats selon l'emetteur
	 * @param reference reference pour obtenir la ref Externe
	 *
	 * @return String
	 */
	public String creerRefExterne(Serializable message, String reference) {
		return reference;
	}

	/**
	 * R�cup�re la balise de la r�ference externe de l'Intention de Commande.
	 *
	 * @return String
	 */
	public abstract String getBaliseRefExterne();

	public String getBaliseFin() {
		return "\"";
	}

}
