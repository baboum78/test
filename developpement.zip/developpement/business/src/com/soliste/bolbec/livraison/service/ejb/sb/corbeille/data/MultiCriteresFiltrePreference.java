/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.io.Serializable;
import java.util.List;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/01/2014</TD><TD>FTE</TD><TD>EV-000268 : Crit�re de Filtre Multizones</TD></TR>
 * </TABLE><BR>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQ.10345</TD><TD>EP267 - Permettre aux utilisateurs des corbeilles de filtrer sur plusieurs zones SI � la fois. (EV268)</TD></TR>
 * </TABLE>
 * 
 */
public class MultiCriteresFiltrePreference implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 5822445574936501013L;
	
	private String id;
	private List<String> selectedValues;

	/**
	 * Constructeur
	 * 
	 * @param id
	 * @param texte
	 */
	public MultiCriteresFiltrePreference(String id, List<String> selectedValues) {
		this.id = id;
		this.selectedValues = selectedValues;
	}

	/**
	 * @return the id
	 */
	public String getId() {
		return this.id;
	}

	/**
	 * @return the selected values
	 */
	public List<String> getSelectedValues() {
		return this.selectedValues;
	}
}
