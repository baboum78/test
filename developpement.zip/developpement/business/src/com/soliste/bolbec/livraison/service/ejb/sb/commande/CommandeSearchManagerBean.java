/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.commande;

import com.soliste.bolbec.fwk.util.CollectionUtils;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.util.jdbc.JdbcUtils;
import com.soliste.bolbec.commun.service.util.jdbc.RowMapper;
import com.soliste.bolbec.commun.service.util.pagination.PaginatedList;
import com.soliste.bolbec.commun.service.util.pagination.PaginationCommand;
import com.soliste.bolbec.commun.service.util.pagination.PaginationUtil;
import com.soliste.bolbec.commun.service.util.sort.BasicSortTranslator;
import com.soliste.bolbec.commun.service.util.sort.SortTranslator;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.jndi.ServiceLocator;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.commande.data.CommandeSearchResultDTO;
import com.soliste.bolbec.livraison.service.util.sort.CommandeSortCommand;

/**
 * Impl�mentation de l'EJB session CommandeSearchManager.
 * 
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>11/07/2012</TD><TD>EBA</TD><TD>EV188 - Vente FTTH</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377: Commandes FTTE - Ajout du num�ro CLIP</TD></TR>
 * </TABLE>
 * 
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQ.4275</TD><TD>EP0101 - G�rer un indicateur permettant de savoir si un AVP ou une t�che manuelle est en cours de traitement sur une commande</TD></TR>
 * <TR><TD>REQ.4963</TD><TD>EP0142 - Utiliser le num�ro VIA � la place du ND, pour les commandes FTTH op�rateur</TD></TR>
 * </TABLE>
 * 
 * 
 * @author rgvs7490
 * @see CommandeSearchManager
 */
public class CommandeSearchManagerBean extends FwkSessionBean {

	/**
	 * serial version UID
	 */
	private static final long serialVersionUID = -4445988418336150028L;

	private static RowMapper<CommandeSearchResultDTO> commandeRowMapper = new RowMapper<CommandeSearchResultDTO>() {

		public CommandeSearchResultDTO mapRow(ResultSet rs) throws SQLException {
			String id = rs.getString(1);
			String etat = rs.getString(2);
			String statutCommande = rs.getString(3);
			long dateCreationAsLong = rs.getLong(4);
			Date dateCreation = DateUtils.getDatabaseDate(Long.valueOf(dateCreationAsLong));
			String client = rs.getString(5);
			String vendeur = rs.getString(6);
			long dateFinAsLong = rs.getLong(7);
			Date dateFin = null;
			if (dateFinAsLong > 0) {
				dateFin = DateUtils.getDatabaseDate(Long.valueOf(dateFinAsLong));
			}
			long dateValidationAsLong = rs.getLong(8);
			Date dateValidation = null;
			if (dateValidationAsLong > 0) {
				dateValidation = DateUtils.getDatabaseDate(Long.valueOf(dateValidationAsLong));
			}
			String refExterne = rs.getString(9);
			long dateDebutPriseAsLong = rs.getLong(10);
			Date dateDebutPrise = null;
			if (dateDebutPriseAsLong > 0) {
				dateDebutPrise = DateUtils.getDatabaseDate(Long.valueOf(dateDebutPriseAsLong));
			}
			String version = rs.getString(11);
			String jalon = rs.getString(12);
			String zoneSI = rs.getString(13);
			return new CommandeSearchResultDTO(id, etat, dateCreation, client, vendeur, dateFin, dateValidation, refExterne, dateDebutPrise, version, jalon, zoneSI, statutCommande);
		}
	};

	/** The dynamic commande row mapper. */
	private static RowMapper<String> dynamicCommandeRowMapper = new RowMapper<String>() {

		public String mapRow(ResultSet rs) throws SQLException {
			return rs.getString(1);
		}
	};

	private static SortTranslator commandeSortTranslator = new BasicSortTranslator() {

		protected String translateSortCriterion(String sortCriterion) {
			if (CommandeSortCommand.DATE_CREATION_SORT.equals(sortCriterion)) {
				return STRING_C_DATE_CREATION_BOLBEC;
			} else if (CommandeSortCommand.CLIENT_CONTRACTANT_SORT.equals(sortCriterion)) {
				return STRING_CL_DENOMINATION;
			} else if (CommandeSortCommand.DATE_FIN_SORT.equals(sortCriterion)) {
				return STRING_C_DATE_FIN_COMMANDE;
			} else if (CommandeSortCommand.ETAT_SORT.equals(sortCriterion)) {
				return STRING_E_LIBELLE;
			} else if (CommandeSortCommand.VENDEUR_SORT.equals(sortCriterion)) {
				return STRING_C_ID_VENDEUR;
			} else if (CommandeSortCommand.DATE_VALIDATION_SORT.equals(sortCriterion)) {
				return STRING_C_DATE_VALIDATION_FO;
			} else if (CommandeSortCommand.REFEXTERNE_SORT.equals(sortCriterion)) {
				return STRING_C_REF_EXTERNE;
			} else if (CommandeSortCommand.DATE_DEBUT_PRISE_SORT.equals(sortCriterion)) {
				return STRING_C_DATE_DEBUT_PRISE_COMMANDE_FO;
			} else if (CommandeSortCommand.DATE_DEBUT_PRISE_SORT.equals(sortCriterion)) {
				return STRING_C_DATE_DEBUT_PRISE_COMMANDE_FO;
			} else if (CommandeSortCommand.JALON_SORT.equals(sortCriterion)) {
				return STRING_LC_FK_REPEREPARJALON;
			} else if (CommandeSortCommand.ZONESI_SORT.equals(sortCriterion)) {
				return STRING_LC_FK_DANSZSIZONESI;
			} else if (CommandeSortCommand.STATUT_COMMANDE_SORT.equals(sortCriterion)) {
				return STRING_LC_FK_DANSZSIZONESI;
			} else {
				return STRING_C_ID;
			}
		}
	};
	private static final String QUERY_SUFFIX_SORT = " ORDER BY $SORT$";
	private static final String INNER_JOIN_TOUTES_COMMANDES = " INNER JOIN EtatCommande e ON c.fk_estDansEtatCommande = e.id INNER JOIN StatutCommande s ON c.fk_estDansStatutCommande = s.id ";
	private static final String INNER_JOIN_COMMANDES_NON_TERMINEES = " INNER JOIN EtatCommande e ON c.fk_estDansEtatCommande = e.id INNER JOIN StatutCommande s ON c.fk_estDansStatutCommande = s.id "
			+ " WHERE (e.id = 'COMP' OR e.id = 'CREEE' OR e.id = 'LIVR')";
	private static final String FILTER_COMMANDES_NON_TERMINEES = " AND (c.fk_estDansEtatCommande = 'COMP' OR c.fk_estDansEtatCommande = 'CREEE' OR c.fk_estDansEtatCommande = 'LIVR')";
	/* ****************** Recherche par DATE CREATION ******************** */
	private static final String QUERY_BY_DATE_CREATION = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_DATE_CREATION_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_WHERE_CLAUSE_BY_DATE_CREATION = " c.dateCreationArtemis >= ? AND c.dateCreationArtemis <= ?";
	private static final String QUERY_BY_DATE_CREATION_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_DATE_CREATION;
	private static final String QUERY_BY_DATE_CREATION_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_DATE_CREATION;
	/* ****************** Recherche par ND ******************** */
	private static final String QUERY_BY_ND = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, " + "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, "
			+ "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, " + "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c"
			+ " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_ND_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_WHERE_CLAUSE_BY_ND = " lc.ndFinder = ?";
	private static final String QUERY_BY_ND_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_ND;
	private static final String QUERY_BY_ND_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_ND;
	/* ****************** Recherche par ND ACCES LIVRAISON ******************** */
	private static final String QUERY_BY_ND_ACCES_LIVRAISON = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_ND_ACCES_LIVRAISON_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_WHERE_CLAUSE_BY_ND_ACCES_LIVRAISON = " lc.accesLivraison = ? AND lc.typeAccesLivraison = 'ND'";
	private static final String QUERY_BY_ND_ACCES_LIVRAISON_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_ND_ACCES_LIVRAISON;
	private static final String QUERY_BY_ND_ACCES_LIVRAISON_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_ND_ACCES_LIVRAISON;
	/* ****************** Recherche par CLIENT CONTRACTANT ******************** */
	private static final String QUERY_PREFIX_CLIENT_CONTRACTANT = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_PREFIX_CLIENT_CONTRACTANT_COUNT = "SELECT COUNT(DISTINCT c.id)" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_WHERE_CLAUSE_NOM_CLIENT_CONTRACTANT_ONLY = " cl.fk_appartientCategorieClient <> 'OP' AND UPPER(cl.denomination) LIKE ?";
	private static final String QUERY_WHERE_CLAUSE_PRENOM_CLIENT_CONTRACTANT_ONLY = " cl.fk_appartientCategorieClient <> 'OP' AND UPPER(cl.prenom) LIKE ?";
	private static final String QUERY_WHERE_CLAUSE_NOM_ET_PRENOM_CLIENT_CONTRACTANT = " cl.fk_appartientCategorieClient <> 'OP' AND UPPER(cl.denomination) LIKE ?" + "AND UPPER(cl.prenom) LIKE ?";
	private static final String QUERY_BY_NOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_NOM_CLIENT_CONTRACTANT_ONLY;
	private static final String QUERY_BY_NOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_NOM_CLIENT_CONTRACTANT_ONLY;
	private static final String QUERY_BY_PRENOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_PRENOM_CLIENT_CONTRACTANT_ONLY;
	private static final String QUERY_BY_PRENOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_PRENOM_CLIENT_CONTRACTANT_ONLY;
	private static final String QUERY_BY_NOM_PRENOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_NOM_ET_PRENOM_CLIENT_CONTRACTANT;
	private static final String QUERY_BY_NOM_PRENOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_NOM_ET_PRENOM_CLIENT_CONTRACTANT;
	/* ****************** Recherche par CLIENT LIVRE ******************** */
	private static final String QUERY_PREFIX_CLIENT_LIVRE = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON c.id = lc.idCommande"
			+ " INNER JOIN Client clLivre ON lc.fk_livreClient = clLivre.id ";
	private static final String QUERY_PREFIX_CLIENT_LIVRE_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON c.ID = lc.idCommande"
			+ " INNER JOIN Client clLivre ON lc.fk_livreClient = clLivre.id ";
	private static final String QUERY_WHERE_CLAUSE_PRENOM_CLIENT_LIVRE_ONLY = " UPPER(clLivre.prenom) LIKE ?";
	private static final String QUERY_WHERE_CLAUSE_NOM_CLIENT_LIVRE_ONLY = " UPPER(clLivre.denomination) LIKE ?";
	private static final String QUERY_WHERE_CLAUSE_NOM_ET_PRENOM_CLIENT_LIVRE = " UPPER(clLivre.denomination) LIKE ? AND UPPER(clLivre.prenom) LIKE ?";
	private static final String QUERY_BY_NOM_CLIENT_LIVRE_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_NOM_CLIENT_LIVRE_ONLY;
	private static final String QUERY_BY_NOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_NOM_CLIENT_LIVRE_ONLY;
	private static final String QUERY_BY_PRENOM_CLIENT_LIVRE_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_PRENOM_CLIENT_LIVRE_ONLY;
	private static final String QUERY_BY_PRENOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_PRENOM_CLIENT_LIVRE_ONLY;
	private static final String QUERY_BY_NOM_PRENOM_CLIENT_LIVRE_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_NOM_ET_PRENOM_CLIENT_LIVRE;
	private static final String QUERY_BY_NOM_PRENOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_NOM_ET_PRENOM_CLIENT_LIVRE;
	/* ****************** Recherche par ND PLP ******************** */
	private static final String QUERY_BY_NDPLP = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_NDPLP_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_WHERE_CLAUSE_BY_NDPLP = " lc.accesLivraisonOrigine = ? AND lc.typeAccesLivraisonOrigine = 'NDPLP'";
	private static final String QUERY_BY_ND_PLP_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_NDPLP;
	private static final String QUERY_BY_ND_PLP_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_NDPLP;
	/* ****************** Recherche par REFERENCE COMMANDE ******************** */
	private static final String QUERY_BY_ID = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, " + "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, "
			+ "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, " + "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c"
			+ " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_ID_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c";
	private static final String QUERY_WHERE_CLAUSE_BY_ID = " c.id = ?";
	private static final String QUERY_BY_ID_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_ID;
	private static final String QUERY_BY_ID_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_ID;
	/* ****************** Recherche par REFERENCE ETUDE NA ******************** */
	private static final String QUERY_BY_REF_NA = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_REF_NA_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String CBL = "CBL";
	private static final String QUERY_WHERE_CLAUSE_BY_REF_NA = " instancert.idexterne = ? AND rt.valeurConstante='" + CBL + "'";
	private static final String QUERY_BY_REF_NA_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " INNER JOIN ProcessusLC procLc ON procLc.Fk_Livrelignecommande=lc.id" + " INNER JOIN Processus proc ON proc.id=procLc.Fk_Estlivreparprocessus"
			+ " INNER JOIN ProcessusInstancert procInstancert ON procInstancert.Fk_Livreparprocessus=proc.id" + " INNER JOIN Instancert instancert ON instancert.id=procInstancert.Fk_Livrertinstancert"
			+ " INNER JOIN Ressourcetech rt ON rt.id=instancert.fk_esttyperessourcetech" + " WHERE " + QUERY_WHERE_CLAUSE_BY_REF_NA;
	private static final String QUERY_BY_REF_NA_COMMANDES_NON_TERMINEES = " INNER JOIN EtatCommande e ON c.fk_estDansEtatCommande = e.id INNER JOIN StatutCommande s ON c.fk_estDansStatutCommande = s.id "
			+ " INNER JOIN ProcessusLC procLc ON procLc.Fk_Livrelignecommande=lc.id" + " INNER JOIN Processus proc ON proc.id=procLc.Fk_Estlivreparprocessus" + " INNER JOIN ProcessusInstancert procInstancert ON procInstancert.Fk_Livreparprocessus=proc.id"
			+ " INNER JOIN Instancert instancert ON instancert.id=procInstancert.Fk_Livrertinstancert" + " INNER JOIN Ressourcetech rt ON rt.id=instancert.fk_esttyperessourcetech" + " WHERE (e.id = 'COMP' OR e.id = 'CREEE' OR e.id = 'LIVR') AND "
			+ QUERY_WHERE_CLAUSE_BY_REF_NA;
	/* ****************** Recherche par REFERENCE INTERVENTION ******************** */
	private static final String QUERY_BY_REF_INTERVENTION = QUERY_BY_ID;
	private static final String QUERY_WHERE_CLAUSE_BY_INTERVENTION = " interv.reference=?";
	private static final String QUERY_BY_REF_INTERVENTION_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_REF_INTERVENTION_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " INNER JOIN LienOpProgLdC opProgLdc ON opProgLdc.fk_appartientlignecommande=lc.id"
			+ " INNER JOIN OpProgrammee opProg ON opProg.id=opProgLdc.fk_requiereopprogrammee" + " INNER JOIN Intervention interv ON interv.id=opProg.fk_faitelorsintervention" + " WHERE " + QUERY_WHERE_CLAUSE_BY_INTERVENTION;
	private static final String QUERY_BY_REF_INTERVENTION_COMMANDES_NON_TERMINEES = " INNER JOIN EtatCommande e ON c.fk_estDansEtatCommande = e.id INNER JOIN StatutCommande s ON c.fk_estDansStatutCommande = s.id "
			+ " INNER JOIN LienOpProgLdC opProgLdc ON opProgLdc.fk_appartientlignecommande=lc.id" + " INNER JOIN OpProgrammee opProg ON opProg.id=opProgLdc.fk_requiereopprogrammee"
			+ " INNER JOIN Intervention interv ON interv.id=opProg.fk_faitelorsintervention" + " WHERE (e.id = 'COMP' OR e.id = 'CREEE' OR e.id = 'LIVR') AND " + QUERY_WHERE_CLAUSE_BY_INTERVENTION;
	/* ****************** Recherche par REFERENCE EXTERNE ******************** */
	private static final String QUERY_BY_REF_EXTERNE = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_REF_EXTERNE_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_WHERE_CLAUSE_BY_REF_EXTERNE = " UPPER(c.refExterne) = ?";
	private static final String QUERY_BY_REF_EXTERNE_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_REF_EXTERNE;
	private static final String QUERY_BY_REF_EXTERNE_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_REF_EXTERNE;
	/* ****************** Recherche par SIREN et NIC ******************** */
	private static final String QUERY_PREFIX_SIREN_AND_NIC = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON c.ID = lc.idCommande";
	private static final String QUERY_PREFIX_SIREN_AND_NIC_COUNT = "SELECT COUNT(DISTINCT c.id)" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON c.ID = lc.idCommande";
	private static final String QUERY_WHERE_CLAUSE_BY_NIC_ONLY = " cl.nic = ? ";
	private static final String QUERY_WHERE_CLAUSE_BY_SIREN_ONLY = " cl.siren = ? ";
	private static final String QUERY_WHERE_CLAUSE_BY_SIREN_AND_NIC = " cl.siren = ? AND cl.nic = ? ";
	private static final String QUERY_BY_NIC_ONLY_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_NIC_ONLY;
	private static final String QUERY_BY_NIC_ONLY_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_NIC_ONLY;
	private static final String QUERY_BY_SIREN_ONLY_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_SIREN_ONLY;
	private static final String QUERY_BY_SIREN_ONLY_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_SIREN_ONLY;
	private static final String QUERY_BY_SIREN_AND_NIC_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_SIREN_AND_NIC;
	private static final String QUERY_BY_SIREN_AND_NIC_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_SIREN_AND_NIC;
	/* ****************** Recherche par EPC id VIA ******************** */
	private static final String VIA = "VIA";
	private static final String QUERY_BY_EPC_ID_VIA = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_EPC_ID_VIA_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";

	private static final String QUERY_WHERE_CLAUSE_BY_EPC_ID_VIA = " lc.accesLivraison = ? AND lc.typeAccesLivraison='" + VIA + "'";
	private static final String QUERY_BY_EPC_ID_VIA_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_EPC_ID_VIA;
	private static final String QUERY_BY_EPC_ID_VIA_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_EPC_ID_VIA;
	/* ****************** Recherche par Num�ro CLIP ******************** */
	private static final String FTTE = "FTTE";
	private static final String QUERY_BY_NUMERO_CLIP = "SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande, " + "c.dateCreationArtemis AS dateCreation, cl.denomination AS client, "
			+ "c.idVendeur AS vendeur, c.dateFinCommande AS dateFin, " + "c.dateValidationFO AS dateValidation, c.refExterne AS refExterne, " + "c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, "
			+ "lc.fk_repereParJalon, lc.fk_danszsiZoneSI" + " FROM Commande c" + " INNER JOIN Client cl ON c.fk_commandeParClient = cl.id " + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";
	private static final String QUERY_BY_NUMERO_CLIP_COUNT = "SELECT count(DISTINCT c.ID) FROM Commande c" + " INNER JOIN LigneCommande lc ON lc.idCommande = c.id ";

	private static final String QUERY_WHERE_CLAUSE_BY_NUMERO_CLIP = " lc.accesLivraison = ? ";
	private static final String QUERY_BY_NUMERO_CLIP_TOUTES_COMMANDES = INNER_JOIN_TOUTES_COMMANDES + " WHERE " + QUERY_WHERE_CLAUSE_BY_NUMERO_CLIP;
	private static final String QUERY_BY_NUMERO_CLIP_COMMANDES_NON_TERMINEES = INNER_JOIN_COMMANDES_NON_TERMINEES + " AND " + QUERY_WHERE_CLAUSE_BY_NUMERO_CLIP;
	/* ****************** Recherche par R�f�rence traitement en masse ******************** */
	private static final String QUERY_BY_REFERENCE_TRAITEMENT_EN_MASSE = " SELECT DISTINCT c.id AS id, e.libelle AS etat, s.libelle AS statutCommande,c.dateCreationArtemis AS dateCreation, cl.denomination AS client, c.idVendeur AS vendeur, c.dateFinCommande AS dateFin,c.dateValidationFO AS dateValidation,    "
			+ " c.refExterne AS refExterne, c.dateDebutPriseCommandeFO AS dateDebutPrise, c.VersionArtemis AS version, lc.fk_repereParJalon, lc.fk_danszsiZoneSI       FROM Commande c INNER JOIN Client cl ON c.fk_commandeParClient = cl.id    "
			+ " INNER JOIN LigneCommande lc ON lc.idCommande = c.id       INNER JOIN EtatCommande e ON c.fk_estDansEtatCommande = e.id       INNER JOIN StatutCommande s ON c.fk_estDansStatutCommande = s.id    "
			+ " WHERE (c.id IN (select distinct(c1.id) from commande c1, lignecommande lc1, lignecmdcatalogue lca1,pssouhaite p1, dynamicpssouhaite d1 where c1.id = lc1.idcommande    "
			+ " and lc1.id = lca1.fk_estlignecommande and lca1.fk_decriteparpssouhaite = p1.id      and p1.id = d1.fk_pourpssouhaite       and lc1.fk_dependcontexte ='MUT_DSLAM'    "
			+ " and c1.fk_provientsystemeexterne like '%_FRONTAL'    and d1.cle='NumCampagneMutation'   " + " and d1.valeur=? " + "  union "
			+ "  select distinct(c2.id) from commande c2, lignecommande lc2, lignecmdmodparc lcmp2,pssouhaite p2, dynamicpssouhaite d2 where c2.id = lc2.idcommande    "
			+ "	    and lc2.id = lcmp2.fk_estlignecommande and  lcmp2.fk_decriteparpssouhaite = p2.id       and p2.id = d2.fk_pourpssouhaite       and lc2.fk_dependcontexte ='MUT_DSLAM'    "
			+ "	    and c2.fk_provientsystemeexterne like '%_FRONTAL'      and d2.cle='NumCampagneMutation'      and UPPER(d2.valeur)=?))";

	private static final String QUERY_BY_REFERENCE_TRAITEMENT_EN_MASSE_COUNT = " SELECT count(DISTINCT c.id) AS id FROM Commande c INNER JOIN Client cl ON c.fk_commandeParClient = cl.id    "
			+ " INNER JOIN LigneCommande lc ON lc.idCommande = c.id       INNER JOIN EtatCommande e ON c.fk_estDansEtatCommande = e.id       INNER JOIN StatutCommande s ON c.fk_estDansStatutCommande = s.id    "
			+ " WHERE (c.id IN (select distinct(c1.id) from commande c1, lignecommande lc1, lignecmdcatalogue lca1,pssouhaite p1, dynamicpssouhaite d1 where c1.id = lc1.idcommande    "
			+ " and lc1.id = lca1.fk_estlignecommande and lca1.fk_decriteparpssouhaite = p1.id      and p1.id = d1.fk_pourpssouhaite       and lc1.fk_dependcontexte ='MUT_DSLAM'    "
			+ " and c1.fk_provientsystemeexterne like '%_FRONTAL'      and d1.cle='NumCampagneMutation'   " + " and d1.valeur=? " + "  union "
			+ "  select distinct(c2.id) from commande c2, lignecommande lc2, lignecmdmodparc lcmp2,pssouhaite p2, dynamicpssouhaite d2 where c2.id = lc2.idcommande    "
			+ "	    and lc2.id = lcmp2.fk_estlignecommande and  lcmp2.fk_decriteparpssouhaite = p2.id       and p2.id = d2.fk_pourpssouhaite       and lc2.fk_dependcontexte ='MUT_DSLAM'    "
			+ "	    and c2.fk_provientsystemeexterne like '%_FRONTAL'     and d2.cle='NumCampagneMutation'      and UPPER(d2.valeur)=?))";

	private static final String QUERY_COMPLEMENT_DYNAMIC_COMMANDE = " SELECT valeur FROM dynamiccommande dc WHERE dc.fk_pourcommande = ? and dc.cle = ?";


	/* ****************** Autre? ******************** */
	private static final String STRING_C_DATE_CREATION_BOLBEC = "c.dateCreationArtemis";
	private static final String STRING_C_DATE_DEBUT_PRISE_COMMANDE_FO = "c.dateDebutPriseCommandeFO";
	private static final String STRING_C_DATE_FIN_COMMANDE = "c.dateFinCommande";
	private static final String STRING_C_DATE_VALIDATION_FO = "c.dateValidationFO";
	private static final String STRING_C_ID = "c.id";
	private static final String STRING_C_ID_VENDEUR = "c.idVendeur";
	private static final String STRING_C_REF_EXTERNE = "c.refExterne";
	private static final String STRING_CL_DENOMINATION = "cl.denomination";
	private static final String STRING_E_LIBELLE = "e.libelle";
	private static final String STRING_LC_FK_REPEREPARJALON = "lc.fk_repereParJalon";
	private static final String STRING_LC_FK_DANSZSIZONESI = "lc.fk_danszsiZoneSI";

	private DataSource dataSource;

	/**
	 * Recherche les commandes par client contractant. Le nom, ou le pr�nom, ou
	 * les deux doivent �tre fournis. Si les deux sont fournis, un ET logique
	 * est r�alis�. Le nom et le pr�nom sont compar�s avec ceux stock�s en base
	 * en ignorant la casse. une sous-cha�ne du pr�nom et du nom peuvent �tre
	 * pass�es (un like %valeur% est r�alis�)
	 * 
	 * @param nom
	 * le nom du client contractant, ou une partie de ce nom (ou null
	 * si on veut rechercher uniquement par pr�nom)
	 * @param prenom
	 * le pr�nom du client contractant, ou une partie de ce pr�nom
	 * (ou null si on veut rechercher uniquement par nom)
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByClientContractant(String nom, String prenom, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_PREFIX_CLIENT_CONTRACTANT_COUNT;
			String query = QUERY_PREFIX_CLIENT_CONTRACTANT;
			Object[] arguments;
			if ((nom == null) || (nom.trim().length() == 0)) {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_PRENOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_PRENOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_PRENOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES;
					query += QUERY_BY_PRENOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES;
				}
				arguments = new String[] { '%' + prenom.toUpperCase() + '%' };
			} else if ((prenom == null) || (prenom.trim().length() == 0)) {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_NOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_NOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_NOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES;
					query += QUERY_BY_NOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES;
				}
				arguments = new String[] { '%' + nom.toUpperCase() + '%' };
			} else {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_NOM_PRENOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_NOM_PRENOM_CLIENT_CONTRACTANT_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_NOM_PRENOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES;
					query += QUERY_BY_NOM_PRENOM_CLIENT_CONTRACTANT_TOUTES_COMMANDES;
				}
				arguments = new String[] { '%' + nom.toUpperCase() + '%', '%' + prenom.toUpperCase() + '%' };
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, arguments, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par client livr�. Le nom, ou le pr�nom, ou les
	 * deux doivent �tre fournis. Si les deux sont fournis, un ET logique est
	 * r�alis�. Le nom et le pr�nom sont compar�s avec ceux stock�s en base en
	 * ignorant la casse. une sous-cha�ne du pr�nom et du nom peuvent �tre
	 * pass�es (un like %valeur% est r�alis�)
	 * 
	 * @param nom
	 * le nom du client livr�, ou une partie de ce nom (ou null si on
	 * veut rechercher uniquement par pr�nom)
	 * @param prenom
	 * le pr�nom du client livr�, ou une partie de ce pr�nom (ou null
	 * si on veut rechercher uniquement par nom)
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByClientLivre(String nom, String prenom, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_PREFIX_CLIENT_LIVRE_COUNT;
			String query = QUERY_PREFIX_CLIENT_LIVRE;
			Object[] arguments;
			if ((nom == null) || (nom.trim().length() == 0)) {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_PRENOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_PRENOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_PRENOM_CLIENT_LIVRE_TOUTES_COMMANDES;
					query += QUERY_BY_PRENOM_CLIENT_LIVRE_TOUTES_COMMANDES;
				}
				arguments = new String[] { '%' + prenom.toUpperCase() + '%' };
			} else if ((prenom == null) || (prenom.trim().length() == 0)) {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_NOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_NOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_NOM_CLIENT_LIVRE_TOUTES_COMMANDES;
					query += QUERY_BY_NOM_CLIENT_LIVRE_TOUTES_COMMANDES;
				}
				arguments = new String[] { '%' + nom.toUpperCase() + '%' };
			} else {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_NOM_PRENOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_NOM_PRENOM_CLIENT_LIVRE_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_NOM_PRENOM_CLIENT_LIVRE_TOUTES_COMMANDES;
					query += QUERY_BY_NOM_PRENOM_CLIENT_LIVRE_TOUTES_COMMANDES;
				}
				arguments = new String[] { '%' + nom.toUpperCase() + '%', '%' + prenom.toUpperCase() + '%' };
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, arguments, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par date de cr�ation. Les deux dates doivent �tre
	 * fournies.
	 * 
	 * @param dateDebut
	 * la date minimale de cr�ation
	 * @param dateFin
	 * la date maximale de cr�ation
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByDateCreation(Date dateDebut, Date dateFin, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		Long dateDebutAsLong = DateUtils.getDatabaseDate(dateDebut.getTime());
		Date newDateFin = DateUtils.createNextDay(dateFin);
		Long dateFinAsLong = DateUtils.getDatabaseDate(newDateFin.getTime());
		try {
			String countQuery = QUERY_BY_DATE_CREATION_COUNT;
			String query = QUERY_BY_DATE_CREATION;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_DATE_CREATION_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_DATE_CREATION_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_DATE_CREATION_TOUTES_COMMANDES;
				query += QUERY_BY_DATE_CREATION_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { dateDebutAsLong, dateFinAsLong }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par identifiant. La recherche est effectu�e sur
	 * l'identifiant complet, en ignorant la casse
	 * 
	 * @param id
	 * l'identifiant
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchById(String id, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_ID_COUNT;
			String query = QUERY_BY_ID;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_ID_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_ID_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_ID_TOUTES_COMMANDES;
				query += QUERY_BY_ID_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { id }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par ND. La recherche est effectu�e sur le ND
	 * complet
	 * 
	 * @param nd
	 * le ND
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByNd(String nd, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_ND_COUNT;
			String query = QUERY_BY_ND;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_ND_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_ND_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_ND_TOUTES_COMMANDES;
				query += QUERY_BY_ND_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { nd }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par Acces Livraison o� le type est ND. La
	 * recherche est effectu�e sur le ND complet
	 * 
	 * @param ndAccesLivraison
	 * le ND
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByNdAccesLivraison(String ndAccesLivraison, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_ND_ACCES_LIVRAISON_COUNT;
			String query = QUERY_BY_ND_ACCES_LIVRAISON;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_ND_ACCES_LIVRAISON_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_ND_ACCES_LIVRAISON_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_ND_ACCES_LIVRAISON_TOUTES_COMMANDES;
				query += QUERY_BY_ND_ACCES_LIVRAISON_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { ndAccesLivraison }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par NDPLP. La recherche est effectu�e sur le
	 * NDPLP complet
	 * 
	 * @param ndplp
	 * le NDPLP
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByNdplp(String ndplp, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_NDPLP_COUNT;
			String query = QUERY_BY_NDPLP;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_ND_PLP_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_ND_PLP_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_ND_PLP_TOUTES_COMMANDES;
				query += QUERY_BY_ND_PLP_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { ndplp }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par r�f�rence externe. La recherche est effectu�e
	 * sur la r�f�rence compl�te, en ignorant la casse
	 * 
	 * @param refExterne
	 * la r�f�rence externe
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByRefExterne(String refExterne, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_REF_EXTERNE_COUNT;
			String query = QUERY_BY_REF_EXTERNE;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_REF_EXTERNE_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_REF_EXTERNE_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_REF_EXTERNE_TOUTES_COMMANDES;
				query += QUERY_BY_REF_EXTERNE_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { refExterne.toUpperCase() }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par r�f�rence d'�tude NA. La recherche est
	 * effectu�e sur la r�f�rence compl�te
	 * 
	 * @param refNa
	 * le r�f�rence d'�tude NA
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByRefNa(String refNa, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_REF_NA_COUNT;
			String query = QUERY_BY_REF_NA;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_REF_NA_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_REF_NA_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_REF_NA_TOUTES_COMMANDES;
				query += QUERY_BY_REF_NA_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { refNa }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par r�f�rence d'intervention. La recherche est
	 * effectu�e sur la r�f�rence compl�te
	 * 
	 * @param refIntervention
	 * le r�f�rence d'intervention
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByRefIntervention(String refIntervention, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_REF_INTERVENTION_COUNT;
			String query = QUERY_BY_REF_INTERVENTION;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_REF_INTERVENTION_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_REF_INTERVENTION_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_REF_INTERVENTION_TOUTES_COMMANDES;
				query += QUERY_BY_REF_INTERVENTION_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { refIntervention }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par Siren et/ou Nic. Le Siren, ou le Nic, ou les
	 * deux doivent �tre fournis. Si les deux sont fournis, un ET logique est
	 * r�alis�.
	 * 
	 * @param siren
	 * le Siren complet du client contractant (ou null si on veut
	 * rechercher uniquement par Nic)
	 * @param nic
	 * le Nic complet du client contractant (ou null si on veut
	 * rechercher uniquement par Siren)
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchBySirenAndNic(String siren, String nic, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_PREFIX_SIREN_AND_NIC_COUNT;
			String query = QUERY_PREFIX_SIREN_AND_NIC;
			Object[] arguments;
			if ((siren == null) || (siren.trim().length() == 0)) {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_NIC_ONLY_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_NIC_ONLY_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_NIC_ONLY_TOUTES_COMMANDES;
					query += QUERY_BY_NIC_ONLY_TOUTES_COMMANDES;
				}
				arguments = new String[] { nic };
			} else if ((nic == null) || (nic.trim().length() == 0)) {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_SIREN_ONLY_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_SIREN_ONLY_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_SIREN_ONLY_TOUTES_COMMANDES;
					query += QUERY_BY_SIREN_ONLY_TOUTES_COMMANDES;
				}
				arguments = new String[] { siren };
			} else {
				if (commandesNonTerminees) {
					countQuery += QUERY_BY_SIREN_AND_NIC_COMMANDES_NON_TERMINEES;
					query += QUERY_BY_SIREN_AND_NIC_COMMANDES_NON_TERMINEES;
				} else {
					countQuery += QUERY_BY_SIREN_AND_NIC_TOUTES_COMMANDES;
					query += QUERY_BY_SIREN_AND_NIC_TOUTES_COMMANDES;
				}
				arguments = new String[] { siren, nic };
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, arguments, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par r�f�rence d'intervention. La recherche est
	 * effectu�e sur la r�f�rence compl�te
	 * 
	 * @param epcIdVIA
	 * le r�f�rence d'intervention
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByEpcIdVIA(String epcIdVIA, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_EPC_ID_VIA_COUNT;
			String query = QUERY_BY_EPC_ID_VIA;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_EPC_ID_VIA_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_EPC_ID_VIA_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_EPC_ID_VIA_TOUTES_COMMANDES;
				query += QUERY_BY_EPC_ID_VIA_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { epcIdVIA }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par num�ro CLIP.
	 * 
	 * @param numeroCLIP
	 * le num�ro CLIP
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByNumeroCLIP(String numeroCLIP, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		try {
			String countQuery = QUERY_BY_NUMERO_CLIP_COUNT;
			String query = QUERY_BY_NUMERO_CLIP;
			if (commandesNonTerminees) {
				countQuery += QUERY_BY_NUMERO_CLIP_COMMANDES_NON_TERMINEES;
				query += QUERY_BY_NUMERO_CLIP_COMMANDES_NON_TERMINEES;
			} else {
				countQuery += QUERY_BY_NUMERO_CLIP_TOUTES_COMMANDES;
				query += QUERY_BY_NUMERO_CLIP_TOUTES_COMMANDES;
			}
			query += QUERY_SUFFIX_SORT;
			numeroCLIP = numeroCLIP.trim();
			return PaginationUtil.search(dataSource, countQuery, query, new Object[] { numeroCLIP.toUpperCase() }, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Recherche les commandes par R�f�rence traitement en masse .
	 * 
	 * @param referenceTraitementEnMasse
	 * la r�f�rence
	 * @param commandesNonTerminees
	 * true si on n'affiche que les commandes non termin�es, false si
	 * on affiche toutes les commandes
	 * @param paginationCommand
	 * la commande de pagination
	 * @param sortCommand
	 * la commande de tri
	 * @return la liste pagin�e des r�sultats
	 */
	public PaginatedList<CommandeSearchResultDTO> searchByReferenceTraitementEnMasse(String referenceTraitementEnMasse, boolean commandesNonTerminees, PaginationCommand paginationCommand, CommandeSortCommand sortCommand) {
		Object[] arguments;
		arguments = new String[2];
		arguments[0] = referenceTraitementEnMasse.toUpperCase();
		arguments[1] = referenceTraitementEnMasse.toUpperCase();
		try {
			String countQuery = QUERY_BY_REFERENCE_TRAITEMENT_EN_MASSE_COUNT;
			String query = QUERY_BY_REFERENCE_TRAITEMENT_EN_MASSE;
			if (commandesNonTerminees) {
				countQuery += FILTER_COMMANDES_NON_TERMINEES;
				query += FILTER_COMMANDES_NON_TERMINEES;
			}
			query += QUERY_SUFFIX_SORT;

			return PaginationUtil.search(dataSource, countQuery, query, arguments, paginationCommand, sortCommand, commandeSortTranslator, commandeRowMapper);
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * Compl�ment de la recherche pour compl�ter avec les informations de dynamic commande
	 *
	 * @param commandeId
	 * l'identifiant de la commande r�cup�r� en amont.
	 * @param dynamicCommande
	 * la dynamique commande
	 * @return la valeur de la dynamic commande
	 */
	public String searchComplementDynamicCommande(String commandeId, String dynamicCommande) {
		Object[] arguments;
		arguments = new String[2];
		arguments[0] = commandeId;
		arguments[1] = dynamicCommande;
		try {
			String query = QUERY_COMPLEMENT_DYNAMIC_COMMANDE;
			return CollectionUtils.getFirstOrNull(JdbcUtils.query(dataSource, query, arguments, dynamicCommandeRowMapper));
		} catch (SQLException e) {
			throw new EJBException(e);
		}
	}



	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			dataSource = ServiceLocator.getInstance().getDataSource(Constantes.DATASOURCE_NAME);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}
}
