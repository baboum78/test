package com.soliste.bolbec.livraison.service.ejb.sb.parametreDynamique;

import javax.ejb.EJBLocalObject;

/**
 * Interface locale de l'EJB Session ParametreDynamiqueManager
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/01/2012</TD><TD>GPA</TD><TD>EV-000168: Cr�ation de l'interface</TD></TR>
 * </TABLE>
 */
public interface ParametreDynamiqueManagerLocal extends EJBLocalObject, ParametreDynamiqueManager {

}
