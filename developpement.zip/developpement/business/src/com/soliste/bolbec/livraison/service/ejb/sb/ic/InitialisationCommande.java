package com.soliste.bolbec.livraison.service.ejb.sb.ic;

import java.util.List;

import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.EtatCommandeConstantes;

/**
 * M�canisme Generique Initialisation Commande Artemis MG_InitialisationCommandeArtemis
 * pour enregistrer dans la table COMMANDE les informations suivantes:
 *
 * -	Commande.ID : Identifiant Art�mis de la commande (selon l�algorithme AAMM+code instance+counter commande)
 * -	Commande.REFEXTERNE : r�f�rence de la commande fournie par l�application appelante et fournie au MG
 * -	Commande.ESTDANSETATCOMMANDE: FO_ACOMP (� compl�ter par le front office)
 * -	Commande.DATECREATIONBOLBEC: date courante du syst�me
 */
public class InitialisationCommande {

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = InitialisationCommande.class.getName();
	/** Classe contenant tous les services m�tier d'Artemis */
	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	private InitialisationCommande () {

	}
	/**
	 * M�thode pour cr�er ou r�cuperers la commande � partir de la refExterne fourni en param�tre
	 *
	 * @param refExterne
	 * @return
	 */
	public static CommandeDTO getOrCreateCommande(String refExterne) {
		CommandeDTO commandeDTO = null;

		List<CommandeDTO> commandeDTOList = serviceManager.getCommandeManager().findListCommandesNonAnnByRefExterne(refExterne);
		for (CommandeDTO commande : commandeDTOList) {
			if (commande.getEtatCommande() != null && EtatCommandeConstantes.FO_ACOMP.equals(commande.getEtatCommande().getId())) {
				commandeDTO = commande;
			}
		}

		if (commandeDTO == null) {
			try {
				commandeDTO = serviceManager.getInjectionCommandeManager().createCommande(refExterne);
				ServiceManager.getInstance().getLoggerManager().info(CLASSNAME, "createCommande", "Cr�ation de la commande " + commandeDTO.getId() + " pour la ref externe : " + refExterne);
			} catch (Exception e) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createCommande", "Erreur cr�ation de la commande " + refExterne, e);
			}
		}

		return commandeDTO;
	}
}
