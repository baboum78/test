package com.soliste.bolbec.livraison.service.ejb.sb.parametreDynamique;

import java.util.List;

import aps.ParametreDynamique;

import com.soliste.bolbec.livraison.service.model.ParametreDynamiqueDTO;

/**
 * Interface de l'EJB session ParametreDynamiqueManager
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/01/2012</TD><TD>GPA</TD><TD>EV-000168: Cr�ation de l'interface</TD></TR>
 * <TR><TD>13/02/2014</TD><TD>BPE</TD><TD>EV-000276: Enrichissement de l'interface</TD></TR>
 * </TABLE>
 */
public interface ParametreDynamiqueManager {

	/**
	 * R�cup�re une liste de param�tres dynamique pour une cl� et version donn�es
	 * 
	 * @param cle la cle du param�tre dynamique
	 * @param version la version du param�tre dynamique
	 * @return la liste de ParametreDynamiqueDTO
	 */
	List<ParametreDynamiqueDTO> findParametreDynamiqueParCleEtVersion(String cle, String version);

	/**
	 * R�cup�re une liste de param�tres dynamique pour une cl� donn�e
	 * 
	 * @param cle la cle du param�tre dynamique
	 * @return la liste de ParametreDynamiqueDTO
	 */
	List<ParametreDynamiqueDTO> findParametreDynamiqueParCle(String cle);

	/**
	 * Cr�e une nouvelle entit� param�treDynamique
	 * 
	 * @param parametreDynamique le param�tre dynamique � persister
	 * @return
	 */
	ParametreDynamique createParametreDynamique(final ParametreDynamiqueDTO parametreDynamique);

	/**
	 * Met � jour le param�treDynamique
	 * 
	 * @param parametreDynamique le param�tre dynamique � mettre � jour
	 */
	void updateParametreDynamique(final ParametreDynamiqueDTO parametreDynamique);

	/**
	 * Met � jour le param�treDynamique, ou cr�e s'il n'existe pas
	 * 
	 * @param parametreDynamique le param�tre dynamique � mettre � jour ou � cr�er
	 */
	void updateOrCreateParametreDynamique(final ParametreDynamiqueDTO parametreDynamique);

}
