package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>06/07/2018</TD><TD>BM</TD><TD>US-4117 : Ajout Op�rateur Immeuble Aff BLO</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs Operateur d'immeuble Absent
 */
public class CloturerAvpOpeImbAbs extends CloturerAvpCommande {

	private String operatorIMB;
	private final int NB_PARAM = 1;

	public CloturerAvpOpeImbAbs(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String operatorIMB) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.operatorIMB = operatorIMB;
	}

	public CloturerAvpOpeImbAbs(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData) {
		super(tacheId, info, causeEvenementId, date, itemData);
	}

	/**
	 * Getter of the operatorIMB
	 * @return the operatorIMB
	 */
	public String getOperatorIMB() {
		return operatorIMB;
	}

	/**
	 * Setter of the operatorIMB
	 * @param operatorIMB
	 */
	public void setOperatorIMB(String operatorIMB) {
		this.operatorIMB = operatorIMB;
	}

	public void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande){

		int cpt = 0;

		for (LigneCommandeDTO commandePrecedente : listeLigneCommande) {
			String operatorIMBLdC = commandePrecedente.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OPERATEUR_IMMEUBLE);
			if(StringUtils.isBlank(operatorIMB) && !StringUtils.isBlank(operatorIMBLdC) && !ConstantesDynamicLigneCommande.NON_RENSEIGNE.equals(operatorIMBLdC)){
				operatorIMB = operatorIMBLdC;
				cpt++;
			}
			if(cpt >= NB_PARAM){
				break;
			}
		}

		if(dataToSet != null){
			if(dataToSet.getOpImb() != null){
				operatorIMB = dataToSet.getOpImb();
			}
		}

	}
}
