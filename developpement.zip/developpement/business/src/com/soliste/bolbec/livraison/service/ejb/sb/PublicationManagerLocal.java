package com.soliste.bolbec.livraison.service.ejb.sb;

import javax.ejb.EJBLocalObject;

public interface PublicationManagerLocal extends PublicationManager, EJBLocalObject {

}
