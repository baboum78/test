package com.soliste.bolbec.livraison.service.ejb.sb;

import java.util.ArrayList;
import java.util.List;

import com.soliste.bolbec.livraison.service.model.CompteRenduDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.PublicationATraiterDTO;

/**
 * Interface metier de l'ejb <code>PublicationManagerSB</code><br/>
 * Permet de rechercher des entit�es li�es � une publication<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>30/04/2018</TD><TD>AJO</TD><TD>QC974 : VADOR</TD></TR>
 * </TABLE>
 * 
 * @author ajo
 * 
 */
public interface PublicationManager {

	/**
	 * Cr�� ou mets � jour le compte rendu
	 * 
	 * @param compteRendu
	 * @return le compteRendu cr��
	 */
	public void createPublicationATraiter(PublicationATraiterDTO publicationATraiterDTO);

	/**
	 * Mets � jour le l'�tat d'une liste de publications
	 * 
	 * @param publications
	 */
	void updatePublicationEtat(ArrayList<PublicationATraiterDTO> publications);

	/**
	 * Mets � jour la date de r�cup�ration d'une liste de publications
	 * 
	 * @param publications
	 */
	void updatePublicationDateRecuperation(ArrayList<PublicationATraiterDTO> publications);

	/**
	 * R�cup�re les publications pour un partenaire et ayant un certain �tat
	 * 
	 * @param codePArtenaire
	 * @param etat
	 */
	public ArrayList<PublicationATraiterDTO> findPublicationByApplicationEtEtat(String codePArtenaire, String etat);

	/**
	 * R�cup�re les publications pour un partenaire
	 * 
	 * @param codePArtenaire
	 */
	public ArrayList<PublicationATraiterDTO> findPublicationByApplication(String codePArtenaire);

	/**
	 * R�cup�re les publications pour �tant dans un certain �tat
	 * 
	 * @param etat
	 */
	public ArrayList<PublicationATraiterDTO> findPublicationByEtat(String etat);

}
