/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.seba;

import java.io.IOException;
import java.io.Serializable;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesxdsl.data.SebaDeclarations;

/**
 * @author unknown
 */
public class InjecteurCRSebaMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException {
		Document l_doc = getDocument(a_message);
		Element l_root = l_doc.getDocumentElement();
		ActivationParam l_ap = getActivationParam(l_root);
		return l_ap;
	}

	/**
	 * getActivationParam
	 * 
	 * @param a_root
	 * Element
	 * @return String
	 * @throws InvalidMessageException
	 */
	private ActivationParam getActivationParam(Element a_root) throws InvalidMessageException {
		// Affecter
		ActivationParam l_ap = getActivationParamForService(a_root, SebaDeclarations.TAG_SF_AFFECTER_EPT_XDSL);
		if (l_ap != null) {
			return l_ap;
		}
		// Configurer
		l_ap = getActivationParamForService(a_root, SebaDeclarations.TAG_SF_CONFIG_EPT_XDSL);
		if (l_ap != null) {
			return l_ap;
		}
		// Deconfig
		l_ap = getActivationParamForService(a_root, SebaDeclarations.TAG_SF_DECONFIG_EPT_XDSL);
		if (l_ap != null) {
			return l_ap;
		}
		// Liberer
		l_ap = getActivationParamForService(a_root, SebaDeclarations.TAG_SF_LIBERER_EPT_XDSL);
		if (l_ap != null) {
			return l_ap;
		}
		// MES
		l_ap = getActivationParamForService(a_root, SebaDeclarations.TAG_SF_MES_EPT_XDSL);
		if (l_ap != null) {
			return l_ap;
		}
		// MOD
		l_ap = getActivationParamForService(a_root, SebaDeclarations.TAG_SF_MODIFIER_EPT_XDSL);
		if (l_ap != null) {
			return l_ap;
		}
		// Obtenir
		l_ap = getActivationParamForService(a_root, SebaDeclarations.TAG_SF_OBTENIR_EPT_XDSL);
		if (l_ap != null) {
			return l_ap;
		}
		throw new InvalidMessageException("Message invalide, aucun tag XDSL !");
	}

	/**
	 * getActivationParamForService
	 * 
	 * @param a_root
	 * @param a_sf
	 * @return ?
	 * @throws InvalidMessageException
	 */
	private ActivationParam getActivationParamForService(Element a_root, String a_sf) throws InvalidMessageException {
		NodeList l_nodeList = a_root.getElementsByTagName(a_sf);
		if (l_nodeList.getLength() == 1) {
			Element l_node = (Element) l_nodeList.item(0);
			l_nodeList = l_node.getElementsByTagName(SebaDeclarations.TAG_NUM_ORDRE_COMMANDE);
			if (l_nodeList.getLength() == 1) {
				l_node = (Element) l_nodeList.item(0);
				Node l_textNode = l_node.getFirstChild();
				String l_idRequete = l_textNode.getNodeValue();
				return new ActivationParam(a_sf, l_idRequete);
			}
			throw new InvalidMessageException("Message invalide, tag " + SebaDeclarations.TAG_NUM_ORDRE_COMMANDE);
		}
		return null;
	}

	/**
	 * getDocument
	 * 
	 * @param a_message
	 * Serializable
	 * @return Document
	 * @throws InvalidMessageException
	 */
	private Document getDocument(Serializable a_message) throws InvalidMessageException {
		Document l_doc;
		try {
			l_doc = XmlUtils.getDocument((String) a_message, InjecteurCRSebaMessageHandlerBean.class.getResource(SebaDeclarations.SEBA_SERVICES_XSD).getFile());
		} catch (IOException ioe) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + ioe.getMessage(), a_message, ioe);
		} catch (SAXException saxe) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + saxe.getMessage(), a_message, saxe);
		}
		return l_doc;
	}
}