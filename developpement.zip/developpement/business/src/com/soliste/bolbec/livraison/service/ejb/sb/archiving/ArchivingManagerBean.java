package com.soliste.bolbec.livraison.service.ejb.sb.archiving;

import javax.ejb.SessionContext;

import com.soliste.bolbec.commun.service.ejb.sb.archiving.ArchivingManager;
import com.soliste.bolbec.commun.service.ejb.sb.archiving.IArchivingManagerRemote;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.jms.JmsUtils;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Impl�mentation du ArchivingManager livraison
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>18/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Archivage des WS</TD></TR>
 * </TABLE>
 */
public class ArchivingManagerBean extends FwkSessionBean implements ArchivingManager, IArchivingManagerRemote {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = -2943870870462696831L;

	/**
	 * Le nom de la classe
	 */
	private static final String CLASS_NAME = ArchivingManagerBean.class.getName();

	/**
	 * Le service manager
	 */
	protected static final IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	/**
	 * Fabrique de file d'archivage
	 */
	public static final String PUBLICATION_QUEUE_FACTORY = "java:comp/env/jms/archivingQueueConnectionFactory";

	/**
	 * File MQ d'archivage
	 */
	public static final String PUBLICATION_QUEUE_NAME = "java:comp/env/jms/archivingQueue";

	/**
	 * Contexte EJB associ� au bean.
	 */
	private SessionContext sessionContext;

	/**
	 * Retourne le contexte EJB associ� au bean.
	 * 
	 * @return le contexte EJB associ� au bean.
	 */
	public SessionContext getSessionContext() {
		return sessionContext;
	}

	/**
	 * R�cup�ration du contexte EJB associ� au bean.
	 */
	@Override
	public void setSessionContext(SessionContext sessionContext) {
		this.sessionContext = sessionContext;
	}

	/**
	 * @see </br>
	 * On fait le choix de ne pas archiver c�t� livraison.
	 * On pr�f�re publier vers le routeur pour archivage dans la base de donn�e.
	 */
	public void archiveToDatabase(Archivable archivable) throws ArchivingException {
		final String method = "archiveToDatabase";

		// V�rification de la validit� du archivable
		if (archivable == null) {
			SERVICE_MANAGER.getLoggerManager().warning(CLASS_NAME, method, "Archivable null => Abandon de l'archivage.");
			return;
		}

		// On envoie l'archivable vers le routeur
		try {
			SERVICE_MANAGER.getLoggerManager().finest(CLASS_NAME, method, "Publication de l'Archivable [" + archivable.toString() + "] dans la file " + PUBLICATION_QUEUE_NAME);
			JmsUtils.sendMessage(PUBLICATION_QUEUE_FACTORY, PUBLICATION_QUEUE_NAME, archivable, false);
		} catch (Exception e) {
			SERVICE_MANAGER.getLoggerManager().info(CLASS_NAME, method, "Transaction � annuler unitairement en cas de probl�me");
			getSessionContext().setRollbackOnly();
			throw new ArchivingException("NamingException lors de l'envoi dans la file de publication " + PUBLICATION_QUEUE_NAME, e);
		}
	}

}
