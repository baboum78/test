package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement;

import java.util.Date;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.ConstantesAPI;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.util.GeneratorManager;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.api.utils.NoteUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Note;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.NoteType;
import com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon.CochisePharaonManager;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.ProcessusTraitement;
import com.soliste.bolbec.livraison.service.model.BlocNoteDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.publication.INotificationGeneriqueManager;
import com.soliste.bolbec.livraison.service.publication.Notification;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.PublicationConstantes;

/**
 * Traitement des ressources Note
 * 
 * @author mfayd
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/12/2015</TD><TD>MFA</TD><TD>Initialisation NoteRessourceTraitement</TD></TR>
 * <TR><TD>04/01/2016</TD><TD>KWE</TD><TD>Modification NoteRessourceTraitement + ajout commentaires</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>API REST</TD></TR>
 * </TABLE>
 **/
public class NoteRessourceTraitement {
	/**
	 * Manager Utils
	 */
	private final CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
	private final ILoggerManager LOGGER_MANAGER = ServiceManager.getInstance().getLoggerManager();
	private final CochisePharaonManager COCHISE_MANAGER = ServiceManager.getInstance().getCochisePharaonManager();
	private final INotificationGeneriqueManager NOTIFICATION_GENERIQUE_MANAGER = ServiceManager.getInstance().getNotificationGeneriqueManager();
	private final String CLASS_NAME = getClass().getSimpleName();
	private static final int TAILLE_MAX_INFO_NOTES = 2000;
	private static final int STATUS_CREATION = 201;

	/**
	 * NoteRessourceTraitement
	 */
	public NoteRessourceTraitement() {

	}

	/**
	 * getNote Retourne la note d'id idNote pour la commande d'id idCommande
	 * 
	 * @param idCommande
	 * @param idNote
	 * @param context
	 * @return
	 */

	public Response getNote(String idCommande, String idNote, @SuppressWarnings("unused") MessageContext context) {

		if (idCommande == null) {
			throw APIExceptionEnum.noteorderidnotfound.createAPIException();
		}
		BlocNoteDTO blocNote = COMMANDE_MANAGER.findBlocNoteById(idNote);
		// 404 not found --> pas de note
		if (blocNote == null) {
			throw APIExceptionEnum.notenotfound.createAPIException(idNote);
		}

		String commandeId = blocNote.getCommandeId();
		// Si la note ne correspond pas � la commande alors la ressource est NOT_FOUND
		if (!idCommande.equals(commandeId)) {
			// ERR 404
			throw APIExceptionEnum.noteandordernotlinked.createAPIException(idNote, idCommande);
		}

		// Sinon on contruit la note de sortie
		Note note = new Note();
		note.setId(idNote);
		if (blocNote.getEcritParAgent() != null) {
			note.setAuthor(blocNote.getEcritParAgent().getId());
		}

		note.setText(blocNote.getInfo());
		note.setDate(DateUtils.toCalendar(blocNote.getDateCreation()));

		note.setType(NoteType.serviceOrder);
		return Response.ok(note).build();
	}

	/**
	 * createNote Cr�er une nouvelle note pour la commande d'id idCommande
	 * 
	 * @param idCommande
	 * @param note
	 * @param context
	 * @return
	 */
	public Response createNote(String idCommande, Note note, MessageContext context) {
		String methode = "createNote";
		LOGGER_MANAGER.fine(CLASS_NAME, methode, "Cr�ation d'une Note pour la commande (id = " + idCommande + ")");

		if (NoteType.unknown.equals(note.getType())) {
			throw APIExceptionEnum.notebadstatus.createAPIException();
		}

		if (idCommande == null) {
			throw APIExceptionEnum.noteorderidnotfound.createAPIException();
		}

		// erreur 404
		CommandeDTO commande = COMMANDE_MANAGER.findCommandeById(idCommande);

		if (commande == null) {
			throw APIExceptionEnum.noteorderdosnotexists.createAPIException(idCommande);
		}

		// erreur 400
		if (StringUtils.isBlank(note.getText())) {
			throw APIExceptionEnum.notecommentnull.createAPIException(note.getId());
		}

		BlocNoteDTO blocNote;
		if (note.getId() == null) {
			blocNote = new BlocNoteDTO(GeneratorManager.getInstance().generateKey());
		} else {
			throw APIExceptionEnum.notealreadyexists.createAPIException(note.getId());
		}

		blocNote.setCommandeId(idCommande);

		final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
		final AgentDTO agentInfo = new AgentDTO(agentName);
		blocNote.setEcritParAgent(agentInfo);
		note.setAuthor(agentName);
		Date date = new Date();
		blocNote.setDateCreation(date);
		blocNote.setInfo(note.getText());
		note.setDate(DateUtils.toCalendar(date));
		note.setId(blocNote.getId());
		note.setType(NoteType.serviceOrder);

		final WfUser wfU = new WfUser(agentInfo.getId());

		// On cree la blockNote

		try {
			COMMANDE_MANAGER.createBlocNote(blocNote);
		} catch (Exception e) {
			throw APIExceptionEnum.noteerrorcreating.createAPIException(note.getId());
		} finally {
			// US-678 Notification pour action API d'ajouter notes
			NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A,NotificationGeneriqueConstantes.TYPE_NOTE,idCommande,note.getId(),agentInfo.getId(),idCommande);
			NOTIFICATION_GENERIQUE_MANAGER.emettreNotification(ng);
		}

		final EvtDTO evtDTO = ProcessusTraitement.createEvtNoteSurCommande(idCommande, Constantes.CST_CREATION_NOTE + blocNote.getId(), wfU, blocNote.getDateCreation().getTime() / 1000);
		Notification notification = COCHISE_MANAGER.creerNotificationAjoutNote(PublicationConstantes.PUB_COCHISE_PHARAON_NOTE_CMD, commande, evtDTO.getId());
		if (notification != null) {
			COCHISE_MANAGER.publierMessage(notification);
		}
		return Response.status(STATUS_CREATION).entity(note).build();
	}

	public Response modifyNote(String idCommande, String idNote, Note note, MessageContext context) {
		String methode = "modifyNote";
		LOGGER_MANAGER.fine(CLASS_NAME, methode, "Cr�ation d'une Note pour la commande (id = " + idCommande + ")");

		validate(note);

		// erreur 404
		CommandeDTO commande = COMMANDE_MANAGER.findCommandeById(idCommande);

		if (commande == null) {
			throw APIExceptionEnum.noteorderidnotfound.createAPIException("");
		}
		if (NoteType.unknown.equals(note.getType())) {
			throw APIExceptionEnum.notebadstatus.createAPIException();
		}

		// erreur 400
		if (StringUtils.isBlank(note.getText())) {
			throw APIExceptionEnum.notecommentnull.createAPIException(idNote);
		}

		BlocNoteDTO blocNote = COMMANDE_MANAGER.findBlocNoteById(idNote);
		if (blocNote == null) {
			throw APIExceptionEnum.notenotfound.createAPIException(idNote);
		}
		if (!NoteUtils.EstLaNoteLaPlusRecente(blocNote, idNote, idCommande)) {
			throw APIExceptionEnum.notenotoldest.createAPIException();
		}

		blocNote.setCommandeId(idCommande);

		final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
		final AgentDTO agentInfo = new AgentDTO(agentName);
		blocNote.setEcritParAgent(agentInfo);
		note.setAuthor(agentName);
		Date date = new Date();
		blocNote.setDateCreation(date);
		blocNote.setInfo(note.getText());
		note.setDate(DateUtils.toCalendar(date));
		note.setId(idNote);
		note.setType(NoteType.serviceOrder);

		try {
			COMMANDE_MANAGER.updateBlocNote(blocNote);
		} catch (Exception e) {
			e.printStackTrace();
			throw APIExceptionEnum.noteerrorupdating.createAPIException(idNote);
		} finally {
			// US-678 Notification pour action API de modifier notes
			NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A,NotificationGeneriqueConstantes.TYPE_NOTE,idCommande,note.getId(),agentInfo.getId(),idCommande);
			NOTIFICATION_GENERIQUE_MANAGER.emettreNotification(ng);
		}


		final WfUser wfU = new WfUser(agentInfo.getId());
		final EvtDTO evtDTO = ProcessusTraitement.createEvtNoteSurCommande(idCommande, Constantes.CST_MODIF_NOTE + blocNote.getId(), wfU, blocNote.getDateCreation().getTime() / 1000L);
		Notification notification = COCHISE_MANAGER.creerNotificationAjoutNote(PublicationConstantes.PUB_COCHISE_PHARAON_NOTE_CMD, commande, evtDTO.getId());
		if (notification != null) {
			COCHISE_MANAGER.publierMessage(notification);
		}

		return Response.ok(note).build();
	}

	public void validate(Note note) {

		if (note.getText().length() > TAILLE_MAX_INFO_NOTES) {
			throw APIExceptionEnum.noteerrorvalidating.createAPIException();
		}
		return;
	}
}