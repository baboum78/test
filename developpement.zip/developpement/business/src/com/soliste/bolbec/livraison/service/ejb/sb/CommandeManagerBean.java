/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.RemoveException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.commun.service.model.ZoneGeographiqueDTO;
import com.soliste.bolbec.commun.service.model.ZoneSiDTO;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.NumberUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.commande.data.InfosComplementairesCommandeDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.commande.data.InfosComplementairesCommandeDTOFactory;
import com.soliste.bolbec.livraison.service.model.AccesClientDTO;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.BlocNoteDTO;
import com.soliste.bolbec.livraison.service.model.CasMetierDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.CompletudeRegroupementDTO;
import com.soliste.bolbec.livraison.service.model.ContexteDTO;
import com.soliste.bolbec.livraison.service.model.EpCommercialDTO;
import com.soliste.bolbec.livraison.service.model.EtatLigneCdeDTO;
import com.soliste.bolbec.livraison.service.model.InstanceLocalisationDTO;
import com.soliste.bolbec.livraison.service.model.InstanceOgDTO;
import com.soliste.bolbec.livraison.service.model.InterferenceDTO;
import com.soliste.bolbec.livraison.service.model.InterlocuteurDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.JalonDTO;
import com.soliste.bolbec.livraison.service.model.LienOpProgLdcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdCatalogueDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdModParcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdSupParcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.PrestationAFacturerDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusLcDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RapportInterventionDTO;
import com.soliste.bolbec.livraison.service.model.RepartiteurDTO;
import com.soliste.bolbec.livraison.service.model.ResponsabiliteDTO;
import com.soliste.bolbec.livraison.service.model.StatutCommandeDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatRegulDTO;
import com.soliste.bolbec.livraison.service.model.TypeOpPonctuellesDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.AccesClient;
import aps.AccesClientHome;
import aps.Adresse;
import aps.AdresseHome;
import aps.BlocNote;
import aps.BlocNoteHome;
import aps.Client;
import aps.ClientHome;
import aps.Commande;
import aps.CommandeHome;
import aps.CompletudeRegroupement;
import aps.CompletudeRegroupementHome;
import aps.DynamicCommande;
import aps.DynamicCommandeHome;
import aps.DynamicEPCommercial;
import aps.DynamicEPCommercialHome;
import aps.DynamicIntervention;
import aps.DynamicInterventionHome;
import aps.DynamicLigneCommande;
import aps.DynamicLigneCommandeHome;
import aps.DynamicPsSouhaite;
import aps.DynamicPsSouhaiteHome;
import aps.DynamicRapportIntervention;
import aps.DynamicRapportInterventionHome;
import aps.EPCommercial;
import aps.EPCommercialHome;
import aps.EtatCommandeConstantes;
import aps.EtatInterventionConstantes;
import aps.InstanceFT;
import aps.InstanceFTHome;
import aps.InstanceOG;
import aps.InstanceOGHome;
import aps.Interference;
import aps.InterferenceHome;
import aps.Intervention;
import aps.InterventionHome;
import aps.LienOpProgLdC;
import aps.LienOpProgLdCHome;
import aps.LigneCmdCatalogue;
import aps.LigneCmdCatalogueHome;
import aps.LigneCmdModParc;
import aps.LigneCmdModParcHome;
import aps.LigneCmdSupParc;
import aps.LigneCmdSupParcHome;
import aps.LigneCommande;
import aps.LigneCommandeHome;
import aps.MessageSagicInHome;
import aps.OpProgrammee;
import aps.OpProgrammeeHome;
import aps.PrestationAFacturer;
import aps.PrestationAFacturerHome;
import aps.Processus;
import aps.ProcessusLC;
import aps.ProcessusLCHome;
import aps.PsSouhaite;
import aps.PsSouhaiteHome;
import aps.RapportIntervention;
import aps.RapportInterventionHome;
import aps.SappuieSur;
import aps.SappuieSurHome;
import aps.Tache;
import aps.TacheHome;
import aps.TransitSystStat;
import aps.TransitSystStatHome;
import aps.TransitSystStatRegul;
import aps.TransitSystStatRegulHome;

/**
 * Impl�mentation de l'EJB session <code>CommandeManager</code>.
 * 
 * @see {@link com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager}
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>05/05/2010</TD><TD>DBA</TD><TD>EV-000029: Correction probl�me null pointeur</TD></TR>
 * <TR><TD>07/06/2010</TD><TD>DBA</TD><TD>EV-000067: Nouvelle m�thode pour faire la persistance du cas metier</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>20/10/2010</TD><TD>YTR</TD><TD>IRMA_232 : optimisation m�thode isMarked</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>GPA</TD><TD>Suppression des appels � la classe IdGenerator</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>28/02/2010</TD><TD>BPE</TD><TD>EV-000089: Ajout de la m�thode updateOpProgrammeeTypeOPProgrammee</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>22/12/2011</TD><TD>GPA</TD><TD>EV-000174: Cr�ation des m�thodes findPsSouhaiteByLigneCommandeCR() et findEpCommercialByLigneCommandeSU()</TD></TR>
 * <TR><TD>07/05/2012</TD><TD>FTE</TD><TD>Ajout de la mise � jour de la r�f�rence d'intervention dans updateIntervention()</TD></TR>
 * <TR><TD>12/07/2012</TD><TD>EBA</TD><TD>Ajout du finder findInterventionPlusRecenteByLdc</TD></TR>
 * <TR><TD>19/10/2010</TD><TD>EBA</TD><TD>EV000183 - EB-0058 : Apostrof Corbeille IHM BIS suite � remarque client </TD></TR>
 * <TR><TD>14/02/2013</TD><TD>EBA</TD><TD>G8R2CI � EV-000210 : Ajout de la m�thode isFTTHEntreprise</TD></TR>
 * <TR><TD>27/05/2013</TD><TD>GPA</TD><TD>G8R2C2 � Tech : Passage du type de transaction des m�thodes des EJB Remote en RequiresNew</TD></TR>
 * <TR><TD>29/05/2013</TD><TD>EBA</TD><TD>G8R2C2 BackOffice : Cr�ation methodes necessaires avec NewTransaction</TD></TR>
 * <TR><TD>29/05/2013</TD><TD>EBA</TD><TD>G8R2C2 BackOffice : Impact suppression des contraintes table INTERFERENCE</TD></TR>
 * <TR><TD>23/09/2013</TD><TD>BPE</TD><TD>G8R2C3 � EV-000264 : Ajout de la m�thode findCommandeByRefeRDV</TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000304 : Fluidification ADSL vers Fibre </TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000298 - R�siliation acc�s FTTH en cas de porta sortante </TD></TR>
 * <TR><TD>22/07/2016</TD><TD>SDO</TD><TD>EV-392 - D�commissionnement G8</TD></TR>
 * <TR><TD>18/01/2018</TD><TD>AJO</TD><TD>QC-937 : Gestion de la quantit� des prestations</TD></TR>
 * </TABLE>
 */
public class CommandeManagerBean extends FwkSessionBean implements CommandeManager, ICommandeManagerRemote {

	/**
	 * Serialization UID
	 */
	private static final long serialVersionUID = 1648916375821647382L;

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = CommandeManagerBean.class.getName();

	/** The commande home. */
	private CommandeHome commandeHome;

	/** The dynamic commande home. */
	private DynamicCommandeHome dynamicCommandeHome;

	/** The ligne commande home. */
	private LigneCommandeHome ligneCommandeHome;

	/** The dynamic ligne commande home. */
	private DynamicLigneCommandeHome dynamicLigneCommandeHome;

	/** The ligne cmd mod parc home. */
	private LigneCmdModParcHome ligneCmdModParcHome;

	/** The ligne cmd sup parc home. */
	private LigneCmdSupParcHome ligneCmdSupParcHome;

	/** The ligne cmd catalogue home. */
	private LigneCmdCatalogueHome ligneCmdCatalogueHome;

	/** The processus lc home. */
	private ProcessusLCHome processusLCHome;

	/** The ep commercial home. */
	private EPCommercialHome epCommercialHome;

	/** The dynamic ep commercial home. */
	private DynamicEPCommercialHome dynamicEPCommercialHome;

	/** The ps souhaite home. */
	private PsSouhaiteHome psSouhaiteHome;

	/** The dynamic ps souhaite home. */
	private DynamicPsSouhaiteHome dynamicPsSouhaiteHome;

	/** The interference home. */
	private InterferenceHome interferenceHome;

	/** The transit syst stat home. */
	private TransitSystStatHome transitSystStatHome;

	/** The transit syst stat regul home. */
	private TransitSystStatRegulHome transitSystStatRegulHome;

	/** The completude regroupement home. */
	private CompletudeRegroupementHome completudeRegroupementHome;

	/** The instance og home. */
	private InstanceOGHome instanceOGHome;

	/** The intervention home. */
	private InterventionHome interventionHome;

	/** The dynamic intervention home. */
	private DynamicInterventionHome dynamicInterventionHome;

	/** The op programmee home. */
	private OpProgrammeeHome opProgrammeeHome;

	/** The lien op prog ld c home. */
	private LienOpProgLdCHome lienOpProgLdCHome;

	/** The rapport intervention home. */
	private RapportInterventionHome rapportInterventionHome;

	/** The dynamic rapport intervention home. */
	private DynamicRapportInterventionHome dynamicRapportInterventionHome;

	/** The s'appuie sur home. */
	private SappuieSurHome sAppuieSurHome;

	/** The acces client home. */
	private AccesClientHome accesClientHome;

	/** The client home. */
	private ClientHome clientHome;

	/** The adresse home. */
	private AdresseHome adresseHome;

	/** The instanceFT home. */
	private InstanceFTHome instanceFTHome;

	/** The blocNote Home *. */
	private BlocNoteHome blocNoteHome;

	/** The prestationAFacturer Home *. */
	private PrestationAFacturerHome prestationAFacturerHome;

	/** The tacheHome Home *. */
	private TacheHome tacheHome;

	/** The message sagic in home. */
	private MessageSagicInHome messageSagicInHome;

	/** Le service manager */
	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			commandeHome = getEntityHome(CommandeHome.class);
			dynamicCommandeHome = getEntityHome(DynamicCommandeHome.class);
			ligneCommandeHome = getEntityHome(LigneCommandeHome.class);
			dynamicLigneCommandeHome = getEntityHome(DynamicLigneCommandeHome.class);
			ligneCmdModParcHome = getEntityHome(LigneCmdModParcHome.class);
			ligneCmdSupParcHome = getEntityHome(LigneCmdSupParcHome.class);
			ligneCmdCatalogueHome = getEntityHome(LigneCmdCatalogueHome.class);
			processusLCHome = getEntityHome(ProcessusLCHome.class);
			dynamicEPCommercialHome = getEntityHome(DynamicEPCommercialHome.class);
			epCommercialHome = getEntityHome(EPCommercialHome.class);
			psSouhaiteHome = getEntityHome(PsSouhaiteHome.class);
			dynamicPsSouhaiteHome = getEntityHome(DynamicPsSouhaiteHome.class);
			interferenceHome = getEntityHome(InterferenceHome.class);
			transitSystStatHome = getEntityHome(TransitSystStatHome.class);
			transitSystStatRegulHome = getEntityHome(TransitSystStatRegulHome.class);
			completudeRegroupementHome = getEntityHome(CompletudeRegroupementHome.class);
			instanceOGHome = getEntityHome(InstanceOGHome.class);
			interventionHome = getEntityHome(InterventionHome.class);
			dynamicInterventionHome = getEntityHome(DynamicInterventionHome.class);
			opProgrammeeHome = getEntityHome(OpProgrammeeHome.class);
			lienOpProgLdCHome = getEntityHome(LienOpProgLdCHome.class);
			rapportInterventionHome = getEntityHome(RapportInterventionHome.class);
			dynamicRapportInterventionHome = getEntityHome(DynamicRapportInterventionHome.class);
			sAppuieSurHome = getEntityHome(SappuieSurHome.class);
			accesClientHome = getEntityHome(AccesClientHome.class);
			clientHome = getEntityHome(ClientHome.class);
			adresseHome = getEntityHome(AdresseHome.class);
			instanceFTHome = getEntityHome(InstanceFTHome.class);
			blocNoteHome = getEntityHome(BlocNoteHome.class);
			prestationAFacturerHome = getEntityHome(PrestationAFacturerHome.class);
			tacheHome = getEntityHome(TacheHome.class);
			messageSagicInHome = getEntityHome(MessageSagicInHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	// --------------------------------------------------------------
	// COMMANDE et DYNAMIC_COMMANDE
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getCommande(java.lang.String)
	 */
	public CommandeDTO getCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getCommande", "Recherche de la commande " + commandeId);
		try {
			Commande commande = getCommandeEntity(commandeId);
			return new CommandeDTO(commande);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getCommande", "Pas de commande avec id = " + commandeId, fe);
			return null;
		}
	}

	/**
	 * Gets the commande entity.
	 * 
	 * @param id the id
	 * 
	 * @return the commande entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Commande getCommandeEntity(String id) throws FinderException {
		return commandeHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getInfosComplementairesCommande(java.lang.String)
	 */
	public InfosComplementairesCommandeDTO getInfosComplementairesCommande(String commandeId) {
		try {
			Commande commande = getCommandeEntity(commandeId);
			return InfosComplementairesCommandeDTOFactory.create(commande, messageSagicInHome);
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findDynamicsCommande(java.lang.String)
	 */
	public Map<String, String> findDynamicsCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findDynamicsCommande", "Recherche des champs dynamiques pour la commande " + commandeId);
		Map<String, String> dynamics = new HashMap<String, String>();
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicCommande> dynamicCommandes = dynamicCommandeHome.findByPourCommande(commandeId);
			for (DynamicCommande dynamicCommande : dynamicCommandes) {
				dynamics.put(dynamicCommande.getCle(), dynamicCommande.getValeur());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findDynamicsCommande", "Probl�me lors de la recherche des champs dynamiques pour la commande " + commandeId, fe);
			throw new EJBException(fe);
		}
		return dynamics;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByIdCommandeMixte(java.lang.String)
	 */
	public List<CommandeDTO> findCommandeByRefIntervention(String refIntervention) {

		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Intervention> interventions = interventionHome.findParRefIntervention(refIntervention);
			for (Intervention intervention : interventions) {
				String interventionId = intervention.getId();

				List<LigneCommandeDTO> listLigneCommande = findLigneCommandeByIntervention(interventionId);
				for (LigneCommandeDTO lc : listLigneCommande) {
					String ligneCommandeId = lc.getId();

					CommandeDTO cmd = findCommandeByLigneCommande(ligneCommandeId);
					boolean exist = false;
					for (CommandeDTO c : commandeDTOs) {
						if (c.getId().equals(cmd.getId())) {
							exist = true;
							break;
						}
					}
					if (!exist) {
						commandeDTOs.add(cmd);
					}
				}
			}
		} catch (FinderException fe) {
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByRefeRDV(String)
	 */
	public List<CommandeDTO> findCommandeByRefeRDV(String refeRDV) {
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Intervention> interventions = interventionHome.findParRefErdv(refeRDV);
			for (Intervention intervention : interventions) {
				String interventionId = intervention.getId();

				List<LigneCommandeDTO> listLigneCommande = findLigneCommandeByIntervention(interventionId);
				for (LigneCommandeDTO lc : listLigneCommande) {
					String ligneCommandeId = lc.getId();

					CommandeDTO cmd = findCommandeByLigneCommande(ligneCommandeId);
					boolean exist = false;
					for (CommandeDTO c : commandeDTOs) {
						if (c.getId().equals(cmd.getId())) {
							exist = true;
							break;
						}
					}
					if (!exist) {
						commandeDTOs.add(cmd);
					}
				}
			}
		} catch (FinderException fe) {
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByIdCommandeMixte(java.lang.String)
	 */
	public List<CommandeDTO> findCommandeByIdCommandeMixte(String commandeMixteId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getCommande", "Recherche des commandes pour commande mixte " + commandeMixteId);
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findByAPourCmdMixteCommande(commandeMixteId);
			for (Commande commande : commandes) {
				commandeDTOs.add(new CommandeDTO(commande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByIdCommandeMixte", "Probleme lors de la recherche des commandes composant la commande mixte " + commandeMixteId, fe);
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByIdCommandeMixteEtStatus(java.lang.String, java.lang.String)
	 */
	public List<CommandeDTO> findCommandeByIdCommandeMixteEtStatus(String commandeId, String statutId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByIdCommandeMixteEtStatus", "Recherche des commandes pour commande mixte " + commandeId + " et statut " + statutId);
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findAPourCmdMixteAndAPourStatus(commandeId, statutId);
			for (Commande commande : commandes) {
				commandeDTOs.add(new CommandeDTO(commande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByIdCommandeMixteEtStatus", "Probleme lors de la recherche des commandes composant la commande mixte " + commandeId + " et le status " + statutId, fe);
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByND(java.lang.String)
	 */
	public List<CommandeDTO> findCommandeByND(String nd) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByND", "Recherche des commandes pour le ND " + nd);
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {

			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findParNd(nd);
			for (Commande commande : commandes) {
				commandeDTOs.add(new CommandeDTO(commande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByND", "Probleme lors de la recherche des commandes pour le ND " + nd, fe);
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByAccesLivraisonAndTypeAccesLivraison(String, String)
	 */
	public List<CommandeDTO> findCommandeByAccesLivraisonAndTypeAccesLivraison(String accesLivraison, String typeAcces) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByND", "Recherche des commandes pour l'accesLivraison / typeAccesLivraison " + accesLivraison + " / " + typeAcces);
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findByAccesLivraisonEtTypeAccesLivraison(accesLivraison,typeAcces);
			for (Commande commande : commandes) {
				commandeDTOs.add(new CommandeDTO(commande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByAccesLivraisonAndTypeAccesLivraison", "Probleme lors de la recherche des commandes pour l'accesLivraison / typeAccesLivraison " + accesLivraison + " / " + typeAcces, fe);
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeById(java.lang.String)
	 */
	public CommandeDTO findCommandeById(String id) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeById", "Recherche des commandes pour l'Id " + id);
		CommandeDTO commandeDTO = null;
		try {

			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findParId(id);
			for (Commande commande : commandes) {
				commandeDTO = new CommandeDTO(commande);
				break;
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeById", "Probleme lors de la recherche des commandes pour l'Id " + id, fe);
			throw new EJBException(fe);
		}
		return commandeDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeEnCoursByND(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<CommandeDTO> findCommandeEnCoursByND(String nd) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeEnCoursByND", "Recherche des commandes pour le ND " + nd);
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {
			Collection<Commande> commandes = commandeHome.findCompOuLivrParNdCat(nd);
			commandes.addAll(commandeHome.findCompOuLivrParNdSup(nd));
			commandes.addAll(commandeHome.findCompOuLivrParNdMod(nd));
			for (Commande commande : commandes) {
				commandeDTOs.add(new CommandeDTO(commande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeEnCoursByND", "Probleme lors de la recherche des commandes pour le ND " + nd, fe);
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeEnCoursAVPInterfByND(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<CommandeDTO> findCommandeEnCoursAVPInterfByND(String nd) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeEnCoursAVPInterfByND", "Recherche des commandes pour le ND " + nd);
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();
		try {
			Collection<Commande> commandes = commandeHome.findParContientNdLCCat(nd);
			commandes.addAll(commandeHome.findParContientNdLCSup(nd));
			commandes.addAll(commandeHome.findParContientNdLCMod(nd));
			for (Commande commande : commandes) {
				if (EtatCommandeConstantes.CREEE.equals(commande.getEstDansEtatCommande())) {
					commandeDTOs.add(new CommandeDTO(commande));
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeEnCoursAVPInterfByND", "Probleme lors de la recherche des commandes pour le ND " + nd, fe);
			throw new EJBException(fe);
		}
		return commandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByPsSouhaite(java.lang.String)
	 */
	public CommandeDTO findCommandeByPsSouhaite(String psSouhaiteId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByEpCommercial", "Recherche des lignes de commande pour le ps souhaite " + psSouhaiteId);
		// FIXME OLD: GTA Faire un finder appropri�
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCmdCatalogue> lccs = ligneCmdCatalogueHome.findByDecriteParPsSouhaite(psSouhaiteId);
			Iterator<LigneCmdCatalogue> it = lccs.iterator();
			if (it.hasNext()) {
				LigneCmdCatalogue ligneCmdCatalogue = it.next();
				InstanceOG instanceOG = ligneCmdCatalogue.getLinkComposeInstanceOG();
				if (instanceOG != null) {
					Commande commande = instanceOG.getLinkComposeCommande();
					if (commande != null) {
						return new CommandeDTO(commande);
					}
				}
			}
			@SuppressWarnings("unchecked")
			Collection<LigneCmdModParc> lcmps = ligneCmdModParcHome.findByDecriteParPsSouhaite(psSouhaiteId);
			Iterator<LigneCmdModParc> it2 = lcmps.iterator();
			if (it2.hasNext()) {
				LigneCmdModParc ligneCmdModParc = it2.next();
				Commande commande = ligneCmdModParc.getLinkComposeCommande();
				if (commande != null) {
					return new CommandeDTO(commande);
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByPsSouhaite", "Probleme lors de la recherche de la ligne de commande pour le psSouhaite = " + psSouhaiteId, fe);
			throw new EJBException(fe);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByEpCommercial(java.lang.String)
	 */
	public CommandeDTO findCommandeByEpCommercial(String epCommercialId) {
		CommandeDTO retour = null;
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByEpCommercial", "Recherche des lignes de commande pour l'ep commercial " + epCommercialId);
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCmdModParc> lcmps = ligneCmdModParcHome.findByModifieEPCommercial(epCommercialId);
			Iterator<LigneCmdModParc> itModParc = lcmps.iterator();
			if (itModParc.hasNext()) {
				LigneCmdModParc ligneCmdModParc = itModParc.next();
				Commande commande = ligneCmdModParc.getLinkComposeCommande();
				if (commande != null) {
					retour = new CommandeDTO(commande);
				}
			}
			if (retour == null) {
				@SuppressWarnings("unchecked")
				Collection<LigneCmdSupParc> lcsps = ligneCmdSupParcHome.findBySupprimeEPCommercial(epCommercialId);
				Iterator<LigneCmdSupParc> it = lcsps.iterator();
				if (it.hasNext()) {
					LigneCmdSupParc ligneCmdSupParc = it.next();
					Commande commande = ligneCmdSupParc.getLinkComposeCommande();
					if (commande != null) {
						retour = new CommandeDTO(commande);
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByEpCommercial", "Probleme lors de la recherche de la ligne de commande pour l'epCommercial = " + epCommercialId, fe);
			throw new EJBException(fe);
		}
		return retour;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByLigneCommande(java.lang.String)
	 */
	public CommandeDTO findCommandeByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByLigneCommande", "Recherche de la commande pour la ligne de commande " + ligneCommandeId);
		try {
			// 1. type CR
			@SuppressWarnings("unchecked")
			Collection<LigneCmdCatalogue> ligneCmdCatalogues = ligneCmdCatalogueHome.findByEstLigneCommande(ligneCommandeId);
			for (LigneCmdCatalogue ligneCmdCatalogue : ligneCmdCatalogues) {
				InstanceOG instanceOg = ligneCmdCatalogue.getLinkComposeInstanceOG();
				if (instanceOg != null) {
					return new CommandeDTO(instanceOg.getLinkComposeCommande());
				}
			}

			// 2. type MO
			@SuppressWarnings("unchecked")
			Collection<LigneCmdModParc> lignesCmdModParc = ligneCmdModParcHome.findByEstLigneCommande(ligneCommandeId);
			if (lignesCmdModParc != null && !lignesCmdModParc.isEmpty()) {
				LigneCmdModParc ligneCmdModParc = lignesCmdModParc.iterator().next();
				return new CommandeDTO(ligneCmdModParc.getLinkComposeCommande());
			}

			// 3. type SU
			@SuppressWarnings("unchecked")
			Collection<LigneCmdSupParc> lignesCmdSupParc = ligneCmdSupParcHome.findByEstLigneCommande(ligneCommandeId);
			if (lignesCmdSupParc != null && !lignesCmdSupParc.isEmpty()) {
				LigneCmdSupParc ligneCmdSupParc = lignesCmdSupParc.iterator().next();
				return new CommandeDTO(ligneCmdSupParc.getLinkComposeCommande());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByLigneCommande", "Probleme lors de la recherche de la commande pour la ligne de commande = " + ligneCommandeId, fe);
			throw new EJBException(fe);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByRefExterne(java.lang.String)
	 */
	public CommandeDTO findCommandeByRefExterne(String refExterne) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByRefExterne", "Recherche de la commande ayant pour refExterne " + refExterne);
		try {
			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findParRefExterne(refExterne);
			// on ne recupere que le premier
			if (!commandes.isEmpty()) {
				return new CommandeDTO(commandes.iterator().next());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getCommande", "Pas de commande avec refExterne = " + refExterne, fe);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeListByRefExterne(java.lang.String)
	 */
	public List<CommandeDTO> findCommandeListByRefExterne(String refExterne) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByRefExterne", "Recherche de la commande ayant pour refExterne " + refExterne);
		List<CommandeDTO> toReturn = new ArrayList<CommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findParRefExterne(refExterne);

			for (Commande commande : commandes) {
				toReturn.add(new CommandeDTO(commande));
			}
			return toReturn;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getCommande", "Pas de commande avec refExterne = " + refExterne, fe);
		}
		return toReturn;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeNonAnnByRefExterne(java.lang.String)
	 */
	public CommandeDTO findCommandeNonAnnByRefExterne(String refExterne) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeNonAnnByRefExterne", "Recherche de la commande non annul�e ayant pour refExterne " + refExterne);
		try {
			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findNonAnnParRefExterne(refExterne);
			// on ne recupere que le premier
			if (!commandes.isEmpty()) {
				return new CommandeDTO(commandes.iterator().next());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, "findCommandeNonAnnByRefExterne", "Pas de commande non annul�e avec refExterne = " + refExterne, fe);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findListCommandesNonAnnByRefExterne(java.lang.String)
	 */
	public List<CommandeDTO> findListCommandesNonAnnByRefExterne(String refExterne) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findListCommandesNonAnnByRefExterne", "Recherche de la commande non annul�e ayant pour refExterne " + refExterne);
		List<CommandeDTO> listCommandesDTO = new ArrayList<CommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Commande> commandes = commandeHome.findNonAnnParRefExterne(refExterne);
			//on retourne la liste de commandes
			for (Commande commande : commandes) {
				listCommandesDTO.add(new CommandeDTO(commande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, "findListCommandesNonAnnByRefExterne", "Pas de commande non annul�e avec refExterne = " + refExterne, fe);
		}
		return listCommandesDTO;
	}


	/**
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByProcessus(java.lang.String)
	 */
	public CommandeDTO findCommandeByProcessus(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByProcessus", "Recherche de la commande pour processus " + processusId);
		try {
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> plcs = processusLCHome.findByEstLivreParProcessus(processusId);
			if (!plcs.isEmpty()) {
				ProcessusLC plc = plcs.iterator().next();
				LigneCommande ligneCde = plc.getLinkLivreLigneCommande();
				Commande commande = commandeHome.findByPrimaryKey(new EntityBeanPK(ligneCde.getIdCommande()));
				return new CommandeDTO(commande);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByProcessus", "Pas de commande pour processus = " + processusId, fe);
		}
		return null;
	}

	/**
	 *
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByTache(java.lang.String)
	 */
	public CommandeDTO findCommandeByTache(String tacheId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByTache", "Recherche de la commande pour tache " + tacheId);
		try {
			Tache tache = getTacheEntity(tacheId);
			Processus processus = tache.getLinkLanceParProcessus();
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> plcs = processusLCHome.findByEstLivreParProcessus(processus.getId());
			if (!plcs.isEmpty()) {
				ProcessusLC plc = plcs.iterator().next();
				LigneCommande ligneCde = plc.getLinkLivreLigneCommande();
				Commande commande = commandeHome.findByPrimaryKey(new EntityBeanPK(ligneCde.getIdCommande()));
				return new CommandeDTO(commande);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByTache", "Pas de commande pour tache = " + tacheId, fe);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByInterventionId(java.lang.String)
	 */
	public CommandeDTO findCommandeByInterventionId(String interventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByInterventionId", "Recherche de la commande pour intervention" + interventionId);
		try {
			Collection<Commande> commandes = commandeHome.findByInterventionId(interventionId);
			if (!commandes.isEmpty()) {
				Commande commande = CollectionUtils.getFirstOrNull(commandes);
				return new CommandeDTO(commande);
			}
			return null;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByInterventionId", "Pas de commande pour intervention = " + interventionId, fe);
			return null;
		}
	}


	/**
	 * Gets the tache entity.
	 * 
	 * @param id the id
	 * 
	 * @return the tache entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Tache getTacheEntity(String id) throws FinderException {
		return tacheHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>07/06/2010</TD><TD>DBA</TD><TD>EV-000067: Nouvelle m�thode pour faire la persistance du cas metier</TD></TR>
	 * </TABLE>
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeCasMetier(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateCommandeCasMetier(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeCasMetier", "Mise � jour du casMetier la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setSeRefereCasMetier(commandeDTO.getCasMetier().getId());
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeCasMetier", "Probl�me de mise � jour du casMetier de la commande " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeEtat(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateCommandeEtat(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeEtat", "Mise � jour de la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setEstDansEtatCommande(commandeDTO.getEtatCommande().getId());
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeEtat", "Probl�me de mise � jour de la commande " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeEtat(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
	 * </TABLE>
	 */
	public void updateCommandeRefExterne(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeRefExterne", "Mise � jour de la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setRefExterne(commandeDTO.getRefExterne());
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeRefExterne", "Probl�me de mise � jour de la commande " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeStatut(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateCommandeStatut(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeStatut", "Mise � jour de la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setEstDansStatutCommande(commandeDTO.getStatutCommande().getId());
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeStatut", "Probl�me de mise � jour de la commande: id = " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeIndicateurRegul(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateCommandeIndicateurRegul(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeIndicateurRegul", "Mise � jour de la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setIndicateurRegul(commandeDTO.getIndicateurRegul());
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeIndicateurRegul", "Probl�me de mise � jour de la commande: id = " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeDateFin(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateCommandeDateFin(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeDateFin", "Mise � jour de la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setDateFinCommande(commandeDTO.getDatabaseDateDateFinCommande());
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeDateFin", "Probl�me de mise � jour de la commande: id = " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeDateFinAndEtat(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateCommandeDateFinAndEtat(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeDateFinAndEtat", "Mise � jour de la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setDateFinCommande(commandeDTO.getDatabaseDateDateFinCommande());
			commande.setEstDansEtatCommande(commandeDTO.getEtatCommande().getId());
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeDateFinAndEtat", "Probl�me de mise � jour de la commande: id = " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeNombreAvp(java.lang.String)
	 */
	public void updateCommandeNombreAvp(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeNombreAvp", "Mise � jour du nombre d'avp de la commande pour le processus " + processusId);
		try {
			String commandeId = null;
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> pls = processusLCHome.findByEstLivreParProcessus(processusId);
			Iterator<ProcessusLC> it = pls.iterator();
			if (it.hasNext()) {
				ProcessusLC processusLC = it.next();
				LigneCommande ligneCommande = processusLC.getLinkLivreLigneCommande();
				commandeId = ligneCommande.getIdCommande();
			}
			Commande commande = getCommandeEntity(commandeId);
			Integer nombreAvp = commande.getNombreAvp();
			if (nombreAvp != null) {
				nombreAvp++;
			} else {
				nombreAvp = Integer.valueOf(1);
			}
			commande.setNombreAvp(nombreAvp);
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeNombreAvp", "Probl�me de mise � jour de la commande pour le processus id = " + processusId, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCommandeMixte(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateCommandeMixte(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCommandeMixte", "Mise � jour de la commande " + commandeDTO.getId());
		try {
			Commande commande = getCommandeEntity(commandeDTO.getId());
			commande.setLinkAPourCmdMixteCommande(getCommandeEntity(commandeDTO.getAPourCmdMixteCommande().getId()));
			long timestamp = commande.getTimestamp() + 1;
			commande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCommandeMixte", "Probl�me de mise � jour de la commande: id = " + commandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateDynamicCommande(com.soliste.bolbec.livraison.service.model.CommandeDTO)
	 */
	public void updateDynamicCommande(CommandeDTO commandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateDynamicCommande", "Mise � jour des champs dynamiques de la commande " + commandeDTO.getId());
		Map<String, String> dynamicCommandes = commandeDTO.getDynamicCommandes();
		if (!dynamicCommandes.isEmpty()) {
			String commandeId = commandeDTO.getId();
			try {
				// recup�ration de tous les champs dynamiques pour cette commande
				@SuppressWarnings("unchecked")
				Collection<DynamicCommande> dynamicCommandesAps = dynamicCommandeHome.findByPourCommande(commandeId);
				String cle;
				String valeur;
				String cleAps;
				String valeurAps;
				for (Entry<String, String> dynamicCommandeEntry : dynamicCommandes.entrySet()) {
					boolean isUpdated = false;
					cle = dynamicCommandeEntry.getKey();
					valeur = dynamicCommandeEntry.getValue();
					Iterator<DynamicCommande> it = dynamicCommandesAps.iterator();
					while (it.hasNext()) {
						DynamicCommande dynamicCommande = it.next();
						cleAps = dynamicCommande.getCle();
						valeurAps = dynamicCommande.getValeur();
						if (StringUtils.equals(cleAps, cle)) {
							if (StringUtils.isNotEmpty(valeur)) {
								if (!StringUtils.equals(valeurAps, valeur)) {
									// maj du dynamic existant
									dynamicCommande.setValeur(valeur);
									long timestamp = dynamicCommande.getTimestamp() + 1;
									dynamicCommande.setTimestamp(timestamp);
								}
							} else {
								// on supprime la valeur en base si elle est nulle
								try {
									dynamicCommande.remove();
									it.remove();
								} catch (EJBException e) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicCommande", "Probl�me lors de la suppression du dynamique commande", e);
									throw new EJBException(e);
								} catch (RemoveException re) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicCommande", "Probl�me lors de la suppression du dynamique commande", re);
									throw new EJBException(re);
								}
							}
							isUpdated = true;
							break;
						}
					}
					// Si on n'a pas mis � jour la table dynamique alors on insere un nouvel enregistrement
					if (!isUpdated) {
						if (StringUtils.isNotEmpty(valeur)) {
							createDynamicCommande(commandeId, cle, valeur);
						}
					}
				}
			} catch (FinderException fe) {
				// Cr�ation des champs dynamiques
				String cle;
				String valeur;
				for (Entry<String, String> dynamicCommandeEntry : dynamicCommandes.entrySet()) {
					cle = dynamicCommandeEntry.getKey();
					valeur = dynamicCommandeEntry.getValue();
					if (StringUtils.isNotEmpty(valeur)) {
						createDynamicCommande(commandeId, cle, valeur);
					}
				}
			}

		}
	}

	/**
	 * Creates the dynamic commande.
	 * 
	 * @param commandeId the commande id
	 * @param cle the cle
	 * @param valeur the valeur
	 */
	private void createDynamicCommande(String commandeId, String cle, String valeur) {
		Map<String, Object> values = new HashMap<String, Object>();
		values.put(DynamicCommande.FIELD_CLE, cle);
		values.put(DynamicCommande.FIELD_VALEUR, valeur);
		values.put(DynamicCommande.SLINK_POUR_COMMANDE, commandeId);
		String dynamicCommandeId = serviceManager.getGeneratorManager().generateKey();
		try {
			DynamicCommande dynamicCommande = dynamicCommandeHome.create(dynamicCommandeId, (HashMap<String, Object>) values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			dynamicCommande.setLinks((HashMap<String, Object>) values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createDynamicCommande", "Erreur cr�ation dynamique commande pour la commande " + commandeId, ce);
			throw new EJBException(ce);
		}
	}

	// --------------------------------------------------------------
	// LIGNE_COMMANDE
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getLigneCommande(java.lang.String)
	 */
	public LigneCommandeDTO getLigneCommande(String ligneCmdId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getLigneCommande", "Recherche de la ligne de commande  " + ligneCmdId);
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCmdId);
			return new LigneCommandeDTO(ligneCommande);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getLigneCommande", "Probleme de recuperation de la ligne de commande " + ligneCmdId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findDynamicsLigneCommande(java.lang.String)
	 */
	public Map<String, String> findDynamicsLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findDynamicsLigneCommande", "Recherche des champs dynamiques pour la ligne de commande " + ligneCommandeId);
		Map<String, String> dynamics = new HashMap<String, String>();
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicLigneCommande> dynamicsAps = dynamicLigneCommandeHome.findByPourLigneCommande(ligneCommandeId);
			for (DynamicLigneCommande dynamic : dynamicsAps) {
				dynamics.put(dynamic.getCle(), dynamic.getValeur());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findDynamicsLigneCommande", "Probl�me lors de la recherche des champs dynamiques pour la ligne de commande " + ligneCommandeId, fe);
			throw new EJBException(fe);
		}
		return dynamics;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createLigneCommande(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void createLigneCommande(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createLigneCommande", "Cr�ation de la ligne de Commande (id = " + ligneCommandeDTO.getId());
		try {
			Map<String, Object> values = new HashMap<String, Object>();
			TypeOpPonctuellesDTO typeOpPonctuelles = ligneCommandeDTO.getTypeOpPonctuelles();
			if (typeOpPonctuelles != null && StringUtils.isNotBlank(typeOpPonctuelles.getId())) {
				values.put(LigneCommande.FIELD_A_TYPE_OP_PONCTUELLES, typeOpPonctuelles.getId());
			}
			values.put(LigneCommande.FIELD_ACCES_LIVRAISON, ligneCommandeDTO.getAccesLivraison());
			values.put(LigneCommande.FIELD_ACCES_LIVRAISON_ORIGINE, ligneCommandeDTO.getAccesLivraisonOrigine());
			values.put(LigneCommande.FIELD_CODE_FACTURATION_OFFRE, ligneCommandeDTO.getCodeFacturationOffre());
			values.put(LigneCommande.FIELD_CODE_FACTURATION_REMISE, ligneCommandeDTO.getCodeFacturationRemise());
			ZoneGeographiqueDTO zoneGeographique = ligneCommandeDTO.getZoneGeographique();
			if (zoneGeographique != null && StringUtils.isNotBlank(zoneGeographique.getId())) {
				values.put(LigneCommande.FIELD_DANS_Z_G_ZONE_GEOGRAPHIQUE, zoneGeographique.getId());
			}
			ZoneSiDTO zoneSI = ligneCommandeDTO.getZoneSi();
			if (zoneSI != null && StringUtils.isNotBlank(zoneSI.getId())) {
				values.put(LigneCommande.FIELD_DANS_Z_S_I_ZONE_S_I, zoneSI.getId());
			}
			values.put(LigneCommande.FIELD_DATE_CONTRACTUELLE, ligneCommandeDTO.getDatabaseDateDateContractuelle());
			values.put(LigneCommande.FIELD_DATE_FIN_LIGNE_COMMANDE, ligneCommandeDTO.getDatabaseDateDateFinLigneCommande());
			values.put(LigneCommande.FIELD_DATE_MADT, ligneCommandeDTO.getDatabaseDateDateMadt());
			values.put(LigneCommande.FIELD_DATE_MES, ligneCommandeDTO.getDatabaseDateDateMes());
			values.put(LigneCommande.FIELD_DATE_MES_TECH, ligneCommandeDTO.getDatabaseDateDateMesTech());
			values.put(LigneCommande.FIELD_DATE_SOUHAITEE, ligneCommandeDTO.getDatabaseDateDateSouhaitee());
			ContexteDTO contexte = ligneCommandeDTO.getContexte();
			if (contexte != null && StringUtils.isNotBlank(contexte.getId())) {
				values.put(LigneCommande.FIELD_DEPEND_CONTEXTE, contexte.getId());
			}
			EtatLigneCdeDTO etatLigneCde = ligneCommandeDTO.getEtatLigneCde();
			if (etatLigneCde != null && StringUtils.isNotBlank(etatLigneCde.getId())) {
				values.put(LigneCommande.FIELD_EST_ETAT_LIGNE_CDE, etatLigneCde.getId());
			}
			RepartiteurDTO repartiteur = ligneCommandeDTO.getRepartiteur();
			if (repartiteur != null && StringUtils.isNotBlank(repartiteur.getId())) {
				values.put(LigneCommande.FIELD_EST_SUR_REPARTITEUR, repartiteur.getId());
			}
			values.put(LigneCommande.FIELD_ID_COMMANDE, ligneCommandeDTO.getIdCommande());
			values.put(LigneCommande.FIELD_INDICATEUR_REGUL, ligneCommandeDTO.getIndicateurRegul());
			InstanceLocalisationDTO instanceLocalisation = ligneCommandeDTO.getInstanceLocalisation();
			if (instanceLocalisation != null && StringUtils.isNotBlank(instanceLocalisation.getId())) {
				values.put(LigneCommande.FIELD_LIE_A_INSTANCE_LOCALISATION, instanceLocalisation.getId());
			}
			values.put(LigneCommande.FIELD_ND_FINDER, ligneCommandeDTO.getNdFinder());
			values.put(LigneCommande.FIELD_PRIX_DETENTION_H_T, ligneCommandeDTO.getPrixDetentionHt());
			values.put(LigneCommande.FIELD_PRIX_OFFRE_H_T, ligneCommandeDTO.getPrixOffreHt());
			values.put(LigneCommande.FIELD_PRIX_REMISE_H_T, ligneCommandeDTO.getPrixRemiseHt());
			values.put(LigneCommande.FIELD_QUANTITE, ligneCommandeDTO.getQuantite());
			SystemeExterneDTO systemeExterne = ligneCommandeDTO.getSystemeExterne();
			if (systemeExterne != null && StringUtils.isNotBlank(systemeExterne.getId())) {
				values.put(LigneCommande.FIELD_RECU_PAR_SYSTEME_EXTERNE, systemeExterne.getId());
			}
			values.put(LigneCommande.FIELD_REF_EXTERNE, ligneCommandeDTO.getRefExterne());
			JalonDTO jalon = ligneCommandeDTO.getJalon();
			if (jalon != null && StringUtils.isNotBlank(jalon.getId())) {
				values.put(LigneCommande.FIELD_REPERE_PAR_JALON, jalon.getId());
			}
			values.put(LigneCommande.FIELD_TVA, ligneCommandeDTO.getTva());
			values.put(LigneCommande.FIELD_TYPE_ACCES_LIVRAISON, ligneCommandeDTO.getTypeAccesLivraison());
			values.put(LigneCommande.FIELD_TYPE_ACCES_LIVRAISON_ORIGINE, ligneCommandeDTO.getTypeAccesLivraisonOrigine());
			LigneCommandeDTO induiteLdc = ligneCommandeDTO.getInduiteParLigneCommande();
			if (induiteLdc != null && StringUtils.isNotBlank(induiteLdc.getId())) {
				values.put(LigneCommande.SLINK_INDUITE_PAR_LIGNE_COMMANDE, induiteLdc.getId());
			}
			ClientDTO client = ligneCommandeDTO.getClient();
			if (client != null && StringUtils.isNotBlank(client.getId())) {
				values.put(LigneCommande.SLINK_LIVRE_CLIENT, client.getId());
			}

			LigneCommande ligneCommande = ligneCommandeHome.create(ligneCommandeDTO.getId(), (HashMap<String, Object>) values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			ligneCommande.setLinks((HashMap<String, Object>) values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createProcessusLC", "Erreur cr�ation de la ligne de commande: id " + ligneCommandeDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeJalon(java.util.List, java.lang.String)
	 */
	public void updateLigneCommandeJalon(List<LigneCommandeDTO> ligneCommandeDTOs, String jalonId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeJalon", "Mise � jour de la liste des lignes de commande");
		if (ligneCommandeDTOs != null) {
			try {
				for (LigneCommandeDTO ligneCommandeDTO : ligneCommandeDTOs) {
					LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
					ligneCommande.setRepereParJalon(jalonId);
					long timestamp = ligneCommande.getTimestamp() + 1;
					ligneCommande.setTimestamp(timestamp);
				}
			} catch (FinderException fe) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeJalon", "Probleme de mise � jour de la liste des lignes de commande", fe);
				throw new EJBException(fe);
			}
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeZoneGeoEtZoneSi(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeZoneGeoEtZoneSi(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeZoneGeoEtZoneSi", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setDansZSIZoneSI(ligneCommandeDTO.getZoneSi().getId());
			ligneCommande.setDansZGZoneGeographique(ligneCommandeDTO.getZoneGeographique().getId());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeZoneGeoEtZoneSi", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeEtat(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeEtat(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeEtat", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setEstEtatLigneCde(ligneCommandeDTO.getEtatLigneCde().getId());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeEtat", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeDateFin(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeDateFin(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeDateFin", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setDateFinLigneCommande(ligneCommandeDTO.getDatabaseDateDateFinLigneCommande());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeDateFin", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeDateFinAndEtat(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeDateFinAndEtat(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeDateFinAndEtat", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setEstEtatLigneCde(ligneCommandeDTO.getEtatLigneCde().getId());
			ligneCommande.setDateFinLigneCommande(ligneCommandeDTO.getDatabaseDateDateFinLigneCommande());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeDateFinAndEtat", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeIndicateurRegulEtDateFin(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeIndicateurRegulEtDateFin(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeIndicateurRegulEtDateFin", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setIndicateurRegul(ligneCommandeDTO.getIndicateurRegul());
			ligneCommande.setDateFinLigneCommande(ligneCommandeDTO.getDatabaseDateDateFinLigneCommande());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeIndicateurRegulEtDateFin", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeEtatEtJalonEtIndicateurRegul(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeEtatEtJalonEtIndicateurRegul(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeEtatEtJalonEtIndicateurRegul", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			if (ligneCommandeDTO.getEtatLigneCde() != null) {
				ligneCommande.setEstEtatLigneCde(ligneCommandeDTO.getEtatLigneCde().getId());
			}
			if (ligneCommandeDTO.getJalon() != null) {
				ligneCommande.setRepereParJalon(ligneCommandeDTO.getJalon().getId());
			}
			ligneCommande.setIndicateurRegul(ligneCommandeDTO.getIndicateurRegul());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeEtatEtJalonEtIndicateurRegul", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeDateMadtAndDateMes(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeDateMadtAndDateMes(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeDateMadtAndDateMes", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setDateMadt(ligneCommandeDTO.getDatabaseDateDateMadt());
			ligneCommande.setDateMes(ligneCommandeDTO.getDatabaseDateDateMes());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeDateFinAndEtat", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeDateMesTech(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeDateMesTech(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeDateMesTech", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setDateMesTech(ligneCommandeDTO.getDatabaseDateDateMesTech());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeDateMesTech", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeDateSouhaiteAndDateContractuelle(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeDateSouhaiteAndDateContractuelle(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeDateSouhaiteAndDateContractuelle", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setDateSouhaitee(ligneCommandeDTO.getDatabaseDateDateSouhaitee());
			ligneCommande.setDateContractuelle(ligneCommandeDTO.getDatabaseDateDateContractuelle());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeDateSouhaiteAndDateContractuelle", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeDateSouhaiteAndDateContractuelle(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeDateContractuelle(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeDateContractuelle", "Mise � jour de la date contractuelle de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setDateContractuelle(ligneCommandeDTO.getDatabaseDateDateContractuelle());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeDateContractuelle", "Probl�me de mise � jour de la date contractuelle de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeCodeFacturation(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeCodeFacturation(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeCodeFacturation", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setCodeFacturationOffre(ligneCommandeDTO.getCodeFacturationOffre());
			ligneCommande.setCodeFacturationRemise(ligneCommandeDTO.getCodeFacturationRemise());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeCodeFacturation", "Pas de ligne de commande " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeRepartiteur(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeRepartiteur(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeDateFin", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			RepartiteurDTO repartiteur = ligneCommandeDTO.getRepartiteur();
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setEstSurRepartiteur(repartiteur != null ? repartiteur.getId() : null);
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeDateFin", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeClient(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeClient(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeClient", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			ClientDTO client = ligneCommandeDTO.getClient();
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setLinkLivreClient(client != null ? getClientEntity(client.getId()) : null);
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeClient", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeContexte(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeContexte(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeContexte", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			ContexteDTO contexte = ligneCommandeDTO.getContexte();
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setDependContexte(contexte != null ? contexte.getId() : null);
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeContexte", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeInduiteLigneCommande(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeInduiteLigneCommande(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeInduiteLigneCommande", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommandeDTO induiteLdc = ligneCommandeDTO.getInduiteParLigneCommande();
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setLinkInduiteParLigneCommande(induiteLdc != null ? getLigneCommandeEntity(induiteLdc.getId()) : null);
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeInduiteLigneCommande", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeAccesLivraison(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeAccesLivraison(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeAccesLivraison", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setAccesLivraison(ligneCommandeDTO.getAccesLivraison());
			ligneCommande.setAccesLivraisonOrigine(ligneCommandeDTO.getAccesLivraisonOrigine());
			ligneCommande.setTypeAccesLivraison(ligneCommandeDTO.getTypeAccesLivraison());
			ligneCommande.setTypeAccesLivraisonOrigine(ligneCommandeDTO.getTypeAccesLivraisonOrigine());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeAccesLivraison", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateLigneCommandeNdFinder(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateLigneCommandeNdFinder(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateLigneCommandeNdFinder", "Mise � jour de la ligne de commande " + ligneCommandeDTO.getId());
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeDTO.getId());
			ligneCommande.setNdFinder(ligneCommandeDTO.getNdFinder());
			long timestamp = ligneCommande.getTimestamp() + 1;
			ligneCommande.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateLigneCommandeNdFinder", "Probl�me de mise � jour de la ligne de commande: id = " + ligneCommandeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateDynamicLigneCommande(com.soliste.bolbec.livraison.service.model.LigneCommandeDTO)
	 */
	public void updateDynamicLigneCommande(LigneCommandeDTO ligneCommandeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateDynamicLigneCommande", "Mise � jour des champs dynamiques de la ligne de commande " + ligneCommandeDTO.getId());
		Map<String, String> dynamicLigneCommandes = ligneCommandeDTO.getDynamicLigneCommandes();
		if (!dynamicLigneCommandes.isEmpty()) {
			String ligneCommandeId = ligneCommandeDTO.getId();
			try {
				// recup�ration de tous les champs dynamiques pour cette ligne de commande
				@SuppressWarnings("unchecked")
				Collection<DynamicLigneCommande> dynamicLigneCommandesAps = dynamicLigneCommandeHome.findByPourLigneCommande(ligneCommandeDTO.getId());
				String cle;
				String valeur;
				String cleAps;
				String valeurAps;
				for (Entry<String, String> dynamicLigneCommandeEntry : dynamicLigneCommandes.entrySet()) {
					boolean isUpdated = false;
					cle = dynamicLigneCommandeEntry.getKey();
					valeur = dynamicLigneCommandeEntry.getValue();
					Iterator<DynamicLigneCommande> it = dynamicLigneCommandesAps.iterator();
					while (it.hasNext()) {
						DynamicLigneCommande dynamicLigneCommande = it.next();
						cleAps = dynamicLigneCommande.getCle();
						valeurAps = dynamicLigneCommande.getValeur();
						if (StringUtils.equals(cleAps, cle)) {
							if (StringUtils.isNotEmpty(valeur)) {
								if (!StringUtils.equals(valeurAps, valeur)) {
									// maj du dynamic existant
									dynamicLigneCommande.setValeur(valeur);
									long timestamp = dynamicLigneCommande.getTimestamp() + 1;
									dynamicLigneCommande.setTimestamp(timestamp);
								}
							} else {
								// on supprime la valeur en base si elle est nulle
								try {
									dynamicLigneCommande.remove();
									it.remove();
								} catch (EJBException e) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicLigneCommande", "Probl�me lors de la suppression du dynamique ligne de commande", e);
									throw new EJBException(e);
								} catch (RemoveException re) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicLigneCommande", "Probl�me lors de la suppression du dynamique ligne de commande", re);
									throw new EJBException(re);
								}
							}
							isUpdated = true;
							break;
						}
					}
					// Si on n'a pas mis � jour la table dynamique alors on insere un nouvel enregistrement
					if (!isUpdated) {
						if (StringUtils.isNotEmpty(valeur)) {
							createDynamicLigneCommande(ligneCommandeId, cle, valeur);
						}
					}
				}
			} catch (FinderException fe) {
				// Cr�ation des champs dynamiques
				String cle;
				String valeur;
				for (Entry<String, String> dynamicLigneCommandeEntry : dynamicLigneCommandes.entrySet()) {
					cle = dynamicLigneCommandeEntry.getKey();
					valeur = dynamicLigneCommandeEntry.getValue();
					if (StringUtils.isNotEmpty(valeur)) {
						createDynamicLigneCommande(ligneCommandeId, cle, valeur);
					}
				}
			}
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByCommande(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByCommande", "Recherche des lignes de commande pour la commande " + commandeId);
		List<LigneCommandeDTO> ligneCommandeDTOs = new ArrayList<LigneCommandeDTO>();
		try {
			// 1. type CR
			@SuppressWarnings("unchecked")
			Collection<InstanceOG> instanceOGs = instanceOGHome.findByComposeCommande(commandeId);
			for (InstanceOG instanceOG : instanceOGs) {
				@SuppressWarnings("unchecked")
				Collection<LigneCmdCatalogue> lignesCmdCatalogue = instanceOG.getLinkContientLigneCmdCatalogue();
				for (LigneCmdCatalogue ligneCmdCatalogue : lignesCmdCatalogue) {
					LigneCommande ligneCommande = ligneCmdCatalogue.getLinkEstLigneCommande();
					ligneCommandeDTOs.add(new LigneCommandeDTO(ligneCommande));
				}
			}

			// 2. type MO
			@SuppressWarnings("unchecked")
			Collection<LigneCmdModParc> lignesCmdModParc = ligneCmdModParcHome.findForListOfLigneCommandeParCde(commandeId);
			for (LigneCmdModParc ligneCmdModParc : lignesCmdModParc) {
				LigneCommande ligneCommande = ligneCmdModParc.getLinkEstLigneCommande();
				ligneCommandeDTOs.add(new LigneCommandeDTO(ligneCommande));
			}

			// 3. type SU
			@SuppressWarnings("unchecked")
			Collection<LigneCmdSupParc> lignesCmdSupParc = ligneCmdSupParcHome.findForListOfLigneCommandeParCde(commandeId);
			for (LigneCmdSupParc ligneCmdSupParc : lignesCmdSupParc) {
				LigneCommande ligneCommande = ligneCmdSupParc.getLinkEstLigneCommande();
				ligneCommandeDTOs.add(new LigneCommandeDTO(ligneCommande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByCommande", "Probleme lors de la recherche de la liste de ligne de commande pour commande = " + commandeId, fe);
			throw new EJBException(fe);
		}
		return ligneCommandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByInstanceRT(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeByInstanceRT(String instanceRtId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByInstanceRT", "Recherche des lignes de commande pour l'insatnceRT " + instanceRtId);
		List<LigneCommandeDTO> ligneCommandeDTOs = new ArrayList<LigneCommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<SappuieSur> sAppuieSurs = sAppuieSurHome.findByAppuieInstanceRT(instanceRtId);
			for (SappuieSur sappuieSur : sAppuieSurs) {
				InstanceFT instanceFT = sappuieSur.getLinkAppuieSurInstanceFT();
				PsSouhaite psSouhaite = instanceFT.getLinkFournitParPsSouhaite();
				if (psSouhaite != null && StringUtils.isNotEmpty(psSouhaite.getId())) {
					LigneCommandeDTO ligneCommande = findLigneCommandeByPsSouhaite(psSouhaite.getId());
					if (ligneCommande != null) {
						ligneCommandeDTOs.add(ligneCommande);
					}
				} else {
					@SuppressWarnings("unchecked")
					Collection<EPCommercial> epCommercials = instanceFT.getLinkConcerneEPCommercial();
					for (EPCommercial epCommercial : epCommercials) {
						LigneCommandeDTO ligneCommande = findLigneCommandeByEpCommercial(epCommercial.getId());
						if (ligneCommande != null) {
							ligneCommandeDTOs.add(ligneCommande);
						}
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByInstanceRT", "Probleme lors de la recherche de la liste de ligne de commande pour l'instanceRT " + instanceRtId, fe);
			throw new EJBException(fe);
		}
		return ligneCommandeDTOs;
	}

	/**
	 * R�cup�re la ligne de commande pour l'EpCommercial pass� en param�tre par son id
	 * on essaye de trouver la ligne de commande en passant par LigneCmdModParc (modification)
	 * si non trouv� on essaye en passant par LigneCmdSupParc (suppression).
	 * 
	 * @param epCommercialId PS souhaite
	 * 
	 * @return LigneCommandeDTO
	 */
	public LigneCommandeDTO findLigneCommandeByEpCommercial(String epCommercialId) {
		LigneCommandeDTO retour = null;
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByEpCommercial", "Recherche des lignes de commande pour l'ep commercial " + epCommercialId);
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCmdModParc> lcmps = ligneCmdModParcHome.findByModifieEPCommercial(epCommercialId);
			Iterator<LigneCmdModParc> itModParc = lcmps.iterator();
			if (itModParc.hasNext()) {
				LigneCmdModParc ligneCmdModParc = itModParc.next();
				LigneCommande ligneCommande = ligneCmdModParc.getLinkEstLigneCommande();
				if (ligneCommande != null) {
					retour = new LigneCommandeDTO(ligneCommande);
				}
			}
			if (retour == null) {
				@SuppressWarnings("unchecked")
				Collection<LigneCmdSupParc> lcsps = ligneCmdSupParcHome.findBySupprimeEPCommercial(epCommercialId);
				Iterator<LigneCmdSupParc> it = lcsps.iterator();
				if (it.hasNext()) {
					LigneCmdSupParc ligneCmdSupParc = it.next();
					LigneCommande ligneCommande = ligneCmdSupParc.getLinkEstLigneCommande();
					if (ligneCommande != null) {
						retour = new LigneCommandeDTO(ligneCommande);
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByEpCommercial", "Probleme lors de la recherche de la ligne de commande pour l'epCommercial = " + epCommercialId, fe);
			throw new EJBException(fe);
		}
		return retour;
	}

	/**
	 * R�cup�re la ligne de commande pour le PSSouhaite pass� en param�tre par son id
	 * on essaye de trouver la ligne de commande en passant par LigneCmdCatalogue (creation)
	 * si non trouv� on essaye en passant par LigneCmdModParc (modification).
	 * 
	 * @param psSouhaiteId PS souhaite
	 * 
	 * @return LigneCommandeDTO
	 */
	public LigneCommandeDTO findLigneCommandeByPsSouhaite(String psSouhaiteId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByPsSouhaite", "Recherche des lignes de commande pour le ps souhaite " + psSouhaiteId);
		// FIXME OLD: GTA Faire un finder appropri�
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCmdCatalogue> lccs = ligneCmdCatalogueHome.findByDecriteParPsSouhaite(psSouhaiteId);
			Iterator<LigneCmdCatalogue> it = lccs.iterator();
			if (it.hasNext()) {
				LigneCmdCatalogue ligneCmdCatalogue = it.next();
				LigneCommande ligneCommande = ligneCmdCatalogue.getLinkEstLigneCommande();
				if (ligneCommande != null) {
					return new LigneCommandeDTO(ligneCommande);
				}
			}
			@SuppressWarnings("unchecked")
			Collection<LigneCmdModParc> lcmps = ligneCmdModParcHome.findByDecriteParPsSouhaite(psSouhaiteId);
			Iterator<LigneCmdModParc> it2 = lcmps.iterator();
			if (it2.hasNext()) {
				LigneCmdModParc ligneCmdModParc = it2.next();
				LigneCommande ligneCommande = ligneCmdModParc.getLinkEstLigneCommande();
				if (ligneCommande != null) {
					return new LigneCommandeDTO(ligneCommande);
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByPsSouhaite", "Probleme lors de la recherche de la ligne de commande pour le psSouhaite = " + psSouhaiteId, fe);
			throw new EJBException(fe);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByProcessus(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeByProcessus(String processusId) {
		// FIXME OLD: Faire un finder appropri�
		try {
			List<LigneCommandeDTO> lignesCde = new ArrayList<LigneCommandeDTO>();
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> processusLCs = processusLCHome.findByEstLivreParProcessus(processusId);
			for (ProcessusLC processusLc : processusLCs) {
				LigneCommande lc = processusLc.getLinkLivreLigneCommande();
				lignesCde.add(new LigneCommandeDTO(lc));
			}
			return lignesCde;
		} catch (FinderException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeInduiteByLigneCommande(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeInduiteByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeInduiteByLigneCommande", "Recherche des lignes de commande pour la ligne de commande " + ligneCommandeId);
		List<LigneCommandeDTO> ligneCommandeDTOs = new ArrayList<LigneCommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCommande> lignesCommande = ligneCommandeHome.findByInduiteParLigneCommande(ligneCommandeId);
			for (LigneCommande ligneCde : lignesCommande) {
				ligneCommandeDTOs.add(new LigneCommandeDTO(ligneCde));
			}
			return ligneCommandeDTOs;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeInduiteByLigneCommande", "Probleme lors de la recherche de la ligne de commande pour la ligne de commande " + ligneCommandeId, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByRefExterne(java.lang.String)
	 */
	public LigneCommandeDTO findLigneCommandeByRefExterne(String refExterne) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByRefExterne", "Recherche de la ligne de commande pour la refExterne : " + refExterne);
		LigneCommandeDTO ligneCommandeDTO = null;
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCommande> lignesCommande = ligneCommandeHome.findParRefExterne(refExterne);
			if (!lignesCommande.isEmpty()) {
				ligneCommandeDTO = new LigneCommandeDTO(lignesCommande.iterator().next());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByRefExterne", "Probleme lors de la recherche de la ligne de commande pour la refExterne : " + refExterne, fe);
			throw new EJBException(fe);
		}
		return ligneCommandeDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByRefExterneEtProcessusNonTerm(java.lang.String)
	 */
	public LigneCommandeDTO findLigneCommandeByRefExterneEtProcessusNonTerm(String refExterne) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByRefExterneEtProcessusNonTerm", "Recherche de la ligne de commande pour la refExterne : " + refExterne + " et pour un processus en �tat non termin�");
		LigneCommandeDTO ligneCommandeDTO = null;
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCommande> lignesCommande = ligneCommandeHome.findParRefExterneEtProcessusNonTERM(refExterne);
			if (!lignesCommande.isEmpty()) {
				ligneCommandeDTO = new LigneCommandeDTO(lignesCommande.iterator().next());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByRefExterneEtProcessusNonTerm",
					"Probleme lors de la recherche de la ligne de commande pour la refExterne : " + refExterne + " et pour un processus en �tat non termin�", fe);
			throw new EJBException(fe);
		}
		return ligneCommandeDTO;
	}

	/**
	 * Creates the dynamic ligne commande.
	 * 
	 * @param ligneCommandeId the ligneCommande id
	 * @param cle the cle
	 * @param valeur the valeur
	 */
	private void createDynamicLigneCommande(String ligneCommandeId, String cle, String valeur) {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(DynamicLigneCommande.FIELD_CLE, cle);
		values.put(DynamicLigneCommande.FIELD_VALEUR, valeur);
		values.put(DynamicLigneCommande.SLINK_POUR_LIGNE_COMMANDE, ligneCommandeId);
		String dynamicCommandeId = serviceManager.getGeneratorManager().generateKey();
		try {
			DynamicLigneCommande dynamicLigneCommande = dynamicLigneCommandeHome.create(dynamicCommandeId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			dynamicLigneCommande.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createDynamicCommande", "Erreur cr�ation dynamique ligne commande pour la ligne commande " + ligneCommandeId, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Gets the ligne commande entity.
	 * 
	 * @param id the id
	 * 
	 * @return the ligne commande entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private LigneCommande getLigneCommandeEntity(String id) throws FinderException {
		return ligneCommandeHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByIntervention(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeByIntervention(String interventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByEpCommercial", "Recherche des lignes de commande pour l'intervention " + interventionId);
		// TODO OLD: GTA revoir l'algo de cette m�thode (faire un finder plus appropri�)
		List<LigneCommandeDTO> ligneCommandeDTOs = new ArrayList<LigneCommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<OpProgrammee> ops = opProgrammeeHome.findByFaiteLorsIntervention(interventionId);
			for (OpProgrammee opProgrammee : ops) {
				@SuppressWarnings("unchecked")
				Collection<LienOpProgLdC> loplcs = opProgrammee.getLinkAppartientLigneCommande();
				for (LienOpProgLdC lienOpProgLdC : loplcs) {
					LigneCommande ligneCommande = lienOpProgLdC.getLinkAppartientLigneCommande();
					ligneCommandeDTOs.add(new LigneCommandeDTO(ligneCommande));
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByIntervention", "Probleme lors de la recherche des lignes de commande pour l'intervention " + interventionId, fe);
			throw new EJBException(fe);
		}
		return ligneCommandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByInterventionViaCommande(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeByInterventionViaCommande(String interventionId) {
		List<LigneCommandeDTO> lignesCdeDeInterv = findLigneCommandeByIntervention(interventionId);
		if (!lignesCdeDeInterv.isEmpty()) {
			LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(lignesCdeDeInterv);
			return findLigneCommandeByCommande(premiereLC.getIdCommande());
		}
		return new ArrayList<LigneCommandeDTO>();
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByOpProgrammee(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeByOpProgrammee(String opProgrammeeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByOpProgrammee", "Recherche des lignes de commande pour l'op�ration programm�e " + opProgrammeeId);
		// TODO OLD: GTA revoir l'algo de cette m�thode (faire un finder plus appropri�)
		List<LigneCommandeDTO> ligneCommandeDTOs = new ArrayList<LigneCommandeDTO>();
		try {
			OpProgrammee opProgrammee = getOpProgrammeeEntity(opProgrammeeId);
			@SuppressWarnings("unchecked")
			Collection<LienOpProgLdC> loplcs = opProgrammee.getLinkAppartientLigneCommande();
			for (LienOpProgLdC lienOpProgLdC : loplcs) {
				LigneCommande ligneCommande = lienOpProgLdC.getLinkAppartientLigneCommande();
				ligneCommandeDTOs.add(new LigneCommandeDTO(ligneCommande));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByOpProgrammee", "Probleme lors de la recherche des lignes de commande pour l'op�ration programm�e " + opProgrammeeId, fe);
			throw new EJBException(fe);
		}
		return ligneCommandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteLigneCmdSupParc(java.lang.String)
	 */
	public void deleteLigneCmdSupParc(String ligneCmdSupParcId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteLigneCmdSupParc", "Suppression de la ligneCmdSupParc " + ligneCmdSupParcId);
		try {
			LigneCmdSupParc ligneCmdSupParc = getLigneCmdSupParcEntity(ligneCmdSupParcId);
			ligneCmdSupParc.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLigneCmdSupParc", "Erreur suppression LigneCmdSupParc", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLigneCmdSupParc", "Erreur suppression LigneCmdSupParc", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLigneCmdSupParc", "Erreur suppression LigneCmdSupParc", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteLigneCommande(java.lang.String)
	 */
	public void deleteLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteLigneCommande", "Suppression de la LigneCommande et de ses champs dynamiques " + ligneCommandeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicLigneCommande> dynamicLigneCommandes = dynamicLigneCommandeHome.findByPourLigneCommande(ligneCommandeId);
			for (DynamicLigneCommande dynamicLigneCommande : dynamicLigneCommandes) {
				dynamicLigneCommande.remove();
			}
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeId);
			ligneCommande.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLigneCommande", "Erreur suppression LigneCommande", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLigneCommande", "Erreur suppression LigneCommande", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLigneCommande", "Erreur suppression LigneCommande", re);
			throw new EJBException(re);
		}
	}

	// --------------------------------------------------------------
	// LIGNE_CMD_SUP_PARC
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCmdSupParcByEpCommercial(java.lang.String)
	 */
	public List<LigneCmdSupParcDTO> findLigneCmdSupParcByEpCommercial(String epCommercialId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCmdSupParcByEpCommercial", "Recherche des LigneCmdSupParc pour l'EpCommercial " + epCommercialId);
		List<LigneCmdSupParcDTO> ligneCmdSupParcDTOs = new ArrayList<LigneCmdSupParcDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCmdSupParc> ligneCmdSupParcList = ligneCmdSupParcHome.findBySupprimeEPCommercial(epCommercialId);
			for (LigneCmdSupParc ligneCmdSupParc : ligneCmdSupParcList) {
				ligneCmdSupParcDTOs.add(new LigneCmdSupParcDTO(ligneCmdSupParc));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "ligneCmdSupParcDTOs", "Probleme lors de la recherche des LigneCmdSupParc pour l'EpCommercial " + epCommercialId, fe);
			throw new EJBException(fe);
		}
		return ligneCmdSupParcDTOs;
	}

	/**
	 * Gets the LigneCmdSupParc entity.
	 * 
	 * @param id the ligne cmd sup parc id
	 * 
	 * @return LigneCmdSupParc
	 * 
	 * @throws FinderException the finder exception
	 */
	private LigneCmdSupParc getLigneCmdSupParcEntity(String id) throws FinderException {
		return ligneCmdSupParcHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * Cr�e une occurence de PsSouhaite.<br/>
	 * 
	 * @param psSouhaiteDTO the PsSouhaiteDTO
	 * 
	 */
	public void createPsSouhaite(PsSouhaiteDTO psSouhaiteDTO) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createPsSouhaite", "Cr�ation du ps souhaite");
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(PsSouhaite.FIELD_ID_EXTERNE, psSouhaiteDTO.getIdExterne());
		if (psSouhaiteDTO.getPorteSurOffre() != null) {
			values.put(PsSouhaite.FIELD_PORTE_SUR_OFFRE, psSouhaiteDTO.getPorteSurOffre().getId());
		}
		if (psSouhaiteDTO.getDetentionPs() != null) {
			values.put(PsSouhaite.FIELD_DETIENT_DETENTION_P_S, psSouhaiteDTO.getDetentionPs().getId());
		}
		if (psSouhaiteDTO.getDescriptionPs() != null) {
			values.put(PsSouhaite.FIELD_EST_DESCRIPTION_P_S, psSouhaiteDTO.getDescriptionPs().getId());
		}
		values.put(PsSouhaite.FIELD_ND, psSouhaiteDTO.getNd());

		try {
			PsSouhaite psSouhaite = psSouhaiteHome.create(psSouhaiteDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			psSouhaite.setLinks(values);
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createPsSouhaite", "Erreur cr�ation du ps souhaite " + psSouhaiteDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Cr�e une occurence de InstanceOg.<br/>
	 * 
	 * @param instanceOgDTO the InstanceOgDTO
	 * 
	 */
	public void createInstanceOg(InstanceOgDTO instanceOgDTO) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createInstanceOG", "Cr�ation de l'instance OG");
		HashMap<String, Object> values = new HashMap<String, Object>(1);
		if (instanceOgDTO.getOffreGroupee() != null) {
			values.put(aps.InstanceOG.FIELD_CONCERNE_OFFRE_GROUPEE, instanceOgDTO.getOffreGroupee().getId());
		}
		if (instanceOgDTO.getCommande() != null) {
			values.put(aps.InstanceOG.SLINK_COMPOSE_COMMANDE, instanceOgDTO.getCommande().getId());
		}
		try {
			InstanceOG instanceOg = instanceOGHome.create(instanceOgDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			instanceOg.setLinks(values);
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createInstanceOG", "Erreur cr�ation de l'instance OG " + instanceOgDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Cr�e une occurence de LigneCmdCatalogue.<br/>
	 * 
	 * @param ligneCmdCatalogueDTO the ligneCmdCatalogue dto
	 * 
	 */
	public void createLigneCmdCatalogue(LigneCmdCatalogueDTO ligneCmdCatalogueDTO) {
		serviceManager.getLoggerManager().fine(CLASSNAME, "createLigneCmdCatalogue", "Cr�ation de la ligne commande catalogue");
		HashMap<String, Object> values = new HashMap<String, Object>();
		if (ligneCmdCatalogueDTO.getInstanceOg() != null) {
			values.put(aps.LigneCmdCatalogue.SLINK_COMPOSE_INSTANCE_O_G, ligneCmdCatalogueDTO.getInstanceOg().getId());
		}
		if (ligneCmdCatalogueDTO.getPsSouhaite() != null) {
			values.put(aps.LigneCmdCatalogue.SLINK_DECRITE_PAR_PS_SOUHAITE, ligneCmdCatalogueDTO.getPsSouhaite().getId());
		}
		values.put(aps.LigneCmdCatalogue.SLINK_EST_LIGNE_COMMANDE, ligneCmdCatalogueDTO.getLigneCommandeId());
		if (ligneCmdCatalogueDTO.getGroupeOffres() != null) {
			values.put(aps.LigneCmdCatalogue.FIELD_CONCERNE_GROUPE_OFFRES, ligneCmdCatalogueDTO.getGroupeOffres().getId());
		}
		try {
			LigneCmdCatalogue ligneCmdCatalogue = ligneCmdCatalogueHome.create(ligneCmdCatalogueDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			ligneCmdCatalogue.setLinks(values);
		} catch (CreateException ce) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "createLigneCmdCatalogue", "Erreur cr�ation de la ligne commande catalogue " + ligneCmdCatalogueDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Cr�e une occurence de LigneCmdSupParc.<br/>
	 * 
	 * @param ligneCmdSupParcDTO the ligneCmdSupParc dto
	 * 
	 */
	public void createLigneCmdSupParc(LigneCmdSupParcDTO ligneCmdSupParcDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createLigneCmdSupParc",
				"Cr�ation de la relation Commande (id = " + ligneCmdSupParcDTO.getCommande().getId() + ")/Ligne de commande (id = " + ligneCmdSupParcDTO.getLigneCommandeId() + ")/EpCommercial (id = " + ligneCmdSupParcDTO.getEpCommercial().getId() + ")");
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(LigneCmdSupParc.SLINK_COMPOSE_COMMANDE, ligneCmdSupParcDTO.getCommande().getId());
			values.put(LigneCmdSupParc.SLINK_EST_LIGNE_COMMANDE, ligneCmdSupParcDTO.getLigneCommandeId());
			values.put(LigneCmdSupParc.SLINK_SUPPRIME_E_P_COMMERCIAL, ligneCmdSupParcDTO.getEpCommercial().getId());
			LigneCmdSupParc ligneCmdSupParc = ligneCmdSupParcHome.create(ligneCmdSupParcDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			ligneCmdSupParc.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createProcessusLC", "Erreur cr�ation de la relation Processus/Ligne de commande: id " + ligneCmdSupParcDTO.getId(), ce);
			throw new EJBException(ce);
		}

	}

	// --------------------------------------------------------------
	// LIGNE_CMD_MOD_PARC
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCmdModParcByEpCommercial(java.lang.String)
	 */
	public List<LigneCmdModParcDTO> findLigneCmdModParcByEpCommercial(String epCommercialId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCmdModParcByEpCommercial", "Recherche des LigneCmdModParc pour l'EpCommercial " + epCommercialId);
		List<LigneCmdModParcDTO> ligneCmdModParcDTOs = new ArrayList<LigneCmdModParcDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCmdModParc> ligneCmdModParcList = ligneCmdModParcHome.findByModifieEPCommercial(epCommercialId);
			for (LigneCmdModParc ligneCmdModParc : ligneCmdModParcList) {
				ligneCmdModParcDTOs.add(new LigneCmdModParcDTO(ligneCmdModParc));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "ligneCmdModParcDTOs", "Probleme lors de la recherche des LigneCmdModParc pour l'EpCommercial " + epCommercialId, fe);
			throw new EJBException(fe);
		}
		return ligneCmdModParcDTOs;
	}

	// --------------------------------------------------------------
	// PROCESSUS_LC
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByEstLivreParProcessus(java.lang.String)
	 */
	public List<LigneCommandeDTO> findLigneCommandeByEstLivreParProcessus(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByCommande", "Recherche des lignes de commande livr�es par le processus " + processusId);
		List<LigneCommandeDTO> ligneCommandeDTOs = new ArrayList<LigneCommandeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> plcs = processusLCHome.findByEstLivreParProcessus(processusId);
			for (ProcessusLC processusLC : plcs) {
				ligneCommandeDTOs.add(new LigneCommandeDTO(processusLC.getLinkLivreLigneCommande()));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByEstLivreParProcessus", "Pas de de ligne de commande avec le processus id = " + processusId, fe);
			throw new EJBException(fe);
		}
		return ligneCommandeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findLigneCommandeByEstLivreParProcessusAndUneSeule(java.lang.String)
	 */
	public LigneCommandeDTO findLigneCommandeByEstLivreParProcessusAndUneSeule(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findLigneCommandeByEstLivreParProcessusAndUneSeule", "Recherche d'une des lignes de commande livr�es par le processus " + processusId);
		try {
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> plcs = processusLCHome.findByEstLivreParProcessus(processusId);
			Iterator<ProcessusLC> it = plcs.iterator();
			if (it.hasNext()) {
				return new LigneCommandeDTO(it.next().getLinkLivreLigneCommande());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findLigneCommandeByEstLivreParProcessusAndUneSeule", "Pas de de ligne de commande avec le processus id = " + processusId, fe);
			throw new EJBException(fe);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createProcessusLC(com.soliste.bolbec.livraison.service.model.ProcessusLcDTO)
	 */
	public ProcessusLcDTO createProcessusLC(ProcessusLcDTO processusLcDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createProcessusLC", "Cr�ation de la relation Processus (id = " + processusLcDTO.getProcessus().getId() + ")/Ligne de commande (id = " + processusLcDTO.getLigneCommande().getId());
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(ProcessusLC.SLINK_EST_LIVRE_PAR_PROCESSUS, processusLcDTO.getProcessus().getId());
			values.put(ProcessusLC.SLINK_LIVRE_LIGNE_COMMANDE, processusLcDTO.getLigneCommande().getId());
			ProcessusLC processusLC = processusLCHome.create(processusLcDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			processusLC.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createProcessusLC", "Erreur cr�ation de la relation Processus/Ligne de commande: id " + processusLcDTO.getId(), ce);
			throw new EJBException(ce);
		}
		return processusLcDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteProcessusLCByLigneCommande(java.lang.String)
	 */
	public void deleteProcessusLCByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteProcessusLCByLigneCommande", "Recherche et suppression des processusLC pour la ligne de commande " + ligneCommandeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> plcs = processusLCHome.findByLivreLigneCommande(ligneCommandeId);
			for (ProcessusLC processusLC : plcs) {
				processusLC.remove();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteProcessusLCByLigneCommande", "Pas de processusLC pour la ligne de commande = " + ligneCommandeId, fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteProcessusLCByLigneCommande", "Erreur suppression processusLC", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteProcessusLCByLigneCommande", "Erreur suppression processusLC", re);
			throw new EJBException(re);
		}
	}

	// --------------------------------------------------------------
	// EP_COMMERCIAL et DYNAMIC_EP_COMMERCIAL
	// --------------------------------------------------------------

	/**
	 * 
	 */
	public Map<String, String> findDynamicsEpCommercial(String epCommercialId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findDynamicsEpCommercial", "Recherche des champs dynamiques pour l'ep commercial " + epCommercialId);
		Map<String, String> dynamics = new HashMap<String, String>();
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicEPCommercial> dynamicsAps = dynamicEPCommercialHome.findByPourEPCommercial(epCommercialId);
			for (DynamicEPCommercial dynamic : dynamicsAps) {
				dynamics.put(dynamic.getCle(), dynamic.getValeur());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findDynamicsEpCommercial", "Probl�me lors de la recherche des champs dynamiques pour l'ep commercial " + epCommercialId, fe);
			throw new EJBException(fe);
		}
		return dynamics;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteDynamicEpCommercial(java.lang.String)
	 */
	public void deleteDynamicEpCommercial(String epCommercialId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteDynamicEpCommercial", "Suppression des champs dynamique de l'ep commercial " + epCommercialId);
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicEPCommercial> dynamicEpCommercials = dynamicEPCommercialHome.findByPourEPCommercial(epCommercialId);
			try {
				for (DynamicEPCommercial dynamicEPCommercial : dynamicEpCommercials) {
					dynamicEPCommercial.remove();
				}
			} catch (EJBException ee) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteDynamicEpCommercial", "Probleme suppression de la dynamique epCommercial de l'epCommercial " + epCommercialId, ee);
				throw new EJBException(ee);
			} catch (RemoveException re) {
				ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteDynamicEpCommercial", "Probleme suppression de la dynamique epCommercial de l'epCommercial " + epCommercialId, re);
				throw new EJBException(re);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteDynamicEpCommercial", "Probleme suppresion de la dynamique epCommercial de l'epCommercial " + epCommercialId, fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findEPCommercialByEpCommercialSupport(java.lang.String)
	 */
	public List<EpCommercialDTO> findEPCommercialByEpCommercialSupport(String epcSupportId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEPCommercialByEpCommercialSupport", "Recherche les ep commerciaux pour ep commercial support " + epcSupportId);
		List<EpCommercialDTO> epCommercialDTOs = new ArrayList<EpCommercialDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<EPCommercial> epcs = epCommercialHome.findByEstSupporteParEPCommercial(epcSupportId);
			for (EPCommercial epCommercial : epcs) {
				epCommercialDTOs.add(new EpCommercialDTO(epCommercial));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEPCommercialByEpCommercialSupport", "Pas d'epCommercial ayant pou supportId = " + epcSupportId, fe);
			throw new EJBException(fe);
		}
		return epCommercialDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findEPCommercialByInstanceFT(java.lang.String)
	 */
	public List<EpCommercialDTO> findEPCommercialByInstanceFT(String instanceFTId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEPCommercialByInstanceFT", "Recherche les ep commerciaux pour instance FT " + instanceFTId);
		List<EpCommercialDTO> epCommercialDTOs = new ArrayList<EpCommercialDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<EPCommercial> epcs = epCommercialHome.findByAInstanceFT(instanceFTId);
			for (EPCommercial epCommercial : epcs) {
				epCommercialDTOs.add(new EpCommercialDTO(epCommercial));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEPCommercialByInstanceFT", "Pas d'epCommercial ayant pour instance FT = " + instanceFTId, fe);
			throw new EJBException(fe);
		}
		return epCommercialDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findEPCommercialByPsSouhaiteSupport(java.lang.String)
	 */
	public List<EpCommercialDTO> findEPCommercialByPsSouhaiteSupport(String pssSupportId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEPCommercialByEpCommercialSupport", "Recherche les ep commerciaux pour ps souhaite support " + pssSupportId);
		List<EpCommercialDTO> epCommercialDTOs = new ArrayList<EpCommercialDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<EPCommercial> epcs = epCommercialHome.findByEstSupporteParPsSouhaite(pssSupportId);
			for (EPCommercial epCommercial : epcs) {
				epCommercialDTOs.add(new EpCommercialDTO(epCommercial));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEPCommercialByEpCommercialSupport", "Pas d'epCommercial ayant pour psSouhaiteId = " + pssSupportId, fe);
			throw new EJBException(fe);
		}
		return epCommercialDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findEpCommercialByLigneCommande(java.lang.String)
	 */
	public EpCommercialDTO findEpCommercialByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEpCommercialByLigneCommande", "Recherche les ep commerciaux pour la ligne de commande " + ligneCommandeId);
		// TODO OLD: GTA revoir l'algo de cette m�thode (faire des finders plus appropri�s)
		EpCommercialDTO epCommercialDTO = null;
		EPCommercial epCommercial = null;
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeId);
			// 1. la ligne cde est une ligne de commande de type CREATION (catalogue)
			LigneCmdCatalogue ligneCmdCatalogue = ligneCommande.getLinkALCCLigneCmdCatalogue();
			if (ligneCmdCatalogue != null) {
				InstanceOG instanceOG = ligneCmdCatalogue.getLinkComposeInstanceOG();
				if (instanceOG != null) {
					epCommercial = instanceOG.getLinkAPourAccesEPCommercial();
				}
			} else {
				// 2. la ligne cde est une ligne de commande de type MODIFICATION
				LigneCmdModParc ligneCmdModParc = ligneCommande.getLinkALCMPLigneCmdModParc();
				if (ligneCmdModParc != null) {
					// c'est une ligne de commande modification, on r�cup�re l'EP Commercial associ�
					epCommercial = ligneCmdModParc.getLinkModifieEPCommercial();
				} else {
					// 3. la ligne cde est une ligne de commande de type SUPPRESSION
					LigneCmdSupParc ligneCmdSupParc = ligneCommande.getLinkALCSPLigneCmdSupParc();
					if (ligneCmdSupParc != null) {
						epCommercial = ligneCmdSupParc.getLinkSupprimeEPCommercial();
					} else {
						throw new RuntimeException("ligne de commande de type inconnu");
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEpCommercialByLigneCommande", "Probl�me lors de la recherche d'un epCommercial de la ligne de commande: id = " + ligneCommandeId, fe);
			return null;
		}
		if (epCommercial != null) {
			epCommercialDTO = new EpCommercialDTO(epCommercial);
		}
		return epCommercialDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findEpCommercialByLigneCommandeSU(java.lang.String)
	 */
	public EpCommercialDTO findEpCommercialByLigneCommandeSU(String ligneCommandeSUId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEpCommercialByLigneCommandeSU", "Recherche les ep commerciaux pour la ligne de commande " + ligneCommandeSUId);
		EpCommercialDTO epCommercialDTO = null;
		EPCommercial epCommercial = null;
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeSUId);
			LigneCmdSupParc ligneCmdSupParc = ligneCommande.getLinkALCSPLigneCmdSupParc();
			if (ligneCmdSupParc != null) {
				// La ligne cde est une ligne de commande de type SUPPRESSION
				epCommercial = ligneCmdSupParc.getLinkSupprimeEPCommercial();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEpCommercialByLigneCommandeSU", "Probl�me lors de la recherche d'un epCommercial de la ligne de commande: id = " + ligneCommandeSUId, fe);
			return null;
		}
		if (epCommercial != null) {
			epCommercialDTO = new EpCommercialDTO(epCommercial);
		}
		return epCommercialDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateDynamicEpCommercial(com.soliste.bolbec.livraison.service.model.EpCommercialDTO)
	 */
	public void updateDynamicEpCommercial(EpCommercialDTO epCommercialDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateDynamicEpCommercial", "Mise � jour des champs dynamiques de l'epCommercial " + epCommercialDTO.getId());
		Map<String, String> dynamicEpCommercials = epCommercialDTO.getDynamicEpCommercials();
		if (!dynamicEpCommercials.isEmpty()) {
			String epCommercialId = epCommercialDTO.getId();
			try {
				// recup�ration de tous les champs dynamiques pour cette commande
				@SuppressWarnings("unchecked")
				Collection<DynamicEPCommercial> dynamicEpCommercialsAps = dynamicEPCommercialHome.findByPourEPCommercial(epCommercialId);
				String cle;
				String valeur;
				String cleAps;
				String valeurAps;
				for (Entry<String, String> dynamicEPCommercialEntry : dynamicEpCommercials.entrySet()) {
					boolean isUpdated = false;
					cle = dynamicEPCommercialEntry.getKey();
					valeur = dynamicEPCommercialEntry.getValue();
					Iterator<DynamicEPCommercial> it = dynamicEpCommercialsAps.iterator();
					while (it.hasNext()) {
						DynamicEPCommercial dynamicEPCommercial = it.next();
						cleAps = dynamicEPCommercial.getCle();
						valeurAps = dynamicEPCommercial.getValeur();
						if (StringUtils.equals(cleAps, cle)) {
							if (StringUtils.isNotEmpty(valeur)) {
								if (!StringUtils.equals(valeurAps, valeur)) {
									// maj du dynamic existant
									dynamicEPCommercial.setValeur(valeur);
									long timestamp = dynamicEPCommercial.getTimestamp() + 1;
									dynamicEPCommercial.setTimestamp(timestamp);
								}
							} else {
								// on supprime la valeur en base si elle est nulle
								try {
									dynamicEPCommercial.remove();
									it.remove();
								} catch (EJBException e) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicEpCommercial", "Probl�me lors de la suppression du dynamique ep commercial", e);
									throw new EJBException(e);
								} catch (RemoveException re) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicEpCommercial", "Probl�me lors de la suppression du dynamique ep commercial", re);
									throw new EJBException(re);
								}
							}
							isUpdated = true;
							break;
						}
					}
					// Si on n'a pas mis � jour la table dynamique alors on insere un nouvel enregistrement
					if (!isUpdated) {
						if (StringUtils.isNotEmpty(valeur)) {
							createDynamicEPCommercial(epCommercialId, cle, valeur);
						}
					}
				}
			} catch (FinderException fe) {
				// Cr�ation des champs dynamiques
				String cle;
				String valeur;
				for (Entry<String, String> dynamicEPCommercialEntry : dynamicEpCommercials.entrySet()) {
					cle = dynamicEPCommercialEntry.getKey();
					valeur = dynamicEPCommercialEntry.getValue();
					if (StringUtils.isNotEmpty(valeur)) {
						createDynamicEPCommercial(epCommercialId, cle, valeur);
					}
				}
			}

		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createEpCommercial(com.soliste.bolbec.livraison.service.model.EpCommercialDTO)
	 */
	public void createEpCommercial(EpCommercialDTO epCommercialDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createEpCommercial", "Cr�ation d'un ep Commercial (id = " + epCommercialDTO.getId() + ")");
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(EPCommercial.FIELD_DATE_MES, epCommercialDTO.getDatabaseDateDateMes());
			values.put(EPCommercial.FIELD_DATE_SOUHAITEE, epCommercialDTO.getDatabaseDateDateSouhaitee());
			values.put(EPCommercial.FIELD_ETAT, epCommercialDTO.getEtat());
			values.put(EPCommercial.FIELD_ID_EXTERNE, epCommercialDTO.getIdExterne());
			values.put(EPCommercial.FIELD_ND, epCommercialDTO.getNd());
			values.put(EPCommercial.FIELD_NDPLP, epCommercialDTO.getNdplp());
			values.put(EPCommercial.FIELD_OFFRE_H_D, epCommercialDTO.getOffreHd());
			values.put(EPCommercial.FIELD_EST_OFFRE, epCommercialDTO.getOffre() != null ? epCommercialDTO.getOffre().getId() : null);
			values.put(EPCommercial.FIELD_POUR_DETENTION_P_S, epCommercialDTO.getDetentionPs() != null ? epCommercialDTO.getDetentionPs().getId() : null);
			values.put(EPCommercial.SLINK_A_INSTANCE_F_T, epCommercialDTO.getInstanceFt() != null ? epCommercialDTO.getInstanceFt().getId() : null);
			values.put(EPCommercial.SLINK_CONCERNE_ACCES_CLIENT, epCommercialDTO.getAccesClient() != null ? epCommercialDTO.getAccesClient().getId() : null);
			values.put(EPCommercial.SLINK_CONTRACTE_PAR_CLIENT, epCommercialDTO.getContracteParClient() != null ? epCommercialDTO.getContracteParClient().getId() : null);
			values.put(EPCommercial.SLINK_EST_SUPPORTE_PAR_E_P_COMMERCIAL, epCommercialDTO.getSupporteParEpCommercial() != null ? epCommercialDTO.getSupporteParEpCommercial().getId() : null);
			values.put(EPCommercial.SLINK_EST_SUPPORTE_PAR_PS_SOUHAITE, epCommercialDTO.getPsSouhaite() != null ? epCommercialDTO.getPsSouhaite().getId() : null);
			values.put(EPCommercial.SLINK_LIVRE_A_CLIENT, epCommercialDTO.getLivreAClient() != null ? epCommercialDTO.getLivreAClient().getId() : null);
			EPCommercial epCommercial = epCommercialHome.create(epCommercialDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			epCommercial.setLinks(values);
			createDynamicEpCommercial(epCommercialDTO);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createEpCommercial", "Erreur cr�ation de l'EP Commercial: id " + epCommercialDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Creates the dynamic ep commercial.
	 * 
	 * @param epCommercialDTO the ep commercial dto
	 */
	private void createDynamicEpCommercial(EpCommercialDTO epCommercialDTO) {
		// Cr�ation des dynamiques
		Map<String, String> dynamics = epCommercialDTO.getDynamicEpCommercials();
		for (Entry<String, String> dynamic : dynamics.entrySet()) {
			String value = dynamic.getValue();
			if (StringUtils.isNotBlank(value)) {
				createDynamicEPCommercial(epCommercialDTO.getId(), dynamic.getKey(), value);
			}

		}
	}

	/**
	 * Creates the dynamic EPCommercial.
	 * 
	 * @param epCommercialId the EPCommercial id
	 * @param cle the cle
	 * @param valeur the valeur
	 */
	private void createDynamicEPCommercial(String epCommercialId, String cle, String valeur) {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(DynamicEPCommercial.FIELD_CLE, cle);
		values.put(DynamicEPCommercial.FIELD_VALEUR, valeur);
		values.put(DynamicEPCommercial.SLINK_POUR_E_P_COMMERCIAL, epCommercialId);
		String dynamicEpCommercialId = serviceManager.getGeneratorManager().generateKey();
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createDynamicEPCommercial", "Cr�ation d'un dynamique ep Commercial (id = " + dynamicEpCommercialId + ") et ep commercial id (" + epCommercialId + ")");
		try {
			DynamicEPCommercial dynamicEPCommercial = dynamicEPCommercialHome.create(dynamicEpCommercialId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			dynamicEPCommercial.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createDynamicEPCommercial", "Erreur cr�ation dynamique EPCommercial pour l'EPCommercial " + epCommercialId, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findEpCommercialByAccesClient(java.lang.String)
	 */
	public List<EpCommercialDTO> findEpCommercialByAccesClient(String idAccesClient) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findEpCommercialByAccesClient", "Recherche les ep commerciaux pour l'acces client " + idAccesClient);
		List<EpCommercialDTO> epCommercialDTOs = new ArrayList<EpCommercialDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<EPCommercial> epcs = epCommercialHome.findByConcerneAccesClient(idAccesClient);
			for (EPCommercial epCommercial : epcs) {
				epCommercialDTOs.add(new EpCommercialDTO(epCommercial));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findEPCommercialByEpCommercialSupport", "Pas d'epCommercial ayant pour acces client = " + idAccesClient, fe);
			throw new EJBException(fe);
		}
		return epCommercialDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteEpCommercial(String)
	 */
	public void deleteEpCommercial(String epCommercialId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteEpCommercial", "Suppression de l'EpCommercial et de ses champs dynamiques " + epCommercialId);
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicEPCommercial> dynamicEpCommercials = dynamicEPCommercialHome.findByPourEPCommercial(epCommercialId);
			for (DynamicEPCommercial dynamicEPCommercial : dynamicEpCommercials) {
				dynamicEPCommercial.remove();
			}
			EPCommercial epCommercial = getEpCommercialEntity(epCommercialId);
			epCommercial.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteEpCommercial", "Erreur suppression EpCommercial", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteEpCommercial", "Erreur suppression EpCommercial", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteEpCommercial", "Erreur suppression EpCommercial", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getEpCommercial(java.lang.String)
	 */
	public EpCommercialDTO getEpCommercial(String epCommercialId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getEpCommercial", "Recherche de l'epCommercial " + epCommercialId);
		try {
			EPCommercial epCOmmercial = getEpCommercialEntity(epCommercialId);
			return new EpCommercialDTO(epCOmmercial);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getEpCommercial", "Pas de epCommercial " + epCommercialId, fe);
			return null;
		}
	}

	/**
	 * Gets the EPCommercial entity.
	 * 
	 * @param id the id
	 * 
	 * @return the EPCommercial entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private EPCommercial getEpCommercialEntity(String id) throws FinderException {
		return epCommercialHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateEpCommercialAccesClient(com.soliste.bolbec.livraison.service.model.EpCommercialDTO)
	 */
	public void updateEpCommercialAccesClient(EpCommercialDTO epCommercialDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateEpCommercialAccesClient", "Mise � jour de l'EpCommercial " + epCommercialDTO.getId());
		try {
			EPCommercial epCommercial = getEpCommercialEntity(epCommercialDTO.getId());
			if (epCommercialDTO.getAccesClient() == null) {
				epCommercial.setLinkConcerneAccesClient(null);
			} else {
				epCommercial.setLinkConcerneAccesClient(getAccesClientEntity(epCommercialDTO.getAccesClient().getId()));
			}
			long timestamp = epCommercial.getTimestamp() + 1;
			epCommercial.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateEpCommercialAccesClient", "Probl�me de mise � jour de l'EpCommercial : id = " + epCommercialDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateEpCommercial(com.soliste.bolbec.livraison.service.model.EpCommercialDTO)
	 */
	public void updateEpCommercial(EpCommercialDTO epCommercialDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateEpCommercial", "Mise � jour de l'EpCommercial " + epCommercialDTO.getId());
		try {
			EPCommercial epCommercial = getEpCommercialEntity(epCommercialDTO.getId());
			epCommercial.setDateMes(epCommercialDTO.getDatabaseDateDateMes());
			epCommercial.setDateSouhaitee(epCommercialDTO.getDatabaseDateDateSouhaitee());
			epCommercial.setEstOffre(epCommercialDTO.getOffre() == null ? null : epCommercialDTO.getOffre().getId());
			epCommercial.setEtat(epCommercialDTO.getEtat());
			epCommercial.setNd(epCommercialDTO.getNd());
			epCommercial.setNdplp(epCommercialDTO.getNdplp());
			epCommercial.setOffreHD(epCommercialDTO.getOffreHd());
			epCommercial.setPourDetentionPS(epCommercialDTO.getDetentionPs() == null ? null : epCommercialDTO.getDetentionPs().getId());
			epCommercial.setLinkAInstanceFT(epCommercialDTO.getInstanceFt() == null ? null : getInstanceFTEntity(epCommercialDTO.getInstanceFt().getId()));
			epCommercial.setLinkConcerneAccesClient(epCommercialDTO.getAccesClient() == null ? null : getAccesClientEntity(epCommercialDTO.getAccesClient().getId()));
			epCommercial.setLinkContracteParClient(epCommercialDTO.getContracteParClient() == null ? null : getClientEntity(epCommercialDTO.getContracteParClient().getId()));
			epCommercial.setLinkEstSupporteParPsSouhaite(epCommercialDTO.getPsSouhaite() == null ? null : getPsSouhaiteEntity(epCommercialDTO.getPsSouhaite().getId()));
			EpCommercialDTO supporteParEpCommercial = epCommercialDTO.getSupporteParEpCommercial();
			if (supporteParEpCommercial != null && StringUtils.isNotEmpty(supporteParEpCommercial.getId())) {
				epCommercial.setLinkEstSupporteParEPCommercial(getEpCommercialEntity(supporteParEpCommercial.getId()));

			} else {
				epCommercial.setLinkEstSupporteParEPCommercial(null);
			}
			epCommercial.setLinkLivreAClient(epCommercialDTO.getLivreAClient() == null ? null : getClientEntity(epCommercialDTO.getLivreAClient().getId()));
			long timestamp = epCommercial.getTimestamp() + 1;
			epCommercial.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateEpCommercial", "Probl�me de mise � jour de l'EpCommercial : id = " + epCommercialDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateEpCommercialInstanceFT(com.soliste.bolbec.livraison.service.model.EpCommercialDTO)
	 */
	public void updateEpCommercialInstanceFT(EpCommercialDTO epCommercialDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateEpCommercialAccesClient", "Mise � jour de l'EpCommercial " + epCommercialDTO.getId());
		try {
			EPCommercial epCommercial = getEpCommercialEntity(epCommercialDTO.getId());
			if (epCommercialDTO.getInstanceFt() == null) {
				epCommercial.setLinkAInstanceFT(null);
			} else {
				epCommercial.setLinkAInstanceFT(getInstanceFTEntity(epCommercialDTO.getInstanceFt().getId()));
			}
			long timestamp = epCommercial.getTimestamp() + 1;
			epCommercial.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateEpCommercialAccesClient", "Probl�me de mise � jour de l'EpCommercial : id = " + epCommercialDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateEpCommercialNd(com.soliste.bolbec.livraison.service.model.EpCommercialDTO)
	 */
	public void updateEpCommercialNd(EpCommercialDTO epCommercialDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateEpCommercialNd", "Mise � jour de l'EpCommercial " + epCommercialDTO.getId());
		try {
			EPCommercial epCommercial = getEpCommercialEntity(epCommercialDTO.getId());
			epCommercial.setNd(epCommercialDTO.getNd());
			long timestamp = epCommercial.getTimestamp() + 1;
			epCommercial.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateEpCommercialNd", "Probl�me de mise � jour de l'EpCommercial : id = " + epCommercialDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * Gets the EPCommercial entity.
	 * 
	 * @param id the id
	 * 
	 * @return the EPCommercial entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private InstanceFT getInstanceFTEntity(String id) throws FinderException {
		return instanceFTHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// PS_SOUHAITE
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getOpProgrammee(java.lang.String)
	 */
	public PsSouhaiteDTO getPsSouhaite(String psSouhaiteId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getPsSouhaite", "Recherche du psSouhaite " + psSouhaiteId);
		try {
			PsSouhaite psSouhaite = getPsSouhaiteEntity(psSouhaiteId);
			return new PsSouhaiteDTO(psSouhaite);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getPsSouhaite", "Pas de psSouhaite " + psSouhaiteId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findPsSouhaiteByLigneCommande(java.lang.String)
	 */
	public PsSouhaiteDTO findPsSouhaiteByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findPsSouhaiteByLigneCommande", "Recherche les ps souhaite pour la ligne de commande " + ligneCommandeId);
		// TODO OLD: GTA revoir l'algo de cette m�thode (faire des finders plus appropri�s)
		PsSouhaiteDTO psSouhaiteDTO = null;
		PsSouhaite psSouhaite = null;
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeId);
			// 1. la ligne cde est une ligne de commande de type CREATION (catalogue)
			LigneCmdCatalogue ligneCmdCatalogue = ligneCommande.getLinkALCCLigneCmdCatalogue();
			if (ligneCmdCatalogue != null) {
				psSouhaite = ligneCmdCatalogue.getLinkDecriteParPsSouhaite();
			} else {
				// 2. la ligne cde est une ligne de commande de type MODIFICATION
				LigneCmdModParc ligneCmdModParc = ligneCommande.getLinkALCMPLigneCmdModParc();
				if (ligneCmdModParc != null) {
					psSouhaite = ligneCmdModParc.getLinkDecriteParPsSouhaite();
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findPsSouhaiteByLigneCommande", "Probl�me lors de la recherche d'un psSouhaite de la ligne de commande: id = " + ligneCommandeId, fe);
			return null;
		}
		if (psSouhaite != null) {
			psSouhaiteDTO = new PsSouhaiteDTO(psSouhaite);
		}
		return psSouhaiteDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findPsSouhaiteByLigneCommandeCR(java.lang.String)
	 */
	public PsSouhaiteDTO findPsSouhaiteByLigneCommandeCR(String ligneCommandeId) {
		String methode = "findPsSouhaiteByLigneCommandeCR";

		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, methode, "Recherche les ps souhaite pour la ligne de commande " + ligneCommandeId);
		PsSouhaiteDTO psSouhaiteDTO = null;
		PsSouhaite psSouhaite = null;
		try {
			LigneCommande ligneCommande = getLigneCommandeEntity(ligneCommandeId);
			// La ligne cde est une ligne de commande de type CREATION (catalogue)
			LigneCmdCatalogue ligneCmdCatalogue = ligneCommande.getLinkALCCLigneCmdCatalogue();
			if (ligneCmdCatalogue != null) {
				psSouhaite = ligneCmdCatalogue.getLinkDecriteParPsSouhaite();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, methode, "Probl�me lors de la recherche d'un psSouhaite de la ligne de commande: id = " + ligneCommandeId, fe);
			return null;
		}
		if (psSouhaite != null) {
			psSouhaiteDTO = new PsSouhaiteDTO(psSouhaite);
		}
		return psSouhaiteDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findPsSouhaiteByFourniParInstanceFT(java.lang.String)
	 */
	public PsSouhaiteDTO findPsSouhaiteByFourniParInstanceFT(String instanceFTId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findPsSouhaiteByFourniParInstanceFT", "Recherche le ps souhaite pour l'instance FT " + instanceFTId);
		try {
			@SuppressWarnings("unchecked")
			Collection<PsSouhaite> psSouhaites = psSouhaiteHome.findByFournitInstanceFT(instanceFTId);
			Iterator<PsSouhaite> it = psSouhaites.iterator();
			if (it.hasNext()) {
				PsSouhaite psSouhaite = it.next();
				return new PsSouhaiteDTO(psSouhaite);
			}
			return null;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findPsSouhaiteByFourniParInstanceFT", "Probl�me lors de la recherche d'un psSouhaite de l'instanceFT id = " + instanceFTId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findPsSouhaiteByAccesClient(java.lang.String)
	 */
	public List<PsSouhaiteDTO> findPsSouhaiteByAccesClient(String accesClientId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findPsSouhaiteByAccesClient", "Recherche les ps souhaites qui concernent l'acces client " + accesClientId);
		List<PsSouhaiteDTO> psSouhaiteDTOs = new ArrayList<PsSouhaiteDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<PsSouhaite> psSouhaites = psSouhaiteHome.findByConcerneAccesClient(accesClientId);
			for (PsSouhaite psSouhaite : psSouhaites) {
				psSouhaiteDTOs.add(new PsSouhaiteDTO(psSouhaite));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findPsSouhaiteByFourniParInstanceFT", "Probl�me lors de la recherche des ps souhaites qui concernent l'acces client " + accesClientId, fe);
			throw new EJBException(fe);
		}
		return psSouhaiteDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findDynamicsPsSouhaite(java.lang.String)
	 */
	public Map<String, String> findDynamicsPsSouhaite(String psSouhaiteId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findDynamicsPsSouhaite", "Recherche des champs dynamiques pour le ps souhaite " + psSouhaiteId);
		Map<String, String> dynamics = new HashMap<String, String>();
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicPsSouhaite> dynamicsAps = dynamicPsSouhaiteHome.findByPourPsSouhaite(psSouhaiteId);
			for (DynamicPsSouhaite dynamic : dynamicsAps) {
				dynamics.put(dynamic.getCle(), dynamic.getValeur());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findDynamicsPsSouhaite", "Probl�me lors de la recherche des champs dynamiques pour le ps souhaite " + psSouhaiteId, fe);
			throw new EJBException(fe);
		}
		return dynamics;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateDynamicPsSouhaite(com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO)
	 */
	public void updateDynamicPsSouhaite(PsSouhaiteDTO psSouhaiteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateDynamicPsSouhaite", "Mise � jour des champs dynamiques du ps souhaite " + psSouhaiteDTO.getId());
		Map<String, String> dynamicPsSouhaites = psSouhaiteDTO.getDynamicPsSouhaites();
		if (!dynamicPsSouhaites.isEmpty()) {
			String psSouhaiteId = psSouhaiteDTO.getId();
			try {
				// recup�ration de tous les champs dynamiques pour cette commande
				@SuppressWarnings("unchecked")
				Collection<DynamicPsSouhaite> dynamicPsSouhaiteAps = dynamicPsSouhaiteHome.findByPourPsSouhaite(psSouhaiteId);
				String cle;
				String valeur;
				String cleAps;
				String valeurAps;
				for (Entry<String, String> dynamicPsSouhaiteEntry : dynamicPsSouhaites.entrySet()) {
					boolean isUpdated = false;
					cle = dynamicPsSouhaiteEntry.getKey();
					valeur = dynamicPsSouhaiteEntry.getValue();
					Iterator<DynamicPsSouhaite> it = dynamicPsSouhaiteAps.iterator();
					while (it.hasNext()) {
						DynamicPsSouhaite dynamicPsSouhaite = it.next();
						cleAps = dynamicPsSouhaite.getCle();
						valeurAps = dynamicPsSouhaite.getValeur();
						if (StringUtils.equals(cleAps, cle)) {
							if (StringUtils.isNotEmpty(valeur)) {
								if (!StringUtils.equals(valeurAps, valeur)) {
									// maj du dynamic existant
									dynamicPsSouhaite.setValeur(valeur);
									long timestamp = dynamicPsSouhaite.getTimestamp() + 1;
									dynamicPsSouhaite.setTimestamp(timestamp);
								}
							} else {
								// on supprime la valeur en base si elle est nulle
								try {
									dynamicPsSouhaite.remove();
									it.remove();
								} catch (EJBException e) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicPsSouhaite", "Probl�me lors de la suppression du dynamique ps souhaite", e);
									throw new EJBException(e);
								} catch (RemoveException re) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicPsSouhaite", "Probl�me lors de la suppression du dynamique ps souhaite", re);
									throw new EJBException(re);
								}
							}
							isUpdated = true;
							break;
						}
					}
					// Si on n'a pas mis � jour la table dynamique alors on insere un nouvel enregistrement
					if (!isUpdated) {
						if (StringUtils.isNotEmpty(valeur)) {
							createDynamicPsSouhaite(psSouhaiteId, cle, valeur);
						}
					}
				}
			} catch (FinderException fe) {
				// Cr�ation des champs dynamiques
				String cle;
				String valeur;
				for (Entry<String, String> dynamicPsSouhaiteEntry : dynamicPsSouhaites.entrySet()) {
					cle = dynamicPsSouhaiteEntry.getKey();
					valeur = dynamicPsSouhaiteEntry.getValue();
					if (StringUtils.isNotEmpty(valeur)) {
						createDynamicPsSouhaite(psSouhaiteId, cle, valeur);
					}
				}
			}
		}
	}

	/**
	 * Creates the dynamic ps souhaite.
	 * 
	 * @param id the id
	 * @param cle the cle
	 * @param valeur the valeur
	 */
	private void createDynamicPsSouhaite(String id, String cle, String valeur) {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(DynamicPsSouhaite.FIELD_CLE, cle);
		values.put(DynamicPsSouhaite.FIELD_VALEUR, valeur);
		values.put(DynamicPsSouhaite.SLINK_POUR_PS_SOUHAITE, id);
		String dynamicId = serviceManager.getGeneratorManager().generateKey();
		try {
			DynamicPsSouhaite dynamicPsSouhaite = dynamicPsSouhaiteHome.create(dynamicId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			dynamicPsSouhaite.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createDynamicPsSouhaite", "Erreur cr�ation dynamique ps souhaite pour le ps souhaite " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updatePsSouhaiteAccesClient(com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO)
	 */
	public void updatePsSouhaiteAccesClient(PsSouhaiteDTO psSouhaiteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePsSouhaiteAccesClient", "Mise � jour du PsSouhaite " + psSouhaiteDTO.getId());
		try {
			PsSouhaite psSouhaite = getPsSouhaiteEntity(psSouhaiteDTO.getId());
			if (psSouhaiteDTO.getAccesClient() == null) {
				psSouhaite.setLinkConcerneAccesClient(null);
			} else {
				psSouhaite.setLinkConcerneAccesClient(getAccesClientEntity(psSouhaiteDTO.getAccesClient().getId()));
			}
			long timestamp = psSouhaite.getTimestamp() + 1;
			psSouhaite.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePsSouhaiteAccesClient", "Probl�me de mise � jour du PsSouhaite : id = " + psSouhaiteDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updatePsSouhaiteOffre(com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO)
	 */
	public void updatePsSouhaiteOffre(PsSouhaiteDTO psSouhaiteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePsSouhaiteOffre", "Mise � jour du PsSouhaite " + psSouhaiteDTO.getId());
		try {
			PsSouhaite psSouhaite = getPsSouhaiteEntity(psSouhaiteDTO.getId());
			if (psSouhaiteDTO.getPorteSurOffre() == null) {
				psSouhaite.setPorteSurOffre(null);
			} else {
				psSouhaite.setPorteSurOffre(psSouhaiteDTO.getPorteSurOffre().getId());
			}
			long timestamp = psSouhaite.getTimestamp() + 1;
			psSouhaite.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePsSouhaiteOffre", "Probl�me de mise � jour du PsSouhaite : id = " + psSouhaiteDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updatePsSouhaiteEpCommercial(com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO)
	 */
	public void updatePsSouhaiteEpCommercial(PsSouhaiteDTO psSouhaiteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePsSouhaiteEpCommercial", "Mise � jour du PsSouhaite " + psSouhaiteDTO.getId());
		try {
			PsSouhaite psSouhaite = getPsSouhaiteEntity(psSouhaiteDTO.getId());
			if (psSouhaiteDTO.getAppliqueSurEpCommercial() == null) {
				psSouhaite.setLinkAppliqueSurEPCommercial(null);
			} else {
				psSouhaite.setLinkAppliqueSurEPCommercial(getEpCommercialEntity(psSouhaiteDTO.getAppliqueSurEpCommercial().getId()));
			}
			long timestamp = psSouhaite.getTimestamp() + 1;
			psSouhaite.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePsSouhaiteEpCommercial", "Probl�me de mise � jour du PsSouhaite : id = " + psSouhaiteDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updatePsSouhaiteInstanceFT(com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO)
	 */
	public void updatePsSouhaiteInstanceFT(PsSouhaiteDTO psSouhaiteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePsSouhaiteInstanceFT", "Mise � jour du PsSouhaite " + psSouhaiteDTO.getId());
		try {
			PsSouhaite psSouhaite = getPsSouhaiteEntity(psSouhaiteDTO.getId());
			if (psSouhaiteDTO.getInstanceFt() == null) {
				psSouhaite.setLinkFournitInstanceFT(null);
			} else {
				psSouhaite.setLinkFournitInstanceFT(getInstanceFTEntity(psSouhaiteDTO.getInstanceFt().getId()));
			}
			long timestamp = psSouhaite.getTimestamp() + 1;
			psSouhaite.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePsSouhaiteInstanceFT", "Probl�me de mise � jour du PsSouhaite : id = " + psSouhaiteDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updatePsSouhaiteNd(com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO)
	 */
	public void updatePsSouhaiteNd(PsSouhaiteDTO psSouhaiteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updatePsSouhaiteNd", "Mise � jour du PsSouhaite " + psSouhaiteDTO.getId());
		try {
			PsSouhaite psSouhaite = getPsSouhaiteEntity(psSouhaiteDTO.getId());
			psSouhaite.setNd(psSouhaiteDTO.getNd());
			long timestamp = psSouhaite.getTimestamp() + 1;
			psSouhaite.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updatePsSouhaiteNd", "Probl�me de mise � jour du PsSouhaite : id = " + psSouhaiteDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * Gets the PsSouhaite entity.
	 * 
	 * @param id the id
	 * 
	 * @return the PsSouhaite entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private PsSouhaite getPsSouhaiteEntity(String id) throws FinderException {
		return psSouhaiteHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// INTERFERENCE
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findInterferenceByLigneCommande(java.lang.String)
	 */
	public List<InterferenceDTO> findInterferenceByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterferenceByLigneCommande", "Recherche les interferences pour la lignede commande " + ligneCommandeId);
		List<InterferenceDTO> interferenceDTOs = new ArrayList<InterferenceDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Interference> is = interferenceHome.findParLigneCde(ligneCommandeId);
			for (Interference interference : is) {
				interferenceDTOs.add(new InterferenceDTO(interference));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterferenceByLigneCommande", "Probleme lors de la recherche de la liste d'interference pour la ligne de commande = " + ligneCommandeId, fe);
			throw new EJBException(fe);
		}
		return interferenceDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findInterferenceByNd(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public List<InterferenceDTO> findInterferenceByNd(String nd) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterferenceByNd", "Recherche les interferences pour le nd " + nd);
		List<InterferenceDTO> interferenceDTOs = new ArrayList<InterferenceDTO>();
		try {
			Collection<Interference> is = interferenceHome.findParCmdEnInterferenceSurNDCat(nd);
			is.addAll(interferenceHome.findParCmdEnInterferenceSurNDSup(nd));
			is.addAll(interferenceHome.findParCmdEnInterferenceSurNDMod(nd));
			for (Interference interference : is) {
				interferenceDTOs.add(new InterferenceDTO(interference));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterferenceByNd", "Probleme lors de la recherche de la liste d'interference pour la ligne de commande = " + nd, fe);
			throw new EJBException(fe);
		}
		return interferenceDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findInterferenceByCommande(java.lang.String)
	 */
	public List<InterferenceDTO> findInterferenceByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterferenceByCommande", "Recherche les interferences pour la commande " + commandeId);
		List<InterferenceDTO> interferenceDTOs = new ArrayList<InterferenceDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<Interference> is = interferenceHome.findParCommande(commandeId);
			for (Interference interference : is) {
				interferenceDTOs.add(new InterferenceDTO(interference));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterferenceByCommande", "Probleme lors de la recherche de la liste d'interference concernant la commande " + commandeId, fe);
			throw new EJBException(fe);
		}
		return interferenceDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateInterferenceDateFin(com.soliste.bolbec.livraison.service.model.InterferenceDTO)
	 */
	public void updateInterferenceDateFin(InterferenceDTO interferenceDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateInterferenceDateFin", "Mise � jour de l'interference " + interferenceDTO.getId());
		try {
			Interference interference = getInterferenceEntity(interferenceDTO.getId());
			interference.setDateFin(interferenceDTO.getDateFin());
			long timestamp = interference.getTimestamp() + 1;
			interference.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateInterferenceDateFin", "Probl�me de mise � jour d'interference: id = " + interferenceDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createInterference(com.soliste.bolbec.livraison.service.model.InterferenceDTO)
	 */
	public void createInterference(InterferenceDTO interferenceDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createInterference", "Cr�ation de l'interf�rence" + interferenceDTO.getId());
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(Interference.FIELD_DATE_DEBUT, interferenceDTO.getDateDebut());
			values.put(Interference.FIELD_DATE_FIN, interferenceDTO.getDateFin());
			String commandeId = interferenceDTO.getCommandeId();
			if (StringUtils.isNotBlank(commandeId)) {
				values.put(Interference.FIELD_FK_CONCERNE_COMMANDE, commandeId);
			}
			String ligneCommandeId = interferenceDTO.getLigneCommandeId();
			if (StringUtils.isNotBlank(ligneCommandeId)) {
				values.put(Interference.FIELD_FK_EST_LIGNE_COMMANDE, ligneCommandeId);
			}
			String commandeInterferenteId = interferenceDTO.getCommandeInterferenteId();
			if (StringUtils.isNotBlank(commandeInterferenteId)) {
				values.put(Interference.FIELD_FK_INTERFERE_SUR_COMMANDE, commandeInterferenteId);
			}
			Interference interference = interferenceHome.create(interferenceDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			interference.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createInterference", "Erreur cr�ation de l'interf�rence " + interferenceDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteInterference(java.lang.String)
	 */
	public void deleteInterference(String interferenceId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteInterference", "Suppression de l'interference " + interferenceId);
		try {
			Interference interference = getInterferenceEntity(interferenceId);
			interference.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteInterference", "Erreur suppression Interference", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteInterference", "Erreur suppression Interference", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteInterference", "Erreur suppression Interference", re);
			throw new EJBException(re);
		}
	}

	/**
	 * Gets the interference entity.
	 * 
	 * @param id the id
	 * 
	 * @return the interference entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Interference getInterferenceEntity(String id) throws FinderException {
		return interferenceHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getInterference(java.lang.String)
	 */
	public InterferenceDTO getInterference(String interferenceId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getInterference", "Recherche de l'interference " + interferenceId);
		try {
			Interference interference = getInterferenceEntity(interferenceId);
			return new InterferenceDTO(interference);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getInterference", "Pas d'interference " + interferenceId, fe);
			return null;
		}
	}

	// --------------------------------------------------------------
	// TRANSIT_SYS_STAT et TRANSIT_SYS_STAT_REGUL
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteTransitSystStat(com.soliste.bolbec.livraison.service.model.TransitSystStatDTO)
	 */
	public void deleteTransitSystStat(TransitSystStatDTO transitSystStatDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteTransitSystStat", "Suppression du transitSysStat " + transitSystStatDTO.getId());
		try {
			TransitSystStat transitSystStat = getTransitSystStatEntity(transitSystStatDTO.getId());
			transitSystStat.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTransitSystStat", "Erreur suppression transitSysStat", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTransitSystStat", "Erreur suppression transitSysStat", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteTransitSystStat", "Erreur suppression transitSysStat", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findTransitSystStatByIdentFormatInstLocCdTransfert(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 * FIXME OLD: GTA faire un finder appropri�
	 */
	public List<TransitSystStatDTO> findTransitSystStatByIdentFormatInstLocCdTransfert(String identite, String formatExterne, String instanceLocalisation, String codeTransfert) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTransitSystStatByIdentFormatInstLocCdTransfert",
				"Recherche des transitSysStat pour l'identite " + identite + " , formatExterne " + formatExterne + " , instanceLocalisation " + instanceLocalisation + " et codeTransfert " + codeTransfert);
		List<TransitSystStatDTO> transitSystStatDTOs = new ArrayList<TransitSystStatDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<TransitSystStat> tss = transitSystStatHome.findParIdEntite(identite);
			for (TransitSystStat transitSystStat : tss) {
				if (StringUtils.equals(formatExterne, transitSystStat.getFormatExterne()) && StringUtils.equals(instanceLocalisation, transitSystStat.getAInstanceLocalisation()) && StringUtils.equals(codeTransfert, transitSystStat.getCodeTransfert())) {
					transitSystStatDTOs.add(new TransitSystStatDTO(transitSystStat));
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTransitSystStatByIdentFormatInstLocCdTransfert", "Probleme lors de la recherche de la liste de transit syst stat ", fe);
			throw new EJBException(fe);
		}
		return transitSystStatDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findTransitSystStatRegulByCmdAndCdTransfert(java.lang.String, java.lang.String)
	 */
	public List<TransitSystStatRegulDTO> findTransitSystStatRegulByCmdAndCdTransfert(String idCommande, String codeTransfert) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findTransitSystStatRegulByCmdAndCdTransfert", "Recherche des transitSysStat pour la commande " + idCommande + " et le codeTransfert " + codeTransfert);
		List<TransitSystStatRegulDTO> transitSystStatDTOs = new ArrayList<TransitSystStatRegulDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<TransitSystStatRegul> tss = transitSystStatRegulHome.findByCmdAndCdTransfert(idCommande, codeTransfert);
			for (TransitSystStatRegul transitSystStatRegul : tss) {
				transitSystStatDTOs.add(new TransitSystStatRegulDTO(transitSystStatRegul));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findTransitSystStatRegulByCmdAndCdTransfert", "Probleme lors de la recherche de la liste  de transit syst stat regul", fe);
			throw new EJBException(fe);
		}
		return transitSystStatDTOs;
	}

	/**
	 * Gets the transit syst stat entity.
	 * 
	 * @param id the id
	 * 
	 * @return the transit syst stat entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private TransitSystStat getTransitSystStatEntity(String id) throws FinderException {
		return transitSystStatHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// COMPLETUDE_REGROUPEMENT
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCompletudeRegroupementByCommande(java.lang.String)
	 */
	public List<CompletudeRegroupementDTO> findCompletudeRegroupementByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCompletudeRegroupementByCommande", "Recherche du completude regroupement pour la commande " + commandeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<CompletudeRegroupement> crs = completudeRegroupementHome.findByConcerneCommande(commandeId);
			List<CompletudeRegroupementDTO> result = new ArrayList<CompletudeRegroupementDTO>();
			for (CompletudeRegroupement completudeRegroupement : crs) {
				result.add(new CompletudeRegroupementDTO(completudeRegroupement));
			}
			return result;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCompletudeRegroupementByCommande", "Probleme lors de la recherche de la liste de CompletudeRegroupement", fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCompletudeRegroupementByIdAccesEtStatutCde(java.lang.String, java.lang.String)
	 */
	public List<CompletudeRegroupementDTO> findCompletudeRegroupementByIdAccesEtStatutCde(String idAcces, String statutCde) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCompletudeRegroupementByIdAccesEtStatutCde", "Recherche du completude regroupement pour idAcces " + idAcces + " et StatutCde " + statutCde);
		try {
			@SuppressWarnings("unchecked")
			Collection<CompletudeRegroupement> crs = completudeRegroupementHome.findByIdAccesEtStatutCde(idAcces, statutCde);
			List<CompletudeRegroupementDTO> result = new ArrayList<CompletudeRegroupementDTO>();
			for (CompletudeRegroupement completudeRegroupement : crs) {
				result.add(new CompletudeRegroupementDTO(completudeRegroupement));
			}
			return result;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCompletudeRegroupementByIdAccesEtStatutCde", "Probleme lors de la recherche de la liste de CompletudeRegroupement", fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCompletudeRegroupementByIdAcces(java.lang.String)
	 */
	public List<CompletudeRegroupementDTO> findCompletudeRegroupementByIdAcces(String idAcces) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCompletudeRegroupementByIdAcces", "Recherche du completude regroupement pour idAcces " + idAcces);
		try {
			@SuppressWarnings("unchecked")
			Collection<CompletudeRegroupement> crs = completudeRegroupementHome.findByIdAcces(idAcces);
			List<CompletudeRegroupementDTO> result = new ArrayList<CompletudeRegroupementDTO>();
			for (CompletudeRegroupement completudeRegroupement : crs) {
				result.add(new CompletudeRegroupementDTO(completudeRegroupement));
			}
			return result;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCompletudeRegroupementByIdAcces", "Probleme lors de la recherche de la liste de CompletudeRegroupement", fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteCompletudeRegroupementByCommande(java.lang.String)
	 */
	public void deleteCompletudeRegroupementByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteCompletudeRegroupementByCommande", "Suppression du completude regroupement pour la commande " + commandeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<CompletudeRegroupement> crs = completudeRegroupementHome.findByConcerneCommande(commandeId);
			Iterator<CompletudeRegroupement> it = crs.iterator();
			if (it.hasNext()) {
				CompletudeRegroupement completudeRegroupement = it.next();
				completudeRegroupement.remove();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByCommande", "Erreur suppression CompletudeRegroupement", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByCommande", "Erreur suppression CompletudeRegroupement", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByCommande", "Erreur suppression CompletudeRegroupement", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteCompletudeRegroupementByLieHDCommande(java.lang.String)
	 */
	public void deleteCompletudeRegroupementByLieHDCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteCompletudeRegroupementByLieHDCommande", "Suppression du completude regroupement pour la commande " + commandeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<CompletudeRegroupement> crs = completudeRegroupementHome.findByLieHdCommande(commandeId);
			Iterator<CompletudeRegroupement> it = crs.iterator();
			if (it.hasNext()) {
				CompletudeRegroupement completudeRegroupement = it.next();
				completudeRegroupement.remove();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByLieHDCommande", "Erreur suppression CompletudeRegroupement", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByLieHDCommande", "Erreur suppression CompletudeRegroupement", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByLieHDCommande", "Erreur suppression CompletudeRegroupement", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde(String, String, String)
	 */
	public void deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde(String idCommande, String idAccess, String idStatutCde) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde",
				"Suppression du completude regroupement pour la commande " + idCommande + ", le nd " + idAccess + " et le statut " + idStatutCde);
		try {
			@SuppressWarnings("unchecked")
			Collection<CompletudeRegroupement> crs = completudeRegroupementHome.findByCommandeEtIdAccesEtStatutCde(idCommande, idAccess, idStatutCde);
			Iterator<CompletudeRegroupement> it = crs.iterator();
			if (it.hasNext()) {
				CompletudeRegroupement completudeRegroupement = it.next();
				completudeRegroupement.remove();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde", "Erreur suppression CompletudeRegroupement", fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde", "Erreur suppression CompletudeRegroupement", ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde", "Erreur suppression CompletudeRegroupement", re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createCompletudeRegroupement(CompletudeRegroupementDTO)
	 */
	public CompletudeRegroupementDTO createCompletudeRegroupement(CompletudeRegroupementDTO completudeRegroupementDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createCompletudeRegroupement", "Cr�ation du completudeRegroupement" + completudeRegroupementDTO.getId());
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			StatutCommandeDTO statutCommande = completudeRegroupementDTO.getStatutCommande();
			if (statutCommande != null && StringUtils.isNotBlank(statutCommande.getId())) {
				values.put(CompletudeRegroupement.FIELD_EST_DANS_STATUT_COMMANDE, statutCommande.getId());
			}
			values.put(CompletudeRegroupement.FIELD_ID_ACCES, completudeRegroupementDTO.getIdAcces());
			values.put(CompletudeRegroupement.FIELD_JALON_REGROUPEMENT, completudeRegroupementDTO.getJalonRegroupement());
			CommandeDTO commande = completudeRegroupementDTO.getConcerneCommande();
			if (commande != null && StringUtils.isNotBlank(commande.getId())) {
				values.put(CompletudeRegroupement.SLINK_CONCERNE_COMMANDE, commande.getId());
			}
			CommandeDTO commandeLie = completudeRegroupementDTO.getLieHdCommande();
			if (commandeLie != null && StringUtils.isNotBlank(commandeLie.getId())) {
				values.put(CompletudeRegroupement.SLINK_LIE_HD_COMMANDE, commandeLie.getId());
			}
			CompletudeRegroupement completudeRegroupement = completudeRegroupementHome.create(completudeRegroupementDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			completudeRegroupement.setLinks(values);
			return completudeRegroupementDTO;
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createRapportIntervention", "Erreur cr�ation du completudeRegroupement " + completudeRegroupementDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCompletudeRegroupement(com.soliste.bolbec.livraison.service.model.CompletudeRegroupementDTO)
	 */
	public void updateCompletudeRegroupement(CompletudeRegroupementDTO completudeRegroupementDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCompletudeRegroupement", "Mise � jour du completudeRegroupement " + completudeRegroupementDTO.getId());
		try {
			CompletudeRegroupement completudeRegroupement = getCompletudeRegroupementEntity(completudeRegroupementDTO.getId());
			StatutCommandeDTO statutCommande = completudeRegroupementDTO.getStatutCommande();
			if (statutCommande != null && StringUtils.isNotBlank(statutCommande.getId())) {
				completudeRegroupement.setEstDansStatutCommande(statutCommande.getId());
			}
			CommandeDTO commande = completudeRegroupementDTO.getConcerneCommande();
			if (commande != null && StringUtils.isNotBlank(commande.getId())) {
				completudeRegroupement.setLinkConcerneCommande(getCommandeEntity(commande.getId()));
			}
			CommandeDTO commandeLie = completudeRegroupementDTO.getLieHdCommande();
			if (commandeLie != null && StringUtils.isNotBlank(commandeLie.getId())) {
				completudeRegroupement.setLinkLieHdCommande(getCommandeEntity(commandeLie.getId()));
			}
			completudeRegroupement.setIdAcces(completudeRegroupementDTO.getIdAcces());
			completudeRegroupement.setJalonRegroupement(completudeRegroupementDTO.getJalonRegroupement());
			long timestamp = completudeRegroupement.getTimestamp() + 1;
			completudeRegroupement.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCompletudeRegroupement", "Probl�me de mise � jour du completudeRegroupement " + completudeRegroupementDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateCompletudeRegroupementStatut(com.soliste.bolbec.livraison.service.model.CompletudeRegroupementDTO)
	 */
	public void updateCompletudeRegroupementStatut(CompletudeRegroupementDTO completudeRegroupementDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateCompletudeRegroupementStatut", "Mise � jour du statut de commande du completudeRegroupement " + completudeRegroupementDTO.getId());
		try {
			CompletudeRegroupement completudeRegroupement = getCompletudeRegroupementEntity(completudeRegroupementDTO.getId());
			StatutCommandeDTO statutCommande = completudeRegroupementDTO.getStatutCommande();
			if (statutCommande != null && StringUtils.isNotBlank(statutCommande.getId())) {
				completudeRegroupement.setEstDansStatutCommande(statutCommande.getId());
				long timestamp = completudeRegroupement.getTimestamp() + 1;
				completudeRegroupement.setTimestamp(timestamp);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateCompletudeRegroupementStatut", "Probl�me de mise � jour du statut de commande du completudeRegroupement " + completudeRegroupementDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * Gets the completude regroupement entity.
	 * 
	 * @param id the id
	 * 
	 * @return the completude regroupement entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private CompletudeRegroupement getCompletudeRegroupementEntity(String id) throws FinderException {
		return completudeRegroupementHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// OP_PROGRAMME
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getOpProgrammee(java.lang.String)
	 */
	public OpProgrammeeDTO getOpProgrammee(String opProgrammeeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getOpProgrammee", "Recherche de l'op programmee " + opProgrammeeId);
		try {
			OpProgrammee opProgrammee = getOpProgrammeeEntity(opProgrammeeId);
			return new OpProgrammeeDTO(opProgrammee);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getOpProgrammee", "Pas d'op programmee " + opProgrammeeId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createOpProgrammee(com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO)
	 */
	public OpProgrammeeDTO createOpProgrammee(OpProgrammeeDTO opProgrammeeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createOpProgrammee", "Cr�ation de l'op programmee" + opProgrammeeDTO);
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(OpProgrammee.FIELD_EST_TYPE_OP_PROGRAMMEE, opProgrammeeDTO.getTypeOpProgrammee().getId());
			InterventionDTO interventionDTO = opProgrammeeDTO.getIntervention();
			if (interventionDTO != null && StringUtils.isNotBlank(interventionDTO.getId())) {
				values.put(OpProgrammee.SLINK_FAITE_LORS_INTERVENTION, interventionDTO.getId());
			}
			OpProgrammee opProgrammee = opProgrammeeHome.create(opProgrammeeDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			opProgrammee.setLinks(values);
			opProgrammeeDTO = new OpProgrammeeDTO(opProgrammee);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createRapportIntervention", "Erreur cr�ation de l'op programmee " + opProgrammeeDTO.getId(), ce);
			throw new EJBException(ce);
		}
		return opProgrammeeDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findOpProgrammeeByIntervention(java.lang.String)
	 */
	public List<OpProgrammeeDTO> findOpProgrammeeByIntervention(String interventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findOpProgrammeeByIntervention", "Recherche des op programme pour l'intervention " + interventionId);
		List<OpProgrammeeDTO> opProgrammeeDTOs = new ArrayList<OpProgrammeeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<OpProgrammee> ops = opProgrammeeHome.findByFaiteLorsIntervention(interventionId);
			for (OpProgrammee opProgrammee : ops) {
				opProgrammeeDTOs.add(new OpProgrammeeDTO(opProgrammee));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findOpProgrammeeByIntervention", "Probleme lors de la recherche de la liste d'op programme pour l'intervention " + interventionId, fe);
			throw new EJBException(fe);
		}
		return opProgrammeeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findOpProgrammeByLigneCommande(java.lang.String)
	 */
	public List<OpProgrammeeDTO> findOpProgrammeByLigneCommande(String ligneCommandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findOpProgrammeByLigneCommande", "Recherche des op programme pour la ligne de commande " + ligneCommandeId);
		List<OpProgrammeeDTO> opProgrammeeDTOs = new ArrayList<OpProgrammeeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<LienOpProgLdC> loplcs = lienOpProgLdCHome.findByAppartientLigneCommande(ligneCommandeId);
			for (LienOpProgLdC lienOpProgLdC : loplcs) {
				OpProgrammee opProgrammee = lienOpProgLdC.getLinkRequiereOpProgrammee();
				opProgrammeeDTOs.add(new OpProgrammeeDTO(opProgrammee));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findOpProgrammeByLigneCommande", "Probleme lors de la recherche de la liste d'op programme pour la ligne de commande " + ligneCommandeId, fe);
			throw new EJBException(fe);
		}
		return opProgrammeeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findOpProgrammeeByCommande(java.lang.String)
	 */
	public List<OpProgrammeeDTO> findOpProgrammeeByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findOpProgrammeeByCommande", "Recherche des op programme pour la commande " + commandeId);
		// FIXME OLD: GTA Faire un finder appropri�
		List<OpProgrammeeDTO> opProgrammeeDTOs = new ArrayList<OpProgrammeeDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<LigneCommande> lcs = ligneCommandeHome.findParCde(commandeId);
			for (LigneCommande ligneCommande : lcs) {
				opProgrammeeDTOs.addAll(findOpProgrammeByLigneCommande(ligneCommande.getId()));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findOpProgrammeeByCommande", "Probleme lors de la recherche de la liste d'op programme pour la commande " + commandeId, fe);
			throw new EJBException(fe);
		}
		return opProgrammeeDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateOpProgrammeeIntervention(com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO)
	 */
	public void updateOpProgrammeeIntervention(OpProgrammeeDTO opProgrammeeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateOpProgrammeeIntervention", "Mise � jour de l'op programmee " + opProgrammeeDTO.getId());
		try {
			OpProgrammee opProgrammee = getOpProgrammeeEntity(opProgrammeeDTO.getId());
			opProgrammee.setLinkFaiteLorsIntervention(getInterventionEntity(opProgrammeeDTO.getIntervention().getId()));
			long timestamp = opProgrammee.getTimestamp() + 1;
			opProgrammee.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateOpProgrammeeIntervention", "Probl�me de mise � jour de l'op programmee " + opProgrammeeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateOpProgrammeeIntervention(com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO)
	 */
	public void updateOpProgrammeeTypeOPProgrammee(OpProgrammeeDTO opProgrammeeDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateOpProgrammeeTypeOPProgrammee", "Mise � jour de l'op programmee " + opProgrammeeDTO.getId());
		try {
			OpProgrammee opProgrammee = getOpProgrammeeEntity(opProgrammeeDTO.getId());
			opProgrammee.setEstTypeOpProgrammee(opProgrammeeDTO.getTypeOpProgrammee().getId());
			long timestamp = opProgrammee.getTimestamp() + 1;
			opProgrammee.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateOpProgrammeeTypeOPProgrammee", "Probl�me de mise � jour de l'op programmee " + opProgrammeeDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * Gets the op programmee entity.
	 * 
	 * @param id the id
	 * 
	 * @return the op programmee entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private OpProgrammee getOpProgrammeeEntity(String id) throws FinderException {
		return opProgrammeeHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// INTERVENTION et DYNAMIC_INTERVENTION
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getIntervention(java.lang.String)
	 */
	public InterventionDTO getIntervention(String interventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getIntervention", "Recherche de l'intervention " + interventionId);
		try {
			Intervention intervention = getInterventionEntity(interventionId);
			return new InterventionDTO(intervention);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getIntervention", "Probleme lors de la recup�ration dde l'intervention " + interventionId, fe);
			return null;
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findInterventionByCommande(java.lang.String)
	 */
	@Deprecated
	public InterventionDTO findInterventionByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterventionByCommande", "Recherche des interventions pour la commande " + commandeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<Intervention> is = interventionHome.findForListOfInterventionParCommandeIdOrderByDebutPlage(commandeId);
			Iterator<Intervention> it = is.iterator();
			InterventionDTO interventionDTO = null;
			if (it.hasNext()) {
				Intervention intervention = it.next();
				interventionDTO = new InterventionDTO(intervention);
			}
			return interventionDTO;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterventionByCommande", "Probleme lors de la recherche d'intervention la plus recente pour la commande " + commandeId, fe);
			return null;
		}

	}

	/**
	 * Gets the intervention entity.
	 * 
	 * @param id the id
	 * 
	 * @return the intervention entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Intervention getInterventionEntity(String id) throws FinderException {
		return interventionHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createIntervention(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public void createIntervention(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createIntervention", "Cr�ation de l'intervention " + interventionDTO);
		HashMap<String, Object> values = new HashMap<String, Object>();
		// Champs
		values.put(Intervention.FIELD_DATE_ENVOI_O_T, interventionDTO.getDatabaseDateDateEnvoiOt());
		values.put(Intervention.FIELD_DATE_PRISE, interventionDTO.getDatabaseDateDatePrise());
		values.put(Intervention.FIELD_DEBUT_PLAGE, interventionDTO.getDatabaseDateDebutPlage());
		values.put(Intervention.FIELD_DUREE, interventionDTO.getDuree());
		if (interventionDTO.getEtatIntervention() != null) {
			values.put(Intervention.FIELD_EST_DANS_ETAT_INTERVENTION, interventionDTO.getEtatIntervention().getId());
		} else {
			values.put(Intervention.FIELD_EST_DANS_ETAT_INTERVENTION, EtatInterventionConstantes.REPORT);
		}
		if (interventionDTO.getResponsabilite() != null) {
			values.put(Intervention.FIELD_EST_RESPONSABILITE, interventionDTO.getResponsabilite().getId());
		} else {
			values.put(Intervention.FIELD_EST_RESPONSABILITE, null);
		}
		values.put(Intervention.FIELD_FIN_PLAGE, interventionDTO.getDatabaseDateFinPlage());
		values.put(Intervention.FIELD_MESCONTR, interventionDTO.getMescontr());
		values.put(Intervention.FIELD_OBSERVATION, interventionDTO.getObservation());
		values.put(Intervention.FIELD_REF_ERDV, interventionDTO.getRefErdv());
		values.put(Intervention.FIELD_REF_EXTERNE, interventionDTO.getRefExterne());
		values.put(Intervention.FIELD_REFERENCE, interventionDTO.getReference());
		values.put(Intervention.FIELD_TIMESTAMP, DateUtils.getDatabaseDate());
		// Liens
		InstanceOgDTO instanceOgDTO = interventionDTO.getInstanceOg();
		if (instanceOgDTO != null && StringUtils.isNotBlank(instanceOgDTO.getId())) {
			values.put(Intervention.SLINK_CONCERNE_INSTANCE_O_G, instanceOgDTO.getId());
		}
		RapportInterventionDTO rapportInterventionDTO = interventionDTO.getRapportIntervention();
		if (rapportInterventionDTO != null && StringUtils.isNotBlank(rapportInterventionDTO.getId())) {
			values.put(Intervention.SLINK_POSSEDE_RAPPORT_INTERVENTION, rapportInterventionDTO.getId());
		}
		InterventionDTO suitInterventionDTO = interventionDTO.getSuitIntervention();
		if (suitInterventionDTO != null && StringUtils.isNotBlank(suitInterventionDTO.getId())) {
			values.put(Intervention.SLINK_SUIT_INTERVENTION, suitInterventionDTO.getId());
		}
		try {
			Intervention intervention = interventionHome.create(interventionDTO.getId(), values);
			intervention.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createIntervention", "Erreur cr�ation intervention " + interventionDTO.getId(), ce);
			throw new EJBException(ce);
		}
		Map<String, String> dynamics = interventionDTO.getDynamicInterventions();
		for (Entry<String, String> dynamicInter : dynamics.entrySet()) {
			createDynamicIntervention(interventionDTO.getId(), dynamicInter.getKey(), dynamicInter.getValue());
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateInterventionEtatEtDateEnvoiOt(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public void updateInterventionEtatEtDateEnvoiOt(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateInterventionEtatEtDateEnvoiOt", "Mise � jour de l'intervention " + interventionDTO.getId());
		try {
			Intervention intervention = getInterventionEntity(interventionDTO.getId());
			intervention.setEstDansEtatIntervention(interventionDTO.getEtatIntervention().getId());
			intervention.setDateEnvoiOT(interventionDTO.getDatabaseDateDateEnvoiOt());
			long timestamp = intervention.getTimestamp() + 1;
			intervention.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateInterventionEtatEtDateEnvoiOt", "Probl�me de mise � jour de l'intervention " + interventionDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateInterventionEtatEtRapport(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public void updateInterventionEtatEtRapport(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateInterventionEtatEtRapport", "Mise � jour de l'intervention " + interventionDTO.getId());
		try {
			Intervention intervention = getInterventionEntity(interventionDTO.getId());
			intervention.setEstDansEtatIntervention(interventionDTO.getEtatIntervention().getId());
			if (interventionDTO.getRapportIntervention() != null) {
				intervention.setLinkPossedeRapportIntervention(getRapportInterventionEntity(interventionDTO.getRapportIntervention().getId()));
			}
			long timestamp = intervention.getTimestamp() + 1;
			intervention.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateInterventionEtatEtRapport", "Probl�me de mise � jour de l'intervention " + interventionDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateInterventionEtat(InterventionDTO)
	 */
	public void updateInterventionEtat(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateInterventionEtat", "Mise � jour de l'intervention " + interventionDTO.getId());
		try {
			Intervention intervention = getInterventionEntity(interventionDTO.getId());
			intervention.setEstDansEtatIntervention(interventionDTO.getEtatIntervention().getId());
			long timestamp = intervention.getTimestamp() + 1;
			intervention.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateInterventionEtatEtRapport", "Probl�me de mise � jour de l'intervention " + interventionDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateIntervention(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public void updateIntervention(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateIntervention", "Mise � jour de l'intervention " + interventionDTO.getId());
		try {
			Intervention intervention = getInterventionEntity(interventionDTO.getId());
			intervention.setDateEnvoiOT(interventionDTO.getDatabaseDateDateEnvoiOt());
			intervention.setDatePrise(interventionDTO.getDatabaseDateDatePrise());
			intervention.setDebutPlage(interventionDTO.getDatabaseDateDebutPlage());
			intervention.setDuree(interventionDTO.getDuree());
			intervention.setFinPlage(interventionDTO.getDatabaseDateFinPlage());
			intervention.setEstDansEtatIntervention(interventionDTO.getEtatIntervention().getId());
			intervention.setRefExterne(interventionDTO.getRefExterne());
			intervention.setReference(interventionDTO.getReference());
			intervention.setObservation(interventionDTO.getObservation());
			ResponsabiliteDTO responsabilite = interventionDTO.getResponsabilite();
			if (responsabilite != null) {
				intervention.setEstResponsabilite(responsabilite.getId());
			}
			InterventionDTO suitIntervention = interventionDTO.getSuitIntervention();
			if (suitIntervention != null) {
				intervention.setLinkSuitIntervention(getInterventionEntity(suitIntervention.getId()));
			}
			updateDynamicIntervention(interventionDTO);
			long timestamp = intervention.getTimestamp() + 1;
			intervention.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateIntervention", "Probl�me de mise � jour de l'intervention " + interventionDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findDynamicsIntervention(java.lang.String)
	 */
	public Map<String, String> findDynamicsIntervention(String interventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findDynamicsIntervention", "Recherche des champs dynamiques pour l'intervention " + interventionId);
		Map<String, String> dynamics = new HashMap<String, String>();
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicIntervention> dynamicsAps = dynamicInterventionHome.findByPourIntervention(interventionId);
			for (DynamicIntervention dynamic : dynamicsAps) {
				dynamics.put(dynamic.getCle(), dynamic.getValeur());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findDynamicsIntervention", "Probl�me lors de la recherche des champs dynamiques pour l'intervention " + interventionId, fe);
			throw new EJBException(fe);
		}
		return dynamics;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateDynamicIntervention(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public void updateDynamicIntervention(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateDynamicIntervention", "Mise � jour des champs dynamiques de l'intervention " + interventionDTO.getId());
		Map<String, String> dynamics = interventionDTO.getDynamicInterventions();
		if (!dynamics.isEmpty()) {
			String id = interventionDTO.getId();
			try {
				// recup�ration de tous les champs dynamiques pour cette commande
				@SuppressWarnings("unchecked")
				Collection<DynamicIntervention> ds = dynamicInterventionHome.findByPourIntervention(id);
				String cle;
				String valeur;
				String cleAps;
				String valeurAps;
				for (Entry<String, String> dynamicInterventionEntry : dynamics.entrySet()) {
					boolean isUpdated = false;
					cle = dynamicInterventionEntry.getKey();
					valeur = dynamicInterventionEntry.getValue();
					Iterator<DynamicIntervention> it = ds.iterator();
					while (it.hasNext()) {
						DynamicIntervention dynamic = it.next();
						cleAps = dynamic.getCle();
						valeurAps = dynamic.getValeur();
						if (StringUtils.equals(cleAps, cle)) {
							if (StringUtils.isNotEmpty(valeur)) {
								if (!StringUtils.equals(valeurAps, valeur)) {
									// maj du dynamic existant
									dynamic.setValeur(valeur);
									long timestamp = dynamic.getTimestamp() + 1;
									dynamic.setTimestamp(timestamp);
								}
							} else {
								// on supprime la valeur en base si elle est nulle
								try {
									dynamic.remove();
									it.remove();
								} catch (EJBException e) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicIntervention", "Probl�me lors de la suppression du dynamique intervention", e);
									throw new EJBException(e);
								} catch (RemoveException re) {
									ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateDynamicIntervention", "Probl�me lors de la suppression du dynamique intervention", re);
									throw new EJBException(re);
								}
							}
							isUpdated = true;
							break;
						}
					}
					// Si on n'a pas mis � jour la table dynamique alors on insere un nouvel enregistrement
					if (!isUpdated) {
						if (StringUtils.isNotEmpty(valeur)) {
							createDynamicIntervention(id, cle, valeur);
						}
					}
				}
			} catch (FinderException fe) {
				// Cr�ation des champs dynamiques
				String cle;
				String valeur;
				for (Entry<String, String> dynamicInterventionEntry : dynamics.entrySet()) {
					cle = dynamicInterventionEntry.getKey();
					valeur = dynamicInterventionEntry.getValue();
					if (StringUtils.isNotEmpty(valeur)) {
						createDynamicIntervention(id, cle, valeur);
					}
				}
			}
		}
	}

	/**
	 * Creates the dynamic intervention.
	 * 
	 * @param id the id
	 * @param cle the cle
	 * @param valeur the valeur
	 */
	private void createDynamicIntervention(String id, String cle, String valeur) {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(DynamicIntervention.FIELD_CLE, cle);
		values.put(DynamicIntervention.FIELD_VALEUR, valeur);
		values.put(DynamicIntervention.SLINK_POUR_INTERVENTION, id);
		String dynamicId = serviceManager.getGeneratorManager().generateKey();
		try {
			DynamicIntervention dynamic = dynamicInterventionHome.create(dynamicId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			dynamic.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createDynamicIntervention", "Erreur cr�ation dynamique intervention pour la intervention " + id, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Delete intervention.
	 * 
	 * @param interventionDTO the intervention dto
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteIntervention(com.soliste.bolbec.livraison.service.model.InterventionDTO)
	 */
	public void deleteIntervention(InterventionDTO interventionDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteIntervention", "Suppression de l'intervention " + interventionDTO.getId());
		try {
			Intervention intervention = getInterventionEntity(interventionDTO.getId());
			deleteDynamicInterventions(interventionDTO);
			intervention.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateIntervention", "Probl�me de mise � jour de l'intervention " + interventionDTO.getId(), fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteIntervention", "Probleme suppresion de l'intervention " + interventionDTO.getId(), ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteIntervention", "Probleme suppresion de l'intervention " + interventionDTO.getId(), re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findInterventionByProcessus(java.lang.String)
	 */
	public List<InterventionDTO> findInterventionByProcessus(String idProcessus) {
		// TODO OLD: SCA revoir l'algo de cette m�thode (faire des finders plus appropri�s)
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterventionByProcessus", "Recherche des interventions pour le processus " + idProcessus);
		List<InterventionDTO> resultatFinder = new ArrayList<InterventionDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<ProcessusLC> processusLcs = processusLCHome.findByEstLivreParProcessus(idProcessus);
			for (ProcessusLC processusLc : processusLcs) {
				LigneCommande ldc = processusLc.getLinkLivreLigneCommande();
				@SuppressWarnings("unchecked")
				Collection<LienOpProgLdC> lienOpProgLdCs = ldc.getLinkRequiereOpProgrammee();
				for (LienOpProgLdC lienOpProgLdC : lienOpProgLdCs) {
					resultatFinder.add(new InterventionDTO(lienOpProgLdC.getLinkRequiereOpProgrammee().getLinkFaiteLorsIntervention()));
				}
			}
			return resultatFinder;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterventionByProcessus", "Probleme lors de la recherche d'intervention lpour le processus " + idProcessus, fe);
			return null;
		}
	}

	/**
	 * Delete dynamic interventions.
	 * 
	 * @param interventionDTO the intervention dto
	 */
	private void deleteDynamicInterventions(InterventionDTO interventionDTO) {
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicIntervention> dynamicInterventions = dynamicInterventionHome.findByPourIntervention(interventionDTO.getId());
			for (DynamicIntervention dynamicIntervention : dynamicInterventions) {
				try {
					dynamicIntervention.remove();
				} catch (EJBException ee) {
					ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteDynamicInterventions", "Probleme suppresion de la dynamic intervention " + dynamicIntervention.getId(), ee);
					throw new EJBException(ee);
				} catch (RemoveException re) {
					ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteDynamicInterventions", "Probleme suppresion de la dynamic intervention " + dynamicIntervention.getId(), re);
					throw new EJBException(re);
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteDynamicInterventions", "Probl�me de suppression de la dynamic intervention " + interventionDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findInterventionByOpProgrammee(java.lang.String)
	 */
	public InterventionDTO findInterventionByOpProgrammee(String idOpProgrammee) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterventionByOpProgrammee", "Recherche de l'intervention pour l'op programmee " + idOpProgrammee);
		InterventionDTO resultatFinder = null;
		try {
			OpProgrammee opProgrammee = getOpProgrammeeEntity(idOpProgrammee);
			resultatFinder = new InterventionDTO(opProgrammee.getLinkFaiteLorsIntervention());
			return resultatFinder;
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterventionByOpProgrammee", "Probleme lors de la recherche de l'intervention pour l'op programmee " + idOpProgrammee, fe);
		}
		return null;
	}

	/**
	 * 
	 * @param idLdc
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public InterventionDTO findInterventionPlusRecenteByLdc(String idLdc) {
		String method = "findInterventionPlusRecenteByLdc";
		Collection<Intervention> intervList = null;

		try {
			intervList = interventionHome.findParLdc(idLdc);
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		Intervention interv = null;
		InterventionDTO intervDTO = null;
		if (intervList != null) {
			interv = CollectionUtils.getFirstOrNull(intervList);
			if (interv != null) {
				intervDTO = new InterventionDTO(interv);
			}
		}
		if (intervDTO == null) {
			serviceManager.getLoggerManager().warning(CLASSNAME, method, "Intervention plus r�cente non trouv�e � partir de l'id ligneDeCommande : " + idLdc);
		}

		return intervDTO;

	}

	// --------------------------------------------------------------
	// RAPPORT_INTERVENTION et DYNAMIC_RAPPORT_INTERVENTION
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createRapportIntervention(com.soliste.bolbec.livraison.service.model.RapportInterventionDTO, java.lang.String)
	 */
	public void createRapportIntervention(RapportInterventionDTO rapportInterventionDTO, String interventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createRapportIntervention", "Cr�ation du rapport intervention " + rapportInterventionDTO);
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(RapportIntervention.FIELD_CONFORMITE_O_T, rapportInterventionDTO.getConformiteOt());
			values.put(RapportIntervention.FIELD_DATE_DEBUT, rapportInterventionDTO.getDatabaseDateDateDebut());
			values.put(RapportIntervention.FIELD_DATE_FIN, rapportInterventionDTO.getDatabaseDateDateFin());
			values.put(RapportIntervention.FIELD_DATE_RECEPTION_C_R, rapportInterventionDTO.getDatabaseDateDateReceptionCr());
			values.put(RapportIntervention.FIELD_STATUT, rapportInterventionDTO.getStatut());
			values.put(RapportIntervention.FIELD_TIMESTAMP, DateUtils.getDatabaseDate());
			values.put(RapportIntervention.MLINK_CONCERNE_INTERVENTION, interventionId);
			RapportIntervention rapportIntervention = rapportInterventionHome.create(rapportInterventionDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			rapportIntervention.setLinks(values);
			Map<String, String> dRapportInterventions = rapportInterventionDTO.getDynamicRapportInterventions();
			for (Entry<String, String> dynamicRI : dRapportInterventions.entrySet()) {
				createDynamicRapportIntervention(rapportInterventionDTO.getId(), dynamicRI.getKey(), dynamicRI.getValue());
			}
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createRapportIntervention", "Erreur cr�ation du rapport d'intervention : " + rapportInterventionDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findDynamicsRapportIntervention(java.lang.String)
	 */
	public Map<String, String> findDynamicsRapportIntervention(String rapportInterventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findDynamicsRapportIntervention", "Recherche des champs dynamiques pour le rapport d'intervention " + rapportInterventionId);
		Map<String, String> dynamics = new HashMap<String, String>();
		try {
			@SuppressWarnings("unchecked")
			Collection<DynamicRapportIntervention> dynamicsAps = dynamicRapportInterventionHome.findByPourRapportIntervention(rapportInterventionId);
			for (DynamicRapportIntervention dynamic : dynamicsAps) {
				dynamics.put(dynamic.getCle(), dynamic.getValeur());
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findDynamicsRapportIntervention", "Probl�me lors de la recherche des champs dynamiques pour le rapport d'intervention " + rapportInterventionId, fe);
			throw new EJBException(fe);
		}
		return dynamics;
	}

	/**
	 * Creates the dynamic rapportIntervention.
	 * 
	 * @param rapportInterventionId the rapport intervention id
	 * @param cle the cle
	 * @param valeur the valeur
	 */
	private void createDynamicRapportIntervention(String rapportInterventionId, String cle, String valeur) {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(DynamicRapportIntervention.FIELD_CLE, cle);
		values.put(DynamicRapportIntervention.FIELD_VALEUR, valeur);
		values.put(DynamicRapportIntervention.SLINK_POUR_RAPPORT_INTERVENTION, rapportInterventionId);
		String dynamicRapportInterventionId = serviceManager.getGeneratorManager().generateKey();
		try {
			DynamicRapportIntervention dynamicRapportIntervention = dynamicRapportInterventionHome.create(dynamicRapportInterventionId, values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			dynamicRapportIntervention.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createDynamicRapportIntervention", "Erreur cr�ation dynamique rapport intervention pour le rapport intervention " + rapportInterventionId, ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * Gets the RapportIntervention entity.
	 * 
	 * @param id the id
	 * 
	 * @return the rapport intervention entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private RapportIntervention getRapportInterventionEntity(String id) throws FinderException {
		return rapportInterventionHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// ACCES_CLIENT
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createLienOpProgLdc(com.soliste.bolbec.livraison.service.model.LienOpProgLdcDTO)
	 */
	public void createAccesClient(AccesClientDTO accesClientDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createAccesClient", "Cr�ation de l'acc�s client (id = " + accesClientDTO.getId());
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(AccesClient.FIELD_ND, accesClientDTO.getNd());
			values.put(AccesClient.SLINK_CONCERNE_COMMANDE, accesClientDTO.getCommande().getId());
			AccesClient accesClient = accesClientHome.create(accesClientDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			accesClient.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createAccesClient", "Erreur cr�ation de l'acc�s client: id " + accesClientDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findAccesClientByCommande(java.lang.String)
	 */
	public List<AccesClientDTO> findAccesClientByCommande(String commandeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findAccesClientByCommande", "Recherche des acces clients pour la commande " + commandeId);
		List<AccesClientDTO> accesClientDTOs = new ArrayList<AccesClientDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<AccesClient> accesClientss = accesClientHome.findByConcerneCommande(commandeId);
			for (AccesClient accesClient : accesClientss) {
				accesClientDTOs.add(new AccesClientDTO(accesClient));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findAccesClientByCommande", "Probleme lors de la recherche des acces clients pour la commande " + commandeId, fe);
			throw new EJBException(fe);
		}
		return accesClientDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteAccesClient(java.lang.String)
	 */
	public void deleteAccesClient(String accesClientId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteAccesClient", "Suppression de l'accesClient " + accesClientId);
		try {
			AccesClient accesClient = getAccesClientEntity(accesClientId);
			accesClient.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteAccesClient", "Probl�me de mise � jour de l'accesClient " + accesClientId, fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteAccesClient", "Probleme suppresion de l'accesClient " + accesClientId, ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteAccesClient", "Probleme suppresion de l'accesClient " + accesClientId, re);
			throw new EJBException(re);
		}
	}

	/**
	 * Gets the AccesClient entity.
	 * 
	 * @param id the id
	 * 
	 * @return the AccesClient entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private AccesClient getAccesClientEntity(String id) throws FinderException {
		return accesClientHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// LienOpProgLdc
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createLienOpProgLdc(com.soliste.bolbec.livraison.service.model.LienOpProgLdcDTO)
	 */
	public LienOpProgLdcDTO createLienOpProgLdc(LienOpProgLdcDTO lienOpProgLdcDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createLienOpProgLdc",
				"Cr�ation de la relation Op programmee (id = " + lienOpProgLdcDTO.getOpProgrammee().getId() + ")/Ligne de commande (id = " + lienOpProgLdcDTO.getLigneCommande().getId());
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(LienOpProgLdC.SLINK_APPARTIENT_LIGNE_COMMANDE, lienOpProgLdcDTO.getLigneCommande().getId());
			values.put(LienOpProgLdC.SLINK_REQUIERE_OP_PROGRAMMEE, lienOpProgLdcDTO.getOpProgrammee().getId());
			LienOpProgLdC lienOpProgLdC = lienOpProgLdCHome.create(lienOpProgLdcDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			lienOpProgLdC.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createLienOpProgLdc", "Erreur cr�ation de la relation Op programmee/Ligne de commande: id " + lienOpProgLdcDTO.getId(), ce);
			throw new EJBException(ce);
		}
		return lienOpProgLdcDTO;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteLienOpProgLdcByOpProgrammee(java.lang.String)
	 */
	public void deleteLienOpProgLdcByOpProgrammee(String opProgrammeeId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteLienOpProgLdcByOpProgrammee", "Suppression des lien OpProg/Ldc pour l'op programme " + opProgrammeeId);
		try {
			@SuppressWarnings("unchecked")
			Collection<LienOpProgLdC> lienOpProgLdCs = lienOpProgLdCHome.findByRequiereOpProgrammee(opProgrammeeId);
			for (LienOpProgLdC lienOpProgLdC : lienOpProgLdCs) {
				lienOpProgLdC.remove();
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLienOpProgLdcByOpProgrammee", "Probl�me suppresion du lien OpProg/Ldc pour l'op programme " + opProgrammeeId, fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLienOpProgLdcByOpProgrammee", "Probleme suppresion du lien OpProg/Ldc pour l'op programme " + opProgrammeeId, ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteLienOpProgLdcByOpProgrammee", "Probleme suppresion du lien OpProg/Ldc pour l'op programme " + opProgrammeeId, re);
			throw new EJBException(re);
		}
	}

	// --------------------------------------------------------------
	// Adresse
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createAdresse(AdresseDTO)
	 */
	public void createAdresse(AdresseDTO adresseDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createAdresse", "Cr�ation d'une adresse (id = " + adresseDTO.getId() + ")");
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(Adresse.FIELD_BATIMENT, adresseDTO.getBatiment());
			values.put(Adresse.FIELD_CODE_INSEE, adresseDTO.getCodeInsee());
			values.put(Adresse.FIELD_CODE_POSTAL, adresseDTO.getCodePostal());
			values.put(Adresse.FIELD_CODE_RIVOLI, adresseDTO.getCodeRivoli());
			values.put(Adresse.FIELD_CPLT_NUM_VOIE, adresseDTO.getCpltnumVoie());
			values.put(Adresse.FIELD_ENSEMBLE, adresseDTO.getEnsemble());
			values.put(Adresse.FIELD_ESCALIER, adresseDTO.getEscalier());
			values.put(Adresse.FIELD_ETAGE, adresseDTO.getEtage());
			values.put(Adresse.FIELD_ID_EXTERNE, adresseDTO.getIdExterne());
			values.put(Adresse.FIELD_LIBELLE_VOIE, adresseDTO.getLibelleVoie());
			values.put(Adresse.FIELD_LIGNE1, adresseDTO.getLigne1());
			values.put(Adresse.FIELD_LIGNE2, adresseDTO.getLigne2());
			values.put(Adresse.FIELD_LOGO, adresseDTO.getLogo());
			values.put(Adresse.FIELD_NUMERO_VOIE, adresseDTO.getNumeroVoie());
			values.put(Adresse.FIELD_PAYS, adresseDTO.getPays());
			values.put(Adresse.FIELD_PORTE, adresseDTO.getPorte());
			values.put(Adresse.FIELD_TYPE_VOIE, adresseDTO.getTypeVoie());
			values.put(Adresse.FIELD_VILLE, adresseDTO.getVille());
			Adresse adresse = adresseHome.create(adresseDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			adresse.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createAdresse", "Erreur cr�ation d'une adresse : id " + adresseDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateAdresse(AdresseDTO)
	 */
	public void updateAdresse(AdresseDTO adresseDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateAdresse", "Mise � jour d'une adresse (id = " + adresseDTO.getId() + ")");
		try {
			Adresse adresse = getAdresseEntity(adresseDTO.getId());
			adresse.setBatiment(adresseDTO.getBatiment());
			adresse.setCodeInsee(adresseDTO.getCodeInsee());
			adresse.setCodePostal(adresseDTO.getCodePostal());
			adresse.setCodeRivoli(adresseDTO.getCodeRivoli());
			adresse.setCpltNumVoie(adresseDTO.getCpltnumVoie());
			adresse.setEnsemble(adresseDTO.getEnsemble());
			adresse.setEscalier(adresseDTO.getEscalier());
			adresse.setEtage(adresseDTO.getEtage());
			adresse.setIdExterne(adresseDTO.getIdExterne());
			adresse.setLibelleVoie(adresseDTO.getLibelleVoie());
			adresse.setLigne1(adresseDTO.getLigne1());
			adresse.setLigne2(adresseDTO.getLigne2());
			adresse.setLogo(adresseDTO.getLogo());
			adresse.setNumeroVoie(adresseDTO.getNumeroVoie());
			adresse.setPays(adresseDTO.getPays());
			adresse.setPorte(adresseDTO.getPorte());
			adresse.setTypeVoie(adresseDTO.getTypeVoie());
			adresse.setVille(adresseDTO.getVille());
			long timestamp = adresse.getTimestamp() + 1;
			adresse.setTimestamp(timestamp);
		} catch (FinderException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateAdresse", "Probl�me de mise � jour d'une adresse : id " + adresseDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateBlocNote(BlocNoteDTO)
	 */
	public void updateBlocNote(BlocNoteDTO blocNoteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateBlocNote", "Mise � jour d'un blocNote (id = " + blocNoteDTO.getId() + ")");
		try {
			BlocNote blocNote = getBlocNoteEntity(blocNoteDTO.getId());
			blocNote.setDateCreation(blocNoteDTO.getDatabaseDateDateCreation());
			blocNote.setEcritParAgent(blocNoteDTO.getEcritParAgent().getId());
			blocNote.setInfo(blocNoteDTO.getInfo());
			blocNote.setLinkConcerneCommande(getCommandeEntity(blocNoteDTO.getCommandeId()));
			long timestamp = blocNote.getTimestamp() + 1;
			blocNote.setTimestamp(timestamp);
		} catch (FinderException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateBlocNote", "Probl�me de mise � jour d'un updateBlocNote : id " + blocNoteDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteAdresse(java.lang.String)
	 */
	public void deleteAdresse(String adresseId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteAdresse", "Suppression de l'adresse " + adresseId);
		try {
			Adresse adresse = getAdresseEntity(adresseId);
			adresse.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteAdresse", "Probl�me suppresion de l'adresse " + adresseId, fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteAdresse", "Probleme suppresion de l'adresse " + adresseId, ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteAdresse", "Probleme suppresion de l'adresse " + adresseId, re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getAdresse(java.lang.String)
	 */
	public AdresseDTO getAdresse(String adresseId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getAdresse", "Recherche de l'adresse " + adresseId);
		try {
			Adresse adresse = getAdresseEntity(adresseId);
			return new AdresseDTO(adresse);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getAdresse", "Pas d'adresse " + adresseId, fe);
			return null;
		}
	}

	/**
	 * Gets the Adresse entity.
	 * 
	 * @param id the id
	 * 
	 * @return the Adresse entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Adresse getAdresseEntity(String id) throws FinderException {
		return adresseHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// Client
	// --------------------------------------------------------------
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createClient(com.soliste.bolbec.livraison.service.model.ClientDTO)
	 */
	public void createClient(ClientDTO clientDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createClient", "Cr�ation d'un client (id = " + clientDTO.getId() + ")");
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(Client.FIELD_APPARTIENT_CATEGORIE_CLIENT, clientDTO.getCategorieClient() != null ? clientDTO.getCategorieClient().getId() : null);
			values.put(Client.FIELD_DENOMINATION, clientDTO.getDenomination());
			values.put(Client.FIELD_ID_EXTERNE, clientDTO.getIdExterne());
			values.put(Client.FIELD_NIC, clientDTO.getNic());
			values.put(Client.FIELD_PRENOM, clientDTO.getPrenom());
			values.put(Client.FIELD_SIREN, clientDTO.getSiren());
			values.put(Client.FIELD_TEL_CONTACT, clientDTO.getTelContact());
			values.put(Client.FIELD_TITRE, clientDTO.getTitre());
			values.put(Client.FIELD_TYPE_CLIENT, clientDTO.getTypeClient());
			AdresseDTO adresse = clientDTO.getAdresse();
			if (adresse != null) {
				createAdresse(adresse);
				values.put(Client.SLINK_A_ADRESSE, adresse.getId());
			}
			Client client = clientHome.create(clientDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			client.setLinks(values);
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createClient", "Erreur cr�ation d'un client : id " + clientDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#updateClient(com.soliste.bolbec.livraison.service.model.ClientDTO)
	 */
	public void updateClient(ClientDTO clientDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "updateClient", "Mise � jour du Client " + clientDTO.getId());
		try {
			Client client = getClientEntity(clientDTO.getId());
			client.setAppartientCategorieClient(clientDTO.getCategorieClient() != null ? clientDTO.getCategorieClient().getId() : null);
			client.setDenomination(clientDTO.getDenomination());
			client.setIdExterne(clientDTO.getIdExterne());
			client.setNic(clientDTO.getNic());
			client.setPrenom(clientDTO.getPrenom());
			client.setSiren(clientDTO.getSiren());
			client.setTelContact(clientDTO.getTelContact());
			client.setTitre(clientDTO.getTitre());
			client.setTypeClient(clientDTO.getTypeClient());
			AdresseDTO adresseDTO = clientDTO.getAdresse();
			if (adresseDTO != null) {
				Adresse adresse;
				try {
					adresse = getAdresseEntity(adresseDTO.getId());
					updateAdresse(adresseDTO);
				} catch (FinderException fe) {
					// Si on ne trouve pas l'adresse c'est qu'on veut la cr�er
					createAdresse(adresseDTO);
					adresse = getAdresseEntity(adresseDTO.getId());
				}
				client.setLinkAAdresse(adresse);
			} else {
				client.setLinkAAdresse(null);
			}
			long timestamp = client.getTimestamp() + 1;
			client.setTimestamp(timestamp);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "updateClient", "Probl�me de mise � jour du Client : id = " + clientDTO.getId(), fe);
			throw new EJBException(fe);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#deleteClient(java.lang.String)
	 */
	public void deleteClient(String clientId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "deleteClient", "Suppression du client " + clientId);
		try {
			Client client = getClientEntity(clientId);
			client.remove();
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteClient", "Probl�me suppresion du client " + clientId, fe);
			throw new EJBException(fe);
		} catch (EJBException ee) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteClient", "Probleme suppresion du client " + clientId, ee);
			throw new EJBException(ee);
		} catch (RemoveException re) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "deleteClient", "Probleme suppresion du client " + clientId, re);
			throw new EJBException(re);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getClient(java.lang.String)
	 */
	public ClientDTO getClient(String clientId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "getClient", "Recherche du client " + clientId);
		try {
			Client epCOmmercial = getClientEntity(clientId);
			return new ClientDTO(epCOmmercial);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "getClient", "Pas de client " + clientId, fe);
			return null;
		}
	}

	/**
	 * Gets the Client entity.
	 * 
	 * @param id the id
	 * 
	 * @return the Client entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private Client getClientEntity(String id) throws FinderException {
		return clientHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	// --------------------------------------------------------------
	// BlocNote
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#getBlocNote(java.lang.String)
	 */
	public BlocNoteDTO getBlocNote(String idBlocNote) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "blocNote", "R�cup�ration du blocNote d'id : " + idBlocNote);
		BlocNote blocNote;
		try {
			blocNote = getBlocNoteEntity(idBlocNote);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "blocNote", "Probleme lors de la r�cup�ration du blocNote d'id : " + idBlocNote, fe);
			throw new EJBException(fe);
		}
		return new BlocNoteDTO(blocNote);
	}

	/**
	 * Gets the BlocNote entity.
	 * 
	 * @param id the id
	 * 
	 * @return the BlocNote entity
	 * 
	 * @throws FinderException the finder exception
	 */
	private BlocNote getBlocNoteEntity(String id) throws FinderException {
		return blocNoteHome.findByPrimaryKey(new EntityBeanPK(id));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findBlocNoteById(java.lang.String)
	 */
	@Override
	public BlocNoteDTO findBlocNoteById(String idBlocNote) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "blocNote", "R�cup�ration du blocNote d'id : " + idBlocNote);
		BlocNote blocNote;
		try {
			blocNote = getBlocNoteEntity(idBlocNote);
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "blocNote", "Probleme lors de la r�cup�ration du blocNote d'id : " + idBlocNote, fe);
			return null;
		}
		return new BlocNoteDTO(blocNote);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findBlocNoteByCommande(java.lang.String)
	 */
	public List<BlocNoteDTO> findBlocNoteByCommande(String idCommande) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "blocNote", "Recherche des bloc notes pour la commande " + idCommande);
		List<BlocNoteDTO> blocNoteDTOs = new ArrayList<BlocNoteDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<BlocNote> blocNotes = blocNoteHome.findByConcerneCommande(idCommande);
			for (BlocNote blocNote : blocNotes) {
				blocNoteDTOs.add(new BlocNoteDTO(blocNote));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "blocNote", "Probleme lors de la recherche des acces clients pour la commande " + idCommande, fe);
			throw new EJBException(fe);
		}
		return blocNoteDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createBlocNote(com.soliste.bolbec.livraison.service.model.BlocNoteDTO)
	 */
	public BlocNoteDTO createBlocNote(BlocNoteDTO blocNoteDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createBlocNote", "Cr�ation d'un BlocNote (id = " + blocNoteDTO.getId() + ")");
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(BlocNote.FIELD_DATE_CREATION, blocNoteDTO.getDatabaseDateDateCreation());
			values.put(BlocNote.FIELD_ECRIT_PAR_AGENT, blocNoteDTO.getEcritParAgent() == null ? null : blocNoteDTO.getEcritParAgent().getId());
			values.put(BlocNote.FIELD_INFO, blocNoteDTO.getInfo());
			values.put(BlocNote.SLINK_CONCERNE_COMMANDE, blocNoteDTO.getCommandeId());
			BlocNote blocNote = blocNoteHome.create(blocNoteDTO.getId(), values);
			// Pour que les link soient enregistr�s en base il faut appeller la m�thode setLinks
			blocNote.setLinks(values);
			return blocNoteDTO;
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createBlocNote", "Erreur cr�ation d'un BlocNote : id " + blocNoteDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	// --------------------------------------------------------------
	// PrestationAFacturer
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findPrestationAFacturerByLigneCommande(java.lang.String)
	 */
	public List<PrestationAFacturerDTO> findPrestationAFacturerByLigneCommande(String idLigneCommande) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findPrestationAFacturerByLigneCommande", "Recherche des prestations � facturer pour la ligne de commande " + idLigneCommande);
		List<PrestationAFacturerDTO> prestationAFacturerDTOs = new ArrayList<PrestationAFacturerDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<PrestationAFacturer> prestationAFacturers = prestationAFacturerHome.findParIdLigneCde(idLigneCommande);
			for (PrestationAFacturer prestationAFacturer : prestationAFacturers) {
				prestationAFacturerDTOs.add(new PrestationAFacturerDTO(prestationAFacturer));
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findPrestationAFacturerByLigneCommande", "Probleme lors de la recherche des prestations � facturer pour la ligne de commande " + idLigneCommande, fe);
			throw new EJBException(fe);
		}
		return prestationAFacturerDTOs;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#createPrestationAFacturer(com.soliste.bolbec.livraison.service.model.PrestationAFacturerDTO)
	 */
	public PrestationAFacturerDTO createPrestationAFacturer(PrestationAFacturerDTO prestationAFacturerDTO) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "createPrestationAFacturer", "Cr�ation d'une PrestationAFacturer (id = " + prestationAFacturerDTO.getId() + ")");
		try {
			HashMap<String, Object> values = new HashMap<String, Object>();
			values.put(PrestationAFacturer.FIELD_CODE_DEBIT_CREDIT, prestationAFacturerDTO.getCodeDebitCredit());
			values.put(PrestationAFacturer.FIELD_CODE_OFFRE, prestationAFacturerDTO.getCodeOffre());
			values.put(PrestationAFacturer.FIELD_CODE_TRANSFERT, prestationAFacturerDTO.getCodeTransfert());
			values.put(PrestationAFacturer.FIELD_DATE_EFFET, prestationAFacturerDTO.getDateEffet());
			values.put(PrestationAFacturer.FIELD_DATETRANSFERT, prestationAFacturerDTO.getDateTransfert());
			values.put(PrestationAFacturer.FIELD_FACTURE_PAR_INSTANCE_S_E, prestationAFacturerDTO.getFactureParInstanceSe() == null ? null : prestationAFacturerDTO.getFactureParInstanceSe().getId());
			values.put(PrestationAFacturer.FIELD_ID_FICHIER, prestationAFacturerDTO.getIdFichier());
			values.put(PrestationAFacturer.FIELD_ID_LIGNE_CDE, prestationAFacturerDTO.getIdLigneCde());
			values.put(PrestationAFacturer.FIELD_MONTANT_HT, NumberUtils.toFloat(prestationAFacturerDTO.getMontantHt()));
			values.put(PrestationAFacturer.FIELD_ND, prestationAFacturerDTO.getNd());
			values.put(PrestationAFacturer.FIELD_TAUX_TVA, NumberUtils.toFloat(prestationAFacturerDTO.getTauxTva()));
			values.put(PrestationAFacturer.FIELD_TIMESTAMP, DateUtils.getDatabaseDate());
			values.put(PrestationAFacturer.FIELD_TRANSMIS_A_INSTANCE_S_E, prestationAFacturerDTO.getTransmisAInstanceSe() == null ? null : prestationAFacturerDTO.getTransmisAInstanceSe().getId());
			values.put(PrestationAFacturer.FIELD_QUANTITE, prestationAFacturerDTO.getQuantite());

			prestationAFacturerHome.create(prestationAFacturerDTO.getId(), values);
			return prestationAFacturerDTO;
		} catch (CreateException ce) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "createClient", "Erreur cr�ation d'une PrestationAFacturer : id " + prestationAFacturerDTO.getId(), ce);
			throw new EJBException(ce);
		}
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>25/02/2010</TD><TD>DBA</TD><TD>IRMA_151: Nouveau find</TD></TR>
	 * </TABLE>
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCasMetierByOpProgrammeeInterventionId(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public CasMetierDTO findCasMetierByOpProgrammeeInterventionId(String opProgrammeeInterventionId) {

		// IRMA_151: Impl�mentation du nouveau find
		// Le cas m�tier � calculer
		CasMetierDTO casMetier = null;
		try {

			// R�cup�ration du premier lien op prog lc
			LienOpProgLdC lien = CollectionUtils.getFirstOrNull((Collection<LienOpProgLdC>) lienOpProgLdCHome.findByRequiereOpProgrammee(opProgrammeeInterventionId));
			if (lien != null) {

				// R�cup�ration de la ligne de commande
				LigneCommande lc = lien.getLinkAppartientLigneCommande();
				if (lc != null) {

					// R�cup�ration de l'identifiant de la commande sur la ligne de commande
					String commandId = lc.getIdCommande();

					// Lecture de la commande
					Commande commande = commandeHome.findByPrimaryKey(new EntityBeanPK(commandId));

					// R�cup�ration de son cas m�tier
					casMetier = new CasMetierDTO(commande.getSeRefereCasMetier());
				}
			}
		} catch (FinderException e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCasMetierByOpProgrammeeInterventionId", "Probleme lors de la recherche du cas metier pour l'op programmee intervention " + opProgrammeeInterventionId, e);
			throw new EJBException(e);
		}

		// Retour du cas m�tier trouv� ou null
		return casMetier;
	}

	// --------------------------------------------------------------
	// Interlocuteur
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findInterlocuteurByIntervention(java.lang.String)
	 */
	public InterlocuteurDTO findInterlocuteurByIntervention(String interventionId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findInterlocuteurByIntervention", "Recherche de l'interlocuteur pour l'intervention " + interventionId);
		// TODO OLD: GTA revoir l'algo de cette m�thode (faire un finder plus appropri�)
		try {
			@SuppressWarnings("unchecked")
			Collection<OpProgrammee> ops = opProgrammeeHome.findByFaiteLorsIntervention(interventionId);
			for (OpProgrammee opProgrammee : ops) {
				@SuppressWarnings("unchecked")
				Collection<LienOpProgLdC> loplcs = opProgrammee.getLinkAppartientLigneCommande();
				Iterator<LienOpProgLdC> it = loplcs.iterator();
				if (it.hasNext()) {
					LigneCommande ligneCommande = it.next().getLinkAppartientLigneCommande();
					Commande commande = commandeHome.findByPrimaryKey(new EntityBeanPK(ligneCommande.getIdCommande()));
					if (commande.getLinkContacteInterlocuteur() != null) {
						return new InterlocuteurDTO(commande.getLinkContacteInterlocuteur());
					}
				}
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findInterlocuteurByIntervention", "Probleme lors de la recherche de l'interlocuteur pour l'intervention " + interventionId, fe);
			throw new EJBException(fe);
		}
		return null;
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#isMarked(java.lang.String)
	 */
	public boolean isMarked(String commandeId) {
		List<BlocNoteDTO> notes = findBlocNoteByCommande(commandeId);
		if (notes.size() > 0) {
			return true;
		}
		return false;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#isFTTHEntreprise(java.lang.String)
	 */
	public boolean isFTTHEntreprise(String commandeId) {
		if (StringUtils.isNotEmpty(commandeId)) {
			CommandeDTO commande = getCommande(commandeId);
			Map<String, String> dynCmd = commande.getDynamicCommandes();
			if (Constantes.CST_OUI.equals(dynCmd.get(ConstantesDynamicCommande.CLE_FTTH_ENTREPRISE))) {
				return true;
			}
		}
		return false;
	}

	// BLOC MIGRATION G9 /////////////////////////////////////////////////////////////////////////////////////
	// M�thodes d�finies pour les EJB Remote.
	// Elles sont associ�es � une transaction de type "RequiresNew" dans le descripteur de d�ploiement des EJB.
	// La transaction est donc born�e � la m�thode app�l�e.

	/**
	 * @see
	 */
	public Map<String, String> findDynamicsLigneCommandeWithNewTransaction(String ligneCommandeId) {
		return findDynamicsLigneCommande(ligneCommandeId);
	}

	/**
	 * @see
	 */
	public Map<String, String> findDynamicsCommandeWithNewTransaction(String commandeId) {
		return findDynamicsCommande(commandeId);
	}

	/**
	 * @see
	 */
	public EpCommercialDTO findEpCommercialByLigneCommandeWithNewTransaction(String ligneCommandeId) {
		return findEpCommercialByLigneCommande(ligneCommandeId);
	}

	/**
	 * @see
	 */
	public PsSouhaiteDTO findPsSouhaiteByLigneCommandeWithNewTransaction(String ligneCommandeId) {
		return findPsSouhaiteByLigneCommande(ligneCommandeId);
	}

	/**
	 * @see
	 */
	public Map<String, String> findDynamicsPsSouhaiteWithNewTransaction(String psSouhaiteId) {
		return findDynamicsPsSouhaite(psSouhaiteId);
	}

	/**
	 * @see
	 */
	public Map<String, String> findDynamicsEpCommercialWithNewTransaction(String epCommercialId) {
		return findDynamicsEpCommercial(epCommercialId);
	}

	/**
	 * @see
	 */
	public List<LigneCommandeDTO> findLigneCommandeByCommandeWithNewTransaction(String commandeId) {
		return findLigneCommandeByCommande(commandeId);
	}

	/**
	 * @see
	 */
	public CommandeDTO findCommandeByLigneCommandeWithNewTransaction(String ligneCommandeId) {
		return findCommandeByLigneCommande(ligneCommandeId);
	}

	/**
	 * @see
	 */
	public CommandeDTO findCommandeByIdWithNewTransaction(String id) {
		return findCommandeById(id);
	}

	/**
	 * @see
	 */
	public List<CommandeDTO> findCommandeEnCoursByNDWithNewTransaction(String nd) {
		return findCommandeEnCoursByND(nd);
	}

	/**
	 * @see
	 */
	public List<CommandeDTO> findCommandeEnCoursAVPInterfByNDWithNewTransaction(String nd) {
		return findCommandeEnCoursAVPInterfByND(nd);
	}

	/**
	 * @see
	 */
	public void updateDynamicLigneCommandeWithNewTransaction(LigneCommandeDTO ligneCommandeDTO) {
		updateDynamicLigneCommande(ligneCommandeDTO);
	}

	/**
	 * @see
	 */
	public void createInterferenceWithNewTransaction(InterferenceDTO interferenceDTO) {
		createInterference(interferenceDTO);
	}

	/**
	 * @see
	 */
	public void deleteInterferenceWithNewTransaction(String interferenceId) {
		deleteInterference(interferenceId);
	}

	/**
	 * @see
	 */
	public void updateInterferenceDateFinWithNewTransaction(InterferenceDTO interferenceDTO) {
		updateInterferenceDateFin(interferenceDTO);
	}

	/**
	 * @see
	 */
	public List<CommandeDTO> findCommandeByIdCommandeMixteWithNewTransaction(String commandeMixteId) {
		return findCommandeByIdCommandeMixte(commandeMixteId);
	}

	/**
	 * @see
	 */
	public CommandeDTO getCommandeWithNewTransaction(String commandeId) {
		return getCommande(commandeId);
	}

	/**
	 * @see
	 */
	public LigneCommandeDTO getLigneCommandeWithNewTransaction(String ligneCmdId) {
		return getLigneCommande(ligneCmdId);
	}

	/**
	 * @see
	 */
	public void updateCommandeStatutWithNewTransaction(CommandeDTO commandeDTO) {
		updateCommandeStatut(commandeDTO);
	}

	/**
	 * @see
	 */
	public void updateDynamicCommandeWithNewTransaction(CommandeDTO commandeDTO) {
		updateDynamicCommande(commandeDTO);
	}

	/**
	 * @see
	 */
	public EpCommercialDTO findEpCommercialByLigneCommandeSUWithNewTransaction(String ligneCommandeSUId) {
		return findEpCommercialByLigneCommandeSU(ligneCommandeSUId);
	}

	/**
	 * @see
	 */
	public List<InterferenceDTO> findInterferenceByCommandeWithNewTransaction(String commandeId) {
		return findInterferenceByCommande(commandeId);
	}

	/**
	 * @see
	 */
	public List<InterferenceDTO> findInterferenceByLigneCommandeWithNewTransaction(String commandeId) {
		return findInterferenceByLigneCommande(commandeId);
	}

	/**
	 * @see
	 */
	public OffreDTO getOffreForLigneCommandeCRNew(String lcId, boolean... load) {
		String methode = "getOffreForLigneCommandeCRNew";

		OffreDTO offre = null;
		PsSouhaiteDTO pss = findPsSouhaiteByLigneCommande(lcId);

		if (pss != null && pss.getPorteSurOffre() != null && pss.getPorteSurOffre().getId() != null) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methode, "Recherche de l'offre: " + pss.getPorteSurOffre().getId());
			if (load != null && load.length > 0 && load[0]) {
				offre = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, pss.getPorteSurOffre().getId());
			} else {
				offre = pss.getPorteSurOffre();
			}
			ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methode, "Offre trouv�e: " + offre);
		}

		return offre;
	}

	/**
	 * @see
	 */
	public OffreDTO getOffreForLigneCommandeSUNew(String lcId, boolean... load) {
		String methode = "getOffreForLigneCommandeSUNew";

		OffreDTO offre = null;
		ServiceManager.getInstance().getLoggerManager().finest(CLASSNAME, methode, "Recherche de l'EPC de la ldc " + lcId);
		EpCommercialDTO epCom = serviceManager.getCommandeManager().findEpCommercialByLigneCommandeSU(lcId);

		if (epCom != null && epCom.getOffre() != null && epCom.getOffre().getId() != null) {

			serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Recherche de l'offre: " + epCom.getOffre().getId());
			if (load != null && load.length > 0 && load[0]) {
				offre = serviceManager.getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, epCom.getOffre().getId());
			} else {
				offre = epCom.getOffre();
			}

			serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Offre trouv�e: " + offre);
		}
		return offre;
	}

	// FIN BLOC MIGRATION G9 /////////////////////////////////////////////////////////////////////////////////

	/**
	 *
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByProcessusId(java.lang.String)
	 */
	public CommandeDTO findCommandeByProcessusId(String processusId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByProcessusId", "Recherche et verrouille de la commande pour processus " + processusId);
		try {
			@SuppressWarnings("unchecked")
			Commande commande = (Commande) CollectionUtils.getFirstOrNull(commandeHome.findByProcessusId(processusId));
			if (commande != null) {
				return new CommandeDTO(commande);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByProcessusId", "Pas de commande pour processus = " + processusId, fe);
			throw new EJBException(fe);
		}
		return null;
	}

	/**
	 *
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByTacheId(java.lang.String)
	 */
	public CommandeDTO findCommandeByTacheId(String tacheId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByTacheId", "Recherche et verrouille de la commande pour tache " + tacheId);
		try {
			@SuppressWarnings("unchecked")
			Commande commande = (Commande) CollectionUtils.getFirstOrNull(commandeHome.findByTacheId(tacheId));
			if (commande != null) {
				return new CommandeDTO(commande);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByTacheId", "Pas de commande pour tache = " + tacheId, fe);
			throw new EJBException(fe);
		}
		return null;
	}

	/**
	 *
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager#findCommandeByEvtId(String)
	 */
	public CommandeDTO findCommandeByEvtId(String evtId) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "findCommandeByEvtId", "Recherche et verrouille de la commande pour evt " + evtId);
		try {
			@SuppressWarnings("unchecked")
			// Tentative de r�cup�ration au travers du processus
			Commande commande = (Commande) CollectionUtils.getFirstOrNull(commandeHome.findByEvtIdThroughProcessus(evtId));
			if (commande == null) {
				// Tentative de r�cup�ration au travers de la t�che
				commande = (Commande) CollectionUtils.getFirstOrNull(commandeHome.findByEvtIdThroughTache(evtId));
			}

			if (commande != null) {
				return new CommandeDTO(commande);
			}
		} catch (FinderException fe) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASSNAME, "findCommandeByEvtId", "Pas de commande pour evt = " + evtId, fe);
			throw new EJBException(fe);
		}
		return null;
	}



}
