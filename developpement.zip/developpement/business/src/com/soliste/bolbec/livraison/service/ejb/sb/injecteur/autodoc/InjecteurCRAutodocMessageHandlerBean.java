/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.autodoc;

import java.io.IOException;
import java.io.Serializable;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Message Handler Session Bean pour la r�ception de CR Autodoc en provenance du
 * routeur.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 * 
 * @author kfqd7402
 * @since on 6 avr. 2006
 */
public class InjecteurCRAutodocMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * Rappel: format du CR pour Autodoc
	 * 
	 * <?xml version="1.0" encoding="ISO-8859-1"?> <Blocxml>
	 * <IDroutage>RefArtemis</IDroutage> <Contenu> <![CDATA[ Bloc fonctionnel
	 * ]]> </Contenu> </Blocxml>
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException {
		// Validation du CR pour Autodoc
		ServiceManager.getInstance().getLoggerManager().finest("InjecteurCRAutodocMessageHandlerBean", "getActivationParam", (String) a_message);
		Document l_doc;
		try {
			l_doc = XmlUtils.getDocument((String) a_message);
		} catch (SAXException e) {
			throw new InvalidMessageException("Erreur de recuperation du document", a_message);
		} catch (IOException e) {
			throw new InvalidMessageException("Erreur de recuperation du document", a_message);
		}
		Element l_root = l_doc.getDocumentElement();
		NodeList l_ndLstRoutage = l_root.getElementsByTagName(TagsXML.TAG_IDROUTAGE);
		NodeList l_ndLstContenu = l_root.getElementsByTagName(TagsXML.TAG_CONTENU);
		if ((l_ndLstRoutage != null) && (l_ndLstRoutage.getLength() == 1) && (l_ndLstContenu != null) && (l_ndLstContenu.getLength() == 1)) {
			Node l_blocFct = (l_ndLstContenu.item(0)).getFirstChild();
			if ((l_blocFct != null) && ((l_blocFct.getNodeType() == Node.CDATA_SECTION_NODE) || ((l_blocFct.getNextSibling() != null) && (l_blocFct.getNextSibling().getNodeType() == Node.CDATA_SECTION_NODE)))) {
				// R�cup�ration de l'identifiant de routage du message ou
				// 'RefArtemis'
				Node l_nodeRoutage = (l_ndLstRoutage.item(0)).getFirstChild();
				String l_idRequete = l_nodeRoutage.getNodeValue();
				return new ActivationParam("COMMUT", l_idRequete);
			}
			throw new InvalidMessageException("Erreur de recuperation du document : format du CR invalide", a_message);
		}
		throw new InvalidMessageException("Erreur de recuperation du document : format du CR invalide", a_message);
	}
}