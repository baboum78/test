package com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import aps.CasMetierConstantes;
import aps.LienComplementCR;
import aps.PublicationConstantes;
import aps.SystemeExterneConstantes;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon.exception.NonPublicationException;
import com.soliste.bolbec.livraison.service.enumeration.CochisePharaonIndicateurActionEnum;
import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.LienComplementCrDTO;
import com.soliste.bolbec.livraison.service.model.LienPublicationDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.publication.IOPublication;
import com.soliste.bolbec.livraison.service.publication.Notification;
import com.soliste.bolbec.livraison.service.publication.NotificationCochisePharaon;
import com.soliste.bolbec.livraison.service.publication.Publication;
import com.soliste.bolbec.livraison.service.publication.PublicationUtils;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationCochisePharaon;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ProcessusUtil;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Impl�mentation de l'EJB session CochisePharaonManager.
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * <TR><TD>18/12/2015</TD><TD>GCL</TD><TD>EV-000348 : G9R2C1 - NET Commande unique</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377: ROME Offre - Commandes FTTE</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>EP0309</TD><TD>EP0309 - Transmettre vers Cochise et/ou Pharaon des informations sur certains �v�nements du process de livraison Artemis</TD></TR>
 * <TR><TD>EP0310</TD><TD>EP0310 - Pr�voir un param�trage sp�cifique pour chacune des publications vers Pharaon et/ou Cochise</TD></TR>
 * <TR><TD>REQ.5057</TD><TD>EP0145 - Ne pas alimenter les Infocentres pour les commandes FTTH op�rateur</TD></TR>
 * <TR><TD>REQ.9333</TD><TD>EP237 - Ne pas notifier les infocentres pour les commandes de mutations en masse (EV227)</TD></TR>
 * </TABLE>
 **/

public class CochisePharaonManagerBean implements SessionBean {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2743927599475904050L;

	private static final String CLASSNAME = CochisePharaonManagerBean.class.getName();

	protected IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * Cr�e les ejb sous-jacents
	 */
	public void ejbCreate() {
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon.CochisePharaonManager#creerNotification()
	 */
	public Notification creerNotification(String typePublication, TacheEnCoursDTO tec, String evtId, CochisePharaonIndicateurActionEnum indicateurAction, String ancienRole, String idTraitement) {
		final String methode = "creerNotification";
		// Dans de rares cas, certains traitements ne poss�dent pas de "t�che en cours" (cas non �lucid�). la publication n'est donc pas possible dans ce cas
		if (tec == null) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Erreur lors de la cr�ation de la notification Cochise/Pharaon : pas de t�che en cours associ�e au traitement");
			return null;
		}
		try {
			final CommandeDTO commande = serviceManager.getCommandeManager().getCommande(tec.getIdCommande());
			NotificationCochisePharaon notifCochisePharaon = new NotificationCochisePharaon();
			if (isCmdAIgnorer(commande)) {
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Commande Vente FTTH, Mutation DSLAM, Denum Induite, Resil PLPA ou D�m�nagement sans changement de ND -> pas de publication");
				return null;
			}
			return notifCochisePharaon.creerNotification(typePublication, tec, evtId, indicateurAction, ancienRole, idTraitement);
		} catch (Exception e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Erreur lors de la cr�ation de la notification Cochise/Pharaon", e);
		}
		return null;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon.CochisePharaonManager#creerNotificationAbandonRegul(String, ProcessusDTO, String)
	 */
	public Notification creerNotificationAbandonRegul(String typeNotification, ProcessusDTO processus, String evtId) {
		final String methode = "creerNotificationAbandon";
		try {
			final CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessus(processus.getId());
			NotificationCochisePharaon notifCochisePharaon = new NotificationCochisePharaon();
			if (isCmdAIgnorer(commande)) {
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Commande Vente FTTH, Mutation DSLAM, Denum Induite, Resil PLPA ou D�m�nagement sans changement de ND -> pas de publication");
				return null;
			}
			return notifCochisePharaon.creerNotificationAbandonRegul(typeNotification, processus, evtId);
		} catch (Exception e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Erreur lors de la cr�ation de la notification  Cochise/Pharaon", e);
		}
		return null;
	}

	public Notification creerNotificationAjoutNote(String typeNotification, final CommandeDTO commande, String evtId) {
		final String methode = "creerNotificationAjoutNote";
		try {
			List<ProcessusDTO> processuslst = serviceManager.getProcessusManager().findProcessusByCommande(commande.getId());

			ProcessusDTO processusDto = ProcessusUtil.extraireProcessusLivraison(processuslst);
			// Si le processus de livraison n'est pas trouv�, on recup�re le processus de compl�tude
			if (processusDto == null) {
				processusDto = ProcessusUtil.extraireProcessusCompletude(processuslst);
			}
			NotificationCochisePharaon notifCochisePharaon = new NotificationCochisePharaon();
			if (isCmdGraficVenteFTTHouMutDSLAMouDENUMINDUITE(commande)) {
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Commande Vente FTTH ou Mutation DSLAM ou Denum Induite-> pas de publication");
				return null;
			}
			return notifCochisePharaon.creerNotificationAjoutNote(typeNotification, processusDto, evtId);
		} catch (Exception e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Erreur lors de la cr�ation de la notification  Cochise/Pharaon", e);
		}
		return null;
	}

	/**
	 * Verification du tpe de la commande
	 * 
	 * @param tec
	 * @return true si commande Vente FTTH ou MutDSLAM, false sinon
	 */
	protected boolean isCmdGraficVenteFTTHouMutDSLAMouDENUMINDUITE(final CommandeDTO cmd) {
		if (cmd.getCasMetier() == null) {
			return false;
		}
		final String casMetierId = cmd.getCasMetier().getId();
		return (CasMetierConstantes.VENTE_FTTH.equals(casMetierId) || CasMetierConstantes.MUT_DSLAM.equals(casMetierId) || CasMetierConstantes.DENUM_INDUITE.equals(casMetierId));
	}

	/**
	 * Verification du tpe de la commande
	 * 
	 * @param tec
	 * @return true si commande Vente FTTH, MutDSLAM, Denum Induite, Resil PLPA, Demgt ss cht ND, CR FTTE ou SU FTTE, false sinon
	 */
	protected boolean isCmdAIgnorer(final CommandeDTO cmd) {
		if (cmd.getCasMetier() == null) {
			return false;
		}
		final String casMetierId = cmd.getCasMetier().getId();
		return (CasMetierConstantes.VENTE_FTTH.equals(casMetierId) || CasMetierConstantes.MUT_DSLAM.equals(casMetierId) || CasMetierConstantes.DENUM_INDUITE.equals(casMetierId) || CasMetierConstantes.RESIL_PLPA.equals(casMetierId)
				|| CasMetierConstantes.DEMGT_SANS_CHGT_ND.equals(casMetierId) || CasMetierConstantes.CR_FTTE.equals(casMetierId) || CasMetierConstantes.SU_FTTE.equals(casMetierId));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon.CochisePharaonManager#publierMessage(Notification)
	 */
	public void publierMessage(final Notification notification) {
		final String methode = "publierMessage";
		try {
			final Publication publication = new DeleguePublicationCochisePharaon(notification);
			final List<IOPublication> ioPublicationListe = creerIOPublicationListe(notification);
			publication.publier(ioPublicationListe);
		} catch (NonPublicationException npe) {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, "Aucune publication n'est � envoyer");
		} catch (Exception e) {
			serviceManager.getLoggerManager().warning(CLASSNAME, methode, "Erreur impr�vue lors de la publication vers Cochise et/ou Pharaon", e);
		}

	}

	/**
	 * Cr�e la liste des IOPublication en fonction de la notification
	 * 
	 * @param notification
	 * @return la liste de IOPublication
	 * @throws NonPublicationException
	 */
	private List<IOPublication> creerIOPublicationListe(Notification notification) throws NonPublicationException {
		final String typePublication = notification.getTypeNotification();
		final String idEvt = notification.getIdEvenement();
		final List<LigneCommandeDTO> lignesCommandeListe = serviceManager.getCommandeManager().findLigneCommandeByCommande(notification.getIdCommande());
		final CommandeDTO commande = serviceManager.getCommandeManager().getCommande(notification.getIdCommande());
		final String version = commande.getVersionArtemis();

		// D�termination de la causeEvt
		final String causeEvenementId = determinerCauseEvenement(notification, typePublication, idEvt);

		// Retourne les liens publication
		List<LienPublicationDTO> liensPublicationListe = filtrerLiensPublication(recupererLiensPublicationListe(typePublication, causeEvenementId, lignesCommandeListe, version), notification);

		// Contruction des IOPublication
		return creerIOPublicationListe(notification, lignesCommandeListe, commande, liensPublicationListe);

	}

	/**
	 * Filtre la liste des liens publication, et supprime ceux qui ne doivent pas �tre publi�s
	 * 
	 * @param liensPublication
	 * @param notification
	 * @return liste filtr�e
	 */
	private List<LienPublicationDTO> filtrerLiensPublication(List<LienPublicationDTO> liensPublication, Notification notification) {
		List<LienPublicationDTO> listeFiltree = new ArrayList<LienPublicationDTO>();
		String role = notification.getDynParam().get(NotificationCochisePharaon.ROLE);
		String ancienrole = notification.getDynParam().get(NotificationCochisePharaon.ANCIENROLE);

		// R�cup�ration du type de la t�che
		String typeTache = null;
		if (notification.getIdTache() != null) {
			TacheDTO tache = serviceManager.getProcessusManager().getTache(notification.getIdTache());
			CatalogueTacheDTO catalogueTache = tache.getCatalogueTache();
			catalogueTache = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, catalogueTache.getId());
			typeTache = catalogueTache.getType();
		}

		// Parcours des LiensPublication pour filtrer les publications
		for (LienPublicationDTO lienPublication : liensPublication) {
			String cleRole = null;
			SystemeExterneDTO systemeExterne = lienPublication.getDestineASystemeExterne();

			if (Constantes.CST_COCHISE.equals(systemeExterne.getNom())) {
				cleRole = ConstantesTraduction.CLE_ROLE_COCHISE;
			} else if (Constantes.CST_PHARAON.equals(systemeExterne.getNom())) {
				cleRole = ConstantesTraduction.CLE_ROLE_PHARAON;
			}

			// Recherche dans la table TraductionCatCom
			String tradRole = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, cleRole, role);
			String tradAncienRole = serviceManager.getTraductionManager().getTraductionCatComInterfVersArtemis(SystemeExterneConstantes.NUM_49W, cleRole, ancienrole);
			// Si la traduction trouv�e est "OUI", ou que le type de la t�che n'est ni "AVP" ni "MANUELLE"
			if (!(Constantes.CST_AVP.equals(typeTache) || Constantes.CST_MANUELLE.equals(typeTache)) || Arrays.asList(tradRole, tradAncienRole).contains(Constantes.CST_OUI)) {
				// On ajoute le lienPublication dans la liste filtr�e
				listeFiltree.add(lienPublication);
			}
		}
		return listeFiltree;
	}

	/**
	 * Permet de r�cup�rer la cause evenement. Cette valeur sera utilis�e pour filtrer les publications.
	 * Peut retrouner la valeur null
	 * 
	 * @param notification
	 * @param typePublication
	 * @param idEvt
	 * @return la cause evenement
	 * @throws NonPublicationException aucune publication n'est � envoyer lorsque cette exception est lanc�e
	 */
	private String determinerCauseEvenement(Notification notification, final String typePublication, final String idEvt) throws NonPublicationException {
		final String causeEvenementId;
		if (PublicationConstantes.PUB_COCHISE_PHARAON_FIN_TRT.equals(typePublication)) {
			// Cas particulier pour les publication "fin de trt" : traduction du traitement pour determiner la causeEvt
			final String traitement = notification.getDynParam().get(NotificationCochisePharaon.IDTRAITEMENT);
			final String traduction = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.CLE_TRADUCTION_TRAITEMENT_CAUSEEVT, traitement);

			// Si traduction non trouv�e, on ne recherche pas les liens Publication
			if (traduction == null) {
				throw new NonPublicationException();
			}
			causeEvenementId = String.format("%s_%s", Constantes.VERSION, traduction);
		} else if (PublicationConstantes.PUB_COCHISE_PHARAON_EVT.equals(typePublication) || PublicationConstantes.PUB_COCHISE_PHARAON_NOTE_CMD.equals(typePublication)) {
			// Pour les publication sur evt, on le recherche simplement via l'evt
			// Si pas d'evt, pas de publication
			if (idEvt == null) {
				throw new NonPublicationException();
			}
			// Recherche de la cause evt
			final EvtDTO evt = serviceManager.getProcessusManager().getEvt(idEvt);
			// Si evt non trouv� en base, ou l'evt n'a pas de causeEvt, pas de publication
			if (evt == null || evt.getCauseEvenement() == null) {
				throw new NonPublicationException();
			}
			causeEvenementId = evt.getCauseEvenement().getId();
		} else {
			// Pour le reste des publications, la cause evt est nul
			causeEvenementId = null;
		}
		return causeEvenementId;
	}

	/**
	 * R�cup�re les listes Lienpublication en parcourant les lignes de commande.
	 * Si au moins un lienPublication a �t� trouv� la liste est retourn�e.
	 * Dans le cas contraire, aucune publication n'est � envoyer
	 * 
	 * @param typePublication
	 * @param causeEvenementId
	 * @param lignesCommandeListe
	 * @return la liste des liens publication
	 * @throws NonPublicationException aucune publication n'est � envoyer lorsque cette exception est lanc�e
	 */
	private List<LienPublicationDTO> recupererLiensPublicationListe(final String typePublication, final String causeEvenementId, final List<LigneCommandeDTO> lignesCommandeListe, final String version) throws NonPublicationException {
		List<LienPublicationDTO> liensPublicationListe = new ArrayList<LienPublicationDTO>();
		for (LigneCommandeDTO ligneCommande : lignesCommandeListe) {
			final OffreDTO offre = serviceManager.getOffreManager().getOffreByPSSAfterEPC(ligneCommande.getId(), true);
			if (offre == null) {
				continue;
			}
			final String familleOffreCom = offre.getFamilleOffreCom().getId();
			liensPublicationListe = PublicationUtils.getListeLienPublication(typePublication, familleOffreCom, null, null, causeEvenementId, PublicationUtils.CONTEXTE_LIGNE_LP_GEST_PUB, version);
			// Une publication trouv�e, on effectue la publication
			if (!liensPublicationListe.isEmpty()) {
				break;
			}
		}

		// Si aucune famille n'a correspondu, pas de publication
		if (liensPublicationListe.isEmpty()) {
			throw new NonPublicationException();
		}
		return liensPublicationListe;
	}

	/**
	 * Cr�e la liste de IOPublication
	 * 
	 * @param notification
	 * @param lignesCommandeListe
	 * @param commande
	 * @param liensPublicationListe
	 * @return la liste de IOPublication
	 */
	private List<IOPublication> creerIOPublicationListe(Notification notification, final List<LigneCommandeDTO> lignesCommandeListe, final CommandeDTO commande, List<LienPublicationDTO> liensPublicationListe) {
		IOPublication ioPublication;
		List<LienComplementCrDTO> liensComplementCr;
		String evtId;
		final List<IOPublication> ioPublicationListe = new ArrayList<IOPublication>();
		for (LienPublicationDTO lienPublication : liensPublicationListe) {
			evtId = notification.getIdEvenement() != null ? notification.getIdEvenement() : null;
			ioPublication = new IOPublication(null, null, null, null, evtId, lienPublication.getFormatExterne(), lienPublication.getDestineASystemeExterne().getId(), lienPublication.getId(), commande.getRefExterne(), lienPublication.getNiveauCr(), null,
					null, null, lignesCommandeListe);
			liensComplementCr = serviceManager.getReferenceSpaceManager().listInReferenceSpace(LienComplementCrDTO.class, new Comparaison(LienComplementCR.SLINK_POUR_LIEN_PUBLICATION, Constantes.OPERATOR_EQUAL, lienPublication.getId()));
			ioPublication.setLienComplementCR(liensComplementCr);
			ioPublicationListe.add(ioPublication);
		}
		return ioPublicationListe;
	}

	/**
	 * Le session context n'est pas r�cup�r�
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sc) throws EJBException, RemoteException {
	}

	/**
	 * M�thode non appel�e
	 */
	public void ejbActivate() throws EJBException, RemoteException {
	}

	/**
	 * M�thode non appel�e
	 */
	public void ejbPassivate() throws EJBException, RemoteException {
	}

	/**
	 * Rien � Nettoyer
	 */
	public void ejbRemove() throws EJBException, RemoteException {
	}

}
