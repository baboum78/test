/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.commande.data;

import java.util.Collection;

import javax.ejb.FinderException;

import aps.Commande;
import aps.MessageSagicIn;
import aps.MessageSagicInHome;
import aps.SystemeExterneConstantes;

import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * DTO pour les infos compl�mentaires d'une commande (SAGIC)
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>11/06/2014</TD><TD>GCL</TD><TD>G9R0C1 DE-001069 Suppression de la classe ConstantUtil</TD></TR>
 * </TABLE><BR>
 * 
 * @author rgvs7490
 */
public class InfosComplementairesCommandeDTOFactory {

	private InfosComplementairesCommandeDTOFactory() {
		// Nothing to do
	}

	/**
	 * @param commande
	 * @param messageSagicInHome
	 * @return InfosComplementairesCommandeDTO
	 * @throws FinderException
	 */
	@SuppressWarnings("unchecked")
	public static InfosComplementairesCommandeDTO create(Commande commande, MessageSagicInHome messageSagicInHome) throws FinderException {
		InfosComplementairesCommandeDTO dto = new InfosComplementairesCommandeDTO();
		dto.setId(commande.getId());
		SystemeExterneDTO systemeExterne = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getProvientSystemeExterne());
		if (systemeExterne != null) {
			if (SystemeExterneConstantes.SAGIC_VALEUR_CONSTANTE.equals(systemeExterne.getValeurConstante())) {
				// TODO OLD: v�rifier avec Pascal qu'on prend le premier
				Collection<MessageSagicIn> messageSagicInCollection = messageSagicInHome.findParIdExterne(commande.getRefExterne());
				if (messageSagicInCollection.size() > 0) {
					MessageSagicIn messageSagicIn = messageSagicInCollection.iterator().next();
					dto.setXmlText(messageSagicIn.getContenu());
				}
			}
		}
		return dto;
	}
}