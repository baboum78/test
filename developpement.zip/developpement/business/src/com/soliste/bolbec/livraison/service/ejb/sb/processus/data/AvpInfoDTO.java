/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;

import com.soliste.bolbec.livraison.service.model.TacheDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>13/01/2011</TD><TD>LBA</TD><TD>EV-000089: NSD+ Ajout bouton abandon provisoire</TD></TR>
 * <TR><TD>06/07/2018</TD><TD>AJO</TD><TD>QC980 : Intrants FTTH</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO contenant les informations affich�es dans l'�cran AVP. Ce DTO est en
 * r�alit� la classe m�re de DTO sp�cifiques, contenant en plus les donn�es
 * sp�cifiques de l'AVP
 * 
 * @author rgvs7490
 */
public class AvpInfoDTO implements Serializable {

	public static final String AVP_STANDARD_TYPE = "AVPStandard";
	public static final String AVP_AFFECTATION_XDSL_TYPE = "AVPAffectationEPT";
	public static final String AVP_AFFECTATION_NV_BL_TYPE = "AVPAffectationNvBL";
	public static final String AVP_COMP_COM_TYPE = "AVPCompCom";
	public static final String AVP_CONTROLE_AFF_TYPE = "AVPControleAFF";
	public static final String AVP_MAJ_PARC_MATERIEL_TYPE = "AVPMAJParcMateriel";
	public static final String AVP_CORRECTION_ADRESSE = "AVPCORRADR";
	public static final String AVP_EVT_ABSENT = "AVPEVTABSENT";
	public static final String AVP_AFF_THD = "AVPAFFTHD";
	public static final String AVP_AFF_BLO = "AVPAFFBLO";
	public static final String AVP_OPE_IMB_ABS = "AVPOPEIMBABS";
	public static final String AVP_CTRL_COHERENCE_CMD = "AVPControleCoherenceCommande";
	public static final String AVP_AFF_BLO_IMM_NON_TROUVE = "AVP_AFF_BLO_IMM_NON_TROUVE";
	private String processusId;
	private TacheDTO tachePrecedente;
	private TacheDTO tacheCourante;
	private String evenementProvoquantId;
	private String modeOperatoireUrl;

	private boolean complet;
	private boolean abandonnable;
	private boolean abandonnablePartiellement;
	private boolean abandonnableProvisoirement;
	private boolean suspendable;
	private boolean retablissable;
	private boolean stoppable;
	private boolean regularisable;

	/**
	 * 
	 */
	AvpInfoDTO() {
		//
	}

	public String getProcessusId() {
		return this.processusId;
	}

	void setProcessusId(String processusId) {
		this.processusId = processusId;
	}

	public String getEvenementProvoquantId() {
		return this.evenementProvoquantId;
	}

	void setEvenementProvoquantId(String evenementProvoquantId) {
		this.evenementProvoquantId = evenementProvoquantId;
	}

	/**
	 * Retourne la tache courante, avec ses �v�nements
	 * 
	 * @return la tache courante, avec ses �v�nements
	 */
	public TacheDTO getTacheCourante() {
		return this.tacheCourante;
	}

	void setTacheCourante(TacheDTO tacheCourante) {
		this.tacheCourante = tacheCourante;
	}

	/**
	 * Retourne la tache pr�c�dente, avec ses �v�nements
	 * 
	 * @return la tache pr�c�dente, avec ses �v�nements
	 */
	public TacheDTO getTachePrecedente() {
		return this.tachePrecedente;
	}

	void setTachePrecedente(TacheDTO tachePrecedente) {
		this.tachePrecedente = tachePrecedente;
	}

	public String getModeOperatoireUrl() {
		return this.modeOperatoireUrl;
	}

	void setModeOperatoireUrl(String modeOperatoirUrl) {
		this.modeOperatoireUrl = modeOperatoirUrl;
	}

	public boolean isComplet() {
		return this.complet;
	}

	void setComplet(boolean complet) {
		this.complet = complet;
	}

	public boolean isAbandonnable() {
		return this.abandonnable;
	}

	void setAbandonnable(boolean abandonnable) {
		this.abandonnable = abandonnable;
	}

	public boolean isAbandonnablePartiellement() {
		return this.abandonnablePartiellement;
	}

	void setAbandonnablePartiellement(boolean abandonnablePartiellement) {
		this.abandonnablePartiellement = abandonnablePartiellement;
	}

	public boolean isAbandonnableProvisoirement() {
		return this.abandonnableProvisoirement;
	}

	void setAbandonnableProvisoirement(boolean abandonnableProvisoirement) {
		this.abandonnableProvisoirement = abandonnableProvisoirement;
	}

	public boolean isSuspendable() {
		return this.suspendable;
	}

	void setSuspendable(boolean suspendable) {
		this.suspendable = suspendable;
	}

	public boolean isRetablissable() {
		return this.retablissable;
	}

	void setRetablissable(boolean retablissable) {
		this.retablissable = retablissable;
	}

	/**
	 * Retourne AVP_STANDARD_TYPE. Les sous-classes doivent red�finir cette
	 * m�thode
	 * 
	 * @return AVP_STANDARD_TYPE
	 */
	public String getType() {
		return AVP_STANDARD_TYPE;
	}

	public String getAVP_AFFECTATION_XDSL_TYPE() {
		return AVP_AFFECTATION_XDSL_TYPE;
	}

	public String getAVP_COMP_COM_TYPE() {
		return AVP_COMP_COM_TYPE;
	}

	public String getAVP_CONTROLE_AFF_TYPE() {
		return AVP_CONTROLE_AFF_TYPE;
	}

	public String getAVP_MAJ_PARC_MATERIEL_TYPE() {
		return AVP_MAJ_PARC_MATERIEL_TYPE;
	}

	public String getAVP_CORRECTION_ADRESSE() {
		return AVP_CORRECTION_ADRESSE;
	}

	public String getAVP_EVT_ABSENT() {
		return AVP_EVT_ABSENT;
	}

	public String getAVP_AFF_THD() {
		return AVP_AFF_THD;
	}

	public String getAVP_AFF_BLO() {
		return AVP_AFF_BLO;
	}

	public String getAVP_CTRL_COHERENCE_CMD() {
		return AVP_CTRL_COHERENCE_CMD;
	}

	public String getAVP_OPE_IMB_ABS() {
		return AVP_OPE_IMB_ABS;
	}

	public String getAVP_AFF_BLO_IMM_NON_TROUVE() {
		return AVP_AFF_BLO_IMM_NON_TROUVE;
	}

	public boolean isRegularisable() {
		return regularisable;
	}

	public void setRegularisable(boolean regularisable) {
		this.regularisable = regularisable;
	}

	public boolean isStoppable() {
		return stoppable;
	}

	public void setStoppable(boolean stoppable) {
		this.stoppable = stoppable;
	}
}
