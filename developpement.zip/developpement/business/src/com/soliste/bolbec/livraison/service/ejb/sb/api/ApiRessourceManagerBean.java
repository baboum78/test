package com.soliste.bolbec.livraison.service.ejb.sb.api;

import java.rmi.RemoteException;

import javax.ejb.EJBException;
import javax.ejb.SessionBean;
import javax.ejb.SessionContext;

import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.AppointmentRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.NoteRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.ServiceOrderRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.TaskRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.AddressRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.AppointmentRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.CustomerRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.DonneeReferenceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.NoteRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.PublicationRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.ServiceOrderRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.TaskRessourceTraitementV2;

/**
 * Impl�mentation de l'EJB session ApiRessourceManager.
 * 
 * @author mfayd
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>27/11/2015</TD><TD>MFA</TD><TD>Initialisation de l EJB</TD></TR>
 * <TR><TD>05/10/2016</TD><TD>JDE</TD><TD>Ajout des traitements V2</TD></TR>
 * <TR><TD>19/10/2016</TD><TD>JDE</TD><TD>Ajout du CustomerRessourceTraitement et AddressRessourceTraitement</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>API REST</TD></TR>
 * </TABLE>
 **/

public class ApiRessourceManagerBean implements SessionBean {
	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 2743927599475904050L;

	// Liste des service de traitement de ressources
	private NoteRessourceTraitement noteRessourceTraitement = new NoteRessourceTraitement();
	private TaskRessourceTraitement taskRessourceTraitement = new TaskRessourceTraitement();
	private AppointmentRessourceTraitement appointmentRessourceTraitement = new AppointmentRessourceTraitement();
	private ServiceOrderRessourceTraitement serviceOrderRessourceTraitement = new ServiceOrderRessourceTraitement();

	// Liste des service de traitement de ressources V2
	private NoteRessourceTraitementV2 noteRessourceTraitementV2 = new NoteRessourceTraitementV2();
	private TaskRessourceTraitementV2 taskRessourceTraitementV2 = new TaskRessourceTraitementV2();
	private AppointmentRessourceTraitementV2 appointmentRessourceTraitementV2 = new AppointmentRessourceTraitementV2();
	private ServiceOrderRessourceTraitementV2 serviceOrderRessourceTraitementV2 = new ServiceOrderRessourceTraitementV2();
	private CustomerRessourceTraitementV2 customerRessourceTraitementV2 = new CustomerRessourceTraitementV2();
	private AddressRessourceTraitementV2 addressRessourceTraitementV2 = new AddressRessourceTraitementV2();
	private PublicationRessourceTraitementV2 publicationRessourceTraitementV2 = new PublicationRessourceTraitementV2();
	private DonneeReferenceTraitementV2 donneeReferenceTraitementV2 = new DonneeReferenceTraitementV2();

	/**
	 * @return the noteRessourceTraitement
	 */
	public NoteRessourceTraitement getNoteRessourceTraitement() {
		return noteRessourceTraitement;
	}

	/**
	 * @return the taskRessourceTraitement
	 */
	public TaskRessourceTraitement getTaskRessourceTraitement() {
		return taskRessourceTraitement;
	}

	/**
	 * @return the appointmentRessourceTraitement
	 */
	public AppointmentRessourceTraitement getAppointmentRessourceTraitement() {
		return appointmentRessourceTraitement;
	}

	/**
	 * @return the serviceOrderRessourceTraitement
	 */
	public ServiceOrderRessourceTraitement getServiceOrderRessourceTraitement() {
		return serviceOrderRessourceTraitement;
	}

	/**
	 * @return the noteRessourceTraitementV2
	 */
	public NoteRessourceTraitementV2 getNoteRessourceTraitementV2() {
		return noteRessourceTraitementV2;
	}

	/**
	 * @return the taskRessourceTraitementV2
	 */
	public TaskRessourceTraitementV2 getTaskRessourceTraitementV2() {
		return taskRessourceTraitementV2;
	}

	/**
	 * @return the appointmentRessourceTraitementV2
	 */
	public AppointmentRessourceTraitementV2 getAppointmentRessourceTraitementV2() {
		return appointmentRessourceTraitementV2;
	}

	/**
	 * @return the serviceOrderRessourceTraitement
	 */
	public ServiceOrderRessourceTraitementV2 getServiceOrderRessourceTraitementV2() {
		return serviceOrderRessourceTraitementV2;
	}

	/**
	 * @return the customerRessourceTraitementV2
	 */
	public CustomerRessourceTraitementV2 getCustomerRessourceTraitementV2() {
		return customerRessourceTraitementV2;
	}

	/**
	 * @return the addressRessourceTraitementV2
	 */
	public AddressRessourceTraitementV2 getAddressRessourceTraitementV2() {
		return addressRessourceTraitementV2;
	}

	/**
	 * @return the publicationRessourceTraitementV2
	 */
	public PublicationRessourceTraitementV2 getPublicationRessourceTraitementV2() {
		return publicationRessourceTraitementV2;
	}

	/**
	 * @return the donneeReferenceTraitementV2
	 */
	public DonneeReferenceTraitementV2 getDonneeReferenceTraitementV2() {
		return donneeReferenceTraitementV2;
	}

	/******************************************************************************************************************************************/

	/**
	 * Cr�e les ejb sous-jacents
	 */
	public void ejbCreate() {
	}

	@Override
	public void ejbActivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void ejbPassivate() throws EJBException, RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void ejbRemove() throws EJBException, RemoteException {
		// TODO Auto-generated method stub

	}

	@Override
	public void setSessionContext(@SuppressWarnings("unused") SessionContext arg0) throws EJBException, RemoteException {
		// TODO Auto-generated method stub

	}

}
