/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

/**
 * DTO pour les champs ramen�s par une requ�te
 * 
 * @author gdzd8490
 * 
 */
public class SelectedFieldDTO {

	private SelectedField selectedField;

	/**
	 * Renvoie le champ s�lectionn�
	 * 
	 * @return le champ s�lectionn�
	 */
	public SelectedField getSelectedField() {
		return selectedField;
	}

	/**
	 * D�termine le champ s�lectionn�
	 * 
	 * @param selectedField
	 * le champ s�lectionn�
	 */
	public void setSelectedField(SelectedField selectedField) {
		this.selectedField = selectedField;
	}

}
