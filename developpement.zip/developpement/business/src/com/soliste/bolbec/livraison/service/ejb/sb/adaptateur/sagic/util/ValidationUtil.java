/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.util;

import java.text.ParseException;

import aps.AnomalieConstantes;
import bolbec.adaptateur.sagic.xml.generated.CommandeSagic;
import bolbec.adaptateur.sagic.xml.generated.ComplementService;
import bolbec.adaptateur.sagic.xml.generated.IC;
import bolbec.adaptateur.sagic.xml.generated.types.CodeAction;

import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.SagicConstantes;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;

/**
 * Classe ICSagicValidationDelegate qui fait la validation que Castor n'est pas
 * capable de faire.
 * 
 * @author Phil Bretherton
 */
public class ValidationUtil {

	/** String ERR_MSG_CHAMP. */
	private static final String ERR_MSG_CHAMP = "Le champ ";

	/** String ERR_MSG_CODE_ACTION. */
	private static final String ERR_MSG_CODE_ACTION = " doit �tre renseign� quand le code action est ";

	/** String ERR_MSG_COMMANDE_SAGIC_IC. */
	private static final String ERR_MSG_COMMANDE_SAGIC_IC = "CommandeSagic/IC/";

	/** String ERR_MSG_COMPLEMENT_SERVICE. */
	private static final String ERR_MSG_COMPLEMENT_SERVICE = "ComplementService/";

	/** String ERR_MSG_DATE_PRISE_COMMANDE. */
	private static final String ERR_MSG_DATE_PRISE_COMMANDE = "DatePriseCommande : ";

	/** String ERR_MSG_DATE_RECEP. */
	private static final String ERR_MSG_DATE_RECEP = "DateRecep : ";

	/** String ERR_MSG_DMADFOP. */
	private static final String ERR_MSG_DMADFOP = "DMADFOP";

	/** String ERR_MSG_DSFOP. */
	private static final String ERR_MSG_DSFOP = "DSFOP";

	/** String ERR_MSG_FORMAT_DATE. */
	private static final String ERR_MSG_FORMAT_DATE = "Erreur de format de date de ";

	/** String STRING_COLON. */
	private static final String STRING_COLON = ":";

	/** String STRING_SPACE. */
	private static final String STRING_SPACE = " ";

	/**
	 * Constructeur.
	 */
	ValidationUtil() {
		// Rien � faire
	}

	/**
	 * Validate.
	 * 
	 * @param commandeSagic the commande sagic
	 */
	public static void validate(CommandeSagic commandeSagic) {
		IC ic = commandeSagic.getIC();
		ComplementService cs = ic.getComplementService();
		CodeAction codeAction = ic.getCodeAction();
		validateDatePriseCommande(ic.getDatePriseCommande());
		validateDateRecep(cs.getDateRecep());
		validateDMADFOP(ic.getDMADFOP(), codeAction);
		validateDSFOP(ic.getDSFOP(), codeAction);
	}

	/**
	 * Gets the null field exception.
	 * 
	 * @param field the field
	 * @param codeAction the code action
	 * 
	 * @return <code>ReceptionICSagicException</code>
	 */
	private static ReceptionCdeException getNullFieldException(String field, CodeAction codeAction) {
		return new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, ERR_MSG_CHAMP + field + ERR_MSG_CODE_ACTION + codeAction.toString());
	}

	/**
	 * Validate date prise commande.
	 * 
	 * @param value the value
	 */
	private static void validateDatePriseCommande(String value) {
		if (StringUtils.isEmpty(value)) {
			return;
		}
		try {
			DateUtils.parseDate(value, SagicConstantes.FORMAT_DATE_HEURE);
		} catch (ParseException e) {
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, ERR_MSG_FORMAT_DATE + ERR_MSG_COMMANDE_SAGIC_IC + ERR_MSG_DATE_PRISE_COMMANDE + value);
		}
	}

	/**
	 * Validate date recep.
	 * 
	 * @param value the value
	 */
	private static void validateDateRecep(String value) {
		if (StringUtils.isEmpty(value)) {
			return;
		}
		try {
			DateUtils.parseDate(value, SagicConstantes.FORMAT_DATE);
		} catch (ParseException e) {
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, ERR_MSG_FORMAT_DATE + ERR_MSG_COMMANDE_SAGIC_IC + ERR_MSG_COMPLEMENT_SERVICE + ERR_MSG_DATE_RECEP + value);
		}
	}

	/**
	 * Validate dmadfop.
	 * 
	 * @param value the value
	 * @param codeAction the code action
	 */
	private static void validateDMADFOP(String value, CodeAction codeAction) {
		if (StringUtils.isEmpty(value)) {
			if (CodeAction.CR.equals(codeAction) || CodeAction.MO.equals(codeAction) || CodeAction.MI.equals(codeAction) || CodeAction.MNRAHD.equals(codeAction) || CodeAction.MNRAHDO.equals(codeAction)) {
				throw getNullFieldException(ERR_MSG_COMMANDE_SAGIC_IC + ERR_MSG_DMADFOP, codeAction);
			}
		} else {
			try {
				DateUtils.parseDate(value, SagicConstantes.FORMAT_DATE);
			} catch (ParseException e) {
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, ERR_MSG_FORMAT_DATE + ERR_MSG_COMMANDE_SAGIC_IC + ERR_MSG_DMADFOP + STRING_SPACE + STRING_COLON + STRING_SPACE + value);
			}
		}
	}

	/**
	 * Validate dsfop.
	 * 
	 * @param value the value
	 * @param codeAction the code action
	 */
	private static void validateDSFOP(String value, CodeAction codeAction) {
		if (StringUtils.isEmpty(value)) {
			if (CodeAction.CR.equals(codeAction) || CodeAction.MO.equals(codeAction) || CodeAction.MI.equals(codeAction) || CodeAction.SU.equals(codeAction) || CodeAction.MNRAHD.equals(codeAction) || CodeAction.MNRAHDO.equals(codeAction)) {
				throw getNullFieldException(ERR_MSG_COMMANDE_SAGIC_IC + ERR_MSG_DSFOP, codeAction);
			}
		} else {
			try {
				DateUtils.parseDate(value, SagicConstantes.FORMAT_DATE);
			} catch (ParseException e) {
				throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICSAGIC, ERR_MSG_FORMAT_DATE + ERR_MSG_COMMANDE_SAGIC_IC + ERR_MSG_DSFOP + STRING_SPACE + STRING_COLON + STRING_SPACE + value);
			}
		}
	}

}