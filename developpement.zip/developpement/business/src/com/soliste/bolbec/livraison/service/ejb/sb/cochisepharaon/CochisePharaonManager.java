package com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon;

import javax.ejb.EJBLocalObject;

import com.soliste.bolbec.livraison.service.enumeration.CochisePharaonIndicateurActionEnum;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.publication.Notification;

/**
 * Interface local de l'EJB session CochisePharaonManager.
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>EP0309</TD><TD>EP0309 - Transmettre vers Cochise et/ou Pharaon des informations sur certains �v�nements du process de livraison Artemis</TD></TR>
 * <TR><TD>EP0310</TD><TD>EP0310 - Pr�voir un param�trage sp�cifique pour chacune des publications vers Pharaon et/ou Cochise</TD></TR>
 * <TR><TD>EV353</TD><TD>EV353 - Ajout de la publication de note sur commande</TD></TR>
 * </TABLE>
 */
public interface CochisePharaonManager extends EJBLocalObject {

	/**
	 * Cr�e la notification pour Cochise et/ou Pharaon
	 * 
	 * @return la notification
	 */
	public Notification creerNotification(final String typePublication, final TacheEnCoursDTO tec, final String evtId, final CochisePharaonIndicateurActionEnum indicateurAction, final String ancienRole, final String idTraitement);

	/**
	 * Cr�e une notification pour Cochise et/ou Pharaon exclusivement pour l'abandon et r�gularisation
	 * 
	 * @param processus
	 * @param evtId
	 * @return la notification
	 */
	public Notification creerNotificationAbandonRegul(String typeNotification, ProcessusDTO processus, String evtId);

	/**
	 * Cr�e une notification pour Cochise et/ou Pharaon exclusivement pour la saisie de note sur Commande
	 * 
	 * @param typeNotification
	 * @param processus
	 * @return
	 */

	public Notification creerNotificationAjoutNote(String typeNotification, CommandeDTO commande, String evtId);

	/**
	 * Publie un message vers Pharaon
	 * 
	 * @param notification la notification
	 */
	public void publierMessage(final Notification notification);

}
