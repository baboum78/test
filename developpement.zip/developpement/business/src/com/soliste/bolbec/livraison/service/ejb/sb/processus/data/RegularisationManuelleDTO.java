/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;
import java.util.List;
import java.util.SortedMap;

import aps.CatalogueTacheConstantes;

import com.soliste.bolbec.livraison.service.model.JalonDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Le DTO pour l'entit� RegularisationManuelle
 * 
 * @author La�titia FABRE
 */
public class RegularisationManuelleDTO implements Serializable {

	private String modeOperatoireUrl;

	private String idProcessus;

	private String catalogueTacheValConst;

	private boolean retournable;
	private boolean envoyable;
	private boolean sortable;

	private SortedMap<JalonDTO, SortedMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>>> listeCRNonInfocentre;
	private SortedMap<JalonDTO, List<ListCRSupDeProDTO>> listeCRSupDePro;
	private List<CROsirisDTO> listeCROsiris;

	/**
	 * 
	 */
	RegularisationManuelleDTO() {
		//
	}

	/**
	 * @return CatalogueTacheConstantes.COMPLETERCR_VALEUR_CONSTANTE
	 */
	public String getCOMPLETERCR_VALEUR_CONSTANTE() {
		return CatalogueTacheConstantes.COMPLETERCR_VALEUR_CONSTANTE;
	}

	/**
	 * @return CatalogueTacheConstantes.COMPLETERCRABAN_VALEUR_CONSTANTE
	 */
	public String getCOMPLETERCRABAN_VALEUR_CONSTANTE() {
		return CatalogueTacheConstantes.COMPLETERCRABAN_VALEUR_CONSTANTE;
	}

	/**
	 * @return idProcessus
	 */
	public String getIdProcessus() {
		return idProcessus;
	}

	/**
	 * @param idProcessus
	 */
	public void setIdProcessus(String idProcessus) {
		this.idProcessus = idProcessus;
	}

	/**
	 * @return modeOperatoireUrl
	 */
	public String getModeOperatoireUrl() {
		return modeOperatoireUrl;
	}

	/**
	 * @param modeOperatoireUrl
	 */
	public void setModeOperatoireUrl(String modeOperatoireUrl) {
		this.modeOperatoireUrl = modeOperatoireUrl;
	}

	/**
	 * Retourne le <code>listeCROsiris</code>
	 * 
	 * @return le <code>listeCROsiris</code>
	 */
	public List<CROsirisDTO> getListeCROsiris() {
		return listeCROsiris;
	}

	/**
	 * Affecte le <code>listeCROsiris</code>
	 * 
	 * @param listeCROsiris le <code>listeCROsiris</code> � affecter
	 */
	public void setListeCROsiris(List<CROsirisDTO> listeCROsiris) {
		this.listeCROsiris = listeCROsiris;
	}

	/**
	 * Retourne le <code>listeCRNonInfocentre</code>
	 * 
	 * @return le <code>listeCRNonInfocentre</code>
	 */
	public SortedMap<JalonDTO, SortedMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>>> getListeCRNonInfocentre() {
		return listeCRNonInfocentre;
	}

	/**
	 * Affecte le <code>listeCRNonInfocentre</code>
	 * 
	 * @param listeCRNonInfocentre le <code>listeCRNonInfocentre</code> � affecter
	 */
	public void setListeCRNonInfocentre(SortedMap<JalonDTO, SortedMap<SystemeExterneDTO, List<CRGenNonInfocentreDTO>>> listeCRNonInfocentre) {
		this.listeCRNonInfocentre = listeCRNonInfocentre;
	}

	/**
	 * Retourne le <code>listeCRSupDePro</code>
	 * 
	 * @return le <code>listeCRSupDePro</code>
	 */
	public SortedMap<JalonDTO, List<ListCRSupDeProDTO>> getListeCRSupDePro() {
		return listeCRSupDePro;
	}

	/**
	 * Affecte le <code>listeCRSupDePro</code>
	 * 
	 * @param listeCRSupDePro le <code>listeCRSupDePro</code> � affecter
	 */
	public void setListeCRSupDePro(SortedMap<JalonDTO, List<ListCRSupDeProDTO>> listeCRSupDePro) {
		this.listeCRSupDePro = listeCRSupDePro;
	}

	/**
	 * @return envoyable
	 */
	public boolean isEnvoyable() {
		return envoyable;
	}

	/**
	 * @param envoyable
	 */
	public void setEnvoyable(boolean envoyable) {
		this.envoyable = envoyable;
	}

	/**
	 * @return retournable
	 */
	public boolean isRetournable() {
		return retournable;
	}

	/**
	 * @param retournable
	 */
	public void setRetournable(boolean retournable) {
		this.retournable = retournable;
	}

	/**
	 * @return sortable
	 */
	public boolean isSortable() {
		return sortable;
	}

	/**
	 * @param sortable
	 */
	public void setSortable(boolean sortable) {
		this.sortable = sortable;
	}

	/**
	 * @return catalogueTacheValConst
	 */
	public String getCatalogueTacheValConst() {
		return catalogueTacheValConst;
	}

	/**
	 * @param catalogueTacheValConst
	 */
	public void setCatalogueTacheValConst(String catalogueTacheValConst) {
		this.catalogueTacheValConst = catalogueTacheValConst;
	}

}