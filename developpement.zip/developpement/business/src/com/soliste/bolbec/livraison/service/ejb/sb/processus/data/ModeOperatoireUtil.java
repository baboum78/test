/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.List;

import aps.ModeOperatoire;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.model.ModeOperatoireDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * </TABLE><BR>
 */

/**
 * Classe d'aide permettant de retrouver le mode op�ratoire associ� � une t�che
 * et une cause �v�nement.
 * 
 * @author rgvs7490
 */
public class ModeOperatoireUtil {

	public static final String PAR_DEFAUT = "ParDefaut";

	private ModeOperatoireUtil() {
	}

	/**
	 * 
	 * @param modeOpName
	 * @param causeEvtId
	 * @param versionArtemis
	 * @return
	 */
	public static String getUrlModeOperatoire(String modeOpName, String causeEvtId, String versionArtemis) {
		ModeOperatoireDTO modeOp = null;
		String url = null;
		try {
			List<ModeOperatoireDTO> modesOp = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ModeOperatoireDTO.class, new Comparaison(ModeOperatoire.FIELD_MOD_OPERATOIRE, Constantes.OPERATOR_EQUAL, modeOpName),
					new Comparaison(ModeOperatoire.SLINK_A_CAUSE_EVENEMENT, Constantes.OPERATOR_EQUAL, causeEvtId), new Comparaison(ModeOperatoire.FIELD_VERSION, Constantes.OPERATOR_EQUAL, versionArtemis));
			if (modesOp.isEmpty()) {
				modesOp = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ModeOperatoireDTO.class, new Comparaison(ModeOperatoire.FIELD_MOD_OPERATOIRE, Constantes.OPERATOR_EQUAL, modeOpName),
						new Comparaison(ModeOperatoire.FIELD_VERSION, Constantes.OPERATOR_EQUAL, versionArtemis));
			}
			if (modesOp.isEmpty()) {
				modesOp = ServiceManager.getInstance().getReferenceSpaceManager().listInReferenceSpace(ModeOperatoireDTO.class, new Comparaison(ModeOperatoire.FIELD_MOD_OPERATOIRE, Constantes.OPERATOR_EQUAL, PAR_DEFAUT),
						new Comparaison(ModeOperatoire.FIELD_VERSION, Constantes.OPERATOR_EQUAL, versionArtemis));
			}
			if (!modesOp.isEmpty()) {
				modeOp = CollectionUtils.getFirstOrNull(modesOp);
			}
		} catch (Exception e) {
			// Probl�me de param�trage de la table MODE OPERATOIRE
		} finally {
			// on tente d'attribuer une url par d�faut
			// m�me en cas d'exception
			if (modeOp != null) {
				url = modeOp.getUrl();
			} else {
				url = "http://intranoo.soliste.fr/intranoo-ie.html";
			}
		}
		return url;
	}
}
