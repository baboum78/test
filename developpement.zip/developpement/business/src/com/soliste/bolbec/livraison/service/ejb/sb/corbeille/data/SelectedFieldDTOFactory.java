/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

/**
 * Interface pour factory pour SelectedFieldDTO
 * 
 * @author gdzd8490
 * 
 */
public interface SelectedFieldDTOFactory {

	/**
	 * Cr�er un filtre pour r�cup�rer les donn�es du corbeille info d'id
	 * <code>id</code>
	 * 
	 * @param id
	 * @return un filtre pour r�cup�rer les donn�es du corbeille info d'id
	 * <code>id</code>
	 */
	public SelectedFieldDTO createSelectedField(String id);

}
