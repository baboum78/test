/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import com.soliste.aps.workflow.WfDataFilter;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;

/**
 * Facade pour les filtres corbeille workflow
 * 
 * @author gdzd8490
 * 
 */
public class WfFiltreDTO extends FiltreDTO {

	private WfDataFilter filter;

	/**
	 * Constructeur
	 * 
	 * @param filter
	 */
	public WfFiltreDTO(WfDataFilter filter) {
		this.filter = filter;
	}

	/**
	 * Renvoie le filtre workflow
	 * 
	 * @return le filtre workflow
	 */
	public WfDataFilter getFilter() {
		return filter;
	}

}
