package com.soliste.bolbec.livraison.api.util.autorisation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Annotation permettant de g�rer les annotation
 * 
 * @author bperrard
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>29/10/2015</TD><TD>BPE</TD><TD>EV-000353 : Mise en place archi Rest de Base</TD></TR>
 * </TABLE>
 */
@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.METHOD })
public @interface Habilitation {
	/**
	 * La liste des habilitations n�cessaires
	 */
	public String[]value();
}
