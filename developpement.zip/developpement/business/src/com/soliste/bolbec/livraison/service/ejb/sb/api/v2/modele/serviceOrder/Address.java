package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

/**
 * Modele Ressource Address
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/10/2016</TD><TD>JDE</TD><TD>Cr�ation de la ressource Address</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * <TR><TD>20/06/2018</TD><TD>MBE</TD><TD>QC-000980 : Intrants FTTH</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "address")
public class Address {

	private String id;
	private String streetName;
	private String streetNumber;
	private String streetLetter;
	private String buildingName;
	private String streetType;
	private String floor;
	private String logo;
	private String streetCode;
	private String set;
	private String staircaseNumber;
	private String door;
	private String cityCode;
	private String postalCode;
	private String cityName;
	private String buildingId;
	private String opticalPlugId;
	private String opticalPlugAlreadyInstalled;
	private String buildingOperator;

	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the streetName
	 */
	public String getStreetName() {
		return streetName;
	}

	/**
	 * @param streetName the streetName to set
	 */
	public void setStreetName(String streetName) {
		this.streetName = streetName;
	}

	/**
	 * @return the streetNumber
	 */
	public String getStreetNumber() {
		return streetNumber;
	}

	/**
	 * @param streetNumber the streetNumber to set
	 */
	public void setStreetNumber(String streetNumber) {
		this.streetNumber = streetNumber;
	}

	/**
	 * @return the streetLetter
	 */
	public String getStreetLetter() {
		return streetLetter;
	}

	/**
	 * @param streetLetter the streetLetter to set
	 */
	public void setStreetLetter(String streetLetter) {
		this.streetLetter = streetLetter;
	}

	/**
	 * @return the buildingName
	 */
	public String getBuildingName() {
		return buildingName;
	}

	/**
	 * @param buildingName the buildingName to set
	 */
	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	/**
	 * @return the streetType
	 */
	public String getStreetType() {
		return streetType;
	}

	/**
	 * @param streetType the streetType to set
	 */
	public void setStreetType(String streetType) {
		this.streetType = streetType;
	}

	/**
	 * @return the floor
	 */
	public String getFloor() {
		return floor;
	}

	/**
	 * @param floor the floor to set
	 */
	public void setFloor(String floor) {
		this.floor = floor;
	}

	/**
	 * @return the logo
	 */
	public String getLogo() {
		return logo;
	}

	/**
	 * @param logo the logo to set
	 */
	public void setLogo(String logo) {
		this.logo = logo;
	}

	/**
	 * @return the streetCode
	 */
	public String getStreetCode() {
		return streetCode;
	}

	/**
	 * @param streetCode the streetCode to set
	 */
	public void setStreetCode(String streetCode) {
		this.streetCode = streetCode;
	}

	/**
	 * @return the set
	 */
	public String getSet() {
		return set;
	}

	/**
	 * @param set the set to set
	 */
	public void setSet(String set) {
		this.set = set;
	}

	/**
	 * @return the staircaseNumber
	 */
	public String getStaircaseNumber() {
		return staircaseNumber;
	}

	/**
	 * @param staircaseNumber the staircaseNumber to set
	 */
	public void setStaircaseNumber(String staircaseNumber) {
		this.staircaseNumber = staircaseNumber;
	}

	/**
	 * @return the door
	 */
	public String getDoor() {
		return door;
	}

	/**
	 * @param door the door to set
	 */
	public void setDoor(String door) {
		this.door = door;
	}

	/**
	 * @return the cityCode
	 */
	public String getCityCode() {
		return cityCode;
	}

	/**
	 * @param cityCode the cityCode to set
	 */
	public void setCityCode(String cityCode) {
		this.cityCode = cityCode;
	}

	/**
	 * @return the postalCode
	 */
	public String getPostalCode() {
		return postalCode;
	}

	/**
	 * @param postalCode the postalCode to set
	 */
	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}

	/**
	 * @return the cityName
	 */
	public String getCityName() {
		return cityName;
	}

	/**
	 * @param cityName the cityName to set
	 */
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	/**
	 * @return the buildingId
	 */
	public String getBuildingId() {
		return buildingId;
	}

	/**
	 * @param buildingId the buildingId to set
	 */
	public void setBuildingId(String buildingId) {
		this.buildingId = buildingId;
	}

	/**
	 * @return the opticalPlugId
	 */
	public String getOpticalPlugId() {
		return opticalPlugId;
	}

	/**
	 * @param opticalPlugId the opticalPlugId to set
	 */
	public void setOpticalPlugId(String opticalPlugId) {
		this.opticalPlugId = opticalPlugId;
	}

	/**
	 * @return the opticalPlugAlreadyInstalled
	 */
	public String getOpticalPlugAlreadyInstalled() {
		return opticalPlugAlreadyInstalled;
	}

	/**
	 * @param opticalPlugAlreadyInstalled the opticalPlugAlreadyInstalled to set
	 */
	public void setOpticalPlugAlreadyInstalled(String opticalPlugAlreadyInstalled) {
		this.opticalPlugAlreadyInstalled = opticalPlugAlreadyInstalled;
	}

	/**
	 * @return the buildingOperator
	 */
	public String getBuildingOperator() {
		return buildingOperator;
	}

	/**
	 * @param buildingOperator the buildingOperator to set
	 */
	public void setBuildingOperator(String buildingOperator) {
		this.buildingOperator = buildingOperator;
	}

}
