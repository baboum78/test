/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import aps.CasMetierConstantes;
import aps.EtatLigneCdeConstantes;
import aps.EtatProcessusConstantes;
import aps.JalonConstantes;
import aps.ProcessusTypeConstantes;
import aps.StatutCommandeConstantes;
import aps.SystemeExterneConstantes;

import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.CauseEvenementUtil;
import com.soliste.bolbec.livraison.service.model.CasMetierDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.stepauto.traitements.IInterventionManager;
import com.soliste.bolbec.livraison.service.util.NSDPlusUtil;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>09/08/2010</TD><TD>YTR</TD><TD>Refactor generation manager</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>13/12/2010</TD><TD>LBA</TD><TD>Refactoring CAST : r�duction complexit� cyclomatique</TD></TR>
 * <TR><TD>13/01/2011</TD><TD>LBA</TD><TD>EV-000089: NSD+ Ajout bouton abandon provisoire</TD></TR>
 * <TR><TD>13/01/2011</TD><TD>LBA</TD><TD>EV-000089 - DEFECT 150: NSD+ Correction sur le filtrage des causes abandon</TD></TR>
 * <TR><TD>15/02/2011</TD><TD>GPE</TD><TD>EV-000089: Avenant6 �volution de la gestion du bouton provisoire</TD></TR>
 * <TR><TD>06/05/2011</TD><TD>BPE</TD><TD>CAST : Correction anciens refactoring</TD></TR>
 * <TR><TD>12/07/2013</TD><TD>JLA</TD><TD>REFACTORING : suppression de la conditon processus &lt; 6200</TD></TR>
 * <TR><TD>02/05/2017</TD><TD>SDO</TD><TD>EV413 - Bouton stopper : r�gulariser sur les commandes internes</TD></TR>
 * </TABLE>
 * Classe avec une m�thode utilitaire concernant les actions autoris�es pour un processus.
 */
public class ActionsAutoriseesUtil {

	/**
	 * Retourne les actions autoris�es pour un processus donn�.
	 * 
	 * @param papaProcessus
	 * @param systemeExterneId
	 * @return ProcessusActionsAutorisees
	 */
	public static ProcessusActionsAutorisees getProcessusActionsAutorisees(ProcessusDTO papaProcessus, String systemeExterneId) {
		String etatProcessusId = papaProcessus.getEtatProcessus().getId();

		CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
		IInterventionManager INTERVENTION_MANAGER = ServiceManager.getInstance().getInterventionManager();

		// on ne d�termine s'il existe une cause d'abandon autoris�e que si c'est vraiment n�cessaire
		Set<String> causeAbandonAutoriseesIds = null;
		boolean complet = false;
		boolean abandonnable = false;
		boolean abandonnablePartiellement = false;
		boolean abandonnableProvisoirement = false;
		boolean suspendable = false;
		boolean retablissable = false;
		boolean stoppable = false;
		boolean regularisable = false;

		// R�cup�ration de la commande
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(papaProcessus.getId());

		// R�cup�ration de l'�tat de la premi�re ligne de commande
		String etatPremiereLigneCde = null;
		LigneCommandeDTO firstLigneCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessusAndUneSeule(papaProcessus.getId());
		if (firstLigneCde != null && firstLigneCde.getEtatLigneCde() != null) {
			etatPremiereLigneCde = firstLigneCde.getEtatLigneCde().getId();
		}

		// R�cup�ration de la version de processus workflow et de la valeur
		// constante du processusType du papa processus
		String idProcessusType = papaProcessus.getProcessusType().getId();
		ProcessusTypeDTO processusType = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, idProcessusType);
		String processusTypeValConst = processusType.getValeurConstante();

		// RG2 Contr�le du niveau d'avancement pour affichage actif des boutons
		if (EtatProcessusConstantes.EN_COURS.equals(etatProcessusId)) {

			if (commande != null && StatutCommandeConstantes.MIXTE.equals(commande.getStatutCommande().getId())) {
				if (!EtatLigneCdeConstantes.ECREG.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.ECANN.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.TERM.equals(etatPremiereLigneCde)
						&& !EtatLigneCdeConstantes.ANN.equals(etatPremiereLigneCde)) {
					// Positionner le libell� du bouton Abandonner � "Abd Complet"
					// TRT Filtrage des Causes Abandon Mixte
					causeAbandonAutoriseesIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandonMixte(ConstantesTraduction.ABD_COMPLET, papaProcessus.getId(), systemeExterneId, null);
					if (causeAbandonAutoriseesIds != null) {
						abandonnable = !causeAbandonAutoriseesIds.isEmpty();
					}
					causeAbandonAutoriseesIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandonMixte(ConstantesTraduction.ABD_PARTIEL, papaProcessus.getId(), systemeExterneId, null);
					if (causeAbandonAutoriseesIds != null) {
						abandonnablePartiellement = !causeAbandonAutoriseesIds.isEmpty();
					}
				}
				complet = true;
			} else {
				if (!EtatLigneCdeConstantes.ECREG.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.ECANN.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.TERM.equals(etatPremiereLigneCde)
						&& !EtatLigneCdeConstantes.ANN.equals(etatPremiereLigneCde)) {
					// Positionner le libell� du bouton Abandonner � "Abandonner"
					// TRT Filtrage des Causes Abandon
					String papaProcessusId = papaProcessus.getId();
					causeAbandonAutoriseesIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandon(papaProcessus.getId(), systemeExterneId, null);
					if (causeAbandonAutoriseesIds != null) {
						abandonnable = !causeAbandonAutoriseesIds.isEmpty();
						abandonnableProvisoirement = abandonnable && NSDPlusUtil.isJalonAffectationNonDepasse(papaProcessusId);
					}
				}
				complet = false;
				retablissable = false;
			}

			if (ProcessusTypeConstantes.LIVRAISONPMC_VALEUR_CONSTANTE.equals(processusTypeValConst)) {
				regularisable = false;
			} else {

				// La commande est-elle une commande PMC ?
				boolean isPMC = estCommandePMC(commande);

				regularisable = estCommandeRegularisable(etatPremiereLigneCde, processusTypeValConst, isPMC, commande);
			}
		} else if (EtatProcessusConstantes.SUSP.equals(etatProcessusId)) {
			// XPM ne sait pas abandonner un processus suspendu
			retablissable = true;
		}

		// Si la commande est une commande interne - SystemeExterne = 49W
		if (commande != null) {
			SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
			if (se != null && SystemeExterneConstantes.NUM_49W_VALEUR_CONSTANTE.equals(se.getValeurConstante())) {
				stoppable = true;
			}
		}

		// Si la commande est une commande vente FTTH sans intervention - SystemeExterne = G10_GRAFIC
		if (commande != null) {
			SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
			CasMetierDTO cas = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CasMetierDTO.class, commande.getCasMetier().getId());

			List<LigneCommandeDTO> listeLC = COMMANDE_MANAGER.findLigneCommandeByCommande(commande.getId());
			LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(listeLC);
			if ((premiereLC != null) && JalonConstantes.J_MES.equals(premiereLC.getJalon().getId()) && se != null && SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(se.getValeurConstante()) && CasMetierConstantes.VENTE_FTTH.equals(cas.getId())) {
				final Collection<InterventionDTO> listeIntervention = INTERVENTION_MANAGER.getInterventionsByIdCommande(commande.getId());
				if (listeIntervention.isEmpty()) {
					abandonnable = true;
				}
			}
		}

		// RG2Ter r�gle d'affichage du bouton Stopper d�pendant du comportement
		// des boutons d'abandon
		if (EtatProcessusConstantes.EN_COURS.equals(etatProcessusId) && !abandonnable && !abandonnablePartiellement && !EtatLigneCdeConstantes.ECREG.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.ECANN.equals(etatPremiereLigneCde)
				&& !EtatLigneCdeConstantes.TERM.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.ANN.equals(etatPremiereLigneCde)) {
			stoppable = true;
		}

		return new ProcessusActionsAutorisees(complet, abandonnable, abandonnablePartiellement, abandonnableProvisoirement, suspendable, retablissable, stoppable, regularisable);
	}

	/**
	 * @param regularisable
	 * @param etatPremiereLigneCde
	 * @param versionWorkflow
	 * @param processusTypeValConst
	 * @param isPMC
	 * @return true, si commande regularisable, false sinon
	 * 
	 * /**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>06/05/2011</TD><TD>BPE</TD><TD>Cast : correction sur un ancien refactoring</TD></TR>
	 * </TABLE><BR>
	 */
	protected static boolean estCommandeRegularisable(String etatPremiereLigneCde, String processusTypeValConst, boolean isPMC, CommandeDTO commande) {

		// Si la commande est de type INTERNE - SystemeExterne = 49W
		if (commande != null) {
			SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
			if (se != null && SystemeExterneConstantes.NUM_49W_VALEUR_CONSTANTE.equals(se.getValeurConstante())) {
				return true;
			}
		}

		if (ProcessusTypeConstantes.COMPLETUDE_VALEUR_CONSTANTE.equals(processusTypeValConst) && isPMC) {
			return false;
		}
		if (!EtatLigneCdeConstantes.ECREG.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.ECANN.equals(etatPremiereLigneCde) && !EtatLigneCdeConstantes.TERM.equals(etatPremiereLigneCde)
				&& !EtatLigneCdeConstantes.ANN.equals(etatPremiereLigneCde)) {
			return true;
		}
		return false;
	}

	/**
	 * @param commande
	 * @return
	 */
	protected static boolean estCommandePMC(CommandeDTO commande) {
		boolean isPMC = false;
		if (commande != null) {
			SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
			if (se != null && SystemeExterneConstantes.NUM_49W_VALEUR_CONSTANTE.equals(se.getValeurConstante())) {
				isPMC = true;
			}
		}
		return isPMC;
	}
}
