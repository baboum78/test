package com.soliste.bolbec.livraison.service.ejb.sb.customerorder.traitements;

import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.model.TraductionDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.sw.custorder.ConstantesDeliverCustomerOrder;
import com.orange.bolbec.customerOrderIOSW.services.DeliverCustomerOrderFault;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.AppointmentType;
import com.orange.bolbec.customerOrderIOSW.types.deliverCustomerOrder.SiteType;

import aps.CasMetierConstantes;
import aps.EtatInterventionConstantes;
import aps.ResponsabiliteConstantes;
import aps.SystemeExterneConstantes;
import aps.TypeOpProgrammeeConstantes;
import aps.model.TraductionAttribute;
import bolbec.injection.xml.generated.Commande;
import bolbec.injection.xml.generated.Intervention;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.OperationProgrammee;

/**
 * Classe sp�cifique eRdv du traitement des IC deliverCustomerOrder
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/06/2023</TD><TD>LHZ</TD><TD>US-5726 Injection des commandes eRDV au format DCO</TD></TR>
 * </TABLE>
 */
public class ErdvTraitement extends CustomerOrderTraitement {
	public static final String QT = "QT : ";
	/**
	 * The Constant CLASS_NAME.
	 */
	private final static String CLASS_NAME = ErdvTraitement.class.getName();

	/**
	 * Constructeur
	 */
	public ErdvTraitement(String emetteur) {
		EMETTEUR = emetteur;
	}

	@Override
	protected void controleBooleans() {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected void verifLigneCommande() {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected Collection<TraductionDTO> recupereFonctionsOblig() {
		return serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionDTO.class, new Comparaison(TraductionAttribute.FIELD_CLE, Constantes.OPERATOR_EQUAL, ConstantesTraduction.FUNCTION_IC_ERDV_OBLIG),
					new Comparaison(TraductionAttribute.FIELD_VALEUR_EXTERNE, Constantes.OPERATOR_EQUAL, com.soliste.bolbec.commun.service.Constantes.CST_OUI), new Comparaison(TraductionAttribute.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_48W));
	}

	@Override
	protected void controlesSpecifiques() {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected void verifPrestaClipEtDebit(List<Map<String, String>> fonctionsLcTraduites) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected String determineCategorieClientContractant() throws DeliverCustomerOrderFault {
		final String method = "determineCategorieClientContractant";
		final String label = recupererLabelLocalMarketSegmentClientContractant();
		loggerManager.fine(CLASS_NAME, method, "R�cup�ration du LocalMarketSegmentLabel : " + label);
		if (StringUtils.isBlank(label)) {
			String casMetier = getDeliverCustomerOrderData().getCasMetier();
			if (CasMetierConstantes.CR_FTTH.equals(casMetier) || CasMetierConstantes.SU_FTTH.equals(casMetier) || CasMetierConstantes.MO_FTTH.equals(casMetier)) {
				throw getDeliverCustomerOrderData().getDeliverCustomerOrderHelper().genererAnomalieChampObligatoireAbsent("Local_MarketSegment", customerOrder.getCustomerOrderID());
			}
			return null;
		}
		final String traduction = serviceManager.getTraductionManager().getTraductionInterfVersArtemis(EMETTEUR, ConstantesTraduction.SEGMENT_MARCHE, label);
		loggerManager.fine(CLASS_NAME, method, "LocalMarketSegmentLabels traduit : " + traduction);
		if (StringUtils.isBlank(traduction)) {
			return label;
		}
		return traduction;
	}

	@Override
	protected void valorisationChampDynamiqueOsirisOpPonctuelleOrigine(Collection<LigneCommandeType> lignesDeCommande) {
		for (LigneCommandeType ligneCommande : lignesDeCommande) {
			ligneCommande.addParametreLivraison(createParametre(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OSIRIS_OPPONCTORIG, ligneCommande.getRefOperationPonctuelle()));
		}
	}

	@Override
	protected void fournirInterventionEtParametresAssocies(Commande commande, Collection<LigneCommandeType> lignesDeCommande) {
		LigneCommandeType ligneCommandeType = CollectionUtils.getFirstOrNull(lignesDeCommande);
		if (ligneCommandeType != null) {
			AppointmentType appointment = customerOrder.getCustomerOrderItem().get(0).getAppointment().get(0);
			Intervention intervention = new Intervention();
			intervention.setIdIntervention(serviceManager.getGeneratorManager().generateKey());
			intervention.setRefRDV(appointment.getAppointmentID());
			intervention.setEtatIntervention(EtatInterventionConstantes.RESERV);
			intervention.setResponsabilite(ResponsabiliteConstantes.INITIATIVE_CLIENT);
			if (appointment.getAppointmentDate() != null) {
				Date dateReservation = appointment.getAppointmentDate().getTime();
				intervention.setDateReservation(DateUtils.format(dateReservation, ConstantesDeliverCustomerOrder.FORMAT_DATE_HEURE));
			}

			String observations = getObservations(appointment);
			if (StringUtils.isNotBlank(observations)) {
				intervention.setObservations(observations);
			}

			commande.addIntervention(intervention);
			OperationProgrammee operationProgrammee = new OperationProgrammee();
			operationProgrammee.setIdIntervention(intervention.getIdIntervention());
			operationProgrammee.setTypeOp(TypeOpProgrammeeConstantes.CLIENT);
			ligneCommandeType.addOperationProgrammee(operationProgrammee);
		}
	}

	@Override
	protected void valorisationParametresLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected void valorisationContexteLigneCommande(Collection<LigneCommandeType> lignesCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	@Override
	protected void valorisationChampsDynamiquesLC(Collection<LigneCommandeType> lignesCommande) {
		/**
		 * Rien � faire pour ce partenaire
		 */
	}

	/**
	 * Le champ observation est valoris� via la concat�nation de plusieurs �l�ments
	 * Si le 1er �l�ment est renseign� (Appointment.observ),
	 * le s�parateur a utiliser, est au format : � ; � (espace � point-virgule � espace),
	 *
	 * Pour les �l�ments suivants (TechnicalQuestions),
	 * ils sont s�par�s entre eux si n�cessaire par un s�parateur au format : �; � (point-virgule � espace)
	 * Et chaque QT: � <TechnicalQuestions.question>=<TechnicalQuestions.answer �
	 *
	 * @param appointment
	 * @return
	 */
	private String getObservations(AppointmentType appointment) {
		String observations = null;
		if (StringUtils.isNotBlank(appointment.getObserv())) {
			observations = appointment.getObserv();
		}

		String questionTechniques = QT;
		for (SiteType.TechnicalQuestions technicalQuestion: customerOrder.getCouldBeRelatedToTemporarySite().getSite().get(0).getTechnicalQuestions()) {
			questionTechniques = questionTechniques + technicalQuestion.getQuestion() + "=" + technicalQuestion.getAnswer() + "; ";
		}

		if (!QT.equals(questionTechniques)) {
			questionTechniques = questionTechniques.substring(0, questionTechniques.length()-2);
			observations = observations + " ; " + questionTechniques;
		}
		return observations;
	}

}
