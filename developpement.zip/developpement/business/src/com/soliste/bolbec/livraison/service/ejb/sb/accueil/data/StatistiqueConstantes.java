/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : StatistiqueConstantes.java
 *   Revision  : 06_00#1
 *   DateRev   : 28-FEV-2006 12:00:51
 *   Chemin    : ARTE/developpement/ihm/src.ejb/bolbec/ihm/livraison/accueil/data/StatistiqueConstantes.java
 * --------------------------------------------
 *   Historique  : 
 *    Revision 06_00#1 (CREE)
 *      Created:  28-FEV-2006 12:00:51 RGVS7490
 *        creation
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.accueil.data;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Classe contenant les cl�s des statistiques
 * 
 * @author rgvs7490
 */
public class StatistiqueConstantes {

	public static final String TOTAL_DR_NAME = "Total";

	public static final String NOMBRE_COMMANDES_CREEES = "NbCmdCrees";
	public static final String NOMBRE_COMMANDES_SOLDEES = "NbCmdSoldees";
	public static final String NOMBRE_COMMANDES_SOLDEES_SANS_AVP = "NbCmdSoldeesSansAVP";
	public static final String NOMBRE_COMMANDES_ANNULEES = "NbCmdAnnulees";
	public static final String NOMBRE_COMMANDES_EN_TACHE_MANUELLE = "NbCmdTachMan";
	public static final String NOMBRE_COMMANDES_EN_AVP = "NbCmdAVP";
	public static final String NOMBRE_TACHES_AUTO_EN_COURS = "NbTachesAutoExec";

	public static final Set<String> STATISTIQUES_ACCUEIL_CLES;

	static {
		Set<String> set = new HashSet<String>();
		set.add(NOMBRE_COMMANDES_CREEES);
		set.add(NOMBRE_COMMANDES_SOLDEES);
		set.add(NOMBRE_COMMANDES_SOLDEES_SANS_AVP);
		set.add(NOMBRE_COMMANDES_ANNULEES);
		set.add(NOMBRE_COMMANDES_EN_TACHE_MANUELLE);
		set.add(NOMBRE_COMMANDES_EN_AVP);
		set.add(NOMBRE_TACHES_AUTO_EN_COURS);
		STATISTIQUES_ACCUEIL_CLES = Collections.unmodifiableSet(set);
	}

	private StatistiqueConstantes() {
	}
}
