/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : EFBConstantes.java
 *   Revision  : 06_00#1
 *   DateRev   : 14-NOV-2005 14:22:09
 *   Chemin    : ARTE/developpement/uc_adaptateurs/src.ejb/bolbec/adaptateur/efb/EFBConstantes.java
 * --------------------------------------------
 *   Historique  : 
 *    Revision 06_00#1 (CREE)
 *      Created:  14-NOV-2005 14:22:10 UDGE5525
 *        Cr ation
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>05/05/2010</TD><TD>DBA</TD><TD>EV-000060: Report</TD></TR>
 * <TR><TD>06/08/2010</TD><TD>DBA</TD><TD>EV-000053: Fin dev Adaptateur EFB (Gestion des AID)</TD></TR>
 * <TR><TD>21/04/2011</TD><TD>JCH</TD><TD>EV-000077: ajout de SEGMA</TD></TR>
 * <TR><TD>08/06/2011</TD><TD>GPA</TD><TD>EV-000136: Ajout des constantes MIG_VOIX_ENTREP</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>19/09/2011</TD><TD>GPA</TD><TD>EV-000140: Ajout des constantes PUB_SUIVICDE</TD></TR>
 * <TR><TD>03/10/2012</TD><TD>GPA</TD><TD>EV-000190: Ajout de la constante CODE_STATUT_OP_COMMANDE</TD></TR>
 * <TR><TD>04/10/2012</TD><TD>FTE</TD><TD>EV-000190: Ajout de la constante VDSLPRO</TD></TR>
 * <TR><TD>21/05/2013</TD><TD>AZA</TD><TD>EV-000236-:Ajout constante RADUCTION_ANO_RESIL_FTTH </TD></TR>
 * <TR><TD>22/07/2013</TD><TD>EBA</TD><TD>G8R2C2 EV-000238_01 -: Modification retour anomalie </TD></TR>
 * <TR><TD>14/05/2014</TD><TD>VDE</TD><TD>EV-000278 : Mise en quarantaine des ND</TD></TR>
 * <TR><TD>18/06/2014</TD><TD>GCL</TD><TD>G8R2C5 EV-000302 : PLP Fibre </TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000304 : Fluidification ADSL vers Fibre </TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000298 - R�siliation acc�s FTTH en cas de porta sortante </TD></TR>
 * <TR><TD>31/10/2014</TD><TD>KRA</TD><TD>EV-000302 PLP Fibre</TD></TR>
 * <TR><TD>02/01/2015</TD><TD>GCL</TD><TD>EV-000302_04 : PLP Fibre</TD></TR>
 * <TR><TD>08/12/2015</TD><TD>JDE</TD><TD>EV-000348 : Net commande unique</TD></TR>
 * <TR><TD>11/05/2016</TD><TD>JDE</TD><TD>EV-000348_03 : Net commande unique : Ecrasement cas m�tier</TD></TR>
 * <TR><TD>09/02/2018</TD><TD>JDE</TD><TD>QC-000943 : Avancement MESC FT<TD></TR>
 * <TR><TD>30/07/2019</TD><TD>ynouri</TD><TD>EV-000313 : CLAF - Transmission des donn�es OI et PM dans la commande EFB<TD></TR>
 * </TABLE>
 * 
 * @author SICOR LYON
 * 
 * Classe EFBConstantes
 */
public interface EFBConstantes {

	String MISE_A_DISPO = "MiseADispoAuPlusTard";
	String LIVRAISON_PREVUE = "LivraisonPrevue";

	String KEY_CODE_ACTION = "CODE_ACTION";

	// Param�tres de livraison Ligne de Commande
	String REF_OFFRE_GROUPEE_EFB = "REF_OFFRE_GROUPEE_EFB";
	String OSIRIS_ID_LCDE_ORIGINE = "OsirisIdLdcOrigine";
	String OSIRIS_OP_PONCT_ORIGINE = "OsirisOpPonctuelleOrigine";
	String ID_RES_REUTILISABLE = "IdRessourceReutilisable";
	String ND_FINAL_CHOISI = "NDFinalChoisi";
	String ND_ANCIENNE_ADRESSE = "NDAncienneAdresse";
	String CATRAC_CRISTAL_EFB = "CATRACCristalEFB";
	String EDSI = "EDSI";
	String TYPE_DEBIT_CMD = "TypeDebitCmd";
	String MOTIF_COMMANDE = "MotifCommande";
	String MOTIF_SUPP = "MotifSuppression";

	String SYNCHRO_MIXTE = "SynchroMixte";
	String CHGT_ND = "CHGT_ND";
	String RETOUR_FT = "RetourFT";
	String TYPE_PORTA_SIP_FTTH = "TypePortaSipFTTH";
	// Param�tres Produit Service et EPC
	String TECHNOLOGIE = "TECHNOLOGIE";
	String INTERFACE = "INTERFACE";
	String DEBIT = "DEBIT";
	String OSIRIS_ID_OFFRE_ORIGINE = "OsirisIdOffreOrigine";
	String ABOBD = "ABOBD";
	String SERVICEBD = "SERVICEBD";
	String DEMGT = "DEMGT";
	String STATUT_OP_CDE = "REAHD";
	String STATUT_OP_LC_VALIDE = "VALIDE";
	String STATUT_OP_LC_INCONNU = "INCONNU";
	String STATUT_OP_LC_A_TRAITER = "A_TRAITER";

	String FORMAT_DATE = "dd/MM/yyyy";
	String FORMAT_DATE_AC = "yyyy-MM-dd";
	String FORMAT_DATE_HEURE = "dd/MM/yyyy HH:mm:ss";
	String FORMAT_DATE_HEURE_EFB = "yyyy-MM-dd'T'HH:mm:ss'Z'";

	String DEM = "DEM";

	// cl�s de la hashmap permettant d'envoyer un CR EFB de statut SI et de type
	// Non Enregistr� (NENHD).
	String CLE_VERSION_MODELE_LPA = "VERSION_MODELE_LPA";
	String CLE_REF_COMMANDE = "REF_COMMANDE";
	String CLE_CODE_CPLT_STATUT_OP = "CODE_CPLT_STATUT_OP";
	String CLE_LISTE_REF_LIGNE_CDE = "LISTE_REF_LIGNE_CDE";
	String CLE_LIGNE_CDE_ERREUR = "LIGNE_CDE_ERREUR";
	String CLE_SYNCHRO_MIXTE = "SYNCHRO_MIXTE";

	// EV-000060 - Migration Fibre H323 vers Fibre SIP
	String PORTA_FIBRE_FIBRE = "PORTA_FIBRE_FIBRE";

	// EV-000053: Nouvelle cl� pour la map parametre
	String AID = "AID";

	// EV-000077 -
	String SEGMA = "SEGMA";

	// EV-000136: Migration Opim Opom
	String NO_MIG_VOIX_ENTREP = "NO_MIG_VOIX_ENTREP";
	String MIG_VOIX_ENTREP = "MIG_VOIX_ENTREP";

	String ID_CMD_ORIGINE_BD = "IdCmdOrigineBD";
	// EV-000140: Remonte AVP SuiviCommande
	String PUB_SUIVICDE = "PUB_SUIVICDE";
	String PUB_SUIVICDE_CR = "PUB_SUIVICDE_CR_";
	String PUB_SUIVICDE_MO = "PUB_SUIVICDE_MO_";
	String PUB_SUIVICDE_SU = "PUB_SUIVICDE_SU_";
	String REASSIGNATION_AVP = "REASSIGNATION_AVP";

	// EV-000182
	String EPC_ETUDE_TYPE = "EPC_ETUDE_TYPE";
	String ETUDE_TYPE_SEPARATEUR = " | ";

	String CODE_STATUT_OP_COMMANDE = "CodeStatutOpCommande";
	String VDSLPRO = "VDSLPRO";

	String FORMAT_NON_PEC_EFB = "FORMAT_NON_PEC_EFB";

	// EV-278
	String CODE_ACTION_ORIGINE = "CODE_ACTION_ORIGINE";
	String FAMILLE_OFFRE_PORTA = "FAMILLE_OFFRE_PORTA";
	String VALEUR_FONCTION_TYPEND = "VALEUR_FONCTION_TYPEND";
	String RETRADUCTION_OFFRE = "RETRADUCTION_OFFRE";

	// EV-000302
	String DTIO = "DTIO";
	String PTOId = "PTOId";
	String ID_SISSI = "IdSISSI";
	String ID_SISSI_BAT = "IdSISSIBat";
	String ID_SISSI_ESC = "IdSISSIEsc";
	String ID_SISSI_ET = "IdSISSIEt";
	String IMB = "IMB";
	String PLP_SANS_PT_OID = "PLPSansPTOId";
	String ETAT_LIGNE = "EtatLigne";
	String DET_CAS_METIER_EFB = "DET_CAS_METIER_EFB";
	String CASMETIER_EFB = "CASMETIER_EFB";
	String CONTEXTE_PLP = "ContextePLP";

	// EV-304
	String ADSL_FIBRE = "ADSLFIBRE";

	// EV-313
	String BATIMENTOI = "BatimentOI";
	String ESCALIEROI = "EscalierOI";
	String ETAGEOI = "EtageOI";
	String REFERENCEPM = "ReferencePM";

	// EV-348
	String SOUHAITEE_CLIENT = "SouhaiteeClient";
	String DATE_DESIRE_RESIL_ANCIENNE_BL = "DateDesireResilAncienneBL";
	String TYPE_DEMGT = "TypeDemgt";
	String RES_REUTILISABLES_ID = "ResReutilisablesId";
	String ETAT_RES_REUTILISABLES_ID = "EtatResReutilisablesId";
	String REAACTNU = "REAACTNU";

	// EV-348_03
	String DET_CAS_METIER_EFB_INTERNET_FIBRE = "DET_CAS_METIER_EFB_INTERNET_FIBRE";

	// EV-442
	String DENUM = "DENUM";
	
	// US-2324
	String INTERFLIVR = "interfLivr";

	//US-5292
	String MESSAGE_ANOMALIE_FORMAT_INJECTION = "Anomalie format d'injection";

	//US-5863
	String VF_DEBIT_REPLI = "VFDebitRepli";
	String CLE_DEBIT = "Debit";
}
