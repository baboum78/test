package com.soliste.bolbec.livraison.api.util.autorisation;

import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.bolbec.commun.service.ConstantesAPI;
import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Impl�mentation de l'interface {@link AutorisationUtil}
 * 
 * @author bperrard
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>29/10/2015</TD><TD>BPE</TD><TD>EV-000353 : Mise en place archi Rest de Base</TD></TR>
 * </TABLE>
 *
 */
public class AutorisationUtilImpl implements AutorisationUtil {

	private final IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * @see AutorisationUtil#getCurrentAgentFromMessageContext(MessageContext)
	 */
	@Override
	public AgentDTO getCurrentAgentFromMessageContext(MessageContext messageContext) {

		final String agentName = CollectionUtils.getFirstOrNull(messageContext.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();

		if (StringUtils.isBlank(agentName)) {
			return null;
		}
		return serviceManager.getAgentManager().getCurrentAgent(agentName, StringUtils.lowerCase(Constantes.APPLICATION_TYPE));
	}

	/**
	 * @see AutorisationUtil#isHabilitated(Set, AgentDTO)
	 */
	@Override
	public boolean isHabilitated(Set<String> habilitationsSet, AgentDTO agent) {
		String habilitationKey;
		boolean habilite;
		for (Entry<String, Boolean> habilitationEntry : agent.getHabilitations().entrySet()) {
			habilite = habilitationEntry.getValue();
			// S'il n'est pas habilit�, on continue
			if (!habilite) {
				continue;
			}
			habilitationKey = habilitationEntry.getKey();
			if (habilitationsSet.contains(habilitationKey)) {
				return true;
			}
		}
		return false;
	}

}
