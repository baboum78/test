package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.gpc;

/**
 * Donn�es de la notification des interventions
 */
public class DonneesIntervention {

	private static final String POINT_VIRGULE = ";";
	private static final int NUM_VALEURS = 14;

	/**
	 * R�f�rence de l�intervention
	 */
	private String refInt;

	/**
	 * Num�ro de l�intervention
	 */
	private String numInt;

	/**
	 * Code de l'UI
	 */
	private String codeUI;

	/**
	 * Date de d�but (format DD/MM/AAAA)
	 */
	private String dateDebut;

	/**
	 * Heure de d�but (format HH:MM)
	 */
	private String heureDebut;

	/**
	 * Dur�e (format HHMM)
	 */
	private String duree;

	/**
	 * Code activit�
	 */
	private String activite;

	/**
	 * Code produit
	 */
	private String produit;

	/**
	 * �tat de l�intervention
	 */
	private String etat;

	/**
	 * ND ou num�ro de prestation CLIP
	 */
	private String ndOuPrestClip;

	/**
	 * Code rel�ve
	 */
	private String crInt;

	/**
	 * Code de la DR
	 */
	private String codeDR;

	/**
	 * Code centre
	 */
	private String centre;

	/**
	 * Code zone
	 */
	private String zone;

	/**
	 * Id Commande
	 */
	private String idCommande;

	public DonneesIntervention(String intervention) {
		// on met la limite � negative pour applier la r�gle tous les fois possibles (li� au souci du dernier donn�e facultativ,
		// si la derni�re donn�e est absent, avec le limit -1 on recup�re 14 valeurs (deni�re vide) et on peut mapper tous)
		String[] listValeurs = intervention.split(POINT_VIRGULE, -1);
		if (listValeurs.length >= NUM_VALEURS) {
			refInt = listValeurs [0];
			numInt = listValeurs [1];
			codeUI = listValeurs [2];
			dateDebut = listValeurs [3];
			heureDebut = listValeurs [4];
			duree = listValeurs [5];
			activite = listValeurs [6];
			produit = listValeurs [7];
			etat = listValeurs [8];
			ndOuPrestClip = listValeurs [9];
			crInt = listValeurs [10];
			codeDR = listValeurs [11];
			centre = listValeurs [12];
			zone = listValeurs [13];
		}
	}

	public String getRefInt() {
		return refInt;
	}

	public void setRefInt(String refInt) {
		this.refInt = refInt;
	}

	public String getNumInt() {
		return numInt;
	}

	public void setNumInt(String numInt) {
		this.numInt = numInt;
	}

	public String getCodeUI() {
		return codeUI;
	}

	public void setCodeUI(String codeUI) {
		this.codeUI = codeUI;
	}

	public String getDateDebut() {
		return dateDebut;
	}

	public void setDateDebut(String dateDebut) {
		this.dateDebut = dateDebut;
	}

	public String getHeureDebut() {
		return heureDebut;
	}

	public void setHeureDebut(String heureDebut) {
		this.heureDebut = heureDebut;
	}

	public String getDuree() {
		return duree;
	}

	public void setDuree(String duree) {
		this.duree = duree;
	}

	public String getActivite() {
		return activite;
	}

	public void setActivite(String activite) {
		this.activite = activite;
	}

	public String getProduit() {
		return produit;
	}

	public void setProduit(String produit) {
		this.produit = produit;
	}

	public String getEtat() {
		return etat;
	}

	public void setEtat(String etat) {
		this.etat = etat;
	}

	public String getNdOuPrestClip() {
		return ndOuPrestClip;
	}

	public void setNdOuPrestClip(String ndOuPrestClip) {
		this.ndOuPrestClip = ndOuPrestClip;
	}

	public String getCrInt() {
		return crInt;
	}

	public void setCrInt(String crInt) {
		this.crInt = crInt;
	}

	public String getCodeDR() {
		return codeDR;
	}

	public void setCodeDR(String codeDR) {
		this.codeDR = codeDR;
	}

	public String getCentre() {
		return centre;
	}

	public void setCentre(String centre) {
		this.centre = centre;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public String getIdCommande() {
		return idCommande;
	}

	public void setIdCommande(String idCommande) {
		this.idCommande = idCommande;
	}
}
