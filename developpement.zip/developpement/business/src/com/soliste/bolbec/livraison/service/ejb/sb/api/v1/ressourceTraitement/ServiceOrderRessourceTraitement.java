package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.Response;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.ConstantesAPI;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager;
import com.soliste.bolbec.livraison.service.ejb.sb.WfServices;
import com.soliste.bolbec.livraison.service.ejb.sb.api.utils.ServiceOrderUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCause;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.ServiceOrder;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.ServiceOrderStatus;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.ProcessusTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.AbandonnerProcessusException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.publication.INotificationGeneriqueManager;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Traitement des ressources ServiceOrder
 * 
 * @author mfayd
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/12/2015</TD><TD>MFA</TD><TD>Initialisation ServiceOrderRessourceTraitement</TD></TR>
 * <TR><TD>19/01/2016</TD><TD>KWE</TD><TD>Ajout ServiceOrderRessourceTraitement</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>API REST</TD></TR>
 * </TABLE>
 **/
public class ServiceOrderRessourceTraitement {
	private final CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
	private final ProcessusManager PROCESSUS_MANAGER = ServiceManager.getInstance().getProcessusManager();
	private final INotificationGeneriqueManager NOTIFICATION_GENERIQUE_MANAGER = ServiceManager.getInstance().getNotificationGeneriqueManager();
	private final WfServices WFSERVICES = ServiceManager.getInstance().getWfServices();
	protected final int STATUS_ACCEPTED = 202;

	/**
	 * NoteRessourceTraitement
	 */
	public ServiceOrderRessourceTraitement() {

	}

	/**
	 * getCommande
	 * Permet d'obtenir la commande en fonction de son id.
	 * 
	 * @param idCommande
	 * @param context
	 * @return
	 */
	public Response getCommande(String idCommande, @SuppressWarnings("unused") MessageContext context) {
		if (idCommande == null) {
			throw APIExceptionEnum.serviceorderidnull.createAPIException();
		}
		final CommandeDTO commande = COMMANDE_MANAGER.findCommandeById(idCommande);

		// Commande non trouv�e --> 404
		if (commande == null) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(idCommande);
		}

		ServiceOrder serviceOrder = new ServiceOrder();
		serviceOrder = ServiceOrderUtils.initialiserServiceOrderViaCommande(commande);

		return Response.ok(serviceOrder).build();

	}

	/**
	 * patchCommande
	 * Permet l'abandon de la commande.
	 * 
	 * @param idCommande
	 * @param serviceOrder
	 * @param context
	 * @return
	 */
	public Response abandonnerCommande(String idCommande, ServiceOrder serviceOrder, MessageContext context) {
		final CommandeDTO commande = COMMANDE_MANAGER.findCommandeById(idCommande);
		// Commande non trouv�e --> 404
		if (commande == null) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(idCommande);
		}

		final ServiceOrderStatus statusDemande = serviceOrder.getState();

		if (ServiceOrderStatus.unknown.equals(statusDemande)) {
			throw APIExceptionEnum.serviceorderbadstatus.createAPIException();
		}

		if (serviceOrder.getAbortEventCause() == null || !ServiceOrderStatus.aborted.equals(statusDemande)) {
			throw APIExceptionEnum.serviceorderabortmalformed.createAPIException();
		}

		ServiceOrderStatus statusCommandeActuelle = ServiceOrderUtils.determinerStatut(commande);
		if (statusCommandeActuelle != ServiceOrderStatus.inprogress) {
			throw APIExceptionEnum.serviceorderisnotinprogress.createAPIException(idCommande);
		}

		if (StringUtils.isBlank(serviceOrder.getAbortEventCause().getId())) {
			throw APIExceptionEnum.serviceordernotfoundeventcause.createAPIException(idCommande);
		}

		final ProcessusDTO processusDTO = PROCESSUS_MANAGER.findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(idCommande);
		if (processusDTO == null) {
			throw APIExceptionEnum.serviceorderandprocessnotlinked.createAPIException(idCommande);
		}

		List<EventCause> eventlst = new ArrayList<EventCause>();
		try {
			eventlst = ServiceOrderUtils.getCauseEvenementAutoriseesPourCloturer(processusDTO);
		} catch (DataException e) {
			throw APIExceptionEnum.serviceordernotfoundeventcause.createAPIException(idCommande);
		}

		if (!ServiceOrderUtils.estDansListeCausePossiblePourAbandon(eventlst, serviceOrder.getAbortEventCause())) {
			throw APIExceptionEnum.serviceordercausenotallowed.createAPIException(idCommande);
		}

		final String causeEvenementId = commande.getVersionArtemis() + Constantes.STRING_UNDERSCORE + serviceOrder.getAbortEventCause().getId();
		final String agentName = CollectionUtils.getFirstOrNull(context.getHttpHeaders().getRequestHeader(ConstantesAPI.HEADER_AGENT)).toUpperCase();
		final AgentDTO agent = ServiceManager.getInstance().getAgentManager().getCurrentAgent(agentName, StringUtils.lowerCase(Constantes.APPLICATION_TYPE));
		final WfUser wfU = WFSERVICES.getWfUser(agent);

		String info = "";
		if (serviceOrder.getAbortEventCause().getComment() != null) {
			info = serviceOrder.getAbortEventCause().getComment();
		}

		try {
			ProcessusTraitement.abandonnerProcessus(processusDTO.getId(), info, causeEvenementId, wfU, null, agent);
		} catch (AbandonnerProcessusException e1) {
			throw APIExceptionEnum.serviceorderabandonerror.createAPIException(idCommande);
		} finally {
			// US-678 Notification pour l'abandon
			NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A,NotificationGeneriqueConstantes.TYPE_ABAN,idCommande,agent.getId(),idCommande);
			NOTIFICATION_GENERIQUE_MANAGER.emettreNotification(ng);
		}

		return Response.status(STATUS_ACCEPTED).build();
	}

	/**
	 * getCauseEvenementsListe
	 * Permet d'obtenir les causes d'abandon de la commande en fonction de son id.
	 * 
	 * @param idCommande
	 * @param context
	 * @return
	 */
	public Response getCausesEvenementsByCommandeId(String idCommande, @SuppressWarnings("unused") MessageContext context) {

		TacheEnCoursDTO tacheEnCoursDTO = CollectionUtils.getFirstOrNull(PROCESSUS_MANAGER.findTacheEnCoursByCommande(idCommande));

		if (tacheEnCoursDTO == null) {
			throw APIExceptionEnum.serviceorderandtasknotlinked.createAPIException(idCommande);
		}

		ProcessusDTO process = PROCESSUS_MANAGER.findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(idCommande);
		if (process == null) {
			throw APIExceptionEnum.serviceorderandprocessnotlinked.createAPIException(idCommande);
		}

		List<EventCause> eventlst = new ArrayList<EventCause>();
		try {
			eventlst = ServiceOrderUtils.getCauseEvenementAutoriseesPourCloturer(process);
		} catch (DataException e) {
			throw APIExceptionEnum.serviceordernotfoundeventcause.createAPIException(idCommande);
		}

		if (eventlst.isEmpty()) {
			throw APIExceptionEnum.serviceordernotfoundeventcause.createAPIException(idCommande);
		}

		return Response.ok(eventlst).build();
	}

	/**
	 * Permet d'obtenir les commandes en fonction de l'id d'intervention de l'id externe.
	 * 
	 * @param appointmentId
	 * @param externalId
	 * @param context
	 * @return
	 */
	public Response getCommandes(String appointmentId, String externalId, @SuppressWarnings("unused") MessageContext context) {
		List<ServiceOrder> serviceOrderlst = new ArrayList<ServiceOrder>();
		if (appointmentId == null && externalId == null) {
			throw APIExceptionEnum.serviceorderappointmentidandexternalidnull.createAPIException();
		}
		// 1) cas intervention=null
		if (appointmentId == null) {
			List<CommandeDTO> commandeDTOs = COMMANDE_MANAGER.findCommandeListByRefExterne(externalId);
			// Commande non trouv�e --> 404
			if (commandeDTOs.isEmpty()) {
				throw APIExceptionEnum.serviceordernotfoundwithexternalid.createAPIException(externalId);
			}
			for (CommandeDTO commande : commandeDTOs) {
				ServiceOrder serviceOrder = new ServiceOrder();
				serviceOrder = ServiceOrderUtils.initialiserServiceOrderViaCommande(commande);
				serviceOrderlst.add(serviceOrder);
			}

		}
		// 2) cas refExterne=null
		else if (externalId == null) {
			List<LigneCommandeDTO> lgncommandeDTOs = COMMANDE_MANAGER.findLigneCommandeByIntervention(appointmentId);
			List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();

			for (LigneCommandeDTO lgncommande : lgncommandeDTOs) {
				CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByLigneCommande(lgncommande.getId());
				commandeDTOs.add(commandeDTO);
			}
			if (commandeDTOs.isEmpty()) {
				throw APIExceptionEnum.serviceordernotfoundwithappointmentid.createAPIException(appointmentId);
			}
			for (CommandeDTO commande : commandeDTOs) {
				ServiceOrder serviceOrder = new ServiceOrder();
				serviceOrder = ServiceOrderUtils.initialiserServiceOrderViaCommande(commande);
				serviceOrderlst.add(serviceOrder);
			}
		}
		// 3) Cas o� les 2 param sont non nuls
		else {
			List<CommandeDTO> commandeApps = ServiceOrderUtils.findCommandeByIdIntervention(appointmentId);
			List<CommandeDTO> commandeExts = COMMANDE_MANAGER.findCommandeListByRefExterne(externalId);
			List<CommandeDTO> commandeResult = ServiceOrderUtils.comparerListeEtGarderDoublons(commandeApps, commandeExts);
			if (commandeResult.isEmpty()) {
				throw APIExceptionEnum.serviceorderappointmentandexternalnull.createAPIException(externalId, appointmentId);
			}

			for (CommandeDTO commande : commandeResult) {
				ServiceOrder serviceOrder = new ServiceOrder();
				serviceOrder = ServiceOrderUtils.initialiserServiceOrderViaCommande(commande);
				serviceOrderlst.add(serviceOrder);
			}

		}

		return Response.ok(serviceOrderlst).build();
	}

	public void validate(@SuppressWarnings("unused") ServiceOrder serviceorder) {

	}
}