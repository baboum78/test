/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.sagic;

import java.io.IOException;
import java.io.Serializable;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.commun.sagic.TagsXML;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Ajout accolades autour d'instruction seule</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE><BR>
 */

public class InjecteurCRSagicMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException {
		if (isMessageCRValide(a_message)) {
			ActivationParam l_activationParam = new ActivationParam("CHAINEINJEC", getIdRequete(a_message));
			return l_activationParam;
		}
		throw new InvalidMessageException("Message invalide");
	}

	/**
	 * isMessageCRValide
	 * V�rifie la structure de la commande XML :
	 * pr�sence d'un fils CR et petit fils complementService
	 * 
	 * @param a_message Serializable : message de compte-rendu provenant de Sagic.
	 * @return true si la commande Sagic est valide false sinon.
	 */
	private boolean isMessageCRValide(Serializable a_message) {
		Element l_rootElt;
		String l_IdCommande;
		NodeList l_CRNodeList;
		Element l_crElt;
		boolean l_result = false;
		Document l_docMessage;

		// R�cup�ration du document XML du message
		try {
			l_docMessage = XmlUtils.getDocument((String) a_message);
		} catch (IOException ioe) {
			throw new InvalidMessageException("Erreur dans getDocument", a_message, ioe);
		} catch (SAXException saxe) {
			throw new InvalidMessageException("Erreur dans getDocument", a_message, saxe);
		}

		l_rootElt = l_docMessage.getDocumentElement();
		if (l_rootElt == null) {
			throw new InvalidMessageException("L'element racine est vide");
		}

		// verification de l'existance du noeud CR
		l_CRNodeList = l_rootElt.getElementsByTagName(TagsXML.TAG_CR_CR);
		if (l_CRNodeList.getLength() == 0) {
			throw new InvalidMessageException("Pas de noeud de nom " + TagsXML.TAG_CR_CR + " trouve dans la commandeXML");
		}
		l_crElt = (Element) l_CRNodeList.item(0);
		// trace de l'id de commande pour reperage dans la log
		l_IdCommande = l_crElt.getAttribute(TagsXML.TAG_CR_ID);
		ServiceManager.getInstance().getLoggerManager().info(getClass().getName(), "isCommandeXmlValide", "Traitement de la commande Sagic n� " + l_IdCommande);
		l_result = true;

		return l_result;
	}

	/**
	 * getIdRequete
	 * R�cup�re l'identifiant de la commande.
	 * 
	 * @param a_message Serializable : message de compte-rendu provenant de Sagic.
	 * @return String : Identifiant de la commande.
	 */
	private String getIdRequete(Serializable a_message) {
		return getCRAttribute(a_message, TagsXML.TAG_CR_ID);
	}

	/**
	 * getCRAttribute
	 * R�cuperation de l'attribut de tag a_attributeName du noeud CR
	 * du compte-rendu provenant de SAGIC.
	 * 
	 * @param a_message Serializable : message de compte-rendu provenant de Sagic.
	 * @param a_attributeName String : nom de l'attribut � r�cuperer.
	 * @return String : valeur de l'attribut.
	 */
	private String getCRAttribute(Serializable a_message, String a_attributeName) {
		String l_attrValue = null;
		Element l_crElt;
		Element l_rootElt;
		Document l_docMessage;

		// R�cup�ration du document XML du message
		try {
			l_docMessage = XmlUtils.getDocument((String) a_message);
		} catch (IOException ioe) {
			throw new InvalidMessageException("Erreur dans getDocument", a_message, ioe);
		} catch (SAXException saxe) {
			throw new InvalidMessageException("Erreur dans getDocument", a_message, saxe);
		}

		l_rootElt = l_docMessage.getDocumentElement();
		l_crElt = (Element) l_rootElt.getElementsByTagName(TagsXML.TAG_CR_CR).item(0);
		l_attrValue = l_crElt.getAttribute(a_attributeName);

		if (l_attrValue == null || l_attrValue.length() == 0) {
			// Le champ CommentCr est facultatif
			if (a_attributeName.equals(TagsXML.TAG_CR_COMMENTAIRE)) {
				l_attrValue = "";
			} else {
				throw new InvalidMessageException("Pas d'attribut : " + a_attributeName + "dans la commande XML");
			}
		}
		ServiceManager.getInstance().getLoggerManager().info(getClass().getName(), "getCrAttribute", "attribut " + a_attributeName + " : " + l_attrValue);

		return l_attrValue;
	}
}
