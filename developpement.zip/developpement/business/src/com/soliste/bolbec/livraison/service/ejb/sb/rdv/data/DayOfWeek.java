/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import com.soliste.bolbec.fwk.util.StringUtils;

/**
 * Enum�ration mod�lisant un jour de la semaine.
 */
public enum DayOfWeek {
	TOUS("T", "DayOfWeek.tous"), LUNDI("2", "DayOfWeek.lundi"), MARDI("3", "DayOfWeek.mardi"), MERCREDI("4", "DayOfWeek.mercredi"), JEUDI("5", "DayOfWeek.jeudi"), VENDREDI("6", "DayOfWeek.vendredi"), SAMEDI("7", "DayOfWeek.samedi");

	private String id;
	private String key;

	private DayOfWeek(String id, String key) {
		this.id = id;
		this.key = key;
	}

	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @return key
	 */
	public String getKey() {
		return key;
	}

	/**
	 * @param id
	 * @return day of week
	 */
	public static DayOfWeek getDayOfWeek(String id) {
		for (DayOfWeek dayOfWeek : DayOfWeek.values()) {
			if (StringUtils.equals(dayOfWeek.id, id)) {
				return dayOfWeek;
			}
		}
		return null;
	}
}