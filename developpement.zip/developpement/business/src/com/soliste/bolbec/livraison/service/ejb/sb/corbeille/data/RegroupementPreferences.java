/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.io.Serializable;

/**
 * Pr�f�rences de regroupement
 * 
 * @author rgvs7490
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>01/12/2011</TD><TD>GPA</TD><TD>EV-000175: Apostrof_Ergonomie_Corbeille - Offrir 5 crit�res de regroupement dans les corbeilles</TD></TR>
 * </TABLE>
 */
public class RegroupementPreferences implements Serializable {

	private String level1Id;
	private String level2Id;
	private String level3Id;
	private String level4Id;
	private String level5Id;

	/**
	 * 
	 * @param level1Id
	 * @param level2Id
	 * @param level3Id
	 * @param level4Id
	 * @param level5Id
	 */
	public RegroupementPreferences(String level1Id, String level2Id, String level3Id, String level4Id, String level5Id) {
		this.level1Id = level1Id;
		this.level2Id = level2Id;
		this.level3Id = level3Id;
		this.level4Id = level4Id;
		this.level5Id = level5Id;
	}

	public String getLevel1Id() {
		return this.level1Id;
	}

	public String getLevel2Id() {
		return this.level2Id;
	}

	public String getLevel3Id() {
		return this.level3Id;
	}

	public String getLevel4Id() {
		return this.level4Id;
	}

	public String getLevel5Id() {
		return this.level5Id;
	}
}
