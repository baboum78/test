package com.soliste.bolbec.livraison.service.ejb.sb.cochisepharaon.exception;

/**
 * Exception permettant de remonter l'information comme quoi
 * aucune publication ne doit �tre envoy�e
 * 
 * @author bperrard
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * </TABLE>
 */
public class NonPublicationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 6279928364928364687L;

	public NonPublicationException() {
		super();
	}

}
