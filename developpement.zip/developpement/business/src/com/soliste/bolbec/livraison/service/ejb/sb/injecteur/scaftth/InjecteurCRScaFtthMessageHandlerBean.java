/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.scaftth;

import java.io.IOException;
import java.io.Serializable;

import org.apache.oro.text.perl.Perl5Util;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesthdparsca.data.ScaFtthDeclarations;

/**
 * @author PQTV8886
 */
public class InjecteurCRScaFtthMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable message) throws InvalidMessageException {
		Document doc = getDocument(message);
		Element root = doc.getDocumentElement();
		ActivationParam ap = getActivationParam(root);
		return ap;
	}

	/**
	 * getActivationParam
	 * 
	 * @param root
	 * Element
	 * @return String
	 * @throws InvalidMessageException
	 */
	private ActivationParam getActivationParam(Element root) throws InvalidMessageException {
		ActivationParam ap = null;

		// R�cup�ration du SF
		String sf = null;
		NodeList nodeListRp = root.getElementsByTagName(ScaFtthDeclarations.TAG_REQUEST_PARAMETERS);
		if (nodeListRp.getLength() == 1) {
			Element nodeRp = (Element) nodeListRp.item(0);
			NodeList nodeListTp = nodeRp.getElementsByTagName(ScaFtthDeclarations.TAG_TARGET_PARAMETERS);
			if (nodeListTp.getLength() == 1) {
				Element nodeTp = (Element) nodeListTp.item(0);
				NodeList nodeParameters = nodeTp.getElementsByTagName(ScaFtthDeclarations.TAG_PARAMETER);
				for (int i = 0; i < nodeParameters.getLength(); i++) {
					Element nodeParam = (Element) nodeParameters.item(i);
					String paramName = nodeParam.getAttribute(ScaFtthDeclarations.TAG_PARAMETER_NAME);
					if (ScaFtthDeclarations.PARAMETER_SERVICE_ACTION.equals(paramName)) {
						Node nodeServiceAction = nodeParam.getFirstChild();
						sf = nodeServiceAction.getNodeValue();
						break;
					}
				}
			}
		}
		if (sf == null) {
			throw new InvalidMessageException("Message invalide, tag " + ScaFtthDeclarations.PARAMETER_SERVICE_ACTION);
		}

		NodeList nodeList = root.getElementsByTagName(ScaFtthDeclarations.TAG_REQUEST_ID);
		if (nodeList.getLength() == 1) {
			Node node = nodeList.item(0);
			Node textNode = node.getFirstChild();
			String idRequete = textNode.getNodeValue();
			// On supprime � partir du 3�me _ s'il y en a un
			String chaineTemp = idRequete;
			int indexSubstring = 0;
			int indexUnderscore = chaineTemp.indexOf('_');
			if (indexUnderscore != -1) {
				chaineTemp = chaineTemp.substring(indexUnderscore + 1);
				indexSubstring = indexUnderscore + 1;
				indexUnderscore = chaineTemp.indexOf('_');
				if (indexUnderscore != -1) {
					chaineTemp = chaineTemp.substring(indexUnderscore + 1);
					indexSubstring += indexUnderscore + 1;
					indexUnderscore = chaineTemp.indexOf('_');
					if (indexUnderscore != -1) {
						indexSubstring += indexUnderscore;
						idRequete = idRequete.substring(0, indexSubstring);
					}
				}
			}
			ap = new ActivationParam(sf, idRequete);
		} else {
			throw new InvalidMessageException("Message invalide, tag " + ScaFtthDeclarations.TAG_REQUEST_ID);
		}

		return ap;
	}

	/**
	 * getDocument
	 * 
	 * @param message
	 * Serializable
	 * @return Document
	 * @throws InvalidMessageException
	 */
	private Document getDocument(Serializable message) throws InvalidMessageException {
		try {
			// ce remplacement dans le messgae de l'xsd est fait afin de pouvoir valider de fa�on generique nos xml
			String messageString = (String) message;
			Perl5Util util = new Perl5Util();
			String messageReplace = util.substitute("s/urn:gccsca.soliste.com.serviceconf .*SCA.*xsd/urn:gccsca.soliste.com.serviceconf " + ScaFtthDeclarations.XSD_SCA_FTTH + "/", messageString);
			return XmlUtils.getDocument(messageReplace, InjecteurCRScaFtthMessageHandlerBean.class.getResource(ScaFtthDeclarations.XSD_SCA_FTTH).getFile());
		} catch (IOException pe) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + pe.getMessage(), message, pe);
		} catch (SAXException se) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + se.getMessage(), message, se);
		}
	}
}