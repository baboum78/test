/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader;

import java.util.ArrayList;
import java.util.List;

import com.soliste.aps.workflow.WfAdvancedDataFilter;
import com.soliste.aps.workflow.WfDataFilter;
import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.bolbec.commun.service.util.sort.SortCommand;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfCorbeilleTranslator;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfFieldDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfFiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfFiltreDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;

/**
 * Impl�mentation du chargement des donn�es workflow d'une corbeille
 * 
 * @author gdzd8490
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/02/2010</TD><TD>DBA</TD><TD>EV-000029: Gestion de plusieurs tris au lieu de 1</TD></TR>
 * </TABLE>
 */
public abstract class WfLoaderImpl implements CorbeilleLoaderImpl {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#getFieldFactory()
	 */
	public FieldDTOFactory getFieldFactory() {
		return WfFieldDTOFactory.getInstance();
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#getFiltreFactory()
	 */
	public FiltreDTOFactory getFiltreFactory() {
		return WfFiltreDTOFactory.getInstance();
	}

	/**
	 * M�lange les filtres pour n'en faire qu'un
	 * 
	 * @param filters
	 * liste de FiltreDTO
	 * @return un filtre workflow
	 */
	protected WfDataFilter mergeFilters(List<FiltreDTO> filters) {
		if (filters.isEmpty()) {
			return null;
		} else if (filters.size() == 1) {
			WfFiltreDTO filter = (WfFiltreDTO) CollectionUtils.getFirstOrNull(filters);
			return filter.getFilter();
		}
		List<WfDataFilter> wfFilters = new ArrayList<WfDataFilter>();
		for (int i = 0; i < filters.size(); i++) {
			WfFiltreDTO filter = (WfFiltreDTO) filters.get(i);
			if (filter.getFilter() != null) {
				wfFilters.add(filter.getFilter());
			}
		}
		WfDataFilter[] filtersArray = wfFilters.toArray(new WfDataFilter[filters.size()]);
		WfAdvancedDataFilter wfFiltre = new WfAdvancedDataFilter(WorkflowConstantes.AND, filtersArray);
		return wfFiltre;
	}

	/**
	 * Contruit une crit�re de tri � partir d'une SortCommand
	 * 
	 * @param sortCommand
	 * @return un filtre workflow
	 */
	protected ArrayList<WfSelFilter> buildOrderByField(SortCommand sortCommand) {
		ArrayList<WfSelFilter> orderByList = new ArrayList<WfSelFilter>();
		if (sortCommand != null) {

			// EV-000029: Gestion du multi-tri
			for (String crit : sortCommand.getCriterion()) {
				if (crit != null) {
					orderByList.add((WfSelFilter) WfCorbeilleTranslator.getInstance().translate(crit));
				}
			}

		}

		return orderByList;
	}
}
