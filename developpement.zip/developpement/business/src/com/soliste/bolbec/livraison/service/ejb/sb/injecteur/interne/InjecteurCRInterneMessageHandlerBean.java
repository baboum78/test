/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.interne;

import java.io.IOException;
import java.io.Serializable;
import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesthd.data.BrasilDeclarations;
import com.soliste.bolbec.livraison.service.model.CompteRenduDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * @author PQTV8886
 */

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>22/01/2021</TD><TD>SOP</TD><TD>G10 - Camunda - Injecteur CR interne pour utilisation depuis les WS</TD></TR>
 * </TABLE><BR>
 */

public class InjecteurCRInterneMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4060043127086550478L;

	/**
	 * @see AbstractInjecteurMessageHandlerBean#getActivationParam(Serializable)
	 */
	public ActivationParam getActivationParam(Serializable message) throws InvalidMessageException {
		try {
			ActivationParam ap = null;
			Map<String, Object> hashMapMessage = (HashMap<String, Object>) message;
			Object objActivationParam =  hashMapMessage.get(Constantes.FIELD_INJECTEUR_INTERNE_CR_ACTIVATION_PARAM);
			if (objActivationParam == null) {
				throw new NullPointerException("Le message doit contenir l'information d'activation.");
			} else if (objActivationParam instanceof  ActivationParam) {
				// TODO G10 - 20211231 - Supprimmer la possibilit� de travailler avec la classe.
				ap = (ActivationParam) objActivationParam;
			} else if (objActivationParam instanceof Map) {
				Map<String, String> serialActivationParam = (Map<String, String>) objActivationParam;
				String a_activatedBy = serialActivationParam.get(Constantes.STR_ACTIVATION_PARAM_ACTIVATED_BY);
				String a_idRequete = serialActivationParam.get(Constantes.STR_ACTIVATION_PARAM_ID_REQUETE);
				String a_typeRequete = serialActivationParam.get(Constantes.STR_ACTIVATION_PARAM_TYPE_REQUETE);
				ap = new ActivationParam(a_activatedBy, a_idRequete, a_typeRequete);
			} else {
				throw new Exception("Le message doit contenir l'information d'activation dans un format comprehensible.");
			}
			return ap;
		} catch (Exception e) {
			throw new InvalidMessageException("message invalide : le message ne correspond pas � une CR Interne. " + e.getMessage());
		}
	}


	/**
	 * createCompteRendu
	 *
	 * @param idCR identifiant du CR / Requete
	 * @param message le message � stocker
	 * @throws RemoteException
	 */
	public void createCompteRendu(String idCR, Serializable message) {
		try {
			Map<String, Object> hashMapMessage = (HashMap<String, Object>) message;
			Serializable msgCR = (Serializable) hashMapMessage.get(Constantes.FIELD_INJECTEUR_INTERNE_CR_MESSAGE);
			if (msgCR == null) {
				throw new NullPointerException("Le message doit contenir l'information du CR.");
			}
			super.createCompteRendu(idCR, msgCR);
		} catch (Exception e) {
			throw new InvalidMessageException("message invalide : le message ne correspond pas � une CR Interne. " + e.getMessage());
		}
	}
}