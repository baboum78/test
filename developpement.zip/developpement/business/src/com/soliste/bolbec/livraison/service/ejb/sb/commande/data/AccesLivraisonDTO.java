/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.commande.data;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

import com.soliste.bolbec.livraison.service.model.ClientDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO contenant les donn�es d'un acc�s de livraison
 * 
 * @author rgvs7490
 */
public class AccesLivraisonDTO implements Serializable {

	private String id;
	private Date dateContractuelle;
	private Date dateSouhaitee;
	/** RG7 - La date pr�visionnelle de d�saturation */
	private Date datePrevisionnelleDesaturation;
	private ClientDTO clientLivre;
	private Map<String, String> contacts;

	private AccesLivraisonDataDTO accesLivraisonCourant;
	private AccesLivraisonDataDTO accesLivraisonOrigine;
	private String referenceEtudeNA;
	private String brocheAdsl;
	private String regletteAdsl;

	/**
	 * 
	 */
	AccesLivraisonDTO() {
		this.datePrevisionnelleDesaturation = null;
	}

	public ClientDTO getClientLivre() {
		return this.clientLivre;
	}

	void setClientLivre(ClientDTO clientLivre) {
		this.clientLivre = clientLivre;
	}

	public String getId() {
		return this.id;
	}

	void setId(String id) {
		this.id = id;
	}

	public Map<String, String> getContacts() {
		return this.contacts;
	}

	void setContacts(Map<String, String> contacts) {
		this.contacts = contacts;
	}

	public Date getDateContractuelle() {
		return this.dateContractuelle;
	}

	void setDateContractuelle(Date dateContractuelle) {
		this.dateContractuelle = dateContractuelle;
	}

	public Date getDateSouhaitee() {
		return this.dateSouhaitee;
	}

	void setDateSouhaitee(Date dateSouhaitee) {
		this.dateSouhaitee = dateSouhaitee;
	}

	public AccesLivraisonDataDTO getAccesLivraisonCourant() {
		return this.accesLivraisonCourant;
	}

	public void setAccesLivraisonCourant(AccesLivraisonDataDTO accesLivraisonCourant) {
		this.accesLivraisonCourant = accesLivraisonCourant;
	}

	public AccesLivraisonDataDTO getAccesLivraisonOrigine() {
		return this.accesLivraisonOrigine;
	}

	public void setAccesLivraisonOrigine(AccesLivraisonDataDTO accesLivraisonOrigine) {
		this.accesLivraisonOrigine = accesLivraisonOrigine;
	}

	public String getReferenceEtudeNA() {
		return this.referenceEtudeNA;
	}

	public void setReferenceEtudeNA(String referenceEtudeNA) {
		this.referenceEtudeNA = referenceEtudeNA;
	}

	/**
	 * M�thode permettant de r�cup�rer la valeur de la date pr�visionnelle de d�saturation
	 * 
	 * @return La date pr�visionnelle de d�saturation
	 */
	public Date getDatePrevisionnelleDesaturation() {
		return datePrevisionnelleDesaturation;
	}

	/**
	 * M�thode permettant de modifier la date pr�visionnelle de d�saturation
	 * 
	 * @param datePrevisionnelleDesaturation La nouvelle date pr�visionnelle de d�saturation
	 */
	public void setDatePrevisionnelleDesaturation(Date datePrevisionnelleDesaturation) {
		this.datePrevisionnelleDesaturation = datePrevisionnelleDesaturation;
	}

	public String getBrocheAdsl() {
		return brocheAdsl;
	}

	public void setBrocheAdsl(String brocheAdsl) {
		this.brocheAdsl = brocheAdsl;
	}

	public String getRegletteAdsl() {
		return regletteAdsl;
	}

	public void setRegletteAdsl(String regletteAdsl) {
		this.regletteAdsl = regletteAdsl;
	}
}
