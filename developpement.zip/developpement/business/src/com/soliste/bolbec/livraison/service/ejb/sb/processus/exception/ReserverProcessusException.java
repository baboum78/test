/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.exception;

/**
 * Exception indiquant qu'une t�che n'a pu �tre r�serv�e
 * 
 * @author gdzd8490
 * 
 */
public class ReserverProcessusException extends Exception {

	/**
	 * Constructeur
	 * 
	 * @param arg0
	 */
	public ReserverProcessusException(Throwable arg0) {
		super(arg0);
	}

}
