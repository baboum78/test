/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.util;

import java.io.IOException;
import java.io.StringWriter;

import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.IC42CConstantes;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * The Class MarshalUtil.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 * 
 * @author
 */
public class MarshalUtil {

	/** Nom de la classe. */
	protected static final String CLASS_NAME = MarshalUtil.class.getName();

	/** The message42 c. */
	private String message42C;

	/** The nd. */
	private String nd;

	/** The prefixe. */
	private String prefixe;

	/**
	 * Constructor.
	 * 
	 * @param a_messageXml the a_message xml
	 */
	public MarshalUtil(String a_messageXml) {
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "Constructor", "message XML = " + a_messageXml);
		try {
			Document doc = XmlUtils.getDocument(a_messageXml);
			Element l_root = doc.getDocumentElement();
			NodeList l_icList = l_root.getElementsByTagName(IC42CConstantes.TAG_IC);
			if (l_icList.getLength() == 0) {
				// anomalie ERREUR_INTERNE
				ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, "getMessage42C", "Impossible d'extraire le noeud " + IC42CConstantes.TAG_IC);
				throw new ReceptionCdeException(IC42CConstantes.ANO_ERREUR_INTERNE, "Erreur lors de la lecture du message 42C");
			}
			Element l_icElement = (Element) l_icList.item(0);
			this.message42C = l_icElement.getAttribute(IC42CConstantes.ATT_MESSAGE);
			ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, "getMessage42C", "message 42C = " + message42C);
			this.nd = l_icElement.getAttribute(IC42CConstantes.ATT_ND);
			ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, "getNumeroDesignation", "nd = " + nd);
			this.prefixe = l_icElement.getAttribute(IC42CConstantes.ATT_PREFIXE);
			ServiceManager.getInstance().getLoggerManager().fine(CLASS_NAME, "getPrefixe", "prefixe = " + prefixe);
		} catch (SAXException e) {
			throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_SYNTAXE, "Exception lors de la de-s�rialisation de l'XML d'une intention de commande 42C.\n", e);
		} catch (IOException e) {
			throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_SYNTAXE, "Exception lors de la de-s�rialisation de l'XML d'une intention de commande 42C.\n", e);
		}
	}

	/**
	 * getMessage42C extrait l'attribut message du message xml 42C.
	 * 
	 * @return the message42 c
	 */
	public String getMessage42C() {
		return this.message42C;
	}

	/**
	 * getND extrait l'attribut ND du message xml 42C.
	 * 
	 * @return the ND
	 */
	public String getND() {
		return this.nd;
	}

	/**
	 * getPrefixe extrait l'attribut prefixe du message xml 42C.
	 * 
	 * @return the prefixe
	 */
	public String getPrefixe() {
		return this.prefixe;
	}

	/**
	 * Marshal.
	 * 
	 * @param a_message the a_message
	 * 
	 * @return the string
	 */
	public static String marshal(bolbec.injection.xml.generated.Message a_message) {
		StringWriter l_writer = new StringWriter();
		try {
			a_message.marshal(l_writer);
		} catch (MarshalException me) {
			throw new TechnicalBusinessException("Erreur lors du marshal", me);
		} catch (ValidationException ve) {
			throw new TechnicalBusinessException("Erreur lors de la validation", ve);
		}
		return l_writer.toString();
	}
}
