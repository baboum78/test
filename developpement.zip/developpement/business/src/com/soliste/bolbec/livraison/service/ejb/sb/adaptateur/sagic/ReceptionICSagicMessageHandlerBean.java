/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.AdapatateurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.util.AdaptationUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.util.MarshalUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic.util.ValidationUtil;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.publication.delegues.DeleguePublicationSagic;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil;

import bolbec.adaptateur.sagic.xml.generated.CommandeSagic;

/**
 * The Class ReceptionICSagicMessageHandlerBean.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>07/06/2012</TD><TD>BPE</TD><TD>Suppression import non utilis�</TD></TR>
 * <TR><TD>20/11/2013</TD><TD>FTE</TD><TD>G8R2C4 - EV-000270 : V�rification de la coh�rence des commandes PSG+ 1.1</TD></TR>
 * <TR><TD>13/11/2015</TD><TD>JDE</TD><TD>G9R1C1 - EV-000313 : Gestion des erreurs d'IC (rejets des messages) pour 42C (et d�placement du code specifique � Sagic)</TD></TR>
 * </TABLE>
 * 
 * @author rgvs7490
 */
public class ReceptionICSagicMessageHandlerBean extends AdapatateurMessageHandlerBean {

	private static final Log LOG = new Log(ReceptionICSagicMessageHandlerBean.class);

	/** The CLAS s_ name. */
	private static final String CLASS_NAME = ReceptionICSagicMessageHandlerBean.class.getName();

	/** The Constant INTERFACE_QUEUE_NAME. */
	private static final String INTERFACE_QUEUE_NAME = "jms/interfaceQueue";

	/** The Constant QUEUE_FULL_NAME. */
	private static final String QUEUE_FULL_NAME_SAGIC = "java:comp/env/" + INTERFACE_QUEUE_NAME;

	/** The Constant TRAITEMENT. */
	private static final String TRAITEMENT_SAGIC = "SagicOut";

	/** The Constant TYPE_SERVICE. */
	private static final String TYPE_SERVICE_SAGIC = "SagicOut";

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#processMessage(java.io.Serializable, CommandeDTO)
	 */
	public void processMessage(Serializable message, CommandeDTO commandeDTO) throws InvalidJmsMessageException {
		long begin = System.currentTimeMillis();
		Map<String, Object> paramFonctNotification = new HashMap<String, Object>();
		String xmlMsg = null;

		try {
			xmlMsg = getXmlMessage(message);
			String instanceLocalisation = getInstanceLocalisation(message);
			CommandeSagic commandeSagic = MarshalUtil.unmarshalMessageBody(xmlMsg);

			LOG.metro("'ReceptionICSagic' ND = " + commandeSagic.getIC().getSupport() + " REFEXTERNE = " + commandeSagic.getIC().getIdIceSagic() + " date = " + begin);

			ValidationUtil.validate(commandeSagic);

			AdaptationUtil adaptateur = new AdaptationUtil();

			bolbec.injection.xml.generated.Message messageToInject = adaptateur.adapt(commandeSagic);

			String xmlMessageToInject = MarshalUtil.marshal(messageToInject);

			HashMap<String, String> mapToInject = new HashMap<String, String>();
			mapToInject.put(Constantes.FIELD_INSTANCE_LOCALISATION, instanceLocalisation);
			mapToInject.put(Constantes.FIELD_MESSAGE, xmlMessageToInject);
			mapToInject.put(Constantes.FIELD_ID_COMMANDE, commandeDTO.getId());

			InjectionCdeUtil.inject(mapToInject);
		} catch (ReceptionCdeException rce) {
			// r�cup�ration de l'id ic avec une regex
			Pattern p = Pattern.compile("IdIceSagic=\"(\\w*)\"");
			Matcher m = p.matcher(xmlMsg);
			String idIc = null;
			while (m.find()) {
				idIc = m.group(1);
			}
			paramFonctNotification.put(SagicConstantes.KEY_REF_COMMANDE, idIc);
			paramFonctNotification.put(SagicConstantes.KEY_FORMAT, SagicConstantes.REJ_SAGIC);
			try {
				InjectionCdeUtil.throwExceptionForAnomalie(rce, rce.getId(), message);
			} catch (InvalidJmsMessageException ex) {
				ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, "processMessage", "Envoi d'une notification pour publication NON_PEC");
				envoyerNotificationSagic(paramFonctNotification);
				throw ex;
			}
		} finally {
			long end = System.currentTimeMillis();
			String messageMetro = "'ReceptionICSagic' duree = " + (end - begin) + " ms";
			LOG.metro(messageMetro);
		}
	}

	/**
	 * Appel � la publication.
	 * 
	 * @param infosFonctionnel the infos fonctionnel
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TR><TD>25/11/2013</TD><TD>FTE</TD><TD>DE-000270 : V�rification de la coh�rence des commandes PSG+ 1.1</TD></TR>
	 * </TABLE>
	 */
	private static void envoyerNotificationSagic(Map<String, Object> infosFonctionnel) {
		final String nomMethode = "envoyerNotificationSagic";
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, nomMethode, "Debut");
		// Appeler la strategy de publication
		ServiceManager.getInstance().getLoggerManager().finer(CLASS_NAME, nomMethode, "Appel � PublicationSagicStrategy");
		DeleguePublicationSagic publication = new DeleguePublicationSagic(QUEUE_FULL_NAME_SAGIC, TRAITEMENT_SAGIC, TYPE_SERVICE_SAGIC);
		publication.publierCrRejetSagic(infosFonctionnel);
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, nomMethode, "Fin");
	}

	public String getBaliseRefExterne() {
		return "IdIceSagic=\"";
	}


}