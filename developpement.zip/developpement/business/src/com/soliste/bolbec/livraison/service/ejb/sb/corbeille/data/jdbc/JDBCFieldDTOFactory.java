/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;

/**
 * 
 * Factory pour FieldDTO JDBC
 * 
 * @author gdzd8490
 * 
 */
public class JDBCFieldDTOFactory implements FieldDTOFactory {

	private static JDBCFieldDTOFactory instance = null;

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static JDBCFieldDTOFactory getInstance() {
		if (instance == null) {
			instance = new JDBCFieldDTOFactory();
		}
		return instance;
	}

	private JDBCFieldDTOFactory() {
		// pour �viter instanciation inutile
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory#create(java.lang.String)
	 */
	public FieldDTO create(String id) {
		JDBCField jdbcField = (JDBCField) JDBCCorbeilleTranslator.getInstance().translate(id);
		return new JDBCFieldDTO(jdbcField);
	}
}
