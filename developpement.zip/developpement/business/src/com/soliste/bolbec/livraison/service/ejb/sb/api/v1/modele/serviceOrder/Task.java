package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder;

import java.util.Calendar;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.adapters.XmlJavaTypeAdapter;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.soliste.bolbec.livraison.service.ejb.sb.api.adapter.CalendarAdapter;

/**
 * Modele Ressource Task
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/11/2015</TD><TD>MFA</TD><TD>Initialisation du Task</TD></TR>
 * <TR><TD>23/03/2016</TD><TD>KWE</TD><TD>EV-353_01 Ajout champ date</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "task")
public class Task {

	private String id;
	private String label;
	private String shortLabel;
	private TaskStatus state;
	private String assignatedRole;
	private EventCauseRef closureEventCause;
	@XmlJavaTypeAdapter(CalendarAdapter.class)
	private Calendar date;
	private List<TaskData> data;


	/**
	 * @return the id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id the id to set
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return the label
	 */
	public String getLabel() {
		return label;
	}

	/**
	 * @param label the label to set
	 */
	public void setLabel(String label) {
		this.label = label;
	}

	/**
	 * @return the shortLabel
	 */
	public String getShortLabel() {
		return shortLabel;
	}

	/**
	 * @param shortLabel the shortLabel to set
	 */
	public void setShortLabel(String shortLabel) {
		this.shortLabel = shortLabel;
	}

	/**
	 * @return the state
	 */
	public TaskStatus getState() {
		return state;
	}

	/**
	 * @param state the state to set
	 */
	public void setState(TaskStatus state) {
		this.state = state;
	}

	/**
	 * @return the assignatedRole
	 */
	public Object getAssignatedRole() {
		return assignatedRole;
	}

	/**
	 * @param assignatedRole the assignatedRole to set
	 */
	public void setAssignatedRole(String assignatedRole) {
		this.assignatedRole = assignatedRole;
	}

	/**
	 * @return the closureEventCause
	 */
	public EventCauseRef getClosureEventCause() {
		return closureEventCause;
	}

	/**
	 * @param closureEventCause the closureEventCause to set
	 */
	public void setClosureEventCause(EventCauseRef closureEventCause) {
		this.closureEventCause = closureEventCause;
	}

	/**
	 * @return the date
	 */
	public Calendar getDate() {
		return date;
	}

	/**
	 * @param date the date to set
	 */
	public void setDate(Calendar date) {
		this.date = date;
	}

	/**
	 * @return the data
	 */
	public List<TaskData> getData() {
		return data;
	}

	/**
	 * @param data the data to set
	 */
	public void setData(List<TaskData> data) {
		this.data = data;
	}

}
