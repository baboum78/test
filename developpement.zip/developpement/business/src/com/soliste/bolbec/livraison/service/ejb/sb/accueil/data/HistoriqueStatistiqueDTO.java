/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.accueil.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.soliste.bolbec.livraison.service.model.DrDTO;
import com.soliste.bolbec.livraison.service.model.StatistiqueDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO contenant l'historique d'une statistique pour une DR
 * 
 * @author rgvs7490
 */
public class HistoriqueStatistiqueDTO implements Serializable {

	private DrDTO dr;
	private List<StatistiqueDTO> statistiques = new ArrayList<StatistiqueDTO>();

	/**
	 * 
	 * @param dr
	 * @param statistiques
	 */
	public HistoriqueStatistiqueDTO(DrDTO dr, List<StatistiqueDTO> statistiques) {
		this.dr = dr;
		this.statistiques = statistiques;
	}

	public DrDTO getDr() {
		return this.dr;
	}

	public List<StatistiqueDTO> getStatistiques() {
		return this.statistiques;
	}
}
