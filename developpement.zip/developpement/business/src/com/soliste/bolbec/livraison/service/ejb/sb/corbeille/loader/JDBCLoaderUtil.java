/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.soliste.aps.workflow.model.WfActivityDefinition;
import com.soliste.aps.workflow.model.WfModel;
import com.soliste.aps.workflow.model.WfModelDefinition;
import com.soliste.aps.workflow.xpm.wfsessionin.ConstantesXPM;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCCorbeilleTranslator;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCFiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCSynthesisData;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCCondition;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCFieldCount;
import com.soliste.bolbec.livraison.service.util.jdbc.TacheEnCoursJDBCFields;

/**
 * Classe utilitaire pour le JDBCLoader
 * 
 * @author gdzd8490
 * 
 */
public final class JDBCLoaderUtil {

	/** Champ correspondant � l'identifiant d'une t�che */
	public static final JDBCField ID_PROCESSUS_FIELD = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ID_PROCESS);
	
	/** Champ correspondant � l'identifiant d'un processus */
	public static final JDBCField ID_TACHE_FIELD = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.ID);

	/** Champ correspondant � l'identifiant du traitement */
	public static final JDBCField TRAITEMENT_FIELD = TacheEnCoursJDBCFields.get(TacheEnCoursJDBCFields.TRAITEMENT);

	/**
	 * Cl� pour stockage l'identifiant d'un processus au sein de sa hashMap de
	 * donn�es m�tier
	 */
	private static final String ID_PROCESSUS_KEY = ID_PROCESSUS_FIELD.getFieldName();

	/**
	 * Cl� pour stockage l'identifiant d'une t�che au sein de sa hashMap de
	 * donn�es m�tier
	 */
	private static final String ID_TACHE_KEY = ID_TACHE_FIELD.getFieldName();

	/** Traducteur JDBC */
	private static final JDBCCorbeilleTranslator translator = JDBCCorbeilleTranslator.getInstance();

	private JDBCLoaderUtil() {
		super();
	}

	/**
	 * Traduit la liste des identifiants de CorbeilleInfo en champs JDBC
	 * 
	 * @param infos
	 * @return des champs JDBC
	 */
	public static List<JDBCField> translateInfosIntoFields(List<String> infos) {
		List<JDBCField> fields = new ArrayList<JDBCField>();
		if (infos != null) {
			for (String infoId : infos) {
				JDBCField field = translateInfoIntoField(infoId);
				if (field != null && !fields.contains(field)) {
					fields.add(field);
				}
			}
		}
		return fields;
	}

	/**
	 * Traduit un identifiant de CorbeilleInfo en champ JDBC
	 * 
	 * @param infoId
	 * @return un JDBCField
	 */
	public static JDBCField translateInfoIntoField(String infoId) {
		return (JDBCField) translator.translate(infoId);
	}

	/**
	 * Traduit la liste de r�sultats JDBC en liste de Map [identifiant corbeille
	 * info / valeur] pour que ces donn�es soient exploitables par les
	 * corbeilles
	 * 
	 * @param fields
	 * @return une liste exploitable par les corbeilles
	 */
	public static List<Map<String, String>> translateFieldsIntoInfos(List<Map<String, String>> fields) {
		List<Map<String, String>> translatedElements = new ArrayList<Map<String, String>>();
		if (fields != null) {
			for (Map<String, String> values : fields) {
				Map<String, String> translatedValues = new HashMap<String, String>();
				if (values != null) {
					for (Entry<String, String> entry : values.entrySet()) {
						String key = entry.getKey();
						if (key.equals(ID_TACHE_FIELD.getFullyQualifiedName())) {
							// cas particulier de l'identifiant de t�che qui n'a
							// pas d'�quivalent CorbeilleInfo
							translatedValues.put(ID_TACHE_KEY, entry.getValue());
						} else if (key.equals(ID_PROCESSUS_FIELD.getFullyQualifiedName())) {
							// cas particulier de l'identifiant de processus qui
							// n'a pas d'�quivalent CorbeilleInfo
							translatedValues.put(ID_PROCESSUS_KEY, entry.getValue());
						} else if (key.equals(TRAITEMENT_FIELD.getFullyQualifiedName())) {
							// Cas particulier du champ traitement, qui n'est pas correctement valoris� en BDD.
							//TODO G10 modifier la requ�te de TRAITEMENT_FIELD
							WfModelDefinition element = WfModel.getInstance().getTaskDefinitionById(entry.getValue());
							String value = CollectionUtils.getFirstOrNull(element.getStaticAttribute(ConstantesXPM.WF_ATTRIBUTE_TREATMENT));
							translatedValues.put(translator.translateField(key), value);
						} else {
							// les autres libell�s sont traduits en identifiants
							// de CorbeilleInfo
							translatedValues.put(translator.translateField(key), entry.getValue());
						}
					}
				}
				translatedElements.add(translatedValues);
			}
		}
		return translatedElements;
	}

	/**
	 * Traduit une liste de FiltreDTO en liste de JDBCCondition
	 * 
	 * @param filters
	 * @return une liste de liste de JDBCCondition
	 */
	public static List<JDBCCondition> translateFiltersIntoConditions(List<FiltreDTO> filters) {
		List<JDBCCondition> conditions = new ArrayList<JDBCCondition>();
		for (FiltreDTO dto : filters) {
			conditions.addAll(((JDBCFiltreDTO) dto).getFilter());
		}
		return conditions;
	}

	/**
	 * Transforme une liste de Map en liste de JDBCSynthesisData
	 * 
	 * @param synthesisMaps
	 * amp de valeurs des champs
	 * @param fieldNames
	 * nom des champs
	 * @return une liste de JDBCSynthesisData
	 */
	public static List<SynthesisData> translateMapsIntoSynthesisData(List<Map<String, String>> synthesisMaps, List<String> fieldNames) {
		String libelleFieldCount = JDBCFieldCount.getStarCountField().getFullyQualifiedName();
		List<SynthesisData> jdbcSynthesisData = new ArrayList<SynthesisData>();
		for (Map<String, String> map : synthesisMaps) {
			// sum
			String count = map.get(libelleFieldCount);
			int sum = Integer.parseInt(count);
			// values
			List<String> values = new ArrayList<String>();
			for (String libelleField : fieldNames) {
				values.add(map.get(libelleField));
			}
			// creation du JDBCSynthesisData
			jdbcSynthesisData.add(new JDBCSynthesisData(values, sum));
		}
		return jdbcSynthesisData;
	}

	/**
	 * Utilisation de la facade JDBCData pour les t�ches *
	 * 
	 * @param elements
	 * une liste de JDBCFiltre
	 * @return une liste de JDBCData
	 */
	public static List<ItemData> getTacheFacadeList(List<Map<String, String>> elements) {
		List<ItemData> facadeElements = new ArrayList<ItemData>(elements.size());
		for (Map<String, String> values : elements) {
			String id = values.get(ID_TACHE_KEY);
			facadeElements.add(new JDBCData(id, values));
		}
		return facadeElements;
	}

	/**
	 * Utilisation de la facade JDBCData pour les processus
	 * 
	 * @param elements
	 * une liste de JDBCFiltre
	 * @return une liste de JDBCData
	 */
	public static List<ItemData> getProcessusFacadeList(List<Map<String, String>> elements) {
		int nbTaches = elements.size();
		List<ItemData> facadeElements = new ArrayList<ItemData>(nbTaches);
		for (Map<String, String> values : elements) {
			String id = values.get(ID_PROCESSUS_KEY);
			facadeElements.add(new JDBCData(id, values));
		}
		return facadeElements;
	}
}
