package com.soliste.bolbec.livraison.service;

/**
 * Classe de contantes pout alteoos<br />
 * On les regroupe toutes ici pour pouvoir nettoyer plus facilement
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>15/07/2013</TD><TD>EBA</TD><TD>G9R0C1 - Alteoos : Creation de la classe</TD></TR>
 * </TABLE>
 * 
 */
public interface ConstantesAlteoos {

	String KEY_PROXY = "Proxy";
	String KEY_COMMANDES_IDS = "commandesIds";
	String KEY_VERSION_LIVRAISONS = "versionLivraisons";
	String KEY_ID = "id";

	String FORWARD_VIEW_PROXY = "viewProxy";
	String FORWARD_VIEW_PROXY_DETAIL = "viewProxyDetail";

	String URL_DETAIL_TACHES = "/detailCorbeilleTaches.do";
	String URL_DETAIL_TOUTES_TACHES = "/detailCorbeilleToutesTaches.do";

}
