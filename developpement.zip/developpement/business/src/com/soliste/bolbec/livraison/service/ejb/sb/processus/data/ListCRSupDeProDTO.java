/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * Le DTO pour une liste de CR de Publication
 * 
 * @author La�titia FABRE
 */
public class ListCRSupDeProDTO implements Serializable {

	private List<CRSupDeProDTO> list;
	private String id;
	private String formatExterne;
	private String jalon;
	private String libelleEtatPublication;
	private String libelleLienPublication;

	private boolean validable;

	/**
	 * Constructeur
	 * 
	 */
	public ListCRSupDeProDTO(String id) {
		super();
		list = new ArrayList<CRSupDeProDTO>();
		this.id = id;
	}

	/**
	 * Retourne le <code>list</code>
	 * 
	 * @return le <code>list</code>
	 */
	public List<CRSupDeProDTO> getList() {
		return list;
	}

	/**
	 * Affecte le <code>list</code>
	 * 
	 * @param list le <code>list</code> � affecter
	 */
	public void setList(List<CRSupDeProDTO> list) {
		this.list = list;
	}

	/**
	 * Retourne le <code>size</code>
	 * 
	 * @return le <code>size</code>
	 */
	public int getSize() {
		return list.size();
	}

	/**
	 * Ajoute un objet � la liste
	 * 
	 * @param object
	 */
	public void add(CRSupDeProDTO object) {
		list.add(object);
	}

	/**
	 * Retourne le <code>id</code>
	 * 
	 * @return le <code>id</code>
	 */
	public String getId() {
		return id;
	}

	/**
	 * Affecte le <code>id</code>
	 * 
	 * @param id le <code>id</code> � affecter
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * @return jalon
	 */
	public String getJalon() {
		return jalon;
	}

	/**
	 * @param jalon
	 */
	public void setJalon(String jalon) {
		this.jalon = jalon;
	}

	/**
	 * @return formatExterne
	 */
	public String getFormatExterne() {
		return formatExterne;
	}

	/**
	 * @param formatExterne
	 */
	public void setFormatExterne(String formatExterne) {
		this.formatExterne = formatExterne;
	}

	/**
	 * @return libelleEtatPublication
	 */
	public String getLibelleEtatPublication() {
		return libelleEtatPublication;
	}

	/**
	 * @param libelleEtatPublication
	 */
	public void setLibelleEtatPublication(String libelleEtatPublication) {
		this.libelleEtatPublication = libelleEtatPublication;
	}

	/**
	 * @return libelleLienPublication
	 */
	public String getLibelleLienPublication() {
		return libelleLienPublication;
	}

	/**
	 * @param libelleLienPublication
	 */
	public void setLibelleLienPublication(String libelleLienPublication) {
		this.libelleLienPublication = libelleLienPublication;
	}

	/**
	 * @return validable
	 */
	public boolean isValidable() {
		return validable;
	}

	/**
	 * @param validable
	 */
	public void setValidable(boolean validable) {
		this.validable = validable;
	}
}
