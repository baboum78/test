package com.soliste.bolbec.livraison.service.ejb;

/**
 * Constantes des noms JNDI des EJB de la couche Service
 * 
 * @author kyrw0678
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>27/01/2012</TD><TD>GPA</TD><TD>EV-000168: Ajout de la constante JNDI_PARAMETRE_DYNAMIQUE_MANAGER</TD></TR>
 * <TR><TD>18/12/2012</TD><TD>BPE</TD><TD>DE-000692 : Objets Pharaon non instanci�s par le conteneur EJB</TD></TR>
 * <TR><TD>13/12/2012</TD><TD>GPA</TD><TD>EV-000191: G8R2C1 - Ajout de la constante JNDI_CUSTOMER_ORDER_MANAGER</TD></TR>
 * <TR><TD>08/01/2014</TD><TD>EBA</TD><TD>G8R2C4 - EV-000266 : Nouvel EJB Gel du ND</TD></TR>
 * <TR><TD>14/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * <TR><TD>03/05/2018</TD><TD>AJO</TD><TD>QC974 : Vador</TD></TR>
 * </TABLE>
 */
public interface ConstantesJNDI extends com.soliste.bolbec.commun.service.ejb.ConstantesJNDI {

	String JNDI_PROCESSUS_MANAGER = "ejb.service.ProcessusManager";

	String JNDI_PROCESSUS_MANAGER_REMOTE = "ejb.service.ProcessusManagerRemote";

	String JNDI_COMMANDE_MANAGER = "ejb.service.CommandeManager";

	String JNDI_COMMANDE_MANAGER_REMOTE = "ejb.service.CommandeManagerRemote";

	String JNDI_COMMANDE_SEARCH_MANAGER = "ejb.service.SearchCommandeManager";

	String JNDI_RESSOURCE_TECHNIQUE_MANAGER = "ejb.service.RessourceTechniqueManager";

	String JNDI_RESSOURCE_TECHNIQUE_MANAGER_REMOTE = "ejb.service.RessourceTechniqueManagerRemote";

	String JNDI_COMPTE_RENDU_MANAGER = "ejb.service.CompteRenduManager";

	String JNDI_COMPTE_RENDU_MANAGER_REMOTE = "ejb.service.CompteRenduManagerRemote";

	String JNDI_RENDEZ_VOUS_MANAGER = "ejb.service.RendezVousManager";

	String JNDI_IC_MANAGER = "ejb.service.InjectionCommandeManager";

	String JNDI_WF_SERVICES = "bolbec.livraison.services.WfServices";

	String JNDI_SESSION_IN = "workflow.SessionIN";

	String JNDI_SESSION_IN_REMOTE = "workflow.SessionINRemote";

	String JNDI_TASK_TREATMENT = "workflow.TaskTreatment";

	String JNDI_TASK_TREATMENT_REQUIRED = "workflow.TaskTreatmentRequired";

	String JNDI_ACCUEIL_MANAGER = "ejb.service.AccueilManager";

	String JNDI_PARSIFAL_MANAGER = "ejb.service.ParsifalManager";

	String JNDI_ZONE_GEO_MANAGER = "ejb.service.ZoneGeographiqueManager";

	String JNDI_ZONE_SI_MANAGER = "ejb.service.ZoneSIManager";

	String JNDI_REPARTITEUR_MANAGER = "ejb.service.RepartiteurManager";

	String JNDI_TREE_MANAGER = "ejb.service.TreeManager";

	String JNDI_REGUL_MANUELLE_MANAGER = "ejb.service.RegulManuelleManager";

	String JNDI_WORKFLOW_MANAGER = "WorkflowManager";

	String JNDI_AVP_MANAGER = "ejb.service.AvpManager";

	String JNDI_UNITE_ACTIVITE_MANAGER = "ejb.service.UniteActiviteManager";

	String JNDI_PARAMETRE_DYNAMIQUE_MANAGER = "ejb.service.ParametreDynamiqueManager";

	String JNDI_PHARAON_INIT_LIV_MANAGER = "ejb.service.PharaonInitLivManager";

	String JNDI_CUSTOMER_ORDER_MANAGER = "ejb.service.CustomerOrderManager";

	String JNDI_ND_GELES_MANAGER = "ejb.service.NdGelesManager";

	String JNDI_PUBLICATION_MANAGER = "ejb.service.PublicationManager";
}
