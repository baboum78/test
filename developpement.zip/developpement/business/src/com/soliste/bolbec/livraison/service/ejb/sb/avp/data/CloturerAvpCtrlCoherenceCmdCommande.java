package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;
import java.util.List;

import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;

import com.google.common.base.Strings;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>06/07/2018</TD><TD>AJO</TD><TD>QC-980 : Intrants FTTH</TD></TR>
 * </TABLE><BR>
 *
 * Commande de cl�ture pour les AVPs Controle CoherenceCommande
 */
public class CloturerAvpCtrlCoherenceCmdCommande extends CloturerAvpCommande {

	private String codeImmeuble;
	private String cpltNumVoie;
	private String numeroVoie;
	private String batiment;
	private String etage;
	private String codeRivoli;
	private String escalier;
	private String codeInsee;
	private String referencePrise;
	private String priseExistante;
	private String operateurImmeuble;
	private final int NB_PARAM = 11;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param codeImmeuble
	 * @param cpltNumVoie
	 * @param numeroVoie
	 * @param batiment
	 * @param etage
	 * @param codeRivoli
	 * @param escalier
	 * @param codeInsee
	 * @param referencePrise
	 * @param priseExistante
	 * @param operateurImmeuble
	 */
	public CloturerAvpCtrlCoherenceCmdCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String codeImmeuble, String cpltNumVoie, String numeroVoie, String batiment, String etage, String codeRivoli,
			String escalier, String codeInsee, String referencePrise, String priseExistante, String operateurImmeuble) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.codeImmeuble = codeImmeuble;
		this.cpltNumVoie = cpltNumVoie;
		this.numeroVoie = numeroVoie;
		this.batiment = batiment;
		this.etage = etage;
		this.codeRivoli = codeRivoli;
		this.escalier = escalier;
		this.codeInsee = codeInsee;
		this.referencePrise = referencePrise;
		this.priseExistante = priseExistante;
		this.operateurImmeuble = operateurImmeuble;
	}

	/**
	 *
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 */
	public CloturerAvpCtrlCoherenceCmdCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData) {
		super(tacheId, info, causeEvenementId, date, itemData);
	}

	/**
	 * @return the codeImmeuble
	 */
	public String getCodeImmeuble() {
		return codeImmeuble;
	}

	/**
	 * @param codeImmeuble the codeImmeuble to set
	 */
	public void setCodeImmeuble(String codeImmeuble) {
		this.codeImmeuble = codeImmeuble;
	}

	/**
	 * @return the cpltNumvoie
	 */
	public String getcpltNumVoie() {
		return cpltNumVoie;
	}

	/**
	 * @param cpltNumVoie the cpltNumvoie to set
	 */
	public void setcpltNumVoie(String cpltNumVoie) {
		this.cpltNumVoie = cpltNumVoie;
	}

	/**
	 * @return the numeroVoie
	 */
	public String getNumeroVoie() {
		return numeroVoie;
	}

	/**
	 * @param numeroVoie the numeroVoie to set
	 */
	public void setNumeroVoie(String numeroVoie) {
		this.numeroVoie = numeroVoie;
	}

	/**
	 * @return the batiment
	 */
	public String getBatiment() {
		return batiment;
	}

	/**
	 * @param batiment the batiment to set
	 */
	public void setBatiment(String batiment) {
		this.batiment = batiment;
	}

	/**
	 * @return the etage
	 */
	public String getEtage() {
		return etage;
	}

	/**
	 * @param etage the etage to set
	 */
	public void setEtage(String etage) {
		this.etage = etage;
	}

	/**
	 * @return the codeRivoli
	 */
	public String getCodeRivoli() {
		return codeRivoli;
	}

	/**
	 * @param codeRivoli the codeRivoli to set
	 */
	public void setCodeRivoli(String codeRivoli) {
		this.codeRivoli = codeRivoli;
	}

	/**
	 * @return the escalier
	 */
	public String getEscalier() {
		return escalier;
	}

	/**
	 * @param escalier the escalier to set
	 */
	public void setEscalier(String escalier) {
		this.escalier = escalier;
	}

	/**
	 * @return the codeInsee
	 */
	public String getCodeInsee() {
		return codeInsee;
	}

	/**
	 * @param codeInsee the codeInsee to set
	 */
	public void setCodeInsee(String codeInsee) {
		this.codeInsee = codeInsee;
	}

	/**
	 * @return the referencePrise
	 */
	public String getReferencePrise() {
		return referencePrise;
	}

	/**
	 * @param referencePrise the referencePrise to set
	 */
	public void setReferencePrise(String referencePrise) {
		this.referencePrise = referencePrise;
	}


	/**
	 * @return the priseExistante
	 */
	public String getPriseExistante() {
		return priseExistante;
	}

	/**
	 * @param priseExistante the priseExistante to set
	 */
	public void setPriseExistante(String priseExistante) {
		this.priseExistante = priseExistante;
	}

	/**
	 * @return the operateurImmeuble
	 */
	public String getOperateurImmeuble() {
		return operateurImmeuble;
	}

	/**
	 * @param operateurImmeuble the operateurImmeuble to set
	 */
	public void setOperateurImmeuble(String operateurImmeuble) {
		this.operateurImmeuble = operateurImmeuble;
	}

	public void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande){

		int cpt = 0;

		for (LigneCommandeDTO commandePrecedente : listeLigneCommande) {
			AdresseDTO adresseDTO = commandePrecedente.getClient().getAdresse();

			if(this.getCodeImmeuble() == null && commandePrecedente.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.CLE_CODE_IMMEUBLE) != null){
				this.setCodeImmeuble(commandePrecedente.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.CLE_CODE_IMMEUBLE));
				cpt++;
			}
			if(this.getcpltNumVoie() == null && adresseDTO.getCpltnumVoie() != null){
				this.setcpltNumVoie(adresseDTO.getCpltnumVoie());
				cpt++;
			}
			if(this.getNumeroVoie() == null && adresseDTO.getNumeroVoie() != null){
				this.setNumeroVoie(adresseDTO.getNumeroVoie());
				cpt++;
			}
			if(this.getBatiment() == null && adresseDTO.getBatiment() != null){
				this.setBatiment(adresseDTO.getBatiment());
				cpt++;
			}
			if(this.getEtage() == null && adresseDTO.getEtage() != null){
				this.setEtage(adresseDTO.getEtage());
				cpt++;
			}
			if(this.getCodeRivoli() == null && adresseDTO.getCodeRivoli() != null){
				this.setCodeRivoli(adresseDTO.getCodeRivoli());
				cpt++;
			}
			if(this.getEscalier() == null && adresseDTO.getEscalier() != null){
				this.setEscalier(adresseDTO.getEscalier());
				cpt++;
			}
			if(this.getCodeInsee() == null && adresseDTO.getCodeInsee() != null){
				this.setCodeInsee(adresseDTO.getCodeInsee());
				cpt++;
			}
			if(this.getReferencePrise() == null && commandePrecedente.getLigneCmdCatalogue().getPsSouhaite().getDynamicPsSouhaites().get(ConstantesDynamicPSSouhaite.PTOID) != null){
				this.setReferencePrise(commandePrecedente.getLigneCmdCatalogue().getPsSouhaite().getDynamicPsSouhaites().get(ConstantesDynamicPSSouhaite.PTOID));
				cpt++;
			}
			if(this.getPriseExistante() == null && commandePrecedente.getDynamicLigneCommandes().get(ConstantesDynamicPSSouhaite.PSSOUHAITE_PLPTSANSPTOID) != null){
				this.setPriseExistante(commandePrecedente.getDynamicLigneCommandes().get(ConstantesDynamicPSSouhaite.PSSOUHAITE_PLPTSANSPTOID));
				cpt++;
			}
			if(this.getOperateurImmeuble() == null && commandePrecedente.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OPERATEUR_IMMEUBLE) != null){
				this.setOperateurImmeuble(commandePrecedente.getDynamicLigneCommandes().get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_OPERATEUR_IMMEUBLE));
				cpt++;
			}
			if(cpt >= NB_PARAM){
				break;
			}
		}

		if(dataToSet != null){
			if(dataToSet.getImmeuble() != null){
				setCodeImmeuble(dataToSet.getImmeuble());
			}
			if(dataToSet.getCplVoie() != null){
				setcpltNumVoie(dataToSet.getCplVoie());
			}
			if(dataToSet.getNumVoie() != null){
				setNumeroVoie(dataToSet.getNumVoie());
			}
			if(dataToSet.getBatiment() != null){
				setBatiment(dataToSet.getBatiment());
			}
			if(dataToSet.getEtage() != null){
				setEtage(dataToSet.getEtage());
			}
			if(dataToSet.getCodeRivoli() != null){
				setCodeRivoli(dataToSet.getCodeRivoli());
			}
			if(dataToSet.getEscalier() != null){
				setEscalier(dataToSet.getEscalier());
			}
			if(dataToSet.getCodeInsee() != null){
				setCodeInsee(dataToSet.getCodeInsee());
			}
			if(dataToSet.getIdPTO() != null){
				setReferencePrise(dataToSet.getIdPTO());
			}
			if(dataToSet.getPriseExist() != null){
				setPriseExistante(dataToSet.getPriseExist());
			}
			if(dataToSet.getOpImb() != null){
				setOperateurImmeuble(dataToSet.getOpImb());
			}
		}

	}

}
