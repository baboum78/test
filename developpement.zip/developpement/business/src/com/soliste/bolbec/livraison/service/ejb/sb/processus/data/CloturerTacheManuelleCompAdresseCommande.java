/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * @author edba8262
 */
public class CloturerTacheManuelleCompAdresseCommande extends CloturerTacheManuelleCommande {

	private String libelleVoie;
	private String codeRivoli;
	private String numeroVoie;
	private String ensemble;
	private String batiment;
	private String escalier;
	private String etage;
	private String porte;
	private String logo;
	private String codeInsee;
	private String ndplp;

	/**
	 * 
	 * @param tacheId
	 * @param itemData
	 * @param libelleVoie
	 * @param codeRivoli
	 * @param numeroVoie
	 * @param ensemble
	 * @param batiment
	 * @param escalier
	 * @param etage
	 * @param porte
	 * @param logo
	 * @param codeInsee
	 * @param ndplp
	 */
	public CloturerTacheManuelleCompAdresseCommande(String tacheId, WfItemData itemData, String libelleVoie, String codeRivoli, String numeroVoie, String ensemble, String batiment, String escalier, String etage, String porte, String logo,
			String codeInsee, String ndplp) {
		super(tacheId, itemData);
		this.libelleVoie = libelleVoie;
		this.codeRivoli = codeRivoli;
		this.numeroVoie = numeroVoie;
		this.ensemble = ensemble;
		this.batiment = batiment;
		this.escalier = escalier;
		this.etage = etage;
		this.porte = porte;
		this.logo = logo;
		this.codeInsee = codeInsee;
		this.ndplp = ndplp;
	}

	public String getBatiment() {
		return this.batiment;
	}

	public String getCodeInsee() {
		return this.codeInsee;
	}

	public String getCodeRivoli() {
		return this.codeRivoli;
	}

	public String getEnsemble() {
		return this.ensemble;
	}

	public String getEscalier() {
		return this.escalier;
	}

	public String getEtage() {
		return this.etage;
	}

	public String getLibelleVoie() {
		return this.libelleVoie;
	}

	public String getLogo() {
		return this.logo;
	}

	public String getNdplp() {
		return this.ndplp;
	}

	public String getNumeroVoie() {
		return this.numeroVoie;
	}

	public String getPorte() {
		return this.porte;
	}
}
