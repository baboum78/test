/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.ic;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

import javax.ejb.SessionContext;

import com.soliste.bolbec.commun.service.ejb.sb.jms.AlarmLimitedRejectionRollbackHandler;
import com.soliste.bolbec.commun.service.ejb.sb.jms.LimitedRejectionRollbackHandler;
import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.EFBConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.CompletudeRegroupementDTO;
import com.soliste.bolbec.livraison.service.model.EtatCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ICInjectionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdCatalogueDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.StatutCommandeDTO;
import com.soliste.bolbec.livraison.service.model.TraductionCatComDTO;
import com.soliste.bolbec.livraison.service.model.TypeOpPonctuellesDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamic;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.publication.GestionnairePublication;
import com.soliste.bolbec.livraison.service.publication.Notification;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.ic.ICUtil;
import com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil;

import aps.AnomalieConstantes;
import aps.CasMetierConstantes;
import aps.EtatCommandeConstantes;
import aps.PublicationConstantes;
import aps.StatutCommandeConstantes;
import aps.SystemeExterneConstantes;
import aps.TypeOpPonctuellesConstantes;
import bolbec.injection.xml.generated.LigneCommandeType;
import bolbec.injection.xml.generated.Message;
import bolbec.injection.xml.generated.ParametreType;

/**
 * Ejb Handler permmettant de traiter un message provenant de la file ICInjection :<br/>
 * - cr�e la commande en base<br/>
 * - instancie le processus cot� workflow<br/>
 * - gestiondes commandes mixtes
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>21/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>23/11/2010</TD><TD>CCL</TD><TD>IRMA923: Prise en compte de la r�-injection de commande pour une commande annul�e</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>GPA</TD><TD>Suppression des appels � la classe IdGenerator</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>15/06/2011</TD><TD>GPA</TD><TD>G�n�rer une Commande Mixte "OPIM-OPOM" pour mise en livraison unifi�e</TD></TR>
 * <TR><TD>04/10/2012</TD><TD>FTE</TD><TD>EV190 : Offre VDSL2</TD></TR>
 * <TR><TD>28/05/2013</TD><TD>GPA</TD><TD>G8R2C2 : Suppression du TRT_AbandonExterne</TD></TR>
 * <TR><TD>23/10/2013</TD><TD>EBA</TD><TD>G9R0C1 : Corrections sonar</TD></TR>
 * <TR><TD>07/09/2015</TD><TD>GCL</TD><TD>EV-000278_15 : Mise en quarantaine - Modification du traitement pour les cas de migration RTC vers Net</TD></TR>
 * <TR><TD>24/11/2015</TD><TD>JDE</TD><TD>EV-000278_17 : Mise en quarantaine</TD></TR>
 * <TR><TD>17/03/2020</TD><TD>AGA</TD><TD>US814 : Doublon Grafic</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.620</TD><TD>Func - EP040 - G�n�rer une Commande Mixte � OPIM-OPOM � pour mise en livraison unifi�e</TD></TR>
 * <TR><TD>REQ.5796</TD><TD>Func � EP0165 � Accepter une commande VDSL avec une r�f�rence externe existante</TD></TR>
 * </TABLE>
 */
public class ReceptionCdeMessageHandlerBean extends AbstractMessageHandlerBean {

	private static final String CLASS_NAME = ReceptionCdeMessageHandlerBean.class.getName();

	private static final Log LOG = new Log(ReceptionCdeMessageHandlerBean.class);

	/** Emetteurs faisant l'objet d'une r�gulation */
	private static final String ID_EMETTEUR_SAGIC = "SAGIC";
	private static final String ID_EMETTEUR_EFB = "EFB";

	/** Le service manager */
	protected static IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * Initialisation des d�l�gu�s selon le message
	 * 
	 * @param message Contenu du message
	 */
	protected void initReceiver(@SuppressWarnings("unused") Serializable message) {
	}

	/**
	 * <BR>
	 * <B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>23/11/2010</TD><TD>CCL</TD><TD>IRMA923: Prise en compte de la r�-injection de commande pour une commande annul�e</TD></TR>
	 * <TR><TD>04/10/2012</TD><TD>FTE</TD><TD>EV190 : Offre VDSL2</TD></TR>
	 * <TR><TD>28/05/2013</TD><TD>GPA</TD><TD>G8R2C2 : Suppression du TRT_AbandonExterne</TD></TR>
	 * </TABLE>
	 * <BR>
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#processMessage(java.io.Serializable, CommandeDTO)
	 *
	 * Cette class re�oit l'IC interne d'bolbec, la commande a d� �tre cr�e au moment de la reception du message de l'emetteur,
	 * donc la m�thode create commande va retourner null et ce null c'est l'entr�e de cette m�thode (commandeDTOVide va �tre toujours null)
	 *
	 */
	public void processMessage(Serializable msg, CommandeDTO commandeDTOVide) throws InvalidJmsMessageException {
		long begin = System.currentTimeMillis();
		if (!(msg instanceof Map<?, ?>)) {
			throw new InvalidJmsMessageException("Le message n'est pas une Map");
		}
		CommandeDTO commandeDTO = null;
		// resetRejectCounter indique s'il faut remettre � 0 le rejectCounter.
		// on remet le rejectCounter � 0 si le message courant ne cause pas de rollback
		boolean resetRejectCounter = true;
		try {
			// traitement
			@SuppressWarnings("unchecked")
			ICInjectionDTO injectionDTO = new ICInjectionDTO((Map<String, String>) msg);
			try {
				// On fait le unmarshal du corps du message
				Message messageXml = ICUtil.unmarshalMessageBody(injectionDTO.getMessage());

				LOG.metro("'ReceptionIC' REFEXTERNE = " + messageXml.getCommande().getIdCommande() + " date = " + begin);

				delayForWorkflow(messageXml);

				String instanceLocalisationId = injectionDTO.getInstanceLocalisation();

				String idCommande = injectionDTO.getIdCommande();

				CommandeDTO nouvelleCommande = null;
				//Si le message d'injection a la donn�e idCommande, on recup�re cette commande
				if (org.apache.commons.lang.StringUtils.isNotBlank(idCommande)) {
					nouvelleCommande = serviceManager.getCommandeManager().getCommande(idCommande);
				}

				// C'est une commande, on regarde s'il existe d�ja une commande avec la m�me r�f�rence
				// On a pu recevoir le message plusieurs fois (doublons, message rejet�s...)
				// On regarde s'il y a d'autres commandes avec la m�me r�ference et un �tat <> FO_ACOMP, REJ pour faire les
				// modifications n�cessaires sur cette commande --> la rejeter, cr�er une nouvelle commande...
				String refExterne = ICUtil.getExternalReference(messageXml);
				List<CommandeDTO> commandeDTOList = serviceManager.getCommandeManager().findListCommandesNonAnnByRefExterne(refExterne);
				for (CommandeDTO commande : commandeDTOList) {
					if (commande.getEtatCommande() != null && !EtatCommandeConstantes.FO_ACOMP.equals(commande.getEtatCommande().getId())
							&& !EtatCommandeConstantes.REJ.equals(commande.getEtatCommande().getId())) {
						commandeDTO = commande;
					}
				}
				// Si on n'a pas trouv�e d'autres commandes avec un �tat diff�rent de FO_ACOMP et REJ
				// --> la seule commande trouv�e � l'�tat FO_ACOMP, elle a �t� cr�e avant de l'injection et elle a seulement les donn�es obligatoires
				// --> il faut la modifier avec les donn�es n�cessaires
				if (commandeDTO == null) {
					commandeDTO = nouvelleCommande;
				}

				if (commandeDTO == null || !EtatCommandeConstantes.FO_ACOMP.equals(commandeDTO.getEtatCommande().getId())) {
					// Si non on initalise et sauvegarde la nouvelle commande
					if (commandeDTO == null || estCasMetierPortaSIP(messageXml)) {
						// On sauvegarde la commande dans une nouvelle transaction pour
						// �tre s�r que la commande soit d�finitivement en base m�me en
						// cas d'erreur dans l'instanciation du workflow

						if (commandeDTO == null) {
							//v�rification � faire car, dans le cas de commandes mixtes p.ex., le message ne passe pas par les adaptateurs
							// et la commande do�t �tre cr�e dans l'injecteur.
							commandeDTO = serviceManager.getInjectionCommandeManager().createCommande(messageXml, instanceLocalisationId);
						} else {
							commandeDTO = serviceManager.getInjectionCommandeManager().updateCommande(injectionDTO.getIdCommande(), messageXml, instanceLocalisationId);
						}

						// US-678 Notification de creation
						NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_C, NotificationGeneriqueConstantes.TYPE_CREAT, commandeDTO.getId(), commandeDTO.getId());
						serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);
					}
					// Est-ce que la commande qui existe n'a pas �t� instanci� cot� WF
					else {
						// EV000006: Contr�le du cas m�tier PortaSIP de la commande
						if (!ICUtil.awaitingCreateProcess(commandeDTO)) {
							if (!isVDSLPro(messageXml, msg)) {
								if (!isDeduplicationInhibe(messageXml)) {
									// il s'agit d'un doublon d'injection ou d'une nouvelle tentative
									// alors que le processus de compl�tude a d�j� �t� instanci�
									// consommer le message et mettre fin au traitement
									serviceManager.getLoggerManager().info(CLASS_NAME, "processMessage", "Message est un doublon : " + msg);
									if (nouvelleCommande != null) {
										nouvelleCommande.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
										serviceManager.getInjectionCommandeManager().updateCommandeEtat(nouvelleCommande);
									}
									return;
								}
							}

							// On garde la premi�re commande pour des tests ensuite
							CommandeDTO premiereCommande = commandeDTO;

							// il s�agit d�une nouvelle injection suite � r�-injection ou d�une injection de commande VDSL Pro :
							// une nouvelle commande doit �tre cr��e normalement
							commandeDTO = serviceManager.getInjectionCommandeManager().updateCommande(injectionDTO.getIdCommande(), messageXml, instanceLocalisationId);

							// US-678 Notification de creation
							NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_C, NotificationGeneriqueConstantes.TYPE_CREAT, commandeDTO.getId(), commandeDTO.getId());
							serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

							// RG7 : Identification migration RTC vers NET et r�cup�ration des informations
							identifMigrationRTCVersNet(premiereCommande, commandeDTO);
						} else {
							//Si Commande.EtatCommande = � VALID � ou � ANOINJ �
							//�	passer la commande existante en base � l��tat � ANOINJ �
							//�	passer directement � l�instanciation du processus de compl�tude avec l�id de la commande pr�c�demment r�cup�r�e
							commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.ANOINJ));
							serviceManager.getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
							commandeDTO = nouvelleCommande;
						}
					}
				} else {
					commandeDTO = serviceManager.getInjectionCommandeManager().updateCommande(injectionDTO.getIdCommande(), messageXml, instanceLocalisationId);
					NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_C, NotificationGeneriqueConstantes.TYPE_CREAT, commandeDTO.getId(), commandeDTO.getId());
					serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);
				}

				// La commande est en base. Maintenant on instancie le processus WF
				ICUtil.createProcess(commandeDTO);
				// Une derni�re sauvegarde de la commande

				// Gestion des commandes mixtes
				gererCdesMixtes(commandeDTO);

				// On publie une notification de prise en compte d�une nouvelle commande
				Notification notification = new Notification(PublicationConstantes.ACQ_PEC, commandeDTO.getId());
				GestionnairePublication.publierFromEJB(notification);
			} catch (ReceptionCdeException rce) {
				if (commandeDTO != null) {
					commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
					serviceManager.getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
				}
				serviceManager.getLoggerManager().severe(CLASS_NAME, "processMessage", "Exception dans le traitement du message", rce);
				InjectionCdeUtil.throwExceptionForAnomalie(rce, rce.getId(), msg);
			}
		} catch (RuntimeException e) {
			// si une RuntimeException est lanc�e, alors le traitement va �tre rollback�
			// donc on ne remet pas � 0 le rejectCounter
			resetRejectCounter = false;
			throw e;
		} finally {
			// Si la transaction est marqu�e comme devant �tre rollback�e, on ne remet pas
			// � 0 le rejectCounter
			if (sessionContext.getRollbackOnly()) {
				resetRejectCounter = false;
			}
			if (resetRejectCounter) {
				((LimitedRejectionRollbackHandler) this.rollbackHandler).resetCounter();
			}
			long end = System.currentTimeMillis();
			String messageMetro = "'ReceptionCde' duree = " + (end - begin) + " ms";
			LOG.metro(messageMetro);
		}
	}

	/**
	 * V�rifie si la commande est de type VDSL Pro
	 * 
	 * @param messageXml le message d'injection issu de msg
	 * @param msg le message � traiter
	 * @return true s'il s'agit d'une commande VDSLPro, false si non
	 * 
	 * <BR><BR>
	 * <B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>04/10/2012</TD><TD>FTE</TD><TD>EV190 : Offre VDSL2 - cr�ation de la m�thode</TD></TR>
	 * </TABLE>
	 * <BR>
	 * 
	 */
	protected boolean isVDSLPro(Message messageXml, Serializable msg) {
		if (messageXml.getCommande().getLigneCommandeCount() != 0) {
			// le parcours de la premi�re lc est suffisant
			LigneCommandeType lc = messageXml.getCommande().getLigneCommande()[0];
			for (ParametreType p : lc.getParametreLivraison()) {
				if (StringUtils.equals(EFBConstantes.CODE_STATUT_OP_COMMANDE, p.getCle()) && StringUtils.equals(EFBConstantes.VDSLPRO, p.getValeur())) {
					// Il s�agit d�une injection de commande VDSL Pro pour une migration de ADSL vers
					// VDSL arriv�e simultan�ment avec une commande de migration vers SIP.
					serviceManager.getLoggerManager().info(CLASS_NAME, "isVDSLPro", "Message est une commande VDSL Pro : " + msg);
					return true;
				}
			}
		}
		serviceManager.getLoggerManager().info(CLASS_NAME, "isVDSLPro", "Message n'est pas une commande VDSL Pro : " + msg);
		return false;
	}

	/**
	 * M�thode permettant de v�rifier s'il s�agit d�une injection de portabilit� du ND <BR>
	 * arriv�e simultan�ment avec une commande ou une reprise de livraison d�acc�s de FTTH
	 * 
	 * @param messageXml
	 * @return true si c'est le cas, false sinon
	 * 
	 * <BR><BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>03/10/2012</TD><TD>FTE</TD><TD>EV-0000169:Reprise de commande en KOLIV</TD></TR>
	 * </TABLE>
	 */
	protected boolean estCasMetierPortaSIP(Message messageXml) {
		if (messageXml != null) {
			String casMetier = messageXml.getCommande().getCasMetier();
			if (StringUtils.isNotEmpty(casMetier)) {
				return CasMetierConstantes.SU_PORTA_SIP_FIBRE.equals(casMetier) || CasMetierConstantes.CR_PORTA_SIP_FIBRE.equals(casMetier) || CasMetierConstantes.RECR_PORTA_SIP_FIBRE.equals(casMetier);
			}
		}
		return false;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#rejectMessage(javax.jms.Message, java.lang.String, java.lang.String)
	 */
	protected void rejectMessage(javax.jms.Message message, String causeId, @SuppressWarnings("unused") String diagnostic) {
		try {
			serviceManager.getLoggerManager().severe(CLASS_NAME, "rejectMessage", "Rejet du message : \n" + message);
			InjectionCdeUtil.rejectMessage(message, causeId);
		} catch (Exception ex) {
			serviceManager.getLoggerManager().severe(CLASS_NAME, "rejectMessage", "Erreur grave lors du rejet du message", ex);
			throw new TechnicalBusinessException("RejectMessageException Erreur grave lors du rejet du message", ex);
		}
	}

	@Override
	/**
	 * Cette class re�oit l'IC interne d'bolbec, la commande a d� �tre cr�e au moment de la reception du message de l'emetteur
	 */
	public CommandeDTO getOrCreateCommande(Serializable a_message) throws InvalidJmsMessageException {
		String idCommande = ((Map<String, String>) a_message).get(Constantes.FIELD_ID_COMMANDE);
		if (org.apache.commons.lang.StringUtils.isNotBlank(idCommande)) {
			CommandeDTO commandeDTO = serviceManager.getInjectionCommandeManager().getCommandeById(idCommande);
			if (commandeDTO != null && EtatCommandeConstantes.FO_INIT.equals(commandeDTO.getEtatCommande().getId())){
				commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.FO_ACOMP));
				serviceManager.getInjectionCommandeManager().updateCommandeEtatWithNewTransaction(commandeDTO);
			}
			return commandeDTO;
		}
		return null;
	}

	/**
	 * Delay for workflow.
	 * 
	 * @param message the message
	 * 
	 * <BR><BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/06/2011</TD><TD>GPA</TD><TD>Ajout d'un log dans le catch vide</TD></TR>
	 * </TABLE>
	 */
	private void delayForWorkflow(Message message) {
		String methode = "delayForWorkflow";

		String idEmetteur = message.getIdEmetteur().toUpperCase();
		ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, methode, "Emetteur : " + idEmetteur);
		if (StringUtils.contains(idEmetteur, ID_EMETTEUR_SAGIC) || StringUtils.contains(idEmetteur, ID_EMETTEUR_EFB)) {
			long wfDelay = 0;
			try {
				wfDelay = ServiceManager.getInstance().getWfServices().getDelayBeforeCreateCase();
			} catch (Exception e) {
				throw new ReceptionCdeException("Erreur lors de l'appel � delayForWorkflow", AnomalieConstantes.ERREUR_INTERNE_INJ, e);
			}
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, methode, "d�lai retourn� par Workflow : " + wfDelay);
			if (wfDelay > 0) {
				try {
					Thread.sleep(wfDelay * 1000);
				} catch (InterruptedException e) {
					// ignore
					serviceManager.getLoggerManager().finest(CLASS_NAME, methode, "InterruptedException");
				}
			}
		}
	}

	/**
	 * Gerer cdes mixtes.
	 * 
	 * @param commandeDTO the commande dto
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/06/2011</TD><TD>GPA</TD><TD>EV-000136: gestion des statuts commande MIGRATION VOIX ENTREPRISE</TD></TR>
	 * </TABLE>
	 */
	private void gererCdesMixtes(CommandeDTO commandeDTO) {
		String statutCde = commandeDTO.getStatutCommande().getId();
		String idCde = commandeDTO.getId();
		CommandeManager commandeManager = ServiceManager.getInstance().getCommandeManager();
		if (StatutCommandeConstantes.MIXTE.equals(statutCde)) {
			List<LigneCommandeDTO> ligneCommandeDTOs = commandeManager.findLigneCommandeByCommande(idCde);
			if (!ligneCommandeDTOs.isEmpty()) {
				LigneCommandeDTO ligneCommandeDTO = CollectionUtils.getFirstOrNull(ligneCommandeDTOs);
				Map<String, String> dynamics = ligneCommandeDTO.getDynamicLigneCommandes();
				// R�cup�rer CommandeBD, CommandeHD et IdAccesMixte
				String idCmdBasDebit = dynamics.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_IDCMDORIGINEBD);
				String idCmdHautDebit = dynamics.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_IDCMDORIGINEHD);

				CommandeDTO commandeDTOBasDebit = commandeManager.getCommande(idCmdBasDebit);
				CommandeDTO commandeDTOHautDebit = commandeManager.getCommande(idCmdHautDebit);

				String idAccesMixte = null;
				// R�cup�rer dans une variable nomm�e IdAccesMixte=l1_ligneCommandeBD.<<dynamic>>NDFinalChoisi
				List<LigneCommandeDTO> ligneCommandeDTOBasDebits = commandeManager.findLigneCommandeByCommande(commandeDTOBasDebit.getId());
				if (!ligneCommandeDTOBasDebits.isEmpty()) {
					LigneCommandeDTO ligneCommandeDTOBasDebit = CollectionUtils.getFirstOrNull(ligneCommandeDTOBasDebits);
					Map<String, String> dynamicsBasDebit = ligneCommandeDTOBasDebit.getDynamicLigneCommandes();
					idAccesMixte = dynamicsBasDebit.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_NDFINAL_CHOISI);
				}

				// M�j des commandes CommandeBD et CommandeHD
				commandeDTOBasDebit.setAPourCmdMixteCommande(commandeDTO);
				commandeManager.updateCommandeMixte(commandeDTOBasDebit);
				commandeDTOHautDebit.setAPourCmdMixteCommande(commandeDTO);
				commandeManager.updateCommandeMixte(commandeDTOHautDebit);

				// On enregistre la commande Mixte dans CompletudeRegroupement
				CompletudeRegroupementDTO completudeRegroupementDTO = new CompletudeRegroupementDTO(serviceManager.getGeneratorManager().generateKey());
				completudeRegroupementDTO.setConcerneCommande(commandeDTO);
				completudeRegroupementDTO.setStatutCommande(new StatutCommandeDTO(statutCde));
				completudeRegroupementDTO.setIdAcces(idAccesMixte);
				commandeManager.createCompletudeRegroupement(completudeRegroupementDTO);
			}
		} else if ((StatutCommandeConstantes.MIXTE_THD_PMCTHD.equals(statutCde)) || (StatutCommandeConstantes.MIXTE_PMC_HDMIGVOIX.equals(statutCde))) {
			List<LigneCommandeDTO> ligneCommandeDTOs = commandeManager.findLigneCommandeByCommande(idCde);
			if (!ligneCommandeDTOs.isEmpty()) {
				LigneCommandeDTO ligneCommandeDTO = CollectionUtils.getFirstOrNull(ligneCommandeDTOs);
				Map<String, String> dynamics = ligneCommandeDTO.getDynamicLigneCommandes();
				// R�cup�rer CommandePMC, CommandeHD et IdAccesMixte
				String idCmdPMC = dynamics.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_IDCMDORIGINEPMC);
				String idCmdHautDebit = dynamics.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_IDCMDORIGINEHD);
				CommandeDTO commandeDTOPMC = commandeManager.getCommande(idCmdPMC);
				CommandeDTO commandeDTOHautDebit = commandeManager.getCommande(idCmdHautDebit);

				String idAccesMixte = null;
				// R�cup�rer dans une variable nomm�e IdAccesMixte=l1_ligneCommandeHD.<<dynamic>>NDFinalChoisi
				List<LigneCommandeDTO> ligneCommandeDTOHautDebits = commandeManager.findLigneCommandeByCommande(commandeDTOHautDebit.getId());
				if (!ligneCommandeDTOHautDebits.isEmpty()) {
					LigneCommandeDTO ligneCommandeDTOHautDebit = CollectionUtils.getFirstOrNull(ligneCommandeDTOHautDebits);
					PsSouhaiteDTO psSouhaiteDTO = commandeManager.findPsSouhaiteByLigneCommande(ligneCommandeDTOHautDebit.getId());
					idAccesMixte = psSouhaiteDTO.getNd();
				}

				// M�j des commandes CommandePMC et CommandeHD
				commandeDTOPMC.setAPourCmdMixteCommande(commandeDTO);
				commandeManager.updateCommandeMixte(commandeDTOPMC);
				commandeDTOHautDebit.setAPourCmdMixteCommande(commandeDTO);
				commandeManager.updateCommandeMixte(commandeDTOHautDebit);

				// On enregistre la commande Mixte dans CompletudeRegroupement
				CompletudeRegroupementDTO completudeRegroupementDTO = new CompletudeRegroupementDTO(serviceManager.getGeneratorManager().generateKey());
				completudeRegroupementDTO.setConcerneCommande(commandeDTO);
				completudeRegroupementDTO.setStatutCommande(new StatutCommandeDTO(statutCde));
				completudeRegroupementDTO.setIdAcces(idAccesMixte);
				commandeManager.createCompletudeRegroupement(completudeRegroupementDTO);
			}
		} else if ((StatutCommandeConstantes.MIXTE_THD.equals(statutCde)) || (StatutCommandeConstantes.MIXTE_HDMIGVOIX.equals(statutCde))) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "gererCdesMixtes", "La commande d'id " + idCde + " est une commande mixte " + statutCde);
			List<LigneCommandeDTO> ligneCommandeDTOs = commandeManager.findLigneCommandeByCommande(idCde);
			if (!ligneCommandeDTOs.isEmpty()) {

				// R�cup�rer dans une variable nomm�e ndFinalChoisi=l1_lignesCmdEnCours.<<dynamic>>NDFinalChoisi
				LigneCommandeDTO ligneCommandeDTO = CollectionUtils.getFirstOrNull(ligneCommandeDTOs);
				PsSouhaiteDTO psSouhaiteDTO = commandeManager.findPsSouhaiteByLigneCommande(ligneCommandeDTO.getId());
				String ndARProteur = psSouhaiteDTO.getNd();

				// On enregistre la commande Mixte_THD dans CompletudeRegroupement
				CompletudeRegroupementDTO completudeRegroupementDTO = new CompletudeRegroupementDTO(serviceManager.getGeneratorManager().generateKey());
				completudeRegroupementDTO.setConcerneCommande(commandeDTO);
				completudeRegroupementDTO.setStatutCommande(new StatutCommandeDTO(statutCde));
				completudeRegroupementDTO.setIdAcces(ndARProteur);
				commandeManager.createCompletudeRegroupement(completudeRegroupementDTO);
			}
		} else if (StatutCommandeConstantes.MIXTE_MAITRE.equals(statutCde)) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "gererCdesMixtes", "La commande d'id" + idCde + " est une commande mixte " + statutCde);
			List<LigneCommandeDTO> ligneCommandeDTOs = commandeManager.findLigneCommandeByCommande(idCde);
			if (!ligneCommandeDTOs.isEmpty()) {
				// R�cup�rer dans une variable nomm�e ndFinalChoisi=l1_lignesCmdEnCours.<<dynamic>>NDFinalChoisi
				LigneCommandeDTO ligneCommandeDTO = CollectionUtils.getFirstOrNull(ligneCommandeDTOs);
				Map<String, String> dynamics = ligneCommandeDTO.getDynamicLigneCommandes();
				String ndFinalChoisi = dynamics.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_NDFINAL_CHOISI);

				// On enregistre la commande Mixte_Maitre dans CompletudeRegroupement
				CompletudeRegroupementDTO completudeRegroupementDTO = new CompletudeRegroupementDTO(serviceManager.getGeneratorManager().generateKey());
				completudeRegroupementDTO.setConcerneCommande(commandeDTO);
				completudeRegroupementDTO.setStatutCommande(new StatutCommandeDTO(statutCde));
				completudeRegroupementDTO.setIdAcces(ndFinalChoisi);
				commandeManager.createCompletudeRegroupement(completudeRegroupementDTO);
			}
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(SessionContext sessionContext) {
		super.setSessionContext(sessionContext);
		Integer maxRejectCount = 10;
		try {
			maxRejectCount = (Integer) envContext.lookup("maxRejectCount");
		} catch (Exception e) {
			ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "setSessionContext", "Exception � l'initialisation de maxRejectCount. " + "Utilisation de la valeur par d�faut", e);
		}
		this.rollbackHandler = new AlarmLimitedRejectionRollbackHandler(maxRejectCount, ReceptionCdeRejectCounter.getInstance(), ReceptionCdeAlarmHandler.getInstance());
	}

	/**
	 * Verification de l'inhibition de la d�duplication
	 * 
	 * @param messageXml
	 * @return true si d�duplication inhib�, false sinon
	 */
	protected boolean isDeduplicationInhibe(Message messageXml) {
		List<TraductionCatComDTO> listParam = serviceManager.getTraductionManager().findTraductionCatComByCleAndSystemeExterne(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.CLE_INHIB_DOUBLON);
		for (TraductionCatComDTO traduction : listParam) {
			for (ParametreType paramType : messageXml.getCommande().getParametresCommande()) {
				if (traduction.getValeurArtemis() != null && traduction.getValeurExterne().equals(paramType.getCle()) && traduction.getValeurArtemis().equals(paramType.getValeur())) {
					return true;
				}
			}
		}

		return false;
	}

	/**
	 * RG7 : Identification de la migration RTC vers NET et r�cup�ration des informations
	 * 
	 */
	protected void identifMigrationRTCVersNet(CommandeDTO premiereCommande, CommandeDTO commande) {
		String migrRTCvNET = premiereCommande.getDynamicCommandes().get(ConstantesDynamicCommande.CLE_MIGR_RTC_NET);
		String servSuppBD = premiereCommande.getDynamicCommandes().get(ConstantesDynamic.SERVSUPPBD);
		String contratCommut = premiereCommande.getDynamicCommandes().get(ConstantesDynamicCommande.CLE_CONTRAT_COMMUT);

		if (Constantes.CST_OUI.equals(migrRTCvNET)) {
			commande.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_ACTIVATION_COMMUTATION, Constantes.CST_OUI);
			if (servSuppBD != null) {
				commande.getDynamicCommandes().put(ConstantesDynamic.SERVSUPPBD, servSuppBD);
			}
			if (contratCommut != null) {
				commande.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_CONTRAT_COMMUT, contratCommut);
			}

			// EV-278_17
			List<LigneCommandeDTO> lignesCommande = serviceManager.getCommandeManager().findLigneCommandeByCommande(premiereCommande.getId());
			for (LigneCommandeDTO ldc : lignesCommande) {
				TypeOpPonctuellesDTO typeOpPonctuelles = ldc.getTypeOpPonctuelles();
				if (typeOpPonctuelles != null && TypeOpPonctuellesConstantes.CR.equals(typeOpPonctuelles.getId())) {
					LigneCmdCatalogueDTO ligneCmdCata = ldc.getLigneCmdCatalogue();
					if (ligneCmdCata != null) {
						PsSouhaiteDTO ps = ligneCmdCata.getPsSouhaite();
						if (ps != null) {
							OffreDTO offre = ps.getPorteSurOffre();
							if (offre != null) {
								offre = serviceManager.getOffreManager().getOffreById(offre.getId());
								String valExterne = serviceManager.getTraductionManager().getTraductionCatComArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.OFFRE_PORTA_MARQUAGE, offre.getValeurConstante());
								if (Constantes.CST_OUI.equals(valExterne)) {
									commande.getDynamicCommandes().put(ConstantesDynamicCommande.CLE_PORTA_SIP_CR, Constantes.CST_OUI);
									break;
								}
							}
						}
					}
				}

			}

			// Persistence en base des nouveaux dynamiques
			serviceManager.getCommandeManager().updateDynamicCommande(commande);
		}
	}
}
