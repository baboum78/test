/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

/**
 * Interface pour les infos que doit ramener une requ�te
 * 
 * @author gdzd8490
 * 
 */
public interface SelectedField {

	/**
	 * Renvoie le type de l'attribut
	 * 
	 * @return le type de l'attribut
	 */
	public String getAttributeType();

	/**
	 * Renvoie le nom de l'attribut
	 * 
	 * @return le nom de l'attribut
	 */
	public String getAttributeName();
}
