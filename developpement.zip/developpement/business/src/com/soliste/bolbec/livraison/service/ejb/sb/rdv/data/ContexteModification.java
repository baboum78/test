package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

public class ContexteModification {

	public static final String APPEL_WEBSERVICE_STRING = "WebService";
	public static final String APPEL_IHM_STRING = "IHM";

	private String basicat;

	private String appel;

	/**
	 * 
	 * @param basicat
	 * @param appel
	 */
	public ContexteModification(String basicat, String appel) {
		this.basicat = basicat;
		this.appel = appel;
	}

	public String getAppel() {
		return appel;
	}

	public void setAppel(String appel) {
		this.appel = appel;
	}

	public String getBasicat() {
		return basicat;
	}

	public void setBasicat(String basicat) {
		this.basicat = basicat;
	}
}
