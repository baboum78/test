/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.util.pagination.PaginationCommand;
import com.soliste.bolbec.commun.service.util.pagination.PaginationUtil;
import com.soliste.bolbec.commun.service.util.sort.SortCommand;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.CorbeilleLoadCommand;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleTranslator;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCCorbeilleTranslator;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCFieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCFieldDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc.JDBCFiltreDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.CorbeilleLoaderException;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCCondition;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCDataRetrieverException;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;

/**
 * Impl�mentation du chargement des donn�es JDBC d'une corbeille
 * 
 * @author gdzd8490
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>03/02/2010</TD><TD>DBA</TD><TD>EV-000029: Gestion de plusieurs tris au lieu de 1</TD></TR>
 * <TR><TD>12/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1533 - EV98 - CAS080 - NullPointerException suite � l'application des crit�res de la corbeille de supervision</TD></TR>
 * <TR><TD>21/11/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV-000188 & DE-000516 : Vente FTTH : Tri par EPCidVIA </TD></TR>
 * </TABLE>
 */
public abstract class JDBCLoaderImpl implements CorbeilleLoaderImpl {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#getFieldFactory()
	 */
	public FieldDTOFactory getFieldFactory() {
		return JDBCFieldDTOFactory.getInstance();
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#getFiltreFactory()
	 */
	public FiltreDTOFactory getFiltreFactory() {
		return JDBCFiltreDTOFactory.getInstance();
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#loadSynthesisList(java.util.List, java.util.List, com.soliste.aps.workflow.WfUser)
	 */
	public List<SynthesisData> loadSynthesisList(List<FieldDTO> selectionFilters, List<FiltreDTO> dataFilters, @SuppressWarnings("unused") WfUser user) throws CorbeilleLoaderException {
		try {
			// transformation des filtres en condition JDBC
			List<JDBCCondition> conditions = JDBCLoaderUtil.translateFiltersIntoConditions(dataFilters);
			// r�cup�ration des champs et de leurs noms
			List<JDBCField> fields = new ArrayList<JDBCField>();
			List<String> fieldNames = new ArrayList<String>();
			for (FieldDTO dto : selectionFilters) {
				JDBCField field = ((JDBCFieldDTO) dto).getField();
				fields.add(field);
				fieldNames.add(field.getFullyQualifiedName());
			}
			// les champs du SELECT sont aussi ceux du GROUP BY dans ce cas
			// pr�cis
			List<JDBCField> groupByFields = new ArrayList<JDBCField>(fields);
			// les champs du GROUP BY sont aussi ceux du ORDER BY dans ce cas
			// pr�cis
			List<JDBCField> orderByFields = new ArrayList<JDBCField>(groupByFields);
			// ex�cution de la requ�te JDBC
			List<Map<String, String>> synthesisMaps = loadSynthesis(fields, conditions, orderByFields, groupByFields);
			// transformation en JDBCSynthesisData
			return JDBCLoaderUtil.translateMapsIntoSynthesisData(synthesisMaps, fieldNames);
		} catch (JDBCDataRetrieverException e) {
			throw new CorbeilleLoaderException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#loadItemList(com.soliste.bolbec.livraison.service.ejb.sb.corbeille.CorbeilleLoadCommand, com.soliste.aps.workflow.WfUser)
	 */
	public void loadItemList(CorbeilleLoadCommand corbeilleLoadCommand, @SuppressWarnings("unused") WfUser user) throws CorbeilleLoaderException {
		try {
			SortCommand sortCommand = corbeilleLoadCommand.getSortCommand();
			PaginationCommand paginationCommand = corbeilleLoadCommand.getPaginationCommand();
			List<String> elementsIds = corbeilleLoadCommand.getElementsIds();
			if (elementsIds == null || elementsIds.isEmpty()) {
				// on charge la liste compl�te des ids correspondant � la
				// requ�te si elle ne l'est pas d�j�
				List<JDBCCondition> conditions = JDBCLoaderUtil.translateFiltersIntoConditions(corbeilleLoadCommand.getDataFilters());
				elementsIds = loadElementsIds(conditions, buildOrderByFields(sortCommand));
				corbeilleLoadCommand.setElementsIds(elementsIds);
			}
			if (!elementsIds.isEmpty()) {
				// on calcule les ids � des �l�ments � r�cup�rer selon la page
				// courante
				List<String> elementsToLoadIds = PaginationUtil.subList(elementsIds, paginationCommand);
				// on traduit les donn�es corbeille � afficher en champ jdbc
				List<JDBCField> fields = JDBCLoaderUtil.translateInfosIntoFields(corbeilleLoadCommand.getInfosToLoad());
				// on ajout l'id qu'on doit r�cup�rer dans tous les cas
				fields.add(getIdField());
				// on charge les donn�es correspondant aux champs et aux ids
				// s�lectionn�s
				List<Map<String, String>> loadedElements = loadElements(elementsToLoadIds, fields, buildOrderByFields(sortCommand), buildGroupByFields(fields));
				// on traduit la liste de r�sultats JDBC pour que ces donn�es
				// soient
				// exploitables par les corbeilles
				List<Map<String, String>> translatedElements = JDBCLoaderUtil.translateFieldsIntoInfos(loadedElements);
				// on utilise la facade JDBCData
				List<ItemData> facadeList = getFacadeList(translatedElements);
				// memorisation dans le corbeilleLoadCommand
				corbeilleLoadCommand.setLoadedElements(facadeList);
			} else {
				corbeilleLoadCommand.setLoadedElements(new ArrayList<ItemData>());
			}
		} catch (JDBCDataRetrieverException e) {
			throw new CorbeilleLoaderException(e);
		}
	}

	/**
	 * Contruit des champs pour la clause OrderBy � partir d'une SortCommand
	 * 
	 * @param sortCommand
	 * @return une liste de JDBCField
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>12/04/2011</TD><TD>GPE</TD><TD>BOLBEC-1533 - EV98 - CAS080 - NullPointerException suite � l'application des crit�res de la corbeille de supervision</TD></TR>
	 * </TABLE>
	 */
	protected List<JDBCField> buildOrderByFields(SortCommand sortCommand) {
		// on utilise un Linked set pour �viter les doublons tout en gardant l'ordre (niveau de tri)
		Set<JDBCField> orderByFieldsSet = new LinkedHashSet<JDBCField>();
		if ((sortCommand != null) && (sortCommand.getCriterion() != null)) {
			// EV-000029: Gestion du multi-tri
			String[] criterion = sortCommand.getCriterion();
			int i = 0;
			JDBCField orderBy = null;
			for (String criteria : criterion) {
				if ((criteria != null) && (criteria.trim().length() > 0)) {
					orderBy = JDBCLoaderUtil.translateInfoIntoField(criteria);
					if (orderBy != null) {
						orderByFieldsSet.add(orderBy);
					}
				}
				// il ne devrait pas y avoir, du moins pour le moment, plus de 3 crit�res
				if (i == 2) {
					break;
				}
				i++;
			}
		}
		return new ArrayList<JDBCField>(orderByFieldsSet);
	}

	/**
	 * Contruit des champs pour la clause GroupBy � partir d'une liste de
	 * champs. Si au moins l'un de ces champs comporte une fonction (MAX,
	 * MIN...), la m�thode renvoie la liste des champs qui ne comportent pas de
	 * fonctions. Si aucun champ ne comporte de fonction, la clause GROUP BY
	 * n'est pas n�cessaire donc la m�thode renvoie null.
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>20/11/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV-000188 - Vente FTTH : Tri par EPCidVIA</TD></TR>
	 * </TABLE>
	 * 
	 * @param fields
	 * liste de champs
	 * @return une liste de JDBCField ou null
	 */
	protected List<JDBCField> buildGroupByFields(List<JDBCField> fields) {
		// on utilise un set pour �viter les doublons
		Set<JDBCField> groupByFieldsSet = new HashSet<JDBCField>();
		boolean groupByNeeded = false;
		for (JDBCField field : fields) {
			if (field != null && field.isAggregateFunction()) {
				// au moins un champ comporte une fonction, on doit utiliser la
				// clause group by pour d�terminer la port�e de cette fonction
				groupByNeeded = true;

			} else {
				// on ajoute ce champ pour d�terminer des groupes sur lesquels
				// porteront les �ventuelles fonctions de la clause select
				groupByFieldsSet.add(field);
			}
		}
		if (groupByNeeded) {
			return new ArrayList<JDBCField>(groupByFieldsSet);
		}
		return null;
	}

	/**
	 * Renvoie la liste des lignes de synth�ses correspondant aux crit�res de
	 * recherche pour une corbeille de supervision
	 * 
	 * @param selectFields
	 * champs � r�cup�rer
	 * @param conditions
	 * filtres � appliquer
	 * @param orderByFields
	 * champs pour le tri
	 * @param groupByFields
	 * champ pour le regroupement
	 * @return une liste de JDBCSynthesisData
	 * @throws JDBCDataRetrieverException
	 */
	protected abstract List<Map<String, String>> loadSynthesis(List<JDBCField> selectFields, List<JDBCCondition> conditions, List<JDBCField> orderByFields, List<JDBCField> groupByFields) throws JDBCDataRetrieverException;

	/**
	 * Renvoie la liste des identifiants des �l�ments correspondant aux crit�res
	 * de recherche pour une corbeille de supervision
	 * 
	 * @param dataFilters
	 * les crit�res de filtrage
	 * @param orderByFields
	 * champs pour le tri
	 * @return la liste des identifiants des �l�ments correspondant aux crit�res
	 * de recherche
	 * @throws JDBCDataRetrieverException
	 */
	protected abstract List<String> loadElementsIds(List<JDBCCondition> dataFilters, List<JDBCField> orderByFields) throws JDBCDataRetrieverException;

	/**
	 * Renvoie la liste des �l�ments correspondant aux crit�res de recherche
	 * pour une corbeille de supervision
	 * 
	 * @param elementsToLoadIds
	 * la liste des identifiants des �l�ments � charger
	 * @param fields
	 * les infos (champs) des �l�ments � charger
	 * @param orderByFields
	 * champs pour le tri
	 * @param groupByFields
	 * champs pour le regroupement
	 * @return la liste des �l�ments correspondant aux crit�res de recherche
	 * pour une corbeille de supervision, avec pour chaque �l�ment les
	 * infos correspondant � chaque <code>fields</code>
	 * @throws JDBCDataRetrieverException
	 */
	protected abstract List<Map<String, String>> loadElements(List<String> elementsToLoadIds, List<JDBCField> fields, List<JDBCField> orderByFields, List<JDBCField> groupByFields) throws JDBCDataRetrieverException;

	/**
	 * Utilisation de la facade JDBCData pour les t�ches ou processus
	 * 
	 * @param elements
	 * une liste de JDBCFiltre
	 * @return une liste de JDBCData
	 */
	protected abstract List<ItemData> getFacadeList(List<Map<String, String>> elements);

	/**
	 * Renvoie le champ correspondant � l'identifiant des �l�ments � charger
	 * 
	 * @return le champ correspondant � l'identifiant des �l�ments � charger
	 */
	protected abstract JDBCField getIdField();

	/**
	 * Renvoie une instance d'un traducteur CorbeilleInfo/JDBCField
	 * 
	 * @return une instance d'un traducteur CorbeilleInfo/JDBCField
	 */
	protected CorbeilleTranslator getCorbeilleTranslator() {
		return JDBCCorbeilleTranslator.getInstance();
	}
}
