/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.ArrayList;
import java.util.List;

import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.ProcessusTypeConstantes;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * </TABLE><BR>
 */

/**
 * Factory pour PhaseDTO
 * 
 * @author rgvs7490
 */
public class PhaseDTOFactory {

	private PhaseDTOFactory() {
	}

	/**
	 * 
	 * @param phase
	 * @return
	 */
	public static PhaseDTO create(TacheDTO phase) {
		PhaseDTO dto = new PhaseDTO();

		ProcessusDTO processus = phase.getLancerParProcessus();

		dto.setProcessus(processus);
		dto.setPhase(phase);

		List<EvtDTO> evenements = new ArrayList<EvtDTO>();
		List<ProcessusDTO> sousProcessusList = new ArrayList<ProcessusDTO>();
		String libelle = phase.getLibelle();
		String id = phase.getId();

		ProcessusTypeDTO procType = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, processus.getProcessusType().getId());
		boolean isCompletude = ProcessusTypeConstantes.COMPLETUDE_VALEUR_CONSTANTE.equals(procType.getValeurConstante());

		List<TacheDTO> taches = ServiceManager.getInstance().getProcessusManager().findTacheByLanceParProcessus(processus.getId());
		for (TacheDTO tache : taches) {
			boolean conditionRegroupement = libelle.equals(tache.getLibelle());
			if (isCompletude) {
				conditionRegroupement = id.equals(tache.getId());
			}
			if (conditionRegroupement) {
				List<EvtDTO> evtDTOs = ServiceManager.getInstance().getProcessusManager().findEvtByTache(tache.getId());
				for (EvtDTO evt : evtDTOs) {
					CauseEvenementDTO causeEvtComplete = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseEvenement().getId());
					evt.setCauseEvenement(causeEvtComplete);
					evenements.add(evt);
				}
				List<ProcessusDTO> processusLst = ServiceManager.getInstance().getProcessusManager().findProcessusAppelerParTache(tache.getId());
				for (ProcessusDTO sp : processusLst) {
					ProcessusTypeDTO procTypeComplet = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, sp.getProcessusType().getId());
					sp.setProcessusType(procTypeComplet);
					sousProcessusList.add(sp);
				}

			}
		}

		dto.setEvenements(evenements);
		dto.setSousProcessusList(sousProcessusList);

		return dto;
	}
}
