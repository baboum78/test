/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.gpc;

import java.io.Serializable;

import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionintervention.data.CRInterventionGPC;

public class InjecteurCRIMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable a_message) throws InvalidMessageException {
		ActivationParam l_activationParam = new ActivationParam("Intervention", getIdRequete(a_message));
		return l_activationParam;
	}

	/**
	 * getIdRequete
	 * 
	 * @param a_message message � traiter
	 * @return String
	 */
	private String getIdRequete(Serializable a_message) throws InvalidMessageException {
		CRInterventionGPC l_cri = new CRInterventionGPC((String) a_message);

		return l_cri.getNoMessage();
	}
}
