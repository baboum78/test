/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.data;

import java.util.Date;
import java.util.List;
import java.util.Map;

import aps.TypeRTConstantes;

import com.soliste.bolbec.livraison.service.ejb.sb.api.DataToSet;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.TaskData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesblo.ConstantesIPON;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.RessourceTechDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import com.google.common.base.Strings;

import org.apache.commons.lang.StringUtils;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Commande de cl�ture pour les AVPs Affectation THD
 * 
 */
public class CloturerAvpAffTHDCommande extends CloturerAvpCommande {

	private String oltName;
	private String oltShelf;
	private String oltCard;
	private String oltPort;

	/**
	 * 
	 * @param tacheId
	 * @param info
	 * @param causeEvenementId
	 * @param date
	 * @param itemData
	 * @param oltName
	 * @param oltShelf
	 * @param oltCard
	 * @param oltPort
	 */
	public CloturerAvpAffTHDCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, String oltName, String oltShelf, String oltCard, String oltPort) {
		super(tacheId, info, causeEvenementId, date, itemData);
		this.oltName = oltName.toUpperCase();
		this.oltShelf = oltShelf;
		this.oltCard = oltCard;
		this.oltPort = oltPort;
	}

	public CloturerAvpAffTHDCommande(String tacheId, String info, String causeEvenementId, Date date, WfItemData itemData, List<TaskData> datas) {
		super(tacheId, info, causeEvenementId, date, itemData);
		// Recherche dans les datas fourni les donn�es que l'on souhaite stocker
		if (datas != null) {
			for (TaskData data : datas) {
				if (ConstantesIPON.TAG_OLTNAME.equals(data.getKey()) && !data.getValue().isEmpty()) {
					this.oltName = data.getValue().toUpperCase();
				}
				if (ConstantesIPON.TAG_SHELF.equals(data.getKey()) && !data.getValue().isEmpty()) {
					this.oltShelf = data.getValue();
				}
				if (ConstantesIPON.TAG_CARD.equals(data.getKey()) && !data.getValue().isEmpty()) {
					this.oltCard = data.getValue();
				}
				if (ConstantesIPON.TAG_PORT.equals(data.getKey()) && !data.getValue().isEmpty()) {
					this.oltPort = data.getValue();
				}
			}
		}
	}

	public String getOltName() {
		return oltName;
	}

	public String getOltShelf() {
		return oltShelf;
	}

	public String getOltCard() {
		return oltCard;
	}

	public String getOltPort() {
		return oltPort;
	}

	public void setOltName(String oltName) {
		this.oltName = oltName;
	}

	public void setOltShelf(String oltShelf) {
		this.oltShelf = oltShelf;
	}

	public void setOltCard(String oltCard) {
		this.oltCard = oltCard;
	}

	public void setOltPort(String oltPort) {
		this.oltPort = oltPort;
	}

	public void setDatas(DataToSet dataToSet, List<LigneCommandeDTO> listeLigneCommande) {

		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(this.getTacheId());
		List<InstanceRtDTO> instancesRt = ServiceManager.getInstance().getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processus.getId());
		for (InstanceRtDTO instanceRt : instancesRt) {
			RessourceTechDTO ressourceTech = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, instanceRt.getRessourceTech().getId());
			if (TypeRTConstantes.CSHD_THD.equals(ressourceTech.getTypeRt().getId())) {
				Map<String,String> dynamicRts = instanceRt.getDynamicInstanceRts();
				// Si les donn�es ne sont pas fourni sous forme de data, on reprend par d�faut les valeurs existantes
				if (this.getOltName() == null) {
					setOltName(dynamicRts.get(ConstantesIPON.TAG_OLTNAME));
				}
				if (this.getOltShelf() == null) {
					setOltShelf(dynamicRts.get(ConstantesIPON.TAG_SHELF));
				}
				if (this.getOltCard() == null) {
					setOltCard(dynamicRts.get(ConstantesIPON.TAG_CARD));
				}
				if (this.getOltPort() == null) {
					setOltPort(dynamicRts.get(ConstantesIPON.TAG_PORT));
				}
				break;
			}
		}

		if(dataToSet != null){
			if(dataToSet.getNomOlt() != null){
				setOltName(dataToSet.getNomOlt().toUpperCase());
			}
			if(dataToSet.getChassOlt() != null){
				setOltShelf(dataToSet.getChassOlt());
			}
			if(dataToSet.getCarteOlt() != null){
				setOltCard(dataToSet.getCarteOlt());
			}
			if(dataToSet.getPortOlt() != null){
				setOltPort(dataToSet.getPortOlt());
			}
		}
	}
}
