/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import java.util.List;
import java.util.Map;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfException;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;

/**
 * Facade pour l'utilisation des objets workflow WfActivity
 * 
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>25/02/2010</TD><TD>ALE</TD><TD>EV-000029: Ajout d'un getter sur l'idCommande</TD></TR>
 * <TR><TD>05/11/2012</TD><TD>FTE</TD><TD>EV-000183 � Apostrof</TD></TR>
 * 
 * @author gdzd8490
 * 
 */
public class WfTache extends WfData implements WfItemData {

	/**
	 * 
	 */
	private static final long serialVersionUID = 2395265091946945342L;

	/**
	 * Constructeur
	 * 
	 * @param wfActivity
	 */
	public WfTache(WfActivity wfActivity) {
		this.setWfObject(wfActivity);
		this.setWfExecutionObjectValues(wfActivity.getValues());
	}

	/**
	 * Renvoie les attributs statiques de la t�che
	 * 
	 * @return une liste cle/valeur
	 * @throws DataException
	 */
	public Map<String, List<String>> getStaticAttributes() throws DataException {
		try {
			WfActivity tache = this.getWfObject();
			return tache.getStaticAttributes();
		} catch (WfException e) {
			throw new DataException(e);
		}
	}

	/**
	 * Renvoie la valeur de l'attribut de cle key
	 * 
	 * @param key
	 * @return la valeur de l'attribut de cle key
	 * @throws WfException
	 */
	public List<String> getStaticAttribute(String key) throws WfException {
		WfActivity tache = this.getWfObject();
		return tache.getStaticAttribute(key);
	}

	public WfActivity getWfObject() {
		return (WfActivity) this.wfObject;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#isReservedByAnotherUser()
	 */
	public boolean isReservedByAnotherUser() {
		String status = this.wfObject.getValues().get(WorkflowConstantes.STATUS);
		/*
		 * CODE COMMENTE CAR LA PRESENCE DU CADENAS DE VEROUILLAGE D'UNE TACHE A L'IHM DEPEND UNIQUEMENT DU STATUT DE CETTE TACHE
		 * 
		 * boolean result = false;
		 * boolean reserved = WorkflowConstantes.RUNNING.equals(status);
		 * if (reserved) {
		 * String executedBy = this.wfObject.getValues().get(WorkflowConstantes.AGENT);
		 * WfUser wfUser = this.wfObject.getOwner();
		 * boolean byAnotherUser = !executedBy.equals(wfUser.getId());
		 * result = byAnotherUser;
		 * }
		 * return result;
		 */
		return WorkflowConstantes.RUNNING.equals(status);
	}

	public String getCommandeID() {
		return this.wfObject.getValues().get(WorkflowConstantes.APPLICATION_ID);
	}

}
