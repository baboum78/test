package com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder;

import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import org.codehaus.jackson.map.annotate.JsonSerialize;

import com.soliste.bolbec.commun.service.ConstantesAPI;

/**
 * Modele Ressource Enum ServiceOrderStatus
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>24/11/2015</TD><TD>MFA</TD><TD>Initialisation du Enum StatusAppointmentEnum</TD></TR>
 * <TR><TD>24/02/2017</TD><TD>JDE</TD><TD>Rework de l'API Rest</TD></TR>
 * </TABLE>
 */
@JsonSerialize(include = JsonSerialize.Inclusion.NON_NULL)
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "serviceOrderStatus")
public enum ServiceOrderStatus {

	created(Arrays.asList(ConstantesAPI.CREEE, ConstantesAPI.FO_ACOMP, ConstantesAPI.FO_CREEE, ConstantesAPI.FO_VALID)), inprogress(Arrays.asList(ConstantesAPI.COMP, ConstantesAPI.LIVR)), aborting, aborted(
			Arrays.asList(ConstantesAPI.ANN, ConstantesAPI.REJ)), finished(Arrays.asList(ConstantesAPI.TERM)), unknown;

	private final Set<String> etatsArtemisSet;

	/**
	 * Constructeur ServiceOrderStatus
	 */
	ServiceOrderStatus() {
		this(new HashSet<String>());
	}

	/**
	 * Constructeur ServiceOrderStatus
	 * 
	 * @param etatsArtemisArray
	 */
	ServiceOrderStatus(Collection<String> etatsArtemisArray) {
		etatsArtemisSet = new HashSet<String>(etatsArtemisArray);
	}

	/**
	 * Permet de faire correspondre le statut � l'id
	 * 
	 * @param etatArtemis
	 * @return
	 */
	public static ServiceOrderStatus fromEtatArtemis(String etatArtemis) {
		for (ServiceOrderStatus status : ServiceOrderStatus.values()) {
			if (status.etatsArtemisSet.contains(etatArtemis)) {
				return status;
			}
		}

		return ServiceOrderStatus.unknown;
	}

}
