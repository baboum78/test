package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;

import com.soliste.bolbec.livraison.service.model.CompteRenduDTO;

/**
 * Interface metier de l'ejb <code>CompteRenduSB</code><br/>
 * Permet de rechercher des entit�es li�es � un compte rendu<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public interface ICompteRenduManagerRemote {
	/**
	 * Supprime le compte rendu d'id compteRenduId.
	 * 
	 * @param compteRenduId the compteRendu id
	 */
	void deleteCompteRendu(String compteRenduId) throws RemoteException;

	/**
	 * R�cup�re le CompteRendu d'id compteRenduId
	 * 
	 * @param compteRenduId the compteRenduId
	 * @return compteRendu
	 */
	public CompteRenduDTO getCompteRendu(String compteRenduId) throws RemoteException;

	/**
	 * Cr�� ou mets � jour le compte rendu
	 * 
	 * @param compteRendu
	 * @return le compteRendu cr��
	 */
	CompteRenduDTO createCompteRendu(CompteRenduDTO compteRendu) throws RemoteException;
}
