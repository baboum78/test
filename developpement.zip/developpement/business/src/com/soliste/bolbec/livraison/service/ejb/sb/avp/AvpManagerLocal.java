/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.avp;

import javax.ejb.EJBLocalObject;

/**
 * Interface Local de l'EJB session AvpManagerSB.
 */
public interface AvpManagerLocal extends AvpManager, EJBLocalObject {

}
