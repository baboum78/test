/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

/**
 * $Workfile:   SFAno.java  $
 * $Revision:   1.4  $
 * $Date:   Nov 12 2003 15:31:36  $
 * $Log:   //SRV_BOLBEC/PVCS/00_PVCS_BOLBECG4/archives/developpement/commun/src.lib/bolbec/commun/anomalies/SFAno.java-arc  $
 * 
 *    Rev 1.4   Nov 12 2003 15:31:36   bravent
 * Ajout de la constantes ERREUR_TIMEOUT
 * 
 *    Rev 1.3   Oct 27 2003 08:24:56   adefunti
 * ajout de erreut interne
 * 
 *    Rev 1.2   Oct 21 2003 14:06:14   HBOURDIN
 * modification de la casse des constantes
 * 
 *    Rev 1.1   Oct 08 2003 14:10:04   cbonnard
 * ajout de qq constantes
 * 
 *    Rev 1.0   Oct 06 2003 16:05:02   pmeunier
 * Initial revision.
 * 
 *    Rev 1.0   Oct 06 2003 15:51:44   pmeunier
 * Initial revision.
 * 
 *    Rev 1.0   Sep 26 2003 10:25:08   pmeunier
 * Initial revision.
 */

package com.soliste.bolbec.livraison.service.anomalies;

import aps.AnomalieConstantes;
import aps.TypeAnomalieConstantes;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

public class SFAno {

	public static final String SFANO_KEY = "SFAnoKey";

	public static final String ERREUR_TRADUCTION = AnomalieConstantes.ERREUR_TRADUCTION;
	public static final String ERREUR_LOCALISATION = AnomalieConstantes.ERREUR_LOCALISATION;
	public static final String ERREUR_TECHNIQUE = AnomalieConstantes.ERREUR_TECHNIQUE;
	public static final String ERREUR_PERIMETRESF = AnomalieConstantes.ERREUR_PERIMETRESF;
	public static final String ERREUR_CI = AnomalieConstantes.ERREUR_CI;
	public static final String ERREUR_INTERNE = AnomalieConstantes.ERREUR_INTERNE;
	public static final String ERREUR_INCOHERENCE_DONNEES = AnomalieConstantes.INCOHERENCE_DONNEES;

	public static final String TYPE_AV = TypeAnomalieConstantes.AV;
	public static final String TYPE_DNR = TypeAnomalieConstantes.DNR;
	// EV-000031: Nouveau type d'anomalie g�r� dans le code
	public static final String TYPE_OK = TypeAnomalieConstantes.OK;

	private String id;
	private String nomSF;

	public void setId(String id) {
		this.id = id;
	}

	public void setNomSF(String nomSF) {
		this.nomSF = nomSF;
	}

	public void setInfo(String info) {
		this.info = info;
	}

	private String erreur;
	private String type;
	private String info;

	/**
	 * 
	 * @param a_id
	 * @param a_nomSF
	 * @param a_erreur
	 * @param a_type
	 * @param a_info
	 */
	public SFAno(String a_id, String a_nomSF, String a_erreur, String a_type, String a_info) {
		id = a_id;
		nomSF = a_nomSF;
		erreur = a_erreur;
		type = a_type;
		info = a_info;
	}

	public String getErreur() {
		return erreur;
	}

	public String getId() {
		return id;
	}

	public String getInfo() {
		return info;
	}

	public String getNomSF() {
		return nomSF;
	}

	public String getType() {
		return type;
	}

	public void setErreur(String erreur) {
		this.erreur = erreur;
	}

	public void setType(String type) {
		this.type = type;
	}

}
