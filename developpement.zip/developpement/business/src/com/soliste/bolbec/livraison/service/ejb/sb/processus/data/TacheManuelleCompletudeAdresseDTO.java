/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import com.soliste.bolbec.livraison.service.model.AdresseDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * @author edba8262
 */
public class TacheManuelleCompletudeAdresseDTO extends TacheManuelleDTO {

	private AdresseDTO adresse;
	private String ndplp;

	/**
	 * 
	 */
	TacheManuelleCompletudeAdresseDTO() {

	}

	public String getType() {
		return TACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE;
	}

	public AdresseDTO getAdresse() {
		return this.adresse;
	}

	void setAdresse(AdresseDTO adresse) {
		this.adresse = adresse;
	}

	public String getNdplp() {
		return this.ndplp;
	}

	void setNdplp(String ndplp) {
		this.ndplp = ndplp;
	}

}
