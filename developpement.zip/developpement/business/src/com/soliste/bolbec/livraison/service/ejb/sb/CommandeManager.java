package com.soliste.bolbec.livraison.service.ejb.sb;

import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.ejb.sb.commande.data.InfosComplementairesCommandeDTO;
import com.soliste.bolbec.livraison.service.model.AccesClientDTO;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.BlocNoteDTO;
import com.soliste.bolbec.livraison.service.model.CasMetierDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.CompletudeRegroupementDTO;
import com.soliste.bolbec.livraison.service.model.EpCommercialDTO;
import com.soliste.bolbec.livraison.service.model.InstanceOgDTO;
import com.soliste.bolbec.livraison.service.model.InterferenceDTO;
import com.soliste.bolbec.livraison.service.model.InterlocuteurDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LienOpProgLdcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdCatalogueDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdModParcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCmdSupParcDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.PrestationAFacturerDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusLcDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RapportInterventionDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatDTO;
import com.soliste.bolbec.livraison.service.model.TransitSystStatRegulDTO;

/**
 * Interface metier de l'ejb <code>CommandeManagerSB</code><br/>
 * Permet de rechercher des entit�es li�es � une commande<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>25/02/2010</TD><TD>ALE</TD><TD>EV-000029: Ajout de la commande isMarked pour savoir si une commande doit �tre marqu�e comme annot�e</TD></TR>
 * <TR><TD>27/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>06/12/2010</TD><TD>GPA</TD><TD>EV-000087: Ajout compl�ment de javadoc pour updateDynamicCommande()</TD></TR>
 * <TR><TD>28/02/2010</TD><TD>BPE</TD><TD>EV-000089: Ajout de la m�thode updateOpProgrammeeTypeOPProgrammee</TD></TR>
 * <TR><TD>22/12/2011</TD><TD>GPA</TD><TD>EV-000174: Cr�ation de la m�thode findPsSouhaiteByLigneCommandeCR() et findEpCommercialByLigneCommandeSU()</TD></TR>
 * <TR><TD>12/07/2012</TD><TD>EBA</TD><TD>EV-188 : Ajout du finder findInterventionPlusRecenteByLdc</TD></TR>
 * <TR><TD>19/10/2010</TD><TD>EBA</TD><TD>EV000183 - EB-0058 : Apostrof Corbeille IHM BIS suite � remarque client </TD></TR>
 * <TR><TD>14/02/2013</TD><TD>EBA</TD><TD>G8R2C2 � EV-000210 : Ajout de la m�thode isFTTHEntreprise</TD></TR>
 * <TR><TD>23/09/2013</TD><TD>BPE</TD><TD>G8R2C3 � EV-000264 : Ajout de la m�thode findCommandeByRefeRDV</TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000304 : Fluidification ADSL vers Fibre </TD></TR>
 * <TR><TD>30/07/2014</TD><TD>ASE</TD><TD>EV-000298 - R�siliation acc�s FTTH en cas de porta sortante </TD></TR>
 * <TR><TD>22/07/2016</TD><TD>SDO</TD><TD>EV-392 : D�commissionnement G8</TD></TR>
 * </TABLE>
 * 
 * @author kyrw0678
 * 
 */
public interface CommandeManager {

	/**
	 * R�cup�re une liste de ligne de commande pour un processus donn�
	 * 
	 * @param processusId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByEstLivreParProcessus(String processusId);

	/**
	 * R�cup�re une des lignes de commande pour un processus donn�
	 * 
	 * @param processusId
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByEstLivreParProcessusAndUneSeule(String processusId);

	/**
	 * R�cup�re la ligne de commande pour un reference externe donn�e
	 * (null si non trouv�e)
	 * 
	 * @param refExterne
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByRefExterne(String refExterne);

	/**
	 * R�cup�re la ligne de commande pour un reference externe donn�e et livr�es par un processus en etat non termin�
	 * (null si non trouv�e)
	 * 
	 * @param refExterne
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByRefExterneEtProcessusNonTerm(String refExterne);

	/**
	 * R�cup�re la liste des LigneCommande d'une Commande.
	 * 
	 * @param commandeId the id commande
	 * 
	 * @return Liste de LigneCommandeDTO
	 */
	List<LigneCommandeDTO> findLigneCommandeByCommande(String commandeId);

	/**
	 * R�cup�re la liste des LigneCommande d'un InstanceRT.
	 * 
	 * @param instanceRtId the id instanceRT
	 * 
	 * @return Liste de LigneCommandeDTO
	 */
	List<LigneCommandeDTO> findLigneCommandeByInstanceRT(String instanceRtId);

	/**
	 * R�cup�re la ligne de commande pour l'EpCommercial pass� en param�tre par son id
	 * on essaye de trouver la ligne de commande en passant par LigneCmdModParc (modification)
	 * si non trouv� on essaye en passant par LigneCmdSupParc (suppression)
	 * 
	 * @param epCommercialId the id EpCommercial
	 * 
	 * @return ligneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByEpCommercial(String epCommercialId);

	/**
	 * R�cup�re la ligne de commande pour le PSSouhaite pass� en param�tre par son id
	 * on essaye de trouver la ligne de commande en passant par LigneCmdCatalogue (creation)
	 * si non trouv� on essaye en passant par LigneCmdModParc (modification)
	 * 
	 * @param psSouhaiteId PS souhaite
	 * @return LigneCommandeDTO
	 */
	LigneCommandeDTO findLigneCommandeByPsSouhaite(String psSouhaiteId);

	/**
	 * R�cup�re les lignes de commande correspondant au processus.
	 * 
	 * @param processusId
	 * @return
	 */
	List<LigneCommandeDTO> findLigneCommandeByProcessus(String processusId);

	/**
	 * Mets � jour le jalon d'une liste de ligne de commande
	 * 
	 * @param ligneCommandeDTOs
	 * @param jalonId
	 */
	void updateLigneCommandeJalon(List<LigneCommandeDTO> ligneCommandeDTOs, String jalonId);

	/**
	 * Sauvegarde de la date de fin de la commmande
	 * 
	 * @param ligneCommandeDTO the ligneCommande DTO
	 */
	void updateLigneCommandeDateFin(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Sauvegarde de la date de fin et de l'etat de la ligne de commande.
	 * 
	 * @param ligneCommandeDTO the ligne commande dto
	 */
	void updateLigneCommandeDateFinAndEtat(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les champs <code>dateMadt</code> et <code>dateMes</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeDateMadtAndDateMes(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour le champ <code>dateMesTech</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeDateMesTech(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les champs <code>dateSouhaite</code> et <code>dateContractuelle</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeDateSouhaiteAndDateContractuelle(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les champs <code>dateContractuelle</code> de la ligne de commande
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>20090622</TD><TD>YTR</TD><TD>Nouvelle m�thode de mise � jour d�veloppement EV-000011</TD></TR>
	 * </TABLE>
	 * 
	 * @param ligneCommandeDTOs
	 */
	void updateLigneCommandeDateContractuelle(LigneCommandeDTO ligneCommandeDTOs);

	/**
	 * Mets � jour le champ <code>repartiteur</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeRepartiteur(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour le champ <code>client</code> de la ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeClient(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Cr�e une relation Processus/Ligne de commande.<br/>
	 * Attention il faut que l'id <code>processusLcDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param processusLcDTO the processusLC dto
	 * 
	 * @return processusLcDTO
	 */
	ProcessusLcDTO createProcessusLC(ProcessusLcDTO processusLcDTO);

	/**
	 * R�cup�re une commande � partir de son id commandeId
	 * 
	 * @param commandeId
	 * @return une commande
	 */
	CommandeDTO getCommande(String commandeId);

	/**
	 * R�cup�re la liste des commandes composant la commande mixte pass�e en param�tre
	 * 
	 * @param commandeMixteId the id commande
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeByIdCommandeMixte(String commandeMixteId);

	/**
	 * R�cup�re la liste des CommandeDTO ayant pour commande mixte la commande dont on passe
	 * l'id en param�tre et ayant le statut pass� en param�tre
	 * 
	 * @param commandeId
	 * @param statutId
	 * @return List<CommandeDTO>
	 */
	List<CommandeDTO> findCommandeByIdCommandeMixteEtStatus(String commandeId, String statutId);

	/**
	 * R�cup�re la commande associ�e � un PSSouhait� donn�
	 * 
	 * @param psSouhaiteId
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByPsSouhaite(String psSouhaiteId);

	/**
	 * R�cup�re la commande associ�e � un EPCommercial donn�
	 * 
	 * @param epCommercialId
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByEpCommercial(String epCommercialId);

	/**
	 * R�cup�re la commande associ�e � une ligne de commande donn�e
	 * 
	 * @param ligneCommandeId
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByLigneCommande(String ligneCommandeId);

	/**
	 * R�cup�re la liste des commandes concernant le ND
	 * 
	 * @param nd Le ND
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeByND(String nd);

	/**
	 * R�cup�re la liste des commandes concernant l'acces livraison de la commande et le type acces livraison
	 *
	 * @param accesLivraison acces livraison (ND) de l'acces
	 * @param typeAcces type acces livraison de l'acces
	 *
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeByAccesLivraisonAndTypeAccesLivraison(String accesLivraison, String typeAcces);

	/**
	 * R�cup�re la commande par son Id
	 * 
	 * @param id L'identifiant de la commande
	 * 
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeById(String id);

	/**
	 * R�cup�re la liste de commande en utilisant la ref intervention
	 * 
	 * @param refIntervention La ref intervention � utiliser pour faire la recherche
	 * @return La liste de commande pour cette ref intervention
	 */
	List<CommandeDTO> findCommandeByRefIntervention(String refIntervention);

	/**
	 * R�cup�re la liste de commande en utilisant la r�f�rence eRDV
	 * 
	 * @param refeRDV La ref eRDV � utiliser pour faire la recherche
	 * @return La liste de commande pour cette ref intervention
	 */
	List<CommandeDTO> findCommandeByRefeRDV(String refeRDV);

	/**
	 * R�cup�re la liste des commandes en cours (dont l'�tat vaut COMP ou LIV) concernant le ND
	 * via LigneCmdCatalogue, LigneCmdModParc, LigneCmdSupParc
	 * 
	 * @param nd Le ND
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeEnCoursByND(String nd);

	/**
	 * R�cup�re la liste des commandes (dont l'�tat vaut CREE) concernant le ND
	 * via LigneCmdCatalogue, LigneCmdModParc, LigneCmdSupParc
	 * 
	 * @param nd Le ND
	 * 
	 * @return the list of CommandeDTO
	 */
	List<CommandeDTO> findCommandeEnCoursAVPInterfByND(String nd);

	/**
	 * Find CommandeDTO by refExterne (de commande)
	 * 
	 * @param refExterne
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeByRefExterne(String refExterne);

	/**
	 * Find CommandeDTO by refExterne (de commande)
	 * 
	 * @param refExterne
	 * @return CommandeDTO
	 */
	List<CommandeDTO> findCommandeListByRefExterne(String refExterne);

	/**
	 * Recherche la premiere commande non annul�e et ayant pour ref externe <code>refExterne</code>
	 *
	 * @param refExterne
	 * @return CommandeDTO
	 */
	CommandeDTO findCommandeNonAnnByRefExterne(String refExterne);

	/**
	 * Recherche tous les commandes non annul�es et ayant pour ref externe <code>refExterne</code>
	 *
	 * @param refExterne
	 * @return CommandeDTO
	 */
	List<CommandeDTO> findListCommandesNonAnnByRefExterne(String refExterne);

	/**
	 * Find CommandeDTO by processus.
	 * 
	 * @param processusId
	 * @return la commande
	 */
	CommandeDTO findCommandeByProcessus(String processusId);

	/**
	 * Find CommandeDTO by tache.
	 * 
	 * @param tacheId
	 * @return la commande
	 */
	CommandeDTO findCommandeByTache(String tacheId);


	/**
	 * Find CommandeDTO by interventionId.
	 *
	 * @param interventionId
	 * @return la commande
	 */
	CommandeDTO findCommandeByInterventionId(String interventionId);

	/**
	 * Mets � jour les champs <code>EtatCommande</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeEtat(CommandeDTO commandeDTO);

	/**
	 * Mets � jour les champs <code>RefExterne</code>
	 * 
	 * @param commandeDTO the commande dto
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
	 * </TABLE>
	 */
	void updateCommandeRefExterne(CommandeDTO commandeDTO);

	/**
	 * Mets � jour le champs <code>nombreAvp</code>
	 * 
	 * @param processusId
	 */
	void updateCommandeNombreAvp(String processusId);

	/**
	 * Mets � jour les champs <code>StatutCommande</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeStatut(CommandeDTO commandeDTO);

	/**
	 * Mets � jour les champs <code>dateFinCommande</code>
	 * 
	 * @param commandeDTO the Commande DTO
	 */
	void updateCommandeDateFin(CommandeDTO commandeDTO);

	/**
	 * Mets � jour les champs <code>dateFinCommande</code> et <code>EtatCommande</code>
	 * 
	 * @param commandeDTO the Commande DTO
	 */
	void updateCommandeDateFinAndEtat(CommandeDTO commandeDTO);

	/**
	 * Mets � jour les champs <code>aPourCmdMixteCommande</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeMixte(CommandeDTO commandeDTO);

	/**
	 * Mets � jour le champ <code>IndicateurRegul</code>
	 * 
	 * @param commandeDTO the commande dto
	 */
	void updateCommandeIndicateurRegul(CommandeDTO commandeDTO);

	/**
	 * Sauvegarde la ZoneGeo et la ZoneSI d'une ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeZoneGeoEtZoneSi(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les champs <code>EtatLigneCde</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeEtat(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour le champ <code>Contexte</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeContexte(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour le champ <code>InduiteParLigneCommande</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeInduiteLigneCommande(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les champs <code>AccesLivraison</code> <code>AccesLivraisonOrigine</code> <code>TypeAccesLivraison</code> <code>TypeAccesLivraisonOrigine</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeAccesLivraison(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les champs <code>IndicateurRegul</code> et <code>DateFin</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeIndicateurRegulEtDateFin(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les champs <code>Etat</code>, <code>Jalon</code> et <code>IndicateurRegul</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeEtatEtJalonEtIndicateurRegul(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour le champ <code>NdFinder</code>
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void updateLigneCommandeNdFinder(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Cr�e une ligne de commande
	 * 
	 * @param ligneCommandeDTO the ligneCommande dto
	 */
	void createLigneCommande(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les donn�es dynamiques de la table commande.<br/>
	 * Pour supprimer une valeur en base, mettre null dans la map.
	 * 
	 * @param commandeDTO
	 */
	void updateDynamicCommande(CommandeDTO commandeDTO);

	/**
	 * Mets � jour les donn�es dynamiques de la table intervention.
	 * 
	 * @param interventionDTO
	 */
	void updateDynamicIntervention(InterventionDTO interventionDTO);

	/**
	 * Sauvegarde les champs dynamiques d'une ligne de commande
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateDynamicLigneCommande(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * Mets � jour les donn�es dynamiques de la table PS Souhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updateDynamicPsSouhaite(PsSouhaiteDTO psSouhaiteDTO);

	/**
	 * R�cup�re un psSouhaite � partir de son id psSouhaiteId
	 * 
	 * @param psSouhaiteId
	 * @return un psSouhaite
	 */
	public PsSouhaiteDTO getPsSouhaite(String psSouhaiteId);

	/**
	 * Mets � jour le champ EpCommercial du PS Souhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteEpCommercial(PsSouhaiteDTO psSouhaiteDTO);

	/**
	 * Mets � jour le champ InstanceFT du PS Souhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteInstanceFT(PsSouhaiteDTO psSouhaiteDTO);

	/**
	 * R�cup�re le PsSouhaite li� � la ligne de commande. S'il existe un
	 * LigneCmdCatalogue li� � la ligne de commande, alors le PsSouhaite est
	 * r�cup�r� depuis celui-ci. Sinon, il est r�cup�r� par un LigneCmdModParc
	 * si celui-ci existe.
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * @return PsSouhaiteDTO
	 */
	PsSouhaiteDTO findPsSouhaiteByLigneCommande(String ligneCommandeId);

	/**
	 * R�cup�re le PsSouhaite li� � la ligne de commande s'il existe un
	 * LigneCmdCatalogue li� � la ligne de commande.
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * @return PsSouhaiteDTO
	 */
	PsSouhaiteDTO findPsSouhaiteByLigneCommandeCR(String ligneCommandeId);

	/**
	 * R�cup�re le PsSouhaite fournit par une InstanceFT.
	 * 
	 * @param instanceFTId the instanceFT id
	 * 
	 * @return the psSouhaite
	 */
	PsSouhaiteDTO findPsSouhaiteByFourniParInstanceFT(String instanceFTId);

	/**
	 * Find ps souhaite by acces client.
	 * 
	 * @param accesClientId the acces client id
	 * 
	 * @return the list of PsSouhaiteDTO
	 */
	List<PsSouhaiteDTO> findPsSouhaiteByAccesClient(String accesClientId);

	/**
	 * R�cup�re l'EPCommercial li� � la ligne de commande. S'il existe un
	 * LigneCmdCatalogue li� � la ligne de commande, alors on r�cup�re
	 * l'InstanceOG et � partir de celui-ci, on r�cup�re l'EPCommercial.
	 * S'il existe un LigneCmdModParc, l'EPCommercial est r�cup�r� depuis
	 * celui-ci. Enfin, s'il existe un LigneCmdSupParc, l'EPCommercial est
	 * r�cup�r� depuis celui-ci.
	 * 
	 * @param ligneCommandeId Identifiant de la ligne de commande.
	 * @return EpCommercialDTO
	 */
	EpCommercialDTO findEpCommercialByLigneCommande(String ligneCommandeId);

	/**
	 * R�cup�re l'EPCommercial li� � la ligne de commande de suppression.
	 * S'il existe un LigneCmdSupParc, l'EPCommercial est r�cup�r� depuis celui-ci.
	 * 
	 * @param ligneCommandeSUId Identifiant de la ligne de commande.
	 * @return EpCommercialDTO
	 */
	EpCommercialDTO findEpCommercialByLigneCommandeSU(String ligneCommandeSUId);

	/**
	 * R�cup�re l'ensemble des EpCommercial support� par le PsSouhaite.
	 * (PsSouhaite.MLINK_SUPPORTE_E_P_COMMERCIAL)
	 * 
	 * @param pssSupportId Identifiant du PsSouhaite support
	 * @return List de EpCommercialDTO
	 */
	List<EpCommercialDTO> findEPCommercialByPsSouhaiteSupport(String pssSupportId);

	/**
	 * R�cup�re l'ensemble des EpCommercial support� par le EpCommercial.
	 * (EPCommercial.MLINK_SUPPORTE_E_P_COMMERCIAL)
	 * 
	 * @param epcSupportId Identifiant du EpCommercial support
	 * @return List de EpCommercialDTO
	 */
	List<EpCommercialDTO> findEPCommercialByEpCommercialSupport(String epcSupportId);

	/**
	 * Supprimer les donn�es dynamiques d'epCommercial pour un Id d'Ep Commrcial donn�.
	 * 
	 * @param epCommercialId the ep commercial Id
	 */
	void deleteDynamicEpCommercial(String epCommercialId);

	/**
	 * Charge une InterferenceDTO � partir de son id
	 * 
	 * @param interferenceId id de l'interference
	 * @return InterferenceDTO
	 */
	InterferenceDTO getInterference(String interferenceId);

	/**
	 * R�cup�re la liste des interferences relatives � la ligne de commande
	 * 
	 * @param ligneCommandeId Identifiant de la LigneCommande
	 * 
	 * @return List d'InterferenceDTO
	 */
	List<InterferenceDTO> findInterferenceByLigneCommande(String ligneCommandeId);

	/**
	 * R�cup�re la liste des interferences relatives � un nd
	 * via LigneCmdCatalogue, LigneCmdModParc, LigneCmdSupParc
	 * 
	 * @param nd nd
	 * 
	 * @return List d'InterferenceDTO
	 */
	List<InterferenceDTO> findInterferenceByNd(String nd);

	/**
	 * Sauvegarde de la date de fin d'une interference
	 * 
	 * @param interferenceDTO the interference DTO
	 */
	void updateInterferenceDateFin(InterferenceDTO interferenceDTO);

	/**
	 * Cr�e une interference
	 * 
	 * @param interferenceDTO the interference DTO
	 */
	void createInterference(InterferenceDTO interferenceDTO);

	/**
	 * R�cup�re les interf�rences rattach�es � la commande
	 * 
	 * @param commandeId the id commande
	 * 
	 * @return the list of InterferenceDTO
	 */
	List<InterferenceDTO> findInterferenceByCommande(String commandeId);

	/**
	 * Supprime l'interference.
	 * 
	 * @param interferenceId the interference id
	 */
	void deleteInterference(String interferenceId);

	/**
	 * Cr�e un CompletudeRegroupement
	 * 
	 * @param completudeRegroupement
	 */
	CompletudeRegroupementDTO createCompletudeRegroupement(CompletudeRegroupementDTO completudeRegroupement);

	/**
	 * Recherche d'une liste de CompletudeRegroupement pour la commande pass�e en param�tre
	 * 
	 * @param commandeId the id commande
	 */
	List<CompletudeRegroupementDTO> findCompletudeRegroupementByCommande(String commandeId);

	/**
	 * Recherche d'une liste de CompletudeRegroupement tel que CompletudeRegroupement.IDACCES = idAccess ET CompletudeRegroupement.FK_ESTDANSSTATUTCOMMANDE = idStatutCde pass�es en param�tres
	 * 
	 * @param idAcces the nd
	 * @param statutCde the StatutCde id
	 */
	List<CompletudeRegroupementDTO> findCompletudeRegroupementByIdAccesEtStatutCde(String idAcces, String statutCde);

	/**
	 * Recherche d'une liste de CompletudeRegroupement tel que CompletudeRegroupement.IDACCES = idAccess
	 * 
	 * @param idAcces the nd
	 */
	List<CompletudeRegroupementDTO> findCompletudeRegroupementByIdAcces(String idAcces);

	/**
	 * Supprime un CompletudeRegroupement pour la commande pass�e en param�tre
	 * 
	 * @param commandeId the id commande
	 */
	void deleteCompletudeRegroupementByCommande(String commandeId);

	/**
	 * Supprime un CompletudeRegroupement tel que CompletudeRegroupement.FK_LIEHDCOMMANDE = commandeId pass�e en param�tre
	 * 
	 * @param commandeId the id commande
	 */
	void deleteCompletudeRegroupementByLieHDCommande(String commandeId);

	/**
	 * Supprime un CompletudeRegroupement tel que CompletudeRegroupement.FK_LIEHDCOMMANDE = commandeId ET CompletudeRegroupement.IDACCES = idAccess ET CompletudeRegroupement.FK_ESTDANSSTATUTCOMMANDE = idStatutCde pass�es en param�tres
	 * 
	 * @param commandeId the id commande
	 * @param idAccess the nd
	 * @param idStatutCde the StatutCde id
	 */
	void deleteCompletudeRegroupementByCommandeEtIdAccesEtStatutCde(String commandeId, String idAccess, String idStatutCde);

	/**
	 * R�cup�re la liste des TransitSystStatRegul pour une commande.
	 * 
	 * @param idCommande the id commande
	 * @param codeTransfert the code transfert
	 * 
	 * @return the list of TransitSystStatRegulDTO
	 */
	List<TransitSystStatRegulDTO> findTransitSystStatRegulByCmdAndCdTransfert(String idCommande, String codeTransfert);

	/**
	 * R�cup�re la liste des TransitSystStatDTO correspondant aux crit�res de recherche pass�s en param�tre
	 * 
	 * @param identite the identite
	 * @param formatExterne the format externe
	 * @param instanceLocalisation the instance localisation
	 * @param codeTransfert the code transfert
	 * 
	 * @return the list of TransitSystStatDTO
	 */
	List<TransitSystStatDTO> findTransitSystStatByIdentFormatInstLocCdTransfert(String identite, String formatExterne, String instanceLocalisation, String codeTransfert);

	/**
	 * Supprime le TransitSystStat du DTO pass� en param�tre.
	 * 
	 * @param transitSystStatDTO the transit syst stat dto
	 */
	void deleteTransitSystStat(TransitSystStatDTO transitSystStatDTO);

	/**
	 * Modifie un CompletudeRegroupement
	 * 
	 * @param completudeRegroupement
	 */
	void updateCompletudeRegroupement(CompletudeRegroupementDTO completudeRegroupement);

	/**
	 * Modifie le statut d'un CompletudeRegroupement
	 * 
	 * @param regroupementCourant
	 */
	void updateCompletudeRegroupementStatut(CompletudeRegroupementDTO regroupementCourant);

	/**
	 * R�cup�re l'intervention la plus r�cente
	 * (par debutPlage) parmi les interventions de la commande pass�e en param�tre.
	 * 
	 * @param commandeId the id commande
	 * 
	 * @return une intervention
	 */
	InterventionDTO findInterventionByCommande(String commandeId);

	/**
	 * Mise � jour des champs suivants de l'intervention:
	 * <ul>
	 * <li>les dynamics</li>
	 * <li>DatePrise, DateEnvoiOt, DebutPlage, FinPlage, Duree</li>
	 * <li>EtatIntervention</li>
	 * <li>RefExterne</li>
	 * <li>Responsabilite</li>
	 * </ul>
	 * 
	 * @param interventionDTO l'intervention
	 */
	void updateIntervention(InterventionDTO interventionDTO);

	/**
	 * R�cup�re une opProgammee � partir de son id opProgrammeeId
	 * 
	 * @param opProgrammeeId
	 * @return une opProgrammee
	 */
	OpProgrammeeDTO getOpProgrammee(String opProgrammeeId);

	/**
	 * Cr�e un opProgrammee. </br>
	 * Attention il faut que l'id <code>opProgrammeeDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param opProgrammeeDTO the opProgrammeeDTO dto
	 * 
	 * @return opProgrammeeDTO
	 */
	OpProgrammeeDTO createOpProgrammee(OpProgrammeeDTO opProgrammeeDTO);

	/**
	 * R�cup�re la liste des OpProgrammeeDTO pour l'intervention dont on passe l'id en param�tre
	 * 
	 * @param interventionId
	 * @return List<OpProgrammeeDTO>
	 */
	List<OpProgrammeeDTO> findOpProgrammeeByIntervention(String interventionId);

	/**
	 * R�cup�re la liste des OpProgrammeDTO pour la ligne de commande dont on passe l'id en param�tre
	 * 
	 * @param ligneCommandeId id de la ligne de commande
	 * @return List<OpProgrammeDTO>
	 */
	List<OpProgrammeeDTO> findOpProgrammeByLigneCommande(String ligneCommandeId);

	/**
	 * R�cup�re la liste des OpProgrammeDTO pour la commande dont on passe l'id en param�tre
	 * 
	 * @param commandeId id de la commande
	 * @return List<OpProgrammeDTO>
	 */
	List<OpProgrammeeDTO> findOpProgrammeeByCommande(String commandeId);

	/**
	 * Charge une InterventionDTO � partir de son id
	 * 
	 * @param interventionId id de l'intervention
	 * @return InterventionDTO
	 */
	InterventionDTO getIntervention(String interventionId);

	/**
	 * M�thode de mise � jour des champs de l'intervention pass�e en param�tre :
	 * <ul>
	 * <li>son etat</li>
	 * <li>la date d'envoi Ot</li>
	 * </ul>
	 * 
	 * @param interventionDTO the intervention
	 */
	void updateInterventionEtatEtDateEnvoiOt(InterventionDTO interventionDTO);

	/**
	 * Supprime l'intervention
	 * 
	 * @param interventionDTO
	 */
	void deleteIntervention(InterventionDTO interventionDTO);

	/**
	 * Cr�e un rapport d'intervention
	 * 
	 * @param rapportInterventionDTO
	 * @param interventionId
	 */
	void createRapportIntervention(RapportInterventionDTO rapportInterventionDTO, String interventionId);

	/**
	 * Mise � jour d'une intervention
	 * <ul>
	 * <li>son etat</li>
	 * <li>son rapport</li>
	 * </ul>
	 * 
	 * @param interventionDTO
	 */
	void updateInterventionEtatEtRapport(InterventionDTO interventionDTO);

	/**
	 * Mise � jour d'une OpProgrammee
	 * - intervention sur laquelle elle porte
	 * 
	 * @param opProgrammeeDTO
	 */
	void updateOpProgrammeeIntervention(OpProgrammeeDTO opProgrammeeDTO);

	/**
	 * Mise � jour d'une OpProgrammee
	 * - typeOPProgrammee sur laquelle elle porte
	 * 
	 * @param opProgrammeeDTO
	 */
	void updateOpProgrammeeTypeOPProgrammee(OpProgrammeeDTO opProgrammeeDTO);

	/**
	 * Cr�ation d'une intervention
	 * 
	 * @param interventionDTO
	 */
	void createIntervention(InterventionDTO interventionDTO);

	/**
	 * Mise � jour d'une intervention
	 * <ul>
	 * <li>etat</li>
	 * </ul>
	 * 
	 * @param interventionDTO
	 */
	void updateInterventionEtat(InterventionDTO interventionDTO);

	/**
	 * R�cup�re les lignes de commande � partir de l'id d'intervention donn�e
	 * (on passe par les op programm�e)
	 * 
	 * @param interventionId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByIntervention(String interventionId);

	/**
	 * R�cup�re les lignes de commande � partir de l'id d'intervention donn�e
	 * (on passe par une op programm�e pour r�cup�rer l'id de commande, puis,
	 * � partir de la commande, on r�cup�re toutes les lignes de commande)
	 * 
	 * @param interventionId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByInterventionViaCommande(String interventionId);

	/**
	 * R�cup�re les lignes de commande � partir de l'id d'op�ration programm�e donn�e.
	 * 
	 * @param opProgrammeeId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeByOpProgrammee(String opProgrammeeId);

	/**
	 * R�cup�re les lignes de commande induites par la ligne de commande pass�e
	 * en param�tre.
	 * 
	 * @param ligneCommandeId
	 * @return List<LigneCommandeDTO>
	 */
	List<LigneCommandeDTO> findLigneCommandeInduiteByLigneCommande(String ligneCommandeId);

	/**
	 * Mise � jou d'une ligne de commande
	 * <ul>
	 * <li>codeFacturationOffre</li>
	 * <li>codeFacturationRemise</li>
	 * </ul>
	 * 
	 * @param ligneCommandeDTO
	 */
	void updateLigneCommandeCodeFacturation(LigneCommandeDTO ligneCommandeDTO);

	/**
	 * R�cup�re une ligne de commande � partir de son id ligneCmdId
	 * 
	 * @param ligneCmdId
	 * @return une ligne de commande
	 */
	LigneCommandeDTO getLigneCommande(String ligneCmdId);

	/**
	 * Find acces client by commande.
	 * 
	 * @param commandeId the commande id
	 * 
	 * @return the list of AccesClientDTO
	 */
	List<AccesClientDTO> findAccesClientByCommande(String commandeId);

	/**
	 * Cr�e une relation Ligne de commande/OpProgrammee.<br/>
	 * Attention il faut que l'id <code>lienOpProgLdcDTO</code> soit renseign� avec la classe <code>CounterManager</code>.
	 * 
	 * @param lienOpProgLdcDTO the lienOpProgLdc dto
	 * 
	 * @return lienOpProgLdcDTO
	 */
	LienOpProgLdcDTO createLienOpProgLdc(LienOpProgLdcDTO lienOpProgLdcDTO);

	/**
	 * Supprime les lien op�ration programm�e / ligne de commande pour l'op programm�e pass� en parametre.
	 * 
	 * @param opProgrammeeId the op programmee id
	 */
	void deleteLienOpProgLdcByOpProgrammee(String opProgrammeeId);

	/**
	 * Mets � jour les donn�es dynamiques de la table epCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateDynamicEpCommercial(EpCommercialDTO epCommercialDTO);

	/**
	 * Supprime la ligne de commande
	 * 
	 * @param ligneCommandeId
	 */
	void deleteLigneCommande(String ligneCommandeId);

	/**
	 * Supprime les ProcessusLC pour la ligne de commande dont l'id est pass� en param�tre
	 * 
	 * @param ligneCommandeId
	 */
	void deleteProcessusLCByLigneCommande(String ligneCommandeId);

	/**
	 * Supprime la LigneCmdSupParc
	 * 
	 * @param ligneCmdSupParcId
	 */
	void deleteLigneCmdSupParc(String ligneCmdSupParcId);

	/**
	 * Find LigneCmdSupParc by epCommercialId.
	 * 
	 * @param epCommercialId
	 * @return the list of LigneCmdSupParcDTO
	 */
	List<LigneCmdSupParcDTO> findLigneCmdSupParcByEpCommercial(String epCommercialId);

	/**
	 * Find LigneCmdModParc by epCommercialId.
	 * 
	 * @param epCommercialId
	 * @return the list of LigneCmdModParcDTO
	 */
	List<LigneCmdModParcDTO> findLigneCmdModParcByEpCommercial(String epCommercialId);

	/**
	 * Supprime l'AccesClient
	 * 
	 * @param accesClientId
	 */
	void deleteAccesClient(String accesClientId);

	/**
	 * Cr�e un AccesClient
	 * 
	 * @param accesClient
	 */
	void createAccesClient(AccesClientDTO accesClient);

	/**
	 * Supprime l'EpCommercial
	 * 
	 * @param epCommercialId
	 */
	void deleteEpCommercial(String epCommercialId);

	/**
	 * Cr�e un EpCommercial
	 * 
	 * @param epCommercial
	 */
	void createEpCommercial(EpCommercialDTO epCommercial);

	/**
	 * Supprime le Client
	 * 
	 * @param clientId
	 */
	void deleteClient(String clientId);

	/**
	 * Cr�e un Client
	 * 
	 * @param client
	 */
	void createClient(ClientDTO client);

	/**
	 * Modifie un Client
	 * 
	 * @param client
	 */
	void updateClient(ClientDTO client);

	/**
	 * Charge le Client correspondant � son id
	 * 
	 * @param clientId
	 * @return the clientDTO
	 */
	ClientDTO getClient(String clientId);

	/**
	 * Cr�ation d'une adresse.
	 * 
	 * @param adresseDTO the adresse dto
	 */
	void createAdresse(AdresseDTO adresseDTO);

	/**
	 * Supprime l'Adresse
	 * 
	 * @param adresseId
	 */
	void deleteAdresse(String adresseId);

	/**
	 * Modifie l'Adresse
	 * 
	 * @param adresseDTO
	 */
	void updateAdresse(AdresseDTO adresseDTO);

	/**
	 * Charge l'Adresse correspondant � son id
	 * 
	 * @param adresseId
	 * @return the adresseDTO
	 */
	AdresseDTO getAdresse(String adresseId);

	/**
	 * Mets � jour les donn�es de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercial(EpCommercialDTO epCommercialDTO);

	/**
	 * Mets � jour le champ InstanceFT de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercialInstanceFT(EpCommercialDTO epCommercialDTO);

	/**
	 * Mets � jour le champ nd de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercialNd(EpCommercialDTO epCommercialDTO);

	/**
	 * Find EpCommercialDTO by idAccesClient
	 * 
	 * @param idAccesClient
	 * @return the list of EpCommercialDTO
	 */
	List<EpCommercialDTO> findEpCommercialByAccesClient(String idAccesClient);

	/**
	 * Find EpCommercialDTO by instanceFT
	 * 
	 * @param instanceFTId
	 * @return the list of EpCommercialDTO
	 */
	List<EpCommercialDTO> findEPCommercialByInstanceFT(String instanceFTId);

	/**
	 * Mets � jour l'accesClient de l'EpCommercial
	 * 
	 * @param epCommercialDTO
	 */
	void updateEpCommercialAccesClient(EpCommercialDTO epCommercialDTO);

	/**
	 * Charge l'EpCommercial correspondant � son Id
	 * 
	 * @param idEpCommercial
	 * @return the EpCommercialDTO
	 */
	EpCommercialDTO getEpCommercial(String idEpCommercial);

	/**
	 * Mets � jour l'accesClient du PsSouhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteAccesClient(PsSouhaiteDTO psSouhaiteDTO);

	/**
	 * Mets � jour l'offre du PsSouhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteOffre(PsSouhaiteDTO psSouhaiteDTO);

	/**
	 * Mets � jour le nd du PsSouhaite
	 * 
	 * @param psSouhaiteDTO
	 */
	void updatePsSouhaiteNd(PsSouhaiteDTO psSouhaiteDTO);

	/**
	 * Cr�e une occurence de PsSouhaite.<br/>
	 * 
	 * @param psSouhaiteDTO the PsSouhaiteDTO
	 * 
	 */
	void createPsSouhaite(PsSouhaiteDTO psSouhaiteDTO);

	/**
	 * Cr�e une occurence de InstanceOg.<br/>
	 * 
	 * @param instanceOgDTO the InstanceOgDTO
	 * 
	 */
	void createInstanceOg(InstanceOgDTO instanceOgDTO);

	/**
	 * Cr�e une occurence de LigneCmdCatalogue.<br/>
	 * 
	 * @param ligneCmdCatalogueDTO the ligneCmdCatalogue dto
	 * 
	 */
	void createLigneCmdCatalogue(LigneCmdCatalogueDTO ligneCmdCatalogueDTO);

	/**
	 * Cr�e une occurence de LigneCmdSuppParc.<br/>
	 * 
	 * @param ligneCmdSupParcDTO the ligneCmdSupParc dto
	 * 
	 */
	void createLigneCmdSupParc(LigneCmdSupParcDTO ligneCmdSupParcDTO);

	/**
	 * R�cup�re le blocNote par son Id
	 * 
	 * @param idBlocNote
	 * @return
	 */
	BlocNoteDTO getBlocNote(String idBlocNote);

	/**
	 * Find BlocNoteDTO by idBlocNote
	 * 
	 * @param idBlocNote
	 * @return
	 */
	BlocNoteDTO findBlocNoteById(String idBlocNote);

	/**
	 * Find BlocNoteDTO by idCommande
	 * 
	 * @param idCommande
	 * @return the list of BlocNoteDTO
	 */
	List<BlocNoteDTO> findBlocNoteByCommande(String idCommande);

	/**
	 * Create the BlocNote.
	 * 
	 * @param blocNoteDTO
	 * @return
	 */
	BlocNoteDTO createBlocNote(BlocNoteDTO blocNoteDTO);

	/**
	 * Update the BlocNote
	 * 
	 * @param blocNoteDTO
	 */
	void updateBlocNote(BlocNoteDTO blocNoteDTO);

	/**
	 * Find InterventionDTO by idProcessus
	 * 
	 * @param idProcessus
	 * @return the list of InterventionDTO
	 */
	List<InterventionDTO> findInterventionByProcessus(String idProcessus);

	/**
	 * Retourne l'intervention la plus r�cente trouv� � partir de l'id ligne de commande
	 * 
	 * @param idLdc
	 * @return
	 */
	InterventionDTO findInterventionPlusRecenteByLdc(String idLdc);

	/**
	 * Find InterventionDTO by idOpProgrammee
	 * 
	 * @param idOpProgrammee
	 * @return InterventionDTO
	 */
	InterventionDTO findInterventionByOpProgrammee(String idOpProgrammee);

	/**
	 * Find PrestationAFacturerDTO by idLigneCommande
	 * 
	 * @param idLigneCommande
	 * @return the list of PrestationAFacturerDTO
	 */
	List<PrestationAFacturerDTO> findPrestationAFacturerByLigneCommande(String idLigneCommande);

	/**
	 * Cr�e une occurence de PrestationAFacturer.<br/>
	 * 
	 * @param prestationAFacturerDTO the prestationAFacturer dto
	 * 
	 * @return prestationAFacturerDTO
	 */
	PrestationAFacturerDTO createPrestationAFacturer(PrestationAFacturerDTO prestationAFacturerDTO);

	/**
	 * Find Interlocuteur by interventionId
	 * 
	 * @param interventionId
	 * @return InterlocuteurDTO
	 */
	InterlocuteurDTO findInterlocuteurByIntervention(String interventionId);

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>25/02/2010</TD><TD>DBA</TD><TD>IRMA_151: Nouveau find</TD></TR>
	 * </TABLE>
	 * l_casMetier = LienOpProgLdc.Fk_AppartientLigneCommande.IdCommande.FK_SEREFERECASMETIER
	 * pour LienOpProgLdc.Fk_requiereOpProgrammee = Op�ProgIntervention.Id
	 * 
	 * @param opProgrammeeInterventionId L'identifiant de l'OP programmee intervention
	 * @return Le cas m�tier trouv�<BR> Cette m�thode peut remonter une valeur null
	 */
	CasMetierDTO findCasMetierByOpProgrammeeInterventionId(String opProgrammeeInterventionId);

	/**
	 * Retourne les informations compl�mentaires pour la commande identifi�e par
	 * l'ID donn�
	 * 
	 * @param commandeId l'ID de la commande
	 * @return les infos compl�mentaires
	 */
	InfosComplementairesCommandeDTO getInfosComplementairesCommande(String commandeId);

	/**
	 * Recupere les champs dynamiques d'une commande
	 * 
	 * @param commandeId the commande id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsCommande(String commandeId);

	/**
	 * Recupere les champs dynamiques d'une ligne de commande
	 * 
	 * @param ligneCommandeId the ligne commande id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsLigneCommande(String ligneCommandeId);

	/**
	 * Recupere les champs dynamiques d'une intervention
	 * 
	 * @param interventionId the intervention id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsIntervention(String interventionId);

	/**
	 * Recupere les champs dynamiques d'un ep commercial
	 * 
	 * @param epCommercialId the ep commercial id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsEpCommercial(String epCommercialId);

	/**
	 * Recupere les champs dynamiques d'un ps souhaite
	 * 
	 * @param psSouhaiteId the ps souhaite id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsPsSouhaite(String psSouhaiteId);

	/**
	 * Recupere les champs dynamiques d'une intervention
	 * 
	 * @param rapportInterventionId the rapport intervention id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsRapportIntervention(String rapportInterventionId);

	/**
	 * Renvoie true si la commande dont l'id est pass� en param�tre poss�de une note attach�e :
	 * <ul><li>sur la commande</li>
	 * <li>sur une ligne de commande</li>
	 * <li>sur une t�che</li>
	 * <li>sur un processus</li></ul>
	 * 
	 * @param commandeId id de la commande concern�e
	 * @return true si la commande poss�de une note
	 */
	boolean isMarked(String commandeId);

	/**
	 * @param commandeDTO La commande qu'il faut mettre � jour
	 * 
	 */
	void updateCommandeCasMetier(CommandeDTO commandeDTO);

	/**
	 * retourne vrai si le systeme externe de la commande est Frontal
	 * 
	 * @param commandeId
	 * @return
	 */
	boolean isFTTHEntreprise(String commandeId);

	/**
	 * retourne la valeur constante de l'offre
	 * 
	 * @param lcId
	 * @param load
	 * return
	 */
	OffreDTO getOffreForLigneCommandeCRNew(String lcId, boolean... load);

	/**
	 * retourne la valeur constante de l'offre
	 * 
	 * @param lcId
	 * @param load
	 * @return
	 */
	OffreDTO getOffreForLigneCommandeSUNew(String lcId, boolean... load);

	/**
	 * Find CommandeDTO by processus.
	 *
	 * @param processusId
	 * @return la commande
	 */
	CommandeDTO findCommandeByProcessusId(String processusId);

	/**
	 * Find CommandeDTO by tache.
	 *
	 * @param tacheId
	 * @return la commande
	 */
	CommandeDTO findCommandeByTacheId(String tacheId);

	/**
	 * Find CommandeDTO by EvtId.
	 *
	 * @param evtId
	 * @return la commande
	 */
	CommandeDTO findCommandeByEvtId(String evtId);

}
