package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.apache.commons.lang.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.Constantes;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.api.util.autorisation.AutorisationUtil;
import com.soliste.bolbec.livraison.api.util.autorisation.AutorisationUtilImpl;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager;
import com.soliste.bolbec.livraison.service.ejb.sb.WfServices;
import com.soliste.bolbec.livraison.service.ejb.sb.api.utils.ServiceOrderUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCause;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.ServiceOrderStatus;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.ServiceOrderRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.ServiceOrder;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.ProcessusTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.AbandonnerProcessusException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.publication.INotificationGeneriqueManager;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.stepauto.traitements.IInterventionManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.JalonConstantes;

/**
 * The Class ServiceOrderRessourceTraitementV2.
 */
public class ServiceOrderRessourceTraitementV2 extends ServiceOrderRessourceTraitement {

	private final static String DEG_E = "DEG_E";
	private final static String HABILITATION_DEG_E = "OuvrirCommandesCasMetierDEG_E";
	private final CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
	private final ProcessusManager PROCESSUS_MANAGER = ServiceManager.getInstance().getProcessusManager();
	private final IInterventionManager INTERVENTION_MANAGER = ServiceManager.getInstance().getInterventionManager();
	private final INotificationGeneriqueManager NOTIFICATION_GENERIQUE_MANAGER = ServiceManager.getInstance().getNotificationGeneriqueManager();
	private final WfServices WFSERVICES = ServiceManager.getInstance().getWfServices();

	/**
	 * getCommande
	 * Permet d'obtenir la commande en fonction de son id.
	 * 
	 * @param idCommande
	 * @param context
	 * @return
	 */
	public Response getCommande(String idCommande, @SuppressWarnings("unused") MessageContext context) {
		if (idCommande == null) {
			throw APIExceptionEnum.serviceorderidnull.createAPIException();
		}
		final CommandeDTO commande = COMMANDE_MANAGER.findCommandeById(idCommande);

		// Commande non trouv�e --> 404
		if (commande == null) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(idCommande);
		}

		ServiceOrder serviceOrder = ServiceOrderUtils.initialiserServiceOrderV2ViaCommande(commande);

		return Response.ok(serviceOrder).build();
	}

	/**
	 * Gets the service orders from commandes.
	 *
	 * @param commandeDTOs the commande DT os
	 * @return the service orders from commandes
	 */
	private static List<ServiceOrder> getServiceOrdersFromCommandes(List<CommandeDTO> commandeDTOs) {
		List<ServiceOrder> serviceOrderlst = new ArrayList<ServiceOrder>();

		for (CommandeDTO commande : commandeDTOs) {
			ServiceOrder serviceOrderCommande = ServiceOrderUtils.initialiserServiceOrderV2ViaCommande(commande);
			serviceOrderlst.add(serviceOrderCommande);

			CommandeDTO commandeMixte = commande.getAPourCmdMixteCommande();
			if (commandeMixte != null) {
				ServiceOrder serciceOrderCommandeMixte = ServiceOrderUtils.initialiserServiceOrderV2ViaCommande(commandeMixte);
				serviceOrderlst.add(serciceOrderCommandeMixte);
			}
		}
		// EV-469 QC-955 suppression des doublons
		Set<ServiceOrder> serviceOrderHashSet = new HashSet<ServiceOrder>(serviceOrderlst);
		serviceOrderlst.clear();
		serviceOrderlst.addAll(serviceOrderHashSet);

		return serviceOrderlst;
	}

	/**
	 * Permet d'obtenir les commandes en fonction de l'id d'intervention de l'id externe.
	 * 
	 * @param appointmentId
	 * @param externalId
	 * @param context
	 * @return
	 */
	@Override
	public Response getCommandes(String appointmentId, String externalId, @SuppressWarnings("unused") MessageContext context) {

		if (appointmentId == null && externalId == null) {
			throw APIExceptionEnum.serviceorderappointmentidandexternalidnull.createAPIException();
		}

		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();

		// 1) cas intervention=null
		if (appointmentId == null) {
			commandeDTOs = COMMANDE_MANAGER.findCommandeListByRefExterne(externalId);
			// Commande non trouv�e --> 404
			if (commandeDTOs.isEmpty()) {
				throw APIExceptionEnum.serviceordernotfoundwithexternalid.createAPIException(externalId);
			}
		}

		// 2) cas refExterne=null
		else if (externalId == null) {
			List<LigneCommandeDTO> lgncommandeDTOs = COMMANDE_MANAGER.findLigneCommandeByIntervention(appointmentId);

			for (LigneCommandeDTO lgncommande : lgncommandeDTOs) {
				CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByLigneCommande(lgncommande.getId());
				commandeDTOs.add(commandeDTO);
			}
			if (commandeDTOs.isEmpty()) {
				throw APIExceptionEnum.serviceordernotfoundwithappointmentid.createAPIException(appointmentId);
			}
		}

		// 3) Cas o� les 2 param sont non nuls
		else {
			List<CommandeDTO> commandeApps = ServiceOrderUtils.findCommandeByIdIntervention(appointmentId);
			List<CommandeDTO> commandeExts = COMMANDE_MANAGER.findCommandeListByRefExterne(externalId);
			commandeDTOs = ServiceOrderUtils.comparerListeEtGarderDoublons(commandeApps, commandeExts);

			if (commandeDTOs.isEmpty()) {
				throw APIExceptionEnum.serviceorderappointmentandexternalnull.createAPIException(externalId, appointmentId);
			}
		}

		List<ServiceOrder> serviceOrderlst = getServiceOrdersFromCommandes(commandeDTOs);

		return Response.ok(serviceOrderlst).build();
	}

	/**
	 * patchCommande
	 * Permet l'abandon de la commande.
	 * 
	 * @param idCommande
	 * @param serviceOrder
	 * @param context
	 * @return
	 */
	public Response abandonnerCommande(String idCommande, ServiceOrder serviceOrder, MessageContext context) {

		final CommandeDTO commande = COMMANDE_MANAGER.findCommandeById(idCommande);
		// Commande non trouv�e --> 404
		if (commande == null) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(idCommande);
		}

		AutorisationUtil autorisationUtil = new AutorisationUtilImpl();
		final AgentDTO agent = autorisationUtil.getCurrentAgentFromMessageContext(context);
		// Si l'agent n'est pas habilit� --> Forbidden
		Set<String> habilitationsNecessaires = new HashSet<String>();
		habilitationsNecessaires.add(HABILITATION_DEG_E);
		if (autorisationUtil.isHabilitated(habilitationsNecessaires, agent) && !DEG_E.equals(commande.getCasMetier().getId())) {
			return Response.status(Status.FORBIDDEN).build();
		}

		final ServiceOrderStatus statusDemande = serviceOrder.getState();

		if (ServiceOrderStatus.unknown.equals(statusDemande)) {
			throw APIExceptionEnum.serviceorderbadstatus.createAPIException();
		}

		if (serviceOrder.getAbortEventCause() == null || !ServiceOrderStatus.aborted.equals(statusDemande)) {
			throw APIExceptionEnum.serviceorderabortmalformed.createAPIException();
		}

		ServiceOrderStatus statusCommandeActuelle = ServiceOrderUtils.determinerStatut(commande);

		// EV-469 Si la commande est � l'�tat TERM, anomalie 422,1 not found
		if (statusCommandeActuelle == ServiceOrderStatus.finished) {
			throw APIExceptionEnum.serviceordernotfound.createAPIException(idCommande);
		}

		// EV-469 Si la commande n'est ni in progress, ni created
		if ((statusCommandeActuelle != ServiceOrderStatus.inprogress) && (statusCommandeActuelle != ServiceOrderStatus.created)) {
			throw APIExceptionEnum.serviceorderisnotinprogress.createAPIException(idCommande);
		}

		if (StringUtils.isBlank(serviceOrder.getAbortEventCause().getId())) {
			throw APIExceptionEnum.serviceordernotfoundeventcause.createAPIException(idCommande);
		}

		final ProcessusDTO processusDTO = PROCESSUS_MANAGER.findProcessusByCommandeIdAndEtatProcessusAndGenereParProcessus(idCommande);
		if (processusDTO == null) {
			throw APIExceptionEnum.serviceorderandprocessnotlinked.createAPIException(idCommande);
		}

		List<EventCause> eventlst;
		try {
			eventlst = ServiceOrderUtils.getCauseEvenementAutoriseesPourCloturer(processusDTO);
		} catch (DataException e) {
			throw APIExceptionEnum.serviceordernotfoundeventcause.createAPIException(idCommande);
		}

		// EV-469 : ajout des causes abandon g�n�riques � la liste des �v�nements possibles d'abandon
		List<EventCause> eventLstAbdGen = ServiceOrderUtils.getCauseEvenementAbandonGeneriques(commande.getVersionArtemis());
		eventlst.addAll(eventLstAbdGen);

		if (!ServiceOrderUtils.estDansListeCausePossiblePourAbandon(eventlst, serviceOrder.getAbortEventCause())) {
			throw APIExceptionEnum.serviceordercausenotallowed.createAPIException(idCommande);
		}

		// EV-469 Si le jalon de la commande est J_MES et qu'une intervention existe,
		// anomalie "Commande avec intervention r�alis�e et termin�e"
		final List<LigneCommandeDTO> listeLC = COMMANDE_MANAGER.findLigneCommandeByCommande(commande.getId());
		final LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(listeLC);
		if ((premiereLC != null) && JalonConstantes.J_MES.equals(premiereLC.getJalon().getId())) {
			final Collection<InterventionDTO> listeIntervention = INTERVENTION_MANAGER.getInterventionsByIdCommande(commande.getId());
			if (!listeIntervention.isEmpty()) {
				throw APIExceptionEnum.serviceorderabandoninterditinterventionterminee.createAPIException();
			}
		}

		final String causeEvenementId = commande.getVersionArtemis() + Constantes.STRING_UNDERSCORE + serviceOrder.getAbortEventCause().getId();
		final WfUser wfU = WFSERVICES.getWfUser(agent);

		String info = "";
		if (serviceOrder.getAbortEventCause().getComment() != null) {
			info = serviceOrder.getAbortEventCause().getComment();
		}

		try {
			ProcessusTraitement.abandonnerProcessus(processusDTO.getId(), info, causeEvenementId, wfU, null, agent);
		} catch (AbandonnerProcessusException e1) {
			throw APIExceptionEnum.serviceorderabandonerror.createAPIException(idCommande);
		} finally {
			// US-678 Notification pour l'abandon
			NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_A,NotificationGeneriqueConstantes.TYPE_ABAN,idCommande,agent.getId(),idCommande);
			NOTIFICATION_GENERIQUE_MANAGER.emettreNotification(ng);
		}

		return Response.status(STATUS_ACCEPTED).build();
	}

}
