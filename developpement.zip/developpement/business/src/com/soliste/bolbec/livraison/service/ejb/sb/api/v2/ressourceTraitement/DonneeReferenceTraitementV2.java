package com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement;

import com.soliste.bolbec.commun.service.model.CategorieClientDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.commun.service.model.ZoneGeographiqueDTO;
import com.soliste.bolbec.commun.service.model.ZoneSiDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.DonneeRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.DonneeRefEnveloppe;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.DonneeRefVal;
import com.soliste.bolbec.livraison.service.model.*;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.Traduction;
import aps.TraductionNotif;

import org.apache.commons.lang3.StringUtils;
import org.apache.cxf.jaxrs.ext.MessageContext;

import java.util.ArrayList;
import java.util.List;

public class DonneeReferenceTraitementV2 {
	// Constantes pour les nom des services API
	protected static final String NOM_ETAT_INTERV = "etatInterv";
	protected static final String NOM_TYPE_EVT = "typeEvt";
	protected static final String NOM_CAUSE_EVT = "causeEvt";
	protected static final String NOM_TACHE = "tache";
	protected static final String NOM_ROLE = "role";
	protected static final String NOM_OFFRE = "offre";
	protected static final String NOM_OPER = "oper";
	protected static final String NOM_SEG_MARCHE = "segMarche";
	protected static final String NOM_PROC_LIV = "procLiv";
	protected static final String NOM_ETAT_CMD = "etatCmd";
	protected static final String NOM_CTXT_LIV = "ctxtLiv";
	protected static final String NOM_ETAT_LC = "etatLC";
	protected static final String NOM_INFO_TECH = "infoTech";
	protected static final String NOM_QUEST = "quest";
	protected static final String NOM_ZONE_SI = "zoneSi";
	protected static final String NOM_ZONE_GEO = "zoneGeo";
	protected static final String NOM_JALON = "jalon";
	protected static final String NOM_ORIG = "orig";
	protected static final String MOTIF_COMMANDE_LIBELLE = "MOTIF_COMMANDE_LIBELLE";
	protected static final String MOTIF_CMD = "motifCmd";

	// Constantes multi gestion
	protected static final String AVP = "AVP";
	protected static final String TYPEDONNEE = "TYPEDONNEE";

	// Constantes pour le gestion de typeEvenement
	protected static final String POPAV = "POPAV";
	protected static final String POPBQ = "POPBQ";
	protected static final String POPCHX = "POPCHX";
	protected static final String WARAV = "WARAV";
	protected static final String WARBQ = "WARBQ";
	protected static final String WARBQ_SS_GEST_TO = "WARBQ_SS_GEST_TO";
	protected static final String WARN = "WARN";
	protected static final String INFO = "INFO";

	// Constantes pour le gestion de tache
	protected static final String AUTO = "AUTO";
	protected static final String AUTO_AUTRE = "AUTO_AUTRE";
	protected static final String MANUELLE = "MANUELLE";
	protected static final String MANUEL = "MANUEL";

	protected IServiceManager serviceManager = ServiceManager.getInstance();

	/**
	 * Recupere en BDD la liste etats possible des interventions et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRefEnveloppe getDonneesReferences(@SuppressWarnings("unused") MessageContext context) {
		ArrayList<DonneeRef> listDonneeRef = new ArrayList<DonneeRef>();

		DonneeRefEnveloppe donneeRefEnveloppe = new DonneeRefEnveloppe();

		// Appel a toutes les autres methodes
		DonneeRef donneRefIntervention = getEtatIntervention(context);
		DonneeRef donneRefTypeEvenement = getTypeEvenement(context);
		DonneeRef donneRefCauseEvenement = getCauseEvenement(context);
		DonneeRef donneRefTache = getTache(context);
		DonneeRef donneRefRole = getRole(context);
		DonneeRef donneRefOffre = getOffre(context);
		DonneeRef donneRefOper = getOper(context);
		DonneeRef donneRefSegMarche = getSegMarche(context);
		DonneeRef donneRefProcLiv = getProcLiv(context);
		DonneeRef donneRefEtatCmd = getEtatCmd(context);
		DonneeRef donneRefCtxtLiv = getCtxtLiv(context);
		DonneeRef donneRefEtatLC = getEtatLC(context);
		DonneeRef donneRefInfoTech = getInfoTech(context);
		DonneeRef donneRefQuest = getQuest(context);
		DonneeRef donneRefZoneSi = getZoneSi(context);
		DonneeRef donneRefZoneGeo = getZoneGeo(context);
		DonneeRef donneRefJalon = getJalon(context);
		DonneeRef donneRefOrig = getOrig(context);
		DonneeRef donneRefMotifCmd = getMotifCmd(context);

		// Valorisation des donnees ref
		listDonneeRef.add(donneRefIntervention);
		listDonneeRef.add(donneRefTypeEvenement);
		listDonneeRef.add(donneRefCauseEvenement);
		listDonneeRef.add(donneRefTache);
		listDonneeRef.add(donneRefRole);
		listDonneeRef.add(donneRefOffre);
		listDonneeRef.add(donneRefOper);
		listDonneeRef.add(donneRefSegMarche);
		listDonneeRef.add(donneRefProcLiv);
		listDonneeRef.add(donneRefEtatCmd);
		listDonneeRef.add(donneRefCtxtLiv);
		listDonneeRef.add(donneRefEtatLC);
		listDonneeRef.add(donneRefInfoTech);
		listDonneeRef.add(donneRefQuest);
		listDonneeRef.add(donneRefZoneSi);
		listDonneeRef.add(donneRefZoneGeo);
		listDonneeRef.add(donneRefJalon);
		listDonneeRef.add(donneRefOrig);
		listDonneeRef.add(donneRefMotifCmd);

		donneeRefEnveloppe.setDonneeRef(listDonneeRef);

		return donneeRefEnveloppe;
	}

	/**
	 * Recupere en BDD la liste etats possible des interventions et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getEtatIntervention(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_ETAT_INTERV));

		List<EtatInterventionDTO> listEtatIntervention = serviceManager.getReferenceSpaceManager().listInReferenceSpace(EtatInterventionDTO.class);

		return valorisationEtatIntervention(listEtatIntervention, listTraductionNotif);
	}

	/**
	 * Valorise la liste des etats possible des interventions dans le POJO donneeRed
	 *
	 * @param listEtatIntervention
	 * @return
	 */
	protected DonneeRef valorisationEtatIntervention(List<EtatInterventionDTO> listEtatIntervention, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();

		donneeRef.setNom(NOM_ETAT_INTERV);

		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();
		for (EtatInterventionDTO etatIntervention : listEtatIntervention) {

			// RTR1 : traduction de l identifiant
			// RTR2 : traduction des libelles
			DonneeRefVal val = valorisationEtatInterventionUnitaire(listTraductionNotif, etatIntervention);

			listVal.add(val);
		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise un etat possible des interventions dans le POJO donneeRed
	 *
	 * @param listTraductionNotif
	 * @param etatIntervention
	 * @return
	 */
	protected DonneeRefVal valorisationEtatInterventionUnitaire(List<TraductionNotifDTO> listTraductionNotif, EtatInterventionDTO etatIntervention) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;
		boolean libelleCourtPasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(etatIntervention.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
				if (traductionNotif.getLibelleCourt() != null) {

					val.setLibCourt(traductionNotif.getLibelleCourt());
					libelleCourtPasEncoreValorise = false;
				}

			}
		}
		if (idPasEncoreValorise) {

			val.setId(etatIntervention.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(etatIntervention.getLibelle());

		}
		if (libelleCourtPasEncoreValorise) {

			val.setLibCourt(etatIntervention.getLibelleCourt());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des types d evenements et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getTypeEvenement(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_TYPE_EVT));

		List<TypeEvenementDTO> listTypeEvenement = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TypeEvenementDTO.class);

		return valorisationTypeEvenement(listTypeEvenement, listTraductionNotif);
	}

	/**
	 * Valorise les liste des types d evenements dans le POJO donneeRed
	 *
	 * @param listTypeEvenement
	 * @return
	 */
	protected DonneeRef valorisationTypeEvenement(List<TypeEvenementDTO> listTypeEvenement, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();

		donneeRef.setNom(NOM_TYPE_EVT);

		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();
		for (TypeEvenementDTO typeEvenement : listTypeEvenement) {

			DonneeRefVal val = valorisationUnitaireTypeEvenement(typeEvenement, listTraductionNotif);

			listVal.add(val);
		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise un typeEvenement dans un donneeRefVal unitairement
	 *
	 * @param typeEvenement
	 * @return
	 */
	protected DonneeRefVal valorisationUnitaireTypeEvenement(TypeEvenementDTO typeEvenement, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(typeEvenement.getValeurConstante(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(typeEvenement.getValeurConstante());

		}
		if (libellePasEncoreValorise) {

			val.setLib(typeEvenement.getLibelle());

		}
		if (typeEvenement.getCategorieEvenement() != null && StringUtils.equals(AVP, typeEvenement.getCategorieEvenement().getId())) {

			val.setType(AVP);

		} else if (typeEvenement.getCategorieEvenement() != null && (StringUtils.equals(POPAV, typeEvenement.getCategorieEvenement().getId()) || StringUtils.equals(POPBQ, typeEvenement.getCategorieEvenement().getId())
				|| StringUtils.equals(POPCHX, typeEvenement.getCategorieEvenement().getId()) || StringUtils.equals(WARAV, typeEvenement.getCategorieEvenement().getId()) || StringUtils.equals(WARBQ, typeEvenement.getCategorieEvenement().getId())
				|| StringUtils.equals(WARBQ_SS_GEST_TO, typeEvenement.getCategorieEvenement().getId()))) {

			val.setType(WARN);

		} else {

			val.setType(INFO);

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des cause d evenements et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getCauseEvenement(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_CAUSE_EVT));

		List<CauseEvenementDTO> listCauseEvenement = serviceManager.getReferenceSpaceManager().listInReferenceSpace(CauseEvenementDTO.class);

		return valorisationCauseEvenement(listCauseEvenement, listTraductionNotif);
	}

	/**
	 * Valorise les liste des cause d evenements dans le POJO donneeRed
	 *
	 * @param listCauseEvenement
	 * @return
	 */
	protected DonneeRef valorisationCauseEvenement(List<CauseEvenementDTO> listCauseEvenement, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();

		donneeRef.setNom(NOM_CAUSE_EVT);

		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();
		for (CauseEvenementDTO causeEvenement : listCauseEvenement) {

			DonneeRefVal val = valorisationCauseEvenementUnitaire(listTraductionNotif, causeEvenement);

			listVal.add(val);
		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise une cause d evenements dans le POJO donneeRed
	 *
	 * @param listTraductionNotif
	 * @param causeEvenement
	 * @param val
	 */
	protected DonneeRefVal valorisationCauseEvenementUnitaire(List<TraductionNotifDTO> listTraductionNotif, CauseEvenementDTO causeEvenement) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(causeEvenement.getValeurConstante(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(causeEvenement.getValeurConstante());

		}
		if (libellePasEncoreValorise) {

			val.setLib(causeEvenement.getLibelle());

		}
		return val;

	}

	/**
	 * Recupere en BDD la liste des taches du processus et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getTache(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_TACHE));

		List<CatalogueTacheDTO> listEtatIntervention = serviceManager.getReferenceSpaceManager().listInReferenceSpace(CatalogueTacheDTO.class);

		return valorisationCatalogueTache(listEtatIntervention, listTraductionNotif);
	}

	/**
	 * Valorise la liste taches du processus dans le POJO donneeRed
	 *
	 * @param listCatalogueTache
	 * @return
	 */
	protected DonneeRef valorisationCatalogueTache(List<CatalogueTacheDTO> listCatalogueTache, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_TACHE);

		for (CatalogueTacheDTO catalogueTache : listCatalogueTache) {

			DonneeRefVal val = valorisationCatalogueTacheUnitaire(catalogueTache, listTraductionNotif);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise unitairement les taches du processus
	 *
	 * @param catalogueTache
	 * @return
	 */
	protected DonneeRefVal valorisationCatalogueTacheUnitaire(CatalogueTacheDTO catalogueTache, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(catalogueTache.getValeurConstante(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(catalogueTache.getValeurConstante());

		}
		if (libellePasEncoreValorise) {

			val.setLib(catalogueTache.getNom());

		}

		if (StringUtils.equals(AVP, catalogueTache.getType())) {

			val.setType(AVP);

		} else if (StringUtils.equals(AUTO, catalogueTache.getType()) || StringUtils.equals(AUTO_AUTRE, catalogueTache.getType())) {

			val.setType(AUTO);

		} else if (StringUtils.equals(MANUELLE, catalogueTache.getType())) {

			val.setType(MANUEL);

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des roles metiers et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getRole(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_ROLE));

		List<RoleDTO> listRole = serviceManager.getReferenceSpaceManager().listInReferenceSpace(RoleDTO.class);

		return valorisationRole(listRole, listTraductionNotif);
	}

	/**
	 * Valorise la liste des role metiers dans le POJO donneeRed
	 *
	 * @param listRole
	 * @return
	 */
	protected DonneeRef valorisationRole(List<RoleDTO> listRole, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_ROLE);

		for (RoleDTO role : listRole) {

			DonneeRefVal val = valorisationRoleUnitaire(listTraductionNotif, role);
			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise chaque role metiers dans le POJO donneeRed
	 *
	 * @param listTraductionNotif
	 * @param role
	 * @return
	 */
	protected DonneeRefVal valorisationRoleUnitaire(List<TraductionNotifDTO> listTraductionNotif, RoleDTO role) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(role.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(role.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(role.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des offres d Artemis et les MAP dans le POJO de reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getOffre(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_OFFRE));

		List<OffreDTO> listOffre = serviceManager.getReferenceSpaceManager().listInReferenceSpace(OffreDTO.class);

		return valorisationDonneesRef(listOffre, listTraductionNotif);
	}

	/**
	 * Valorise le POJO de reponse avec les valeurs recuperee de la BDD
	 *
	 * @param listOffre liste des offres recuperee de la BDD
	 * @return
	 */
	protected DonneeRef valorisationDonneesRef(List<OffreDTO> listOffre, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();

		donneeRef.setNom(NOM_OFFRE);

		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();
		for (OffreDTO offre : listOffre) {

			DonneeRefVal val = valorisationDonneesRefUnitaire(listTraductionNotif, offre);
			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise le POJO DonneeRef unitairement avec les valeurs recuperee de la BDD
	 *
	 * @param listTraductionNotif
	 * @param offre
	 * @return
	 */
	protected DonneeRefVal valorisationDonneesRefUnitaire(List<TraductionNotifDTO> listTraductionNotif, OffreDTO offre) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;
		boolean libelleCourtPasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(offre.getValeurConstante(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
				if (traductionNotif.getLibelleCourt() != null) {

					val.setLibCourt(traductionNotif.getLibelleCourt());
					libelleCourtPasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(offre.getValeurConstante());

		}
		if (libellePasEncoreValorise) {

			val.setLib(offre.getLibelle());

		}
		if (libelleCourtPasEncoreValorise) {

			val.setLibCourt(offre.getLibelleCourt());

		}

		return val;
	}

	/**
	 * Recupere en BDD la liste des op�rations sur les offres et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getOper(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_OPER));

		List<TypeOpPonctuellesDTO> listOper = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TypeOpPonctuellesDTO.class);

		return valorisationOper(listOper, listTraductionNotif);
	}

	/**
	 * Valorise la liste des op�rations sur les offres dans le POJO donneeRed
	 *
	 * @param listOper
	 * @return
	 */
	protected DonneeRef valorisationOper(List<TypeOpPonctuellesDTO> listOper, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_OPER);

		for (TypeOpPonctuellesDTO oper : listOper) {

			DonneeRefVal val = valorisationOperUnitaire(listTraductionNotif, oper);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise unitairement l op�ration sur les offres dans le POJO donneeRed
	 *
	 * @param listTraductionNotif
	 * @param oper
	 * @return
	 */
	protected DonneeRefVal valorisationOperUnitaire(List<TraductionNotifDTO> listTraductionNotif, TypeOpPonctuellesDTO oper) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(oper.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(oper.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(oper.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des segments de march� et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getSegMarche(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_SEG_MARCHE));

		List<CategorieClientDTO> listcategorieClient = serviceManager.getReferenceSpaceManager().listInReferenceSpace(CategorieClientDTO.class);

		return valorisationSegMarche(listcategorieClient, listTraductionNotif);
	}

	/**
	 * Valorise la liste des segments de march� dans le POJO donneeRed
	 *
	 * @param listcategorieClient
	 * @return
	 */
	protected DonneeRef valorisationSegMarche(List<CategorieClientDTO> listcategorieClient, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_SEG_MARCHE);

		for (CategorieClientDTO categorieClient : listcategorieClient) {

			DonneeRefVal val = valorisationSegMarcheUnitaire(listTraductionNotif, categorieClient);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des segments de march� de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param categorieClient
	 * @return
	 */
	private DonneeRefVal valorisationSegMarcheUnitaire(List<TraductionNotifDTO> listTraductionNotif, CategorieClientDTO categorieClient) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(categorieClient.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(categorieClient.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(categorieClient.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des processus de livraison et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getProcLiv(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_PROC_LIV));

		List<CasMetierDTO> listCasMetier = serviceManager.getReferenceSpaceManager().listInReferenceSpace(CasMetierDTO.class);

		return valorisationProcLiv(listCasMetier, listTraductionNotif);
	}

	/**
	 * Valorise la liste des processus de livraison dans le POJO donneeRed
	 *
	 * @param listCasMetier
	 * @return
	 */
	protected DonneeRef valorisationProcLiv(List<CasMetierDTO> listCasMetier, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_PROC_LIV);

		for (CasMetierDTO casMetier : listCasMetier) {

			DonneeRefVal val = valorisationProcLivUnitaire(listTraductionNotif, casMetier);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des processus de livraison de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param casMetier
	 * @return
	 */
	private DonneeRefVal valorisationProcLivUnitaire(List<TraductionNotifDTO> listTraductionNotif, CasMetierDTO casMetier) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(casMetier.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(casMetier.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(casMetier.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des etats des commandes et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getEtatCmd(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_ETAT_CMD));

		List<EtatCommandeDTO> listEtatCmd = serviceManager.getReferenceSpaceManager().listInReferenceSpace(EtatCommandeDTO.class);

		return valorisationEtatCmd(listEtatCmd, listTraductionNotif);
	}

	/**
	 * Valorise la liste des etats des commandes dans le POJO donneeRed
	 *
	 * @param listEtatCmd
	 * @return
	 */
	protected DonneeRef valorisationEtatCmd(List<EtatCommandeDTO> listEtatCmd, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_ETAT_CMD);

		for (EtatCommandeDTO etatCmd : listEtatCmd) {

			DonneeRefVal val = valorisationEtatCmdUnitaire(listTraductionNotif, etatCmd);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des etats des commandes de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param etatCmd
	 * @return
	 */
	private DonneeRefVal valorisationEtatCmdUnitaire(List<TraductionNotifDTO> listTraductionNotif, EtatCommandeDTO etatCmd) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(etatCmd.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(etatCmd.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(etatCmd.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des contexts de livraison et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getCtxtLiv(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_CTXT_LIV));

		List<ContexteDTO> listContext = serviceManager.getReferenceSpaceManager().listInReferenceSpace(ContexteDTO.class);

		return valorisationContextLiv(listContext, listTraductionNotif);
	}

	/**
	 * Valorise la liste des contexts de livraison dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationContextLiv(List<ContexteDTO> listContext, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_CTXT_LIV);

		for (ContexteDTO context : listContext) {

			DonneeRefVal val = valorisationContextLivUnitaire(listTraductionNotif, context);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des contexts de livraison de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param context
	 * @return
	 */
	private DonneeRefVal valorisationContextLivUnitaire(List<TraductionNotifDTO> listTraductionNotif, ContexteDTO context) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(context.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(context.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(context.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des etat des lignes commandes et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getEtatLC(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_ETAT_LC));

		List<EtatLigneCdeDTO> listEtatLC = serviceManager.getReferenceSpaceManager().listInReferenceSpace(EtatLigneCdeDTO.class);

		return valorisationEtatLC(listEtatLC, listTraductionNotif);
	}

	/**
	 * Valorise la liste des etat des lignes commandes dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationEtatLC(List<EtatLigneCdeDTO> listEtatLC, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_ETAT_LC);

		for (EtatLigneCdeDTO etatLC : listEtatLC) {

			DonneeRefVal val = valorisationEtatLCUnitaire(listTraductionNotif, etatLC);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des etat des lignes commandes de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param etatLC
	 * @return
	 */
	private DonneeRefVal valorisationEtatLCUnitaire(List<TraductionNotifDTO> listTraductionNotif, EtatLigneCdeDTO etatLC) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(etatLC.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(etatLC.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(etatLC.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des etat des informations techniques et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getInfoTech(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_INFO_TECH));

		List<InfoTechNotifDTO> listTechNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(InfoTechNotifDTO.class);

		return valorisationTechNotif(listTechNotif, listTraductionNotif);
	}

	/**
	 * Valorise la liste des etat des informations techniques dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationTechNotif(List<InfoTechNotifDTO> listTechNotif, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_INFO_TECH);

		for (InfoTechNotifDTO techNotif : listTechNotif) {

			DonneeRefVal val = valorisationTechNotifUnitaire(listTraductionNotif, techNotif);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des etat des informations techniques de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param techNotif
	 * @return
	 */
	private DonneeRefVal valorisationTechNotifUnitaire(List<TraductionNotifDTO> listTraductionNotif, InfoTechNotifDTO techNotif) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(techNotif.getCle(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(techNotif.getCode());

		}
		if (libellePasEncoreValorise) {

			val.setLib(techNotif.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des questions techniques et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getQuest(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_QUEST));

		List<ExtractionQTDTO> listeQuest = serviceManager.getReferenceSpaceManager().listInReferenceSpace(ExtractionQTDTO.class);

		return valorisationQuestionnaire(listeQuest, listTraductionNotif);
	}

	/**
	 * Valorise la liste des questions techniques dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationQuestionnaire(List<ExtractionQTDTO> listeQuest, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_QUEST);

		for (ExtractionQTDTO quest : listeQuest) {

			DonneeRefVal val = valorisationQuestionnaireUnitaire(listTraductionNotif, quest);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des questions techniques de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param quest
	 * @return
	 */
	private DonneeRefVal valorisationQuestionnaireUnitaire(List<TraductionNotifDTO> listTraductionNotif, ExtractionQTDTO quest) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(quest.getCode(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(quest.getCode());

		}
		if (libellePasEncoreValorise) {

			val.setLib(quest.getQuestion());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des zoneSI et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getZoneSi(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_ZONE_SI));

		List<ZoneSiDTO> listTechNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(ZoneSiDTO.class);

		return valorisationZoneSi(listTechNotif, listTraductionNotif);
	}

	/**
	 * Valorise la liste des zoneSI dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationZoneSi(List<ZoneSiDTO> listeZoneSi, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_ZONE_SI);

		for (ZoneSiDTO zoneSi : listeZoneSi) {

			DonneeRefVal val = valorisationZoneSiUnitaire(listTraductionNotif, zoneSi);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des zoneSI de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param zoneSi
	 * @return
	 */
	private DonneeRefVal valorisationZoneSiUnitaire(List<TraductionNotifDTO> listTraductionNotif, ZoneSiDTO zoneSi) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;
		boolean libelleCourtPasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(zoneSi.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
				if (traductionNotif.getLibelleCourt() != null) {

					val.setLibCourt(traductionNotif.getLibelleCourt());
					libelleCourtPasEncoreValorise = false;
				}

			}
		}
		if (idPasEncoreValorise) {

			val.setId(zoneSi.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(zoneSi.getLibelle());

		}
		if (libelleCourtPasEncoreValorise) {

			val.setLibCourt(zoneSi.getLibelleCourt());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des zones geographiques et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getZoneGeo(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_ZONE_GEO));

		List<ZoneGeographiqueDTO> listeZoneGeo = serviceManager.getReferenceSpaceManager().listInReferenceSpace(ZoneGeographiqueDTO.class);

		return valorisationZoneGeo(listeZoneGeo, listTraductionNotif);
	}

	/**
	 * Valorise la liste des zone Geographiques dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationZoneGeo(List<ZoneGeographiqueDTO> listeZoneGeo, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_ZONE_GEO);

		for (ZoneGeographiqueDTO zoneGeo : listeZoneGeo) {

			DonneeRefVal val = valorisationZoneGeoUnitaire(listTraductionNotif, zoneGeo);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des zone Geographiques dans le POJO donneeRed
	 *
	 * @param listTraductionNotif
	 * @param zoneGeo
	 * @return
	 */
	private DonneeRefVal valorisationZoneGeoUnitaire(List<TraductionNotifDTO> listTraductionNotif, ZoneGeographiqueDTO zoneGeo) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;
		boolean libelleCourtPasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(zoneGeo.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
				if (traductionNotif.getLibelleCourt() != null) {

					val.setLibCourt(traductionNotif.getLibelleCourt());
					libelleCourtPasEncoreValorise = false;
				}

			}
		}
		if (idPasEncoreValorise) {

			val.setId(zoneGeo.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(zoneGeo.getLibelle());

		}
		if (libelleCourtPasEncoreValorise) {

			val.setLibCourt(zoneGeo.getLibelleCourt());
		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des jalons du processus et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getJalon(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_JALON));

		List<PhaseDTO> listeJalon = serviceManager.getReferenceSpaceManager().listInReferenceSpace(PhaseDTO.class);

		return valorisationJalon(listeJalon, listTraductionNotif);
	}

	/**
	 * Valorise la liste des jalons du processus dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationJalon(List<PhaseDTO> listeJalon, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_JALON);

		for (PhaseDTO jalon : listeJalon) {

			DonneeRefVal val = valorisationJalonUnitaire(listTraductionNotif, jalon);

			listVal.add(val);

		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Valorise la liste des jalons du processus de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param jalon
	 * @return
	 */
	private DonneeRefVal valorisationJalonUnitaire(List<TraductionNotifDTO> listTraductionNotif, PhaseDTO jalon) {
		DonneeRefVal val = new DonneeRefVal();

		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(jalon.getId(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(jalon.getId());

		}
		if (libellePasEncoreValorise) {

			val.setLib(jalon.getLibelle());

		}
		return val;
	}

	/**
	 * Recupere en BDD la liste des applications d origine et la map dans la reponse
	 *
	 * @param context
	 * @return
	 */
	public DonneeRef getOrig(@SuppressWarnings("unused") MessageContext context) {

		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, NOM_ORIG));

		List<SystemeExterneDTO> listeJalon = serviceManager.getReferenceSpaceManager().listInReferenceSpace(SystemeExterneDTO.class);

		return valorisationOrig(listeJalon, listTraductionNotif);
	}

	/**
	 * Valorise la liste des applications d origine dans le POJO donneeRed
	 *
	 * @param listContext
	 * @return
	 */
	protected DonneeRef valorisationOrig(List<SystemeExterneDTO> listeOrig, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(NOM_ORIG);

		for (SystemeExterneDTO orig : listeOrig) {

			DonneeRefVal val = valorisationOrigUnitaire(listTraductionNotif, orig);

			listVal.add(val);
		}
		donneeRef.setVal(listVal);

		return donneeRef;
	}

	/**
	 * Recupere en BDD la liste des applications d origine de facon unitaire
	 *
	 * @param listTraductionNotif
	 * @param orig
	 * @return
	 */
	private DonneeRefVal valorisationOrigUnitaire(List<TraductionNotifDTO> listTraductionNotif, SystemeExterneDTO orig) {

		DonneeRefVal val = new DonneeRefVal();
		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(orig.getValeurConstante(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(orig.getValeurConstante());

		}
		if (libellePasEncoreValorise) {

			val.setLib(orig.getNom());

		}
		return val;
	}

	public DonneeRef getMotifCmd(@SuppressWarnings("unused") MessageContext context) {
		List<TraductionDTO> listTraduction = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionDTO.class, new Comparaison(Traduction.FIELD_CLE, Constantes.OPERATOR_EQUAL, MOTIF_COMMANDE_LIBELLE));
		List<TraductionNotifDTO> listTraductionNotif = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionNotifDTO.class, new Comparaison(TraductionNotif.FIELD_TYPE_DONNEE, Constantes.OPERATOR_EQUAL, MOTIF_CMD));
		return valorisationMotifCmd(listTraduction, listTraductionNotif);
	}

	private DonneeRef valorisationMotifCmd(List<TraductionDTO> listTraduction, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRef donneeRef = new DonneeRef();
		ArrayList<DonneeRefVal> listVal = new ArrayList<DonneeRefVal>();

		donneeRef.setNom(MOTIF_CMD);
		for (TraductionDTO trad : listTraduction) {
			DonneeRefVal val = valoriserMotifCmdUnitaire(trad, listTraductionNotif);
			if (!listVal.contains(val)) {
				listVal.add(val);
			}
		}
		donneeRef.setVal(listVal);
		return donneeRef;
	}

	private DonneeRefVal valoriserMotifCmdUnitaire(TraductionDTO trad, List<TraductionNotifDTO> listTraductionNotif) {
		DonneeRefVal val = new DonneeRefVal();
		boolean idPasEncoreValorise = true;
		boolean libellePasEncoreValorise = true;

		for (TraductionNotifDTO traductionNotif : listTraductionNotif) {

			if (StringUtils.equals(trad.getValeurExterne(), traductionNotif.getCode())) {

				val.setId(traductionNotif.getCodeCible());
				idPasEncoreValorise = false;

				if (traductionNotif.getLibelle() != null) {

					val.setLib(traductionNotif.getLibelle());
					libellePasEncoreValorise = false;
				}
			}
		}
		if (idPasEncoreValorise) {

			val.setId(trad.getValeurExterne());

		}
		if (libellePasEncoreValorise) {

			val.setLib(trad.getValeurArtemis());

		}
		return val;
	}
}