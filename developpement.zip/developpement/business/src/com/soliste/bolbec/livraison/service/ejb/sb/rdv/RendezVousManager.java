/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.rdv;

import java.util.Date;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.RemoveException;

import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ContexteModification;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.DayOfWeek;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.Duration;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ExtendedInterventionDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.InterventionModification;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.LibererPlageResultDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.MomentInDay;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.NatureIntervention;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.RechercherPlageReferenceDataDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.RechercherPlageResultDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.RendezVousDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.ReserverPlageResultDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.exception.LibererPlageException;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.exception.RechercherPlageException;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.exception.ReserverPlageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.Plage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.CritereIntervention;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.ResponsabiliteDTO;
import com.soliste.bolbec.livraison.service.model.TypeOpProgrammeeDTO;

/**
 * Interface de l'EJB session RendezVousManager. Permet de g�rer des rendez-vous.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>23/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>25/06/2012</TD><TD>GPA</TD><TD>EV-000188: Vente FTTH - Ajout de finders</TD></TR>
 * <TR><TD>23/09/2013</TD><TD>BPE</TD><TD>G8R2C3 � EV-000264 : Ajout de la m�thode getRendezVousParCommandeRef</TD></TR>
 * </TABLE><BR>
 * 
 */
public interface RendezVousManager {

	/**
	 * Retourne l'intervention ayant l'identifiant donn�.
	 * 
	 * @param interventionId L'ID de l'intervention
	 * @return L'intervention
	 */
	public InterventionDTO getIntervention(String interventionId);

	/**
	 * R�cup�re l'intervention par r�f�rence et de date prise la plus r�cente.
	 * 
	 * @param interventionReference la r�f�rence de l'intervention
	 * @return InterventionDTO
	 */
	public InterventionDTO findInterventionByRefInterventionAndPlusRecentDatePrise(String interventionReference);

	/**
	 * Met � jour le champs observation de l'intervention
	 * 
	 * @param interventionDTO
	 */
	public void updateInterventionObservation(InterventionDTO interventionDTO);

	/**
	 * Retourne les infos de rendez-vous pour l'acc�s de livraison ayant le ND
	 * contenu dans la ligne de commande ayant l'ID donn�
	 * 
	 * @param ligneCommandeId
	 * l'ID de la premi�re ligne de commande ayant le ND de l'acc�s
	 * de livraison pour lequel on d�sire conna�tre les infos de
	 * rendez-vous
	 * @return les informations de rendez-vous
	 */
	public RendezVousDTO getRendezVous(String ligneCommandeId);

	/**
	 * Retourne la liste des interventions (ExtendedInterventionDTO)pour un ND
	 * donn� ordonn�es par Intervention.datePriseRDV d�croissante (les plus
	 * r�centes en pemier), avec les DynamicIntervention correspondants, la
	 * Commande li�e, les PsSouhaitee, et les Offre, et pouvant stocker une
	 * String InterventionEtatReport initialis�e � vide.
	 * 
	 * @param nd
	 * @return la liste des interventions (ExtendedInterventionDTO)pour un ND
	 * donn� ordonn�es par Intervention.datePriseRDV d�croissante (les
	 * plus r�centes en pemier), avec les DynamicIntervention
	 * correspondants, la Commande li�e, les PsSouhaitee, et les Offre,
	 * et pouvant stocker une String InterventionEtatReport initialis�e
	 * � vide.
	 */
	public List<ExtendedInterventionDTO> getRendezVousParNd(String nd);

	/**
	 * Retourne la liste des interventions (ExtendedInterventionDTO) pour une commandeRef
	 * donn�e, ordonn�es par Intervention.datePriseRDV d�croissante (les plus
	 * r�centes en pemier), avec les DynamicIntervention correspondants, la
	 * Commande li�e, les PsSouhaitee, et les Offre, et pouvant stocker une
	 * String InterventionEtatReport initialis�e � vide.
	 * 
	 * @param commandeRef
	 * @return la liste des interventions (ExtendedInterventionDTO)pour une commandeRef
	 * donn� ordonn�es par Intervention.datePriseRDV d�croissante (les
	 * plus r�centes en pemier), avec les DynamicIntervention
	 * correspondants, la Commande li�e, les PsSouhaitee, et les Offre,
	 * et pouvant stocker une String InterventionEtatReport initialis�e
	 * � vide.
	 */
	public List<ExtendedInterventionDTO> getRendezVousParCommandeRef(final String commandeRef);

	/**
	 * 
	 * @param refIntervention
	 * @return
	 */
	public List<ExtendedInterventionDTO> getRendezVousParRefIntervention(String refIntervention);

	/**
	 * Modifie une intervention.
	 * 
	 * @param intervention the intervention
	 * @param plage the plage
	 * @param responsabiliteId the responsabilite id
	 * @param contexte the contexte
	 * @param agentDTO the agent dto
	 * 
	 * @return "KO" ou "OK"
	 * 
	 * @throws ReserverPlageException the reserver plage exception
	 */
	public String modifierRendezVous(InterventionModification intervention, Plage plage, String responsabiliteId, ContexteModification contexte, AgentDTO agentDTO) throws ReserverPlageException;

	/**
	 * Retourne les donn�es de r�f�rence n�cessaire � la recherche d'une plage
	 * 
	 * @param ligneCommandeId
	 * la ligne de commande d�terminant l'acc�s de livraison
	 * @param interventionId
	 * l'identifiant de l'intervention
	 * @return les donn�es de r�f�rence
	 */
	public RechercherPlageReferenceDataDTO getRechercherPlageReferenceData(String ligneCommandeId, String interventionId);

	/**
	 * Recherche des plages disponibles
	 * 
	 * @param interventionId
	 * l'ID de l'intervention
	 * @param startDate
	 * la date de d�but
	 * @param endDate
	 * la date de fin
	 * @param dayOfWeek
	 * le jour
	 * @param momentInDay
	 * le moment de la journ�e
	 * @param duration
	 * la dur�e
	 * @return une instance de RechercherPlageResultDTO, contenant une liste
	 * d'instances de PlageDTO et un �ventuel avertissement
	 * @throws RechercherPlageException
	 * dans le cas o� une erreur bloquante est survenue. L'exception
	 * contient le message � pr�senter � l'utilisateur.
	 */
	public RechercherPlageResultDTO rechercherPlage(String interventionId, Date startDate, Date endDate, DayOfWeek dayOfWeek, MomentInDay momentInDay, Duration duration) throws RechercherPlageException;

	/**
	 * R�serve ou modifie une plage, en fonction de l'�tat de l'intervention
	 * identifi�e par interventionId.
	 * 
	 * @param interventionId l'identifiant de l'intervention pour laquelle il faut r�server
	 * la plage
	 * @param plage la plage � r�server
	 * @param critereIntervention les crit�res d'intervention retourn�s par l'appel pr�c�dent �
	 * rechercherPlage
	 * @param responsabiliteId la responsabilit� de la r�servation de plage
	 * @param agentDTO the agent dto
	 * 
	 * @return une instance de ReserverPlageResultDTO
	 * 
	 * @throws ReserverPlageException si la plage n'a pu �tre r�serv�e. L'exception contient le
	 * message d'erreur � pr�senter � l'utilisateur
	 */
	public ReserverPlageResultDTO reserverPlage(String interventionId, Plage plage, CritereIntervention critereIntervention, String responsabiliteId, AgentDTO agentDTO) throws ReserverPlageException;

	/**
	 * Lib�re une plage.
	 * 
	 * @param interventionId l'identifiant de l'intervention pour laquelle il faut lib�rer la plage
	 * @param agentDTO the agent dto
	 * @param responsabiliteId the responsabilit� Id
	 *
	 * @return une instance de LibererPlageResultDTO
	 * 
	 * @throws RemoveException the remove exception
	 * @throws LibererPlageException si la plage n'a pu �tre lib�r�e. L'exception contient le
	 * message d'erreur � pr�senter � l'utilisateur
	 */
	public LibererPlageResultDTO libererPlage(String interventionId, AgentDTO agentDTO, String responsabiliteId) throws LibererPlageException, RemoveException;

	/**
	 * Lors de la saisie des RDV de construction via les IHM Artemis,
	 * filtre les cr�neaux retourn�s par GPC et garde uniquement les cr�neaux
	 * sur des heures pleines (heure de d�but et heure de fin sur des heures pleines du type xxh00),
	 * 
	 * @param interventionId
	 * l'identifiant de l'intervention pour laquelle il faut lib�rer
	 * la plage
	 * @param plages
	 * liste des plages � filtrer
	 * @return une instance de LibererPlageResultDTO
	 * 
	 */
	public List<Plage> filtrerPlage(String interventionId, List<Plage> plages);

	/**
	 * M�thode effectuant la cr�ation d'une nouvelle intervention � partir d'une intervention existante
	 * et le modification de l'existante. La m�thode est appel�e lors de la notification de modification d'un rendez-vous
	 * 
	 * @param referenceIntervention the reference intervention
	 * @param basicat the basicat
	 * @param referenceERdv the reference e rdv
	 * @param dateDebut the date debut
	 * @param dateFin the date fin
	 * @param responsabilite the responsabilite
	 * @param agent the agent
	 * 
	 * @return String
	 */
	public String modificationIntervention(String referenceIntervention, String basicat, String referenceERdv, Date dateDebut, Date dateFin, String agent, String responsabilite);

	/**
	 * M�thode permettant de notifier dans la table Evt une erreur apparue lors du traitement du WebService de notification de modification de rendez vous
	 * 
	 * @param erreur
	 * @throws CreateException
	 */
	public void createEvtPourNotificationModificationRDV(String erreur) throws CreateException;

	/**
	 * M�thode permettant de gerer un retour en erreur pour la notification de nouvelle intervention
	 * 
	 * @param codeErreur = code d'erreur renvoy� par eRDV
	 * @param libelleErreur = libelle d'erreur renvoy� par eRDV
	 */
	public void gererErreurNotifNouvelleInterv(String codeErreur, String libelleErreur);

	/**
	 * Retourne si l'intervention est une intervention client ou une intervention globale.
	 *
	 * @param intervention
	 * @return La nature de l'intervention
	 */
	public NatureIntervention getNatureIntervention(InterventionDTO intervention);

	/**
	 * Retourne la nature, la plus prioritaire de la liste d'opProgrammees
	 *
	 * @param opProgrammeeList
	 * @return La nature de l'intervention
	 */
	public String getNatureOpProgrammes(List<OpProgrammeeDTO> opProgrammeeList);

	/**
	 * Retourne le typeOPProgram�e avec nature, la plus prioritaire
	 *
	 * @param lstTypeOpProgrammee
	 * @return typeOpProgramme avec nature plus prioritaire
	 */
	public TypeOpProgrammeeDTO getTypeOpProgrammeeAvecNaturePrioritaire(List<TypeOpProgrammeeDTO> lstTypeOpProgrammee);

	/**
	 * Rechercher des interventions par ref�rence ERDV<br>
	 * Si aucune intervention n'est trouv�e, la m�thode renvoie une liste vide
	 * 
	 * @param referenceErdv la r�f�rence ERDV
	 * @return la liste des interventions
	 */
	public List<InterventionDTO> findInterventionsByRefErdv(String referenceErdv);

	/**
	 * Rechercher une liste d'intervention li�e � une commande termin�e par ref�rence ERDV et renvoyer la plus r�cente
	 * 
	 * @param referenceErdv la r�f�rence ERDV
	 * @return l'intervention
	 */
	public InterventionDTO findInterventionByRefErdvAndDatePrisePlusRecente(String referenceErdv);

	/**
	 * Creates the intervention fille.
	 * 
	 * @param interventionPrecedente the intervention precedente
	 * @return the intervention dto
	 * @throws CreateException the create exception
	 */
	public InterventionDTO createInterventionFille(InterventionDTO interventionPrecedente) throws CreateException;

	/**
	 * Pour initiative OPERATEUR, return true si la valeur du param�tre "MODIF_RDV_OPER" n'existe pas ou est inf�rieure � la date de cr�ation de la commande dans l�application
	 * Sinon return false (param�tre "MODIF_RDV_OPER" sup�rieur ou �gal � la date de la commande, responsabilit� diff�rent d'OPERATEUR)
	 *
	 * @param responsabiliteDTO
	 * @return isOperateurEtDateDepasse
	 */
	public boolean isResponsabiliteOperateurEtDateDepasse(ResponsabiliteDTO responsabiliteDTO, Long dateCreationCommande);

}
