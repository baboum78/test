/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.exception;

/**
 * Exception indiquant qu'un processus n'a pu �tre suspendu, ou a �t� suspendu
 * mais avec avertissement
 * 
 * @author rgvs7490
 */
public class AffecterTraitementManuelException extends Exception {

	private boolean warning;

	/**
	 * @param message
	 * @param warning
	 */
	public AffecterTraitementManuelException(String message, boolean warning) {
		super(message);
		this.warning = warning;
	}

	/**
	 * @return warning
	 */
	public boolean isWarning() {
		return this.warning;
	}
}
