/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>14/12/2011</TD><TD>CCL</TD><TD>Ajout d'un service manager pour les tests unitaires</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO d'ExtendedIntervention (InterventionDTO enrichi)
 */
public class ExtendedInterventionDTO implements Serializable {

	public static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	private CommandeDTO commande;
	private String etatReport;
	private InterventionDTO intervention;
	private List<LigneCommandeDTO> lignesCommande;
	private List<OffreDTO> offres;
	private List<OpProgrammeeDTO> opProgrammees;

	/**
	 * 
	 * @param intervention
	 * @param commande
	 */
	public ExtendedInterventionDTO(InterventionDTO intervention, CommandeDTO commande) {
		this.intervention = intervention;
		this.commande = commande;
		this.opProgrammees = SERVICE_MANAGER.getCommandeManager().findOpProgrammeeByIntervention(intervention.getId());
		this.lignesCommande = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByIntervention(intervention.getId());
		this.offres = new ArrayList<OffreDTO>();
		for (LigneCommandeDTO ligneCommande : this.lignesCommande) {
			PsSouhaiteDTO psSouhaite = ServiceManager.getInstance().getCommandeManager().findPsSouhaiteByLigneCommande(ligneCommande.getId());
			if (psSouhaite != null) {
				String offreId = psSouhaite.getPorteSurOffre().getId();
				OffreDTO offre = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(OffreDTO.class, offreId);
				this.offres.add(offre);
			}
		}
	}

	/**
	 * @return commande
	 */
	public CommandeDTO getCommande() {
		return commande;
	}

	/**
	 * @return etatReport
	 */
	public String getEtatReport() {
		return etatReport;
	}

	/**
	 * @return intervention
	 */
	public InterventionDTO getIntervention() {
		return intervention;
	}

	/**
	 * @return lignesCommande
	 */
	public List<LigneCommandeDTO> getLignesCommande() {
		return lignesCommande;
	}

	/**
	 * @return offres
	 */
	public List<OffreDTO> getOffres() {
		return offres;
	}

	/**
	 * @return opProgrammees
	 */
	public List<OpProgrammeeDTO> getOpProgrammees() {
		return opProgrammees;
	}

	/**
	 * @param commande
	 */
	public void setCommande(CommandeDTO commande) {
		this.commande = commande;
	}

	/**
	 * @param etatReport
	 */
	public void setEtatReport(String etatReport) {
		this.etatReport = etatReport;
	}

	/**
	 * @param intervention
	 */
	public void setIntervention(InterventionDTO intervention) {
		this.intervention = intervention;
	}

	/**
	 * @param lignesCommande
	 */
	public void setLignesCommande(List<LigneCommandeDTO> lignesCommande) {
		this.lignesCommande = lignesCommande;
	}

	/**
	 * @param offres
	 */
	public void setOffres(List<OffreDTO> offres) {
		this.offres = offres;
	}

	/**
	 * @param opProgrammees
	 */
	public void setOpProgrammees(List<OpProgrammeeDTO> opProgrammees) {
		this.opProgrammees = opProgrammees;
	}
}
