package com.soliste.bolbec.livraison.service.ejb.sb.parametreDynamique;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.List;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.ejb.SessionContext;
import javax.naming.NamingException;

import aps.ParametreDynamique;
import aps.ParametreDynamiqueHome;

import com.soliste.bolbec.commun.service.ejb.EntityBeanPK;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.livraison.service.model.ParametreDynamiqueDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Bean de l'EJB session ParametreDynamiqueManager
 * 
 * @author gPageot
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/01/2012</TD><TD>GPA</TD><TD>EV-000168: Cr�ation de la classe</TD></TR>
 * <TR><TD>02/07/2012</TD><TD>BPE</TD><TD>CAST: Corrections mineures</TD></TR>
 * <TR><TD>13/02/2014</TD><TD>BPE</TD><TD>EV-000276: Enrichissement de l'interface</TD></TR>
 * </TABLE>
 */
public class ParametreDynamiqueManagerBean extends FwkSessionBean implements ParametreDynamiqueManager {

	/**
	 * Serial version UID
	 */
	private static final long serialVersionUID = 801370930046725033L;

	/** The CLASS_NAME. */
	private static final String CLASS_NAME = ParametreDynamiqueManagerBean.class.getName();

	/** Le ServiceManager */
	protected IServiceManager serviceManager = ServiceManager.getInstance();

	/** The Parametre Dynamique home. */
	private ParametreDynamiqueHome parametreDynamiqueHome;

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	public void setSessionContext(@SuppressWarnings("unused") SessionContext sessionContext) {
		try {
			parametreDynamiqueHome = getEntityHome(ParametreDynamiqueHome.class);
		} catch (NamingException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public List<ParametreDynamiqueDTO> findParametreDynamiqueParCleEtVersion(String cle, String version) {
		serviceManager.getLoggerManager().fine(CLASS_NAME, "findParametreDynamiqueParCleEtVersion", "Recherche du param�tre dynamique avec la cle='" + cle + "' et la version '" + version + "'");

		List<ParametreDynamiqueDTO> dtoList = new ArrayList<ParametreDynamiqueDTO>();
		try {
			@SuppressWarnings("unchecked")
			Collection<ParametreDynamique> pdCollection = parametreDynamiqueHome.findByCleEtVersion(cle, version);
			for (ParametreDynamique pd : pdCollection) {
				dtoList.add(new ParametreDynamiqueDTO(pd));
			}
		} catch (FinderException fe) {
			serviceManager.getLoggerManager().warning(CLASS_NAME, "findParametreDynamiqueParCleEtVersion", "Pas de param�tre dynamique avec la cle='" + cle + "' et la version '" + version + "'", fe);
			return null;
		}
		return dtoList;
	}

	/**
	 * {@inheritDoc}
	 */
	public List<ParametreDynamiqueDTO> findParametreDynamiqueParCle(final String cle) {
		final String methode = "findParametreDynamiqueParCle";
		serviceManager.getLoggerManager().finest(CLASS_NAME, methode, String.format("Recherche des param�tres dynamiques avec la cle='%s'", cle));

		final List<ParametreDynamiqueDTO> dtoList = new ArrayList<ParametreDynamiqueDTO>();
		try {
			@SuppressWarnings("unchecked")
			final Collection<ParametreDynamique> pdCollection = parametreDynamiqueHome.findByCle(cle);
			for (ParametreDynamique pd : pdCollection) {
				dtoList.add(new ParametreDynamiqueDTO(pd));
			}
		} catch (FinderException fe) {
			serviceManager.getLoggerManager().warning(CLASS_NAME, methode, String.format("Recherche des param�tres dynamiques avec la cle='%s'", cle));
			return null;
		}
		return dtoList;
	}

	/**
	 * {@inheritDoc}
	 */
	public ParametreDynamique createParametreDynamique(final ParametreDynamiqueDTO parametreDynamique) {
		HashMap<String, Object> values = new HashMap<String, Object>();
		values.put(ParametreDynamique.FIELD_CLE, parametreDynamique.getCle());
		values.put(ParametreDynamique.FIELD_VALEUR, parametreDynamique.getValeur());
		values.put(ParametreDynamique.FIELD_VERSION, parametreDynamique.getVersion());
		try {
			return parametreDynamiqueHome.create(parametreDynamique.getId(), values);
		} catch (CreateException e) {
			throw new EJBException(e);
		}
	}

	/**
	 * {@inheritDoc}
	 */
	public void updateParametreDynamique(ParametreDynamiqueDTO parametreDynamique) {
		final ParametreDynamique parametreDynamiqueEntity;
		try {
			parametreDynamiqueEntity = parametreDynamiqueHome.findByPrimaryKey(new EntityBeanPK(parametreDynamique.getId()));
		} catch (FinderException e) {
			throw new EJBException(e);
		}
		parametreDynamiqueEntity.setCle(parametreDynamique.getCle());
		parametreDynamiqueEntity.setValeur(parametreDynamique.getValeur());
		parametreDynamiqueEntity.setVersion(parametreDynamique.getVersion());

	}

	/**
	 * {@inheritDoc}
	 */
	public void updateOrCreateParametreDynamique(ParametreDynamiqueDTO parametreDynamique) {
		ParametreDynamique parametreDynamiqueEntity;
		try {
			parametreDynamiqueEntity = parametreDynamiqueHome.findByPrimaryKey(new EntityBeanPK(parametreDynamique.getId()));
		} catch (FinderException e) {
			parametreDynamiqueEntity = createParametreDynamique(parametreDynamique);
			return;
		}
		parametreDynamiqueEntity.setCle(parametreDynamique.getCle());
		parametreDynamiqueEntity.setValeur(parametreDynamique.getValeur());
		parametreDynamiqueEntity.setVersion(parametreDynamique.getVersion());
	}
}
