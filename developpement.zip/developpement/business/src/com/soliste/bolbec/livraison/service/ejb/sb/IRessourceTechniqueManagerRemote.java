package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;
import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.interfaces.commun.RTechnique;
import com.soliste.bolbec.livraison.service.model.InstanceFtDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusInstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.SAppuieSurDTO;
import com.soliste.bolbec.livraison.service.model.SupportIRtDTO;

/**
 * Interface metier de l'ejb <code>RessourceTechniqueManagerSB</code><br/>
 * Permet de rechercher des entit�es li�es aux ressources techniques<br/><br/>
 * Interface repr�sentant le Business Interface pattern
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' >
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * <TR><TD>04/07/2012</TD><TD>GPA</TD><TD>EV-000184: Achat FTTH - Cr�ation de la m�thode</TD></TR>
 * <TR><TD>24/10/2012</TD><TD>EBA</TD><TD>EV-000083 : Ajout finder RTechnique</TD></TR>
 * <TR><TD>15/02/2013</TD><TD>EBA</TD><TD>G8R2C1 - DE-717(FT-263) : Ajout d'un filtre SAppuieSur</TD></TR>
 * <TR><TD>27/05/2016</TD><TD>JDE</TD><TD>G9R1C1 - DE-759 : Cr�ation de la m�thode findInstanceRTByIdExterne</TD></TR>
 * </TABLE><BR>
 */
public interface IRessourceTechniqueManagerRemote {

	/**
	 * R�cup�re l'instanceRT d'identifiant instanceRTId
	 * 
	 * @param instanceRTId the instanceRT id
	 * @return InstanceRtDTO
	 */
	InstanceRtDTO getInstanceRT(String instanceRTId) throws RemoteException;

	/**
	 * R�cup�re la liste d'instance de ressource technique pour un id externe donn�
	 * 
	 * @param idExterne l'id externe de l'instance de ressource technique
	 * @return la liste
	 */
	List<InstanceRtDTO> findInstanceRTByIdExterne(String idExterne) throws RemoteException;

	/**
	 * R�cup�re la liste d'instance de ressource technique avec un idRT
	 * 
	 * @param idRT l'id de ressource technique
	 * @return la liste
	 */
	List<InstanceRtDTO> findInstanceRTByIdRT(String idRT) throws RemoteException;

	/**
	 * R�cup�re la liste d'instance de ressource technique qui sont livr�s par un processus.
	 * 
	 * @param processusId the processus id
	 * 
	 * @return the list
	 */
	List<InstanceRtDTO> findInstanceRTByLivreParProcessus(String processusId) throws RemoteException;

	/**
	 * R�cup�re la liste d'instance de ressource technique qui sont livr�s par un processus
	 * pour une ressource technique donn�e
	 * 
	 * @param processusId the processus id
	 * 
	 * @return the list
	 */
	List<InstanceRtDTO> findInstanceRTByLivreParProcessusEtParRT(String processusId, String libelleRT) throws RemoteException;

	/**
	 * R�cup�re la liste d'instances de ressources techniques qui sont g�r�es par une opProgrammee.
	 * 
	 * @param opProgrammeeId
	 * @return
	 */
	List<InstanceRtDTO> findInstanceRTByOpProgrammee(String opProgrammeeId) throws RemoteException;

	/**
	 * Mets � jour les donn�es dynamiques des instances de ressource technique.
	 * 
	 * @param instanceRtDTO the instance rt dto
	 */
	void updateDynamicInstanceRts(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Mets � jour les champs <code>Repartiteur</code> et <code>EtatRt</code>
	 * et <code>IdRt</code> et <code>SensEvolution</code> d'une instanceRT
	 * 
	 * @param instanceRtDTO the intanceRT dto
	 */
	// FIXME OLD: renommer cette m�thode qui ne fait pas une modification de l'objet en entier -> risque d'erreur
	void updateInstanceRT(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>InstanceRT</code> d'une instanceRT
	 * 
	 * @param instanceRtDTO the intanceRT dto
	 */
	void updateInstanceRTInstanceRT(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Mets � jour tous les champs d'une instanceRT
	 * 
	 * @param instanceRtDTO the intanceRT dto
	 */
	void updateInstanceRTAndDynamics(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>EtatRt</code> d'une instanceRT
	 * 
	 * @param instanceRtDTO the intanceRT dto
	 */
	void updateInstanceRTEtat(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>IdExterne</code> d'une instanceRT
	 * 
	 * @param instanceRtDTO the intanceRT dto
	 */
	void updateInstanceRTIdExterne(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>OpProgrammee</code> d'une instanceRT
	 * 
	 * @param instanceRtDTO the intanceRT dto
	 */
	void updateInstanceRTOpProgrammee(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>estRelieInstanceRt</code> avec newInstanceRtId des instanceRT telle que
	 * pour ces instanceRT le champ estRelieInstanceRt �tait �gal � instanceRtId
	 * 
	 * @param instanceRtId
	 * @param newInstanceRtId
	 */
	void updateInstanceRTListEstRelieInstanceRT(String instanceRtId, String newInstanceRtId) throws RemoteException;

	/**
	 * Mets � jour le champ <code>SensEvolution</code> d'une instanceRT
	 * 
	 * @param instanceRtDTO the intanceRT dto
	 */
	void updateInstanceRTSensEvolution(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Supprime une instanceRT
	 * 
	 * @param instanceRtId the intanceRT id
	 */
	void deleteInstanceRT(String instanceRtId) throws RemoteException;

	/**
	 * Supprime les supportIRt ayant pour supporteInstanceRT l'id <code>supporteInstanceRTId</code>.
	 * 
	 * @param supporteInstanceRTId the supporte instance rt id
	 */
	void deleteSupportIRTBySupporteInstanceRT(String supporteInstanceRTId) throws RemoteException;

	/**
	 * Supprime les supportIRt ayant pour supporteeInstanceRT l'id <code>supporteeInstanceRTId</code>.
	 * 
	 * @param supporteeInstanceRTId the supportee instance rt id
	 */
	void deleteSupportIRTBySupporteeParInstanceRT(String supporteeInstanceRTId) throws RemoteException;

	/**
	 * Supprime une sAppuieSur
	 * 
	 * @param sAppuieSurId the sAppuieSur id
	 */
	void deleteSAppuieSur(String sAppuieSurId) throws RemoteException;

	/**
	 * Supprime une instanceFT
	 * 
	 * @param instanceFtId the intanceFT id
	 */
	void deleteInstanceFT(String instanceFtId) throws RemoteException;

	/**
	 * Supprime les relation entre processus et instanceRT pour l'id <code>instanceRtId</code>.
	 * 
	 * @param instanceRtId the instance rt id
	 */
	void deleteProcessusInstanceRTByInstanceRT(String instanceRtId) throws RemoteException;

	/**
	 * Mets � jour le champ <code>Etat</code> d'un sappuieSur
	 * 
	 * @param sappuieSurDTO the sappuieSur dto
	 */
	void updateSAppuieSurEtat(SAppuieSurDTO sappuieSurDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>Sens</code> d'un sappuieSur
	 * Ajout EV-000032
	 * 
	 * @param sappuieSurDTO the sappuieSur dto
	 */
	void updateSAppuieSurSensEvol(SAppuieSurDTO sappuieSurDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>Sens</code> et <code>Etat</code> d'un sappuieSur
	 * Ajout EV-000284
	 * 
	 * @param sappuieSurDTO the sappuieSur dto
	 */
	void updateSAppuieSurSensEvolEtEtat(SAppuieSurDTO sappuieSurDTO) throws RemoteException;

	/**
	 * Mets � jour le champ <code>instanceRt</code> avec newInstanceRtId d'une liste de sappuieSur tel que
	 * pour ces sappuieSur le champ instanceRt �tait �gal � instanceRtId
	 * 
	 * @param instanceRtId
	 * @param newInstanceRtId
	 */
	void updateSAppuieSurListInstanceRT(String instanceRtId, String newInstanceRtId) throws RemoteException;

	/**
	 * R�cup�re la liste des sappuieSur � partir d'une instanceRT
	 * 
	 * @param idInstanceRT
	 * @return la liste des sappuieSur � partir d'une instanceRT
	 */
	List<SAppuieSurDTO> findSappuieSurByAppuieInstanceRT(String idInstanceRT) throws RemoteException;

	/**
	 * R�cup�re la liste des sappuieSur � partir d'une instanceFT
	 * 
	 * @param instanceFTId
	 * @return la liste des sappuieSur � partir d'une instanceFT
	 */
	List<SAppuieSurDTO> findSappuieSurByAppuieInstanceFT(String instanceFTId) throws RemoteException;

	/**
	 * R�cup�re la liste des sappuieSur � partir d'une instanceRT
	 * dont le sensEvolution est diff�rent de sensEvol
	 * 
	 * @param idInstanceRT
	 * @param sensEvol
	 * @return la liste des sappuieSur
	 */
	List<SAppuieSurDTO> findSappuieSurByAppuieInstanceRTAndNotSensEvol(String idInstanceRT, String sensEvol) throws RemoteException;

	/**
	 * R�cup�re la liste des sappuieSur � partir d'une instanceRT
	 * dont l'�tat vaut etat et le sensEvolution est diff�rent de sensEvol
	 * 
	 * @param idInstanceRT
	 * @param etat
	 * @param sensEvol
	 * @return la liste des sappuieSur
	 */
	List<SAppuieSurDTO> findSappuieSurByAppuieInstanceRTAndEtatAndNotSensEvol(String idInstanceRT, String etat, String sensEvol) throws RemoteException;

	/**
	 * R�cup�re l'instance FT � partir de son identifiant
	 * 
	 * @param instanceFtId Identifiant de l'instance FT
	 * @return InstanceRtDTO
	 */
	InstanceFtDTO getInstanceFT(String instanceFtId) throws RemoteException;

	/**
	 * Mets � jour le champ <code>InstanceFT</code> d'une instanceFT
	 * 
	 * @param instanceFtDTO the intanceFT dto
	 */
	void updateInstanceFTRemplaceInstanceFT(InstanceFtDTO instanceFtDTO) throws RemoteException;

	/**
	 * R�cup�re la liste d'instanceFT qui s'appuie sur une InstanceRT.
	 * 
	 * @param instanceRTId the instanceRT id
	 * 
	 * @return the list
	 */
	List<InstanceFtDTO> findInstanceFTByAppuieInstanceRT(String instanceRTId) throws RemoteException;

	/**
	 * R�cup�re la liste d'instanceRT � partir d'une InstanceFT.
	 * 
	 * @param instanceFTId the instanceFT id
	 * 
	 * @return the list
	 */
	List<InstanceRtDTO> findInstanceRTByInstanceFT(String instanceFTId) throws RemoteException;

	/**
	 * R�cup�re la liste d'instanceFT qui sont remplac�s par une instanceFT
	 * 
	 * @param instanceFTId the instanceFT id
	 * 
	 * @return the list
	 */
	List<InstanceFtDTO> findInstanceFTByRemplaceInstanceFT(String instanceFTId) throws RemoteException;

	/**
	 * Cr�e un processusInstanceRT.
	 * 
	 * @param processusInstanceRtDTO the processus dto
	 * 
	 * @return processusInstanceRtDTO
	 */
	ProcessusInstanceRtDTO createProcessusInstanceRT(ProcessusInstanceRtDTO processusInstanceRtDTO) throws RemoteException;

	/**
	 * R�cup�re la liste d'instance de ressource technique qui sont support�s par une instance de ressouce technique d'identfiant instanceRtId.
	 * 
	 * @param instanceRtId the instanceRT id
	 * 
	 * @return the list
	 */
	List<InstanceRtDTO> findInstanceRTBySupporteParInstanceRT(String instanceRtId) throws RemoteException;

	/**
	 * R�cup�re la liste d'instance de ressource technique qui sont reli�es � une instance de ressouce technique d'identfiant instanceRtId.
	 * 
	 * @param instanceRtId the instanceRT id
	 * 
	 * @return the list
	 */
	List<InstanceRtDTO> findInstanceRTByRelieInstanceRT(String instanceRtId) throws RemoteException;

	/**
	 * Mets � jour le champ <code>supporteeParInstanceRt</code> avec newInstanceRtId des supportIRT telle que
	 * pour ces supportIRT le champ supporteeParInstanceRt �tait �gal � instanceRtId
	 * 
	 * @param instanceRtId
	 * @param newInstanceRtId
	 * 
	 */
	void updateSupportIRTListSupporteInstanceRT(String instanceRtId, String newInstanceRtId) throws RemoteException;

	/**
	 * Cr�e un instanceFT.
	 * 
	 * @param instanceFtDTO the instanceFt dto
	 * 
	 */
	void createInstanceFT(InstanceFtDTO instanceFtDTO) throws RemoteException;

	/**
	 * Cr�e un instanceRT.
	 * 
	 * @param instanceRtDTO the instanceRt dto
	 * 
	 */
	void createInstanceRT(InstanceRtDTO instanceRtDTO) throws RemoteException;

	/**
	 * Cr�e un sAppuieSur.
	 * 
	 * @param sAppuieSurDTO the sAppuieSur dto
	 * 
	 */
	void createSAppuieSur(SAppuieSurDTO sAppuieSurDTO) throws RemoteException;

	/**
	 * Cr�e un supportIRt.
	 * 
	 * @param supportIRtDTO the supportIRt dto
	 * 
	 */
	void createSupportIRT(SupportIRtDTO supportIRtDTO) throws RemoteException;

	/**
	 * Recupere les champs dynamiques d'une instance RT
	 * 
	 * @param instanceRtId the instance rt id
	 * 
	 * @return the map< string, string>
	 */
	Map<String, String> findDynamicsInstanceRt(String instanceRtId) throws RemoteException;

	/**
	 * recupere "les" Rtechniques de typeRT avec l'idExterne de l'instanceRT associ� �gal � idExterne
	 * 
	 * @param typeRT
	 * @param idExterne
	 * @return
	 */
	List<RTechnique> findInstanceRtByTypeEtIdExterne(String typeRT, String idExterne) throws RemoteException;

	/**
	 * 
	 * Retourne une liste d'instanceRt sans celles ne possedant pas de SAppuieSur
	 * 
	 * @param instRtList
	 * @return
	 * @throws RemoteException
	 */
	List<InstanceRtDTO> filtreInstanceRtSansSAppuieSur(List<InstanceRtDTO> instRtList) throws RemoteException;

}
