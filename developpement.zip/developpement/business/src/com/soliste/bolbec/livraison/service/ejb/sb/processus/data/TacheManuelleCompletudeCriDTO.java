/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.List;

import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.extended.ExtendedLigneCommandeDTO;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO pour une t�che manuelle sp�cifique de type
 * completude Cri
 * 
 * @author edba8262
 */
public class TacheManuelleCompletudeCriDTO extends TacheManuelleDTO {

	private List<ExtendedLigneCommandeDTO> prestations;
	private List<InterventionDTO> interventions;

	/**
	 * 
	 */
	TacheManuelleCompletudeCriDTO() {

	}

	public String getType() {
		return TACHE_MANUELLE_COMPLETUDE_CRI_TYPE;
	}

	/**
	 * @return Returns the interventions.
	 */
	public List<InterventionDTO> getInterventions() {
		return this.interventions;
	}

	/**
	 * @param interventions The interventions to set.
	 */
	void setInterventions(List<InterventionDTO> interventions) {
		this.interventions = interventions;
	}

	/**
	 * @return Returns the prestations.
	 */
	public List<ExtendedLigneCommandeDTO> getPrestations() {
		return this.prestations;
	}

	/**
	 * @param prestations The prestations to set.
	 */
	void setPrestations(List<ExtendedLigneCommandeDTO> prestations) {
		this.prestations = prestations;
	}

}
