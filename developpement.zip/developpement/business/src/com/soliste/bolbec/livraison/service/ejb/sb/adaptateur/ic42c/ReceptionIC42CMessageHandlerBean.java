/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import aps.EtatCommandeConstantes;

import com.soliste.bolbec.livraison.service.model.EtatCommandeDTO;

import org.apache.commons.lang.StringUtils;

import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.AdapatateurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.util.AdaptationUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.util.MarshalUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c.util.ValidationUtil;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil;

/**
 * The Class ReceptionIC42CMessageHandlerBean.
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>20/08/2017</TD><TD>AJO</TD><TD>D�num�rotation</TD></TR>
 * </TABLE>
 * 
 * @author rgvs7490
 */
public class ReceptionIC42CMessageHandlerBean extends AdapatateurMessageHandlerBean {

	private static final Log LOG = new Log(ReceptionIC42CMessageHandlerBean.class);

	/** Nom de la classe. */
	private static final String CLASS_NAME = ReceptionIC42CMessageHandlerBean.class.getName();

	/** String SEPARATEUR. */
	private static final String SEPARATEUR = "_";

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#processMessage(java.io.Serializable, CommandeDTO)
	 */
	public void processMessage(Serializable a_message, CommandeDTO commandeDTO) throws InvalidJmsMessageException {
		long begin = System.currentTimeMillis();

		try {
			// R�cup�ration du message de l'intention de commande 42C
			String xmlMsg = getXmlMessage(a_message);
			String instanceLocalisation = getInstanceLocalisation(a_message);

			MarshalUtil delegueLecture = new MarshalUtil(xmlMsg);
			String l_injectionMsg = delegueLecture.getMessage42C();

			// V�rification de la conformit� de l'intention de commande 42C
			IC_42C l_ic42c = ValidationUtil.valider(l_injectionMsg);

			boolean estDoublon = ValidationUtil.estDoublon(l_ic42c);

			// V�rifier si l'IC 42C doit donner lieu � une IC Artemis
			if (ValidationUtil.estAccepte(l_ic42c) && !estDoublon) {
				// Convertir l'intention de commande 42C au format intention de commande Artemis
				AdaptationUtil l_delegueConversion = new AdaptationUtil(delegueLecture.getPrefixe());
				bolbec.injection.xml.generated.Message l_icArtemis = l_delegueConversion.traduire(l_ic42c, instanceLocalisation);

				String xmlMessageToInject = MarshalUtil.marshal(l_icArtemis);

				HashMap<String, String> mapToInject = new HashMap<String, String>();
				mapToInject.put(Constantes.FIELD_MESSAGE, xmlMessageToInject);
				mapToInject.put(Constantes.FIELD_INSTANCE_LOCALISATION, instanceLocalisation);
				mapToInject.put(Constantes.FIELD_ID_COMMANDE, commandeDTO.getId());

				// Injecter l'intention de commande Artemis
				InjectionCdeUtil.inject(mapToInject);
			} else {
				// Rejeter l'IC 42C : anomalie IC42C_NON_TRAITEE
				ServiceManager.getInstance().getLoggerManager().warning(CLASS_NAME, "processMessage", "Pas de processus a derouler dans Artemis pour l'IC 42C suivante : " + l_injectionMsg);
				commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
				ServiceManager.getInstance().getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
				if (!ValidationUtil.estAccepte(l_ic42c)) {
					throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_NON_TRAITEE, "Pas de processus a derouler dans Artemis");
					// EV-442 D�num�rotation
				} else if (estDoublon) {
					throw new ReceptionCdeException(IC42CConstantes.ANO_IC42C_NON_TRAITEE, "Doublon d'une commande de DENUM EFB d�j� trait�e");
				}
			}
		} catch (ReceptionCdeException rce) {
			InjectionCdeUtil.throwExceptionForAnomalie(rce, rce.getId(), a_message);
		} finally {
			long end = System.currentTimeMillis();
			String messageMetro = "'ReceptionIC42C' duree = " + (end - begin) + " ms";
			LOG.metro(messageMetro);
		}
	}

	@Override
	public String creerRefExterne(Serializable message, String reference) {

		Map<String, String> map = (Map<String, String>) message;
		String dateHeure = map.get(Constantes.FIELD_DATE_ROUTEUR);
		if (StringUtils.isBlank(dateHeure)) {
			Long dateHeureArtemis = DateUtils.getDatabaseDate();
			dateHeure = String.valueOf(dateHeureArtemis);
		}
		String[] msgTokenizer = reference.split(IC42CConstantes.SEPARATEUR, -1);
		String typeCommande = msgTokenizer[0];
		String ancienND = msgTokenizer[3];
		String offre = msgTokenizer[7];

		return dateHeure.concat(SEPARATEUR).concat(typeCommande).concat(SEPARATEUR).concat(ancienND).concat(SEPARATEUR).concat(offre);
	}

	public String getBaliseRefExterne() {
		return "Message=\"";
	}


}
