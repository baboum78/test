/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader;

import java.util.List;

import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.CorbeilleLoadCommand;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTOFactory;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.CorbeilleLoaderException;

/**
 * Classe d'abstraction pour le chargement des donn�es corbeille
 * 
 * @author gdzd8490
 * 
 */
public class CorbeilleDataLoader implements CorbeilleLoader {

	/** Implementation pour le chargeur de donn�es */
	CorbeilleLoaderImpl loader;

	/**
	 * Constructeur
	 * 
	 * @param loader
	 */
	public CorbeilleDataLoader(CorbeilleLoaderImpl loader) {
		this.loader = loader;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoader#loadSynthesisList(java.util.List, java.util.List, com.soliste.aps.workflow.WfUser)
	 */
	public List<SynthesisData> loadSynthesisList(List<FieldDTO> selectionFilters, List<FiltreDTO> dataFilters, WfUser user) throws CorbeilleLoaderException {
		return loader.loadSynthesisList(selectionFilters, dataFilters, user);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoader#loadItemList(com.soliste.bolbec.livraison.service.ejb.sb.corbeille.CorbeilleLoadCommand, com.soliste.aps.workflow.WfUser)
	 */
	public void loadItemList(CorbeilleLoadCommand corbeilleLoadCommand, WfUser user) throws CorbeilleLoaderException {
		loader.loadItemList(corbeilleLoadCommand, user);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoader#getFieldFactory()
	 */
	public FieldDTOFactory getFieldFactory() {
		return loader.getFieldFactory();
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoader#getFiltreFactory()
	 */
	public FiltreDTOFactory getFiltreFactory() {
		return loader.getFiltreFactory();
	}
}
