/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;

/**
 * Impl�mentation pour les infos que doit ramener une requ�te JDBC
 * 
 * @author gdzd8490
 * 
 */
public class JDBCFieldDTO extends FieldDTO {

	/** Champ JDBC correspondant � une colonne dans une table en base */
	private JDBCField field;

	/**
	 * Constructeur
	 * 
	 * @param field
	 */
	public JDBCFieldDTO(JDBCField field) {
		this.field = field;
	}

	/**
	 * Renvoie le filtre JDBC
	 * 
	 * @return le filtre JDBC
	 */
	public JDBCField getField() {
		return this.field;
	}
}
