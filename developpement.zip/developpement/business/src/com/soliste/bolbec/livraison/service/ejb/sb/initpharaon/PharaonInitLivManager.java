package com.soliste.bolbec.livraison.service.ejb.sb.initpharaon;

import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import javax.ejb.EJBLocalObject;

import aps.TacheEnCoursHome;

import com.soliste.bolbec.commun.service.ejb.sb.commun.data.PharaonConfig;
import com.soliste.bolbec.commun.service.ejb.sb.commun.data.PharaonData;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.publication.Notification;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
 * <TR><TD>25/05/2010</TD><TD>DBA</TD><TD>EV-000047: Ajout d'un find By Processus</TD></TR>
 * <TR><TD>21/06/2010</TD><TD>DBA</TD><TD>EV-000047: Retour sur le traitement d'extraction (Pb transaction)</TD></TR>
 * <TR><TD>21/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>13/11/2012</TD><TD>EBA</TD><TD>Creation d'une methode d'envoi de notification pour publication depuis la commande</TD></TR>
 * <TR><TD>14/05/2013</TD><TD>FTE</TD><TD>DE-000820 - Ajout d'une methode de publication depuis la tec</TD></TR>
 * <TR><TD>14/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * </TABLE>
 * EJB Session pour g�rer tous les aspects de Pharaon
 * 
 * @author dBaret
 * 
 */
public interface PharaonInitLivManager extends EJBLocalObject {

	/**
	 * M�thode permettant de g�n�rer les deux ficher d'extraction d'une instance de livraison (ERR_EXT_LN et EXT_LN)
	 * 
	 * @param data Les informations a utiliser pour l'init
	 * @param fwExt Le buffer du fichier d'extraction
	 * @param fwErrExt Le buffer du fichier d'erreurs
	 * 
	 * @throws IOException Si l'extraction provoque une erreur
	 */
	void generateExtractFile(PharaonData data, FileWriter fwExt, FileWriter fwErrExt) throws IOException;

	/**
	 * M�thode permettant de r�cup�rer les taches en cours pour l�initialisation de Pharaon
	 * 
	 * @return la liste des taches en cours des r�les pr�sent ds le PharaonConfig
	 */
	List<TacheEnCoursDTO> getInit();

	/**
	 * M�thode permettant de g�n�rer un PharaonData � partir d'une tache en cours
	 * 
	 * @param tacheEnCoursDTO la tache � partir de laquelle il faut rechercher les donn�es � extraire
	 * @return un PharaonData ayant tout ses champs de valoris�es
	 */
	PharaonData getDataForInit(TacheEnCoursDTO tacheEnCoursDTO);

	/**
	 * m�thode permettant de mettre "� plat" un PharaonData avec les s�parateurs d�finis dans la configuration
	 * 
	 * @param data : le PharaonData contenant toute les informations � formater
	 * @return une chaine format�e utilsant le separateur d�finit dans PharaonConfig
	 */
	String formatDataForInitFile(PharaonData data);

	/**
	 * 
	 * M�thode permettant de r�cup�rer toutes les informations de configurations
	 * 
	 * @return un PharaonConfig comprenant tout les parametres r�cup�r� en base et dans le fichier properties
	 */
	PharaonConfig loadConfig();

	/**
	 * M�thode permettant de r�cup�rer une instance de l'EJB TacheEnCoursHome
	 * 
	 * @return L'instance de l'EJB
	 */
	TacheEnCoursHome getTacheEnCoursHome();

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * </TABLE>
	 * M�thode permettant de g�n�rer un PharaonData � partir d'une tache en cours
	 * 
	 * @param notification La notification (Objet contenant les informations necessaire pour r�cup�rer les donn�es � publier vers Pharaon)
	 * @return un PharaonData ayant tout ses champs de valoris�es
	 */
	PharaonData getData(Notification notification, boolean init);

	/**
	 * Permet de g�rer les droits sur un r�pertoire
	 * 
	 * @param fichier Le nom du fichier
	 * @param droit Les droits
	 * @throws IOException
	 */
	void gererDroitsFichier(String fichier, String droit) throws IOException;
}
