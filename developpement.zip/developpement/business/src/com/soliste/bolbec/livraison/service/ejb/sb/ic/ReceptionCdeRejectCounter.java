/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.ic;

import com.soliste.bolbec.commun.service.ejb.sb.jms.RejectCounter;

/**
 * Compteur de rejets pour les MDBs de r�ception commande
 * 
 * @author rgvs7490
 */
public class ReceptionCdeRejectCounter implements RejectCounter {

	private static ReceptionCdeRejectCounter instance = new ReceptionCdeRejectCounter();

	private int counter = 0;

	/**
	 * Constructeur (priv� car pattern singleton)
	 */
	private ReceptionCdeRejectCounter() {
	}

	public static ReceptionCdeRejectCounter getInstance() {
		return instance;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.RejectCounter#getValue()
	 */
	public int getValue() {
		return counter;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.RejectCounter#increment()
	 */
	public synchronized void increment() {
		counter++;
	}

	/**
	 * @see com.soliste.bolbec.commun.service.ejb.sb.jms.RejectCounter#reset()
	 */
	public synchronized void reset() {
		counter = 0;
	}
}
