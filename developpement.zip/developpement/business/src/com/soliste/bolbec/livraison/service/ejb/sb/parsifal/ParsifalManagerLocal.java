/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.parsifal;

import javax.ejb.EJBLocalObject;

/**
 * Interface Local de l'EJB session InjectionCommandeManagerSB.
 * 
 * @author kyrw0678
 */
public interface ParsifalManagerLocal extends ParsifalManager, EJBLocalObject {

}
