/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.TacheManuelleLibelleUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.NatureIntervention;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.RessourceTechDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicInstanceRT;
import com.soliste.bolbec.livraison.service.model.extended.ExtendedLigneCommandeDTO;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.EtatInterventionConstantes;
import aps.EtatLigneCdeConstantes;
import aps.RessourceTechConstantes;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>14/06/2012</TD><TD>AGR</TD><TD>EV000184 : Achat FTTH, tache manuelle local tech</TD></TR>
 * <TR><TD>03/05/2013</TD><TD>BPE</TD><TD>DE-000815 : Disparition des infos dans la tache manuelle MAJ Localtechnique sur IHM G8R2 et commande G8R1</TD></TR>
 * <TR><TD>03/05/2013</TD><TD>BPE</TD><TD>DE-000815 : Correction anomalie sur le defect</TD></TR>
 * </TABLE><BR>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQ.5015</TD><TD>Func - EP0150 - D�clencher un traitement manuel de mise � jour du local technique pour les cr�ations d'acc�s FTTH Retail sur immeuble op�rateur</TD></TR>
 * </TABLE>
 */
public class TacheManuelleDTOFactory {

	private static final String STRING_OBLIGATOIRE = "O";

	/**
	 * Service Manager
	 */
	private static final IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();

	private TacheManuelleDTOFactory() {
		// Classe non instanciable
	}

	/**
	 * 
	 * @param tacheCouranteId
	 * @param evtProvoquantId
	 * @param modeOpName
	 * @param versionArtemis
	 * @return
	 */
	public static TacheManuelleDTO createAvecEvenements(String tacheCouranteId, String evtProvoquantId, String modeOpName, String versionArtemis) {

		TacheDTO tacheCourante = SERVICE_MANAGER.getProcessusManager().getTache(tacheCouranteId);
		EvtDTO evenementProvoquant = null;
		if (StringUtils.isNotEmpty(evtProvoquantId)) {
			evenementProvoquant = SERVICE_MANAGER.getProcessusManager().getEvt(evtProvoquantId);
		}
		String tacheType = getCorrespondanceType(tacheCourante);

		TacheManuelleDTO dto;
		if (TacheManuelleDTO.TACHE_MANUELLE_COMPLETUDE_CRI_TYPE.equals(tacheType)) {
			TacheManuelleCompletudeCriDTO a = new TacheManuelleCompletudeCriDTO();
			fillCompletudeCriData(a, tacheCourante);
			dto = a;
		} else if (TacheManuelleDTO.TACHE_MANUELLE_STANDARD_TYPE.equals(tacheType)) {
			dto = new TacheManuelleDTO();
		} else if (TacheManuelleDTO.TACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE.equals(tacheType)) {
			TacheManuelleCompletudeAdresseDTO a = new TacheManuelleCompletudeAdresseDTO();
			fillAdresseData(a, tacheCourante);
			dto = a;
		} else if (TacheManuelleDTO.TACHE_MANUELLE_RESERVATION_INTERVENTION_TYPE.equals(tacheType)) {
			dto = new TacheManuelleReservationInterventionDTO();
		} else if (TacheManuelleDTO.TACHE_MANUELLE_CONTACT_CLIENT_TYPE.equals(tacheType)) {
			dto = new TacheManuelleContactClientDTO();
		} else if (TacheManuelleDTO.TACHE_MANUELLE_LOCAL_TECH_TYPE.equals(tacheType)) {
			TacheManuelleLocalTechDTO a = new TacheManuelleLocalTechDTO();
			fillLocalTechData(a, tacheCourante);
			dto = a;
		} else {
			throw new RuntimeException("Le type de t�che manuelle " + tacheType + " n'est pas support�");
		}
		ProcessusDTO processus = SERVICE_MANAGER.getProcessusManager().findProcessusByTacheAndPere(tacheCourante.getId());
		dto.setIdProcessus(processus.getId());
		chargerCauseEvenementComplet(tacheCourante);
		dto.setTache(tacheCourante);

		String causeEvenementId = null;
		if (evenementProvoquant != null && evenementProvoquant.getCauseEvenement() != null) {
			causeEvenementId = evenementProvoquant.getCauseEvenement().getId();
		}
		dto.setModeOperatoireUrl(ModeOperatoireUtil.getUrlModeOperatoire(modeOpName, causeEvenementId, versionArtemis));

		ProcessusActionsAutorisees avpActionAutorisees = ActionsAutoriseesUtil.getProcessusActionsAutorisees(processus, null);

		dto.setAbandonnable(avpActionAutorisees.isAbandonnable());
		dto.setSuspendable(avpActionAutorisees.isSuspendable());
		dto.setRetablissable(avpActionAutorisees.isRetablissable());

		return dto;
	}

	private static void chargerCauseEvenementComplet(TacheDTO tache) {
		List<EvtDTO> evtDTOs = SERVICE_MANAGER.getProcessusManager().findEvtByTache(tache.getId());
		for (EvtDTO evt : evtDTOs) {
			CauseEvenementDTO causeEvtComplete = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseEvenement().getId());
			evt.setCauseEvenement(causeEvtComplete);
		}
	}

	private static void fillCompletudeCriData(TacheManuelleCompletudeCriDTO dto, TacheDTO tache) {
		List<ExtendedLigneCommandeDTO> prestations = new ArrayList<ExtendedLigneCommandeDTO>();
		List<InterventionDTO> interventions = new ArrayList<InterventionDTO>();
		List<String> interventionsId = new ArrayList<String>();

		ProcessusDTO processus = SERVICE_MANAGER.getProcessusManager().findProcessusByTacheAndPere(tache.getId());
		List<LigneCommandeDTO> lignesCde = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processus.getId());
		for (LigneCommandeDTO lc : lignesCde) {
			if (!EtatLigneCdeConstantes.ANN.equals(lc.getEtatLigneCde().getId())) {
				List<OpProgrammeeDTO> opProgrammees = SERVICE_MANAGER.getCommandeManager().findOpProgrammeByLigneCommande(lc.getId());
				for (OpProgrammeeDTO op : opProgrammees) {
					InterventionDTO interActive = op.getIntervention();
					NatureIntervention nature = SERVICE_MANAGER.getRendezVousManager().getNatureIntervention(interActive);
					if (interActive != null && NatureIntervention.INTERVENTION_CLIENT.equals(nature) && EtatInterventionConstantes.TERM.equals(interActive.getEtatIntervention().getId())) {

						if (!interventionsId.contains(interActive.getId())) {
							interventionsId.add(interActive.getId());
							interventions.add(interActive);
						}

						ExtendedLigneCommandeDTO extendedLc = new ExtendedLigneCommandeDTO(lc);
						prestations.add(extendedLc);
					}
				}
			}
		}

		dto.setInterventions(interventions);
		dto.setPrestations(prestations);
	}

	private static void fillAdresseData(TacheManuelleCompletudeAdresseDTO tacheDto, TacheDTO tache) {
		ProcessusDTO processus = SERVICE_MANAGER.getProcessusManager().findProcessusByTacheAndPere(tache.getId());
		LigneCommandeDTO firstLigneCde = SERVICE_MANAGER.getCommandeManager().findLigneCommandeByEstLivreParProcessusAndUneSeule(processus.getId());
		ClientDTO client = firstLigneCde.getClient();

		tacheDto.setAdresse(client.getAdresse());
		tacheDto.setNdplp(null);
	}

	/**
	 * Valorise la TacheManuelleLocalTechDTO avec les RG
	 * 
	 * @param tacheDto
	 * @param tache
	 */
	private static void fillLocalTechData(TacheManuelleLocalTechDTO tacheDto, TacheDTO tache) {
		ProcessusDTO processus = tache.getLancerParProcessus();
		List<InstanceRtDTO> instancesRT = SERVICE_MANAGER.getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processus.getId());

		RessourceTechDTO ressourceTech;
		for (InstanceRtDTO instanceRT : instancesRT) {
			// R�cup�ration de la ressource technique
			ressourceTech = instanceRT.getRessourceTech();
			ressourceTech = SERVICE_MANAGER.getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, ressourceTech.getId());

			if (RessourceTechConstantes.CBL_THD_VALEUR_CONSTANTE.equals(ressourceTech.getValeurConstante())) {
				// RG 7 : Valorisation du champ � Identification de l�acc�s
				tacheDto.setIdentificationAcces(instanceRT.getIdRt());

				// RG 9 : Valorisation du champ � Dossier
				tacheDto.setDossier(instanceRT.getIdExterne());
			} else if (RessourceTechConstantes.JONCO_FOURNISSEUR_VALEUR_CONSTANTE.equals(ressourceTech.getValeurConstante())) {
				Map<String, String> dynamicInstanceRts = instanceRT.getDynamicInstanceRts();

				// RG 8 : Valorisation du champ � Localisation du PB
				if (dynamicInstanceRts.containsKey(ConstantesDynamicInstanceRT.INSTANCERT_LOCALISATION_PB)) {
					tacheDto.setLocalisationPB(dynamicInstanceRts.get(ConstantesDynamicInstanceRT.INSTANCERT_LOCALISATION_PB));
				}

				// RG 10 : Valorisation du champ � Avertissement
				if (dynamicInstanceRts.containsKey(ConstantesDynamicInstanceRT.INSTANCERT_AVERTISSEMENT_IPON)) {
					tacheDto.setAvertissement(dynamicInstanceRts.get(ConstantesDynamicInstanceRT.INSTANCERT_AVERTISSEMENT_IPON));
				}
			}
		}

	}

	/**
	 * Retourne le type correspondant � la tache
	 * 
	 * @param tache
	 * @return
	 */
	public static String getCorrespondanceType(TacheDTO tache) {
		// initialiser la variable � "Standard"

		String typeTacheMan = TacheManuelleDTO.TACHE_MANUELLE_STANDARD_TYPE;

		if (TacheManuelleLibelleUtil.isTypeMajLocalTech(tache)) {
			// typeTacheMan = "LocTech"
			typeTacheMan = TacheManuelleDTO.TACHE_MANUELLE_LOCAL_TECH_TYPE;
		} else if (TacheManuelleLibelleUtil.isTypeCompletudeCri(tache)) {
			// typeTacheMan = "CRI"
			typeTacheMan = TacheManuelleDTO.TACHE_MANUELLE_COMPLETUDE_CRI_TYPE;
		} else if (TacheManuelleLibelleUtil.isTypeCompletudeAdresse(tache)) {
			// typeTacheMan = "Adresse"
			typeTacheMan = TacheManuelleDTO.TACHE_MANUELLE_COMPLETUDE_ADRESSE_TYPE;
		} else if (TacheManuelleLibelleUtil.isTypeContactClient(tache)) {
			// typeTacheMan = "Contact"
			typeTacheMan = TacheManuelleDTO.TACHE_MANUELLE_CONTACT_CLIENT_TYPE;
		} else if (TacheManuelleLibelleUtil.isTypeReservationIntervention(tache)) {
			// typeTacheMan = "Reserver"
			typeTacheMan = TacheManuelleDTO.TACHE_MANUELLE_RESERVATION_INTERVENTION_TYPE;
		}

		return typeTacheMan;
	}

}