package com.soliste.bolbec.livraison.service.ejb.sb.archiving;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.naming.NamingException;

import com.soliste.bolbec.commun.service.ejb.sb.archiving.ArchivingManager;
import com.soliste.bolbec.commun.service.ejb.sb.archiving.ArchivingManagerRemoteHome;
import com.soliste.bolbec.commun.service.ejb.sb.archiving.IArchivingManagerRemote;
import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.commun.service.util.archiving.Archivable;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;
import com.soliste.bolbec.fwk.jndi.ServiceLocator;
import com.soliste.bolbec.livraison.service.ejb.ConstantesJNDI;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */

public class RemoteArchivingManager implements ArchivingManager {

	private IArchivingManagerRemote manager = null;

	public static final String CLASS_NAME = RemoteArchivingManager.class.getName();

	public RemoteArchivingManager() {
		final String methodeName = "getArchivingManagerRemote()";
		// R�cup�re une instance de l'EJB ArchivingManagerSB
		try {
			ArchivingManagerRemoteHome managerHome = (ArchivingManagerRemoteHome) ServiceLocator.getInstance().getRemoteHome(ConstantesJNDI.JNDI_ARCHIVING_MANAGER_REMOTE, ArchivingManagerRemoteHome.class);
			manager = managerHome.create();
		} catch (RemoteException e) {
			String msg = "EJB " + ConstantesJNDI.JNDI_ARCHIVING_MANAGER_REMOTE + " non accessible : " + e;
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, methodeName, msg);
			throw new TechnicalBusinessException(msg, e);
		} catch (NamingException ne) {
			String msg = "EJB " + ConstantesJNDI.JNDI_ARCHIVING_MANAGER_REMOTE + " non accessible : " + ne;
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, methodeName, msg);
			throw new TechnicalBusinessException(msg, ne);
		} catch (CreateException ce) {
			String msg = "Impossible de creer " + ConstantesJNDI.JNDI_ARCHIVING_MANAGER_REMOTE + " : " + ce;
			ServiceManager.getInstance().getLoggerManager().severe(CLASS_NAME, methodeName, msg);
			throw new TechnicalBusinessException(msg, ce);
		}}

		@Override
		public void archiveToDatabase(Archivable archivable) throws ArchivingException {
			try {
				manager.archiveToDatabase(archivable);
			} catch (RemoteException e) {
				e.printStackTrace();
				throw new RuntimeException(e);
			}
		}
	}