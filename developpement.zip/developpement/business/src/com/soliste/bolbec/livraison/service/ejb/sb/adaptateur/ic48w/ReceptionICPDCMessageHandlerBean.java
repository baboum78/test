/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : ReceptionICPDCMessageHandlerBean.java
 *   Revision  : 06_00#1
 *   DateRev   : 21-NOV-2005 09:57:13
 *   Chemin    : ARTE/developpement/uc_adaptateurs/src.ejb/bolbec/adaptateur/ic49w/ReceptionICPDCMessageHandlerBean.java
 * --------------------------------------------
 *   Historique  :
 *    Revision 06_00#1 (CREE)
 *      Created:  21-NOV-2005 09:57:13 KFQD7402
 *        Version initiale
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic48w;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

import com.soliste.bolbec.commun.service.exception.TechnicalBusinessException;
import com.soliste.bolbec.fwk.log.Log;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.AdapatateurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic48w.util.AdaptationUtil;
import com.soliste.bolbec.livraison.service.exception.InvalidJmsMessageException;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ICInjectionDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.ic.ICUtil;
import com.soliste.bolbec.livraison.service.util.ic.InjectionCdeUtil;

import aps.EtatCommandeConstantes;
import bolbec.injection.xml.generated.Message;

/**
 * Adaptateur IC48W - Adapte la prise
 * de commande � la version G6. Ce service r�cup�re les Intentions de
 * Commandes transmises par la prise de commande (PDC) et les convertit
 * en format IC_Art�mis version G6. H�rite du bean
 * "ReceptionCdeMessageHandlerBean" de gestion g�n�rique de l'injection
 * des Intentions de Commande
 * 
 * @author KFQD7402
 * created on 14 nov. 2005
 * 
 */
public class ReceptionICPDCMessageHandlerBean extends AdapatateurMessageHandlerBean {

	private static final Log LOG = new Log(ReceptionICPDCMessageHandlerBean.class);

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.commun.AbstractMessageHandlerBean#processMessage(java.io.Serializable, CommandeDTO)
	 */
	public void processMessage(Serializable a_message, CommandeDTO commandeDTO) throws InvalidJmsMessageException {
		if (!(a_message instanceof Map<?, ?>)) {
			throw new InvalidJmsMessageException("Le message n'est pas une Map");
		}
		long begin = System.currentTimeMillis();
		try {
			@SuppressWarnings("unchecked")
			ICInjectionDTO injectionDTO = new ICInjectionDTO((Map<String, String>) a_message);
			// R�cup�ration du message XML et de l'instance de localisation de
			// l'intention de commande
			String xmlMessage = injectionDTO.getMessage();
			String instanceLocalisationId = injectionDTO.getInstanceLocalisation();

			// Unmarshaling du message XML
			Message l_msg = ICUtil.unmarshalMessageBody(xmlMessage);

			// Adaptation de l'intention de commande PDC au format IC_Artemis
			Message l_icArtemis = AdaptationUtil.adapt(l_msg);

			String nd = null;
			if (l_icArtemis.getCommande().getLigneCommande() != null && l_icArtemis.getCommande().getLigneCommande().length > 0 && l_icArtemis.getCommande().getLigneCommande(0).getProduitServiceSouhaite() != null)
				nd = l_icArtemis.getCommande().getLigneCommande(0).getProduitServiceSouhaite().getIdAccesClient();

			LOG.metro("'ReceptionICPDC' ND = " + nd + " ; REFEXTERNE = " + l_icArtemis.getCommande().getIdCommande() + " date = " + begin);

			// Injection de l'intention de commande au format IC_Artemis
			String xmlMessageToInject = ICUtil.marshal(l_icArtemis);
			HashMap<String, String> mapToInject = new HashMap<String, String>();
			mapToInject.put(Constantes.FIELD_MESSAGE, xmlMessageToInject);
			mapToInject.put(Constantes.FIELD_INSTANCE_LOCALISATION, instanceLocalisationId);
			mapToInject.put(Constantes.FIELD_ID_COMMANDE, commandeDTO.getId());

			InjectionCdeUtil.inject(mapToInject);
		} catch (TechnicalBusinessException e) {
			ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, "processMessage", "Exception lors du traitement de la commande " + commandeDTO.getId());
			commandeDTO.setEtatCommande(new EtatCommandeDTO(EtatCommandeConstantes.REJ));
			ServiceManager.getInstance().getInjectionCommandeManager().updateCommandeEtat(commandeDTO);
			throw new InvalidJmsMessageException(e.getMessage());
		} finally {
			long end = System.currentTimeMillis();
			String messageMetro = "'ReceptionICPDC' duree = " + (end - begin) + " ms";
			LOG.metro(messageMetro);
		}
	}

	public String getBaliseRefExterne() {
		return "idCommande=\"";
	}


}
