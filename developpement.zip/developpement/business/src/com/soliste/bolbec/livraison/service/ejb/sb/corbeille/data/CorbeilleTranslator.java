/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

/**
 * Classe permettant une traduction d'un CorbeilleInfo
 * 
 * @author gdzd8490
 */
public interface CorbeilleTranslator {

	/**
	 * Renvoie la traduction du CorbeillleInfo compr�hensible par le moteur de
	 * requ�tes
	 * 
	 * @param criterion
	 * l'identifiant du CorbeilleInfo � traduire
	 * @return la traduction du CorbeillleInfo compr�hensible par le moteur de
	 * requ�tes
	 */
	// TODO OLD: renvoyer une exception propre?
	public Object translate(String criterion);
}
