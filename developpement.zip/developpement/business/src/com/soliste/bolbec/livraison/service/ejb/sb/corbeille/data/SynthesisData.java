/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.util.List;

/**
 * Interface pour l'arbre de la corbeille (crit�res de regroupement)
 * 
 * @author gdzd8490
 * 
 */
public interface SynthesisData {

	/**
	 * Renvoie les donn�es de l'objet de synth�se
	 * 
	 * @return les donn�es de l'objet de synth�se
	 */
	public List<String> getValues();

	/**
	 * Renvoie la somme li�e � l'objet de synth�se
	 * 
	 * @return la somme li�e � l'objet de synth�se
	 */
	public int getSum();
}
