package com.soliste.bolbec.livraison.service.ejb.sb.initpharaon;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBException;
import javax.ejb.FinderException;
import javax.naming.NamingException;

import org.apache.commons.lang.StringUtils;

import aps.AnomalieConstantes;
import aps.ParametreArtemis;
import aps.PublicationConstantes;
import aps.SystemeExterneConstantes;
import aps.TacheEnCours;
import aps.TacheEnCoursHome;
import aps.TraductionCatCom;
import aps.TypeAnomalieConstantes;

import com.soliste.bolbec.commun.service.ejb.sb.commun.data.PharaonConfig;
import com.soliste.bolbec.commun.service.ejb.sb.commun.data.PharaonData;
import com.soliste.bolbec.commun.service.model.ZoneSiDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.commun.service.util.ConfigManager;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesRessourcesTech;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EpCommercialDTO;
import com.soliste.bolbec.livraison.service.model.InstanceFtDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.InterlocuteurDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OpProgrammeeDTO;
import com.soliste.bolbec.livraison.service.model.ParametreArtemisDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RessourceTechDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TraductionCatComDTO;
import com.soliste.bolbec.livraison.service.model.TypeRtDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.publication.Notification;
import com.soliste.bolbec.livraison.service.publication.Publication;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>09/04/2010</TD><TD>DBA</TD><TD>EV-000047: </TD></TR>
 * <TR><TD>14/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
 * <TR><TD>15/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de URL_INFOS</TD></TR>
 * <TR><TD>25/05/2010</TD><TD>DBA</TD><TD>EV-000047: Ajout d'un find By Processus</TD></TR>
 * <TR><TD>21/06/2010</TD><TD>DBA</TD><TD>EV-000047: Retour sur le traitement d'extraction (Pb transaction)</TD></TR>
 * <TR><TD>23/06/2010</TD><TD>DBA</TD><TD>EV-000047: Extraction mode Thread</TD></TR>
 * <TR><TD>23/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>30/09/2010</TD><TD>DBA</TD><TD>EV-000047: Catch des exceptions pour ne pas bloquer les IHM</TD></TR>
 * <TR><TD>13/10/2010</TD><TD>BPE</TD><TD>EV-000096: D�doublonnage des TacheEnCours</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Ajout accolades autour d'instruction seule</TD></TR>
 * <TR><TD>24/01/2011</TD><TD>CCL</TD><TD>EV-000124: Ajout d'un champ dans l'interface Pharaon</TD></TR>
 * <TR><TD>10/11/2011</TD><TD>BPE</TD><TD>DE-000190: Probl�me r�cup�ration accesLivraison</TD></TR>
 * <TR><TD>14/06/2012</TD><TD>FTE</TD><TD>EV-188 : Vente FTTH - pas d��mission de publication pour les commandes � Vente FTTH �</TD></TR>
 * <TR><TD>12/10/2012</TD><TD>GPA</TD><TD>EV-000083 : G8R2C1 - Requalification des �tudes 42C EC</TD></TR>
 * <TR><TD>30/01/2013</TD><TD>FTE</TD><TD>DE-000716 : Le NDPLP est r�cup�r� � partir de l'AccesLivraisonOrigine de la ligne de commande</TD></TR>
 * <TR><TD>14/05/2013</TD><TD>EBA</TD><TD>DE-000820 - Ajout d'une methode de publication depuis la tec</TD></TR>
 * <TR><TD>06/11/2013</TD><TD>VDE</TD><TD>EV-000227 "Mutation en masse DSLAM</TD></TR>
 * <TR><TD>14/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.5057</TD><TD>Func - EP0145 - Ne pas alimenter les Infocentres pour les commandes FTTH op�rateur</TD></TR>
 * <TR><TD>REQ.9333</TD><TD>Func - EP237 : Ne pas notifier les infocentres pour les commandes de mutations en masse (EV227)</TD></TR>
 * </TABLE>
 * 
 * @author dBaret
 * 
 */
public class PharaonInitLivManagerBean extends FwkSessionBean {

	/**
	 * serial version UID
	 */
	private static final long serialVersionUID = 4906398635884242335L;

	private static final String CLASS_NAME = PharaonInitLivManagerBean.class.getName();

	/** EJB de tache encours, permet de r�cup�rer les taches dans le getInit */
	private static TacheEnCoursHome tacheEnCoursHome = null;

	protected IServiceManager serviceManager = ServiceManager.getInstance();

	private static final String CST_ERREUR_ROLE = "Role";

	protected static final String PARAM_ENTETE = "PARAM_ENTETE";
	protected static final String PARAM_CAUSE_EVT = "PARAM_CAUSE_EVT";
	protected static final String PARAM_CAUSE_EVT_INITIALE = "PARAM_CAUSE_EVT_INITIALE";
	protected static final String PARAM_DATE_ACTION = "PARAM_DATE_ACTION";
	protected static final String PARAM_DATE_CONTRACTUELLE = "PARAM_DATE_CONTRACTUELLE";
	protected static final String PARAM_FAMILLE_OFFRE_FONCTIONNELLE = "PARAM_FAMILLE_OFFRE_FONCTIONNELLE";
	protected static final String PARAM_ID_COMMANDE = "PARAM_ID_COMMANDE";
	protected static final String PARAM_ID_INTERVENTION_GPC = "PARAM_ID_INTERVENTION_GPC";
	protected static final String PARAM_INDICATEUR_ACTION = "PARAM_INDICATEUR_ACTION";
	protected static final String PARAM_ND = "PARAM_ND";
	protected static final String PARAM_NDPLP = "PARAM_NDPLP";
	protected static final String PARAM_NOM_TACHE = "PARAM_NOM_TACHE";
	protected static final String PARAM_REFERENCE_ETUDE_42C = "PARAM_REFERENCE_ETUDE_42C";
	protected static final String PARAM_ROLE = "PARAM_ROLE";
	protected static final String PARAM_ZONE_SI = "PARAM_ZONE_SI";
	protected static final String PARAM_URL_INFOS = "PARAM_URL_INFOS";
	protected static final String ND_CONTACT = "ND_CONTACT";

	public static final String LIBCAUSEEVTINIT = "LIBCAUSEEVTINIT";
	public static final String LIBCAUSEEVT = "LIBCAUSEEVT";
	public static final String LIBACCESLIVRAISON = "LIBACCESLIVRAISON";

	public static final String INDICATEUR_ACTION_CREATION = "creation";

	/** La configuration de pharaon */
	private static PharaonConfig conf = null;

	/**
	 * 
	 * M�thode permettant de contr�ler les informations r�cup�r�es pour une publication pharaon
	 * 
	 * @param data : le PharaonData � v�rifier
	 * @return true si le data est valide, false sinon
	 */
	protected boolean checkData(PharaonData data) {
		boolean retour = false;
		if (StringUtils.isEmpty(data.getErreur())) {
			retour = true;
		} else {
			retour = false;
		}
		return retour;
	}

	/**
	 * 
	 * M�thode permettant de r�cup�rer les taches en cours pour l�initialisation de Pharaon
	 * 
	 * @return la liste des taches en cours des r�les pr�sent ds le PharaonConfig
	 */
	public List<TacheEnCoursDTO> getInit() {

		conf = loadConfig();

		// R�cup�ration de la liste des r�les
		List<String> rolePharaon = conf.getRoles();

		// R�cup�ration des TacheEnCours associ�es aux roles
		List<TacheEnCoursDTO> tacheEnCoursPharaon = findTachesEnCoursByRolesAndEtatCommandeAndCasMetier(rolePharaon);

		return tacheEnCoursPharaon;
	}

	/**
	 * 
	 * @param tec Une tache en cours
	 * @return Objet repr�sentant les don
	 */
	public PharaonData getDataForInit(TacheEnCoursDTO tec) {

		Notification n = new Notification();

		n.setIdTache(tec.getId());
		n.setIdCommande(tec.getIdCommande());
		n.setIdProcessus(tec.getIdProcess());

		n.getDynParam().put(LIBCAUSEEVTINIT, tec.getLibCauseEvt());
		n.getDynParam().put(LIBCAUSEEVT, tec.getLibCauseEvt());

		return getData(n, true);
	}

	/**
	 * M�thode permettant de g�n�rer un PharaonData � partir d'une tache en cours
	 * 
	 * @param notification La notification (Objet contenant les informations necessaire pour r�cup�rer les donn�es � publier vers Pharaon)
	 * @param init : vrai si la m�thode getData est appelee lors de la phase d'init Pharaon, false sinon
	 * @return un PharaonData ayant tout ses champs de valoris�es
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>12/10/2012</TD><TD>GPA</TD><TD>EV-000083: Gestion de la publication des commandes non requalifiables</TD></TR>
	 * </TABLE>
	 */
	public PharaonData getData(Notification notification, boolean init) {

		final TacheDTO tache = serviceManager.getProcessusManager().getTache(notification.getIdTache());
		final String idcommande = notification.getIdCommande();

		// Recupereation de la liste des lignes de commande
		final List<LigneCommandeDTO> lignesCommandes = serviceManager.getCommandeManager().findLigneCommandeByCommande(idcommande);

		// Recuperation de la liste des instanceRT de la commande
		final List<InstanceRtDTO> instanceRTList = new ArrayList<InstanceRtDTO>();
		PsSouhaiteDTO ps;
		InstanceFtDTO insFT;
		EpCommercialDTO epc;
		List<InstanceRtDTO> listeInsRT;
		for (LigneCommandeDTO ligneCommande : lignesCommandes) {
			ps = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(ligneCommande.getId());
			insFT = null;
			if (ps != null) {
				insFT = ps.getInstanceFt();
			} else {
				epc = serviceManager.getCommandeManager().findEpCommercialByLigneCommande(ligneCommande.getId());
				if (epc != null) {
					insFT = epc.getInstanceFt();
				}
			}
			if (insFT != null) {
				listeInsRT = serviceManager.getRessourceTechniqueManager().findInstanceRTByInstanceFT(insFT.getId());
				if (listeInsRT != null) {
					instanceRTList.addAll(listeInsRT);
				}
			}
		}

		final PharaonData pharaonData = new PharaonData();
		pharaonData.setEntete(PharaonData.Entete.Commande);

		// RG3 num�ro de d�signation
		final String nd = recupNd(lignesCommandes);
		pharaonData.setNd(nd);

		// RG8 valorisation de la zone SI
		pharaonData.setZoneSI(recupZoneSI(lignesCommandes));

		// RG9 valorisation de la reference d'etude 42C
		pharaonData.setRefEtude42C(recupRefEtude42C(instanceRTList));

		final String jalonPublication = notification.getTypeNotification();
		if (PublicationConstantes.PUB_PHARAON_CR.equals(jalonPublication) || PublicationConstantes.PUB_PHARAON_MO.equals(jalonPublication) || PublicationConstantes.PUB_PHARAON_SU.equals(jalonPublication)) {
			pharaonData.setEntete(PharaonData.Entete.AVP);

			// RG1 identifiant de la commande
			pharaonData.setIdcommande(idcommande);

			// RG2 nom de la tache en cours
			pharaonData.setNomTache(recupNomTache(tache));

			// RG4 num�ro de d�signation du plp
			pharaonData.setNdplp(recupNdplp(lignesCommandes));

			// RG5 valorisation de la date contractuelle
			pharaonData.setDateContractuelle(recupDateContractuelle(lignesCommandes));

			// RG6 valorisation de la famille d'offre fonctionnelle
			pharaonData.setFamilleOffreFonctionnelle(recupFamilleOffreFonctionnelle(idcommande));

			// RG7 valorisation du role
			pharaonData.setRole(recupRole(tache));
			if (pharaonData.getRole().equals(Constantes.CST_VIDE)) {
				pharaonData.setErreur(CST_ERREUR_ROLE);
			}

			// RG10 valorisation de la reference d'intervention GPC
			pharaonData.setIdIntervGPC(recupRefIntervGPC(lignesCommandes));

			// RG11 valorisation du libelle de la cause evenement
			pharaonData.setCauseEvt(recupCauseEvt(notification));

			// RG12 valorisation du libelle de la cause evenement initiale
			pharaonData.setCauseEvtInitiale(recupCauseEvtInitiale(notification));

			// RG13 valorisation de l'indicateur d'action
			if (init) {
				pharaonData.setIndicateurAction(INDICATEUR_ACTION_CREATION);
			} else {
				pharaonData.setIndicateurAction(recupIndicateurAction(notification));
			}

			// RG14 valorisation de la date d'action
			final String dateAction = DateUtils.format(DateUtils.getDate(), "dd/MM/yyyy");
			pharaonData.setDateAction(dateAction);

			// RG15 Valorisation de l'URL Infos
			pharaonData.setUrlInfos(generateUrlInfos(idcommande, nd, notification));

			// RG16 Valorisation du ND contact client
			pharaonData.setNdContactClient(recupNdContactClient(idcommande));
		}

		return pharaonData;

	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>21/06/2010</TD><TD>DBA</TD><TD>EV-000047: Retour sur le traitement d'extraction (Pb transaction)</TD></TR>
	 * <TR><TD>23/06/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de l'ouverture des descripteur dans le thread</TD></TR>
	 * </TABLE>
	 * 
	 * M�thode permettant de g�n�rer les deux ficher d'extraction d'une instance de livraison (ERR_EXT_LN et EXT_LN)
	 * 
	 * @param data
	 * @param fwExt
	 * @param fwErrExt
	 * @throws IOException : erreur lors de la cr�ation/�criture dans le fichier d'extraction ou d'erreur
	 */
	public void generateExtractFile(PharaonData data, FileWriter fwExt, FileWriter fwErrExt) throws IOException {

		conf = loadConfig();

		if (checkData(data)) {
			String formatData = formatDataForInitFile(data);
			// Ajout de la donn�e format�e
			fwExt.append(formatData + conf.getSepData());

		} else {
			String formatData = formatDataForInitFile(data);
			// Ajout de la donn�e format�e erron�e
			fwErrExt.append(data.getErreur() + ": " + formatData + conf.getSepData());
		}

	}

	/**
	 * gererDroitsFichier
	 * M�thode permettant de modifier les droits d'acces � un fichier
	 * 
	 * @param fichier � g�rer
	 * @param droit au format de la commande unix (ex "777" pour les droits max)
	 * @throws IOException
	 */
	public void gererDroitsFichier(String fichier, String droit) throws IOException {
		Runtime runtime = Runtime.getRuntime();
		String[] cmd = new String[3];
		cmd[0] = "chmod";
		cmd[1] = droit;
		cmd[2] = fichier;
		runtime.exec(cmd);
	}

	/**
	 * Finder permettant de r�cup�rer toute les taches en cours associ�es aux roles en entr�e et au cas m�tier de la commande
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>14/06/2012</TD><TD>FTE</TD><TD>Ajout du filtrage sur le cas m�tier avec la creation du finder</TD></TR>
	 * 
	 * @param roles : liste des roles
	 * @return tacheEnCoursPharaon : la liste des taches en cours ayant pour role un des role de la liste en entr�e
	 */
	public List<TacheEnCoursDTO> findTachesEnCoursByRolesAndEtatCommandeAndCasMetier(List<String> roles) {

		List<TacheEnCoursDTO> tacheEnCoursPharaon = new ArrayList<TacheEnCoursDTO>();
		if (roles != null) {
			for (String role : roles) {
				try {
					@SuppressWarnings("unchecked")
					Collection<TacheEnCours> tacheEnCours = getTacheEnCoursHome().findByRoleEtatCmdNotInAnnTermCasMetierNotInVenteFTTHOrderedByDateMiseADispo(role);
					for (TacheEnCours tache : tacheEnCours) {
						tacheEnCoursPharaon.add(new TacheEnCoursDTO(tache));
					}
				} catch (FinderException fe) {
					serviceManager.getLoggerManager().warning(CLASS_NAME, "tacheEnCoursHome.findByRole", "Probleme lors de la recherche des taches en cours pour le role " + role, fe);
					throw new EJBException(fe);
				}
			}
			// Suppression des doublons
			tacheEnCoursPharaon = filtreDoublonsTachesEnCours(tacheEnCoursPharaon);
		}
		return tacheEnCoursPharaon;
	}

	/**
	 * Filtre permettant de garder une seule t�che pour un m�me IdCommande
	 * 
	 * @param tachesEnCours : liste des t�ches en cours
	 * @return listeFiltree : liste des t�ches en cours d�doublonn�e
	 */
	protected List<TacheEnCoursDTO> filtreDoublonsTachesEnCours(List<TacheEnCoursDTO> tachesEnCours) {
		List<TacheEnCoursDTO> listeFiltree = new ArrayList<TacheEnCoursDTO>();
		Collection<String> tachesRecensee = new ArrayList<String>();
		for (TacheEnCoursDTO tacheEnCours : tachesEnCours) {
			if (!tachesRecensee.contains(tacheEnCours.getIdCommande())) {
				listeFiltree.add(tacheEnCours);
				tachesRecensee.add(tacheEnCours.getIdCommande());
			}
		}
		return listeFiltree;
	}

	/**
	 * 
	 * @return un PharaonConfig comprenant tout les parametres r�cup�r� en base et dans le fichier properties
	 */
	public PharaonConfig loadConfig() {

		// Chargement uniquement la premi�re fois
		if (conf == null) {

			// Cr�ation d'un nouveau pharaonConfig
			conf = new PharaonConfig();

			// Lecture des roles dans la table traduction cat com
			// -------------------------------------------------------
			List<TraductionCatComDTO> roles = serviceManager.getReferenceSpaceManager().listInReferenceSpace(TraductionCatComDTO.class, new Comparaison(TraductionCatCom.FIELD_CLE, Constantes.OPERATOR_EQUAL, "ROLE_PHARAON"),
					new Comparaison(TraductionCatCom.SLINK_POUR_SYSTEME_EXTERNE, Constantes.OPERATOR_EQUAL, SystemeExterneConstantes.NUM_49W));
			for (TraductionCatComDTO r : roles) {
				conf.getRoles().add(r.getValeurExterne());
			}

			// Lecture du s�parateur table Parametre bolbec
			// ----------------------------------------------------------------------------------
			ParametreArtemisDTO sep = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ParametreArtemisDTO.class, new Comparaison(ParametreArtemis.FIELD_CLE_PARAMETRE, Constantes.OPERATOR_EQUAL, "SeparateurPubliPharaon"),
					new Comparaison(ParametreArtemis.FIELD_VERSION, Constantes.OPERATOR_EQUAL, Constantes.VERSION));
			conf.setSepValue(sep.getValeurParametre());

			// Chargement du param�trage via le fichier properties
			ConfigManager configManager = new ConfigManager();
			configManager.loadConfig("Pharaon");

			conf.setSepData(configManager.getConfig(PharaonConfig.PHARAON_KEY_SEP_DATA));
			conf.setActif("OUI".equals(configManager.getConfig(PharaonConfig.PHARAON_KEY_ACTIF)));
			conf.setInitDir(configManager.getConfig(PharaonConfig.PHARAON_KEY_INIT_DIR));
			conf.setLogDir(configManager.getConfig(PharaonConfig.PHARAON_KEY_LOG_DIR));
			conf.setPrefixExtractFilename(configManager.getConfig(PharaonConfig.PHARAON_KEY_PREFIX_EXTRACT_FILENAME));
			conf.setPrefixInitFilename(configManager.getConfig(PharaonConfig.PHARAON_KEY_PREFIXE_INIT_FILE));
			conf.setExtractDir(configManager.getConfig(PharaonConfig.PHARAON_KEY_EXTRACT_DIR));

		}
		return conf;
	}

	/**
	 * Permet d'ajouter une valeur dans le message
	 * 
	 * @param pharaonDataFormate
	 * @param value
	 */
	private void appendValue(StringBuffer pharaonDataFormate, String value) {
		if (value != null) {
			pharaonDataFormate.append(value);
		} else {
			pharaonDataFormate.append(Constantes.CST_VIDE);
		}
		pharaonDataFormate.append(conf.getSepValue());
	}

	/**
	 * 
	 * m�thode permettant de mettre "� plat" un PharaonData avec les s�parateurs d�finis dans la configuration
	 * 
	 * @param data : le PharaonData contenant toute les informations � formater
	 * @return une chaine format�e utilsant le separateur d�finit dans PharaonConfig
	 */
	public String formatDataForInitFile(PharaonData data) {

		// Buffer contenant la chaine � plat a envoyer � pharaon pour l'initialisation
		StringBuffer pharaonDataFormate = new StringBuffer();

		// Construction du message � plat
		appendValue(pharaonDataFormate, data.getIdcommande());
		appendValue(pharaonDataFormate, data.getNomTache());
		appendValue(pharaonDataFormate, data.getNd());
		appendValue(pharaonDataFormate, data.getNdplp());
		appendValue(pharaonDataFormate, data.getDateContractuelle());
		appendValue(pharaonDataFormate, data.getFamilleOffreFonctionnelle());
		appendValue(pharaonDataFormate, data.getRole());
		appendValue(pharaonDataFormate, data.getZoneSI());
		appendValue(pharaonDataFormate, data.getRefEtude42C());
		appendValue(pharaonDataFormate, data.getIdIntervGPC());
		appendValue(pharaonDataFormate, data.getCauseEvt());
		appendValue(pharaonDataFormate, data.getCauseEvtInitiale());
		appendValue(pharaonDataFormate, data.getIndicateurAction());
		appendValue(pharaonDataFormate, data.getDateAction());
		appendValue(pharaonDataFormate, data.getUrlInfos());
		appendValue(pharaonDataFormate, data.getNdContactClient());

		// Retour de la chaine sans le dernier s�parateur
		return pharaonDataFormate.substring(0, pharaonDataFormate.length() - 1);
	}

	/**
	 * 
	 * RG2 nom de la tache en cours
	 * 
	 * @param tacheEnCours : la tache en cours dont on veut le libelle
	 * @return le nom de la tache
	 */
	protected String recupNomTache(TacheDTO tacheEnCours) {
		String nomTache = null;
		if (tacheEnCours != null) {
			nomTache = tacheEnCours.getLibelle();
		}
		if (nomTache == null) {
			nomTache = StringUtils.EMPTY;
		}
		return nomTache;
	}

	/**
	 * 
	 * RG3 num�ro de d�signation
	 * 
	 * @param lignesCommandes : une liste de ligne de commande
	 * @return le nd
	 */
	protected String recupNd(List<LigneCommandeDTO> lignesCommandes) {

		String nd = null;
		for (LigneCommandeDTO ligneCmd : lignesCommandes) {
			PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(ligneCmd.getId());
			if (psSouhaite != null) {
				// Cas d'une ligne de commande LigneCmdCatalogue
				nd = psSouhaite.getNd();
				break;
			}
			// Cas d'une LC LigneCmdModParc ou LigneCmdSupParc
			EpCommercialDTO epCommercial = serviceManager.getCommandeManager().findEpCommercialByLigneCommande(ligneCmd.getId());
			if (epCommercial != null) {
				nd = epCommercial.getNd();
				break;
			}
		}
		if (nd == null) {
			nd = StringUtils.EMPTY;
		}
		return nd;
	}

	/**
	 * 
	 * RG4 num�ro de d�signation du plp
	 * 
	 * @param lignesCommandes : une liste de ligne de commande
	 * @return le ndplp
	 */
	protected String recupNdplp(List<LigneCommandeDTO> lignesCommandes) {
		String ndplp = null;
		if (lignesCommandes != null && !lignesCommandes.isEmpty()) {
			for (LigneCommandeDTO ligneCommande : lignesCommandes) {
				String typeAccesLivraisonOrigine = ligneCommande.getTypeAccesLivraisonOrigine();
				if (Constantes.TYPEACCES_NDPLP.equals(typeAccesLivraisonOrigine)) {
					ndplp = ligneCommande.getAccesLivraisonOrigine();
					break;
				}
			}
		}
		if (ndplp == null) {
			ndplp = StringUtils.EMPTY;
		}
		return ndplp;
	}

	/**
	 * 
	 * RG5 valorisation de la date contractuelle
	 * 
	 * @param lignesCommandes : une liste de ligne de commande
	 * @return la date contratuelle
	 */
	protected String recupDateContractuelle(List<LigneCommandeDTO> lignesCommandes) {
		String res = null;
		Date dateContractuelle = null;
		if (lignesCommandes != null && !lignesCommandes.isEmpty()) {
			for (LigneCommandeDTO ligneCommande : lignesCommandes) {
				Date date = ligneCommande.getDateContractuelle();
				if (date != null) {
					if (dateContractuelle == null) {
						dateContractuelle = date;

					} else if (date.getTime() < dateContractuelle.getTime()) {
						dateContractuelle = date;
					}
				}
			}
		}

		if (dateContractuelle != null) {
			res = DateUtils.format(dateContractuelle.getTime(), "dd/MM/yyyy");
		} else {
			res = StringUtils.EMPTY;
		}

		return res;
	}

	/**
	 * 
	 * RG6 valorisation de la famille d'offre fonctionnelle
	 * 
	 * @param commandeId : l'id de la commande dont on veut la famille d'offre fonctionnelle
	 * @return la famille d'offre fonctionnelle
	 */
	protected String recupFamilleOffreFonctionnelle(String commandeId) {
		String familleOffreFonctionnelle = null;

		if (commandeId != null) {
			Map<String, String> dynamicsCommande = serviceManager.getCommandeManager().findDynamicsCommande(commandeId);
			familleOffreFonctionnelle = dynamicsCommande.get(ConstantesDynamicCommande.CLE_FAMILLE_OFFRE);
		}

		if (familleOffreFonctionnelle == null) {
			familleOffreFonctionnelle = StringUtils.EMPTY;
		}

		return familleOffreFonctionnelle;
	}

	/**
	 * 
	 * RG7 valorisation du role
	 * 
	 * @param tache : la tache en cours dont on veut le role
	 * @return le role associ� � la tache en cours
	 */
	protected String recupRole(TacheDTO tache) {
		String role = null;
		if (tache != null) {
			role = tache.getFaitParRole().getId();
		}
		if (role == null) {
			role = StringUtils.EMPTY;
		}
		return role;
	}

	/**
	 * 
	 * RG8 valorisation de la zone SI
	 * 
	 * @param lignesCommandes : une liste de ligne de commande
	 * @return la zoneSI
	 */
	protected String recupZoneSI(List<LigneCommandeDTO> lignesCommandes) {
		String zoneSI = null;
		if (lignesCommandes != null && !lignesCommandes.isEmpty()) {
			for (LigneCommandeDTO ligneCommande : lignesCommandes) {
				ZoneSiDTO zoneSiDTO = ligneCommande.getZoneSi();
				if (zoneSiDTO != null) {
					if (zoneSiDTO.getId() != null) {
						zoneSI = zoneSiDTO.getId();
						break;
					}
				}
			}
		}
		if (zoneSI == null) {
			zoneSI = StringUtils.EMPTY;
		}
		return zoneSI;
	}

	/**
	 * RG16 Valorisation du ND contact client
	 * 
	 * @param idCommande Identidiant de la commande
	 * @return Le ND contact client
	 */
	protected String recupNdContactClient(String idCommande) {
		String ndContactClient = StringUtils.EMPTY;

		CommandeDTO commande = serviceManager.getCommandeManager().getCommande(idCommande);

		if (commande != null && commande.getInterlocuteur() != null) {
			InterlocuteurDTO interlocuteur = commande.getInterlocuteur();

			String interlocuteurMobile = interlocuteur.getMobile();
			if (StringUtils.isNotEmpty(interlocuteurMobile)) {
				ndContactClient = interlocuteurMobile;
			} else {
				String interlocuteurTelephone = interlocuteur.getTelephone();
				if (interlocuteurTelephone != null) {
					ndContactClient = interlocuteur.getTelephone();
				}
			}
		}

		return ndContactClient;
	}

	/**
	 * 
	 * RG9 valorisation de la reference d'etude 42C
	 * 
	 * @param instanceRTList la liste des instances de ressources technique
	 * @return la reference de l'etude 42C ayant le pour type "CBL"
	 */
	protected String recupRefEtude42C(List<InstanceRtDTO> instanceRTList) {
		String refEtude42C = null;
		if (instanceRTList != null && !instanceRTList.isEmpty()) {
			for (InstanceRtDTO instanceRtDTO : instanceRTList) {
				String typeRessTech;
				RessourceTechDTO ressourceTech = instanceRtDTO.getRessourceTech();
				if (ressourceTech != null) {
					// Chargement de la ressource technique
					RessourceTechDTO ressTech = serviceManager.getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, ressourceTech.getId());
					TypeRtDTO typeRT = ressTech.getTypeRt();
					if (typeRT != null) {
						typeRessTech = typeRT.getValeurConstante();
						if (ConstantesRessourcesTech.CLE_CBL.equals(typeRessTech)) {
							refEtude42C = instanceRtDTO.getIdExterne();
							break;
						}
					}
				}
			}
		}
		if (refEtude42C == null) {
			refEtude42C = StringUtils.EMPTY;
		}
		return refEtude42C;
	}

	/**
	 * 
	 * RG10 valorisation de la reference d'intervention GPC
	 * 
	 * @param lignesCommandes : une liste de ligne de commande
	 * @return la reference de la derniere intervention GPC
	 */
	protected String recupRefIntervGPC(List<LigneCommandeDTO> lignesCommandes) {
		String refIntervGPC = null;

		// Recuperation de la liste des interventions
		List<InterventionDTO> interventions = new ArrayList<InterventionDTO>();
		if (lignesCommandes != null && !lignesCommandes.isEmpty()) {
			for (LigneCommandeDTO ligneCommande : lignesCommandes) {
				List<OpProgrammeeDTO> opProgrammeeList = serviceManager.getCommandeManager().findOpProgrammeByLigneCommande(ligneCommande.getId());
				if ((opProgrammeeList != null) && !opProgrammeeList.isEmpty()) {
					for (OpProgrammeeDTO opProgrammee : opProgrammeeList) {
						if (opProgrammee.getIntervention() != null) {
							interventions.add(opProgrammee.getIntervention());
						}
					}
				}
			}
		}

		// r�cup�rer la reference de l'intervention ayant la date de prise de rendez-vous la plus recente
		Date date_precedente = new Date(0L);
		if (!interventions.isEmpty()) {
			for (InterventionDTO intervention : interventions) {
				if (intervention.getDatePrise() != null) {
					if (intervention.getDatePrise().getTime() > date_precedente.getTime()) {
						refIntervGPC = intervention.getRefExterne();
						date_precedente = intervention.getDatePrise();
					}
				}
			}
		}
		if (refIntervGPC == null) {
			refIntervGPC = StringUtils.EMPTY;
		}

		return refIntervGPC;
	}

	/**
	 * 
	 * RG11 valorisation du libelle de la cause evenement
	 * 
	 * @param notification : Les informations li�es � la publication ou l'init
	 * @return le libelle de la cause evenement
	 */
	protected String recupCauseEvt(Notification notification) {
		String causeEvt = notification.getDynParam().get(LIBCAUSEEVT);
		if (causeEvt == null) {
			causeEvt = StringUtils.EMPTY;
		}
		return causeEvt;
	}

	/**
	 * 
	 * RG12 valorisation du libelle de la cause evenement
	 * 
	 * @param notification : la notification Pharaon
	 * @return le libelle de la cause evenement initiale
	 */
	protected String recupCauseEvtInitiale(Notification notification) {
		String causeEvtInit = notification.getDynParam().get(LIBCAUSEEVTINIT);
		if (causeEvtInit == null) {
			causeEvtInit = StringUtils.EMPTY;
		}
		return causeEvtInit;
	}

	/**
	 * 
	 * RG13 La valorisation de l�indicateur d�action se fait � partir du type de publication
	 * 
	 * @param notification : la notification Pharaon
	 * @return l'indicateur action r�cup�r� depuis la table Traduction
	 */
	protected String recupIndicateurAction(Notification notification) {
		String indicateur = StringUtils.EMPTY;
		// Recuperer l'indicateur action � partir du type publication de la notification dans la table tradiction
		indicateur = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_91P, ConstantesTraduction.TRADUCTION_CLE_INDICATEUR, notification.getTypeNotification());

		if (indicateur == null) {
			throw serviceManager.getAnomalieManager().newAnomalieException(Publication.PUBLICATION_FOP, AnomalieConstantes.ERREUR_TECHNIQUE, TypeAnomalieConstantes.DNR,
					CLASS_NAME + ".recupIndicateurAction" + " : Impossible de rediger un CR Pharaon, l'indicateur action calcul� est null.");
		}

		return indicateur;
	}

	/**
	 * M�thode permettant de g�n�rer l'url infos utilisable par Pharaon
	 * 
	 * @param idCmd l'denfiant de la commande
	 * @param nd La valeur du ND
	 * @return L'URL infos
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>10/11/2011</TD><TD>BPE</TD><TD>DE-000190: Probl�me r�cup�ration accesLivraison</TD></TR>
	 * </TABLE>
	 */
	protected String generateUrlInfos(String idCmd, String nd, Notification notification) {
		String ndUrlInfo;
		if (StringUtils.isNotEmpty(nd)) {
			ndUrlInfo = nd;
		} else {
			ndUrlInfo = notification.getDynParam().get(LIBACCESLIVRAISON);
		}
		if (ndUrlInfo == null) {
			ndUrlInfo = StringUtils.EMPTY;
		}
		return "redirect=traiterTaches.do&amp;idCmd=" + idCmd + "&amp;portail=pharaon&amp;ND=" + ndUrlInfo;
	}

	/**
	 * M�thode permettant de r�cup�rer une instance de l'EJB TacheEnCoursHome
	 * 
	 * @return L'instance de l'EJB
	 */
	public TacheEnCoursHome getTacheEnCoursHome() {
		if (tacheEnCoursHome == null) {
			try {
				tacheEnCoursHome = getEntityHome(TacheEnCoursHome.class);
			} catch (NamingException e) {
				serviceManager.getLoggerManager().severe(CLASS_NAME, "getTacheEnCoursHome", "Impossible de r�cup�rer l'EJB TacheEnCoursHome", e);
			}
		}
		return tacheEnCoursHome;
	}

}
