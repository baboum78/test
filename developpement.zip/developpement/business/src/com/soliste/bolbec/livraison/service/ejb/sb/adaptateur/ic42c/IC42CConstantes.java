/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

/**
 * $Workfile:   IC42CConstantes.java  $
 * $Revision:   1.7  $
 * $Date:   Oct 13 2004 16:59:04  $
 * $Log:   W:/00_PVCS_BOLBECG4/archives/developpement/uc_adaptateurs/src.ejb/bolbec/adaptateur/ic42c/IC42CConstantes.java-arc  $
 * 
 *    Rev 1.7   Oct 13 2004 16:59:04   EROY
 * modification des tailles max pour le nom et la prestation
 * 
 *    Rev 1.6   Sep 17 2004 17:08:32   EROY
 * ajout de constantes - suite � l'OGA 492
 * 
 *    Rev 1.5   Jun 10 2004 11:32:32   EROY
 * correction suite � l'OGA n�305
 * 
 *    Rev 1.4   May 17 2004 10:30:58   HBOURDIN
 * utilisation de constantes de DynamicFields
 * 
 *    Rev 1.3   Apr 20 2004 16:22:24   EROY
 * ajout des constantes d�finissant les anomalies
 * 
 *    Rev 1.2   Apr 09 2004 09:34:32   EROY
 * correction des cles pour les champs dynamiques
 * 
 *    Rev 1.1   Feb 27 2004 17:51:50   EROY
 * modification de CONSLIEN
 * 
 *    Rev 1.0   Feb 20 2004 16:08:40   EROY
 * Initial revision.
 * 
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.ic42c;

import aps.AnomalieConstantes;
import aps.ServiceExterneConstantes;

import com.soliste.bolbec.livraison.service.ConstantesParametreArtemis;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;

public interface IC42CConstantes {

	String CODE_ACTION = "CODE_ACTION";
	String CONSLIEN = ServiceExterneConstantes.S42C_CONSLIEN;
	String CONTEXTE = "CONTEXTE";
	String COPCO = "COPCO";
	String DXF = ConstantesParametreArtemis.DXF;
	String MOTIF_RESIL = "MOTIF_RESIL";
	String OP = "OP";
	String PROVID = "PROVID";
	String SEPARATEUR = "\\|";
	String PROVIDER = "Provider";
	String OPERATEUR = "Operateur";

	// D�claration des attributs XML
	String ATT_MESSAGE = "Message";
	String ATT_ND = "ND";
	String ATT_PREFIXE = "Prefixe";

	// D�claration des tags XML
	String TAG_IC = "IC";
	String TAG_ROOT = "CommandeIC42C";

	// D�claration des formats de date
	String FORMAT_DATE_HEURE = "dd/MM/yyyy HH:mm:ss";
	String FORMAT_DATE = "dd/MM/yyyy";

	// D�claration des valeurs possibles de motif de r�siliation
	String MOTIF_RESIL_PO = "PO";
	String MOTIF_RESIL_RD = "RD";
	String MOTIF_RESIL_RO = "RO";
	String MOTIF_RESIL_TL = "TL";
	String MOTIF_RESIL_TS = "TS";
	String MOTIF_RESIL_SLS = "SLS";
	String MOTIF_RESIL_STX = "STX";

	// D�claration des valeurs possibles de type de commande
	String TYPE_CDE_CHGT = "CHGT";
	String TYPE_CDE_CNOM = "CNOM";
	String TYPE_CDE_DENUM = "DENUM";
	String TYPE_CDE_RESIL = "RESIL";

	// Types de vente possibles
	String TYPE_DE_VENTE_WHOLESALE = "WHOLESALE";

	// D�claration de nom de champs
	String CLE_CATEGORIE = "CATEGORIE";
	String CLE_CODE_EDSI = ConstantesDynamicLigneCommande.LIGNECOMMANDE_EDSI; // "CODEEDSI";
	String CLE_CODE_USC = ConstantesDynamicLigneCommande.LIGNECOMMANDE_USC; // "CODEUSC";
	String CLE_DETENTION = "DETENTION";
	String CLE_ID_COMMANDE = "ID_COMMANDE";
	String CLE_ID_EPC = "ID_EPC";
	String CLE_ID_ACCES_CLIENT = "ID_ACCES_CLIENT";
	String CLE_ID_CLIENT_CONTRACTANT = "ID_CLIENT_CONTRACTANT";
	String CLE_ID_LIGNE_CDE = "ID_LIGNE_CDE";
	String CLE_MOTIF_RESIL = ConstantesDynamicLigneCommande.LIGNECOMMANDE_MOTIF_RESIL; // "MOTIF_RESIL";
	String CLE_NOM = "NOM";
	String CLE_NOUVEAU_ND = ConstantesDynamicPSSouhaite.PSSOUHAITE_NOUVEAU_ND; // "NOUVEAU_ND";
	String CLE_NOUVEAU_NOM = ConstantesDynamicPSSouhaite.PSSOUHAITE_NOUVEAU_NOM; // "NOUVEAU_NOM";
	String CLE_OFFRE = "OFFRE";
	String CLE_OSIRIS_IDOFFREORIG = ConstantesDynamicPSSouhaite.PSSOUHAITE_OSIRIS_IDOFFREORIG; // "OsirisIdOffreOrigine"
	String CLE_OSIRIS_OPPONCTORIG = ConstantesDynamicLigneCommande.LIGNECOMMANDE_OSIRIS_OPPONCTORIG; // "OsirisOpPonctuelleOrigine"
	String CLE_PARAMETRES = "PARAMETRES";
	String CLE_PRESTATION = ConstantesDynamicLigneCommande.LIGNECOMMANDE_PRESTATION; // "PRESTATION";
	String CLE_RENVOI_REPART = ConstantesDynamicLigneCommande.LIGNECOMMANDE_RENVOI_REPARTITEUR; // "RENVOI_REPARTITEUR";
	String CLE_REPARTITEUR = ConstantesDynamicLigneCommande.LIGNECOMMANDE_REPARTITEUR; // "REPARTITEUR";

	// D�claration des anomalies Adaptateur 42C
	String ANO_ERREUR_INTERNE = AnomalieConstantes.ERREUR_INTERNE;
	String ANO_ERREUR_TRADUCTION = AnomalieConstantes.ERREUR_TRADUCTION;
	String ANO_IC42C_NON_TRAITEE = AnomalieConstantes.IC42C_NON_TRAITEE;
	String ANO_IC42C_SYNTAXE = AnomalieConstantes.IC42C_SYNTAXE;
}
