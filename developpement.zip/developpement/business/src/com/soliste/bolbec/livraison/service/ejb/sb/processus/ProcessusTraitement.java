/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.ejb.CreateException;
import javax.ejb.EJBException;

import org.apache.commons.lang3.StringUtils;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfException;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.api.exception.APIExceptionEnum;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.NdGelesDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.commun.service.util.archiving.ArchivingException;
import com.soliste.bolbec.commun.service.util.log.ILoggerManager;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ConstantesTraduction;
import com.soliste.bolbec.livraison.service.anomalies.AnomalieException;
import com.soliste.bolbec.livraison.service.anomalies.Evenement;
import com.soliste.bolbec.livraison.service.anomalies.SFAno;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.data.AccesLivraisonKey;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.data.KeyPair;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfTache;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.AvpItemDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CloturerTacheManuelleCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CloturerTacheManuelleCompAdresseCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.CloturerTacheManuelleDecrochageCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.AbandonnerProcessusException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.ControlerAbandonProcessusException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.ControlerDiffererProcessusException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.ControlerRetablirProcessusException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.ControlerSuspensionProcessusException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.ReserverProcessusException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.exception.SuspendreProcessusException;
import com.soliste.bolbec.livraison.service.ejb.sb.rdv.data.NatureIntervention;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.WorkflowManager;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.exception.UnavailableTaskException;
import com.soliste.bolbec.livraison.service.enumeration.CochisePharaonIndicateurActionEnum;
import com.soliste.bolbec.livraison.service.enumeration.EventTypeVadorEnum;
import com.soliste.bolbec.livraison.service.enumeration.OffreEnum;
import com.soliste.bolbec.livraison.service.enumeration.TypeAccesLivraisonEnum;
import com.soliste.bolbec.livraison.service.helper.CommandeHelper;
import com.soliste.bolbec.livraison.service.interfaces.commun.CommandeTraitee;
import com.soliste.bolbec.livraison.service.interfaces.commun.TacheIn;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.LibererPlage;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.CritereIntervention;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.sync.gestionintervention.data.IOLibererPlage;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.CasMetierDTO;
import com.soliste.bolbec.livraison.service.model.CatalogueActiviteDTO;
import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CategorieEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EtatInterventionDTO;
import com.soliste.bolbec.livraison.service.model.EtatLigneCdeDTO;
import com.soliste.bolbec.livraison.service.model.EtatProcessusDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.FamilleOffreComDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.JalonDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusLcDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusSuspendusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.SystemeExterneDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicIntervention;
import com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory;
import com.soliste.bolbec.livraison.service.publication.GestionnairePublication;
import com.soliste.bolbec.livraison.service.publication.Notification;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.stepauto.traitements.AbandonLiberationIntervTraitement;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ProcessusUtil;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.VersionArtemisUtil;

import aps.AnomalieConstantes;
import aps.CasMetierConstantes;
import aps.CauseEvenementConstantes;
import aps.EtatInterventionConstantes;
import aps.EtatLigneCdeConstantes;
import aps.EtatProcessusConstantes;
import aps.JalonConstantes;
import aps.MessagesConstantes;
import aps.ProcessusTypeConstantes;
import aps.PublicationConstantes;
import aps.StatutCommandeConstantes;
import aps.SystemeExterneConstantes;
import aps.TraitementConstantes;
import aps.TypeAnomalieConstantes;

/**
 * Regroupement des m�thodes "fonctionnelles" utilis�es dans les IHM.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
 * <TR><TD>25/05/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion des actions de l'onglet commande</TD></TR>
 * <TR><TD>08/06/2010</TD><TD>PHC</TD><TD>IRMA_57: Ajout du cas ENVOI</TD></TR>
 * <TR><TD>21/09/2010</TD><TD>YTR</TD><TD>Refactor</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>02/03/2011</TD><TD>GPE</TD><TD>EV-000089: mauvaise condition pour lib�rer les intervations</TD></TR>
 * <TR><TD>18/05/2011</TD><TD>BPE</TD><TD>Defect 202 : Ajout d'un contr�le sur la valeur de l'idEvt</TD></TR>
 * <TR><TD>19/09/2011</TD><TD>GPA</TD><TD>EV-000140: Remont�e des AVPs � suivi commande</TD></TR>
 * <TR><TD>15/12/2011</TD><TD>GPA</TD><TD>EV-000173: Appel du traitement AbandonLiberationIntervTraitement</TD></TR>
 * <TR><TD>25/10/2012</TD><TD>FTE</TD><TD>EV-000183 : Apostrof</TD></TR>
 * <TR><TD>13/11/2012</TD><TD>EBA</TD><TD>EV-000183 : Ajout d'un serviceManager pour tests U (et perfs)</TD></TR>
 * <TR><TD>25/04/2013</TD><TD>GPA</TD><TD>G8R2C2 : Suppression du doublon sur le MG_ClotureTache</TD></TR>
 * <TR><TD>14/05/2013</TD><TD>FTE</TD><TD>DE-000820 - Sauvegarde des tec d'une cde avant son abandon en vue de la publication vers Pharaon</TD></TR>
 * <TR><TD>28/05/2013</TD><TD>GPA</TD><TD>G8R2C2 - DE-000348 : VHB Annulation : Appel 3 fois GPC pour lib�rer intervention</TD></TR>
 * <TR><TD>31/05/2013</TD><TD>BPE</TD><TD>DE-000846 : Suppression du marquage de la commande lors d'un abandon sur une commande en compl�tude</TD></TR>
 * <TR><TD>12/07/2013</TD><TD>JLA</TD><TD>REFACTORING : suppression de la conditon processus &lt; 6200</TD></TR>
 * <TR><TD>16/10/2013</TD><TD>BPE</TD><TD>G8R2C3 - EV-000250 "Correction mineure"</TD></TR>
 * <TR><TD>08/11/2013</TD><TD>EBA</TD><TD>G8R2C4 - EV-273 : Corrections Sonar </TD></TR>
 * <TR><TD>08/01/2014</TD><TD>EBA</TD><TD>G8R2C4 - EV-266 : Gel du ND</TD></TR>
 * <TR><TD>27/02/2014</TD><TD>VDE</TD><TD>EV-000284 Plug and Play</TD></TR>
 * <TR><TD>14/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * <TR><TD>06/03/2017</TD><TD>JDE</TD><TD>G9R2C1 : Publication de CR EFB via l'EJB AvpManager pour la cloture de t�che manuelle (probl�me QueueHelper)</TD></TR>
 * <TR><TD>15/05/2017</TD><TD>JDE</TD><TD>G9R2C1 : QC974 Vador</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'><TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.1328</TD><TD>EP048 - Identifier les t�ches candidates � la publication</TD></TR>
 * <TR><TD>REQ.1329</TD><TD>EP049 - Utiliser le m�canisme existant de publication des CR</TD></TR>
 * <TR><TD>REQ.1330</TD><TD>EP050 - Envoyer un message � chaque action sur une t�che candidate � la publication</TD></TR>
 * <TR><TD>REQ.10347</TD><TD>EP264 - Indiquer � 42C que le ND doit �tre conserv� lors de l'abandon sur certains cas de gestion</TD></TR>
 * <TR><TD>REQ.10349</TD><TD>EP265 - Stocker les commandes dont le ND a �t� gel� lors de l'abandon</TD></TR>
 * <TR><TD>REQ.10380</TD><TD>EP0296 � Identifier les commandes de type Plug and Play</TD></TR>
 * </TABLE>
 */
public final class ProcessusTraitement {

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = ProcessusTraitement.class.getSimpleName();

	/** The Constant ERRMSG_CORBEILLE_ERROR_SUSPENDRE_VERSION_WORKFLOW. */
	private static final String ERRMSG_CORBEILLE_ERROR_SUSPENDRE_VERSION_WORKFLOW = "Corbeille.error.suspendre.versionWfInterditSuspendre";

	/** The Constant ERRMSG_KEY_CORBEILLE_ERROR_ABANDONNER_ETAT_PROCESSUS_INCOMPATIBLE. */
	private static final String ERRMSG_KEY_CORBEILLE_ERROR_ABANDONNER_ETAT_PROCESSUS_INCOMPATIBLE = "Corbeille.error.abandonner.etatProcessusIncompatible";

	/** The Constant ERRMSG_KEY_CORBEILLE_ERROR_DIFFERER_EN_MASSE_ETAT_PROCESSUS_INCOMPATIBLE. */
	private static final String ERRMSG_KEY_CORBEILLE_ERROR_DIFFERER_EN_MASSE_ETAT_PROCESSUS_INCOMPATIBLE = "Corbeille.error.differerEnMasse.etatProcessusIncompatible";

	/** The Constant ERRMSG_KEY_CORBEILLE_ERROR_DIFFERER_ETAT_LIGNE_COMMANDE_INCOMPATIBLE. */
	private static final String ERRMSG_KEY_CORBEILLE_ERROR_DIFFERER_ETAT_LIGNE_COMMANDE_INCOMPATIBLE = "Corbeille.error.differerEnMasse.etatLigneCommandeIncompatible";

	/** The Constant ERRMSG_KEY_CORBEILLE_ERROR_RETABLIR_ETAT_PROCESSUS_INCOMPATIBLE. */
	private static final String ERRMSG_KEY_CORBEILLE_ERROR_RETABLIR_ETAT_PROCESSUS_INCOMPATIBLE = "Corbeille.error.retablir.etatProcessusIncompatible";

	/** The Constant ERRMSG_KEY_CORBEILLE_ERROR_SUSPENDRE_ETAT_PROCESSUS_INCOMPATIBLE. */
	private static final String ERRMSG_KEY_CORBEILLE_ERROR_SUSPENDRE_ETAT_PROCESSUS_INCOMPATIBLE = "Corbeille.error.suspendre.etatProcessusIncompatible";

	/** The Constant STRING_AVP. */
	private static final String STRING_AVP = "AVP";

	/** The Constant STRING_TACHE_MANUELLE. */
	private static final String STRING_TACHE_MANUELLE = "MANUELLE";

	/** The Constant STRING_COMPLETER_CR. */
	private static final String STRING_COMPLETER_CR = "CompleterCR";

	/** The Constant STRING_COMPLETER_CRABAN. */
	private static final String STRING_COMPLETER_CRABAN = "CompleterCRABAN";

	/** The Constant STRING_BLANK. */
	private static final String STRING_BLANK = "";

	/** The Constant TACHE_MANUELLE */
	private static final String TACHE_MANUELLE = "MANUELLE";

	/** The Constant TACHE_AVP */
	private static final String TACHE_AVP = "AVP";

	/** Nombre de caract�res maximal du champ info */
	private static final int MAX_CHAR_INFO = 300;

	/** Publications sur AVP vers Vador */
	private static final String PUB_AVP_VAO = "PUB_VADOR";

	private static IServiceManager serviceManager = ServiceManager.getInstance();

	public static IServiceManager getServiceManager() {
		return serviceManager;
	}

	public static void setServiceManager(IServiceManager serviceManager) {
		ProcessusTraitement.serviceManager = serviceManager;
	}

	/**
	 * constructeur priv� pour classe full statique
	 */
	private ProcessusTraitement() {
	}

	/**
	 * Pr�pare l'abandon d'un processus.
	 * 
	 * @param papaProcessus le processus � abandonner
	 * @param evenement l'�v�nement n�cessaire � l'abandon
	 * @param reprise indique si l'annulation est d�finitive (false) ou pas (true)
	 * @param systemeExterneId l'identifiant du syst�me externe demandant l'abandon
	 * (null si bolbec)
	 * @param wfUser the wf user
	 * @param abandon the abandon
	 * 
	 * @return null si le traitement s'est bien pass�, et une SFAno s'il y a eu un
	 * probl�me
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>02/03/2011</TD><TD>GPE</TD><TD>EV-000089: mauvaise condition pour lib�rer les intervations</TD></TR>
	 * <TR><TD>20/02/2013</TD><TD>GPA</TD><TD>DE-000760(interne): Analyse de la lib�ration des interventions dans les cas GRAFIC et FRONTAL</TD></TR>
	 * <TR><TD>26/04/2013</TD><TD>GPA</TD><TD>G8R2C1 - Erreur post MEP G8R2C1 LN - Suppression de la suppresion de la t�che en cours</TD></TR>
	 * </TABLE>
	 */
	public static SFAno preparerAbandon(ProcessusDTO papaProcessus, Evenement evenement, boolean reprise, String systemeExterneId, WfUser wfUser, String abandon, TacheEnCoursDTO tec) {
		final String method = "preparerAbandon";
		// Contr�le de la validit� de la cause d�abandon vis � vis de l��tat d�avancement du processus
		Set<String> causeEvenementIds;
		if (StringUtils.isBlank(abandon) || ConstantesTraduction.ABD_PROVISOIRE.equals(abandon)) {
			// abandon simple
			causeEvenementIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandon(papaProcessus.getId(), systemeExterneId, null);
		} else {
			// abandon complet ou partiel
			causeEvenementIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandonMixte(abandon, papaProcessus.getId(), systemeExterneId, null);
		}

		// EV-469 si sys extern = null (IHM ou API) alors ajout causes abandon generiques
		if (systemeExterneId == null) {
			CommandeDTO cmd = serviceManager.getCommandeManager().findCommandeByProcessus(papaProcessus.getId());
			List<LigneCommandeDTO> ldcList = serviceManager.getCommandeManager().findLigneCommandeByCommande(cmd.getId());
			if(null != ldcList && !ldcList.isEmpty() && null != ldcList.get(0).getJalon()) {
				
				JalonDTO jalActuel = serviceManager.getReferenceSpaceManager().findInReferenceSpace(JalonDTO.class, ldcList.get(0).getJalon().getId());
				JalonDTO jalonMax = serviceManager.getReferenceSpaceManager().findInReferenceSpace(JalonDTO.class, JalonConstantes.J_MES);
				if( jalActuel.getRang() < jalonMax.getRang() ) {
					Set<String> causesAbandonGeneriquesIds = CauseEvenementUtil.getCauseEvenementAbandonGeneriqueId(papaProcessus);
					causeEvenementIds.addAll(causesAbandonGeneriquesIds);
				}
				
			}
		}

		SFAno sfAno = null;
		if (causeEvenementIds != null && !causeEvenementIds.contains(evenement.getIdCauseEvenement())) {
			String jalon = getJalon(papaProcessus.getId());
			String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.PREPABAN_000030, jalon, systemeExterneId);
			String ano = VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.CAUSE_ABANDON_IMP_VALEUR_CONSTANTE, papaProcessus);
			sfAno = serviceManager.getAnomalieManager().newSFAno(TraitementConstantes.PREPABANDON, ano, SFAno.TYPE_DNR, message);
			return sfAno;
		}

		// Marquage de la commande pour la conservation du ND
		// et sauvegarde de l'abandon
		marquageCommandePourGelND(papaProcessus, abandon);

		try {
			// Lib�ration des interventions �ventuelles
			if (!ConstantesTraduction.ABD_PARTIEL.equals(abandon) && !ConstantesTraduction.ABD_PROVISOIRE.equals(abandon)) {
				String responsabiliteId = evenement.getResponsabiliteId();
				CauseEvenementDTO causeEvt = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evenement.getIdCauseEvenement());
				if (StringUtils.isBlank(responsabiliteId) && causeEvt.getResponsabilite() != null) {
					responsabiliteId = causeEvt.getResponsabilite().getId();
				}
				sfAno = AbandonLiberationIntervTraitement.process(papaProcessus, responsabiliteId);
				sfAno = analyserLiberationGraficFrontal(systemeExterneId, sfAno);
				if (sfAno != null) {
					return sfAno;
				}
				serviceManager.getLoggerManager().finer(CLASSNAME, method, "Lib�ration des interventions effectu�e.");
			}

			// M�moriser l��v�nement r�cup�r�
			createEvtPourProcessus(evenement, papaProcessus.getId(), papaProcessus.getIdCommande());

			rechercheEtSuppressionTacheEnCoursByProcessus(papaProcessus.getId());

			// Transmission de la demande d�abandon au workflow
			abandonWorkflow(wfUser, papaProcessus, reprise, evenement, abandon); // TODO G10 : R�vision du processus p�re.

		} catch (CreateException e) {
			throw new EJBException(e);
		}
		// Publication pour Cochise/Pharaon
		Notification notification = serviceManager.getCochisePharaonManager().creerNotificationAbandonRegul(PublicationConstantes.PUB_COCHISE_PHARAON_ABANDON, papaProcessus, evenement.getId());
		if (notification != null) {
			serviceManager.getCochisePharaonManager().publierMessage(notification);
		}
		// RG 8 : Publication vers Vador
		CommandeDTO commandeDto = serviceManager.getCommandeManager().findCommandeByProcessus(papaProcessus.getId());
		if (commandeDto.getCasMetier() != null && CasMetierConstantes.VENTE_FTTH.equals(commandeDto.getCasMetier().getId())) {
			Notification notificationVador = new Notification(PUB_AVP_VAO, papaProcessus.getId(), evenement.getId());
			notificationVador.setIdTache(tec.getId());
			notificationVador.setTacheEnCours(tec);
			notificationVador.getDynParam().put(EventTypeVadorEnum.ABANDON.toString(), Constantes.CST_OUI);
			GestionnairePublication.publierFromEJB(notificationVador);
		}
		return null;
	}

	/**
	 * G�re le marquage d'une commande pour le gel du ND
	 * Si le traitement du marquage du ND �choue, aucune anomalie n'est remont�. L'abandon doit continuer
	 * 
	 * @param papaProcessus le processus p�re
	 * @param abandon la valeur du type d'abandon
	 */
	private static void marquageCommandePourGelND(ProcessusDTO papaProcessus, String abandon) {
		final String methode = "marquageCommandePourGelND";
		final ILoggerManager logger = serviceManager.getLoggerManager();
		final CommandeManager commandeManager = serviceManager.getCommandeManager();

		// R�cup�ration des informations n�cessairse, � savoir la commande, les lignes de commandes et offres assossi�es
		final CommandeDTO cmd = commandeManager.findCommandeByProcessus(papaProcessus.getId());
		final String idCmd = cmd.getId();
		final List<LigneCommandeDTO> ldcList = commandeManager.findLigneCommandeByCommande(idCmd);

		// On v�rifie si la commande traite une construction de boucle locale (typeAcces origine NDCLI ou NDPLP)
		// Si ce n'est pas le cas, on s'arr�te ici
		if (!isCommandeConstructionBoucleLocale(ldcList)) {
			return;
		}

		// R�cup�ration des offres de cr�ation associ�es � leur ligne de commande
		final Map<OffreDTO, LigneCommandeDTO> offresLcCrmap = getOffresLcCrMap(ldcList);

		// Extraction du typeVente (peut �tre null)
		final String typeVente = extraireTypeVente(offresLcCrmap.keySet());

		// Si le type de vente n'est pas trouv�, la commande n'est pas � marquer : on s'arr�te ici
		if (typeVente == null) {
			return;
		}

		// Si la commande n'est pas � marquer, on s'arr�te ici.
		if (!isCommandeAMarquerPourGelNd(cmd, offresLcCrmap, typeVente)) {
			return;
		}

		// R�cup�ration du nd (premier trouv�)
		String nd = null;
		for (LigneCommandeDTO ldc : ldcList) {
			if (StringUtils.isNotBlank(ldc.getAccesLivraison())) {
				nd = ldc.getNdFinder();
				break;
			}
		}

		// Si nd non trouv� => arr�t du marquage (Ce cas ne devrait pas se produire)
		if (StringUtils.isBlank(nd)) {
			logger.warning(CLASSNAME, methode, String.format("Impossible de marquer la commande \"%s\" si aucun nd n'a �t� trouv�", idCmd));
			return;
		}

		// Nous sommes dor�navant dans un cas de marquage de commande
		marqueCmdGelND(cmd, nd, typeVente, abandon);
	}

	/**
	 * @param ldcList la liste de lignes de commande
	 * @return true si la commande est une construction de boucle locale, false sinon
	 */
	private static boolean isCommandeConstructionBoucleLocale(final List<LigneCommandeDTO> ldcList) {
		for (LigneCommandeDTO lc : ldcList) {
			if (Arrays.asList(TypeAccesLivraisonEnum.IDCLI.name(), TypeAccesLivraisonEnum.NDPLP.name()).contains(lc.getTypeAccesLivraisonOrigine())) {
				return true;
			}
		}
		return false;
	}

	/**
	 * Extrait le type de vente de la commande
	 * 
	 * @param offresList la liste d'offres de cr�ation li�e � la commande
	 * @return le type de vente si trouv�, sinon null
	 */
	private static String extraireTypeVente(final Set<OffreDTO> offresList) {
		for (OffreDTO offre : offresList) {
			if (StringUtils.isNotBlank(offre.getTypeDeVente())) {
				return offre.getTypeDeVente();
			}
		}
		return null;
	}

	/**
	 * D�termine si oui ou non la commande est � marquer pour gel du ND
	 * 
	 * @param commande la commande
	 * @param offresLcCrmap la map des offre de cr�ation -> ligne de commande de cr�ation li�e � la commande
	 * @param typeVente Le type de Vente de la commande
	 * @return true si la commande est � marquer, false sinon
	 */
	private static boolean isCommandeAMarquerPourGelNd(final CommandeDTO commande, final Map<OffreDTO, LigneCommandeDTO> offresLcCrmap, final String typeVente) {
		String traduction;
		FamilleOffreComDTO familleOffreCom;
		if (OffreEnum.RETAIL.name().equals(typeVente) || OffreEnum.ENTREPRISE.name().equals(typeVente)) {
			if (StatutCommandeConstantes.AGREGEE.equals(commande.getStatutCommande().getId())) {
				final String casMetierId = commande.getCasMetier() != null ? commande.getCasMetier().getId() : null;
				return !Arrays.asList(CasMetierConstantes.CR_FTTH, CasMetierConstantes.RECR_FTTH).contains(casMetierId);
			}
			for (OffreDTO offre : offresLcCrmap.keySet()) {
				familleOffreCom = serviceManager.getReferenceSpaceManager().findInReferenceSpace(FamilleOffreComDTO.class, offre.getFamilleOffreCom().getId());
				traduction = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.FAMILLE_OFFRE_RETAIL_NDGELE, familleOffreCom.getValeurConstante());
				if (Constantes.CST_OUI.equals(traduction)) {
					return true;
				}
			}
			return false;
		}

		LigneCommandeDTO lc;
		OffreDTO offre;
		if (OffreEnum.WHOLESALE.name().equals(typeVente)) {
			for (Entry<OffreDTO, LigneCommandeDTO> offreLcEntry : offresLcCrmap.entrySet()) {
				offre = offreLcEntry.getKey();
				lc = offreLcEntry.getValue();
				familleOffreCom = serviceManager.getReferenceSpaceManager().findInReferenceSpace(FamilleOffreComDTO.class, offre.getFamilleOffreCom().getId());
				traduction = serviceManager.getTraductionManager().getTraductionArtemisVersInterf(SystemeExterneConstantes.NUM_49W, ConstantesTraduction.FAMILLE_OFFRE_WS_NDGELE, familleOffreCom.getValeurConstante());
				if (Constantes.CST_OUI.equals(traduction) && TypeAccesLivraisonEnum.ND.name().equals(lc.getTypeAccesLivraison())) {
					return true;
				}
			}
			return false;
		}
		return false;
	}

	/**
	 * R�cup�re la map Offre -> LigneDeCommande de cr�ation
	 * 
	 * @param lcList La liste de lignes de commande
	 */
	private static Map<OffreDTO, LigneCommandeDTO> getOffresLcCrMap(final List<LigneCommandeDTO> lcList) {
		final Map<OffreDTO, LigneCommandeDTO> offresLcMap = new HashMap<OffreDTO, LigneCommandeDTO>();

		OffreDTO offre;
		for (LigneCommandeDTO lc : lcList) {
			offre = serviceManager.getOffreManager().getOffreForLigneCommandeCRNew(lc.getId(), true);
			if (offre != null) {
				offresLcMap.put(offre, lc);
			}
		}

		return offresLcMap;
	}

	/**
	 * Marque la commande et sauve les informations du nd abandonn� en base
	 * 
	 * @param cmd La commande � marquer
	 * @param abandon le type d'abandon
	 */
	private static void marqueCmdGelND(final CommandeDTO cmd, final String nd, final String typeVente, final String abandon) {

		final String methode = "marqueCmdGelND";

		final String typeAbandon;
		if (Arrays.asList(ConstantesTraduction.ABD_PROVISOIRE, ConstantesTraduction.ABD_PARTIEL).contains(abandon)) {
			typeAbandon = "Provisoire";
		} else {
			typeAbandon = "D�finitif";
		}

		serviceManager.getLoggerManager().qualif(CLASSNAME, 0, methode, cmd.getId(), String.format("Marquage de la commande \"%s\" pour gel ND : nd=%s, typeVente=%s, typeAbandon=%s", cmd.getId(), nd, typeVente, typeAbandon));

		final NdGelesDTO ndAGeler = new NdGelesDTO(nd, Calendar.getInstance().getTime());
		ndAGeler.setTypeAbandon(typeAbandon);
		ndAGeler.setTypeVente(typeVente);

		// Validation de l'objet. Arr�t si l'objet est invalide
		if (!ndAGeler.validate()) {
			serviceManager.getLoggerManager().severe(CLASSNAME, methode, String.format("Impossible d'archiver l'objet %s : %s", NdGelesDTO.class.getSimpleName(), ndAGeler.toString()));
			return;
		}

		// Marquage de la commande
		cmd.getDynamicCommandes().put(ConstantesDynamicCommande.CONSERVER_ND, Constantes.CST_OUI);
		serviceManager.getCommandeManager().updateDynamicCommande(cmd);

		// Archivage dans la table NdGelee c�t� routeur
		try {
			serviceManager.getArchivingManager().archiveToDatabase(ndAGeler);
		} catch (ArchivingException e) {
			serviceManager.getLoggerManager().severe(CLASSNAME, methode, String.format("Erreur lors de l'archivage du ND � geler pour la commande \"%s\"", cmd.getId()));
		}
	}

	/**
	 * Analyse du resultat de la lib�ration de l�intervention aupr�s de GPC
	 * 
	 * @param systemeExterneId le systeme externe demandant l'abandon de la commande
	 * @param sfAnoLibererPlage le sfAno remont� par la lib�ration de l�intervention aupr�s de GPC (SF_LibererPlage)
	 * @return le nouveau sfAno
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>06/06/2012</TD><TD>FTE</TD><TD>EV-000188: g�n�ration d'une anomalie lors de la lib�ration KO d'une commande de vente FTTH</TD></TR>
	 * <TR><TD>04/01/2013</TD><TD>GPA</TD><TD>EV-000210: Gestion de FRONTAL</TD></TR>
	 * </TABLE>
	 */
	private static SFAno analyserLiberationGraficFrontal(String systemeExterneId, SFAno sfAnoLibererPlage) {
		SFAno sfAno = null;

		String systemeExterneValeurConstante = null;
		if (systemeExterneId != null) {
			SystemeExterneDTO systemeExterne = serviceManager.getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, systemeExterneId);
			if (systemeExterne != null) {
				systemeExterneValeurConstante = systemeExterne.getValeurConstante();
			}

		}

		List<String> systems = Arrays.asList(SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE, SystemeExterneConstantes.FRONTAL_VALEUR_CONSTANTE);
		if (systems.contains(systemeExterneValeurConstante) && sfAnoLibererPlage != null && StringUtils.isNotEmpty(sfAnoLibererPlage.getInfo())) {
			// RG_ANO2 : La lib�ration de l�intervention aupr�s de GPC s�est mal d�roul�e et la poursuite de l�abandon est stopp�e
			// On �crase le sfAno
			sfAno = serviceManager.getAnomalieManager().newSFAno(TraitementConstantes.PREPABANDON, AnomalieConstantes.LIBINTERV_ANO, TypeAnomalieConstantes.DNR, sfAnoLibererPlage.getInfo());
		}

		return sfAno;
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>15/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * </TABLE>
	 * Abandonne l'AVP ou la t�che manuelle donn�(e).
	 * 
	 * @param tacheId l'identifiant de la t�che
	 * @param info le texte de l'�v�nement
	 * @param causeEvenementId la cause de l'�v�nement
	 * @param wfUser le WfUser permettant d'abandonner l'AVP
	 * @param abandon the abandon
	 * @param agent the agent
	 * 
	 * @throws AbandonnerProcessusException si l'AVP n'a pu �tre suspendu, ou s'il a pu l'�tre, mais avec
	 * un avertissement. L'exception contient le message � pr�senter
	 */
	public static void abandonnerAvp(String tacheId, String info, String causeEvenementId, WfUser wfUser, String abandon, AgentDTO agent) throws AbandonnerProcessusException {
		ProcessusDTO processus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		abandonnerProcessus(processus, info, causeEvenementId, wfUser, abandon, agent);
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>25/05/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion des actions de l'onglet commande</TD></TR>
	 * </TABLE>
	 * Abandonne le processus donn�.
	 * 
	 * @param processusId l'identifiant du processus
	 * @param info le texte de l'�v�nement
	 * @param causeEvenementId la cause de l'�v�nement
	 * @param wfUser le WfUser permettant de contacter le workflow
	 * @param abandon the abandon
	 * @param agent the agent
	 * 
	 * @throws AbandonnerProcessusException si le processus n'a pu �tre suspendu, ou s'il a pu l'�tre,
	 * mais avec un avertissement. L'exception contient le message �
	 * pr�senter
	 */
	public static void abandonnerProcessus(String processusId, String info, String causeEvenementId, WfUser wfUser, String abandon, AgentDTO agent) throws AbandonnerProcessusException {
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessusId(processusId);
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(processusId);
		List<TacheEnCoursDTO> tcList = new ArrayList<TacheEnCoursDTO>();
		// r�cup�ration des tec en base avant l'abandon de la commande qui va induire leur suppression. Permettra plus bas de faire la publication vers Pharaon.
		List<ProcessusDTO> processusFils = serviceManager.getProcessusManager().findProcessusFils(processusId);
		for (ProcessusDTO proc : processusFils) {
			tcList.addAll(serviceManager.getProcessusManager().findTacheEnCoursByProcessus(proc.getId()));
		}

		abandonnerProcessus(processus, info, causeEvenementId, wfUser, abandon, agent);
	}

	/**
	 * R�tablit l'AVP ou la t�che manuelle donn�(e).
	 * 
	 * @param tacheId l'identifiant de la t�che
	 * @param info le texte de l'�v�nement
	 * @param causeEvenementId la cause de l'�v�nement
	 * @param idCurrentAgent Identifiant de l'agent
	 * @param wfUser le WfUser permettant d'abandonner l'AVP
	 */
	public static void retablirAvp(String tacheId, String info, String causeEvenementId, String idCurrentAgent, WfUser wfUser) {
		ProcessusDTO processus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		retablirProcessus(processus, info, causeEvenementId, idCurrentAgent, wfUser);
	}

	/**
	 * R�tablit le processus donn�.
	 * 
	 * @param processusId l'identifiant du processus
	 * @param info le texte de l'�v�nement
	 * @param causeEvenementId la cause de l'�v�nement
	 * @param idCurrentAgent Identifiant de l'agent
	 * @param wfUser le WfUser permettant de contacter le workflow
	 */
	public static void retablirProcessus(String processusId, String info, String causeEvenementId, String idCurrentAgent, WfUser wfUser) {
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(processusId);
		retablirProcessus(processus, info, causeEvenementId, idCurrentAgent, wfUser);
	}

	/**
	 * R�assigne l'AVP ou la t�che manuelle donn�(e).
	 * 
	 * @param tacheId l'identifiant de la t�che
	 * @param info le texte de l'�v�nement
	 * @param causeEvenementId la cause de l'�v�nement
	 * @param idCurrentAgent Identifiant de l'agent
	 * @param wfUser le WfUser permettant d'abandonner l'AVP
	 * 
	 * @throws SuspendreProcessusException si l'AVP n'a pu �tre suspendu, ou s'il a pu l'�tre, mais avec
	 * un avertissement. L'exception contient le message � pr�senter
	 */
	public static void suspendreAvp(String tacheId, String info, String causeEvenementId, String idCurrentAgent, WfUser wfUser) throws SuspendreProcessusException {
		ProcessusDTO processus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		suspendreProcessus(processus, info, causeEvenementId, idCurrentAgent, wfUser);
	}

	/**
	 * Suspend le processus donn�.
	 * 
	 * @param processusId l'identifiant du processus
	 * @param info le texte de l'�v�nement
	 * @param causeEvenementId la cause de l'�v�nement
	 * @param idCurrentAgent Identifiant de l'agent
	 * @param wfUser le WfUser permettant de contacter le workflow
	 * 
	 * @throws SuspendreProcessusException si le processus n'a pu �tre suspendu, ou s'il a pu l'�tre,
	 * mais avec un avertissement. L'exception contient le message �
	 * pr�senter
	 */
	public static void suspendreProcessus(String processusId, String info, String causeEvenementId, String idCurrentAgent, WfUser wfUser) throws SuspendreProcessusException {
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(processusId);
		suspendreProcessus(processus, info, causeEvenementId, idCurrentAgent, wfUser);
	}

	/**
	 * Controle que l'abandon d'un AVP est possible.
	 * 
	 * @param tacheId l'identifiant de l'AVP
	 * @param abandon the abandon
	 * 
	 * @throws ControlerAbandonProcessusException si l'abandon ne peut �tre effectu� ou s'il peut l'�tre mais
	 * avec un avertissement, selong la valeur du champ warning de
	 * l'exception. L'exception contient l'avertissement ou l'erreur
	 * � afficher.
	 */
	public static void controlerAbandonAvp(String tacheId, String abandon) throws ControlerAbandonProcessusException {
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByTacheId(tacheId);
		ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		controlerAbandonProcessus(papaProcessus, abandon);
	}

	/**
	 * Controle que l'abandon d'un processus est possible.
	 * 
	 * @param processusId l'identifiant du processus
	 * @param abandon the abandon
	 * 
	 * @throws ControlerAbandonProcessusException si l'abandon ne peut �tre effectu� ou s'il peut l'�tre mais
	 * avec un avertissement, selong la valeur du champ warning de
	 * l'exception. L'exception contient l'avertissement ou l'erreur
	 * � afficher.
	 */
	public static void controlerAbandonProcessus(String processusId, String abandon) throws ControlerAbandonProcessusException {
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessusId(processusId);
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(processusId);
		controlerAbandonProcessus(processus, abandon);
	}

	/**
	 * V�rifie que l'AVP peut �tre diff�r� (son papaProcessus doit �tre en
	 * cours).
	 * 
	 * @param tacheId the tache id
	 * 
	 * @throws ControlerDiffererProcessusException the controler differer processus exception
	 */
	public static void controlerDiffererAvp(String tacheId) throws ControlerDiffererProcessusException {
		ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		controlerDiffererProcessus(papaProcessus);
	}

	/**
	 * V�rifie que l'AVP peut �tre abandonn� (son papaProcessus doit �tre en
	 * cours ou suspendu).
	 * 
	 * @param tacheId the tache id
	 * 
	 * @throws ControlerAbandonProcessusException the controler abandon processus exception
	 */
	public static void controlerEtatAbandonAvp(String tacheId) throws ControlerAbandonProcessusException {
		ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		controlerEtatAbandonProcessus(papaProcessus);
	}

	/**
	 * V�rifie que le processus peut �tre abandonn� (il doit �tre en cours ou
	 * suspendu).
	 * 
	 * @param processusId the processus id
	 * 
	 * @throws ControlerAbandonProcessusException the controler abandon processus exception
	 */
	public static void controlerEtatAbandonProcessus(String processusId) throws ControlerAbandonProcessusException {
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(processusId);
		controlerEtatAbandonProcessus(processus);
	}

	/**
	 * V�rifie que le processus peut-�tre r�tabli.
	 * 
	 * @param processusId the processus id
	 * 
	 * @throws ControlerRetablirProcessusException the controler retablir processus exception
	 */
	public static void controlerRetablirProcessus(String processusId) throws ControlerRetablirProcessusException {
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(processusId);
		controlerRetablirProcessus(processus);
	}

	/**
	 * V�rifie que l'avp peut �tre suspendu.
	 * 
	 * @param tacheId the tache id
	 * 
	 * @throws ControlerSuspensionProcessusException the controler suspension processus exception
	 */
	public static void controlerSuspensionAvp(String tacheId) throws ControlerSuspensionProcessusException {
		ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		controlerSuspensionProcessus(papaProcessus);
	}

	/**
	 * V�rifie que le processus peut-�tre suspendu.
	 * 
	 * @param processusId the processus id
	 * 
	 * @throws ControlerSuspensionProcessusException the controler suspension processus exception
	 */
	public static void controlerSuspensionProcessus(String processusId) throws ControlerSuspensionProcessusException {
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(processusId);
		controlerSuspensionProcessus(processus);
	}

	/**
	 * Retourne une liste d'AvpItemDTO, contenant, en plus des donn�es JDBC de
	 * la t�che, l'identifiant bolbec de la t�che et l'identifiant de son
	 * PapaProcessus.
	 * 
	 * @param items une collection d'instances de ItemData
	 * 
	 * @return une liste d'instances de AvpItemDTO
	 */
	public static List<AvpItemDTO> getAvpItems(List<ItemData> items) {
		List<AvpItemDTO> result = new ArrayList<AvpItemDTO>(items.size());
		for (ItemData itemData : items) {
			TacheDTO tache = serviceManager.getProcessusManager().getTache(itemData.getId());
			AvpItemDTO avpItem = getAvpItem(tache, itemData);
			result.add(avpItem);
		}
		return result;
	}

	/**
	 * Retourne une liste d'AvpItemDTO, contenant, en plus des donn�es workflow
	 * de la t�che, l'identifiant bolbec de la t�che et l'identifiant de son
	 * PapaProcessus.
	 * 
	 * @param items une collection d'instances de ItemData
	 * 
	 * @return une liste d'instances de AvpItemDTO
	 */
	public static List<AvpItemDTO> getAvpWorkflowItems(List<ItemData> items, WfUser wfUser) {
		List<AvpItemDTO> result = new ArrayList<AvpItemDTO>(items.size());
		for (ItemData itemData : items) {
			WfItemData wfTache;
			if (itemData instanceof WfTache) {
				wfTache = (WfTache) itemData;
			} else {
				wfTache = serviceManager.getWorkflowManager().enrichirWfData(itemData, wfUser);
			}
			WfActivity wfActivity = wfTache.getWfObject();
			TacheDTO tache = serviceManager.getTacheManager().getTache(wfActivity.getValue(Constantes.RS_IDEXTERNE), wfActivity.getValues());
			AvpItemDTO avpItem = getAvpItem(tache, wfTache);
			result.add(avpItem);
		}
		return result;
	}

	/**
	 * Retourne l'id de la t�che correspondant au WfActivity pass� en param�tre.
	 *
	 * @param wfActivity the wf activity
	 *
	 * @return String
	 */
	public static String getTacheId(WfActivity wfActivity) {
		String tacheId = wfActivity.getValue(Constantes.RS_ID_TACHE);
		if (StringUtils.isBlank(tacheId)) {
			TacheDTO tache = serviceManager.getTacheManager().getTache(wfActivity.getValue(Constantes.RS_IDEXTERNE), wfActivity.getValues());
			if (tache != null) {
				tacheId = tache.getId();
			}
		}
		return tacheId;
	}

	/**
	 * Lib�re une t�che dans le workflow.
	 * 
	 * @param wfActivity the wf activity
	 */
	public static void libererTache(WfActivity wfActivity) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "libererTache", "Liberation de l'activit� : " + wfActivity.getId());
		serviceManager.getWorkflowManager().liberer(wfActivity);
	}

	/**
	 * R�serve une t�che dans le workflow.
	 * 
	 * @param wfActivity de la tache
	 * 
	 * @throws ReserverProcessusException the reserver processus exception
	 */
	public static void reserverTache(WfActivity wfActivity, String agentFullName) throws ReserverProcessusException {
		try {
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "reserverTache", "Reservation de l'activit� : " + wfActivity.getId());
			serviceManager.getWorkflowManager().reserver(wfActivity, agentFullName);
		} catch (UnavailableTaskException e) {
			throw new ReserverProcessusException(e);
		}
	}

	/**
	 * Force la r�servation d'une t�che dans le workflow.
	 * 
	 * @param wfActivity de la tache
	 * 
	 * @throws ReserverProcessusException the reserver processus exception
	 */
	public static void forcerReservationTache(WfActivity wfActivity, String agentFullName) throws ReserverProcessusException {
		try {
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "forcerReservationTache", "Forcage de la reservation de l'activit� : " + wfActivity.getId());
			serviceManager.getWorkflowManager().forcerReservation(wfActivity, agentFullName);
		} catch (UnavailableTaskException e) {
			throw new ReserverProcessusException(e);
		}
	}

	/**
	 * Ajoute une note � l'AVP ou la t�che manuelle donn�e.
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>09/11/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV000183 - EB-0059 : Afficher le contenu de la derni�re note dans le d�tail de l�AVP</TD></TR>
	 * </TABLE>
	 * 
	 * @param tacheId l'identifiant de la t�che
	 * @param info le texte de la note
	 * @param wfActivity the wf activity
	 * @param wfUser the wf user
	 * 
	 */
	public static void addAvpNote(final String tacheId, final String info, final WfActivity wfActivity, final WfUser wfUser) {
		TacheDTO tache = serviceManager.getProcessusManager().getTache(tacheId);
		long dateCreation = DateUtils.getDatabaseDate();

		String infoTronquee = info;

		if ((info != null) && (info.length() > MAX_CHAR_INFO)) {
			serviceManager.getLoggerManager().warning(CLASSNAME, "traiter", String.format("On tronque � %d caract�res le message EVT.INFO : %s", MAX_CHAR_INFO, info));
			infoTronquee = info.substring(0, MAX_CHAR_INFO);
		}
		// cree l'evt en base
		final EvtDTO evt = createEvtNote(infoTronquee, wfUser, tache, dateCreation, wfActivity.getValues().get(Constantes.RS_IDCOMMANDE));

		// Publication Pharaon Cochise
		TacheEnCoursDTO tec = serviceManager.getProcessusManager().getTacheEnCours(tache.getId());
		Notification notification = serviceManager.getCochisePharaonManager().creerNotification(PublicationConstantes.PUB_COCHISE_PHARAON_EVT, tec, evt.getId(), CochisePharaonIndicateurActionEnum.SANS_INDICATEUR_ACTION, StringUtils.EMPTY,
				StringUtils.EMPTY);
		if (notification != null) {
			serviceManager.getCochisePharaonManager().publierMessage(notification);
		}
	}

	private static EvtDTO createEvtNote(String info, WfUser wfUser, TacheDTO tache, long dateCreation, String idCommande) {
		final String id = serviceManager.getGeneratorManager().generateKey();
		EvtDTO evtDTO = new EvtDTO(id);
		evtDTO.setCauseEvenement(new CauseEvenementDTO(VersionArtemisUtil.versionnerValeurConstante(CauseEvenementConstantes.SAISIENOTE_VALEUR_CONSTANTE, tache)));

		evtDTO.setDatabaseDateDateCreation(dateCreation);

		evtDTO.setInfo(info);
		evtDTO.setTache(new TacheDTO(tache.getId()));
		evtDTO.setAPourOrigineAgent(new AgentDTO(wfUser.getId()));
		serviceManager.getProcessusManager().createEvt(evtDTO);

		// US-678 Notification pour creation d'evenement
		String evtLibelle = StringUtils.removeStart(evtDTO.getCauseEvenement().getId(), serviceManager.getVersionManager().getCurrentVersion() + "_");
		NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_E, evtLibelle, evtDTO.getId(),idCommande);
		serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

		return evtDTO;
	}

	/**
	 * Permet de cr�er un �v�nement � partir de la cr�ation d'une note
	 * 
	 * @param idCommande l'id de la commande
	 * @param info les infos
	 * @param wfUser l'utilisateur
	 * @param dateCreation la date de cr�ation
	 * @return
	 */
	public static EvtDTO createEvtNoteSurCommande(String idCommande, String info, WfUser wfUser, long dateCreation) {

		// On a besoin de trouver la tache la plus r�cente afin de g�n�rer
		TacheEnCoursDTO tacheec = CollectionUtils.getFirstOrNull(serviceManager.getProcessusManager().findTacheEnCoursByCommande(idCommande));
		TacheDTO tache = null;
		if (tacheec == null) {
			List<ProcessusDTO> processuslst = serviceManager.getProcessusManager().findProcessusByCommande(idCommande);

			ProcessusDTO processusDto = ProcessusUtil.extraireProcessusLivraison(processuslst);
			if (processusDto != null) {
				tache = CollectionUtils.getFirstOrNull(serviceManager.getProcessusManager().findTacheByLanceParProcessus(processusDto.getId()));
			}
			// Si le processus de livraison ou une tache lanc�e par ce processus n'est pas trouv�, on recup�re le processus de compl�tude
			if (tache == null) {
				processusDto = ProcessusUtil.extraireProcessusCompletude(processuslst);
				tache = CollectionUtils.getFirstOrNull(serviceManager.getProcessusManager().findTacheByLanceParProcessus(processusDto.getId()));
			}
		} else {
			tache = serviceManager.getProcessusManager().getTache(tacheec.getId());
		}

		final String id = serviceManager.getGeneratorManager().generateKey();
		EvtDTO evtDTO = new EvtDTO(id);
		evtDTO.setCauseEvenement(new CauseEvenementDTO(VersionArtemisUtil.versionnerValeurConstante(CauseEvenementConstantes.SAISIENOTE_CMD_VALEUR_CONSTANTE, tache)));

		evtDTO.setDatabaseDateDateCreation(dateCreation);

		evtDTO.setInfo(info);
		evtDTO.setTache(new TacheDTO(tache.getId()));
		evtDTO.setAPourOrigineAgent(new AgentDTO(wfUser.getId()));
		serviceManager.getProcessusManager().createEvt(evtDTO);

		// US-678 Notification pour creation d'evenement
		String evtLibelle = StringUtils.removeStart(evtDTO.getCauseEvenement().getId(), serviceManager.getVersionManager().getCurrentVersion() + "_");
		NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_E, evtLibelle, evtDTO.getId(),idCommande);
		serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

		return evtDTO;
	}

	/**
	 * Cr�ation occurence tache et tacheEnCours.
	 * 
	 * @param wfActivities the wf activities
	 */
	public static void creerTacheEtTacheEnCours(List<WfActivity> wfActivities) {

		for (WfActivity wfActivity : wfActivities) {

			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "creerTacheEtTacheEnCours", "Traitement tache et tacheEnCours pour l'activit� : " + wfActivity.getId());

			// G�n�r�r un objet TacheIn
			Map<String, String> proprietesWorkflow = wfActivity.getValues();
			TacheIn tacheIn = serviceManager.getTacheManager().creeTacheIn(proprietesWorkflow);

			// Rechercher l'ensemble des TacheEnCours qui correspondent au libelleCourt et au Processus de la tache
			serviceManager.getProcessusManager().deleteTacheEnCoursByCommandeAndProcessusAndLibelleCourt(tacheIn.getIdCommande(), tacheIn.getProcessus(), tacheIn.getLibelleCourt());

			boolean tacheNotExist = true;
			TacheDTO tache = null;
			List<TacheDTO> tachesLanceParProcessus = serviceManager.getProcessusManager().findTacheByLanceParProcessus(tacheIn.getProcessus());

			if (tacheIn.getIdExterne() != null) {
				for (TacheDTO tacheLanceParProcessus : tachesLanceParProcessus) {
					if (tacheIn.getIdExterne().equals(tacheLanceParProcessus.getIdExterne())) {
						tache = tacheLanceParProcessus;
						break;
					}
				}
				if (tache != null) {
					// Si une tache existe
					// et que son idExterne est �gal � celui de la tacheIn (qui n'est pas nul)

					// Cas o� la tache existe d�j� en base et o� l'on re�oit un nouveau trigger
					// C'est le cas � chaque fois o� l'AVP est r�-ouvert dans la corbeille de t�ches
					// mettre � jour l'occurence de tache en appliquant la RG22
					ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "creerTacheEtTacheEnCours", "Tache existante trouv�e : " + tache.getId());
					miseAJourTacheDTO(tache, tacheIn);
					serviceManager.getProcessusManager().updateTache(tache);
					miseAJourTacheEnCours(tache.getId(), tacheIn);
					tacheNotExist = false;
				}
			}

			if (tacheNotExist) {
				boolean updateTache = false;

				for (TacheDTO tacheLanceParProcessus : tachesLanceParProcessus) {
					tache = tacheLanceParProcessus;
					if ((tacheIn.getDatePremiereMADispo().equals(tache.getDatabaseDateDatePremiereMADispo())) && ((tache.getIdExterne() == null) || (tache.getIdExterne().length() == 0))) {
						updateTache = true;
						break;
					}
				}
				if (updateTache && tache != null) {
					ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "creerTacheEtTacheEnCours", "Tache et updateTache pour la tache : " + tache.getId());
					// si il existe une tache avec tache.DatePremiereMADispo = tacheIn.DatePremiereMADispo
					// et tache.FK_LanceParProcessus = tacheIn.Processus et tache.IdExterne est null ou vide
					// (update tache et tacheEnCours)
					miseAJourTacheDTO(tache, tacheIn);
					serviceManager.getProcessusManager().updateTache(tache);
					miseAJourTacheEnCours(tache.getId(), tacheIn);
				} else {
					// (insert tache et tacheEnCours)
					String newTacheId = serviceManager.getGeneratorManager().generateKey();
					ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "creerTacheEtTacheEnCours", "Insert tache et tacheEnCours : " + newTacheId);

					TacheDTO newTache = new TacheDTO(newTacheId);
					miseAJourTacheDTO(newTache, tacheIn);
					serviceManager.getProcessusManager().createTache(newTache);
					miseAJourTacheEnCours(newTacheId, tacheIn);
					miseAJourProcessus(tacheIn);
				}
			}
		}
	}

	/**
	 * Cloture la t�che manuelle donn�(e).
	 * 
	 * @param commande les donn�es n�cessaires � la cloture
	 * @param wfUser the wf user
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * <TR><TD>19/09/2011</TD><TD>GPA</TD><TD>EV-000140: Publication vers l�application EFB</TD></TR>
	 * </TABLE>
	 */
	public static void cloturerTacheManuelle(CloturerTacheManuelleCommande commande, WfUser wfUser) {
		TacheDTO tache = serviceManager.getProcessusManager().getTache(commande.getTacheId());
		ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(commande.getTacheId());
		if (commande instanceof CloturerTacheManuelleDecrochageCommande) {
			cloturerTacheManuelleDecrochage((CloturerTacheManuelleDecrochageCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerTacheManuelleCompAdresseCommande) {
			cloturerTacheManuelleCompletudeAdresse((CloturerTacheManuelleCompAdresseCommande) commande, papaProcessus.getId());
		}
		WfTache wfTache = (WfTache) commande.getTache();

		// EV-000140: Publication vers l�application EFB
		serviceManager.getAvpManager().publierCrEfb(EfbNotificationFactory.GroupeCodeCR.GROUPE_CODE_300, tache.getId(), EfbNotificationFactory.Action.VALIDER_TACHE_MANUELLE, null);

		// publication Pharaon/Cochise
		TacheEnCoursDTO tec = serviceManager.getProcessusManager().getTacheEnCours(tache.getId());
		Notification notification = serviceManager.getCochisePharaonManager().creerNotification(PublicationConstantes.PUB_COCHISE_PHARAON_CLOTURE, tec, null, CochisePharaonIndicateurActionEnum.SUPPRESSION, "", "");
		if (notification != null) {
			serviceManager.getCochisePharaonManager().publierMessage(notification);
		}
		serviceManager.getTacheManager().cloturerTache(tache, wfTache.getValues(), false, false, false, wfUser);
		serviceManager.getWorkflowManager().cloturer(wfTache.getWfObject(), wfTache.getValues());
	}

	/**
	 * Permet de savoir si une commande est mixte.
	 * 
	 * @param tacheId the tache id
	 * 
	 * @return true si la commande est mixte
	 */
	public static boolean isCommandeMixte(String tacheId) {
		ProcessusDTO processus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessus(processus.getId());
		return StatutCommandeConstantes.MIXTE.equals(commande.getStatutCommande().getId());
	}

	/**
	 * Controle que l'abandon d'un processus est possible.
	 * 
	 * @param abandon the abandon
	 * @param papaProcessus the papa processus
	 * 
	 * @throws ControlerAbandonProcessusException si l'abandon ne peut �tre effectu� ou s'il peut l'�tre mais
	 * avec un avertissement, selong la valeur du champ warning de
	 * l'exception. L'exception contient l'avertissement ou l'erreur
	 * � afficher.
	 */
	private static void controlerAbandonProcessus(ProcessusDTO papaProcessus, String abandon) throws ControlerAbandonProcessusException {
		SFAno sfAno = null;

		Set<String> causeEvenementAutorisePourAbandonIds = null;
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessus(papaProcessus.getId());

		List<LigneCommandeDTO> listeLC = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
		LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(listeLC);
		SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
		CasMetierDTO cas = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CasMetierDTO.class, commande.getCasMetier().getId());

		if (commande != null) {
			if (ConstantesTraduction.ABD_MANUEL.equals(abandon)) {
				// Si parametre d'abandon = "ABD_MANUEL" alors faire appel au
				// TRT GEN Filtrage Des Causes Abandon en lui passant le
				// processus et l'identifiant du syst�meExterne fourni en
				// entr�e de ce traitement
				causeEvenementAutorisePourAbandonIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandon(papaProcessus.getId(), null, null);
				// Si aucune cause r�cup�r�e, faire appel au TRT GEN
				// FiltrageDesCausesAbandonMixte en lui passant le processus et
				// l'identifiant du syst�meExterne fourni en entr�e de ce
				// traitement et le param�tre "ABD_COMPLET"
				if (causeEvenementAutorisePourAbandonIds == null || causeEvenementAutorisePourAbandonIds.isEmpty()) {
					causeEvenementAutorisePourAbandonIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandonMixte(ConstantesTraduction.ABD_COMPLET, papaProcessus.getId(), null, null);
				}
			} else if (StatutCommandeConstantes.MIXTE.equals(commande.getStatutCommande().getId())) {
				// la commande est une commande mixte
				causeEvenementAutorisePourAbandonIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandonMixte(abandon, papaProcessus.getId(), null, null);
			} else {
				// la commande n'est pas une commande mixte
				causeEvenementAutorisePourAbandonIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandon(papaProcessus.getId(), null, null);
			}

			if ((premiereLC != null) && (premiereLC.getJalon() != null)) {
				if (JalonConstantes.J_MES.equals(premiereLC.getJalon().getId()) && se != null && SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(se.getValeurConstante()) && CasMetierConstantes.VENTE_FTTH.equals(cas.getId())) {
					causeEvenementAutorisePourAbandonIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandon(papaProcessus.getId(), SystemeExterneConstantes.GRAFIC, JalonConstantes.J_MES);
				}
			}
			if (causeEvenementAutorisePourAbandonIds == null || causeEvenementAutorisePourAbandonIds.isEmpty()) {
				String jalon = getJalon(papaProcessus.getId());
				String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.PREPABAN_000030, jalon, STRING_BLANK);
				String ano = VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.CAUSE_ABANDON_IMP_VALEUR_CONSTANTE, commande);
				sfAno = serviceManager.getAnomalieManager().newSFAno(TraitementConstantes.CONTROLEABANDON, ano, SFAno.TYPE_DNR, message);
			} else {
				sfAno = controlerLiberationInterventions(papaProcessus);
			}
		}

		if (sfAno != null) {
			Evenement evenement = serviceManager.getAnomalieManager().traiter(sfAno.getNomSF(), sfAno);
			boolean warning = SFAno.TYPE_AV.equals(sfAno.getType());
			throw new ControlerAbandonProcessusException(evenement.getLibelle(), warning);
		}
	}

	/**
	 * V�rifie que le processus peut �tre diff�r� (il doit �tre en cours).
	 * 
	 * @param papaProcessus the papa processus
	 * 
	 * @throws ControlerDiffererProcessusException the controler differer processus exception
	 */
	private static void controlerDiffererProcessus(ProcessusDTO papaProcessus) throws ControlerDiffererProcessusException {
		String etatProcessus = papaProcessus.getEtatProcessus().getId();
		if (EtatProcessusConstantes.EN_COURS.equals(etatProcessus)) {
			String etatPremiereLigneCde = null;
			LigneCommandeDTO ligneCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessusAndUneSeule(papaProcessus.getId());
			if (ligneCde != null) {
				etatPremiereLigneCde = ligneCde.getEtatLigneCde().getId();
			}
			if (EtatLigneCdeConstantes.ECREG.equals(etatPremiereLigneCde) || EtatLigneCdeConstantes.ECANN.equals(etatPremiereLigneCde) || EtatLigneCdeConstantes.TERM.equals(etatPremiereLigneCde)
					|| EtatLigneCdeConstantes.ANN.equals(etatPremiereLigneCde)) {
				throw new ControlerDiffererProcessusException(ERRMSG_KEY_CORBEILLE_ERROR_DIFFERER_ETAT_LIGNE_COMMANDE_INCOMPATIBLE);
			}
		} else {
			throw new ControlerDiffererProcessusException(ERRMSG_KEY_CORBEILLE_ERROR_DIFFERER_EN_MASSE_ETAT_PROCESSUS_INCOMPATIBLE);
		}
	}

	/**
	 * V�rifie que le processus peut �tre abandonn� (il doit �tre en cours).
	 * 
	 * @param papaProcessus the papa processus
	 * 
	 * @throws ControlerAbandonProcessusException the controler abandon processus exception
	 */
	private static void controlerEtatAbandonProcessus(ProcessusDTO papaProcessus) throws ControlerAbandonProcessusException {
		String etatProcessus = papaProcessus.getEtatProcessus().getId();
		if (!EtatProcessusConstantes.EN_COURS.equals(etatProcessus)) {
			throw new ControlerAbandonProcessusException(ERRMSG_KEY_CORBEILLE_ERROR_ABANDONNER_ETAT_PROCESSUS_INCOMPATIBLE, false);
		}
	}

	/**
	 * Renvoie une ControlerRetablirProcessusException si le processus ne peut
	 * �tre r�tabli.
	 * 
	 * @param papaProcessus the papa processus
	 * 
	 * @throws ControlerRetablirProcessusException the controler retablir processus exception
	 */
	private static void controlerRetablirProcessus(ProcessusDTO papaProcessus) throws ControlerRetablirProcessusException {
		if (!EtatProcessusConstantes.SUSP.equals(papaProcessus.getEtatProcessus().getId())) {
			throw new ControlerRetablirProcessusException(ERRMSG_KEY_CORBEILLE_ERROR_RETABLIR_ETAT_PROCESSUS_INCOMPATIBLE);
		}
	}

	/**
	 * Renvoie une ControlerSuspensionProcessusException si le processus ne peut
	 * �tre suspendu.
	 * 
	 * @param papaProcessus the papa processus
	 * 
	 * @throws ControlerSuspensionProcessusException the controler suspension processus exception
	 */
	private static void controlerSuspensionProcessus(ProcessusDTO papaProcessus) throws ControlerSuspensionProcessusException {
		if (EtatProcessusConstantes.EN_COURS.equals(papaProcessus.getEtatProcessus().getId())) {
			throw new ControlerSuspensionProcessusException(ERRMSG_CORBEILLE_ERROR_SUSPENDRE_VERSION_WORKFLOW);
		}
		throw new ControlerSuspensionProcessusException(ERRMSG_KEY_CORBEILLE_ERROR_SUSPENDRE_ETAT_PROCESSUS_INCOMPATIBLE);
	}

	/**
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>18/05/2011</TD><TD>BPE</TD><TD>Defect 202 : Ajout d'un contr�le sur la valeur de l'idEvt</TD></TR>
	 * </TABLE>
	 * 
	 * RG22 - Mise � jour des donn�es de la table tache.
	 * 
	 * @param tache the tache
	 * @param tacheIn the tache in
	 */
	private static void miseAJourTacheDTO(TacheDTO tache, TacheIn tacheIn) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "miseAJourTacheDTO", "Mise a jour de la TacheDTO : " + tache.getId());
		tache.setIdExterne(tacheIn.getIdExterne());
		tache.setDatabaseDateDatePremiereMADispo(tacheIn.getDatePremiereMADispo());
		tache.setEsd(tacheIn.getESD());
		tache.setDatabaseDateDateProgrammation(tacheIn.getDateProgrammation());
		tache.setLibelleCourt(tacheIn.getLibelleCourt());
		tache.setLibelle(tacheIn.getLibelle());
		tache.setLibelleIHM(tacheIn.getLibelleIHM());
		tache.setDatabaseDateDatePremiereExecution(tacheIn.getDatePremiereExecution());
		tache.setFaitParRole(new RoleDTO(tacheIn.getRole()));
		tache.setOfd(tacheIn.getOFD());
		tache.setNbRejeux(tacheIn.getNbRejeux());
		if (StringUtils.isNotBlank(tacheIn.getVersionArtemis())) {
			tache.setCatalogueTache(new CatalogueTacheDTO(tacheIn.getVersionArtemis() + "_" + tacheIn.getLibelleCourt()));
		}
		if (StringUtils.isNotBlank(tacheIn.getActivite())) {
			tache.setCatalogueActivite(new CatalogueActiviteDTO(tacheIn.getActivite()));
		}
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(tacheIn.getProcessus());
		tache.setLancerParProcessus(processus);
		String idEvt = tacheIn.getIdEvt();
		if (idEvt != null) {
			EvtDTO evt = serviceManager.getProcessusManager().getEvt(idEvt);
			if (evt != null) {
				tache.setEvt(evt);
			}
		}
	}

	/**
	 * RG21 - Mise � jour d'une tacheEnCours (la cr�e si elle n'existe pas).
	 * 
	 * @param tacheId the tache id
	 * @param tacheIn the tache in
	 */
	private static void miseAJourTacheEnCours(String tacheId, TacheIn tacheIn) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "miseAJourTacheEnCours", "Mise � jour de la tacheEnCours " + tacheId);
		TacheEnCoursDTO tacheEnCours = serviceManager.getProcessusManager().getTacheEnCours(tacheId);
		if (tacheEnCours != null) {
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "miseAJourTacheEnCours", "TacheEnCours trouv�e : " + tacheEnCours.getId());
			miseAJourDonneesSupervision(tacheEnCours, tacheIn);
			serviceManager.getProcessusManager().updateTacheEnCours(tacheEnCours);
		} else {
			ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "miseAJourTacheEnCours", "Impossible de r�cup�rer la tacheEnCours : " + tacheId);
			tacheEnCours = new TacheEnCoursDTO(tacheId);
			miseAJourDonneesSupervision(tacheEnCours, tacheIn);
			serviceManager.getProcessusManager().createTacheEnCours(tacheEnCours);
		}
	}

	/**
	 * RG21 - Mise � jour des donn�es de supervision
	 * (Donn�e regroupement / filtre / trie et court-circuit donn�es m�tiers).
	 * 
	 * @param tacheEnCours the tache en cours
	 * @param tacheIn the tache in
	 */
	private static void miseAJourDonneesSupervision(TacheEnCoursDTO tacheEnCours, TacheIn tacheIn) {
		ServiceManager.getInstance().getLoggerManager().fine(CLASSNAME, "miseAJourDonneesSupervision", "Mise � jour des donn�es de supervision pour la tacheEnCours : " + tacheEnCours.getId());
		tacheEnCours.setIdProcess(tacheIn.getProcessus());
		tacheEnCours.setAccesLivraison(tacheIn.getAccesLivraison());
		tacheEnCours.setLibelleCourt(tacheIn.getLibelleCourt());
		tacheEnCours.setLibelle(tacheIn.getLibelle());
		tacheEnCours.setDatePremiereMADispo(tacheIn.getDatePremiereMADispo());
		tacheEnCours.setIdEvt(tacheIn.getIdEvt());
		tacheEnCours.setLibCauseEvt(tacheIn.getLibCauseEvt());
		tacheEnCours.setLibCauseEvtInit(tacheIn.getLibCauseEvtInit());
		tacheEnCours.setEsd(tacheIn.getESD());
		tacheEnCours.setZoneGeo(tacheIn.getZoneGeo());
		tacheEnCours.setZoneGeoLib(tacheIn.getZoneGeoLib());
		tacheEnCours.setZoneSi(tacheIn.getZoneSI());
		tacheEnCours.setZoneSiLib(tacheIn.getZoneSILib());
		tacheEnCours.setIdCommande(tacheIn.getIdCommande());
		tacheEnCours.setAgent(tacheIn.getAgent());
		tacheEnCours.setRole(tacheIn.getRole());
		tacheEnCours.setOfd(tacheIn.getOFD());
		tacheEnCours.setDateProgrammation(tacheIn.getDateProgrammation());
		tacheEnCours.setCatCliCont(tacheIn.getCatCliCont());
		tacheEnCours.setCatCliLiv(tacheIn.getCatCliLiv());
		tacheEnCours.setDateContractuelle(tacheIn.getDateContractuelle());
		tacheEnCours.setInfoLc(tacheIn.getInfoLC());
		tacheEnCours.setFamilleOffre(tacheIn.getFamilleOffre());
		tacheEnCours.setJalon(tacheIn.getJalon());
		tacheEnCours.setRepartiteur(tacheIn.getRepartiteur());
		tacheEnCours.setDslam(tacheIn.getDSLAM());
		tacheEnCours.setAncDslam(tacheIn.getAncDSLAM());
	}

	/**
	 * Mise � jour des donn�es de la table processus.
	 * 
	 * @param tacheIn the tache in
	 */
	private static void miseAJourProcessus(TacheIn tacheIn) {
		ProcessusDTO processus = serviceManager.getProcessusManager().getProcessus(tacheIn.getProcessus());
		if (((processus.getBpiid() != null) && (processus.getBpiid().length() > 0)) || ((processus.getBpName() != null) && (processus.getBpName().length() > 0))) {
			processus.setBpiid(tacheIn.getBpiid());
			processus.setBpName(tacheIn.getBpname());
			serviceManager.getProcessusManager().updateProcessusBp(processus);
		}
	}

	/**
	 * Abandonner processus.
	 * 
	 * @param processus the processus
	 * @param info the info
	 * @param causeEvenementId the cause evenement id
	 * @param wfUser the wf user
	 * @param abandon the abandon
	 * @param agent the agent
	 * 
	 * @throws AbandonnerProcessusException the abandonner processus exception
	 */
	private static void abandonnerProcessus(ProcessusDTO processus, String info, String causeEvenementId, WfUser wfUser, String abandon, AgentDTO agent) throws AbandonnerProcessusException {
		serviceManager.getLoggerManager().finest(CLASSNAME, "abandonnerProcessus", "Type abandon = " + abandon);
		Evenement evenement = createEvenement(causeEvenementId, info, null, agent.getId(), abandon);
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessus(processus.getId());
		TacheEnCoursDTO tec = CollectionUtils.getFirstOrNull(serviceManager.getProcessusManager().findTacheEnCoursByCommande(commande.getId()));

		SystemeExterneDTO se = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(SystemeExterneDTO.class, commande.getSystemeExterne().getId());
		List<LigneCommandeDTO> listeLC = serviceManager.getCommandeManager().findLigneCommandeByCommande(commande.getId());
		LigneCommandeDTO premiereLC = CollectionUtils.getFirstOrNull(listeLC);
		CasMetierDTO cas = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CasMetierDTO.class, commande.getCasMetier().getId());

		SFAno ano = null;
		if ((premiereLC != null) && (premiereLC.getJalon() != null)) {
			if (JalonConstantes.J_MES.equals(premiereLC.getJalon().getId()) && se != null && SystemeExterneConstantes.GRAFIC_VALEUR_CONSTANTE.equals(se.getValeurConstante()) && CasMetierConstantes.VENTE_FTTH.equals(cas.getId())) {
				ano = preparerAbandon(processus, evenement, false, SystemeExterneConstantes.GRAFIC, wfUser, abandon, tec);

			} else {
				ano = preparerAbandon(processus, evenement, false, null, wfUser, abandon, tec);
			}
		}

		if (ano != null) {
			// EV-469 is Anomalie.LIBINTERV_ANO, exception "Lib�ration de l'intevention refus�e par GPC"
			if (AnomalieConstantes.LIBINTERV_ANO.equalsIgnoreCase(ano.getErreur())) {
				throw APIExceptionEnum.serviceorderabandonrefusegpc.createAPIException();
			}
			Evenement e = serviceManager.getAnomalieManager().traiter(TraitementConstantes.SUSPENSION, ano);
			throw new AbandonnerProcessusException(e.getLibelle(), false);
		}
	}

	/**
	 * Adds the dynamic instance rt.
	 * 
	 * @param instanceRT the instance rt
	 * @param qts the qts
	 */
	private static void addDynamicInstanceRT(InstanceRtDTO instanceRT, List<KeyPair> qts) {
		for (KeyPair keyPair : qts) {
			serviceManager.getRessourceTechniqueManager().updateDynamicInstanceRts(instanceRT);
		}
	}

	/**
	 * Cloturer tache manuelle completude adresse.
	 * 
	 * @param commande the commande
	 * @param processusId the processus id
	 */
	private static void cloturerTacheManuelleCompletudeAdresse(CloturerTacheManuelleCompAdresseCommande commande, String processusId) {
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		for (LigneCommandeDTO lc : lignesCde) {
			ClientDTO clientLivre = lc.getClient();
			AdresseDTO adresse = clientLivre.getAdresse();
			if (adresse != null) {
				adresse.setLibelleVoie(commande.getLibelleVoie());
				adresse.setCodeRivoli(commande.getCodeRivoli());
				adresse.setNumeroVoie(commande.getNumeroVoie());
				adresse.setEnsemble(commande.getEnsemble());
				adresse.setBatiment(commande.getBatiment());
				adresse.setEscalier(commande.getEscalier());
				adresse.setEtage(commande.getEtage());
				adresse.setPorte(commande.getPorte());
				adresse.setLogo(commande.getLogo());
				adresse.setCodeInsee(commande.getCodeInsee());
				serviceManager.getCommandeManager().updateAdresse(adresse);
			} else {
				AdresseDTO nouvAdresse = new AdresseDTO(serviceManager.getGeneratorManager().generateKey());
				nouvAdresse.setLibelleVoie(commande.getLibelleVoie());
				nouvAdresse.setCodeRivoli(commande.getCodeRivoli());
				nouvAdresse.setNumeroVoie(commande.getNumeroVoie());
				nouvAdresse.setEnsemble(commande.getEnsemble());
				nouvAdresse.setBatiment(commande.getBatiment());
				nouvAdresse.setEscalier(commande.getEscalier());
				nouvAdresse.setEtage(commande.getEtage());
				nouvAdresse.setPorte(commande.getPorte());
				nouvAdresse.setLogo(commande.getLogo());
				nouvAdresse.setCodeInsee(commande.getCodeInsee());
				serviceManager.getCommandeManager().createAdresse(nouvAdresse);
				clientLivre.setAdresse(nouvAdresse);
				serviceManager.getCommandeManager().updateClient(clientLivre);
			}
			if ((commande.getNdplp() != null) && (commande.getNdplp().length() > 0)) {
				lc.setTypeAccesLivraisonOrigine(TypeAccesLivraisonEnum.NDPLP.name());
				lc.setAccesLivraisonOrigine(commande.getNdplp());
			}
		}
	}

	/**
	 * Cloturer tache manuelle decrochage.
	 * 
	 * @param commande the commande
	 * @param processusId the processus id
	 */
	private static void cloturerTacheManuelleDecrochage(CloturerTacheManuelleDecrochageCommande commande, String processusId) {
		Map<String, List<KeyPair>> qtsByInstanceRT = commande.getQtsByInstanceRT();
		List<InstanceRtDTO> instancesRT = serviceManager.getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processusId);
		for (InstanceRtDTO instanceRT : instancesRT) {
			if (qtsByInstanceRT.containsKey(instanceRT.getId())) {
				List<KeyPair> qts = qtsByInstanceRT.get(instanceRT.getId());
				addDynamicInstanceRT(instanceRT, qts);
			}
		}
	}

	/**
	 * Creer tache.
	 * 
	 * @param wfActivity the wf activity
	 * 
	 * @return the tache dto
	 */
	private static TacheDTO creerTache(WfActivity wfActivity) {
		try {
			Map<String, String> proprietesWorkflow = wfActivity.getValues();
			Map<String, List<String>> staticAttributes = wfActivity.getStaticAttributes();

			String roleId = proprietesWorkflow.get(WorkflowConstantes.ROLE);
			String processusId = proprietesWorkflow.get(Constantes.RS_IDEXTERNE);
			String evtId = proprietesWorkflow.get(WorkflowConstantes.ID_EVT);
			long dateFAD;
			try {
				dateFAD = Long.parseLong(proprietesWorkflow.get(WorkflowConstantes.DATE_PREMIERE_MISE_A_DISPO));
			} catch (Exception e) {
				// Si c'est pas ou mal d�fini dans les proprietesWorkflow, on met 0.
				dateFAD = 0;
			}

			TacheDTO tache = new TacheDTO(serviceManager.getGeneratorManager().generateKey());
			tache.setIdExterne(proprietesWorkflow.get(WorkflowConstantes.IDENTIFIER));
			tache.setLibelle(proprietesWorkflow.get(WorkflowConstantes.LIBELLE));
			tache.setLibelleCourt(proprietesWorkflow.get(WorkflowConstantes.LIBELLE_COURT));
			tache.setDatabaseDateDatePremiereMADispo(Long.valueOf(dateFAD));
			if (roleId != null) {
				tache.setFaitParRole(new RoleDTO(roleId));
			}
			if (processusId != null) {
				tache.setLancerParProcessus(new ProcessusDTO(processusId));
			}
			if (evtId != null) {
				tache.setEvt(new EvtDTO(evtId));
			}
			serviceManager.getProcessusManager().createTache(tache);

			// 3. Progression du jalon d�avancement du processus
			List<String> jalonList = staticAttributes.get(WorkflowConstantes.JALON);
			String jTacheId = null;
			if (jalonList != null) {
				jTacheId = CollectionUtils.getFirstOrNull(jalonList);
			}
			if ((jTacheId != null) && (jTacheId.length() > 0)) {
				// acceder a la premiere des lignes de commande
				List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
				LigneCommandeDTO firstligneCde = lignesCde.iterator().next();
				// rechercher les objets de la table jalon
				JalonDTO jLigne = serviceManager.getReferenceSpaceManager().findInReferenceSpace(JalonDTO.class, firstligneCde.getJalon().getId());
				JalonDTO jTache = serviceManager.getReferenceSpaceManager().findInReferenceSpace(JalonDTO.class, jTacheId);
				// recuperer le rang des jalons
				int jLigneRang = 0;
				int jTacheRang = 0;
				if (jLigne != null) {
					jLigneRang = jLigne.getRang();
				}
				if (jTache != null) {
					jTacheRang = jTache.getRang();
				}
				// comparer les rangs des jalons
				if (jTacheRang > jLigneRang) {
					// Reporter la valeur de JT�che dans tous les LigneCommande
					serviceManager.getCommandeManager().updateLigneCommandeJalon(lignesCde, jTacheId);
					// Reporter la valeur de JT�che dans le champ "JalonActuel" du rootset du processus.
					proprietesWorkflow.put(Constantes.RS_JALON_ACTUEL, jTacheId);
				}
			}
			return tache;
		} catch (WfException ce) {
			throw new EJBException(ce);
		}
	}

	/**
	 * Construit un AvpItemDTO � partir de la t�che et de ses donn�es m�tiers.
	 * 
	 * @param tache t�che
	 * @param itemData donn�es m�tier
	 * 
	 * @return un AvpItemDTO
	 */
	private static AvpItemDTO getAvpItem(TacheDTO tache, ItemData itemData) {
		ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tache.getId());
		int itemType = AvpItemDTO.PHASE_TYPE;

		/*
		 * tache.FK_estTypeCatalogueTache n'est pas vide
		 * partie � conserver
		 */
		if (tache.getCatalogueTache() != null && StringUtils.isNotBlank(tache.getCatalogueTache().getId())) {
			CatalogueTacheDTO catalogueTache = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tache.getCatalogueTache().getId());
			if (STRING_AVP.equals(catalogueTache.getType())) {
				itemType = AvpItemDTO.AVP_TYPE;
			} else if (STRING_TACHE_MANUELLE.equals(catalogueTache.getType())) {
				if (STRING_COMPLETER_CR.equals(catalogueTache.getValeurConstante())) {
					itemType = AvpItemDTO.REGULARISATION_MANUELLE_TYPE;
				} else if (STRING_COMPLETER_CRABAN.equals(catalogueTache.getValeurConstante())) {
					itemType = AvpItemDTO.ABANDON_MANUEL_TYPE;
				} else {
					itemType = AvpItemDTO.TACHE_MANUELLE_TYPE;
				}
			} else {
				itemType = AvpItemDTO.TACHE_ADHOC_TYPE;
			}
		}
		/*
		 * Partie � supprimer d�s lors o� toutes les taches seront aliment�es correctement
		 * c'est-�-dire quand tache.FK_estTypeCatalogueTache ne sera pas vide
		 */
		else {
			itemType = TacheManuelleLibelleUtil.getItemType(tache);
		}

		return new AvpItemDTO(tache.getId(), papaProcessus.getId(), itemData, itemType);
	}

	/**
	 * Retablir processus.
	 * 
	 * @param processus the processus
	 * @param info the info
	 * @param causeEvenementId the cause evenement id
	 * @param idCurrentAgent the id current agent
	 * @param wfUser the wf user
	 */
	private static void retablirProcessus(ProcessusDTO processus, String info, String causeEvenementId, String idCurrentAgent, WfUser wfUser) {
		WorkflowManager wfManager = serviceManager.getWorkflowManager();

		Evenement evenement = createEvenement(causeEvenementId, info, null, idCurrentAgent, null);
		createEvtPourProcessus(evenement, processus.getId(), processus.getIdCommande());
		wfManager.retablir(wfUser, processus.getId());
		processus.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.EN_COURS));
		serviceManager.getProcessusManager().updateProcessusEtat(processus);
		// Supprimer les instances de ProcessusSuspendus dont ProcessusSuspendus.IDPere = identifiant du processus fourni en entr�e
		serviceManager.getProcessusManager().deleteProcessusSuspendusByIdPere(processus.getId());
	}

	/**
	 * Ex�cute le traitement "Suspension".
	 * 
	 * @param processus le papaProcessus � suspendre
	 * @param causeEvenementId l'�v�nement n�cessaire � la suspension
	 * @param idCurrentAgent the id current agent
	 * @param wfUser le WfUser n�cessaire � l'invocation du workflow
	 * @param info the info
	 * 
	 * @throws SuspendreProcessusException the suspendre processus exception
	 */
	private static void suspendreProcessus(ProcessusDTO processus, String info, String causeEvenementId, String idCurrentAgent, WfUser wfUser) throws SuspendreProcessusException {
		Evenement evenement = createEvenement(causeEvenementId, info, null, idCurrentAgent, null);
		Set<String> causeEvenementAutorisePourAbandonIds = CauseEvenementUtil.getCauseEvenementAutoriseesIdPourAbandon(processus.getId(), null, null);
		if (causeEvenementAutorisePourAbandonIds.isEmpty()) {
			String jalon = getJalon(processus.getId());
			String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.SUSPENSION__000010, jalon);
			String ano = VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.CAUSE_SUSPENS_IMP_VALEUR_CONSTANTE, processus);
			SFAno sfAno = serviceManager.getAnomalieManager().newSFAno(TraitementConstantes.SUSPENSION, ano, SFAno.TYPE_DNR, message);
			Evenement e = serviceManager.getAnomalieManager().traiter(TraitementConstantes.SUSPENSION, sfAno);
			boolean warning = SFAno.TYPE_AV.equals(sfAno.getType());
			throw new SuspendreProcessusException(e.getLibelle(), warning);
		}

		createEvtPourProcessus(evenement, processus.getId(), processus.getIdCommande());

		// Transmission au workflow
		serviceManager.getWorkflowManager().suspendre(wfUser, processus.getId());

		// Mise � jour de l'�tat du processus
		processus.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.SUSP));
		serviceManager.getProcessusManager().updateProcessusEtat(processus);

		// Suspension du papa Processus (RG1 : Cr�ation des processus supendus (p�re et fils))
		// - Cr�ation du processus suspendus p�re
		ProcessusSuspendusDTO processusSuspendusPere = new ProcessusSuspendusDTO(serviceManager.getGeneratorManager().generateKey());
		processusSuspendusPere.setIdPere(processus.getId());
		processusSuspendusPere.setIdFils(processus.getId());
		serviceManager.getProcessusManager().createProcessusSuspendus(processusSuspendusPere);
		// - Cr�ation des processus suspendus fils
		List<ProcessusDTO> collectionProcessusFils = serviceManager.getProcessusManager().findProcessusFils(processus.getId());
		for (ProcessusDTO processusFils : collectionProcessusFils) {
			ProcessusSuspendusDTO processusSuspendusFils = new ProcessusSuspendusDTO(serviceManager.getGeneratorManager().generateKey());
			processusSuspendusFils.setIdPere(processus.getId());
			processusSuspendusFils.setIdFils(processusFils.getId());
			serviceManager.getProcessusManager().createProcessusSuspendus(processusSuspendusFils);
		}
	}

	/**
	 * Liberer intervention.
	 * 
	 * @param intervention the intervention
	 * @param papaProcessusId the papa processus id
	 * @param critereLocalisation the critere localisation
	 * @param ndLocalisation the nd localisation
	 * @param versionArtemis the version bolbec
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>20/02/2013</TD><TD>GPA</TD><TD>DE-000760(interne): Ajout du SFAno en retour de la m�thode</TD></TR>
	 * <TR><TD>27/03/2013</TD><TD>VDE</TD><TD>DE-000316 : Frontal : Abandon avec erreur GPC lors de la lib�ration de l'intervention, ajout de verification du champ FTTH_Entreprise � la valeur "Oui"</TD></TR>
	 * <TR><TD>28/03/2013</TD><TD>VDE</TD><TD>DE-000316 : Frontal : Abandon avec erreur GPC lors de la lib�ration de l'intervention</TD></TR>
	 * </TABLE>
	 */
	private static SFAno libererIntervention(InterventionDTO intervention, String papaProcessusId, String critereLocalisation, String ndLocalisation, String versionArtemis, String responsabiliteId) {
		String method = "libererIntervention";
		String reference = intervention.getReference();
		String refExterne = intervention.getRefExterne();
		Map<String, String> dynamicsintervention = intervention.getDynamicInterventions();
		String activ = dynamicsintervention.get(ConstantesDynamicIntervention.INTERVENTION_ACTIV);
		String prod = dynamicsintervention.get(ConstantesDynamicIntervention.INTERVENTION_PROD);
		String baseGpc = dynamicsintervention.get(ConstantesDynamicIntervention.INTERVENTION_BASEGPC);
		String refKyaku = dynamicsintervention.get(ConstantesDynamicIntervention.INTERVENTION_REFKYAKU);
		boolean isPerimKyaku = ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU_OUI.equals(dynamicsintervention.get(ConstantesDynamicIntervention.INTERVENTION_PERIM_KYAKU));
		CritereIntervention critInterv = new CritereIntervention(activ, prod);
		critInterv.setBaseGpc(baseGpc);

		// r�cup�ration de la commande trait�e
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessus(papaProcessusId);
		Map<String, String> dynamicscommande = commande.getDynamicCommandes();
		CommandeTraitee commandeTraitee = new CommandeTraitee(commande.getId(), commande.getDatabaseDateDateValidationFo().toString(), commande.getVersionArtemis(), commande.getRefExterne());

		IOLibererPlage ioLibererPlage = new IOLibererPlage(critereLocalisation, ndLocalisation, critInterv, reference, refExterne, commandeTraitee, responsabiliteId, refKyaku, isPerimKyaku);
		ioLibererPlage.setVersionArtemis(versionArtemis);

		// appel au SF
		SFAno anoLibererPlage = null;
		try {
			LibererPlage.executer(ioLibererPlage);
		} catch (AnomalieException exc) {
			serviceManager.getLoggerManager().warning(CLASSNAME, method, "Attention l'intervention r�f�rence : " + reference + " n'a pas �t� lib�r�e.");
			if ((!StringUtils.equals(exc.getSfAno().getType(), Constantes.CST_OK)) && (StringUtils.equals(commande.getCasMetier().getId(), CasMetierConstantes.VENTE_FTTH)
					|| (dynamicscommande.containsKey(ConstantesDynamicCommande.CLE_FTTH_ENTREPRISE) && StringUtils.equalsIgnoreCase(Constantes.VALEUR_VARIANTE_OUI, dynamicscommande.get(ConstantesDynamicCommande.CLE_FTTH_ENTREPRISE))))) {
				return exc.getSfAno();
			}
		}

		// MAJ de l'intervention en BDD
		intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.ANN));
		serviceManager.getCommandeManager().updateInterventionEtat(intervention);

		NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_I, NotificationGeneriqueConstantes.LIBERERINTERV, intervention.getId(),commande.getId());
		serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

		return anoLibererPlage;
	}

	/**
	 * Abandon workflow.
	 * 
	 * @param wfUser the wf user
	 * @param papaProcessus the papa processus
	 * @param reprise the reprise
	 * @param evenement the evenement
	 * 
	 * @throws CreateException the create exception
	 */
	private static void abandonWorkflow(WfUser wfUser, ProcessusDTO papaProcessus, boolean reprise, Evenement evenement, String abandon) throws CreateException {
		String methodName = "abandonWorkflow";

		WorkflowManager wfManager = serviceManager.getWorkflowManager();

		Map<String, String> donneesWf = new HashMap<String, String>();
		donneesWf.put(Constantes.RS_VAR_ABANDON, Constantes.VALEUR_VARIANTE_OUI);
		if (reprise) {
			donneesWf.put(Constantes.RS_VAR_REPRISE, Constantes.VALEUR_VARIANTE_OUI);
		}

		// R�cup�ration du type de processus
		String idProcessusType = papaProcessus.getProcessusType().getId();
		ProcessusTypeDTO processusType = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, idProcessusType);
		String processusTypeValConst = processusType.getValeurConstante();

		List<ProcessusDTO> sousProcessusLst = serviceManager.getProcessusManager().findProcessusFils(papaProcessus.getId());
		String sTypologieAbandon = null;
		String sProcessusOrigineAbandon = null;
		if (sousProcessusLst.isEmpty() && ProcessusTypeConstantes.COMPLETUDE_VALEUR_CONSTANTE.equals(processusTypeValConst)) {
			// Cas particulier de la compl�tude
			CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessus(papaProcessus.getId());

			String abanComplId = VersionArtemisUtil.versionnerValeurConstante(ProcessusTypeConstantes.ABANCOMPL_VALEUR_CONSTANTE, papaProcessus);
			ProcessusDTO processusCree = createProcessus(abanComplId, papaProcessus);
			relierProcessusALignesCommandes(papaProcessus.getId(), processusCree);
			donneesWf.put(Constantes.RS_IDEXTERNE, processusCree.getId());
			donneesWf.put(Constantes.RS_IDEVT, evenement.getId());
			addIdempotence(donneesWf, papaProcessus.getId());

			// On r�cup�re la valeur constante pour la t�che ABANCOMPL
			ProcessusTypeDTO abanCompl = serviceManager.getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, abanComplId);
			String abanComplValeurConstante = abanCompl.getValeurConstante();

			// Pr�paration de l'abandon du processus workflow
			sTypologieAbandon = determinerTypologieAbandon(abanComplValeurConstante, donneesWf, true);
			sProcessusOrigineAbandon = Constantes.ORIGINE_ABANDON_COMPLETUDE;

			processusCree.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.EN_COURS));
			serviceManager.getProcessusManager().updateProcessusEtat(processusCree);

			// cl�ture de toutes les t�ches manuelles et les AVP du processus de COMPLETUDE
			cloturerTacheManuelleEtAvp(papaProcessus, wfUser);

			// Cas particulier : Suppression du marquage "en cours de traitement sur la commande"
			CommandeHelper cmdHelper = new CommandeHelper(commande);
			cmdHelper.supprimerMarquageCdeTraitementTache();

		} else {
			// on est dans le cas d'une livraison , ou en tout cas, dehors la compl�tude.
			// si le processus p�re est suspendu
			if (papaProcessus.getEtatProcessus() != null && EtatProcessusConstantes.SUSP.equals(papaProcessus.getEtatProcessus().getId())) {
				wfManager.retablir(wfUser, papaProcessus.getId());
			}

			// Pr�paration de l'abandon du processus workflow
			sTypologieAbandon = determinerTypologieAbandon(abandon, donneesWf, false);
			sProcessusOrigineAbandon = Constantes.ORIGINE_ABANDON_LIVRAISON;
		}

		// mise � jour de l'�tat du processus
		papaProcessus.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.ANNUL));
		serviceManager.getProcessusManager().updateProcessusEtat(papaProcessus);
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByProcessus(papaProcessus.getId());
		for (LigneCommandeDTO lc : lignesCde) {
			lc.setEtatLigneCde(new EtatLigneCdeDTO(EtatLigneCdeConstantes.ECANN));
			serviceManager.getCommandeManager().updateLigneCommandeEtat(lc);
		}

		// Abandonner le processus workflow
		ServiceManager.getInstance().getLoggerManager().finer(CLASSNAME, methodName, "Appel au service workflow de r�gularisation du processus (WfUser.doAbandon)");
		wfManager.abandonner(donneesWf, wfUser, papaProcessus.getId(), sTypologieAbandon, sProcessusOrigineAbandon);
	}

	/**
	 * Determine la typologie d'abandon � effectuer en fonction des crit�res
	 * 
	 * @param valeurAbandon type d'abandon initialement pr�vue
	 * @param donneesWf donnees worklow, avec le typeEvt
	 * @param bIsCompletude true si la commande est encore en compl�tude
	 * @return la typologie d'abandon � r�aliser
	 */
	private static String determinerTypologieAbandon(String valeurAbandon, Map<String, String> donneesWf, boolean bIsCompletude) {
		if (bIsCompletude) {
			return Constantes.TYPE_ABANDON_STD;
		} else {
			return Constantes.TYPE_ABANDON_ANNUL_RESIL;
		}
	}

	/**
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>20/08/2013</TD><TD>EBA</TD><TD>G8R2C3 DE-000915 : T�che auto rejou�e pour commande en AVP durant la phase de Compl�tude, lors d'une demande d'abandon</TD></TR>
	 * <TR><TD>06/02/2014</TD><TD>FTE</TD><TD>Retour arri�re sur la correction du 20/08/2013</TD></TR>
	 * </TABLE>
	 * 
	 */
	private static void cloturerTacheManuelleEtAvp(ProcessusDTO papaProcessus, WfUser wfUser) {
		// Rechercher pour le processus, ses taches manuelles et AVP non termin�s
		List<TacheDTO> tachesDuProcessus = serviceManager.getProcessusManager().findTacheByLanceParProcessus(papaProcessus.getId());
		for (TacheDTO tache : tachesDuProcessus) {
			if (tache != null) {
				// R�cup�ration du type de la t�che
				CatalogueTacheDTO catalogueTache = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tache.getCatalogueTache().getId());
				String type = catalogueTache.getType();
				if (TACHE_AVP.equals(type) || TACHE_MANUELLE.equals(type)) {
					// Le processus contient au moins une t�che manuelle ou un AVP
					try {
						// Faire un Done de la tache workflow
						wfUser.doDoneActivityWfwByProcessId(papaProcessus.getId());
						break;
					} catch (WfException e) {
						throw new EJBException(e);
					}
				}
			}
		}
	}

	/**
	 * Controler liberation interventions.
	 * 
	 * @param papaProcessus the papa processus
	 * 
	 * @return the sF ano
	 */
	private static SFAno controlerLiberationInterventions(ProcessusDTO papaProcessus) {
		List<InterventionDTO> interventions = serviceManager.getCommandeManager().findInterventionByProcessus(papaProcessus.getId());
		if (interventions.isEmpty()) {
			return null;
		}
		for (InterventionDTO intervention : interventions) {
			String etatInterventionId = intervention.getEtatIntervention().getId();
			NatureIntervention nature = serviceManager.getRendezVousManager().getNatureIntervention(intervention);
			boolean isClient = NatureIntervention.INTERVENTION_CLIENT.equals(nature);
			if (isClient && EtatInterventionConstantes.TERM.equals(etatInterventionId)) {
				String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.CTRL_LIBINTERV_000010);
				return serviceManager.getAnomalieManager().newSFAno(TraitementConstantes.CONTROLELIBERATIONINTERV, VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.ABANDON_KO_VALEUR_CONSTANTE, papaProcessus), TypeAnomalieConstantes.DNR,
						message);
			} else if (isClient && (EtatInterventionConstantes.RESERV.equals(etatInterventionId) || EtatInterventionConstantes.ENVOI.equals(etatInterventionId))) {
				String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.CTRL_LIBINTERV_000020);
				return serviceManager.getAnomalieManager().newSFAno(TraitementConstantes.CONTROLELIBERATIONINTERV, VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.CONFIRM_ABANDON_VALEUR_CONSTANTE, papaProcessus), TypeAnomalieConstantes.AV,
						message);
			}
		}
		return null;
	}

	// --------------------------------------------------------------
	// M�thodes partag�es avec d'autres *Traitement du package
	// --------------------------------------------------------------

	/**
	 * Creates the evenement.
	 * 
	 * @param causeEvenementId the cause evenement id
	 * @param info the info
	 * @param dateFin the date fin
	 * @param idCurrentAgent the id current agent
	 * @param typeAbd the type abd
	 * 
	 * @return the evenement
	 */
	public static Evenement createEvenement(String causeEvenementId, String info, Date dateFin, String idCurrentAgent, String typeAbd) {
		serviceManager.getLoggerManager().finest(CLASSNAME, "createEvenement", "Construction de l'evenement avec les parametres causeEvenementId=" + causeEvenementId + " info=" + info + " dateFin=" + dateFin);
		CauseEvenementDTO causeEvenement = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, causeEvenementId);
		if (causeEvenement == null) {
			serviceManager.getLoggerManager().severe(CLASSNAME, "createEvenement", "La CauseEvenement d'Id=" + causeEvenementId + " n'existe pas.");
			return null;
		}
		TypeEvenementDTO typeEvenement = causeEvenement.getTypeEvenement();
		CategorieEvenementDTO categorieEvenement = typeEvenement.getCategorieEvenement();
		RoleDTO role = causeEvenement.getRole();
		Evenement evenement = new Evenement();
		evenement.setId(serviceManager.getGeneratorManager().generateKey());
		evenement.setLibelle(info);
		evenement.setIdCauseEvenement(causeEvenementId);
		evenement.setLibCauseEvenement(causeEvenement.getLibelle());
		evenement.setIdTypeEvenement(typeEvenement.getId());
		if (categorieEvenement != null) {
			evenement.setIdCategorieEvenement(categorieEvenement.getId());
		}
		if (role != null) {
			evenement.setIdRole(role.getId());
		}
		if (dateFin != null) {
			evenement.setDateFin(DateUtils.getDatabaseDate(dateFin.getTime()));
		}
		evenement.setIdAPourOrigineAgent(idCurrentAgent);
		evenement.setTypeAbd(typeAbd);
		return evenement;
	}

	/**
	 * Creates the evt pour processus.
	 * 
	 * @param evenement the evenement
	 * @param processusId the processus id
	 * 
	 * @return the evt dto
	 */
	protected static EvtDTO createEvtPourProcessus(final Evenement evenement, final String processusId, String idCommande) {
		EvtDTO evtDTO = new EvtDTO(evenement.getId());
		if (evenement.getIdCauseEvenement() != null) {
			evtDTO.setCauseEvenement(new CauseEvenementDTO(evenement.getIdCauseEvenement()));
		}
		evtDTO.setDatabaseDateDateCreation(evenement.getDateGeneration());
		evtDTO.setDatabaseDateDateFinPrevue(evenement.getDateFin());
		String info = evenement.getLibelle();
		if (info != null) {
			if (info.length() > MAX_CHAR_INFO) {
				serviceManager.getLoggerManager().warning(CLASSNAME, "createEvtPourProcessus", String.format("On tronque � %d caract�res le message EVT.INFO : %s", MAX_CHAR_INFO, info));
				evtDTO.setInfo(info.substring(0, MAX_CHAR_INFO));
			} else {
				evtDTO.setInfo(info);
			}
		}
		evtDTO.setAPourOrigineAgent(new AgentDTO(evenement.getIdAPourOrigineAgent()));
		evtDTO.setTypeAbd(evenement.getTypeAbd());
		evtDTO.setProcessus(new ProcessusDTO(processusId));
		serviceManager.getProcessusManager().createEvt(evtDTO);

		// US-678 Notification pour creation d'evenement
		String evtLibelle = StringUtils.removeStart(evtDTO.getCauseEvenement().getId(), serviceManager.getVersionManager().getCurrentVersion() + "_");

		NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_E, evtLibelle, evtDTO.getId(),idCommande);
		serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);

		return evtDTO;
	}

	/**
	 * Supprimer les occurrences de TacheEnCours telles que
	 * TacheEnCours.IdCommande = Id_Commande dont on veut interrompre le
	 * traitement automatique (pour Regul Manuel).
	 * 
	 * @param processusId the processus id
	 * 
	 * @return Liste des tacheId des TacheEnCours supprim�es
	 */
	protected static Collection<String> rechercheEtSuppressionTacheEnCoursByProcessus(String processusId) {
		String methodName = "rechercheEtSuppressionTacheEnCoursByProcessus";
		serviceManager.getLoggerManager().finest(CLASSNAME, methodName, "D�but pour processus d'id=" + processusId);

		// Je r�cup�re l'ID de commande de la PREMIERE ligne de commande
		// li�e au processus courant car toutes les lignes de commande
		// d'un processus sont de la m�me commande
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByProcessus(processusId);

		// R�cup�ration, puis suppression, des taches en cours li� � la
		// commande pass�e en param�tre
		Collection<String> lstTacheId = new ArrayList<String>();
		serviceManager.getLoggerManager().finest(CLASSNAME, methodName, "R�cup�ration des taches en cours correspondant � la commande " + commande.getId());
		List<TacheEnCoursDTO> tachesEnCours = serviceManager.getProcessusManager().findTacheEnCoursByCommande(commande.getId());
		for (TacheEnCoursDTO tacheEnCours : tachesEnCours) {
			lstTacheId.add(tacheEnCours.getId());
			serviceManager.getLoggerManager().finest(CLASSNAME, methodName, "Suppression de la tache en cours d'identifiant " + tacheEnCours.getId());
			serviceManager.getProcessusManager().deleteTacheEnCours(tacheEnCours.getId());
		}

		return lstTacheId;
	}

	/**
	 * Relier processus a lignes commandes.
	 * 
	 * @param papaProcessusId the papa processus id
	 * @param processusARelier the processus a relier
	 */
	protected static void relierProcessusALignesCommandes(String papaProcessusId, ProcessusDTO processusARelier) {
		Set<String> ligneCommandeIdSet = new HashSet<String>();
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(papaProcessusId);
		for (LigneCommandeDTO lc : lignesCde) {
			// d�doublonnement
			if (!ligneCommandeIdSet.contains(lc.getId())) {
				ligneCommandeIdSet.add(lc.getId());
				ProcessusLcDTO processusLC = new ProcessusLcDTO(serviceManager.getGeneratorManager().generateKey());
				processusLC.setProcessus(processusARelier);
				processusLC.setLigneCommande(lc);
				serviceManager.getProcessusManager().createProcessusLC(processusLC);
			}
		}
	}

	/**
	 * Creates the processus.
	 * 
	 * @param processusTypeId the processus type id
	 * @param papaProcessus the papa processus
	 * 
	 * @return the processus dto
	 */
	protected static ProcessusDTO createProcessus(String processusTypeId, ProcessusDTO papaProcessus) {
		Long dateCreation = DateUtils.getDatabaseDate();
		ProcessusDTO processus = new ProcessusDTO(serviceManager.getGeneratorManager().generateKey());
		processus.setDatabaseDateDateCreation(dateCreation);
		processus.setEtatProcessus(new EtatProcessusDTO(EtatProcessusConstantes.CREE));
		processus.setProcessusType(new ProcessusTypeDTO(processusTypeId));
		processus.setGenereParProcessus(papaProcessus);
		processus.setIdCommande(papaProcessus.getIdCommande());
		processus = serviceManager.getProcessusManager().createProcessus(processus);
		serviceManager.getLoggerManager().finer(CLASSNAME, "createProcessus", "Cr�ation processus " + processus.getId() + " de type : " + processusTypeId);
		return processus;
	}

	/**
	 * Adds the idempotence.
	 * 
	 * @param donnees the donnees
	 * @param papaProcessusId the papa processus id
	 */
	protected static void addIdempotence(Map<String, String> donnees, String papaProcessusId) {
		// on recherche la ligne de commande avec le plus petit ID
		LigneCommandeDTO ligneCommande = null;
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(papaProcessusId);
		for (LigneCommandeDTO lc : lignesCde) {
			if (ligneCommande == null) {
				ligneCommande = lc;
			} else if (lc.getId().compareTo(ligneCommande.getId()) < 0) {
				ligneCommande = lc;
			}
		}
		// mise a jour du champ d'idempotence du rootset
		if (ligneCommande != null) {
			donnees.put(Constantes.IDEMPOTENCE_ID_LIGNE_CMD, ligneCommande.getId());
		}
	}

	/**
	 * Gets the jalon.
	 * 
	 * @param processusId the processus id
	 * 
	 * @return the jalon
	 */
	protected static String getJalon(String processusId) {
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByProcessus(processusId);
		if (lignesCde.isEmpty()) {
			LigneCommandeDTO lc = lignesCde.iterator().next();
			return lc.getJalon().getId();
		}
		return null;
	}

	/**
	 * Lib�rations des interventions �ventuelles.
	 * 
	 * @param versionArtemis the version bolbec
	 * @param papaProcessusId the papa processus id
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>08/06/2010</TD><TD>PHC</TD><TD>IRMA_57: Ajout du cas ENVOI</TD></TR>
	 * <TR><TD>08/12/2011</TD><TD>GPA</TD><TD>EV-000173 : Passage de la m�thode en public</TD></TR>
	 * <TR><TD>20/02/2013</TD><TD>GPA</TD><TD>DE-000760(interne): Ajout du SFAno en retour de la m�thode</TD></TR>
	 * <TR><TD>28/05/2013</TD><TD>GPA</TD><TD>DE-000348 : D�doublonnage des interventions</TD></TR>
	 * <TR><TD>08/11/2012</TD><TD>EBA</TD><TD>G8R2C4 EV-273 : Prendre le RDV DQPSI 2013_38</TD></TR>
	 * </TABLE>
	 */
	public static SFAno libererInterventions(String papaProcessusId, String versionArtemis, String responsabiliteId) {
		SFAno sfAno = null;
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByProcessus(papaProcessusId);
		LigneCommandeDTO firstLigneCde = lignesCde.iterator().next();

		// R�cup�ration du critereLocalisation pour le processus
		String critereLocalisation = firstLigneCde.getInstanceLocalisation().getId();

		// R�cup�ration le ND � utiliser en mode bouchons, � la place du crit�re de localisation
		String ndLocalisation = null;
		AccesLivraisonKey key = new AccesLivraisonKey(firstLigneCde);
		if (key.getType().getValue() == TypeAccesLivraisonEnum.ND.getValue()) {
			ndLocalisation = key.getReference();
		}

		// lib�ration des interventions
		List<InterventionDTO> interventions = serviceManager.getCommandeManager().findInterventionByProcessus(papaProcessusId);
		// DE-348 : D�doublonnage des interventions
		Set<InterventionDTO> interventionsSansDoublon = new HashSet<InterventionDTO>(interventions);
		for (InterventionDTO intervention : interventionsSansDoublon) {
			String etatInterventionId = intervention.getEtatIntervention().getId();
			// IRMA_57: Ajout de ENVOI
			if (EtatInterventionConstantes.RESERV.equals(etatInterventionId) || EtatInterventionConstantes.AMODIF.equals(etatInterventionId) || EtatInterventionConstantes.ENVOI.equals(etatInterventionId)) {
				sfAno = libererIntervention(intervention, papaProcessusId, critereLocalisation, ndLocalisation, versionArtemis, responsabiliteId);
			} else if (EtatInterventionConstantes.ARESERV.equals(etatInterventionId) || EtatInterventionConstantes.PLANIF.equals(etatInterventionId)) {
				intervention.setEtatIntervention(new EtatInterventionDTO(EtatInterventionConstantes.ANN));
				serviceManager.getCommandeManager().updateInterventionEtat(intervention);
			}
		}

		return sfAno;
	}

}