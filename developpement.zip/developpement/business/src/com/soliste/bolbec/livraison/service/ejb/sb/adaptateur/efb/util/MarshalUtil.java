/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : MarshalDelegate.java
 *   Revision  : 06_00#1
 *   DateRev   : 14-NOV-2005 14:35:51
 *   Chemin    : ARTE/developpement/uc_adaptateurs/src.ejb/bolbec/adaptateur/efb/delegues/MarshalDelegate.java
 * --------------------------------------------
 *   Historique  :
 *    Revision 06_00#1 (CREE)
 *      Created:  14-NOV-2005 14:35:51 UDGE5525
 *        Cr ation
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.efb.util;

import java.io.StringReader;
import java.io.StringWriter;

import org.exolab.castor.xml.MarshalException;
import org.exolab.castor.xml.ValidationException;

import aps.AnomalieConstantes;
import bolbec.adaptateur.efb.xml.generated.CommandeEfb;
import bolbec.injection.xml.generated.Message;

import com.soliste.bolbec.livraison.service.exception.ReceptionCdeException;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>02/12/2010</TD><TD>LBA</TD><TD>Ajout accolades autour d'instruction seule</TD></TR>
 * </TABLE><BR>
 */

/**
 * The Class MarshalUtil.
 */
public class MarshalUtil {

	/**
	 * Unmarshal message body.
	 * 
	 * @param message the message
	 * 
	 * @return the commande efb
	 * 
	 * @throws ReceptionCdeException the reception cde exception
	 */
	public static CommandeEfb unmarshalMessageBody(String message) throws ReceptionCdeException {
		try {
			return (CommandeEfb) CommandeEfb.unmarshal(new StringReader(message));
		} catch (ValidationException ve) {
			throw getValidationException(ve);
		} catch (MarshalException me) {
			if (me.getException() instanceof ValidationException) {
				throw getValidationException((ValidationException) me.getException());
			}
			throw new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Une exception s'est produite lors de la de-s�rialisation de l'XML d'une intention de commande EFB.\n L'exception Castor est la suivante : \n" + me.getLocalizedMessage(), me);
		}
	}

	/**
	 * Gets the validation exception.
	 * 
	 * @param ve the a_ex
	 * 
	 * @return the validation exception
	 */
	private static ReceptionCdeException getValidationException(ValidationException ve) {
		return new ReceptionCdeException(AnomalieConstantes.SYNTAXE_ICEFB, "Une exception s'est produite lors de la validation de l'XML d'une intention de commande EFB.\n" + "L'exception Castor est la suivante pour le champ " + ve.getLocation() + ": \n"
				+ ve.getLocalizedMessage(), ve);
	}

	/**
	 * Marshal.
	 * 
	 * @param message the message
	 * 
	 * @return the string
	 */
	public static String marshal(Message message) {
		StringWriter writer = new StringWriter();
		try {
			message.marshal(writer);
		} catch (MarshalException a_ex) {
			throw new ReceptionCdeException("marshal", "Erreur lors du marshal", a_ex);
		} catch (ValidationException a_ex) {
			throw new ReceptionCdeException("marshal", "Erreur lors de la validation", a_ex);
		}
		return writer.toString();
	}

}