package com.soliste.bolbec.livraison.service.ejb.sb.accueil;

import javax.ejb.EJBLocalObject;

public interface AccueilManagerLocal extends EJBLocalObject, AccueilManager {

}
