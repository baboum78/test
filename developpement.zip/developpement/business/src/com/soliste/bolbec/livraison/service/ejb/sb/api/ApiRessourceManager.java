package com.soliste.bolbec.livraison.service.ejb.sb.api;

import javax.ejb.EJBLocalObject;

import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.AppointmentRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.NoteRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.ServiceOrderRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.ressourceTraitement.TaskRessourceTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.AddressRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.AppointmentRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.CustomerRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.DonneeReferenceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.NoteRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.PublicationRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.ServiceOrderRessourceTraitementV2;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.ressourceTraitement.TaskRessourceTraitementV2;

/**
 * Interface local de l'EJB session ApiRessourceManager.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>27/11/2015</TD><TD>MFA</TD><TD>Initialisation</TD></TR>
 * <TR><TD>05/10/2016</TD><TD>JDE</TD><TD>Ajout des traitements V2</TD></TR>
 * <TR><TD>19/10/2016</TD><TD>JDE</TD><TD>Ajout du CustomerRessourceTraitement et AddressRessourceTraitement</TD></TR>
 * <TR><TD>03/05/2018</TD><TD>AJO</TD><TD>QC974 : Vador</TD></TR>
 * </TABLE>
 * 
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'>
 * <TR><TD>REQNumber</TD><TD>API REST</TD></TR>
 * </TABLE>
 */
public interface ApiRessourceManager extends EJBLocalObject {

	/**
	 * Retourne NoteRessourceTraitement
	 * 
	 */
	public NoteRessourceTraitement getNoteRessourceTraitement();

	/**
	 * Retourne TaskRessourceTraitement
	 * 
	 */
	public TaskRessourceTraitement getTaskRessourceTraitement();

	/**
	 * Retourne AppointmentRessourceTraitement
	 */
	public AppointmentRessourceTraitement getAppointmentRessourceTraitement();

	/**
	 * Retourne ServiceOrderRessourceTraitement
	 */
	public ServiceOrderRessourceTraitement getServiceOrderRessourceTraitement();

	/**
	 * Retourne NoteRessourceTraitementV2
	 * 
	 */
	public NoteRessourceTraitementV2 getNoteRessourceTraitementV2();

	/**
	 * Retourne TaskRessourceTraitementV2
	 * 
	 */
	public TaskRessourceTraitementV2 getTaskRessourceTraitementV2();

	/**
	 * Retourne AppointmentRessourceTraitementV2
	 */
	public AppointmentRessourceTraitementV2 getAppointmentRessourceTraitementV2();

	/**
	 * Retourne ServiceOrderRessourceTraitementV2
	 */
	public ServiceOrderRessourceTraitementV2 getServiceOrderRessourceTraitementV2();

	/**
	 * Retourne CustomerRessourceTraitementV2
	 */
	public CustomerRessourceTraitementV2 getCustomerRessourceTraitementV2();

	/**
	 * Retourne AddressRessourceTraitementV2
	 */
	public AddressRessourceTraitementV2 getAddressRessourceTraitementV2();

	/**
	 * Retourne PublicationRessourceTraitementV2
	 */
	public PublicationRessourceTraitementV2 getPublicationRessourceTraitementV2();

	/**
	 * Retourne DonneeReferenceTraitementV2
	 */
	public DonneeReferenceTraitementV2 getDonneeReferenceTraitementV2();

}
