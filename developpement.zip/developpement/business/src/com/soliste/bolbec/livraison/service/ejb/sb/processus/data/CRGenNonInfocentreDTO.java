/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.io.Serializable;
import java.util.List;

/**
 * Le DTO pour l'entit� CR non infocentre
 */
public class CRGenNonInfocentreDTO implements Serializable {

	private String id;

	private boolean validable;

	private String formatExterne;
	private String jalon;
	private String sysExterne;
	private String libelleEtatPublication;
	private String libelleLienPublication;
	private List<ChampCRGenNonInfocentreDTO> champs;

	/**
	 * @param id
	 */
	CRGenNonInfocentreDTO(String id) {
		// Constructeur
		this.id = id;
	}

	/**
	 * @return id
	 */
	public String getId() {
		return id;
	}

	/**
	 * @param id
	 */
	public void setId(String id) {
		this.id = id;
	}

	/**
	 * 
	 * @return liste des champs
	 */
	public List<ChampCRGenNonInfocentreDTO> getChamps() {
		return champs;
	}

	/**
	 * 
	 * @param champs
	 */
	public void setChamps(List<ChampCRGenNonInfocentreDTO> champs) {
		this.champs = champs;
	}

	/**
	 * 
	 * @return le libell� du jalon
	 */
	public String getJalon() {
		return jalon;
	}

	/**
	 * 
	 * @param jalon libell� du jalon
	 */
	public void setJalon(String jalon) {
		this.jalon = jalon;
	}

	/**
	 * Valeur constante du syst�me externe.
	 * 
	 * @return le libell� du syst�me externe
	 */
	public String getSysExterne() {
		return sysExterne;
	}

	/**
	 * Valeur constante du syst�me externe.
	 * 
	 * @param sysExterne libell� du syst�me externe
	 */
	public void setSysExterne(String sysExterne) {
		this.sysExterne = sysExterne;
	}

	/**
	 * @return formatExterne
	 */
	public String getFormatExterne() {
		return formatExterne;
	}

	/**
	 * @param formatExterne
	 */
	public void setFormatExterne(String formatExterne) {
		this.formatExterne = formatExterne;
	}

	/**
	 * @return libelleEtatPublication
	 */
	public String getLibelleEtatPublication() {
		return libelleEtatPublication;
	}

	/**
	 * @param libelleEtatPublication
	 */
	public void setLibelleEtatPublication(String libelleEtatPublication) {
		this.libelleEtatPublication = libelleEtatPublication;
	}

	/**
	 * @return libelleLienPublication
	 */
	public String getLibelleLienPublication() {
		return libelleLienPublication;
	}

	/**
	 * @param libelleLienPublication
	 */
	public void setLibelleLienPublication(String libelleLienPublication) {
		this.libelleLienPublication = libelleLienPublication;
	}

	/**
	 * @return validable
	 */
	public boolean isValidable() {
		return validable;
	}

	/**
	 * @param validable
	 */
	public void setValidable(boolean validable) {
		this.validable = validable;
	}
}
