/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.adaptateur.sagic;

import com.soliste.bolbec.livraison.service.ConstantesParametreArtemis;

/**
 * @author Phil Bretherton
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>21/03/2011</TD><TD>JCH</TD><TD>Correction de l'affichage des comptes rendus Sagic. Affichage de Compte rendu inexistant</TD></TR>
 * <TR><TD>20/11/2013</TD><TD>FTE</TD><TD>G8R2C4 - EV-000270 : V�rification de la coh�rence des commandes PSG+ 1.1</TD></TR>
 * <TR><TD>19/12/2018</TD><TD>RMA</TD><TD>US 58: Transmission Debit Messur� � 42C</TD></TR>
 * </TABLE><BR>
 * Classe de constantes SAGIC
 */
public interface SagicConstantes {

	String OP = "OP";
	String M = "M"; // Pour RV 12 SFG_AdaptateurSagic
	String DXF = ConstantesParametreArtemis.DXF;

	String CODE_OFFRE = "CODE_OFFRE";

	String KEY_CODE_ACTION = "CODE_ACTION";
	String KEY_CONTEXTE_OPERATION = "CONTEXTE_OPERATION";
	String KEY_CODE_OPERATEUR = "CODE_OPERATEUR";
	String KEY_TYPE_OFFRE = "TYPE_OFFRE";
	String KEY_CASMETIER_SAGIC = "CASMETIER_SAGIC";
	String KEY_CODE_ACTION_PORTA_SUB = "CODE_ACTION_PORTA_SUB";
	String KEY_CODE_ACTION_MOTIF_RESIL = "CODE_ACTION_MOTIF_RESIL";

	String FORMAT_DATE_HEURE = "dd/MM/yyyy HH:mm:ss";
	String FORMAT_DATE = "dd/MM/yyyy";

	String JMS_PROP_DATE_REJET = "DateRejet";
	String JMS_PROP_CAUSE_REJET = "CauseRejet";
	String JMS_PROP_DIAGNOSTIC_REJET = "DiagnosticRejet";

	String TYPE_OFFRE_DE_GROS = "Offre_De_Gros";
	String TYPE_OFFRE_DETAIL = "Offre_Detail";

	String TYPE_DE_VENTE_WHOLESALE = "WHOLESALE";

	String VALEUR_INCONNUE = "?";
	String SEPARATOR_CRENEAURDVOP = "-";
	String SEPARATOR_REFRDV = "-";

	String TYPEACCES_ND = "ND";
	String TYPEACCES_NDPLP = "NDPLP";
	String TYPEACCES_IDCLI = "IDCLI";

	String ETATINTERV_PLANIFIEE = "PLANIF";
	String ETATINTERV_ARESERVER = "ARESERV";
	String ETATINTERV_RESERVE = "RESERV";

	String DUREE_INTERV_DEFAUT = "0200";

	String TYPE_DEG = "TYPE_DEG";

	String ANO_ERREUR_TRADUCTION = "ERREUR_TRADUCTION";
	String ANO_INCONNU = "ERREUR_INTERNE";
	String ANO_SYNTAX_ICSAGIC = "SYNTAXE_ICSAGIC";

	String COMPTERENDUINEXISTANT = "Compte rendu inexistant";

	String KEY_REF_COMMANDE = "REF_COMMANDE";
	String KEY_FORMAT = "FORMAT";
	String REJ_SAGIC = "REJ_SAGIC";
	String NON_PEC = "NON_PEC";

	String CR_402 = "402";
	String CR_403 = "403";

	int LIMITE_INFERIEUR_CONTEXTE_ELIGIBILITE_DEBIT = 0;
	int LIMITE_SUPERIEUR_CONTEXTE_ELIGIBILITE_DEBIT = 9;
}
