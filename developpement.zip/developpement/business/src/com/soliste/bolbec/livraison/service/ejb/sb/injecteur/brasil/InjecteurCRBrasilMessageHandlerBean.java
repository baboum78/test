/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.injecteur.brasil;

import java.io.IOException;
import java.io.Serializable;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.fwk.util.XmlUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean;
import com.soliste.bolbec.livraison.service.ejb.sb.injecteur.ActivationParam;
import com.soliste.bolbec.livraison.service.exception.InvalidMessageException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesthd.data.BrasilDeclarations;

/**
 * @author PQTV8886
 */

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>29/01/2014</TD><TD>VDE</TD><TD>G8R2C4 : EV-000227_1 "Mutation en masse DSLAM"</TD></TR>
 * </TABLE><BR>
 */

public class InjecteurCRBrasilMessageHandlerBean extends AbstractInjecteurMessageHandlerBean {

	/**
	 * 
	 */
	private static final long serialVersionUID = -4060043127086550478L;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.injecteur.AbstractInjecteurMessageHandlerBean#getActivationParam(java.io.Serializable)
	 */
	public ActivationParam getActivationParam(Serializable message) throws InvalidMessageException {
		ActivationParam ap = null;
		String messageId = null;
		String sf = null;
		Document doc;
		String messageStr = (String) message;
		// R�cup�ration du bon nom de service
		if (StringUtils.indexOf(messageStr, BrasilDeclarations.TAG_SERVICE_PREPARE_OUT) != -1) {
			sf = BrasilDeclarations.TAG_SERVICE_PREPARE_OUT;
		} else if (StringUtils.indexOf(messageStr, BrasilDeclarations.TAG_SERVICE_ABORT_OUT) != -1) {
			sf = BrasilDeclarations.TAG_SERVICE_ABORT_OUT;
		} else if (StringUtils.indexOf(messageStr, BrasilDeclarations.TAG_SERVICE_COMMIT_OUT) != -1) {
			sf = BrasilDeclarations.TAG_SERVICE_COMMIT_OUT;
		} else if (StringUtils.indexOf(messageStr, BrasilDeclarations.TAG_RECHERCHE_BROCHE) != -1) {
			// Pas de modifiation du processus pour ce SF donc on utilise affecterEPTXDSL
			sf = BrasilDeclarations.AFFECTEREPTXDSL;
		} else {
			throw new InvalidMessageException("message invalide : le fichier soap ne correspond pas � une r�ponse de Brasil");
		}

		/*
		 * String bodyMessage = StringUtils.substring(messageStr, StringUtils.indexOf(messageStr, BrasilDeclarations.TAG_SOAP_BODY_DEBUT) + BrasilDeclarations.TAG_SOAP_BODY_FIN.length(), StringUtils
		 * .indexOf(messageStr, BrasilDeclarations.TAG_SOAP_BODY_FIN));
		 */
		try {
			doc = XmlUtils.getDocument(messageStr);
			// Pas de validation pour l'instant tant que l'on n'arrive pas � avoir une bonne coh�rence entre les XML en entr�e et les XSD
			// doc = XmlUtils.getDocument(bodyMessage, InjecteurCRBrasilMessageHandlerBean.class.getResource(xsd).getFile());
		} catch (SAXException se) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + se.getMessage(), messageStr, se);
		} catch (IOException ie) {
			throw new InvalidMessageException("Erreur de recuperation du document : " + ie.getMessage(), messageStr, ie);
		}

		Element element = doc.getDocumentElement();
		NodeList nodeList;
		// Recherche du num�ro de commande pour d�finir le CR en base
		// EV 227_1
		if (BrasilDeclarations.AFFECTEREPTXDSL.equals(sf)) {
			nodeList = element.getElementsByTagName(BrasilDeclarations.TAG_ID_DEMANDE_UNITAIRE);
		} else {
			nodeList = element.getElementsByTagName(BrasilDeclarations.TAG_ORDER_ID);
		}

		if (nodeList.getLength() == 1) {
			Element nodeOrderId = (Element) nodeList.item(0);
			Node textNode = nodeOrderId.getFirstChild();
			messageId = textNode.getNodeValue();
		}
		if (messageId != null) {
			ap = new ActivationParam(sf, messageId);
		} else {
			throw new InvalidMessageException("Message invalide, tag " + BrasilDeclarations.TAG_ORDER_ID);
		}
		return ap;
	}

}