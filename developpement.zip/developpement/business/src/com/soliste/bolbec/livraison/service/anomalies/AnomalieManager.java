/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.anomalies;

import java.text.MessageFormat;
import java.util.List;
import java.util.Map;

import aps.CauseEvenementConstantes;
import aps.FiltrageFamilleIHM;
import aps.LienAnoCauseEvt;
import aps.MessagesConstantes;
import aps.TypeAnomalieConstantes;

import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.commun.service.util.Comparaison;
import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.exception.CancelException;
import com.soliste.bolbec.livraison.service.exception.DoneException;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.InterfaceException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.commun.GestionErreurInterface;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.commun.IOParam;
import com.soliste.bolbec.livraison.service.model.AnomalieDTO;
import com.soliste.bolbec.livraison.service.model.CategorieEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.FiltrageFamilleIHMDTO;
import com.soliste.bolbec.livraison.service.model.LienAnoCauseEvtDTO;
import com.soliste.bolbec.livraison.service.model.MessagesDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.util.ExecStepAutoData;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * Classe de base permettant, pour un traitement et une anomalie donn�s, de d�terminer l'�v�nement � �x�cuter
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Ajout de la m�thode getGestionErreurInterface</TD></TR>
 * <TR><TD>21/11/2011</TD><TD>GPA</TD><TD>Correction du message NO_MESSAGE_ERROR</TD></TR>
 * </TABLE>
 */
public class AnomalieManager implements IAnomalieManager {

	private static final String CLASS_NAME = AnomalieManager.class.getName();
	private static final String NO_MESSAGE_ERROR = "Aucun message trouve pour l''erreur ";

	private static IAnomalieManager instance = null;
	private IServiceManager serviceManager;

	/**
	 * 
	 */
	protected AnomalieManager() {
		serviceManager = ServiceManager.getInstance();
	}

	/**
	 * 
	 * @return
	 */
	public synchronized static IAnomalieManager getInstance() {
		if (instance == null) {
			instance = new AnomalieManager();
		}
		return instance;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#majRoleEvenement(com.soliste.bolbec.livraison.service.anomalies.Evenement, java.lang.String, java.util.Map)
	 */
	public final Evenement majRoleEvenement(Evenement evenement, String idTraitement, Map<String, String> proprietesWorkflow) {
		String familleIHM = proprietesWorkflow.get(Constantes.RS_FAMILLE_OFFRE);
		if (familleIHM != null) {
			FiltrageFamilleIHMDTO filtrageFamilleIHM = serviceManager.getReferenceSpaceManager().findInReferenceSpace(FiltrageFamilleIHMDTO.class, new Comparaison(FiltrageFamilleIHM.SLINK_CONCERNE_TRAITEMENT, Constantes.OPERATOR_EQUAL, idTraitement),
					new Comparaison(FiltrageFamilleIHM.FIELD_FAMILLE_IHM, Constantes.OPERATOR_EQUAL, familleIHM), new Comparaison(FiltrageFamilleIHM.SLINK_POUR_CAUSE_EVENEMENT, Constantes.OPERATOR_EQUAL_OR_NULL, evenement.getIdCauseEvenement()));
			if (filtrageFamilleIHM != null && filtrageFamilleIHM.getRole() != null) {
				evenement.setIdRole(filtrageFamilleIHM.getRole().getId());
			}
		}
		return evenement;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#traiter(java.lang.String, com.soliste.bolbec.livraison.service.anomalies.SFAno)
	 */
	public final Evenement traiter(String idTraitement, SFAno sfAno) {
		serviceManager.getLoggerManager().finest(CLASS_NAME, "traiter",
				"idTraitement=" + idTraitement + ", sfAno.getId()=" + sfAno.getId() + ", sfAno.getNomSF()=" + sfAno.getNomSF() + ", sfAno.getErreur()=" + sfAno.getErreur() + ", sfAno.getType()=" + sfAno.getType() + ", sfAno.getInfo()=" + sfAno.getInfo());

		String causeEvenement = getLienAnoCauseEvt(idTraitement, sfAno);
		Evenement evenement = new Evenement();
		if (StringUtils.isNotEmpty(causeEvenement)) {
			evenement.setLibelle(sfAno.getInfo());
			evenement.setIdCauseEvenement(causeEvenement);
		} else {
			evenement.setLibelle(getMessage(MessagesConstantes.GENE_000150, new Object[] { sfAno.getErreur(), idTraitement }));
			if (TypeAnomalieConstantes.DNR.equals(sfAno.getType())) {
				evenement.setIdCauseEvenement(CauseEvenementConstantes.ERREURPARAM);
			} else {
				evenement.setIdCauseEvenement(CauseEvenementConstantes.ERREURPARAMNBQ);
			}
		}
		setCauseEvenement(evenement);
		setTypeEvenement(evenement);
		setCategorieEvenement(evenement);
		evenement.setIdAPourOrigineAgent(null);
		evenement.setTypeAbd(null);
		return evenement;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#newAnomalieException(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public AnomalieException newAnomalieException(String nomSF, String erreur, String type, String message) {
		return new AnomalieException(newSFAno(nomSF, erreur, type, message));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#newAnomalieException(java.lang.String, java.lang.String, java.lang.String)
	 */
	public AnomalieException newAnomalieException(String nomSF, String erreur, String message) {
		return new AnomalieException(newSFAno(nomSF, erreur, message));
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#newSFAno(java.lang.String, java.lang.String, java.lang.String, java.lang.String)
	 */
	public SFAno newSFAno(String nomSF, String erreur, String type, String message) {
		return new SFAno("0", nomSF, erreur, type, message);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#newSFAno(java.lang.String, java.lang.String, java.lang.String)
	 */
	public SFAno newSFAno(String nomSF, String erreur, String message) {
		return newSFAno(nomSF, erreur, getType(erreur), message);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#newAno(java.lang.String, java.lang.String, java.lang.String)
	 */
	public SFAno newAno(String erreur, String type, String message) {
		return newSFAno(null, erreur, type, message);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#newAno(java.lang.String, java.lang.String)
	 */
	public SFAno newAno(String erreur, String message) {
		String type = getType(erreur);
		return newSFAno(null, erreur, type, message);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#getMessage(java.lang.String, java.lang.Object[])
	 */
	public String getMessage(String messageId, Object... params) {
		String message = getMessageLibelle(messageId);
		return MessageFormat.format(message, params);
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.anomalies.IAnomalieManager#getMessage(java.lang.String)
	 */
	public String getMessage(String messageId) {
		return getMessage(messageId, (Object[]) null);
	}

	private String getType(String anoId) {
		AnomalieDTO anomalieDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(AnomalieDTO.class, anoId);
		return anomalieDTO.getTypeAnomalie().getId();
	}

	/**
	 * getMessageLibelle
	 * 
	 * @param messageId
	 * @return un libell� de message
	 */
	private String getMessageLibelle(String messageId) {
		String libelle = null;
		MessagesDTO messagesDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(MessagesDTO.class, messageId);
		if (messagesDTO != null) {
			libelle = messagesDTO.getLibelle();
		}
		if (libelle == null) {
			libelle = NO_MESSAGE_ERROR + messageId;
		}
		return libelle;
	}

	/**
	 * @param idTraitement
	 * @param sfAno
	 * @return la cause �v�nement recherche dans la table LienAnoCauseEvt en
	 * fonction de l'anomalie et du traitement.
	 */
	private String getLienAnoCauseEvt(String idTraitement, SFAno sfAno) {
		LienAnoCauseEvtDTO lienAnoCauseEvtDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(LienAnoCauseEvtDTO.class, new Comparaison(LienAnoCauseEvt.SLINK_EST_ANOMALIE, Constantes.OPERATOR_EQUAL, sfAno.getErreur()),
				new Comparaison(LienAnoCauseEvt.SLINK_POUR_TRAITEMENT, Constantes.OPERATOR_EQUAL, idTraitement));
		String causeEvenement = null;
		if (lienAnoCauseEvtDTO != null) {
			causeEvenement = lienAnoCauseEvtDTO.getCauseEvenement().getId();
		}
		serviceManager.getLoggerManager().finest(CLASS_NAME, "getLienAnoCauseEvt", "causeEvenement=" + causeEvenement);
		return causeEvenement;
	}

	/**
	 * setCauseEvenement On recherche dans la table CauseEvenement � partir de
	 * l'id trouv� pr�cedemment dans LienAnoCauseEvt.
	 * 
	 * @param evenement
	 */
	private void setCauseEvenement(Evenement evenement) {
		CauseEvenementDTO causeEvenementDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evenement.getIdCauseEvenement());
		String libcauseEvenement = null;
		String typeEvenement = null;
		String role = null;
		if (causeEvenementDTO != null) {
			libcauseEvenement = causeEvenementDTO.getLibelle();
			evenement.setLibCauseEvenement(libcauseEvenement);
			typeEvenement = causeEvenementDTO.getTypeEvenement().getId();
			evenement.setIdTypeEvenement(typeEvenement);
			RoleDTO roleDto = causeEvenementDTO.getRole();
			if (roleDto != null) {
				role = roleDto.getId();
			}
			evenement.setIdRole(role);
		}
		serviceManager.getLoggerManager().finest(CLASS_NAME, "setCauseEvenement", "libcauseEvenement=" + libcauseEvenement + " , typeEvenement=" + typeEvenement + " , role=" + role);
	}

	/**
	 * setTypeEvenement On recherche dans la table TypeEvenement la
	 * categorieEvenement � partir de l'id trouv� pr�c�demment dans
	 * CauseEvenement.
	 * 
	 * @param evenement
	 */
	private void setTypeEvenement(Evenement evenement) {
		TypeEvenementDTO typeEvenementDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(TypeEvenementDTO.class, evenement.getIdTypeEvenement());
		String categorieEvenement = null;
		if (typeEvenementDTO != null) {
			categorieEvenement = typeEvenementDTO.getCategorieEvenement().getId();
			evenement.setIdCategorieEvenement(categorieEvenement);
		}
		serviceManager.getLoggerManager().finest(CLASS_NAME, "setTypeEvenement", "categorieEvenement=" + categorieEvenement);
	}

	/**
	 * setCategorieEvenement On recherche dans la table CategorieEvenement �
	 * partir de l'id trouv� pr�c�demment dans TypeEvenement.
	 * 
	 * @param evenement
	 */
	private void setCategorieEvenement(Evenement evenement) {
		CategorieEvenementDTO categorieEvenementDTO = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CategorieEvenementDTO.class, evenement.getIdCategorieEvenement());
		String libcategorieEvenement = null;
		if (categorieEvenementDTO != null) {
			libcategorieEvenement = categorieEvenementDTO.getLibelle();
			evenement.setLibCategorieEvenement(libcategorieEvenement);
		}
		serviceManager.getLoggerManager().finest(CLASS_NAME, "setCategorieEvenement", "libcategorieEvenement=" + libcategorieEvenement);
	}

	/**
	 * 
	 */
	public SFAno newAno(String erreur, String type, String message, String nomSF) {
		SFAno ano = newAno(erreur, type, message);
		ano.setNomSF(nomSF);
		return ano;
	}

	public void setServiceManager(IServiceManager serviceManager) {
		this.serviceManager = serviceManager;

	}

	/**
	 * 
	 */
	public void genererAnomalie(ExecStepAutoData data, Map<String, List<String>> staticAttributes, String erreur, String type, String messageId, Object... paramMessage) throws CancelException, DoneException {
		String message = serviceManager.getAnomalieManager().getMessage(messageId, paramMessage);
		SFAno sfAno = serviceManager.getAnomalieManager().newAno(erreur, type, message, data.getTraitementName());
		Evenement evt = serviceManager.getAnomalieManager().traiter(data.getTraitementName(), sfAno);
		serviceManager.getTacheManager().analyseEvenementAVP(evt, null, data.getTache(), data.getProprietesWorkflow(), staticAttributes, data.getTraitementName());
	}

	/**
	 * {@inheritDoc}
	 */
	public GestionErreurInterface getGestionErreurInterface(String nomSf, String origineCodeErreur, IOParam io, String codeErreurInterface) {
		return new GestionErreurInterface(nomSf, origineCodeErreur, io, codeErreurInterface);
	}

	/**
	 * {@inheritDoc}
	 */
	public GestionErreurInterface getGestionErreurInterface(String nomSf, String origineCodeErreur, IOParam io, InterfaceException ie) {
		return new GestionErreurInterface(nomSf, origineCodeErreur, io, ie);
	}

}