/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.avp.exception;

/**
 * Exception contenant un message internationalisable
 * 
 * @author rgvs7490
 */
public class MessageException extends Exception {

	private static final Object[] NO_PARAMETER = new Object[0];

	private String messageKey;
	private Object[] parameters;

	/**
	 * Constructeur
	 * 
	 * @param messageKey la cl� du message
	 */
	public MessageException(String messageKey) {
		this(messageKey, NO_PARAMETER);
	}

	/**
	 * Constructeur
	 * 
	 * @param messageKey la cl� du message
	 * @param parameters les param�tres du message
	 */
	public MessageException(String messageKey, Object[] parameters) {
		super(messageKey);
		this.messageKey = messageKey;
		if (parameters == null) {
			this.parameters = NO_PARAMETER;
		} else {
			this.parameters = parameters;
		}
	}

	/**
	 * Retourne la cl� du message
	 * 
	 * @return la cl� du message
	 */
	public String getMessageKey() {
		return this.messageKey;
	}

	/**
	 * Retourne les param�tres du message
	 * 
	 * @return les param�tres du message
	 */
	public Object[] getParameters() {
		return this.parameters;
	}
}
