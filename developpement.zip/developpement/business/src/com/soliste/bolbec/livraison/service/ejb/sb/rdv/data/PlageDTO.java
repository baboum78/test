/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.rdv.data;

import java.util.Date;

import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.gpc.Plage;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * DTO repr�sentant une plage. On y stocke la date de d�but de la plage sous forme de
 * date pour pouvoir la formater comme bon nous semble dans l'interface graphique
 * La date stock� est la date locale li� � la zoneSI de la commande.
 */
public class PlageDTO {

	private String id;
	private String codeUi;
	private Date dateDebut;
	private Date dateFin;
	private String dureePrevue;
	private String intervenor;

	/**
	 * 
	 * @param plage
	 * @param id
	 */
	public PlageDTO(Plage plage, String id) {
		this.codeUi = plage.getCodeUi();
		this.dateDebut = plage.getDebut();
		this.dateFin = plage.getFin();
		this.dureePrevue = plage.getDureePrevue();
		this.id = id;
		this.intervenor = plage.getIntervenor();
	}

	/**
	 * 
	 * @param codeUi
	 * @param dateDebut
	 * @param dateFin
	 * @param dureePrevue
	 */
	public PlageDTO(String codeUi, Date dateDebut, Date dateFin, String dureePrevue) {
		this.codeUi = codeUi;
		this.dateDebut = dateDebut;
		this.dateFin = dateFin;
		this.dureePrevue = dureePrevue;
	}

	public Date getDateDebut() {
		return this.dateDebut;
	}

	public String getCodeUi() {
		return codeUi;
	}

	public Date getDateFin() {
		return dateFin;
	}

	public String getDureePrevue() {
		return dureePrevue;
	}

	public String getId() {
		return id;
	}

	public String getIntervenor() {
		return intervenor;
	}

	public void setIntervenor(String intervenor) {
		this.intervenor = intervenor;
	}
}
