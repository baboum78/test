package com.soliste.bolbec.livraison.service.ejb.sb;

import java.rmi.RemoteException;

import javax.ejb.CreateException;
import javax.ejb.EJBHome;

/**
 * Interface home de l'EJB session ProcessusManager.
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>26/07/2011</TD><TD>GPE</TD><TD>BOLBEC-1394: ajout de l'interface remote</TD></TR>
 * </TABLE>
 */
public interface ProcessusManagerRemoteHome extends EJBHome {

	/**
	 * 
	 * @return
	 * @throws CreateException
	 */
	public ProcessusManagerRemote create() throws CreateException, RemoteException;

}
