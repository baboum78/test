/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader;

import java.util.ArrayList;
import java.util.List;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfDataFilter;
import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.aps.workflow.WfSynthesisObject;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.CorbeilleLoadCommand;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FiltreDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfFieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfSynthesisData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow.WfTache;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.CorbeilleLoaderException;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowLoadDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>09/08/2010</TD><TD>YTR</TD><TD>Refactor generation manager</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * </TABLE>
 * Impl�mentation du chargement des t�ches d'une corbeille � partir du workflow
 * 
 * @author gdzd8490
 * 
 */
public class WfTacheLoaderImpl extends WfLoaderImpl {

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#loadSynthesisList(java.util.List, java.util.List, com.soliste.aps.workflow.WfUser)
	 */
	public List<SynthesisData> loadSynthesisList(List<FieldDTO> selectionFilters, List<FiltreDTO> dataFilters, WfUser user) throws CorbeilleLoaderException {
		try {
			// Traduction des FieldDTO en WfSelFilter
			WfSelFilter[] wfSelectionFilters = null;
			if (selectionFilters != null) {
				wfSelectionFilters = new WfSelFilter[selectionFilters.size()];
				int i = 0;
				for (FieldDTO dto : selectionFilters) {
					wfSelectionFilters[i] = ((WfFieldDTO) dto).getField();
					i++;
				}
			}
			// Merge des filtres pour ne donner qu'un seul filtre workflow
			WfDataFilter wfFiltre = mergeFilters(dataFilters);
			// Appel workflow
			List<WfSynthesisObject> wfSynthesisList = ServiceManager.getInstance().getWorkflowManager().loadSynthesisTachesList(wfSelectionFilters, wfFiltre, user);
			// Transformation des WfSynthesis en WfSynthesisData
			return getSynthesisFacadeList(wfSynthesisList);
		} catch (Exception e) {
			throw new CorbeilleLoaderException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.loader.CorbeilleLoaderImpl#loadItemList(com.soliste.bolbec.livraison.service.ejb.sb.corbeille.CorbeilleLoadCommand, com.soliste.aps.workflow.WfUser)
	 */
	public void loadItemList(CorbeilleLoadCommand corbeilleLoadCommand, WfUser user) throws CorbeilleLoaderException {
		try {
			// Traduction du filtre en filtre workflow
			WfDataFilter wfFiltre = mergeFilters(corbeilleLoadCommand.getDataFilters());
			// R�cup�ration des donn�es workflow
			WorkflowLoadDTO dto = ServiceManager.getInstance().getWorkflowManager().load(wfFiltre, corbeilleLoadCommand.getPaginationCommand(), corbeilleLoadCommand.getElementsIds(), user, buildOrderByField(corbeilleLoadCommand.getSortCommand()));
			// Transformation des WfActivity en WfTache
			List<ItemData> wfTaches = getTacheFacadeList(dto.getLoadedElements());
			// Chargement de CorbeilleLoadCommand
			corbeilleLoadCommand.setLoadedElements(wfTaches);
			corbeilleLoadCommand.setElementsIds(dto.getElementsIds());
		} catch (Exception e) {
			throw new CorbeilleLoaderException(e);
		}
	}

	/**
	 * Utilisation de la facade WfTache
	 * 
	 * @param wfActivities
	 * une liste de WfActivity
	 * @return une liste de WfTache
	 */
	private List<ItemData> getTacheFacadeList(List<WfActivity> wfActivities) {
		int nbTaches = wfActivities.size();
		List<ItemData> wfTaches = new ArrayList<ItemData>(nbTaches);
		for (int i = 0; i < nbTaches; i++) {
			WfActivity wfActivity = wfActivities.get(i);
			wfTaches.add(new WfTache(wfActivity));
		}
		return wfTaches;
	}

	/**
	 * Utilisation de la facade WfSynthesisData
	 * 
	 * @param wfSynthesisList
	 * une liste de WfSynthesisObject
	 * @return une liste de wfSynthesisData
	 */
	private List<SynthesisData> getSynthesisFacadeList(List<WfSynthesisObject> wfSynthesisList) {
		int nbObjects = wfSynthesisList.size();
		List<SynthesisData> wfSynthesisDatas = new ArrayList<SynthesisData>(nbObjects);
		for (int i = 0; i < nbObjects; i++) {
			WfSynthesisObject wfObject = wfSynthesisList.get(i);
			wfSynthesisDatas.add(new WfSynthesisData(wfObject));
		}
		return wfSynthesisDatas;
	}
}
