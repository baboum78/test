/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField;

/**
 * Impl�mentation pour les infos que doit ramener une requ�te workflow
 * 
 * @author gdzd8490
 * 
 */
public class WfSelectedField implements SelectedField {

	private WfSelFilter selectedField;

	/**
	 * Constructeur
	 * 
	 * @param selectedField
	 */
	public WfSelectedField(WfSelFilter selectedField) {
		this.selectedField = selectedField;
	}

	/**
	 * Renvoie le filtre workflow
	 * 
	 * @return le filtre workflow
	 */
	public WfSelFilter getSelectedField() {
		return selectedField;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField#getAttributeType()
	 */
	public String getAttributeType() {
		return this.selectedField.getAttributeType();
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SelectedField#getAttributeName()
	 */
	public String getAttributeName() {
		return this.selectedField.getAttributeName();
	}

}
