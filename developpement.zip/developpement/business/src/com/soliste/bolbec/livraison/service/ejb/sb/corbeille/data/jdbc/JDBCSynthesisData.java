/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import java.util.List;

import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.SynthesisData;

/**
 * Facade pour les donn�es de synth�se JDBC
 * 
 * @author gdzd8490
 * 
 */
public class JDBCSynthesisData implements SynthesisData {

	/** Donn�es de regroupement */
	private List<String> values;

	/** Nb d'�l�ments dans ce regroupement */
	private int sum;

	/**
	 * Constructeur
	 * 
	 * @param values
	 * @param sum
	 */
	public JDBCSynthesisData(List<String> values, int sum) {
		this.values = values;
		this.sum = sum;
	}

	/**
	 * Retourne le nombre d'�l�ments dans ce regroupement
	 * 
	 * @return le nombre d'�l�ments dans ce regroupemen
	 */
	public int getSum() {
		return this.sum;
	}

	/**
	 * Renvoie les sous-regroupements formant ce regroupement
	 * 
	 * @return les sous-regroupements formant ce regroupement
	 */
	public List<String> getValues() {
		return this.values;
	}

}
