/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.jdbc;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleInfoConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleTranslator;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;
import com.soliste.bolbec.livraison.service.util.jdbc.JDBCField;
import com.soliste.bolbec.livraison.service.util.jdbc.TacheEnCoursJDBCFields;

/**
 * Classe permettant une traduction d'un CorbeilleInfo en �quivalent JDBC
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>17/09/2012</TD><TD>EBA</TD><TD>EV-000188: Vente FTTH - Ajout de l'EPCidVIA</TD></TR>
 * <TR><TD>12/11/2012</TD><TD>FTE</TD><TD>EV-000183: Apostrof - Ajout du CODE_REGIME (DynamicPsSouhaite)</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377: Commandes FTTE - Ajout du num�ro CLIP</TD></TR>
 * </TABLE>
 * 
 * @author gdzd8490
 */
public class JDBCCorbeilleTranslator implements CorbeilleTranslator {

	private static JDBCCorbeilleTranslator instance = null;
	/** Traduction CorbeilleInfo -> JDBCFilters */
	private static Map<String, String> filters;
	/** Traduction JDBCFilters -> CorbeilleInfo */
	private static Map<String, String> reverseFilters;

	static {
		Map<String, String> h = new HashMap<String, String>();
		h.put(CorbeilleInfoConstantes.ND_SUPPORT, TacheEnCoursJDBCFields.ND);
		h.put(CorbeilleInfoConstantes.NDPLP, TacheEnCoursJDBCFields.NDPLP);
		h.put(CorbeilleInfoConstantes.NUMERO_CLIP, TacheEnCoursJDBCFields.NUMERO_CLIP);
		h.put(CorbeilleInfoConstantes.TACHE, TacheEnCoursJDBCFields.TACHE);
		h.put(CorbeilleInfoConstantes.CAUSE_EVENEMENT, TacheEnCoursJDBCFields.CAUSE);
		h.put(CorbeilleInfoConstantes.CAUSE_EVENEMENT_INIT, TacheEnCoursJDBCFields.CAUSE_INIT);
		h.put(CorbeilleInfoConstantes.DATE_SOUHAITEE, TacheEnCoursJDBCFields.DATE_SOUHAITEE);
		h.put(CorbeilleInfoConstantes.DATE_CONTRACTUELLE_COMMANDE, TacheEnCoursJDBCFields.DATE_CONTRACTUELLE);
		h.put(CorbeilleInfoConstantes.DATE_CREATION_COMMANDE, TacheEnCoursJDBCFields.DATE_CREATION_COMMANDE);
		// EV-000014 Ajout d'un nouveau filtre dans la liste des filtres possibles
		h.put(CorbeilleInfoConstantes.DATE_RDV, TacheEnCoursJDBCFields.DATE_RDV);
		h.put(CorbeilleInfoConstantes.GROUPE_OFFRE, TacheEnCoursJDBCFields.GROUPE_OFFRE);
		h.put(CorbeilleInfoConstantes.FAMILLE_OFFRE, TacheEnCoursJDBCFields.FAMILLE_OFFRE);
		h.put(CorbeilleInfoConstantes.DEBUT_AU_PLUS_TOT, TacheEnCoursJDBCFields.DATE_DEBUT_AU_PLUS_TOT);
		h.put(CorbeilleInfoConstantes.REPARTITEUR, TacheEnCoursJDBCFields.REPARTITEUR);
		h.put(CorbeilleInfoConstantes.ZONE_GEOGRAPHIQUE, TacheEnCoursJDBCFields.ZONE_GEOGRAPHIQUE);
		h.put(CorbeilleInfoConstantes.ZONE_SI, TacheEnCoursJDBCFields.ZONE_SI);
		h.put(CorbeilleInfoConstantes.ID_COMMANDE, TacheEnCoursJDBCFields.ID_COMMANDE);
		h.put(CorbeilleInfoConstantes.JALON, TacheEnCoursJDBCFields.JALON);
		h.put(CorbeilleInfoConstantes.ROLE, TacheEnCoursJDBCFields.ROLE);
		h.put(CorbeilleInfoConstantes.TRAITE_PAR, TacheEnCoursJDBCFields.TRAITE_PAR);
		h.put(CorbeilleInfoConstantes.NOM_VENDEUR, TacheEnCoursJDBCFields.NOM_VENDEUR);
		h.put(CorbeilleInfoConstantes.REF_CLIENT_CONTRACTANT, TacheEnCoursJDBCFields.REF_CLIENT_CONTRACTANT);
		h.put(CorbeilleInfoConstantes.NOM_CONTRACTANT, TacheEnCoursJDBCFields.NOM_CONTRACTANT);
		h.put(CorbeilleInfoConstantes.PRENOM_CONTRACTANT, TacheEnCoursJDBCFields.PRENOM_CONTRACTANT);
		h.put(CorbeilleInfoConstantes.CATEGORIE_CONTRACTANT, TacheEnCoursJDBCFields.CATEGORIE_CLIENT_CONTRACTANT);
		h.put(CorbeilleInfoConstantes.NOM_CLIENT_LIVRE, TacheEnCoursJDBCFields.NOM_CLIENT_LIVRE);
		h.put(CorbeilleInfoConstantes.CATEGORIE_CLIENT_LIVRE, TacheEnCoursJDBCFields.CATEGORIE_CLIENT_LIVRE);
		h.put(CorbeilleInfoConstantes.DSLAM, TacheEnCoursJDBCFields.DSLAM);
		h.put(CorbeilleInfoConstantes.ANCIEN_DSLAM, TacheEnCoursJDBCFields.ANCIEN_DSLAM);
		h.put(CorbeilleInfoConstantes.DATE_PREMIERE_EXECUTION, TacheEnCoursJDBCFields.DATE_PREMIERE_EXECUTION);
		h.put(CorbeilleInfoConstantes.DATE_MAX_EXECUTION, TacheEnCoursJDBCFields.DATE_MAX_EXECUTION);
		h.put(CorbeilleInfoConstantes.DATE_PROGRAMMATION, TacheEnCoursJDBCFields.DATE_PROGRAMMATION);
		h.put(CorbeilleInfoConstantes.DATE_VALIDATION_FO, TacheEnCoursJDBCFields.DATE_VALIDATION_FO);
		h.put(CorbeilleInfoConstantes.NOMBRE_REJEUX, TacheEnCoursJDBCFields.NB_REJEUX);
		h.put(CorbeilleInfoConstantes.REFEXTERNE_COMMANDE, TacheEnCoursJDBCFields.REF_EXTERNE);
		h.put(CorbeilleInfoConstantes.STATUT_COMMANDE, TacheEnCoursJDBCFields.STATUT_COMMANDE);
		h.put(CorbeilleInfoConstantes.TYPE_EVENEMENT, TacheEnCoursJDBCFields.TYPE_EVENEMENT);
		h.put(CorbeilleInfoConstantes.VERSION_BOLBEC, TacheEnCoursJDBCFields.VERSION_BOLBEC);
		h.put(CorbeilleInfoConstantes.DIFFEREE, TacheEnCoursJDBCFields.DATE_DEBUT_AU_PLUS_TOT);
		h.put(CorbeilleInfoConstantes.EN_COURS, TacheEnCoursJDBCFields.DATE_DEBUT_AU_PLUS_TOT);
		h.put(CorbeilleInfoConstantes.LIGNES_COMMANDE, TacheEnCoursJDBCFields.LIGNE_COMMMANDE_INFOS);
		h.put(CorbeilleInfoConstantes.INTERFERE, TacheEnCoursJDBCFields.INTERFERE);
		h.put(CorbeilleInfoConstantes.INTERFERE_DATE_FIN, TacheEnCoursJDBCFields.INTERFERE_DATE_FIN);
		h.put(CorbeilleInfoConstantes.REGIME_SAV, TacheEnCoursJDBCFields.VALEUR_DYNAMICPSSOUHAITE);
		// EV-317 Ajout de libelle et code erreur IPON
		h.put(CorbeilleInfoConstantes.LIBELLE_ERREUR_IPON, TacheEnCoursJDBCFields.LIBELLE_ERREUR_IPON);
		// EV-348_09
		h.put(CorbeilleInfoConstantes.CONTEXTE_LIVRAISON, TacheEnCoursJDBCFields.VALEUR_DYNAMICCOMMANDE);

		// US-674: champs manquants
		h.put(CorbeilleInfoConstantes.EPC_ID_VIA, TacheEnCoursJDBCFields.EPCidVIA);
		h.put(CorbeilleInfoConstantes.ID_EVENEMENT, TacheEnCoursJDBCFields.ID_EVT);
		h.put(CorbeilleInfoConstantes.ID_CAUSE_EVT, TacheEnCoursJDBCFields.CAUSEEVT);
		h.put(CorbeilleInfoConstantes.RESSOURCES_TECHNIQUES, TacheEnCoursJDBCFields.RESSOURCES_TECHNIQUES_INFOS);
		h.put(CorbeilleInfoConstantes.EDSI, TacheEnCoursJDBCFields.EDSI);
		h.put(CorbeilleInfoConstantes.INTERVENTIONS, TacheEnCoursJDBCFields.INTERVENTIONS_INFOS);
		h.put(CorbeilleInfoConstantes.DATE_CONTRACTUELLE_EPC_SUPPORT, TacheEnCoursJDBCFields.DATE_CONTRACTUELLE_EPC_SUPPORT);
		h.put(CorbeilleInfoConstantes.DEBUT_REEL, TacheEnCoursJDBCFields.DEBUT_REEL);
		h.put(CorbeilleInfoConstantes.TRAITEMENT, TacheEnCoursJDBCFields.TRAITEMENT);
		h.put(CorbeilleInfoConstantes.DEBUT_AU_PLUS_TARD,TacheEnCoursJDBCFields.DATE_DEBUT_AU_PLUS_TARD);
		h.put(CorbeilleInfoConstantes.FIN_AU_PLUS_TARD,TacheEnCoursJDBCFields.DATE_FIN_AU_PLUS_TARD);

		// US-674: Traitement en cours
		h.put(CorbeilleInfoConstantes.IS_TRAITEMENT_EN_COURS,TacheEnCoursJDBCFields.IS_TRAITEMENT_EN_COURS);

		h.put(CorbeilleInfoConstantes.LAST_NOTE, TacheEnCoursJDBCFields.DERNIERE_NOTE);

		filters = Collections.unmodifiableMap(h);
		// On cr�� une map de traduction invers�e
		// TODO OLD: cr�er des constantes CorbeilleConstantes et y faire appel ICI
		// et dans CorbeilleInfo.
		Map<String, String> r = new HashMap<String, String>();
		r.put(TacheEnCoursJDBCFields.ND, Constantes.RS_ND);
		r.put(TacheEnCoursJDBCFields.NDPLP, Constantes.RS_NDPLP);
		r.put(TacheEnCoursJDBCFields.NUMERO_CLIP, Constantes.RS_NUMERO_CLIP);
		r.put(TacheEnCoursJDBCFields.TACHE, WorkflowConstantes.LIBELLE);
		r.put(TacheEnCoursJDBCFields.CAUSE, Constantes.RS_LIBCAUSEEVT);
		r.put(TacheEnCoursJDBCFields.CAUSE_INIT, Constantes.RS_LIBCAUSEEVTINIT);
		r.put(TacheEnCoursJDBCFields.DATE_SOUHAITEE, Constantes.RS_DATE_ORDONNANCEMENT);
		r.put(TacheEnCoursJDBCFields.DATE_CONTRACTUELLE, Constantes.RS_DATE_CONTRACTUELLE);
		// EV-000014: Ajout du filtre dans la table de traduction inverse
		r.put(TacheEnCoursJDBCFields.DATE_RDV, Constantes.RS_DATE_RDV);
		r.put(TacheEnCoursJDBCFields.GROUPE_OFFRE, Constantes.RS_OFFRE_GROUPEE);
		r.put(TacheEnCoursJDBCFields.FAMILLE_OFFRE, Constantes.RS_FAMILLE_OFFRE);
		r.put(TacheEnCoursJDBCFields.LIGNE_COMMMANDE_INFOS, Constantes.RS_LIGNES_CMD_INFOS);
		r.put(TacheEnCoursJDBCFields.DATE_DEBUT_AU_PLUS_TOT, WorkflowConstantes.DEBUT_AU_PLUS_TOT);
		r.put(TacheEnCoursJDBCFields.REPARTITEUR, Constantes.RS_REPARTITEUR);
		r.put(TacheEnCoursJDBCFields.ZONE_GEOGRAPHIQUE, Constantes.RS_ZONE_GEO);
		r.put(TacheEnCoursJDBCFields.ZONE_SI, Constantes.RS_ZONE_SI);
		r.put(TacheEnCoursJDBCFields.ID_COMMANDE, Constantes.RS_ID_COMMANDE);
		r.put(TacheEnCoursJDBCFields.JALON, Constantes.RS_JALON_ACTUEL);
		r.put(TacheEnCoursJDBCFields.ROLE, Constantes.RS_ROLE_DYNAMIQUE);
		r.put(TacheEnCoursJDBCFields.TRAITE_PAR, WorkflowConstantes.AGENT);
		r.put(TacheEnCoursJDBCFields.NOM_VENDEUR, Constantes.RS_NOM_VENDEUR);
		r.put(TacheEnCoursJDBCFields.REF_CLIENT_CONTRACTANT, Constantes.RS_ID_CLIENT_CONTRACTANT);
		r.put(TacheEnCoursJDBCFields.NOM_CONTRACTANT, Constantes.RS_DENOMINATION_CONTRACTANT);
		r.put(TacheEnCoursJDBCFields.PRENOM_CONTRACTANT, Constantes.RS_PRENOM_CONTRACTANT);
		r.put(TacheEnCoursJDBCFields.CATEGORIE_CLIENT_CONTRACTANT, Constantes.RS_CATEGORIE_CONTRACTANT);
		r.put(TacheEnCoursJDBCFields.NOM_CLIENT_LIVRE, Constantes.RS_DENOMINATION_LIVRE);
		r.put(TacheEnCoursJDBCFields.CATEGORIE_CLIENT_LIVRE, Constantes.RS_CATEGORIE_LIVRE);
		r.put(TacheEnCoursJDBCFields.DSLAM, Constantes.RS_DSLAM);
		r.put(TacheEnCoursJDBCFields.ANCIEN_DSLAM, Constantes.RS_ANC_DSLAM);
		r.put(TacheEnCoursJDBCFields.DATE_PREMIERE_EXECUTION, WorkflowConstantes.DATE_PREMIERE_EXECUTION);
		r.put(TacheEnCoursJDBCFields.DATE_MAX_EXECUTION, WorkflowConstantes.DATE_MAX_EXECUTION);
		r.put(TacheEnCoursJDBCFields.DATE_PROGRAMMATION, Constantes.RS_DATE_PROGRAMMATION);
		r.put(TacheEnCoursJDBCFields.DATE_VALIDATION_FO, Constantes.RS_DATEVALIDATIONFO);
		r.put(TacheEnCoursJDBCFields.NB_REJEUX, Constantes.RS_NBRE_REJEUX);
		r.put(TacheEnCoursJDBCFields.REF_EXTERNE, Constantes.RS_REFEXTERNE_COMMANDE);
		r.put(TacheEnCoursJDBCFields.STATUT_COMMANDE, Constantes.RS_STATUT_COMMANDE);
		r.put(TacheEnCoursJDBCFields.TYPE_EVENEMENT, Constantes.RS_TYPE_EVT);
		r.put(TacheEnCoursJDBCFields.VERSION_BOLBEC, Constantes.RS_VERSION_BOLBEC);
		r.put(TacheEnCoursJDBCFields.INTERFERE, Constantes.RS_INTERFERE);
		r.put(TacheEnCoursJDBCFields.INTERFERE_DATE_FIN, Constantes.RS_INTERFERE_DATE_FIN);
		r.put(TacheEnCoursJDBCFields.VALEUR_DYNAMICPSSOUHAITE, Constantes.RS_CODE_REGIME);
		// EV-317 Ajout de libelle et code erreur IPON
		r.put(TacheEnCoursJDBCFields.LIBELLE_ERREUR_IPON, Constantes.RS_LIBELLE_ERREUR_IPON);
		// EV-348_09
		r.put(TacheEnCoursJDBCFields.VALEUR_DYNAMICCOMMANDE, Constantes.RS_CONTEXTE_LIV);

		// US-674: champs manquants
		r.put(TacheEnCoursJDBCFields.EPCidVIA, Constantes.RS_EPC_ID_VIA);
		r.put(TacheEnCoursJDBCFields.ID_EVT, Constantes.RS_IDEVT);
		r.put(TacheEnCoursJDBCFields.CAUSEEVT, Constantes.RS_IDCAUSEEVT);
		r.put(TacheEnCoursJDBCFields.RESSOURCES_TECHNIQUES_INFOS, Constantes.RS_RESSOURCES_TECHNIQUES_INFOS);
		r.put(TacheEnCoursJDBCFields.EDSI, Constantes.RS_EDS_INSTALL);
		r.put(TacheEnCoursJDBCFields.INTERVENTIONS_INFOS, Constantes.RS_INTERVENTIONS_INFOS);
		r.put(TacheEnCoursJDBCFields.DATE_CONTRACTUELLE_EPC_SUPPORT, Constantes.RS_DATE_CONTRACTUELLE_EPCSUP);
		r.put(TacheEnCoursJDBCFields.DEBUT_REEL, WorkflowConstantes.DEBUT_REEL);
		r.put(TacheEnCoursJDBCFields.TRAITEMENT, WorkflowConstantes.NOM_TRAITEMENT);
		r.put(TacheEnCoursJDBCFields.DATE_DEBUT_AU_PLUS_TARD,WorkflowConstantes.DEBUT_AU_PLUS_TARD);
		r.put(TacheEnCoursJDBCFields.DATE_FIN_AU_PLUS_TARD,WorkflowConstantes.FIN_AU_PLUS_TARD);

		// US-674: Traitement en cours
		r.put(TacheEnCoursJDBCFields.IS_TRAITEMENT_EN_COURS,Constantes.IS_TRAITEMENT_EN_COURS);

		r.put(TacheEnCoursJDBCFields.DERNIERE_NOTE, Constantes.RS_WF_LAST_NOTE);

		reverseFilters = Collections.unmodifiableMap(r);
	}

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static JDBCCorbeilleTranslator getInstance() {
		if (instance == null) {
			instance = new JDBCCorbeilleTranslator();
		}
		return instance;
	}

	private JDBCCorbeilleTranslator() {
		// pour �viter instanciation inutile
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleTranslator#translate(java.lang.String)
	 */
	public Object translate(String criterion) {
		JDBCField field = null;
		String fieldId = filters.get(criterion);
		if (fieldId != null) {
			field = TacheEnCoursJDBCFields.get(fieldId);
		}
		return field;
	}

	/**
	 * Renvoie l'identifiant CorbeilleInfo pour le champ JDBC retourn�
	 * 
	 * @param fieldId
	 * @return l'identifiant CorbeilleInfo pour le champ JDBC retourn�
	 */
	public String translateField(String fieldId) {
		return reverseFilters.get(fieldId);
	}
}
