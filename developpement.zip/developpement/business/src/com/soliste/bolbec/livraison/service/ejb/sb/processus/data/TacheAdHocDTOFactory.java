/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusTypeDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * </TABLE><BR>
 */

/**
 * Factory pour TacheAdHocDTO
 * 
 * @author rgvs7490
 */
public class TacheAdHocDTOFactory {

	private TacheAdHocDTOFactory() {
		//
	}

	/**
	 * 
	 * @param tacheAdHoc
	 * @return
	 */
	public static TacheAdHocDTO create(TacheDTO tacheAdHoc) {
		TacheAdHocDTO dto = new TacheAdHocDTO();

		dto.setTache(tacheAdHoc);
		ProcessusDTO sp = tacheAdHoc.getLancerParProcessus();
		ProcessusTypeDTO procTypeComplet = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(ProcessusTypeDTO.class, sp.getProcessusType().getId());
		sp.setProcessusType(procTypeComplet);
		dto.setSousProcessus(sp);
		TacheDTO phase = SousProcessusDTOFactory.getPhaseFromTache(tacheAdHoc.getId());
		dto.setPhase(phase);
		dto.setPapaProcessus(phase.getLancerParProcessus());
		List<TacheDTO> tacheList = ServiceManager.getInstance().getProcessusManager().findTacheByLanceParProcessus(dto.getPapaProcessus().getId());
		TacheDTO tacheGroupee = null;
		List<TacheDTO> tachesGroupees = new ArrayList<TacheDTO>();
		// Tri de la liste par TimestampCreation
		Collections.sort(tacheList);
		for (TacheDTO tacheDTO : tacheList) {
			if (tacheDTO.getId().equals(tacheAdHoc.getId())) {
				//On ajoute � la liste de taches la tache � afficher et on initialise la tache group�e pour ajouter aussi la suivante du groupe
				tachesGroupees.add(tacheDTO);
				tacheGroupee = tacheDTO;
			} else if (tacheGroupee != null && tacheGroupee.getLibelleIHM().equals(tacheDTO.getLibelleIHM())) {
				tachesGroupees.add(tacheDTO);
				break;
			}
		}

		chargerCauseEvenementEtAgentComplets(tachesGroupees);

		return dto;
	}

	private static void chargerCauseEvenementEtAgentComplets (List<TacheDTO> tacheLst) {
		for (TacheDTO tache : tacheLst) {
			List<EvtDTO> evtDTOs = ServiceManager.getInstance().getProcessusManager().findEvtByTache(tache.getId());
			for (EvtDTO evt : evtDTOs) {
				CauseEvenementDTO causeEvtComplete = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseEvenement().getId());
				evt.setCauseEvenement(causeEvtComplete);
				AgentDTO agentComplet = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(AgentDTO.class, evt.getAPourOrigineAgent().getId());
				evt.setAPourOrigineAgent(agentComplet);
			}
		}
	}
}
