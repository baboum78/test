/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.List;
import java.util.Map;

import com.soliste.bolbec.livraison.service.ejb.sb.commun.data.KeyPair;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 *
 * @author edba8262
 */
public class CloturerTacheManuelleDecrochageCommande extends CloturerTacheManuelleCommande {

	private Map<String, List<KeyPair>> qtsByInstanceRT;

	/**
	 * 
	 * @param tacheId
	 * @param itemData
	 * @param qtsByInstanceRT
	 */
	public CloturerTacheManuelleDecrochageCommande(String tacheId, WfItemData itemData, Map<String, List<KeyPair>> qtsByInstanceRT) {
		super(tacheId, itemData);
		this.qtsByInstanceRT = qtsByInstanceRT;
	}

	/**
	 * Retourne l'ensemble des QTs, rang�s par instanceRT. La Map contient,
	 * en cl�s, les IDs des instancesRT. En valeurs, pour chaque instanceRT, on y trouve une liste d'instances de bolbec.ihm.common.data.KeyPair.
	 * La cl� de la KeyPair est l'identifiant r�el du QT, et la valeur de la KeyPair est
	 * la nouvelle valeur pour ce QT.
	 */
	public Map<String, List<KeyPair>> getQtsByInstanceRT() {
		return this.qtsByInstanceRT;
	}
}
