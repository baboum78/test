/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  :
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.avp;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.CreateException;
import javax.ejb.EJBException;
import javax.ejb.SessionContext;
import javax.jms.JMSException;
import javax.jms.ObjectMessage;
import javax.jms.QueueConnection;
import javax.jms.QueueSender;
import javax.jms.QueueSession;
import javax.naming.NamingException;

import org.apache.commons.lang3.StringUtils;

import com.soliste.aps.workflow.WfActivity;
import com.soliste.aps.workflow.WfException;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.commun.service.model.AgentDTO;
import com.soliste.bolbec.commun.service.model.RoleDTO;
import com.soliste.bolbec.commun.service.util.jms.QueueHelper;
import com.soliste.bolbec.fwk.ejb.FwkSessionBean;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.fwk.util.DateUtils;
import com.soliste.bolbec.fwk.util.PropertiesUtils;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.anomalies.Evenement;
import com.soliste.bolbec.livraison.service.anomalies.SFAno;
import com.soliste.bolbec.livraison.service.ejb.sb.RessourceTechniqueManager;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpActivCommutCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpAffBLOImmNonTrouve;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpAffTHDCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpAffectationXdslCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCompComCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpControleAffCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCorrectionAdresseCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpCtrlCoherenceCmdCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpMajParcMaterielCommande;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.data.CloturerAvpOpeImbAbs;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.CloturerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.DiffererAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.ReassignerAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.avp.exception.RerouterAvpException;
import com.soliste.bolbec.livraison.service.ejb.sb.commun.data.KeyPair;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.WfItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.ProcessusTraitement;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;
import com.soliste.bolbec.livraison.service.enumeration.CochisePharaonIndicateurActionEnum;
import com.soliste.bolbec.livraison.service.enumeration.EventTypeVadorEnum;
import com.soliste.bolbec.livraison.service.exception.CancelException;
import com.soliste.bolbec.livraison.service.exception.DoneException;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesblo.ConstantesIPON;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.CatalogueTacheDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RessourceTechDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicInstanceRT;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory;
import com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory.Action;
import com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory.GroupeCodeCR;
import com.soliste.bolbec.livraison.service.publication.GestionnairePublication;
import com.soliste.bolbec.livraison.service.publication.Notification;
import com.soliste.bolbec.livraison.service.publication.NotificationGenerique;
import com.soliste.bolbec.livraison.service.publication.NotificationGeneriqueConstantes;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ServiceManager;
import com.soliste.bolbec.livraison.service.util.VersionArtemisUtil;

import aps.AnomalieConstantes;
import aps.CasMetierConstantes;
import aps.CategorieEvenementConstantes;
import aps.CauseEvenementConstantes;
import aps.MessagesConstantes;
import aps.PublicationConstantes;
import aps.TypeOpPonctuellesConstantes;
import aps.TypeRTConstantes;

/**
 * Impl�mentation de l'EJB session <code>AvpManager</code>.
 *
 * @see {@link com.soliste.bolbec.livraison.service.ejb.sb.avp.AvpManager}
 *
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>14/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
 * <TR><TD>20/08/2010</TD><TD>YTR</TD><TD>EV-000053 : creation classe</TD></TR>
 * <TR><TD>12/01/2011</TD><TD>GPE</TD><TD>IRMA923 : correction de la m�thode cloturerAvpAffTHD (sauvegarde en base des ressources techniques modifi�es)</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * <TR><TD>19/09/2011</TD><TD>GPA</TD><TD>EV-000140: Remont�e des AVPs � suivi commande</TD></TR>
 * <TR><TD>18/12/2012</TD><TD>BPE</TD><TD>DE-000692 : Objets Pharaon non instanci�s par le conteneur EJB</TD></TR>
 * <TR><TD>25/04/2013</TD><TD>GPA</TD><TD>G8R2C2 : Suppression du doublon sur le MG_ClotureTache</TD></TR>
 * <TR><TD>31/05/2013</TD><TD>BPE</TD><TD>DE-000846 : Refactoring</TD></TR>
 * <TR><TD>13/06/2013</TD><TD>EBA</TD><TD>G8R2C2 : Refactoring, utilisation de l'attribut serviceManager au lieu de le r�cup�rer � chaque fois</TD></TR>
 * <TR><TD>16/12/2013</TD><TD>BPE</TD><TD>G9R0C1 : Refactoring FWK</TD></TR>
 * <TR><TD>14/08/2014</TD><TD>BPE</TD><TD>EV-000303 : G8R2C5 - Publication Cochise Pharaon</TD></TR>
 * <TR><TD>06/03/2017</TD><TD>JDE</TD><TD>G9R2C1 : Ajout de la m�thode de publication de CR EFB (notamment pour les t�ches manuelles)</TD></TR>
 * <TR><TD>15/05/2018</TD><TD>AJO</TD><TD>G9R2C1 : QC974 Vador</TD></TR>
 * <TR><TD>06/07/2018</TD><TD>AJO</TD><TD>G9R7C0 : QC980 Intrants FTTH</TD></TR>
 * <TR><TD>08/10/2018</TD><TD>AJO</TD><TD>QC-1025 Filtre AVP robot</TD></TR>
 * </TABLE>
 *
 * <BR><B>REQUIREMENTS:</B>
 * <TABLE frame='border'><TR><TD>REQNumber</TD><TD>Exigence Produit impact�e</TD></TR>
 * <TR><TD>REQ.1328</TD><TD>EP048 - Identifier les t�ches candidates � la publication</TD></TR>
 * <TR><TD>REQ.1329</TD><TD>EP049 - Utiliser le m�canisme existant de publication des CR</TD></TR>
 * <TR><TD>REQ.1330</TD><TD>EP050 - Envoyer un message � chaque action sur une t�che candidate � la publication</TD></TR>
 * <TR><TD>EP0311</TD><TD>EP0311 - D�clencher des �v�nememnts sp�cifiques sur certaines �tapes d'avancement du process Artemis</TD></TR>
 * </TABLE>
 */
public class AvpManagerBean extends FwkSessionBean implements AvpManager {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -5716563577217313832L;

	/** The Constant CLASSNAME. */
	private static final String CLASSNAME = AvpManagerBean.class.getName();

	private static final String PUBLICATION_QUEUE_CONNECTION_FACTORY_NAME = "jms/publicationQueueConnectionFactory";
	private static final String PUBLICATION_QUEUE_NAME = PropertiesUtils.getConfig(Constantes.BOLBEC_PROP_FILE).getString("GestionnairePubQueueJndiName", "queue.GestionnairePub").trim();

	private static final String DEPASSEMENT_DUREE_TACHE = "DEPASSEMENT_DUREE_TACHE";
	private static final String NBRE_MAX_REPET_ATTEINT = "NBRE_MAX_REPET_ATTEINT";
	private static final String TIME_OUT_NBRE_REJEUX = "NBRE_REJEUX_MAX_ATTEINT";

	private static final String STRING_0 = "0";
	private static final String STRING_COMMENTAIRE = ", commentaire : ";
	private static final String STRING_PAR = " par ";
	private static final String STRING_REASSIGNE_AU_ROLE = "R�assign� au r�le ";
	private static final String STRING_REROUTE_VERS_ZONE_GEO = "Rerout� vers la zone ";
	private static final String STRING_SPACE = " ";
	// Publications sur AVP vers Vador
	private static final String PUB_AVP_VAO = "PUB_VADOR";

	/** The Service Manager */
	private static final IServiceManager serviceManager = ServiceManager.getInstance();
	private SessionContext sessionContext;
	private QueueHelper publicationQueueHelper;

	/**
	 * @see com.soliste.bolbec.fwk.ejb.FwkSessionBean#setSessionContext(javax.ejb.SessionContext)
	 */
	@Override
	public void setSessionContext(SessionContext sessionContext) {
		this.sessionContext = sessionContext;
		publicationQueueHelper = new QueueHelper(PUBLICATION_QUEUE_CONNECTION_FACTORY_NAME, PUBLICATION_QUEUE_NAME, true);
	}

	/*
	 * (non-Javadoc)
	 *
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.avp.AvpManager#publierCrEfb(com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory.GroupeCodeCR, java.lang.String,
	 * com.soliste.bolbec.livraison.service.publication.EfbNotificationFactory.Action, java.lang.String)
	 */
	public void publierCrEfb(GroupeCodeCR groupeCodeCR, String idTacheEnCours, Action actionIHM, String idEvt) {
		EfbNotificationFactory.envoyerCr(groupeCodeCR, idTacheEnCours, actionIHM, idEvt);
	}

	// --------------------------------------------------------------
	// OPERATIONS SUR AVP
	// --------------------------------------------------------------

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.avp.AvpManager#cloturerAvp(CloturerAvpCommande, WfUser)
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>14/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * <TR><TD>19/09/2010</TD><TD>GPA</TD><TD>EV-000140: Publication vers l�application EFB</TD></TR>
	 * </TABLE>
	 */
	public void cloturerAvp(CloturerAvpCommande commande, WfUser wfUser) throws CloturerAvpException {
		final String methode = "cloturerAvp";
		Evenement evenement = ProcessusTraitement.createEvenement(commande.getCauseEvenementId(), commande.getInfo(), commande.getDate(), wfUser.getId(), null);
		TacheDTO tache = serviceManager.getProcessusManager().getTache(commande.getTacheId());
		ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(commande.getTacheId());
		if (commande instanceof CloturerAvpAffectationXdslCommande) {
			cloturerAvpAffectationXdsl((CloturerAvpAffectationXdslCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpCompComCommande) {
			cloturerAvpCompCom((CloturerAvpCompComCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpControleAffCommande) {
			cloturerAvpControleAff((CloturerAvpControleAffCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpMajParcMaterielCommande) {
			cloturerAvpMajParcMateriel((CloturerAvpMajParcMaterielCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpCorrectionAdresseCommande) {
			cloturerAvpCorrectionAdresse((CloturerAvpCorrectionAdresseCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpActivCommutCommande) {
			cloturerAvpActivCommut((CloturerAvpActivCommutCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpAffTHDCommande) {
			cloturerAvpAffTHD((CloturerAvpAffTHDCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpCtrlCoherenceCmdCommande) {
			cloturerAvpCtrlCoherenceCmd((CloturerAvpCtrlCoherenceCmdCommande) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpOpeImbAbs) {
			cloturerAvpOpeImbAbs((CloturerAvpOpeImbAbs) commande, papaProcessus.getId());
		} else if (commande instanceof CloturerAvpAffBLOImmNonTrouve) {
			cloturerAvpAffBLOImmNonTrouve((CloturerAvpAffBLOImmNonTrouve) commande, papaProcessus.getId());
		}
		WfItemData wfTache = commande.getTache();
		try {
			String nomTraitement = wfTache.getValue(WorkflowConstantes.NOM_TRAITEMENT);
			try {
				analyserEvenementAvp(tache, evenement, wfTache.getValues(), wfTache.getStaticAttributes(), nomTraitement);
			} catch (DoneException e) {
				serviceManager.getLoggerManager().finest(CLASSNAME, methode, String.format("%s lors de l'appel � analyserEvenementAvp", e.getClass().getName()));
			} catch (CancelException e) {
				sessionContext.setRollbackOnly();
				throw new CloturerAvpException();
			}
			TacheEnCoursDTO tec = serviceManager.getProcessusManager().getTacheEnCours(tache.getId());
			Notification notification = serviceManager.getCochisePharaonManager().creerNotification(PublicationConstantes.PUB_COCHISE_PHARAON_CLOTURE, tec, evenement.getId(), CochisePharaonIndicateurActionEnum.SUPPRESSION, "", "");
			if (notification != null) {
				serviceManager.getCochisePharaonManager().publierMessage(notification);
			}

			// RG 10: Publication vers l�application EFB
			publierCrEfb(EfbNotificationFactory.GroupeCodeCR.GROUPE_CODE_300, tache.getId(), EfbNotificationFactory.Action.CLOTURER, evenement.getId());

			// RG 16 : Publication vers Vador
			CommandeDTO commandeDto = serviceManager.getCommandeManager().getCommande(commande.getTache().getCommandeID());
			if (commandeDto.getCasMetier() != null && CasMetierConstantes.VENTE_FTTH.equals(commandeDto.getCasMetier().getId())) {
				CatalogueTacheDTO catalogueTache = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tache.getCatalogueTache().getId());
				String traduction = catalogueTache.getValeurConstante();
				if (traduction != null) {
					Notification notificationVador = new Notification(PUB_AVP_VAO, papaProcessus.getId(), evenement.getId());
					notificationVador.setIdTache(tache.getId());
					notificationVador.getDynParam().put(EventTypeVadorEnum.CLOTURE.toString(), Constantes.CST_OUI);
					notificationVador.setTacheEnCours(tec);
					GestionnairePublication.publierFromEJB(notificationVador);
				}
			}

			serviceManager.getTacheManager().cloturerTache(tache, wfTache.getValues(), true, false, false, wfUser);
			serviceManager.getWorkflowManager().cloturer(wfTache.getWfObject(), wfTache.getValues());

		} catch (DataException e) {
			throw new EJBException(e);
		}

	}
	
	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.avp.AvpManager#differerAvp(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.util.Date, com.soliste.aps.workflow.WfActivity)
	 *
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'><TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>19/09/2011</TD><TD>GPA</TD><TD>EV-000140: RG 5 - Publication vers l�application EFB</TD></TR>
	 * </TABLE>
	 */
	public void differerAvp(String tacheId, String info, String causeEvenementId, String idCurrentAgent, Date date, WfActivity wfActivity) throws DiffererAvpException {
		final String methode = "differerAvp";
		Evenement evenement = ProcessusTraitement.createEvenement(causeEvenementId, info, date, idCurrentAgent, null);

		// EV-303
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByTache(tacheId);
		commande.getDynamicCommandes().put(ConstantesDynamicCommande.DATE_FIN_DIFFERE, DateUtils.format(date, Constantes.FORMAT_DATE_PUB_COCHISE_PHARAON));
		serviceManager.getCommandeManager().updateDynamicCommande(commande);

		TacheDTO tache = serviceManager.getProcessusManager().getTache(tacheId);
		TacheEnCoursDTO tec = serviceManager.getProcessusManager().getTacheEnCours(tacheId);

		try {
			Map<String, String> proprietesWorkflow = wfActivity.getValues();
			Map<String, List<String>> staticWfAttributes = wfActivity.getStaticAttributes();
			String nomTraitement = proprietesWorkflow.get(WorkflowConstantes.NOM_TRAITEMENT);
			analyserEvenementAvp(tache, evenement, proprietesWorkflow, staticWfAttributes, nomTraitement);
		} catch (DoneException e) {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, String.format("%s lors de l'appel � analyserEvenementAvp", e.getClass().getName()));
		} catch (CancelException e) {
			sessionContext.setRollbackOnly();
			throw new DiffererAvpException();
		} catch (WfException e) {
			throw new EJBException(e);
		}
		ProcessusDTO processus = tache.getLancerParProcessus();
		String fatherBpFullName = null;
		if (processus.getGenereParProcessus() != null) {
			ProcessusDTO papaProcessus = serviceManager.getProcessusManager().findProcessusByTacheAndPere(tacheId);
			fatherBpFullName = papaProcessus.getBpName();
		}

		serviceManager.getWorkflowManager().differer(wfActivity, fatherBpFullName, processus.getBpName(), DateUtils.getDatabaseDate(date.getTime()).intValue());

		Notification notification = serviceManager.getCochisePharaonManager().creerNotification(PublicationConstantes.PUB_COCHISE_PHARAON_EVT, tec, evenement.getId(), CochisePharaonIndicateurActionEnum.MODIFICATION, "", "");
		if (notification != null) {
			serviceManager.getCochisePharaonManager().publierMessage(notification);
		}
		// RG 5: Publication vers l�application EFB
		publierCrEfb(EfbNotificationFactory.GroupeCodeCR.GROUPE_CODE_200, tache.getId(), EfbNotificationFactory.Action.DIFFERER, evenement.getId());
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>14/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * <TR><TD>19/09/2011</TD><TD>GPA</TD><TD>EV-000140: RG 5 - Publication vers l�application EFB</TD></TR>
	 * </TABLE>
	 *
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.avp.AvpManager#reassignerAvp(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.soliste.aps.workflow.WfActivity,
	 * com.soliste.bolbec.commun.service.model.AgentDTO)
	 */
	public void reassignerAvp(String tacheId, String info, String causeEvenementId, String roleId, String idCurrentAgent, WfActivity wfActivity, AgentDTO agent) throws ReassignerAvpException {
		final String methode = "reassignerAvp";
		Evenement evenement = ProcessusTraitement.createEvenement(causeEvenementId, info, null, idCurrentAgent, null);
		String libelle = getLibelleReassignation(roleId, info, agent);
		evenement.setLibelle(libelle);
		TacheDTO tache = serviceManager.getProcessusManager().getTache(tacheId);

		TacheEnCoursDTO tacheEnCours = serviceManager.getProcessusManager().getTacheEnCours(tacheId);
		// EV303
		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByTache(tacheEnCours.getId());
		final String ancienRole = tacheEnCours.getRole();
		commande.getDynamicCommandes().put(ConstantesDynamicCommande.ANCIEN_ROLE, ancienRole);
		serviceManager.getCommandeManager().updateDynamicCommande(commande);

		try {
			Map<String, String> proprietesWorkflow = wfActivity.getValues();
			Map<String, List<String>> staticWfAttributes = wfActivity.getStaticAttributes();
			String nomTraitement = proprietesWorkflow.get(WorkflowConstantes.NOM_TRAITEMENT);
			analyserEvenementAvp(tache, evenement, proprietesWorkflow, staticWfAttributes, nomTraitement);
		} catch (DoneException e) {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, String.format("%s lors de l'appel � analyserEvenementAvp", e.getClass().getName()));
		} catch (CancelException e) {
			sessionContext.setRollbackOnly();
			throw new ReassignerAvpException();
		} catch (WfException e) {
			throw new EJBException(e);
		}
		tache.setFaitParRole(new RoleDTO(roleId));
		serviceManager.getProcessusManager().updateTacheFaitParRole(tache);
		tacheEnCours.setRole(roleId);
		serviceManager.getProcessusManager().updateTacheEnCoursRole(tacheEnCours);

		ProcessusDTO processus = tache.getLancerParProcessus();
		String fatherBpFullName = null;
		ProcessusDTO papaProcessus = processus;
		while (papaProcessus.getGenereParProcessus() != null) {
			papaProcessus = papaProcessus.getGenereParProcessus();
			fatherBpFullName = papaProcessus.getBpName();
		}
		serviceManager.getWorkflowManager().reassigner(wfActivity, fatherBpFullName, processus.getBpName(), roleId);

		// L'indicateur action sera d�termin� plus tard dans le delegue publication Cochise Pharaon
		final Notification notification = serviceManager.getCochisePharaonManager().creerNotification(PublicationConstantes.PUB_COCHISE_PHARAON_EVT, tacheEnCours, evenement.getId(), CochisePharaonIndicateurActionEnum.SANS_INDICATEUR_ACTION, ancienRole,
				StringUtils.EMPTY);
		if (notification != null) {
			serviceManager.getCochisePharaonManager().publierMessage(notification);
		}

		// RG 5: Publication vers l�application EFB
		publierCrEfb(EfbNotificationFactory.GroupeCodeCR.GROUPE_CODE_200, tache.getId(), EfbNotificationFactory.Action.REASSIGNER, evenement.getId());

		// RG 7 : Publication vers Vador
		if (commande.getCasMetier() != null && CasMetierConstantes.VENTE_FTTH.equals(commande.getCasMetier().getId())) {
			CatalogueTacheDTO catalogueTache = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CatalogueTacheDTO.class, tache.getCatalogueTache().getId());
			String traduction = catalogueTache.getValeurConstante();
			if (traduction != null) {
				Notification notificationVador = new Notification(PUB_AVP_VAO, processus.getId(), evenement.getId());
				notificationVador.setIdTache(tache.getId());
				notificationVador.getDynParam().put(EventTypeVadorEnum.REASSIGNATION.toString(), Constantes.CST_OUI);
				notificationVador.setTacheEnCours(tacheEnCours);
				GestionnairePublication.publierFromEJB(notificationVador);
			}
		}
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>14/04/2010</TD><TD>DBA</TD><TD>EV-000047: Gestion de la publication Pharaon</TD></TR>
	 * <TR><TD>10/05/2010</TD><TD>DBA</TD><TD>EV-000047: Mise en place EjbFactory</TD></TR>
	 * <TR><TD>19/09/2011</TD><TD>GPA</TD><TD>EV-000140: RG 5 - Publication vers l�application EFB</TD></TR>
	 * </TABLE>
	 *
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.avp.AvpManager#rerouterAvp(java.lang.String, java.lang.String, java.lang.String, java.lang.String, com.soliste.aps.workflow.WfActivity,
	 * com.soliste.bolbec.commun.service.model.AgentDTO)
	 */
	public void rerouterAvp(String tacheId, String info, String causeEvenementId, String zoneGeographiqueId, WfActivity wfActivity, AgentDTO agent) throws RerouterAvpException {
		final String methode = "rerouterAvp";
		Evenement evenement = ProcessusTraitement.createEvenement(causeEvenementId, info, null, agent.getId(), null);
		String libelle = getLibelleReroutage(zoneGeographiqueId, info, agent);
		evenement.setLibelle(libelle);
		TacheDTO tache = serviceManager.getProcessusManager().getTache(tacheId);
		TacheEnCoursDTO tacheEnCours = serviceManager.getProcessusManager().getTacheEnCours(tacheId);

		CommandeDTO commande = serviceManager.getCommandeManager().findCommandeByTache(tacheEnCours.getId());
		commande.getDynamicCommandes().put(ConstantesDynamicCommande.ANCIENNE_ZONE_SI, tacheEnCours.getZoneSi());
		serviceManager.getCommandeManager().updateDynamicCommande(commande);

		try {
			Map<String, String> proprietesWorkflow = wfActivity.getValues();
			Map<String, List<String>> staticWfAttributes = wfActivity.getStaticAttributes();
			String nomTraitement = proprietesWorkflow.get(WorkflowConstantes.NOM_TRAITEMENT);
			analyserEvenementAvp(tache, evenement, proprietesWorkflow, staticWfAttributes, nomTraitement);
		} catch (DoneException e) {
			serviceManager.getLoggerManager().finest(CLASSNAME, methode, String.format("%s lors de l'appel � analyserEvenementAvp", e.getClass().getName()));
		} catch (CancelException e) {
			sessionContext.setRollbackOnly();
			throw new RerouterAvpException();
		} catch (WfException e) {
			throw new EJBException(e);
		}
		// MAJ de la tacheEnCours
		tacheEnCours.setZoneGeo(zoneGeographiqueId);
		serviceManager.getProcessusManager().updateTacheEnCoursZoneGeo(tacheEnCours);

		Map<String, String> data = new HashMap<String, String>();
		data.put(Constantes.RS_ZONE_GEO, zoneGeographiqueId);

		serviceManager.getWorkflowManager().rerouter(wfActivity, zoneGeographiqueId);

		Notification notification = serviceManager.getCochisePharaonManager().creerNotification(PublicationConstantes.PUB_COCHISE_PHARAON_EVT, tacheEnCours, evenement.getId(), CochisePharaonIndicateurActionEnum.MODIFICATION, "", "");
		if (notification != null) {
			serviceManager.getCochisePharaonManager().publierMessage(notification);
		}
		// RG 5: Publication vers l�application EFB
		publierCrEfb(EfbNotificationFactory.GroupeCodeCR.GROUPE_CODE_200, tache.getId(), EfbNotificationFactory.Action.REROUTER, evenement.getId());
	}

	private static void cloturerAvpAffectationXdsl(CloturerAvpAffectationXdslCommande commande, String processusId) {
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		for (LigneCommandeDTO lc : lignesCde) {
			PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
			if (psSouhaite != null) {
				addAvpAffectationXdslDynamicFields(psSouhaite, commande);
			}
		}
	}

	private static void cloturerAvpCompCom(CloturerAvpCompComCommande commande, String processusId) {
		Map<String, List<KeyPair>> qtsByLigneCommande = commande.getQtsByLigneCommande();
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		for (LigneCommandeDTO lc : lignesCde) {
			String typeOpPonctuellesId = lc.getTypeOpPonctuelles().getId();
			if (TypeOpPonctuellesConstantes.CR.equals(typeOpPonctuellesId) || TypeOpPonctuellesConstantes.MO.equals(typeOpPonctuellesId)) {
				if (qtsByLigneCommande.containsKey(lc.getId())) {
					PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
					List<KeyPair> qts = qtsByLigneCommande.get(lc.getId());
				}
			} else if (TypeOpPonctuellesConstantes.SU.equals(typeOpPonctuellesId) && qtsByLigneCommande.containsKey(lc.getId())) {
				List<KeyPair> qts = qtsByLigneCommande.get(lc.getId());
			}
		}
	}

	private static void cloturerAvpControleAff(CloturerAvpControleAffCommande commande, String processusId) {
		cloturerAvpAffectationXdsl(commande, processusId);
	}

	private static void cloturerAvpMajParcMateriel(CloturerAvpMajParcMaterielCommande commande, String processusId) {
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		for (LigneCommandeDTO lc : lignesCde) {
			Map<String, String> dynamics = lc.getDynamicLigneCommandes();
			dynamics.put(ConstantesDynamicLigneCommande.LIGNECOMMANDE_USC, commande.getUsc());
			serviceManager.getCommandeManager().updateDynamicLigneCommande(lc);
		}
	}

	private static void cloturerAvpActivCommut(CloturerAvpActivCommutCommande commande, String processusId) {
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		for (LigneCommandeDTO lc : lignesCde) {
			PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
			if (psSouhaite != null) {
				Map<String, String> dynamics = psSouhaite.getDynamicPsSouhaites();
				dynamics.put(ConstantesDynamicPSSouhaite.PSSOUHAITE_Z0BPQ, commande.getZ0bpq());
				serviceManager.getCommandeManager().updateDynamicPsSouhaite(psSouhaite);
			}
		}
	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>12/01/2011</TD><TD>GPE</TD><TD>IRMA923 : sauvegarde en base des ressources techniques modifi�es et optimisation de code</TD></TR>
	 * </TABLE>
	 * Traitement li� � la cloture d'un AVP AffTHD. Mets � jour les ressources technique (idRt) des InstanceRtDTO li�es au processus pass� en param�tre avec commande pass�e en param�tre (oltName, oltShelf, oltCard, oltPort)
	 *
	 * @param commande
	 * la commande clotur�e
	 * @param processusId
	 * le processus impact�
	 */
	private static void cloturerAvpAffTHD(CloturerAvpAffTHDCommande commande, String processusId) {
		List<InstanceRtDTO> instancesRt = ServiceManager.getInstance().getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processusId);
		for (InstanceRtDTO instanceRt : instancesRt) {
			RessourceTechDTO ressourceTech = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, instanceRt.getRessourceTech().getId());
			if (TypeRTConstantes.CSHD_THD.equals(ressourceTech.getTypeRt().getId())) {
				Map<String,String> dynamicRts = instanceRt.getDynamicInstanceRts();
				// Les champs dynamiques � r�cup�rer sont stock�s dans les champs dynamiques de l'instanceRT "CSHD_THD"
				dynamicRts.put(ConstantesIPON.TAG_OLTNAME, commande.getOltName());
				dynamicRts.put(ConstantesIPON.TAG_SHELF, commande.getOltShelf());
				dynamicRts.put(ConstantesIPON.TAG_CARD, commande.getOltCard());
				dynamicRts.put(ConstantesIPON.TAG_PORT, commande.getOltPort());
				serviceManager.getRessourceTechniqueManager().updateDynamicInstanceRts(instanceRt);
				break;
			}
		}

	}

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>06/07/2018</TD><TD>AJO</TD><TD>QC-980 : Intrants FTTH</TD></TR>
	 * </TABLE>
	 * Traitement li� � la cloture d'un AVP ControleCoherenceCommande. Mets � jour les des champs addresse et dynamicPssouhaite/dynamicLigneCommande
	 *
	 * @param commande
	 * la commande clotur�e
	 * @param processusId
	 * le processus impact�
	 */
	private static void cloturerAvpCtrlCoherenceCmd(CloturerAvpCtrlCoherenceCmdCommande commande, String processusId) {
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		ClientDTO clientLivre = lignesCde.get(0).getClient();
		AdresseDTO adresse = clientLivre.getAdresse();
		adresse.setCpltnumVoie(commande.getcpltNumVoie());
		adresse.setNumeroVoie(commande.getNumeroVoie());
		adresse.setBatiment(commande.getBatiment());
		adresse.setEtage(commande.getEtage());
		adresse.setCodeRivoli(commande.getCodeRivoli());
		adresse.setEscalier(commande.getEscalier());
		adresse.setCodeInsee(commande.getCodeInsee());
		serviceManager.getCommandeManager().updateAdresse(adresse);

		for (LigneCommandeDTO lc : lignesCde) {
			PsSouhaiteDTO psSouhaite = serviceManager.getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
			Map<String, String> dynamicLigneCommandes = lc.getDynamicLigneCommandes();
			Map<String, String> dynamicPsSouhaites = null;
			if (psSouhaite != null) {
				dynamicPsSouhaites = psSouhaite.getDynamicPsSouhaites();
			}
			if (dynamicLigneCommandes != null) {
				dynamicLigneCommandes.put(ConstantesDynamicLigneCommande.CLE_CODE_IMMEUBLE, commande.getCodeImmeuble());
				dynamicLigneCommandes.put(ConstantesDynamicLigneCommande.CLE_PRISE_EXISTANTE, commande.getPriseExistante());
				dynamicLigneCommandes.put(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE, commande.getOperateurImmeuble());
				serviceManager.getCommandeManager().updateDynamicLigneCommande(lc);
			}
			if (dynamicPsSouhaites != null) {
				dynamicPsSouhaites.put(ConstantesDynamicPSSouhaite.PTOID, commande.getReferencePrise());
				serviceManager.getCommandeManager().updateDynamicPsSouhaite(psSouhaite);
			}
		}
		CommandeDTO cmd = serviceManager.getCommandeManager().findCommandeByProcessus(processusId);
		Map<String, String> dynamicCommande = cmd.getDynamicCommandes();
		if (dynamicCommande != null) {
			dynamicCommande.put(ConstantesDynamicCommande.CLE_NOMBRE_REJEUX, null);
			serviceManager.getCommandeManager().updateDynamicCommande(cmd);
		}

	}

	private static void cloturerAvpCorrectionAdresse(CloturerAvpCorrectionAdresseCommande commande, String processusId) {
		List<LigneCommandeDTO> lignesCde = serviceManager.getCommandeManager().findLigneCommandeByEstLivreParProcessus(processusId);
		for (LigneCommandeDTO lc : lignesCde) {
			ClientDTO clientLivre = lc.getClient();
			AdresseDTO adresse = clientLivre.getAdresse();
			adresse.setLibelleVoie(commande.getLibelleVoie());
			adresse.setCodeRivoli(commande.getCodeRivoli());
			adresse.setNumeroVoie(commande.getNumeroVoie());
			adresse.setEnsemble(commande.getEnsemble());
			adresse.setBatiment(commande.getBatiment());
			adresse.setEscalier(commande.getEscalier());
			adresse.setEtage(commande.getEtage());
			adresse.setPorte(commande.getPorte());
			adresse.setLogo(commande.getLogo());
			adresse.setCodeInsee(commande.getCodeInsee());
			serviceManager.getCommandeManager().updateAdresse(adresse);
		}
	}

	private static void cloturerAvpOpeImbAbs(CloturerAvpOpeImbAbs commande, String processusId) {
		RessourceTechniqueManager ressourceTechniqueManager = serviceManager.getRessourceTechniqueManager();
		List<InstanceRtDTO> instancesRT = ressourceTechniqueManager.findInstanceRTByLivreParProcessus(processusId);
		for (InstanceRtDTO instanceRT : instancesRT) {
			if (TypeRTConstantes.CBL_THD.equals(instanceRT.getRessourceTech().getId())) {
				instanceRT.getDynamicInstanceRts().put(ConstantesDynamicInstanceRT.INSTANCERT_CBL_THD_OPERATEUR_IMMEUBLE, commande.getOperatorIMB());
				ressourceTechniqueManager.updateDynamicInstanceRts(instanceRT);
				break;
			}
		}
	}

	private static void cloturerAvpAffBLOImmNonTrouve(CloturerAvpAffBLOImmNonTrouve commande, String processusId) {
		RessourceTechniqueManager ressourceTechniqueManager = serviceManager.getRessourceTechniqueManager();
		List<InstanceRtDTO> instancesRT = ressourceTechniqueManager.findInstanceRTByLivreParProcessus(processusId);
		for (InstanceRtDTO instanceRT : instancesRT) {
			if (TypeRTConstantes.CBL_THD.equals(instanceRT.getRessourceTech().getId())) {
				instanceRT.getDynamicInstanceRts().put(ConstantesDynamicInstanceRT.INSTANCERT_CBL_THD_IMB, commande.getCodeImb());
				ressourceTechniqueManager.updateDynamicInstanceRts(instanceRT);
				break;
			}
		}
	}

	private static void addAvpAffectationXdslDynamicFields(PsSouhaiteDTO psSouhaite, CloturerAvpAffectationXdslCommande commande) {
		Map<String, String> dynamics = psSouhaite.getDynamicPsSouhaites();
		if (!StringUtils.isEmpty(commande.getCentre())) {
			dynamics.put(ConstantesDynamicPSSouhaite.PSSOUHAITE_CENTRE_ADSL, commande.getCentre());
		}
		if (!StringUtils.isEmpty(commande.getBroche())) {
			dynamics.put(ConstantesDynamicPSSouhaite.PSSOUHAITE_BROCHE_ADSL, commande.getBroche());
		}
		if (!StringUtils.isEmpty(commande.getReglette())) {
			dynamics.put(ConstantesDynamicPSSouhaite.PSSOUHAITE_REGLETTE_ADSL, commande.getReglette());
		}
		if (!StringUtils.isEmpty(commande.getVcCible())) {
			dynamics.put(ConstantesDynamicPSSouhaite.PSSOUHAITE_VC_FORCE, commande.getVcCible());
		}
		if (!StringUtils.isEmpty(commande.getVcOper())) {
			dynamics.put(ConstantesDynamicPSSouhaite.PSSOUHAITE_VC_FORCE, commande.getVcOper());
		}
		serviceManager.getCommandeManager().updateDynamicPsSouhaite(psSouhaite);
	}

	/**
	 * Ex�cute le traitement "Analyse Evenement AVP"
	 *
	 * @param tache la tache correspondant � l'AVP
	 * @param evenement l'�v�nement � analyser
	 * @param proprietesWorkflow les proprietes workflow
	 * @param staticWorkflowAttributes les attributs statiques du workflow
	 * @param nomTraitement le nom du traitement
	 * @throws DoneException si le traitement a r�ussi
	 * @throws CancelException si le traitement a �chou�
	 */
	private void analyserEvenementAvp(TacheDTO tache, Evenement evenement, Map<String, String> proprietesWorkflow, Map<String, List<String>> staticWorkflowAttributes, String nomTraitement) throws DoneException, CancelException {
		try {
			EvtDTO evt = getOrCreateEvenement(tache, evenement, proprietesWorkflow.get(Constantes.RS_IDCOMMANDE));
			CauseEvenementDTO causeEvenement = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseEvenement().getId());
			TypeEvenementDTO typeEvenement = serviceManager.getReferenceSpaceManager().findInReferenceSpace(TypeEvenementDTO.class, causeEvenement.getTypeEvenement().getId());
			if (Constantes.MODIF_MANUELLE_O.equals(typeEvenement.getModifManuelleEtat())) {
				ProcessusDTO processus = tache.getLancerParProcessus();
				processus.setModifManuelleEtat(Constantes.MODIF_MANUELLE_O);
				serviceManager.getProcessusManager().updateProcessusModifManuelleEtat(processus);
			}
			String categorieEvenementId = typeEvenement.getCategorieEvenement().getId();
			if (CategorieEvenementConstantes.AVP.equals(categorieEvenementId)) {
				analyserEvenementAvpPourCategorieAvp(tache, evt, proprietesWorkflow, categorieEvenementId);
			} else if (CategorieEvenementConstantes.WARBQ.equals(categorieEvenementId)) {
				analyserEvenementAvpPourCategorieWarbq(tache, evt, proprietesWorkflow, staticWorkflowAttributes, nomTraitement);
			} else if (CategorieEvenementConstantes.REPAUTO.equals(categorieEvenementId)) {
				analyserEvenementAvpPourCategorieRepauto(tache, evt, proprietesWorkflow, staticWorkflowAttributes, nomTraitement, categorieEvenementId);
			} else if (CategorieEvenementConstantes.REPASYNC.equals(categorieEvenementId)) {
				analyserEvenementAvpPourCategorieRepasync(evt, proprietesWorkflow, categorieEvenementId);
			}
		} catch (CreateException e) {
			throw new EJBException(e);
		}
	}

	private void analyserEvenementAvpPourCategorieAvp(TacheDTO tache, EvtDTO evt, Map<String, String> proprietesWorkflow, String categorieEvenementId) throws DoneException {
		String lancerParProcessusId = null;
		if (tache.getLancerParProcessus() != null) {
			lancerParProcessusId = tache.getLancerParProcessus().getId();
		}
		Notification notification = new Notification(PublicationConstantes.AVP, lancerParProcessusId, evt.getId(), proprietesWorkflow.get(Constantes.RS_VERSION_BOLBEC));
		publier(notification);
		modifierProprietesWorkflow(proprietesWorkflow, evt, STRING_0, Constantes.VALEUR_VARIANTE_OUI);
		throw new DoneException(categorieEvenementId);
	}

	private static void analyserEvenementAvpPourCategorieRepasync(EvtDTO evt, Map<String, String> proprietesWorkflow, String categorieEvenementId) throws DoneException {
		proprietesWorkflow.put(Constantes.RS_IDEVT, evt.getId());
		// EV 317 mise � jour de libelle et code erreur
		proprietesWorkflow.put(Constantes.RS_LIBELLE_ERREUR_IPON, evt.getInfo());
		throw new DoneException(categorieEvenementId);
	}

	private void analyserEvenementAvpPourCategorieRepauto(TacheDTO tache, EvtDTO evt, Map<String, String> proprietesWorkflow, Map<String, List<String>> staticWorkflowAttributes, String nomTraitement, String categorieEvenementId)
			throws DoneException, CancelException, CreateException {
		String nbreRepet = proprietesWorkflow.get(Constantes.RS_NBRE_REPET);
		// On incr�mente le nombre de rejeux
		if ((nbreRepet == null) || (nbreRepet.length() <= 0)) {
			nbreRepet = Integer.toString(1);
		} else {
			nbreRepet = Integer.toString(Integer.parseInt(nbreRepet) + 1);
		}
		String lancerParProcessusId = null;
		if (tache.getLancerParProcessus() != null) {
			lancerParProcessusId = tache.getLancerParProcessus().getId();
		}
		proprietesWorkflow.put(Constantes.RS_NBRE_REPET, nbreRepet);
		boolean isTimeout = controlerTimeout(NBRE_MAX_REPET_ATTEINT, proprietesWorkflow, staticWorkflowAttributes);
		if (isTimeout) {
			String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.GENE_000120);
			SFAno ano = serviceManager.getAnomalieManager().newSFAno(nomTraitement, VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.MAX_REJEUX_VALEUR_CONSTANTE, tache), SFAno.TYPE_DNR, message);
			Evenement anoEvenement = serviceManager.getAnomalieManager().traiter(nomTraitement, ano);
			String erreurParam = VersionArtemisUtil.versionnerValeurConstante(CauseEvenementConstantes.ERREURPARAM_VALEUR_CONSTANTE, tache);
			if ((anoEvenement == null) || erreurParam.equals(anoEvenement.getIdCauseEvenement())) {
				throw new CancelException();
			} else if (anoEvenement.getIdCauseEvenement().equals(evt.getCauseEvenement().getId())) {
				publierClotureAvp(lancerParProcessusId, evt, proprietesWorkflow, nbreRepet);
				throw new DoneException(categorieEvenementId);
			} else {
				createEvtPourTache(anoEvenement, tache.getId(), proprietesWorkflow.get(Constantes.RS_IDCOMMANDE));
				analyserEvenementAvp(tache, anoEvenement, proprietesWorkflow, staticWorkflowAttributes, nomTraitement);
			}
		} else {
			publierClotureAvp(lancerParProcessusId, evt, proprietesWorkflow, nbreRepet);
			throw new DoneException(categorieEvenementId);
		}
	}

	private void analyserEvenementAvpPourCategorieWarbq(TacheDTO tache, EvtDTO evt, Map<String, String> proprietesWorkflow, Map<String, List<String>> staticWorkflowAttributes, String nomTraitement) throws DoneException, CancelException, CreateException {
		boolean isTimeOut = controlerTimeout(TIME_OUT_NBRE_REJEUX, proprietesWorkflow, staticWorkflowAttributes);
		if (isTimeOut) {
			String message = serviceManager.getAnomalieManager().getMessage(MessagesConstantes.GENE_000100);
			SFAno ano = serviceManager.getAnomalieManager().newSFAno(nomTraitement, VersionArtemisUtil.versionnerValeurConstante(AnomalieConstantes.TIME_OUT_VALEUR_CONSTANTE, tache), SFAno.TYPE_DNR, message);
			Evenement anoEvenement = serviceManager.getAnomalieManager().traiter(nomTraitement, ano);
			String erreurParam = VersionArtemisUtil.versionnerValeurConstante(CauseEvenementConstantes.ERREURPARAM_VALEUR_CONSTANTE, tache);
			if ((anoEvenement == null) || erreurParam.equals(anoEvenement.getIdCauseEvenement())) {
				throw new CancelException();
			} else if (anoEvenement.getIdCauseEvenement().equals(evt.getCauseEvenement().getId())) {
				throw new CancelException();
			} else {
				createEvtPourTache(anoEvenement, tache.getId(), proprietesWorkflow.get(Constantes.RS_IDCOMMANDE));
				analyserEvenementAvp(tache, anoEvenement, proprietesWorkflow, staticWorkflowAttributes, nomTraitement);
			}
		} else {
			throw new CancelException();
		}
	}

	private void publierClotureAvp(String lancerParProcessusId, EvtDTO evt, Map<String, String> proprietesWorkflow, String nbreRepet) {
		modifierProprietesWorkflow(proprietesWorkflow, evt, nbreRepet, null);
		Notification notification = new Notification(PublicationConstantes.CLOT_AVP, lancerParProcessusId, evt.getId(), proprietesWorkflow.get(Constantes.RS_VERSION_BOLBEC));
		publier(notification);
	}

	private static EvtDTO getOrCreateEvenement(TacheDTO tache, Evenement evenement, String idCommande) {
		EvtDTO result = null;
		List<EvtDTO> tacheEvts = serviceManager.getProcessusManager().findEvtByTache(tache.getId());
		for (EvtDTO evt : tacheEvts) {
			if (evt.getCauseEvenement().getId().equals(evenement.getIdCauseEvenement()) && (equalOrBothNull(evt.getInfo(), evenement.getLibelle()))) {
				result = evt;
				break;
			}
		}
		if (result == null) {
			result = createEvtPourTache(evenement, tache.getId(), idCommande);
		} else {
			result.setDatabaseDateDateCreation(evenement.getDateGeneration());
			serviceManager.getProcessusManager().updateEvtDateCreation(result);
		}
		return result;
	}

	private static boolean equalOrBothNull(Object o1, Object o2) {
		if ((o1 == null) && (o2 == null)) {
			return true;
		} else if (o1 == null) {
			return false;
		} else if (o2 == null) {
			return false;
		} else {
			return o1.equals(o2);
		}
	}

	private static EvtDTO createEvtPourTache(Evenement evenement, String tacheId, String idCommande) {
		EvtDTO evtDTO = new EvtDTO(evenement.getId());
		if (evenement.getIdCauseEvenement() != null) {
			evtDTO.setCauseEvenement(new CauseEvenementDTO(evenement.getIdCauseEvenement()));
		}
		evtDTO.setDatabaseDateDateCreation(evenement.getDateGeneration());
		evtDTO.setDatabaseDateDateFinPrevue(evenement.getDateFin());
		String info = evenement.getLibelle();
		if (info != null) {
			if (info.length() > 300) {
				serviceManager.getLoggerManager().warning(CLASSNAME, "traiter", "On tronque � 300 caract�res le message EVT.INFO : " + info);
				evtDTO.setInfo(info.substring(0, 300));
			} else {
				evtDTO.setInfo(info);
			}
		}
		evtDTO.setAPourOrigineAgent(new AgentDTO(evenement.getIdAPourOrigineAgent()));
		evtDTO.setTache(new TacheDTO(tacheId));
		serviceManager.getProcessusManager().createEvt(evtDTO);
		// US-678 Notification pour creation d'evenement
		String evtLibelle = StringUtils.removeStart(evtDTO.getCauseEvenement().getId(), serviceManager.getVersionManager().getCurrentVersion() + "_");
		NotificationGenerique ng = new NotificationGenerique(NotificationGeneriqueConstantes.DECLENCHEUR_E, evtLibelle, evtDTO.getId(),idCommande);
		serviceManager.getNotificationGeneriqueManager().emettreNotification(ng);
		return evtDTO;
	}

	private static void modifierProprietesWorkflow(Map<String, String> proprietesWorkflow, EvtDTO evt, String nbreRepet, String inAvp) {
		proprietesWorkflow.put(Constantes.RS_IDEVT, evt.getId());
		// EV 317 mise � jour de libelle et code erreur
		proprietesWorkflow.put(Constantes.RS_LIBELLE_ERREUR_IPON, evt.getInfo());
		CauseEvenementDTO causeEvenement = serviceManager.getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseEvenement().getId());
		String libelleCauseEvt = causeEvenement.getLibelle();
		TypeEvenementDTO typeEvenement = causeEvenement.getTypeEvenement();
		String typeEvenementValeurConstante = typeEvenement.getValeurConstante();
		String roleId = (causeEvenement.getRole() == null) ? null : causeEvenement.getRole().getId();
		proprietesWorkflow.put(Constantes.RS_IDCAUSEEVT, causeEvenement.getId());
		proprietesWorkflow.put(Constantes.RS_LIBCAUSEEVT, StringUtils.stripAccents(libelleCauseEvt));
		proprietesWorkflow.put(Constantes.RS_TYPE_EVT, typeEvenementValeurConstante);
		proprietesWorkflow.put(Constantes.RS_ROLE_DYNAMIQUE, roleId);
		proprietesWorkflow.put(Constantes.RS_NBRE_REPET, nbreRepet);
		proprietesWorkflow.put(Constantes.RS_VAR_INAVP, inAvp);
	}

	private static boolean controlerTimeout(String cle, Map<String, String> proprietesWorkflow, Map<String, List<String>> staticWorkflowAttributes) {
		if (DEPASSEMENT_DUREE_TACHE.equals(cle)) {
			return isDateOut(proprietesWorkflow);
		} else if (NBRE_MAX_REPET_ATTEINT.equals(cle)) {
			return isNbreRepetMaxAtteint(proprietesWorkflow, staticWorkflowAttributes);
		} else if (TIME_OUT_NBRE_REJEUX.equals(cle)) {
			// Contr�le sur la date
			return isNbreRejeuxMaxAtteint(proprietesWorkflow, staticWorkflowAttributes);
		} else {
			throw new IllegalArgumentException("cle doit �tre DEPASSEMENT_DUREE_TACHE ou NBRE_MAX_REJEUX_ATTEINT ou NBRE_REJEUX_MAX_ATTEINT");
		}
	}

	private static boolean isDateOut(Map<String, String> proprietesWorkflow) {
		long overFinishDate = Long.parseLong(proprietesWorkflow.get(WorkflowConstantes.DATE_MAX_EXECUTION));
		long time = System.currentTimeMillis() / 1000L;
		return (time > overFinishDate);
	}

	private static boolean isNbreRepetMaxAtteint(Map<String, String> proprietesWorkflow, Map<String, List<String>> staticWorkflowAttributes) {
		String nbreRepetMax = CollectionUtils.getFirstOrNull(staticWorkflowAttributes.get(Constantes.RS_NBRE_REPET_MAX));
		String nbreRepet = proprietesWorkflow.get(Constantes.RS_NBRE_REPET);

		if (StringUtils.isNotBlank(nbreRepetMax) && StringUtils.isNumeric(nbreRepetMax) && StringUtils.isNumeric(nbreRepet)) {
			// Le nombre de repet est valoris� => on compare
			return (nbreRepetMax != null && (Integer.parseInt(nbreRepet) >= Integer.parseInt(nbreRepetMax)));
		}
		return false;
	}

	/**
	 * isNbreRejeuxMaxAtteint
	 *
	 * @param proprietesWorkflow Les propri�t�s workflow
	 * @param staticAttributes Les attributs statiques de la tache
	 * @return ?
	 */
	private static boolean isNbreRejeuxMaxAtteint(Map<String, String> proprietesWorkflow, Map<String, List<String>> staticAttributes) {
		String nbRejeuxMax = CollectionUtils.getFirstOrNull(staticAttributes.get(Constantes.RS_NBRE_REJEUX_MAX));
		if (StringUtils.isBlank(nbRejeuxMax) || !StringUtils.isNumeric(nbRejeuxMax)) {
			nbRejeuxMax = Constantes.DEFAULT_NBRE_REJEUX_MAX;
		}
		String nbRejeux = proprietesWorkflow.get(Constantes.RS_NBRE_REJEUX);
		if (StringUtils.isNotBlank(nbRejeux) && StringUtils.isNumeric(nbRejeux)) {
			// Le nombre de rejeu est valoris� => on compare
			return (Integer.parseInt(nbRejeux) >= Integer.parseInt(nbRejeuxMax));
		}
		return false;
	}

	private static String getLibelleReassignation(String roleId, String info, AgentDTO agent) {
		String libelle = STRING_REASSIGNE_AU_ROLE;
		libelle += roleId;
		if (agent.getNom() != null) {
			libelle += STRING_PAR;
			libelle += agent.getNom();
			if (agent.getPrenom() != null) {
				libelle += STRING_SPACE;
				libelle += agent.getPrenom();
			}
		}
		libelle += STRING_COMMENTAIRE;
		libelle += info;
		return libelle;
	}

	private static String getLibelleReroutage(String zoneGeographiqueId, String info, AgentDTO agent) {
		String libelle = STRING_REROUTE_VERS_ZONE_GEO;
		libelle += zoneGeographiqueId;
		libelle += STRING_SPACE;
		if (agent.getNom() != null) {
			libelle += STRING_PAR;
			libelle += agent.getNom();
			if (agent.getPrenom() != null) {
				libelle += STRING_SPACE;
				libelle += agent.getPrenom();
			}
		}
		libelle += STRING_COMMENTAIRE;
		libelle += info;
		return libelle;
	}

	// --------------------------------------------------------------
	// QUEUE PUBLICATION
	// --------------------------------------------------------------

	private void publier(Notification notification) {
		QueueConnection queueConnection = null;
		try {
			queueConnection = publicationQueueHelper.createConnection();
			QueueSession session = queueConnection.createQueueSession(true, 0);
			QueueSender sender = session.createSender(publicationQueueHelper.getQueue());
			ObjectMessage message = session.createObjectMessage(new HashMap<String, String>(notification.toHashMap()));
			sender.send(message);
		} catch (JMSException e) {
			publicationQueueHelper.invalidate();
			throw new EJBException("Erreur lors de l'envoi du message de publication", e);
		} catch (NamingException e) {
			throw new EJBException("Impossible d'utiliser le QueueHelper", e);
		} finally {
			QueueHelper.closeConnection(queueConnection);
		}
	}

}
