/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data;

import java.io.Serializable;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>12/10/2010</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Pr�f�rences pour un filtre de type texte
 * 
 * @author rgvs7490
 */
public class TexteFiltrePreference implements Serializable {

	private String id;
	private String texte;

	/**
	 * 
	 * @param id
	 * @param texte
	 */
	public TexteFiltrePreference(String id, String texte) {
		this.id = id;
		this.texte = texte;
	}

	public String getId() {
		return this.id;
	}

	public String getTexte() {
		return this.texte;
	}
}
