/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus;

import java.io.Serializable;
import java.util.List;

import com.soliste.bolbec.commun.service.exception.InterfaceTechnicalException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.AvpCorrectionAdresseDTO;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.InterfaceException;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.a42c.Client42C;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.a42c.Interface42C;
import com.soliste.bolbec.livraison.service.interfaces.servicesexternes.a42c.Interface42C.TypesConsultation;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EpCommercialDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

/**
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>06/10/2010</TD><TD>DBA</TD><TD>BI-MODE: Non remont� d'exception sur l'IHM</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>19/01/2011</TD><TD>CCL</TD><TD>Amelioration de la gestion des logs</TD></TR>
 * </TABLE>
 * Traitement de correction d'adresse sur AVP
 */
public class AvpCorrectionAdresseTraitement implements Serializable {

	private static final String CLASS_NAME = "AvpCorrectionAdresseTraitement";
	private static final String NDPLP = "NDPLP";

	/**
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>06/10/2010</TD><TD>DBA</TD><TD>BI-MODE: Non remont� d'exception sur l'IHM</TD></TR>
	 * </TABLE>
	 * Appel au service ConsulterEtude
	 * 
	 * @param tacheId donn�es d'entr�es au service ConsulterEtude
	 * @param avpCorrectionAdresseDTO
	 * @param proprietesWorkflow
	 * 
	 */
	public static void consulterClient(String tacheId, AvpCorrectionAdresseDTO avpCorrectionAdresseDTO) {
		String methodName = "consulterClient";

		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(processus.getId());
		CommandeDTO commande = ServiceManager.getInstance().getCommandeManager().findCommandeByProcessus(processus.getId());
		String referenceExt = commande.getRefExterne();
		LigneCommandeDTO firstLigneCde = lignesCde.iterator().next();

		String instanceLocalisation = null;
		if (firstLigneCde.getInstanceLocalisation() != null) {
			instanceLocalisation = firstLigneCde.getInstanceLocalisation().getId();
		}

		String nd = getND(firstLigneCde.getId());
		String ndplp = getNDPLP(lignesCde);
		if (ndplp != null) {
			// Si on a un ndplp, alors on interroge 42C.
			// Il faut donc d�finir le param�tre adresse42CRenseignee � non null
			// pour pouvoir afficher la partie "Adresse Attendue" dans la jsp
			avpCorrectionAdresseDTO.setAdresse42CRenseignee(true);
			ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, methodName, "ConsulterClient - NDPLP = " + ndplp);
			ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, methodName, "Appel au SE 42C ConsulterClient");
			Client42C client = null;
			try {
				client = Interface42C.consulterClient(nd, instanceLocalisation, TypesConsultation.ABONNE, nd, referenceExt, commande.getId());
				AdresseDTO adresse = new AdresseDTO(firstLigneCde.getClient().getId());
				adresse.setVille(client.getCommune());
				adresse.setLibelleVoie(client.getNomVoie());
				adresse.setCodeRivoli(client.getCodeRivoli());
				adresse.setNumeroVoie(client.getNumeroVoie());
				adresse.setEnsemble(client.getEnsemble());
				adresse.setBatiment(client.getBatiment());
				adresse.setEscalier(client.getEscalier());
				adresse.setEtage(client.getEtage());
				adresse.setPorte(client.getPorte());
				adresse.setLogo(client.getLogo());
				adresse.setCodeInsee(client.getCodeInsee());
				avpCorrectionAdresseDTO.setAdresseAttendue(adresse);
			} catch (InterfaceException ie) {
				String messageErreur = "Echec d'appel d'interface (" + ie.getCode() + " " + ie.getLibelle() + ")";
				avpCorrectionAdresseDTO.setMessageErreurInterface(messageErreur);
				ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, methodName, messageErreur);
			} catch (InterfaceTechnicalException ite) {
				String messageErreur = "Erreur technique (" + ite.getMessage() + ")";
				avpCorrectionAdresseDTO.setMessageErreurInterface(messageErreur);
				ServiceManager.getInstance().getLoggerManager().finest(CLASS_NAME, methodName, messageErreur);
			}
			ServiceManager.getInstance().getLoggerManager().info(CLASS_NAME, methodName, "Retour du SF 42C ConsulterClient");
		}
	}

	private static String getNDPLP(List<LigneCommandeDTO> lignesCde) {
		LigneCommandeDTO ligneCommande = null;
		for (LigneCommandeDTO lc : lignesCde) {
			if (NDPLP.equals(lc.getTypeAccesLivraisonOrigine())) {
				ligneCommande = lc;
				break;
			}
		}
		if (ligneCommande != null) {
			String accesLivraisonOrigine = ligneCommande.getAccesLivraisonOrigine();
			String ndplp = null;
			if (accesLivraisonOrigine.length() >= 8) {
				ndplp = accesLivraisonOrigine.substring(accesLivraisonOrigine.length() - 8, accesLivraisonOrigine.length()) + "*";
			}
			return ndplp;
		}

		return null;
	}

	/**
	 * On r�cup�re le ND de la commande � partir d'une ligne de commande.
	 * 
	 * @param ligneCommandeId
	 * @return ND
	 */
	private static String getND(String ligneCommandeId) {
		PsSouhaiteDTO psSouhaite = ServiceManager.getInstance().getCommandeManager().findPsSouhaiteByLigneCommande(ligneCommandeId);
		if (psSouhaite != null) {
			return psSouhaite.getNd();
		}
		EpCommercialDTO epc = ServiceManager.getInstance().getCommandeManager().findEpCommercialByLigneCommande(ligneCommandeId);
		if (epc != null) {
			return epc.getNd();
		}
		return null;
	}

}
