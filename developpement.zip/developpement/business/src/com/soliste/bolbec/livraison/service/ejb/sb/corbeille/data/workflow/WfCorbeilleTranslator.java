/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.bolbec.livraison.service.Constantes;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleInfoConstantes;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleTranslator;
import com.soliste.bolbec.livraison.service.ejb.sb.workflow.data.WorkflowConstantes;

/**
 * Classe permettant une traduction d'un CorbeilleInfo en �quivalent workflow
 * 
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>17/09/2012</TD><TD>EBA</TD><TD>EV-000188: Vente FTTH - Ajout de l'EPCidVIA</TD></TR>
 * <TR><TD>09/11/2012</TD><TD>EBA</TD><TD>G8R2C1 - EV000183 - EB-0059 : Afficher le contenu de la derni�re note dans le d�tail de l�AVP</TD></TR>
 * <TR><TD>12/11/2012</TD><TD>FTE</TD><TD>EV-000183: Apostrof - Ajout du CODE_REGIME</TD></TR> * </TABLE>
 * <TR><TD>14/11/2013</TD><TD>FTE</TD><TD>EV-000272 : Affichage Ref FCI dans Art�mis</TD></TR>
 * <TR><TD>10/09/2016</TD><TD>JDE</TD><TD>EV-000377: Commandes FTTE - Ajout du num�ro CLIP</TD></TR>
 * 
 * @author gdzd8490
 */
public class WfCorbeilleTranslator implements CorbeilleTranslator {

	/**
	 * Identifiant d'une t�che
	 */
	public static final String TACHE_ID = "TACHE_ID";
	/**
	 * Identifiant d'un processus
	 */
	public static final String PROCESSUS_ID = "PROCESSUS_ID";
	private static WfCorbeilleTranslator instance = null;

	private static Map<String, WfSelFilter> filters = null;

	static {
		Map<String, WfSelFilter> h = new HashMap<String, WfSelFilter>();
		h.put(TACHE_ID, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.IDENTIFIER));
		h.put(PROCESSUS_ID, new WfSelFilter(WorkflowConstantes.CASE_TYPE, WorkflowConstantes.IDENTIFIER));
		h.put(CorbeilleInfoConstantes.ND_SUPPORT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ND_FINDER));
		h.put(CorbeilleInfoConstantes.EPC_ID_VIA, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_EPC_ID_VIA));
		h.put(CorbeilleInfoConstantes.NDPLP, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_NDPLP));
		h.put(CorbeilleInfoConstantes.NUMERO_CLIP, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_NUMERO_CLIP));
		h.put(CorbeilleInfoConstantes.TACHE, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.LIBELLE));
		h.put(CorbeilleInfoConstantes.CAUSE_EVENEMENT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_LIBCAUSEEVT));
		h.put(CorbeilleInfoConstantes.CAUSE_EVENEMENT_INIT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_LIBCAUSEEVTINIT));
		h.put(CorbeilleInfoConstantes.DATE_SOUHAITEE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATE_ORDONNANCEMENT));
		h.put(CorbeilleInfoConstantes.DATE_CREATION_COMMANDE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATE_CREATION_CMD));
		h.put(CorbeilleInfoConstantes.DATE_CONTRACTUELLE_EPC_SUPPORT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATE_CONTRACTUELLE_EPCSUP));
		h.put(CorbeilleInfoConstantes.DATE_CONTRACTUELLE_COMMANDE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATE_CONTRACTUELLE));
		h.put(CorbeilleInfoConstantes.GROUPE_OFFRE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_OFFRE_GROUPEE));
		h.put(CorbeilleInfoConstantes.FAMILLE_OFFRE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_FAMILLE_OFFRE));
		h.put(CorbeilleInfoConstantes.DEBUT_AU_PLUS_TOT, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.DEBUT_AU_PLUS_TOT));
		h.put(CorbeilleInfoConstantes.FIN_AU_PLUS_TARD, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.FIN_AU_PLUS_TARD));
		h.put(CorbeilleInfoConstantes.REPARTITEUR, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_REPARTITEUR));
		h.put(CorbeilleInfoConstantes.ZONE_GEOGRAPHIQUE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ZONE_GEO));
		h.put(CorbeilleInfoConstantes.ZONE_SI, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ZONE_SI));
		h.put(CorbeilleInfoConstantes.EDSI, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_EDS_INSTALL));
		h.put(CorbeilleInfoConstantes.ID_COMMANDE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ID_COMMANDE));
		h.put(CorbeilleInfoConstantes.STATUT_COMMANDE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_STATUT_COMMANDE));
		h.put(CorbeilleInfoConstantes.JALON, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_JALON_ACTUEL));
		h.put(CorbeilleInfoConstantes.TRAITE_PAR, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.AGENT));
		h.put(CorbeilleInfoConstantes.ROLE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, WorkflowConstantes.ROLE));
		h.put(CorbeilleInfoConstantes.NOM_VENDEUR, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_NOM_VENDEUR));
		h.put(CorbeilleInfoConstantes.REF_CLIENT_CONTRACTANT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ID_CLIENT_CONTRACTANT));
		h.put(CorbeilleInfoConstantes.NOM_CONTRACTANT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DENOMINATION_CONTRACTANT));
		h.put(CorbeilleInfoConstantes.PRENOM_CONTRACTANT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_PRENOM_CONTRACTANT));
		h.put(CorbeilleInfoConstantes.CATEGORIE_CONTRACTANT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_CATEGORIE_CONTRACTANT));
		h.put(CorbeilleInfoConstantes.NOM_CLIENT_LIVRE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DENOMINATION_LIVRE));
		h.put(CorbeilleInfoConstantes.CATEGORIE_CLIENT_LIVRE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_CATEGORIE_LIVRE));
		h.put(CorbeilleInfoConstantes.DSLAM, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DSLAM));
		h.put(CorbeilleInfoConstantes.ANCIEN_DSLAM, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_ANC_DSLAM));
		h.put(CorbeilleInfoConstantes.DATE_PREMIERE_EXECUTION, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, WorkflowConstantes.DATE_PREMIERE_EXECUTION));
		h.put(CorbeilleInfoConstantes.DATE_MAX_EXECUTION, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.DATE_MAX_EXECUTION));
		h.put(CorbeilleInfoConstantes.DATE_PROGRAMMATION, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATE_PROGRAMMATION));
		h.put(CorbeilleInfoConstantes.DATE_VALIDATION_FO, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATEVALIDATIONFO));
		h.put(CorbeilleInfoConstantes.DEBUT_AU_PLUS_TARD, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.DEBUT_AU_PLUS_TARD));
		h.put(CorbeilleInfoConstantes.DEBUT_REEL, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.DEBUT_REEL));
		h.put(CorbeilleInfoConstantes.DESCRIPTION_CONTRACTANT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_NUM_CONTACT_CONTRACTANT));
		h.put(CorbeilleInfoConstantes.FIN_AU_PLUS_TOT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, WorkflowConstantes.FIN_AU_PLUS_TOT));
		h.put(CorbeilleInfoConstantes.FIN_REELLE, new WfSelFilter(WorkflowConstantes.STEP_TYPE, WorkflowConstantes.DATE_FIN_REELLE));
		h.put(CorbeilleInfoConstantes.NOMBRE_REJEUX, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_NBRE_REJEUX));
		h.put(CorbeilleInfoConstantes.REFEXTERNE_COMMANDE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_REFEXTERNE_COMMANDE));
		h.put(CorbeilleInfoConstantes.TRAITEMENT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, WorkflowConstantes.NOM_TRAITEMENT));
		h.put(CorbeilleInfoConstantes.TYPE_EVENEMENT, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_TYPE_EVT));
		h.put(CorbeilleInfoConstantes.VERSION_BOLBEC, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_VERSION_BOLBEC));
		h.put(CorbeilleInfoConstantes.DIFFEREE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, WorkflowConstantes.DEBUT_AU_PLUS_TOT));
		h.put(CorbeilleInfoConstantes.EN_COURS, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, WorkflowConstantes.DEBUT_AU_PLUS_TOT));
		h.put(CorbeilleInfoConstantes.STATUT_COMMANDE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_STATUT_COMMANDE));
		// TP_INTERFERE
		h.put(CorbeilleInfoConstantes.INTERFERE, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_INTERFERE));

		// EV-000014: La r�cup�ration de la date de RDV est bas�e sur la valeur du champ DateRDV dans XPM
		h.put(CorbeilleInfoConstantes.DATE_RDV, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_DATE_RDV));

		// EV-00183
		h.put(CorbeilleInfoConstantes.REGIME_SAV, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_CODE_REGIME));

		h.put(CorbeilleInfoConstantes.REFERENCE_FCI, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_REFERENCE_FCI));

		// EV-317 Ajout de libelle et code erreur IPON
		h.put(CorbeilleInfoConstantes.LIBELLE_ERREUR_IPON, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_LIBELLE_ERREUR_IPON));

		// EV-348_09
		h.put(CorbeilleInfoConstantes.CONTEXTE_LIVRAISON, new WfSelFilter(WorkflowConstantes.ROOTSET_TYPE, Constantes.RS_CONTEXTE_LIV));

		filters = Collections.unmodifiableMap(h);
	}

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static WfCorbeilleTranslator getInstance() {
		if (instance == null) {
			instance = new WfCorbeilleTranslator();
		}
		return instance;
	}

	private WfCorbeilleTranslator() {
		// pour �viter instanciation inutile
	}

	/**
	 * Traduit un CorbeilleInfo en filtre workflow
	 * 
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.CorbeilleTranslator#translate(java.lang.String)
	 */
	public Object translate(String criterion) {
		WfSelFilter filter = filters.get(criterion);
		if (filter == null) {
			filter = filters.get(CorbeilleInfoConstantes.ND_SUPPORT);
		}
		return filter;
	}
}
