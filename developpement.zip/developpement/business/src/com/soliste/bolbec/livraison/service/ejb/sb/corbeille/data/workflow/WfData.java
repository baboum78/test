/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import java.util.List;
import java.util.Map;

import com.soliste.aps.workflow.WfException;
import com.soliste.aps.workflow.WfExecutionObject;
import com.soliste.aps.workflow.WfUser;
import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;

/**
 * Facade pour l'utilisation des objets workflow
 * 
 * @author gdzd8490
 * 
 */
public abstract class WfData implements ItemData {

	// TODO OLD: a revoir
	protected WfExecutionObject wfObject;
	private Map<String, String> wfExecutionObjectValues;

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#getValues()
	 */
	public Map<String, String> getValues() {
		// return wfObject.getValues();
		return wfExecutionObjectValues;
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#getValue(java.lang.String)
	 */
	@SuppressWarnings("unchecked")
	public String getValue(String keyName) throws DataException {
		try {
			Object value = null;
			value = wfObject.getValue(keyName);
			if (value == null ) {
				value = wfObject.getStaticAttribute(keyName);
			}
			String valueStr = null;
			if (value instanceof String) {
				valueStr = (String) value;
			} else if (value instanceof List) {
				// Il existe des cas o� l'on re�oit une liste (notamment pour le ModOp),
				// Dans ce cas on retourne uniquement le premier �l�ment de la liste
				valueStr = CollectionUtils.getFirstOrNull(((List<String>) value));
			}
			return valueStr;
		} catch (WfException e) {
			throw new DataException(e);
		}
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.ItemData#getId()
	 */
	public String getId() {
		return wfObject.getId();
	}

	/**
	 * Renvoie l'utilisateur workflow associ� � cet objet
	 * 
	 * @return l'utilisateur workflow associ� � cet objet
	 */
	public WfUser getOwner() {
		return wfObject.getOwner();
	}

	/**
	 * D�termine les attributs/valeurs de l'objet encapsul�
	 * 
	 * @param wfExecutionObjectValues
	 */
	protected void setWfExecutionObjectValues(Map<String, String> wfExecutionObjectValues) {
		this.wfExecutionObjectValues = wfExecutionObjectValues;
	}

	/**
	 * D�termine l'objet encapsul�
	 * 
	 * @param wfObject
	 */
	protected void setWfObject(WfExecutionObject wfObject) {
		this.wfObject = wfObject;
	}

}
