/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.soliste.bolbec.fwk.util.StringUtils;
import com.soliste.bolbec.livraison.service.interfaces.servicesfonctionnels.async.gestionressourcestechniquesblo.ConstantesIPON;
import com.soliste.bolbec.livraison.service.model.AdresseDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.ClientDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.InstanceRtDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.RessourceTechDTO;
import com.soliste.bolbec.livraison.service.model.TacheDTO;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicLigneCommande;
import com.soliste.bolbec.livraison.service.model.dynamic.ConstantesDynamicPSSouhaite;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.TypeRTConstantes;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border'>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>DBA</TD><TD>Suppression classe deprecated</TD></TR>
 * <TR><TD>07/12/2010</TD><TD>JCH</TD><TD>correction pour le bouton abd_provisoire</TD></TR>
 * <TR><TD>06/07/2018</TD><TD>AJO</TD><TD>QC980 : Intrants FTTH</TD></TR>
 * </TABLE>
 * La factory permettant de cr�er des AvpInfo
 * 
 * @author rgvs7490
 */
public class AvpInfoDTOFactory {

	private final static String CST_Z0BPQ_DEFAUT = "00000";

	/**
	 * @param avpType
	 * @param tacheCourante
	 * @param tachePrecedente
	 * @param evenementProvoquant
	 * @param modeOpName
	 * @param versionArtemis
	 * @return
	 */
	public static AvpInfoDTO create(String avpType, TacheDTO tacheCourante, TacheDTO tachePrecedente, EvtDTO evenementProvoquant, String modeOpName, String versionArtemis) {
		AvpInfoDTO dto;
		if (AvpInfoDTO.AVP_AFFECTATION_XDSL_TYPE.equals(avpType)) {
			AvpAffectationXdslDTO a = new AvpAffectationXdslDTO();
			fillAvpAffectationXdslData(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_CONTROLE_AFF_TYPE.equals(avpType)) {
			AvpControleAffDTO a = new AvpControleAffDTO();
			fillAvpControleAffData(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_MAJ_PARC_MATERIEL_TYPE.equals(avpType)) {
			AvpMajParcMaterielDTO a = new AvpMajParcMaterielDTO();
			fillAvpMajParcMaterielData(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_CORRECTION_ADRESSE.equals(avpType)) {
			AvpCorrectionAdresseDTO a = new AvpCorrectionAdresseDTO();
			fillAvpCorrectionAdresseData(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_EVT_ABSENT.equals(avpType)) {
			AvpActivCommutDTO a = new AvpActivCommutDTO();
			fillAvpActivCommutData(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_AFF_THD.equals(avpType)) {
			AvpAffTHDDTO a = new AvpAffTHDDTO();
			fillAvpAffTHDData(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_CTRL_COHERENCE_CMD.equals(avpType)) {
			AvpCtrlCoherenceCmdDTO a = new AvpCtrlCoherenceCmdDTO();
			fillAvpCtrlCoherenceCmd(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_OPE_IMB_ABS.equals(avpType)) {
			AvpOpeImbAbsDTO a = new AvpOpeImbAbsDTO();
			fillAvpOpeImbAbs(a, tacheCourante.getId());
			dto = a;
		} else if (AvpInfoDTO.AVP_AFF_BLO_IMM_NON_TROUVE.equals(avpType)) {
			AvpAffBLOImmNonTrouveDTO a = new AvpAffBLOImmNonTrouveDTO();
			fillAvpAffBLOImmNonTrouve(a, tacheCourante.getId());
			dto = a;
		} else {
			dto = new AvpInfoDTO();
		}

		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheCourante.getId());
		dto.setProcessusId(processus.getId());
		chargerCauseEvenementComplet(tacheCourante);
		dto.setTacheCourante(tacheCourante);

		if (tachePrecedente != null) {
			chargerCauseEvenementComplet(tachePrecedente);
			dto.setTachePrecedente(tachePrecedente);
		}

		String causeEvenementId = null;
		if (evenementProvoquant != null) {
			dto.setEvenementProvoquantId(evenementProvoquant.getId());
			if (evenementProvoquant.getCauseEvenement() != null) {
				causeEvenementId = evenementProvoquant.getCauseEvenement().getId();
			}
		}
		dto.setModeOperatoireUrl(ModeOperatoireUtil.getUrlModeOperatoire(modeOpName, causeEvenementId, versionArtemis));

		ProcessusActionsAutorisees avpActionAutorisees = ActionsAutoriseesUtil.getProcessusActionsAutorisees(processus, null);
		dto.setComplet(avpActionAutorisees.isComplet());
		dto.setAbandonnable(avpActionAutorisees.isAbandonnable());
		dto.setAbandonnablePartiellement(avpActionAutorisees.isAbandonnablePartiellement());
		dto.setAbandonnableProvisoirement(avpActionAutorisees.isAbandonnableProvisoirement());
		dto.setSuspendable(avpActionAutorisees.isSuspendable());
		dto.setRetablissable(avpActionAutorisees.isRetablissable());
		dto.setStoppable(avpActionAutorisees.isStoppable());
		dto.setRegularisable(avpActionAutorisees.isRegularisable());

		return dto;
	}

	private static void chargerCauseEvenementComplet(TacheDTO tache) {
		List<EvtDTO> evtDTOs = ServiceManager.getInstance().getProcessusManager().findEvtByTache(tache.getId());
		for (EvtDTO evt : evtDTOs) {
			CauseEvenementDTO causeEvtComplete = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseEvenement().getId());
			evt.setCauseEvenement(causeEvtComplete);
		}
	}

	// FIXME OLD: � d�placer dans CommandeManager ?
	private static List<PsSouhaiteDTO> findPsSouhaiteByTache(String tacheId) {
		List<PsSouhaiteDTO> psSouhaiteList = new ArrayList<PsSouhaiteDTO>();
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(processus.getId());
		for (LigneCommandeDTO lc : lignesCde) {
			PsSouhaiteDTO psSouhaite = ServiceManager.getInstance().getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
			if (psSouhaite != null) {
				psSouhaiteList.add(psSouhaite);
			}
		}
		return psSouhaiteList;
	}

	private static void fillAvpAffectationXdslData(AvpAffectationXdslDTO dto, String tacheId) {
		List<PsSouhaiteDTO> psSouhaiteList = findPsSouhaiteByTache(tacheId);
		dto.setCentre(getValeurDynamicPsSouhaiteFromPsSouhaiteList(ConstantesDynamicPSSouhaite.PSSOUHAITE_CENTRE_ADSL, psSouhaiteList));
		dto.setBroche(getValeurDynamicPsSouhaiteFromPsSouhaiteList(ConstantesDynamicPSSouhaite.PSSOUHAITE_BROCHE_ADSL, psSouhaiteList));
		dto.setReglette(getValeurDynamicPsSouhaiteFromPsSouhaiteList(ConstantesDynamicPSSouhaite.PSSOUHAITE_REGLETTE_ADSL, psSouhaiteList));
		dto.setVcOperateur(getValeurDynamicPsSouhaiteFromPsSouhaiteList(ConstantesDynamicPSSouhaite.PSSOUHAITE_VC, psSouhaiteList));
		dto.setVcCible(getValeurDynamicPsSouhaiteFromPsSouhaiteList(ConstantesDynamicPSSouhaite.PSSOUHAITE_VC_FORCE, psSouhaiteList));
	}

	private static void fillAvpControleAffData(AvpControleAffDTO dto, String tacheId) {
		fillAvpAffectationXdslData(dto, tacheId);
	}

	private static void fillAvpMajParcMaterielData(AvpMajParcMaterielDTO dto, String tacheId) {
		String usc = null;
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<LigneCommandeDTO> lignesCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(processus.getId());
		for (LigneCommandeDTO lc : lignesCde) {
			Map<String, String> dynamics = lc.getDynamicLigneCommandes();
			usc = dynamics.get(ConstantesDynamicLigneCommande.LIGNECOMMANDE_USC);
			if (usc != null) {
				break;
			}
		}
		dto.setUsc(usc);
	}

	private static void fillAvpCorrectionAdresseData(AvpCorrectionAdresseDTO dto, String tacheId) {
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		LigneCommandeDTO firstLigneCde = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessusAndUneSeule(processus.getId());
		ClientDTO client = firstLigneCde.getClient();
		dto.setAdresse(client.getAdresse());
	}

	private static void fillAvpActivCommutData(AvpActivCommutDTO dto, String tacheId) {
		List<PsSouhaiteDTO> psSouhaiteList = findPsSouhaiteByTache(tacheId);
		String z0bpq = getValeurDynamicPsSouhaiteFromPsSouhaiteList(ConstantesDynamicPSSouhaite.PSSOUHAITE_Z0BPQ, psSouhaiteList);
		if (z0bpq == null || StringUtils.isEmpty(z0bpq)) {
			z0bpq = CST_Z0BPQ_DEFAUT;
		}
		dto.setZ0bpq(z0bpq);
	}

	private static void fillAvpAffTHDData(AvpAffTHDDTO dto, String tacheId) {
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<InstanceRtDTO> instancesRt = ServiceManager.getInstance().getRessourceTechniqueManager().findInstanceRTByLivreParProcessus(processus.getId());
		for (InstanceRtDTO instanceRt : instancesRt) {
			RessourceTechDTO ressourceTech = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(RessourceTechDTO.class, instanceRt.getRessourceTech().getId());
			if (TypeRTConstantes.CSHD_THD.equals(ressourceTech.getTypeRt().getId())) {
				Map<String,String> dynamicRts = instanceRt.getDynamicInstanceRts();
				// Les champs dynamiques � r�cup�rer sont stock�s dans les champs dynamiques de l'instanceRT "CSHD_THD"
				dto.setOltName(dynamicRts.get(ConstantesIPON.TAG_OLTNAME));
				dto.setOltShelf(dynamicRts.get(ConstantesIPON.TAG_SHELF));
				dto.setOltCard(dynamicRts.get(ConstantesIPON.TAG_CARD));
				dto.setOltPort(dynamicRts.get(ConstantesIPON.TAG_PORT));
				break;
			}
		}
	}

	private static void fillAvpCtrlCoherenceCmd(AvpCtrlCoherenceCmdDTO dto, String tacheId) {
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<LigneCommandeDTO> lignesCommande = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(processus.getId());
		ClientDTO client = lignesCommande.get(0).getClient();
		AdresseDTO adresse = client.getAdresse();
		dto.setCpltNumVoie(adresse.getCpltnumVoie());
		dto.setNumeroVoie(adresse.getNumeroVoie());
		dto.setBatiment(adresse.getBatiment());
		dto.setEtage(adresse.getEtage());
		dto.setCodeRivoli(adresse.getCodeRivoli());
		dto.setEscalier(adresse.getEscalier());
		dto.setCodeInsee(adresse.getCodeInsee());

		for (LigneCommandeDTO lc : lignesCommande) {
			PsSouhaiteDTO psSouhaite = ServiceManager.getInstance().getCommandeManager().findPsSouhaiteByLigneCommande(lc.getId());
			Map<String, String> dynamicLigneCommandes = lc.getDynamicLigneCommandes();
			Map<String, String> dynamicPsSouhaites = null;
			if (psSouhaite != null) {
				dynamicPsSouhaites = psSouhaite.getDynamicPsSouhaites();
			}
			if (dynamicLigneCommandes != null) {
				String codeImbValue = dynamicLigneCommandes.get(ConstantesDynamicLigneCommande.CLE_CODE_IMMEUBLE);
				String priseExistanteValue = dynamicLigneCommandes.get(ConstantesDynamicLigneCommande.CLE_PRISE_EXISTANTE);
				String operateurImbValue = dynamicLigneCommandes.get(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE);
				if (StringUtils.isNotBlank(codeImbValue)) {
					dto.setCodeImmeuble(codeImbValue);
				}
				if (StringUtils.isNotBlank(priseExistanteValue)) {
					dto.setPriseExistante(priseExistanteValue);
				} else {
					dto.setPriseExistante(ConstantesDynamicLigneCommande.DEFAULT_PRISE_EXISTANTE);
				}
				if (StringUtils.isNotBlank(operateurImbValue)) {
					dto.setOperateurImmeuble(operateurImbValue);
				}
			}
			if (dynamicPsSouhaites != null) {
				String referencePriseValue = dynamicPsSouhaites.get(ConstantesDynamicPSSouhaite.PTOID);
				if (StringUtils.isNotBlank(referencePriseValue)) {
					dto.setReferencePrise(referencePriseValue);
				}
			}
		}
	}

	private static void fillAvpOpeImbAbs(AvpOpeImbAbsDTO dto, String tacheId) {
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<LigneCommandeDTO> lignesCommande = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(processus.getId());

		for (LigneCommandeDTO lc : lignesCommande) {
			Map<String, String> dynamicLigneCommandes = lc.getDynamicLigneCommandes();
			if (dynamicLigneCommandes != null) {
				String operateurImbValue = dynamicLigneCommandes.get(ConstantesDynamicLigneCommande.CLE_OPERATEUR_IMMEUBLE);
				if (!ConstantesDynamicLigneCommande.NON_RENSEIGNE.equals(operateurImbValue)) {
					dto.setOperatorImb(operateurImbValue);
				}
			}
		}
	}

	private static void fillAvpAffBLOImmNonTrouve(AvpAffBLOImmNonTrouveDTO dto, String tacheId) {
		ProcessusDTO processus = ServiceManager.getInstance().getProcessusManager().findProcessusByTacheAndPere(tacheId);
		List<LigneCommandeDTO> lignesCommande = ServiceManager.getInstance().getCommandeManager().findLigneCommandeByEstLivreParProcessus(processus.getId());

		for (LigneCommandeDTO lc : lignesCommande) {
			Map<String, String> dynamicLigneCommandes = lc.getDynamicLigneCommandes();
			if (dynamicLigneCommandes != null) {
				String codeImb = dynamicLigneCommandes.get(ConstantesDynamicLigneCommande.CLE_CODE_IMMEUBLE);
				if (!ConstantesDynamicLigneCommande.NON_RENSEIGNE.equals(codeImb)) {
					dto.setCodeImb(codeImb);
				}
			}
		}
	}

	private static String getValeurDynamicPsSouhaiteFromPsSouhaiteList(String cle, List<PsSouhaiteDTO> psSouhaiteList) {
		String valeur = null;
		for (PsSouhaiteDTO psSouhaite : psSouhaiteList) {
			Map<String, String> dynamics = psSouhaite.getDynamicPsSouhaites();
			valeur = dynamics.get(cle);
			if (valeur != null) {
				break;
			}
		}
		return valeur;
	}
}
