/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory;

/**
 * 
 * Factory pour FieldDTO workflow
 * 
 * @author gdzd8490
 * 
 */
public class WfFieldDTOFactory implements FieldDTOFactory {

	private static WfFieldDTOFactory instance = null;

	/**
	 * Renvoie l'instance pour la factory
	 * 
	 * @return l'instance pour la factory
	 */
	public static WfFieldDTOFactory getInstance() {
		if (instance == null) {
			instance = new WfFieldDTOFactory();
		}
		return instance;
	}

	private WfFieldDTOFactory() {
		// pour �viter instanciation inutile
	}

	/**
	 * @see com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTOFactory#create(java.lang.String)
	 */
	public FieldDTO create(String id) {
		WfSelFilter wfField = (WfSelFilter) WfCorbeilleTranslator.getInstance().translate(id);
		return new WfFieldDTO(wfField);
	}

}
