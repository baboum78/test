/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */
package com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.workflow;

import com.soliste.aps.workflow.WfSelFilter;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.data.FieldDTO;

/**
 * Impl�mentation pour les infos que doit ramener une requ�te workflow
 * 
 * @author gdzd8490
 * 
 */
public class WfFieldDTO extends FieldDTO {

	private WfSelFilter field;

	/**
	 * Constructeur
	 * 
	 * @param field
	 */
	public WfFieldDTO(WfSelFilter field) {
		this.field = field;
	}

	/**
	 * Renvoie le filtre workflow
	 * 
	 * @return le filtre workflow
	 */
	public WfSelFilter getField() {
		return field;
	}

}
