package com.soliste.bolbec.livraison.service.ejb.sb.api.utils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;

import org.apache.commons.lang3.time.DateUtils;

import com.soliste.bolbec.fwk.util.CollectionUtils;
import com.soliste.bolbec.livraison.service.ejb.sb.CommandeManager;
import com.soliste.bolbec.livraison.service.ejb.sb.ProcessusManager;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.AppointmentRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.AppointmentStatus;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.CancellingType;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCause;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.EventCauseRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.Note;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.NoteType;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.OrderItem;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.ServiceOrder;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v1.modele.serviceOrder.ServiceOrderStatus;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.AddressRef;
import com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.CustomerRef;
import com.soliste.bolbec.livraison.service.ejb.sb.corbeille.exception.DataException;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.CauseEvenementUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.ActionsAutoriseesUtil;
import com.soliste.bolbec.livraison.service.ejb.sb.processus.data.ProcessusActionsAutorisees;
import com.soliste.bolbec.livraison.service.model.BlocNoteDTO;
import com.soliste.bolbec.livraison.service.model.CauseEvenementDTO;
import com.soliste.bolbec.livraison.service.model.CommandeDTO;
import com.soliste.bolbec.livraison.service.model.EvtDTO;
import com.soliste.bolbec.livraison.service.model.InterventionDTO;
import com.soliste.bolbec.livraison.service.model.LigneCommandeDTO;
import com.soliste.bolbec.livraison.service.model.OffreDTO;
import com.soliste.bolbec.livraison.service.model.ProcessusDTO;
import com.soliste.bolbec.livraison.service.model.PsSouhaiteDTO;
import com.soliste.bolbec.livraison.service.model.TacheEnCoursDTO;
import com.soliste.bolbec.livraison.service.model.TypeEvenementDTO;
import com.soliste.bolbec.livraison.service.model.TypeOpPonctuellesDTO;
import com.soliste.bolbec.livraison.service.stepauto.traitements.IInterventionManager;
import com.soliste.bolbec.livraison.service.util.IOffreManager;
import com.soliste.bolbec.livraison.service.util.IServiceManager;
import com.soliste.bolbec.livraison.service.util.ITraductionManager;
import com.soliste.bolbec.livraison.service.util.ProcessusUtil;
import com.soliste.bolbec.livraison.service.util.ServiceManager;

import aps.EtatProcessusConstantes;
import aps.TypeEvenementConstantes;
import aps.TypeOpPonctuellesConstantes;

public class ServiceOrderUtils {
	protected static IServiceManager SERVICE_MANAGER = ServiceManager.getInstance();
	protected static ProcessusManager PROCESSUS_MANAGER = ServiceManager.getInstance().getProcessusManager();
	protected static CommandeManager COMMANDE_MANAGER = ServiceManager.getInstance().getCommandeManager();
	protected static IOffreManager OFFRE_MANAGER = ServiceManager.getInstance().getOffreManager();
	protected static IInterventionManager INTERVENTION_MANAGER = ServiceManager.getInstance().getInterventionManager();
	protected static ITraductionManager TRADUCTION_MANAGER = ServiceManager.getInstance().getTraductionManager();

	/**
	 * Fonction utilitaire permettant de savoir si la cause r�cup�r�e d'abandon de la commande est
	 * bien dans la liste des causes d'abandon possible.
	 * 
	 * @param causeEvenements
	 * @param eventCauseRef
	 * @return true si la cause r�cup�r�e d'abandon de la commande est bien dans la liste des causes d'abandon possible
	 */

	public static boolean estDansListeCausePossiblePourAbandon(List<EventCause> causeEvenements, EventCauseRef eventCauseRef) {
		for (EventCause causelst : causeEvenements) {
			if (causelst.getId().equals(eventCauseRef.getId())) { // eventCauseRef.getId() n'est jamais null
				return true;
			}
		}
		return false;
	}

	/**
	 * Fonction utilitaire permettant d'obtenir l'offre de la commande en fonction du statut de celle-ci (CR,MO,SU)
	 * 
	 * @param lgnCommande
	 * @return orderItemsList
	 */
	public static List<OrderItem> getOrderItem(final List<LigneCommandeDTO> lgnCommande) {

		List<OrderItem> orderItemsList = new ArrayList<OrderItem>();
		for (LigneCommandeDTO lgnCommandeEC : lgnCommande) {
			OrderItem orderItem = new OrderItem();
			TypeOpPonctuellesDTO tp = lgnCommandeEC.getTypeOpPonctuelles();
			if (TypeOpPonctuellesConstantes.CR.equals(tp.getId())) {

				OffreDTO offre = OFFRE_MANAGER.getOffreForLigneCommandeCRNew(lgnCommandeEC.getId(), true);

				orderItem.setCommercialOperationType(TypeOpPonctuellesConstantes.CR);
				orderItem.setExternalId(lgnCommandeEC.getRefExterne());
				orderItem.setId(lgnCommandeEC.getId());
				orderItem.setOfferSpecificationCode(offre.getValeurConstante());
				orderItemsList.add(orderItem);
			}
			if (TypeOpPonctuellesConstantes.SU.equals(tp.getId())) {

				OffreDTO offre = OFFRE_MANAGER.getOffreForLigneCommandeSUNew(lgnCommandeEC.getId(), true);
				orderItem.setCommercialOperationType(TypeOpPonctuellesConstantes.SU);
				orderItem.setExternalId(lgnCommandeEC.getRefExterne());
				orderItem.setId(lgnCommandeEC.getId());
				orderItem.setOfferSpecificationCode(offre.getValeurConstante());
				orderItemsList.add(orderItem);

			}

			if (TypeOpPonctuellesConstantes.MO.equals(tp.getId())) {
				PsSouhaiteDTO psmod = COMMANDE_MANAGER.findPsSouhaiteByLigneCommande(lgnCommandeEC.getId());
				OffreDTO offre = OFFRE_MANAGER.getOffreById(psmod.getPorteSurOffre().getId());
				orderItem.setCommercialOperationType(TypeOpPonctuellesConstantes.MO);
				orderItem.setExternalId(lgnCommandeEC.getRefExterne());
				orderItem.setId(lgnCommandeEC.getId());
				orderItem.setOfferSpecificationCode(offre.getValeurConstante());
				orderItemsList.add(orderItem);
			}

		}
		return orderItemsList;
	}

	/**
	 * Fonction utilitaire permettant d'initialiser un serviceOrder � partir d'une commande.
	 * 
	 * @param commandeDTOs
	 * @return serviceOrder
	 */
	public static ServiceOrder initialiserServiceOrderViaCommande(final CommandeDTO commandeDTOs) {
		ServiceOrder serviceOrder = new ServiceOrder();
		// Id
		String idCommande = commandeDTOs.getId();
		serviceOrder.setId(idCommande);
		// State
		ServiceOrderStatus state = ServiceOrderUtils.determinerStatut(commandeDTOs);
		serviceOrder.setState(state);
		// Task
		final TacheEnCoursDTO tacheEnCoursDTO = CollectionUtils.getFirstOrNull(PROCESSUS_MANAGER.findTacheEnCoursByCommande(idCommande));
		if (tacheEnCoursDTO != null) {
			// TaskId
			serviceOrder.setTaskRefId(tacheEnCoursDTO.getId());
		}

		// AbortEventCause
		final List<ProcessusDTO> processus = SERVICE_MANAGER.getProcessusManager().findProcessusByCommande(idCommande);
		ProcessusDTO processusDto = ProcessusUtil.extraireProcessusLivraison(processus);
		// Si le processus de livraison n'est pas trouv�, on recup�re le processus de compl�tude
		if (processusDto == null) {
			processusDto = ProcessusUtil.extraireProcessusCompletude(processus);
		}
		// � partir de la G10R06C00 (US-2019) les commandes sont cr��es d'une mani�re diff�rente.
		// Dans une premi�re temps, on cr�e une v�rsion r�duite de la comande (avec seulement les donn�es n�cessaires)
		// et si la commande est rejet�e on ne vas pas instancier les processus ou remplir d'autres donn�es comme la ldc
		if (processusDto != null) {
			List<EvtDTO> evts = ServiceManager.getInstance().getProcessusManager().findEvtByProcessus(processusDto.getId());
			for (EvtDTO evt : evts) {
				CauseEvenementDTO causeEvt = ServiceManager.getInstance().getReferenceSpaceManager().findInReferenceSpace(CauseEvenementDTO.class, evt.getCauseEvenement().getId());
				if (Arrays.asList(TypeEvenementConstantes.EVTABANDON_VALEUR_CONSTANTE, TypeEvenementConstantes.EVTABANMANU_VALEUR_CONSTANTE, TypeEvenementConstantes.ABD_COMPL_NOTPARCFT_VALEUR_CONSTANTE).contains(causeEvt.getTypeEvenement().getValeurConstante())) {
					EventCauseRef CauseRef = new EventCauseRef();
					CauseRef.setId(causeEvt.getValeurConstante());
					CauseRef.setComment(evt.getInfo());
					serviceOrder.setAbortEventCause(CauseRef);
					break;
				}
			}
		}

		// ExternalId
		serviceOrder.setExternalId(commandeDTOs.getRefExterne());

		// JobCase
		if (commandeDTOs.getCasMetier() != null) {
			serviceOrder.setJobCase(commandeDTOs.getCasMetier().getId());
		}

		// Note
		final List<Note> note = new ArrayList<Note>();
		final List<BlocNoteDTO> blocsnoteList = COMMANDE_MANAGER.findBlocNoteByCommande(idCommande);
		Note observation;
		for (BlocNoteDTO blocnote : blocsnoteList) {
			observation = new Note();
			observation.setType(NoteType.serviceOrder);
			observation.setId(blocnote.getId());
			observation.setText(blocnote.getInfo());
			observation.setDate(DateUtils.toCalendar(blocnote.getDateCreation()));
			observation.setAuthor(blocnote.getEcritParAgent().getId());
			note.add(observation);
		}
		serviceOrder.setNotesList(note);

		// Appointment
		Collection<InterventionDTO> interventionlst = INTERVENTION_MANAGER.getInterventionsByIdCommande(idCommande);
		InterventionDTO intervention = INTERVENTION_MANAGER.recupererInterventionPlusRecente(interventionlst);
		if (intervention != null) {

			AppointmentRef appointmentRef = new AppointmentRef();
			appointmentRef.setId(intervention.getId());
			appointmentRef.setState(AppointmentStatus.getEtatById(intervention.getEtatIntervention().getId()));
			serviceOrder.setAppointmentRef(appointmentRef);
		}

		// OrderItem
		List<LigneCommandeDTO> lgnCommande = COMMANDE_MANAGER.findLigneCommandeByCommande(idCommande);
		List<OrderItem> orderItemsList = new ArrayList<OrderItem>();
		orderItemsList = getOrderItem(lgnCommande);
		serviceOrder.setOrderItemsList(orderItemsList);

		return serviceOrder;
	}

	/**
	 * Fonction utilitaire permettant d'initialiser un serviceOrderV2 � partir d'une commande.
	 * 
	 * @param commandeDTO
	 * @return serviceOrder
	 */
	public static com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.ServiceOrder initialiserServiceOrderV2ViaCommande(final CommandeDTO commandeDTO) {
		com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.ServiceOrder serviceOrder = new com.soliste.bolbec.livraison.service.ejb.sb.api.v2.modele.serviceOrder.ServiceOrder(
				initialiserServiceOrderViaCommande(commandeDTO));

		List<LigneCommandeDTO> lgnCommande = COMMANDE_MANAGER.findLigneCommandeByCommande(commandeDTO.getId());

		// ContractorCustomer
		CustomerRef contractorCustomer = new CustomerRef();
		contractorCustomer.setId(commandeDTO.getClient().getId());
		if (commandeDTO.getClient().getAdresse() != null) {
			AddressRef address = new AddressRef();
			address.setId(commandeDTO.getClient().getAdresse().getId());
			contractorCustomer.setAddress(address);
		}
		serviceOrder.setContractorCustomer(contractorCustomer);

		// DeliveredCustomer
		LigneCommandeDTO ligneCmd = CollectionUtils.getFirstOrNull(lgnCommande);
		CustomerRef deliveredCustomer = new CustomerRef();
		// � partir de la G10R06C00 (US-2019) les commandes sont cr��es d'une mani�re diff�rente.
		// Dans une premi�re temps, on cr�e une v�rsion r�duite de la comande (avec seulement les donn�es n�cessaires)
		// et si la commande est rejet�e on ne vas pas instancier les processus ou remplir d'autres donn�es comme la ldc
		if (ligneCmd != null) {
			deliveredCustomer.setId(ligneCmd.getClient().getId());
			if (ligneCmd.getClient().getAdresse() != null) {
				AddressRef address = new AddressRef();
				address.setId(ligneCmd.getClient().getAdresse().getId());
				deliveredCustomer.setAddress(address);
			}
		}

		serviceOrder.setDeliveredCustomer(deliveredCustomer);

		return serviceOrder;
	}

	/**
	 * determinerStatut
	 * Fonction utilitaire permettant de d�terminer le statut de la commande.
	 * 
	 * @param commande
	 * @return
	 */
	public static ServiceOrderStatus determinerStatut(final CommandeDTO commande) {
		ServiceOrderStatus status = ServiceOrderStatus.fromEtatArtemis(commande.getEtatCommande().getId());

		// Cas particulier : si le commande est "IN PROGRESS" et au niveau du papaprocessus en cours l'�tat est � "abandonn�", la commande est donc en cours d'annulation
		if (status == ServiceOrderStatus.inprogress) {
			ProcessusDTO processusDto;
			final List<ProcessusDTO> processusList = PROCESSUS_MANAGER.findProcessusByCommande(commande.getId());
			processusDto = ProcessusUtil.extraireProcessusLivraison(processusList);
			// Si le processus de livraison n'est pas trouv�, on recup�re le processus de compl�tude
			if (processusDto == null) {
				processusDto = ProcessusUtil.extraireProcessusCompletude(processusList);
			}
			if (EtatProcessusConstantes.ANNUL.equals(processusDto.getEtatProcessus().getId())) {
				status = ServiceOrderStatus.aborting;
			}
		}
		return status;
	}

	/**
	 * Fonction utilitaire permettant de d�terminer la liste de commandes concern�e par l'intervention.
	 * 
	 * @param interventionId
	 * @return
	 */
	public static List<CommandeDTO> findCommandeByIdIntervention(final String interventionId) {

		List<LigneCommandeDTO> lgncommandeDTOs = COMMANDE_MANAGER.findLigneCommandeByIntervention(interventionId);
		List<CommandeDTO> commandeDTOs = new ArrayList<CommandeDTO>();

		for (LigneCommandeDTO lgncommande : lgncommandeDTOs) {
			CommandeDTO commandeDTO = COMMANDE_MANAGER.findCommandeByLigneCommande(lgncommande.getId());
			commandeDTOs.add(commandeDTO);
		}
		return commandeDTOs;
	}

	/**
	 * Fonction utilitaire permettant de garder les �l�ments pr�sents dans les 2 listes et les ins�re dans une nouvelle liste.
	 * 
	 * @param lstCom1 <CommandeDTO>
	 * @param lstCom2 <CommandeDTO>
	 */
	public static List<CommandeDTO> comparerListeEtGarderDoublons(final List<CommandeDTO> lstCom1, final List<CommandeDTO> lstCom2) {
		List<CommandeDTO> lstResult = new ArrayList<CommandeDTO>();
		for (CommandeDTO lstcom : lstCom1) {
			if (!(lstcom == null)) {
				for (CommandeDTO lstcomp : lstCom2) {
					if (lstcom.getId().equals(lstcomp.getId())) {
						lstResult.add(lstcom);
					}
				}
			}
		}
		return lstResult;
	}

	/**
	 * Fonction utilitaire permettant de retourner l'eventCause en fonction des causes �v�nements disponibles,
	 * selon le type d'evenement et le CancellingType.
	 * 
	 * @param causeEvenements
	 * @param typeEvenement
	 * @param type
	 * @return
	 */
	public static EventCause initialiserEventCause(CauseEvenementDTO causeEvenements, String typeEvenement, CancellingType type) {

		EventCause event = new EventCause();
		event.setId(causeEvenements.getValeurConstante());
		event.setLabel(causeEvenements.getLibelle());
		if (typeEvenement.equals(causeEvenements.getTypeEvenement().getId())) {
			event.setCancellingType(type);
		}
		return event;

	}

	/**
	 * Retourne la liste des causes d'�v�nement s�lectionnables pour cloturer une commande.
	 * 
	 * @param process le process associ�
	 * 
	 * @return une liste d'instances de CauseEvenementDTO
	 * @throws DataException
	 */
	public static List<EventCause> getCauseEvenementAutoriseesPourCloturer(ProcessusDTO process) throws DataException {
		ProcessusActionsAutorisees avpActionAutorisees = ActionsAutoriseesUtil.getProcessusActionsAutorisees(process, null);
		List<CauseEvenementDTO> causeEvenements = new ArrayList<CauseEvenementDTO>();
		List<EventCause> eventlst = new ArrayList<EventCause>();

		// Recuperation des causes evenements en fonction des actions autoris�es (abandon auto, manuel, regul...)
		if (avpActionAutorisees.isAbandonnable()) {
			causeEvenements = CauseEvenementUtil.getCauseEvenementAutoriseesPourAbandonnerByProcessus(process.getId(), null, null);

			for (CauseEvenementDTO causeEvenementlst : causeEvenements) {
				EventCause event = ServiceOrderUtils.initialiserEventCause(causeEvenementlst, TypeEvenementConstantes.EVTABANDON, CancellingType.autoAbort);
				eventlst.add(event);
			}
		}
		if (avpActionAutorisees.isStoppable()) {
			causeEvenements = CauseEvenementUtil.getCauseEvenementAutoriseesPourAbandonnerByProcessus(process.getId(), null, null);

			for (CauseEvenementDTO causeEvenementlst : causeEvenements) {
				EventCause event = ServiceOrderUtils.initialiserEventCause(causeEvenementlst, TypeEvenementConstantes.EVTABANMANU, CancellingType.manuelAbort);
				eventlst.add(event);
			}
		}
		return eventlst;
	}

	/**
	 * Gets the cause evenement abandon generiques.
	 *
	 * @param version the sys externe
	 * @return the cause evenement abandon generiques
	 * 
	 * <BR><B>HISTORIQUE:</B>
	 * <TABLE frame='border'>
	 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
	 * <TR><TD>11/12/2017</TD><TD>CDS</TD><TD>EV-469</TD></TR>
	 * </TABLE>
	 */
	public static List<EventCause> getCauseEvenementAbandonGeneriques(String version) {
		List<CauseEvenementDTO> causeEvenements = CauseEvenementUtil.getCauseEvenementAbandonGeneriqueParVersion(version);
		List<EventCause> eventlst = new ArrayList<EventCause>();

		for (CauseEvenementDTO causeEvenementDTO : causeEvenements) {
			TypeEvenementDTO typeEvt = causeEvenementDTO.getTypeEvenement();
			EventCause event = ServiceOrderUtils.initialiserEventCause(causeEvenementDTO, typeEvt.getId(), CancellingType.autoAbort);
			eventlst.add(event);
		}

		return eventlst;
	}

}
