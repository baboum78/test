/*
 * ------ tags PVCS - Ne pas modifier svp -----
 *   Composant : %PM%
 *   Revision  : %PR%
 *   DateRev   : %PRT%
 *   Chemin    : %PW%%PM%
 * --------------------------------------------
 *   Historique  : 
 *    %PL%
 * --------------------------------------------
 */

package com.soliste.bolbec.livraison.service.ejb.sb.processus.data;

/**
 * <BR><B>HISTORIQUE:</B>
 * <TABLE frame='border' bgcolor=green>
 * <TR><TD>DATE</TD><TD>USER</TD><TD>DETAIL</TD></TR>
 * <TR><TD>10/05/2022</TD><TD>LBA</TD><TD>Initialisation javadoc</TD></TR>
 * </TABLE><BR>
 */

/**
 * Les infos d'AVP pour les AVP de type "AvpAffBLO" et cause evenement IPON_IMMEUBLE_NON_TROUVE
 *
 */
public class AvpAffBLOImmNonTrouveDTO extends AvpInfoDTO {

	private String codeImb;


	public String getType() {
		return AVP_AFF_BLO_IMM_NON_TROUVE;
	}

	/**
	 * Getter of the codeIMB
	 * @return
	 */
	public String getCodeImb() {
		return codeImb;
	}

	/**
	 * Setter of codeIMB
	 * @param codeImb
	 */
	public void setCodeImb(String codeImb) {
		this.codeImb = codeImb;
	}
}
